package de.goerner.maklercockpit.handy;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Locale;

/**
 * v52: Gibt genau ein Bild aus dem App-Cache (Ordner „mail“) nur lesend an die Mail-App weiter,
 * damit das Anschreiben an Hausverwaltungen mit Bild-Anhang geöffnet werden kann. Keine anderen Dateien.
 */
public final class BildProvider extends ContentProvider {
    @Override public boolean onCreate() { return true; }

    private File datei(Uri u) {
        if (getContext() == null || u == null) return null;
        String n = u.getLastPathSegment();
        if (n == null || n.contains("/") || n.contains("..") || n.isEmpty()) return null;
        return new File(new File(getContext().getCacheDir(), "mail"), n);
    }

    @Override public ParcelFileDescriptor openFile(Uri u, String mode) throws FileNotFoundException {
        File f = datei(u);
        if (f == null || !f.isFile()) throw new FileNotFoundException("nicht gefunden");
        return ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY);
    }

    @Override public String getType(Uri u) {
        String n = String.valueOf(u.getLastPathSegment()).toLowerCase(Locale.ROOT);
        return n.endsWith(".png") ? "image/png" : "image/jpeg";
    }

    @Override public Cursor query(Uri u, String[] p, String s, String[] a, String o) {
        File f = datei(u);
        if (f == null || !f.isFile()) return null;
        MatrixCursor c = new MatrixCursor(new String[]{ OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE });
        c.addRow(new Object[]{ f.getName(), f.length() });
        return c;
    }

    @Override public Uri insert(Uri u, ContentValues v) { return null; }
    @Override public int delete(Uri u, String s, String[] a) { return 0; }
    @Override public int update(Uri u, ContentValues v, String s, String[] a) { return 0; }
}
