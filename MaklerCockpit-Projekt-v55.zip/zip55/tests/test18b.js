// v18: Status „Per Kleinanzeigen angeschrieben“
const { chromium } = require('playwright');
let fehler = 0; const ok = (b, t) => { if(!b){ fehler++; console.log('FEHLER:', t); } else console.log('ok  ', t); };
(async () => {
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 1536, height: 1000 }, deviceScaleFactor: 2 });
  const fe = []; p.on('pageerror', e => { fe.push(e.message); console.log('SEITENFEHLER', e.message); });
  await p.addInitScript(() => {
    const alt = { objekte: [
        { id:'ka1', createdAt: Date.now()-5000, akqTitel:'Baugrundstück 800 m²', objektart:'Grundstück', ort:'Mahlow', kaufpreis:210000, auftragsart:'verkauf', status:'neu', quelle:'Kleinanzeigen', privat:'ja', grundstueck:800, link:'https://www.kleinanzeigen.de/s-anzeige/baugrundstueck/2912345678-208-3398', verlauf:[] },
        { id:'ka2', createdAt: Date.now()-9000, akqTitel:'Reihenhaus', objektart:'Reihenhaus', ort:'Teltow', kaufpreis:420000, auftragsart:'verkauf', status:'kleinanzeigen_geschrieben', kleinanzeigenAm: Date.now()-7*864e5, quelle:'Kleinanzeigen', privat:'ja', verlauf:[] } ],
      kontakte: [], termine: [], marktanalysen: [], aufgaben: [], notizen: [], mentorFragen: [], meta: { v9neustart: { quittiert: true } } };
    window.__geoeffnet = []; window.open = u => { window.__geoeffnet.push(u); };
    window.pc = { laden: () => JSON.parse(JSON.stringify(alt)), speichern: () => ({ ok:true }), ordner(){}, sicherungSchreiben: () => ({ ok:true }), sicherungLesen: () => null, zwischenablage: async () => '', abruf: async () => ({ ok:false }) };
  });
  await p.goto('file:///tmp/pc/app/index.html'); await p.waitForTimeout(1500);
  const ev = (f, ...a) => p.evaluate(f, ...a);
  await ev(() => { AQ2.status = 'offen'; AQ2.sel = 'ka1'; wechsleAnsicht('akquise'); }); await p.waitForTimeout(300);
  ok(await ev(() => OBJEKT_STATUS.some(s => s[0] === 'kleinanzeigen_geschrieben' && /Per Kleinanzeigen angeschrieben/.test(s[1]))), 'Status in der Liste');
  ok(await ev(() => [...document.querySelectorAll('#aqDetail select option')].some(o => o.value === 'kleinanzeigen_geschrieben')), 'Im Lead auswählbar');
  ok(await ev(() => document.querySelectorAll('#aqListe .lc').length === 2), 'Gilt als offener Lead');
  ok(await ev(() => /Nachricht/.test(document.querySelectorAll('.dp-aktionen button')[1].textContent)), 'Knopf heißt „Nachricht“ (keine E-Mail, aber Anzeige)');
  await ev(() => aq2Email()); await p.waitForTimeout(150);
  ok(await ev(() => /Nachricht bei Kleinanzeigen verschickt/.test(document.getElementById('dpErgebnis').textContent) && window.__geoeffnet.slice(-1)[0].includes('kleinanzeigen.de')), 'Anschreiben kopiert, Anzeige geöffnet, Frage „bei Kleinanzeigen verschickt?“');
  await ev(() => document.querySelector('#dpErgebnis button').click()); await p.waitForTimeout(200);
  const r = await ev(() => { const o = findObjekt('ka1'); return { st:o.status, am: !!o.kleinanzeigenAm, vl:o.verlauf.slice(-1)[0], pill: document.querySelector('#lc-ka1 .pill').textContent, kpi: document.querySelectorAll('.kpi2, .aq-kpi, [onclick*="kontaktiert"]').length }; });
  ok(r.st === 'kleinanzeigen_geschrieben' && r.am && r.vl.typ === 'email' && r.vl.text === 'Per Kleinanzeigen angeschrieben', 'Status gesetzt + Verlauf: ' + r.vl.text);
  ok(r.pill === 'Kleinanzeigen angeschrieben', 'Pill auf der Karte: ' + r.pill);
  ok(await ev(() => tbHinweise().some(h => /1 Kleinanzeigen-Nachricht seit über 5 Tagen/.test(h.t))), 'Glocke: Nachfassen nach 5 Tagen');
  await p.screenshot({ path: '/tmp/v18test/3_kleinanzeigen_status.png' });
  await ev(() => wechsleAnsicht('objekte')); await p.waitForTimeout(200);
  ok(await ev(() => /Per Kleinanzeigen angeschrieben/.test(document.getElementById('main').innerText)), 'Auch in der Objekte-Ansicht');
  ok(fe.length === 0, 'Keine Seitenfehler');
  console.log('\nFEHLER', fehler); await b.close(); process.exit(fehler ? 1 : 0);
})();
