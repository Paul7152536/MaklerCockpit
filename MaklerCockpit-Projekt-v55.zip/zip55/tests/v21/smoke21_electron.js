const { app, BrowserWindow } = require('electron'); const fs = require('fs'); const path = require('path');
const HOME = '/tmp/claude-0/-home-claude/fcfe88c9-293d-574d-8cfa-b1821c923895/scratchpad/etest/home21';
app.setPath('documents', HOME + '/Dokumente');
require(process.env.MC_MAIN || '/tmp/pc/app/main.js');
app.whenReady().then(() => setTimeout(async () => {
  const w = BrowserWindow.getAllWindows()[0];
  const lesen = async (datei, typ) => w.webContents.executeJavaScript(`(async()=>{
    const t0 = Date.now();
    const b64 = '${fs.readFileSync(datei).toString('base64')}';
    const bytes = Uint8Array.from(atob(b64), c => c.charCodeAt(0));
    const f = new File([bytes], '${path.basename(datei)}', { type:'${typ}' });
    const s = await zlDateiLesen(f, () => {});
    await zlOcrEnde();
    const r = zlAnalysieren(s, { quelle:'Test' });
    return JSON.stringify({ ms: Date.now() - t0, art: s.map(x => x.art), a: r.angebote.length, g: r.gesuche.length, w: r.weg.filter(x => x.grund !== 'zu kurz').length, tel: r.angebote.filter(x => x.f.telefon).length, preis: r.angebote.filter(x => x.f.preis).length, datum: r.datum, ges: r.gesuche.map(g => (g.wer||g.chiffre) + ':' + g.preisMax) });
  })()`);
  try{
    console.log('TEXT-PDF', await lesen('/tmp/v21test/zeitung_text.pdf', 'application/pdf'));
    console.log('SCAN-PDF', await lesen('/tmp/v21test/zeitung_scan.pdf', 'application/pdf'));
    console.log('FOTO-JPG', await lesen('/tmp/v21test/zeitung_foto.jpg', 'image/jpeg'));
    console.log('VERSION', await w.webContents.executeJavaScript(`document.body.innerText.includes('v21') + ' ' + !!document.querySelector('script[src="vendor/pdf.min.js"]')`));
  }catch(e){ console.log('FEHLER', e && e.message || e); }
  app.exit(0);
}, 3000));
