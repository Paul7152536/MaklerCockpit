// Reine Lese-Logik: knifflige Anzeigentexte
const ctx = require('./harness.js');
let fehler = 0; const ok = (b, t) => { if(!b){ fehler++; console.log('FEHLER:', t); } else console.log('ok  ', t); };
const G = t => ctx.zlGesuchKriterien(t);
let g = G('Suche Haus/Grundstück im Raum Oranienburg, Hohen Neuendorf, bis ca. 450 T€, gern auch renovierungsbedürftig. ☎ 0171-2223334');
ok(g.arten.includes('EFH') && g.arten.includes('Grundstück') && g.orte.join() === 'Oranienburg,Hohen Neuendorf' && g.preisMax === 450000, 'Haus/Grundstück, zwei Orte, 450 T€: ' + JSON.stringify(g));
g = G('Pärchen sucht 2-3 Zi.-Whg. zum Kauf in Pankow/Prenzlauer Berg, bis 350.000,- €, Tel. 0176/12345678');
ok(g.arten.join() === 'Wohnung' && g.orte.join() === 'Pankow,Prenzlauer Berg' && g.preisMax === 350000 && g.zimmerMin === 2 && g.nutzung === 'kauf', '2-3 Zi.-Whg. Pankow/Prenzlauer Berg: ' + JSON.stringify(g));
g = G('Kaufe Haus von privat in Berlin und Umland, schnelle Abwicklung, Tel. 0151 1234567');
ok(g.berlinAlle && g.umland && g.orte.length === 0, 'Berlin und Umland: ' + JSON.stringify(g));
g = G('Familie sucht EFH mit mind. 600 m² Grundstück in Werder (Havel) oder Schwielowsee, Wfl. ab 130 m², max. 700.000 €');
ok(g.grundstueckMin === 600 && g.flaecheMin === 130 && g.preisMax === 700000 && g.orte.some(o => /Werder/.test(o)) && g.orte.includes('Schwielowsee'), 'Grundstück ab 600, Wfl. ab 130: ' + JSON.stringify(g));
g = G('Suche 2-Zimmer-Wohnung zur Miete in Spandau, bis 900 € warm');
ok(g.nutzung === 'miete' && g.preisMax === 900, 'Mietgesuch bis 900 € warm');
// Telefon / Preis / Ort
ok(ctx.zlTel('VB 489.000 €, privat, Tel. 0171 / 234 56 78') === '0171 / 234 56 78', 'Telefon mit Schrägstrich');
ok(ctx.zlTel('2005, 4 Zi., 125 m², 550 m² Grdst., 459.000 €') === '', 'keine Telefonnummer aus Preisen/Flächen');
ok(ctx.zlTel('Infos unter 0331-2001234 ab 18 Uhr') === '0331-2001234', 'Telefon ohne „Tel.“');
ok(ctx.zlPreisAngebot('KP 299.000 €, zzgl. 3,57 % Käuferprovision', false).w === 299000, 'Preis trotz Provision daneben');
ok(ctx.zlPreisAngebot('Preis: 349 T€ VB', false).s === '349.000 € VB', 'T€ mit VB');
ok(ctx.zlPreisAngebot('780 € kalt + NK, Kaution 2.340 €', true).s === '780 € kalt', 'Miete kalt, Kaution ignoriert');
ok(ctx.zlOrtAngebot('Teltow: Gepflegte 3-Zi.-ETW, 75 m², 289.000 €') === 'Teltow', 'Ort vorne mit Doppelpunkt');
ok(ctx.zlOrtAngebot('Schönes Baugrundstück in Brieselang, 600 m², 159.000 €') === 'Brieselang', 'Ort nach „in“');
ok(ctx.zlOrtAngebot('Großzügige DHH, Nähe Potsdam, 5 Zi., 520.000 €') === 'Potsdam', 'bekannter Ort im Text');
ok(ctx.zlIstMakler('Bungalow, privat, keine Makler!') === false && ctx.zlIstMakler('KP 299.000 €, zzgl. 3,57 % Käuferprovision') === true, 'Makler erkennen, „keine Makler“ nicht');
ok(ctx.zlDatumAus('Ausgabe vom Samstag, 7. November 2026') === '2026-11-07', 'Datum aus Kopfzeile');
// ganze Analyse aus Rohzeilen (ohne Layout): Verkäufer, der auch sucht → Angebot
const z = (t, y) => ({ x0:0, x1:200, y, yb:y + 9, h:9, text:t, fett:false });
const r = ctx.zlAnalysieren([{ nr:1, zeilen:[z('Verkaufe ETW in Steglitz, 2 Zi., 65 m²,', 0), z('279.000 €, suche gleichzeitig größere', 10), z('Wohnung, Tel. 030 9876543', 20)] }], { quelle:'Test' });
ok(r.angebote.length === 1 && r.gesuche.length === 0, 'Verkäufer, der auch sucht → Angebot');
console.log('\nFEHLER', fehler); process.exit(fehler ? 1 : 0);
