# Erzeugt eine realistische Anzeigenseite (4 Spalten, Rubriken, fett gesetzte Anzeigenanfänge, Trennlinien)
from reportlab.lib.pagesizes import A4
from reportlab.platypus import BaseDocTemplate, Frame, PageTemplate, Paragraph, Spacer
from reportlab.platypus.flowables import HRFlowable
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
import glob, sys
reg = glob.glob('/usr/share/fonts/**/DejaVuSans.ttf', recursive=True)[0]
bold = glob.glob('/usr/share/fonts/**/DejaVuSans-Bold.ttf', recursive=True)[0]
pdfmetrics.registerFont(TTFont('DV', reg)); pdfmetrics.registerFont(TTFont('DV-Bold', bold))
from reportlab.lib.fonts import addMapping
addMapping('DV', 0, 0, 'DV'); addMapping('DV', 1, 0, 'DV-Bold')
txt = ParagraphStyle('t', fontName='DV', fontSize=7.4, leading=8.9)
rub = ParagraphStyle('r', fontName='DV-Bold', fontSize=9.5, leading=12, spaceBefore=4, spaceAfter=3, textColor='#000000', backColor='#dddddd', borderPadding=2)
RUBRIKEN = [
 ('Häuser – Verkauf', [
  '<b>Falkensee:</b> Freist. EFH, Bj. 1998, 5 Zi., ca. 140 m² Wfl., 620 m² Grdst., Garage, VB 489.000 €, privat, Tel. 0171 / 234 56 78',
  '<b>Dallgow-Döberitz,</b> DHH, 4 Zi., 118 m² Wfl., EBK, Garten, KP 429.000 €, von privat, Tel. 03322 - 21 45 67',
  '<b>Spandau –</b> Reihenmittelhaus, 4 Zi., ca. 105 m², Bj. 1975, renovierungsbed., 349.000 € VB, Zuschriften unter Chiffre ZA 4711 an den Verlag',
  '<b>Nauen –</b> Gepfl. Bungalow, 3 Zi., 90 m² Wfl., 800 m² Grst., KP 299.000 €, zzgl. 3,57 % Käuferprovision. Muster Immobilien GmbH, Tel. 03321 / 44 55 66, www.muster-immo.de',
  '<b>Brieselang,</b> EFH, Bj. 2005, 4 Zi., 125 m², 550 m² Grdst., 459.000 €, Tel. 033232 / 12345',
  '<b>Wustermark OT Elstal:</b> Reihenendhaus, 5 Zi., 130 m² Wfl., 300 m² Grdst., KP 395.000 €, privat, 0157 33344455',
  '<b>Hennigsdorf –</b> Zweifamilienhaus, 2 x 3 Zi., 180 m² Wfl., 700 m² Grdst., VB 520.000 €, Tel. 03302 / 556677',
  '<b>Kleinmachnow:</b> Großzügiges EFH mit Einliegerwohnung, 7 Zi., 210 m² Wfl., 900 m² Grundstück, Bj. 1936, saniert, 1.150.000 €, privat, Tel. 0152-11122233',
 ]),
 ('Eigentumswohnungen', [
  '<b>Berlin-Mitte,</b> 3-Zi.-ETW, 80 m², Balkon, 4. OG mit Aufzug, vermietet, 520.000 €, privat, Tel. 030/1234567',
  '<b>Spandau-Siemensstadt:</b> 1-Zi.-Apartment, 34 m², vermietet, 129.000 €, Tel. 030 7778889, keine Makler',
  '<b>Potsdam-Babelsberg:</b> helle 2-Zi.-Whg., 58 m², EBK, Bj. 1995, FP 249.000,- €, E-Mail: wohnung.babelsberg@web.de',
 ]),
 ('Grundstücke', [
  '<b>Baugrundstück</b> in Schönwalde-Glien, 750 m², voll erschlossen, 185.000 € VB, Tel. 0160 9988776',
 ]),
 ('Vermietungen', [
  '<b>Spandau,</b> 2-Zi.-Whg., 62 m², 780 € kalt + NK, ab 1.12. frei, Tel. 030 3311223',
 ]),
 ('Immobilien-Gesuche', [
  '<b>Junge Familie</b> sucht EFH oder DHH in Falkensee, Dallgow oder Spandau, ab 4 Zi., bis 500.000 €. Tel. 0176 55544433',
  '<b>Suche ETW</b> in Potsdam oder Berlin-Steglitz, 2-3 Zi., ab 60 m², max. 300 T€, Kauf. Chiffre ZA 4812',
  '<b>Rentnerpaar</b> sucht ebenerdigen Bungalow in Nauen oder Falkensee bis 350.000 €, E-Mail: rentner.paar@gmx.de',
  '<b>Ärztin sucht</b> Haus mit Garten im Raum Potsdam/Werder, ab 120 m² Wfl., bis 650.000 €, Tel. 0170 1231234',
  '<b>Wir (2 Erw., 2 Kinder) suchen</b> DHH oder RH in Hennigsdorf oder Velten, bis 420.000 €, gern renovierungsbedürftig. Tel. 0163 4445556',
  '<b>Für vorgemerkte Kunden</b> suchen wir Häuser und Wohnungen in Berlin und Umland. Sofortige Bewertung! Muster Immobilien GmbH, Tel. 03321 / 44 55 66',
  '<b>Kaufe Grundstück</b> in Schönwalde oder Brieselang, auch Bauerwartungsland, bis 200.000 €, Tel. 0172 1112223',
  '<b>Suche 3-Zi.-Wohnung</b> zur Miete in Falkensee, bis 1.100 € warm, Tel. 0151 2223334',
 ]),
 ('Verschiedenes', [
  '<b>Wohnwagen</b> Hobby 495, Bj. 2010, guter Zustand, 8.500 €, Tel. 0174 1212121',
 ]),
 ('Kfz-Markt', [
  '<b>VW Golf 7,</b> Bj. 2016, 98.000 km, TÜV neu, 9.800 € VB, Tel. 0171 9998887',
 ]),
 ('Stellenangebote', [
  '<b>Reinigungskraft</b> (m/w/d) für Büro in Falkensee gesucht, 14 €/Std., Tel. 03322 445566',
 ]),
 ('Urlaub & Reisen', [
  '<b>Ferienwohnung</b> an der Ostsee, 2 Zi., ab 75 €/Nacht, Tel. 038 12345',
 ]),
]
def kopf(c, doc):
    c.saveState(); c.setFont('DV-Bold', 14); c.drawString(15*mm, A4[1]-14*mm, 'Havelland Kurier – Kleinanzeigen')
    c.setFont('DV', 8); c.drawRightString(A4[0]-15*mm, A4[1]-14*mm, 'Mittwoch, 4. November 2026 · Seite 12')
    c.line(15*mm, A4[1]-16.5*mm, A4[0]-15*mm, A4[1]-16.5*mm); c.restoreState()
def bauen(pfad):
    doc = BaseDocTemplate(pfad, pagesize=A4, leftMargin=15*mm, rightMargin=15*mm, topMargin=20*mm, bottomMargin=12*mm)
    n = 4; gap = 4*mm; w = (A4[0]-30*mm-(n-1)*gap)/n
    frames = [Frame(15*mm+i*(w+gap), 12*mm, w, A4[1]-32*mm, id='c%d'%i, leftPadding=0, rightPadding=0, topPadding=0, bottomPadding=0) for i in range(n)]
    doc.addPageTemplates([PageTemplate(id='p', frames=frames, onPage=kopf)])
    story = []
    for r, ads in RUBRIKEN:
        story.append(Paragraph(r, rub))
        for a in ads:
            story.append(Paragraph(a, txt)); story.append(Spacer(1, 2.2)); story.append(HRFlowable(width='100%', thickness=0.3, color='#888888')); story.append(Spacer(1, 2.2))
    # Fülltext, damit es nach Zeitung aussieht (redaktioneller Teil darf nicht als Anzeige gelten)
    story.append(Paragraph('Leserbriefe', rub))
    story.append(Paragraph('Der Ortsbeirat tagt am kommenden Dienstag im Rathaus. Themen sind unter anderem der Ausbau des Radwegs und die neue Kita an der Bahnhofstraße.', txt))
    doc.build(story)
bauen(sys.argv[1])
