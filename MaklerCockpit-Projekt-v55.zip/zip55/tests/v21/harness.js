// Lädt die reinen Lese-Funktionen in Node (ohne Browser) und wertet ein PDF mit Textebene aus
const fs = require('fs'), vm = require('vm');
const ctx = { console, document:{ addEventListener(){} }, window:{} };
vm.createContext(ctx);
const quelle = (datei, namen) => { const s = fs.readFileSync(datei, 'utf8'); return namen.map(n => { const i = s.indexOf('function ' + n + '('); if(i < 0) throw new Error('fehlt ' + n); let t = 0, j = s.indexOf('{', i); for(; j < s.length; j++){ if(s[j] === '{') t++; else if(s[j] === '}'){ t--; if(!t) break; } } return s.slice(i, j + 1); }).join('\n'); };
vm.runInContext(fs.readFileSync('/tmp/jvb/markt_kompakt.js', 'utf8').replace('const MC_MARKT', 'var MC_MARKT'), ctx);
vm.runInContext(quelle('/tmp/jvb/extras20.js', ['x20Norm']), ctx);
vm.runInContext(quelle('/tmp/jvb/akquise.js', ['akqZahl', 'akqObjektart', 'akqPreis', 'akqFlaechen']), ctx);
vm.runInContext(fs.readFileSync('/tmp/jvb/zeitung21.js', 'utf8').replace(/^const /gm, 'var ').replace(/^let /gm, 'var '), ctx);
module.exports = ctx;
if(require.main === module){
  (async () => {
    const pdfjs = require('/tmp/claude-0/-home-claude/fcfe88c9-293d-574d-8cfa-b1821c923895/scratchpad/ocr/node_modules/pdfjs-dist/legacy/build/pdf.js');
    const doc = await pdfjs.getDocument({ data: new Uint8Array(fs.readFileSync(process.argv[2])), standardFontDataUrl: undefined }).promise;
    const seiten = [];
    for(let i = 1; i <= doc.numPages; i++){
      const p = await doc.getPage(i), vp = p.getViewport({ scale: 1 }), tc = await p.getTextContent();
      await p.getOperatorList();
      const fonts = {}; for(const it of tc.items){ if(!fonts[it.fontName]){ try{ fonts[it.fontName] = p.commonObjs.get(it.fontName).name; }catch(e){ fonts[it.fontName] = ''; } } }
      seiten.push({ nr: i, zeilen: ctx.zlZeilenAusPdf(tc.items, vp.transform, fonts) });
    }
    const r = ctx.zlAnalysieren(seiten, { quelle: 'Havelland Kurier' });
    console.log('DATUM', r.datum, 'RUBRIKEN', r.rubriken.join(' | '));
    console.log('\nANGEBOTE', r.angebote.length); r.angebote.forEach(a => console.log(' -', JSON.stringify({ o:a.f.objekt, l:a.f.lage, p:a.f.preis, t:a.f.telefon, m:a.f.email, k:a.f.kontakt, pr:a.f.privat.slice(0,8), miete:a.miete })));
    console.log('\nGESUCHE', r.gesuche.length); r.gesuche.forEach(g => console.log(' -', JSON.stringify({ wer:g.wer, arten:g.arten, orte:g.orte, max:g.preisMax, zi:g.zimmerMin, fl:g.flaecheMin, gr:g.grundstueckMin, n:g.nutzung, t:g.telefon, m:g.email, c:g.chiffre, bA:g.berlinAlle, um:g.umland })));
    console.log('\nWEG', r.weg.length); r.weg.forEach(w => console.log(' -', w.grund, '|', w.text.slice(0, 70)));
  })();
}
