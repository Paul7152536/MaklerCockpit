// v21: Zeitung lesen (PDF mit Text), Suchkunden, Trefferquote, Seite „Käufer & Markt“, KI-Felder
const { chromium } = require('playwright');
let fehler = 0; const ok = (b, t) => { if(!b){ fehler++; console.log('FEHLER:', t); } else console.log('ok  ', t); };
(async () => {
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 1536, height: 1000 }, deviceScaleFactor: 1 });
  const fe = []; p.on('pageerror', e => { fe.push(e.message); console.log('SEITENFEHLER', e.message); });
  await p.addInitScript(() => {
    const ob = [
      { id:'auf1', createdAt:Date.now()-9e8, akqTitel:'Einfamilienhaus mit Garten', objektart:'EFH', adresse:'Lindenweg 5', ort:'14612 Falkensee', status:'auftrag', kaufpreis:459000, wohnflaeche:140, zimmer:'5', grundstueck:620, baujahr:'1998', verlauf:[] },
      { id:'lead1', createdAt:Date.now()-8e8, akqTitel:'Doppelhaushälfte mit Garten', objektart:'DHH', ort:'14624 Dallgow-Döberitz', status:'neu', quelle:'Kleinanzeigen', kaufpreis:429000, wohnflaeche:118, zimmer:'4', verlauf:[] },
      { id:'lead2', createdAt:Date.now()-7e8, akqTitel:'Helle 2-Zimmer-Wohnung', objektart:'Wohnung', ort:'Berlin-Lichterfelde', status:'neu', kaufpreis:279000, wohnflaeche:62, zimmer:'2', verlauf:[] },
      { id:'miet1', createdAt:Date.now()-6e8, akqTitel:'3-Zimmer-Wohnung zur Miete', objektart:'Wohnung', ort:'Falkensee', status:'auftrag', auftragsart:'vermietung', kaufpreis:1050, wohnflaeche:78, zimmer:'3', verlauf:[] }
    ];
    const alt = { objekte: ob, kontakte: [], termine: [], marktanalysen: [], aufgaben: [], notizen: [], mentorFragen: [], meta: { v9neustart: { quittiert: true } } };
    window.pc = { laden: () => JSON.parse(JSON.stringify(alt)), speichern: () => ({ ok:true }), ordner(){}, sicherungSchreiben: () => ({ ok:true }), sicherungLesen: () => null, zwischenablage: async () => '', abruf: async () => ({ ok:false }) };
    window.__geoeffnet = []; window.open = u => { window.__geoeffnet.push(u); };
    window.__kopiert = [];
    try{ Object.defineProperty(navigator, 'clipboard', { value:{ writeText: async t => { window.__kopiert.push(t); } }, configurable:true }); }catch(e){}
  });
  await p.goto('file:///tmp/pc/app/index.html'); await p.waitForTimeout(1500);
  const ev = (f, ...a) => p.evaluate(f, ...a);

  // ── Grundlagen ──
  ok(await ev(() => NAV.some(n => n.key === 'kaeufer') && /Käufer & Markt/.test(document.getElementById('nav').textContent || document.body.textContent)), 'Neuer Menüpunkt „Käufer & Markt“');
  ok(await ev(() => /vendor\/pdf\.worker\.min\.js$/.test(pdfjsLib.GlobalWorkerOptions.workerSrc) && typeof Tesseract !== 'undefined' && !document.querySelector('script[src*="cdnjs.cloudflare.com/ajax/libs/pdf.js"]')), 'pdf.js + Texterkennung lokal eingebunden (kein CDN)');
  const pr = await ev(() => ({ z: AKQ_PROMPTS.find(x => x.key === 'zeitung').prompt(akqDb().einst), k: AKQ_PROMPTS.find(x => x.key === 'kleinanzeigen').prompt(akqDb().einst) }));
  ok(/Kaufgesuche von Privatleuten/.test(pr.z) && /Anzeigentyp: Gesuch/.test(pr.z) && /Preis-Einschätzung:/.test(pr.z) && /Passende Käufer:/.test(pr.z), 'Zeitung-Prompt: Gesuche + Preis-Einschätzung + Passende Käufer');
  ok(/Preis-Einschätzung:/.test(pr.k) && /Passende Käufer:/.test(pr.k) && !/Anzeigentyp: Gesuch/.test(pr.k), 'Kleinanzeigen-Prompt: Preis-Einschätzung + Passende Käufer');

  // ── Zeitung als PDF einlesen ──
  await ev(() => { wechsleAnsicht('akquise'); zlDialog(); }); await p.waitForTimeout(150);
  ok(await ev(() => !!document.getElementById('zlDrop') && /Kaufgesuche/.test(document.getElementById('zlModal').textContent)), 'Dialog „Zeitung einlesen“');
  await p.setInputFiles('#zlDatei', '/tmp/v21test/zeitung_text.pdf');
  await p.waitForFunction(() => ZL.ergebnis && !ZL.laeuft, null, { timeout: 60000 });
  const zr = await ev(() => ({ a: ZL.ergebnis.angebote.length, g: ZL.ergebnis.gesuche.length, an: ZL.ergebnis.angebote.filter(x => x.an).length, quelle: ZL.quelle, datum: document.getElementById('zlDatum').value, zeilen: document.querySelectorAll('#zlErgebnis .zl-zeile').length, knopf: document.getElementById('zlUebernehmenKnopf').textContent, treffer: [...document.querySelectorAll('#zlErgebnis .zl-treffer')].map(x => x.textContent), status: document.getElementById('zlStatus').textContent }));
  ok(zr.a === 13 && zr.g === 7 && zr.zeilen === 20, `PDF gelesen: 13 Angebote, 7 Gesuche (${JSON.stringify(zr)})`);
  ok(zr.an === 11 && /11 Leads \+ 7 Suchkunden/.test(zr.knopf), 'Makler-Angebot (nur privat) und Vermietung vorab abgewählt');
  ok(zr.quelle === 'zeitung text' && zr.datum === '2026-11-04' && /Ausgabe vom 04\.11\.2026/.test(zr.status), 'Quelle aus Dateiname, Datum aus der Kopfzeile');
  ok(zr.treffer.length >= 2, 'Vorschau zeigt schon, zu wie vielen Objekten die Gesuche passen: ' + zr.treffer.join(' | '));
  await p.screenshot({ path: '/tmp/v21test/1_zeitung_vorschau.png' });
  await ev(() => { document.getElementById('zlQuelle').value = 'Havelland Kurier'; ZL.quelle = 'Havelland Kurier'; ZL.quelleAuto = false; zlUebernehmen(); }); await p.waitForTimeout(200);
  let st = await ev(() => ({ o: db.objekte.length, g: db.gesuche.length, k: db.kontakte.filter(k => k.kontaktart === 'kaeufer').length, txt: document.getElementById('zlErgebnis').textContent,
    fs: db.objekte.find(o => /Falkensee/.test(o.ort) && o.objektart === 'EFH' && o.id !== 'auf1'), sp: db.objekte.find(o => o.chiffre === 'ZA 4711'), ges: db.gesuche.find(g => g.name === 'Junge Familie') }));
  ok(st.o === 4 + 11 && st.g === 7 && st.k === 6, `Übernommen: 11 Leads, 7 Suchkunden, 6 Käufer-Kontakte (${st.o}/${st.g}/${st.k})`);
  ok(st.fs && st.fs.akqTitel === 'Einfamilienhaus, 5 Zi., 140 m²' && st.fs.kaufpreis === 489000 && st.fs.privat === 'ja' && st.fs.quelle === 'Zeitung' && /Havelland Kurier/.test(st.fs.quelleText) && st.fs.inseratDatum === '2026-11-04' && st.fs.wohnflaeche === 140 && st.fs.grundstueck === 620, 'Lead korrekt: Titel, Preis, privat, Quelle, Datum, Flächen');
  ok(st.sp && st.sp.kaufpreis === 349000 && !st.sp.verkaeuferTelefon, 'Chiffre-Anzeige ohne Telefon übernommen');
  ok(st.ges && st.ges.arten.join() === 'EFH,DHH' && st.ges.preisMax === 500000 && st.ges.zimmerMin === 4 && st.ges.quelleText === 'Havelland Kurier' && st.ges.datum === '2026-11-04', 'Suchkunde „Junge Familie“ mit Kriterien');
  ok(/passen zu \d+ Objekt/.test(st.txt), 'Ergebnis nennt passende Objekte: ' + st.txt.slice(0, 160));
  await p.screenshot({ path: '/tmp/v21test/2_zeitung_fertig.png' });
  // Rückgängig und nochmal
  await ev(() => zlRueckgaengig()); await p.waitForTimeout(100);
  st = await ev(() => ({ o: db.objekte.length, g: (db.gesuche || []).length, k: db.kontakte.length }));
  ok(st.o === 4 && st.g === 0 && st.k === 0, 'Rückgängig entfernt Leads, Suchkunden und Kontakte');
  await ev(() => zlDialog()); await p.setInputFiles('#zlDatei', '/tmp/v21test/zeitung_text.pdf');
  await p.waitForFunction(() => ZL.ergebnis && !ZL.laeuft, null, { timeout: 60000 });
  await ev(() => zlUebernehmen()); await ev(() => schliesseModal());
  // dieselbe Zeitung noch einmal → nichts doppelt
  await ev(() => zlDialog()); await p.setInputFiles('#zlDatei', '/tmp/v21test/zeitung_text.pdf');
  await p.waitForFunction(() => ZL.ergebnis && !ZL.laeuft, null, { timeout: 60000 });
  await ev(() => zlUebernehmen());
  st = await ev(() => ({ o: db.objekte.length, g: db.gesuche.length, txt: document.getElementById('zlErgebnis').textContent }));
  ok(st.o === 15 && st.g === 7 && /11 schon bekannt/.test(st.txt) && /7 schon bekannt/.test(st.txt), 'Zweites Einlesen derselben Seite: nichts doppelt (' + st.txt.slice(0, 120) + ')');
  await ev(() => schliesseModal());

  // ── Trefferquote ──
  const m = await ev(() => { const g = db.gesuche.find(x => x.name === 'Junge Familie'); return skObjekteFuer(g).map(x => [x.o.id === 'auf1' ? 'auf1' : x.o.akqTitel, x.m.score]); });
  ok(m.length >= 3 && m[0][1] === 100 && m.some(x => x[0] === 'auf1' && x[1] === 100) && m.some(x => /Doppelhaushälfte/.test(x[0])), 'Junge Familie passt zu Auftrag Falkensee (100 %) und DHH Dallgow: ' + JSON.stringify(m));
  const m2 = await ev(() => { const g = db.gesuche.find(x => x.chiffre === 'ZA 4812'); return skObjekteFuer(g).map(x => [x.o.akqTitel, x.m.score, x.m.gruende.map(r => r[1]).join('|')]); });
  ok(m2.some(x => x[0] === 'Helle 2-Zimmer-Wohnung' && /gleicher Bezirk/.test(x[2])) && m2.some(x => /2-Zimmer-Wohnung, 58 m²/.test(x[0])), 'ETW-Gesuch Steglitz/Potsdam: Lichterfelde (gleicher Bezirk) + Babelsberg: ' + JSON.stringify(m2));
  ok(await ev(() => { const g = db.gesuche.find(x => x.nutzung === 'miete'); const t = skObjekteFuer(g); return t.length === 1 && t[0].o.id === 'miet1'; }), 'Mietgesuch passt nur zur Mietwohnung');
  ok(await ev(() => { const g = db.gesuche.find(x => x.name === 'Rentnerpaar'); return !skObjekteFuer(g).some(x => x.o.id === 'auf1'); }), 'Rentnerpaar (bis 350.000 €) passt nicht zum Haus für 459.000 €');

  // ── Seite „Käufer & Markt“ ──
  await ev(() => { KM.filter = null; KM.tab = 'objekte'; wechsleAnsicht('kaeufer'); }); await p.waitForTimeout(200);
  ok(await ev(() => KM.filter === 'auftrag' && document.querySelectorAll('#kmListe .lc').length === 2), 'Startet mit den Aufträgen (2)');
  await ev(() => { KM.sel = 'auf1'; kmListe(); }); await p.waitForTimeout(80);
  const km = await ev(() => ({ filter: KM.filter, karten: document.querySelectorAll('#kmListe .lc').length, sel: KM.sel, det: document.getElementById('kmDetail').textContent, treffer: document.querySelectorAll('#kmDetail .sk-treffer').length, fin: [...document.querySelectorAll('#kmDetail .km-fin-zahlen b')].map(x => x.textContent) }));
  ok(km.sel === 'auf1', 'Haus Falkensee gewählt');
  ok(km.treffer >= 1 && /Junge Familie/.test(km.det) && /100/.test(km.det), 'Detail: passende Suchkunden mit Trefferquote');
  ok(km.fin.join('|') === '≈ 101.300 €|≈ 2.100 €|ab ≈ 5.900 €', 'Finanzierbarkeit (Brandenburg 6,5 % GrESt, 4 % Zins): ' + km.fin.join(' | '));
  ok(/Familien mit Kindern/.test(km.det) && /Berliner, die ins Grüne ziehen/.test(km.det), 'Käufergruppen: Familien + Berliner ins Grüne');
  ok(/Kleinanzeigen-Gesuche öffnen/.test(km.det) && /📊 Preis-Check/.test(km.det), 'Käufer finden + Preis-Check');
  await p.screenshot({ path: '/tmp/v21test/3_kaeufer_objekt.png' });
  await ev(() => [...document.querySelectorAll('#kmDetail button')].find(x => /Kleinanzeigen-Gesuche/.test(x.textContent)).click());
  ok(await ev(() => window.__geoeffnet.slice(-1)[0] === 'https://www.kleinanzeigen.de/s-haus-kaufen/anzeige:gesuche/falkensee/k0c208'), 'Kleinanzeigen-Gesuche: Häuser, Falkensee');
  // Suchkunden anschreiben → informiert
  await ev(() => { const g = db.gesuche.find(x => x.name === 'Rentnerpaar'); g.preisMax = 480000; kmDetail(); });
  await ev(() => [...document.querySelectorAll('#kmDetail .sk-treffer')].find(x => /Rentnerpaar/.test(x.textContent)).querySelector('button[title*="E-Mail"]').click()); await p.waitForTimeout(80);
  const mail = await ev(() => decodeURIComponent(window.__geoeffnet.slice(-1)[0]));
  ok(mail.startsWith('mailto:rentner.paar@gmx.de') && /subject=Passendes Angebot: Einfamilienhaus mit Garten in Falkensee/.test(mail) && /Exposé/.test(mail), 'Mail an Suchkunden mit passendem Angebot');
  ok(await ev(() => { const g = db.gesuche.find(x => x.name === 'Rentnerpaar'); return !!g.informiert.auf1 && /informiert am/.test(document.getElementById('kmDetail').textContent); }), 'Als informiert markiert');
  // KI fragen + Antwort übernehmen
  await ev(() => kmKiKopieren('auf1'));
  const kp = await ev(() => window.__kopiert.slice(-1)[0]);
  ok(/AUFGABE 1 – PREIS/.test(kp) && /AUFGABE 3 – GESUCHE/.test(kp) && /Anzeigentyp: Gesuch/.test(kp) && /Lindenweg 5, 14612 Falkensee/.test(kp), 'KI-Prompt: Preis, Käufer, Gesuche – mit Objektdaten');
  await ev(() => kmKiEinfuegen('auf1')); await p.waitForTimeout(60);
  await ev(() => { document.getElementById('kmKiText').value = `Preis-Einschätzung: eher hoch – ca. 3.280 €/m², vergleichbare Häuser in Falkensee liegen bei 3.000–3.200 €/m².
Passende Käufer: Familien mit 1–2 Kindern aus Spandau; Paare 40+, die mehr Platz wollen.
Ansprache: ImmoScout + Kleinanzeigen, Schulnähe betonen.

1.
Anzeigentyp: Gesuch
Name: Familie Schulz
Sucht: Einfamilienhaus
Lage: Falkensee, Brieselang
Budget: bis 480.000 €
Details: ab 4 Zimmer, Garten
Telefon: 0171 5556667
E-Mail: Nicht angegeben
Link: https://www.kleinanzeigen.de/s-anzeige/suche-haus-falkensee/999
Eingestellt am: 01.11.2026
Quelle: Kleinanzeigen`; kmKiUebernehmen('auf1'); }); await p.waitForTimeout(150);
  const ki = await ev(() => ({ o: findObjekt('auf1'), g: db.gesuche.find(x => x.name === 'Familie Schulz') }));
  ok(/^eher hoch/.test(ki.o.kiPreis) && /Familien mit 1–2 Kindern/.test(ki.o.kiKaeufer) && /Schulnähe/.test(ki.o.kiAnsprache), 'KI-Antwort: Preis, Käufer, Ansprache am Objekt');
  ok(ki.g && ki.g.orte.join() === 'Falkensee,Brieselang' && ki.g.preisMax === 480000 && ki.g.zimmerMin === 4 && ki.g.link.endsWith('/999') && ki.g.arten.includes('EFH'), 'Gesuch aus der KI-Antwort wird Suchkunde: ' + JSON.stringify(ki.g && { orte: ki.g.orte, max: ki.g.preisMax, zi: ki.g.zimmerMin, arten: ki.g.arten }));
  ok(await ev(() => /Familie Schulz/.test(document.getElementById('kmDetail').textContent) && !!document.querySelector('#kmDetail .ki-box')), 'Neuer Suchkunde + KI-Box im Detail');

  // ── Suchkunden-Tab ──
  await ev(() => { KM.tab = 'suchkunden'; renderMain(); }); await p.waitForTimeout(100);
  const sk = await ev(() => ({ n: document.querySelectorAll('.sk-zeile').length, passt: document.querySelectorAll('.sk-zeile .sk-obj').length, txt: document.getElementById('kmInhalt').textContent }));
  ok(sk.n === 8 && sk.passt >= 6 && /Chiffre ZA 4812/.test(sk.txt), `Suchkunden-Liste: 8 Karten, Objekt-Chips (${sk.n}/${sk.passt})`);
  await p.screenshot({ path: '/tmp/v21test/4_suchkunden.png' });
  await ev(() => skBearbeiten()); await p.waitForTimeout(60);
  await ev(() => { document.getElementById('skName').value = 'Herr Krüger'; document.getElementById('skTel').value = '0172 1010101'; document.querySelector('#skModal .sk-arten input[value="Wohnung"]').checked = true; document.getElementById('skOrte').value = 'Steglitz, Lichterfelde'; document.getElementById('skPreis').value = '300.000'; document.getElementById('skZi').value = '2'; skSpeichern(null); }); await p.waitForTimeout(80);
  const kr = await ev(() => { const g = db.gesuche.find(x => x.name === 'Herr Krüger'); const k = db.kontakte.find(x => x.id === g.kontaktId); return { g, k, t: skObjekteFuer(g).map(x => x.o.id) }; });
  ok(kr.g && kr.g.preisMax === 300000 && kr.k && kr.k.kontaktart === 'kaeufer' && kr.t.includes('lead2'), 'Suchkunde von Hand: Kontakt „Käufer“, passt zu Lichterfelde-Wohnung');
  await ev(() => skStatus(db.gesuche.find(x => x.name === 'Herr Krüger').id));
  ok(await ev(() => skTrefferFuer(findObjekt('lead2')).every(x => x.g.name !== 'Herr Krüger')), 'Erledigte Suchkunden zählen nicht mehr');

  // ── Akquise: Suchkunden + KI am Lead ──
  await ev(() => { AQ2.status = 'alle'; wechsleAnsicht('akquise'); aq2Waehlen('lead1'); }); await p.waitForTimeout(150);
  const aq = await ev(() => ({ box: (document.querySelector('.dp .sk-box') || {}).textContent || '', chip: (document.querySelector('#lc-lead1 .sk-chip') || {}).textContent || '' }));
  ok(/Suchkunde/.test(aq.box) && /vorgemerkte Käufer/.test(aq.box) && /👥/.test(aq.chip), 'Lead: Box „Suchkunden suchen so etwas“ + Argument, Karte mit 👥-Chip');
  await p.screenshot({ path: '/tmp/v21test/5_lead_suchkunden.png' });
  // KI-Import über die Akquise (Angebot mit Preis-Einschätzung + Gesuch)
  const ber = await ev(() => akqImportText(`1.
Name: Nicht angegeben
Objekt: Bungalow mit Garten
Lage: Brieselang
Preis: 365.000 €
Telefon: 0176 4040404
E-Mail: Nicht angegeben
Eingestellt am: 05.11.2026
Privat eindeutig: 🟢 Ja – „von privat“
Details: 3 Zimmer, 95 m² Wohnfläche, 700 m² Grundstück
Quelle: Kleinanzeigen
Link: https://www.kleinanzeigen.de/s-anzeige/bungalow/4711
Status: Privatangebot
Preis-Einschätzung: günstig – ca. 3.840 €/m², andere Bungalows in Brieselang ab 4.200 €/m²
Passende Käufer: Paare 55+ (ebenerdig), junge Paare als Starterhaus

2.
Anzeigentyp: Gesuch
Name: Frau Lehmann
Sucht: Bungalow oder Einfamilienhaus
Lage: Brieselang, Nauen
Budget: bis 400.000 €
Details: ebenerdig
Telefon: 0151 3030303
E-Mail: Nicht angegeben
Eingestellt am: 02.11.2026
Quelle: Märkische Allgemeine

Gesamt: 2 Anzeigen`));
  const bu = await ev(() => ({ o: db.objekte.find(o => o.akqTitel === 'Bungalow mit Garten'), g: db.gesuche.find(x => x.name === 'Frau Lehmann') }));
  ok(ber.neuObjekte === 1 && ber.suchkunden === 1 && ber.suchkundenTreffer >= 1, 'KI-Ergebnis: 1 Lead + 1 Suchkunde (passt): ' + JSON.stringify({ n: ber.neuObjekte, s: ber.suchkunden, t: ber.suchkundenTreffer }));
  ok(bu.o && /^günstig/.test(bu.o.kiPreis) && /Paare 55\+/.test(bu.o.kiKaeufer), 'Preis-Einschätzung + Passende Käufer am Lead gespeichert');
  ok(bu.g && bu.g.orte.join() === 'Brieselang,Nauen' && bu.g.preisMax === 400000 && bu.g.arten.includes('EFH'), 'Gesuch aus der KI: Orte, Budget, Art');
  await ev(() => aq2Waehlen(db.objekte.find(o => o.akqTitel === 'Bungalow mit Garten').id)); await p.waitForTimeout(80);
  ok(await ev(() => /günstig/.test((document.querySelector('.dp .ki-box') || {}).textContent || '') && /Frau Lehmann/.test((document.querySelector('.dp .sk-box') || {}).textContent || '')), 'Lead-Detail: KI-Box + passender Suchkunde');

  // ── Glocke ──
  ok(await ev(() => tbHinweise().some(h => h.k === 'suchkunden' && /passt zu deinen Aufträgen/.test(h.t))), 'Glocke: neue Suchkunden passen zu Aufträgen');
  ok(await ev(() => { tbErinnerungenEinstellen(); const t = document.getElementById('modalInner').textContent; schliesseModal(); return /Neue Suchkunden passen zu deinen Aufträgen/.test(t); }), 'Erinnerung abschaltbar');
  // Menü
  await ev(() => document.querySelector('[onclick*="tbMenue(event,\'nutzer\')"]').click()); await p.waitForTimeout(60);
  ok(await ev(() => /Zeitung einlesen/.test(document.getElementById('tbMenue').textContent) && /PC-Version v2[1-9]/.test(document.getElementById('tbMenue').textContent)), 'Zahnrad-Menü: Zeitung einlesen, Version');
  await ev(() => tbMenueZu());
  ok(fe.length === 0, 'Keine Seitenfehler');
  console.log('\nFEHLER', fehler); await b.close(); process.exit(fehler ? 1 : 0);
})();
