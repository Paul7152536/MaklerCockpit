const {chromium}=require('playwright');
(async()=>{ const b=await chromium.launch(); const p=await b.newPage({viewport:{width:1536,height:1024}}); const fe=[]; p.on('pageerror',e=>{fe.push(e.message);console.log('ERR',e.message)});
await p.addInitScript(()=>{
  const alt={objekte:[{id:"x1",createdAt:Date.now()-2*864e5,akqTitel:"Anwesen mit zwei großen Wohnungen",objektart:"EFH",ort:"Südlich von Berlin",kaufpreis:660000,status:"erstkontakt",statusAm:Date.now()-3600e3,emailAm:Date.now()-7200e3,quelle:"Zeitung",seite:"B 26",privat:"ja",verkaeuferEmail:"anwesen@mail.de",leadNotiz:"Wir telefonieren evtl morgen einmal",
    notizen:'<b>📥 Akquise · Zeitung</b> – Seite B 26 · eingestellt 07.11.2026 (Zeitungsdatum)<br>Objekt: Anwesen mit zwei großen Wohnungen<br>Lage: Südlich von Berlin<br>Preis: 660.000 €<br>Details: Ca. 360 m² Wohnfläche, 14 Zimmer<br>Privat: 🟢 Ja<br>Einschätzung: Eigentümerangebot<br>🔁 Erneut gefunden am 8.11.2026<br>9.11.2026 19:07 – Status: E-Mail geschrieben<br>9.11.2026 19:07 – Status: Kontakt aufgenommen'}],
    kontakte:[],marktanalysen:[],aufgaben:[],termine:[],notizen:[],mentorFragen:[],meta:{v9neustart:{quittiert:true}}};
  window.pc={laden:()=>JSON.parse(JSON.stringify(alt)),speichern:()=>({ok:true}),ordner(){},sicherungSchreiben:()=>({ok:true}),sicherungLesen:()=>null,zwischenablage:async()=>'',abruf:async()=>({ok:false})}; });
await p.goto('file:///tmp/pc/app/index.html'); await p.waitForTimeout(1200);
await p.evaluate(()=>{ if(aktuelleAnsicht!=='akquise') wechsleAnsicht('akquise'); }); await p.waitForTimeout(200);  // v24: Start auf „Heute“
console.log('MIGRIERT:', await p.evaluate(()=>JSON.stringify(findObjekt('x1').verlauf.map(v=>[new Date(v.ts).toLocaleString('de-DE'),v.typ,v.text]))), await p.evaluate(()=>JSON.stringify(findObjekt('x1').leadNotiz)));
// Notiz hinzufügen
await p.fill('#dpNotiz','Rückruf zugesagt, Unterlagen per Mail angefragt'); await p.keyboard.press('Control+Enter'); await p.waitForTimeout(200);
// Anruf und Rückruf
await p.evaluate(()=>{ aq2Anruf('nicht_erreicht'); aq2TerminFrage('nochmal_anrufen'); aq2TerminAnlegen(); });
console.log('VERLAUF-UI:', (await p.evaluate(()=>document.querySelector('.vl').innerText)).replace(/\n/g,' | '));
console.log('NOTIZEN-HTML Ende:', await p.evaluate(()=>findObjekt('x1').notizen.split('<br>').slice(-3).join(' || ')));
await p.evaluate(()=>{ document.getElementById('dpNotiz').scrollIntoView({block:'start'}); });
const box=await p.evaluate(()=>{ const r=document.querySelector('#aqDetail .dp').getBoundingClientRect(); return {x:r.x,y:r.y,width:r.width,height:r.height}; });
await p.screenshot({path:'/tmp/v9test/13_verlauf.png', clip:box});
// Suche findet Notiz
await p.evaluate(()=>{ AQ2.status='alle'; AQ2.q='unterlagen'; renderAkquise(document.getElementById('main')); }); console.log('SUCHE NOTIZ:', await p.evaluate(()=>document.querySelectorAll('.lc').length));
// Neuer Import hat Verlauf
await p.evaluate(()=>{ AQ2.q=''; aq2ImportUndZeigen('1.\nName: Herr Test\nObjekt: Reihenhaus\nLage: Teltow\nPreis: 389.000 €\nTelefon: 03328 1\nSeite: A 4\nQuelle: MAZ'); });
console.log('NEU-VERLAUF:', await p.evaluate(()=>JSON.stringify(findObjekt(AQ2.sel).verlauf.map(v=>v.typ+': '+v.text))));
console.log('FEHLER', fe.length); await b.close(); })();
