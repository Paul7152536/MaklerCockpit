// v22: „keine Makler“ raus, Suchkunden-Tabelle, Suchkunden an jedem Objekt, Suchkunden finden (Kleinanzeigen, KI)
const { chromium } = require('playwright');
let fehler = 0; const ok = (b, t) => { if(!b){ fehler++; console.log('FEHLER:', t); } else console.log('ok  ', t); };
(async () => {
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 1536, height: 1000 }, deviceScaleFactor: 1 });
  const fe = []; p.on('pageerror', e => { fe.push(e.message); console.log('SEITENFEHLER', e.message); });
  await p.addInitScript(() => {
    const ob = [
      { id:'auf1', createdAt:Date.now()-9e8, akqTitel:'Einfamilienhaus mit Garten', objektart:'EFH', adresse:'Lindenweg 5', ort:'14612 Falkensee', status:'auftrag', kaufpreis:459000, wohnflaeche:140, zimmer:'5', grundstueck:620, verlauf:[] },
      { id:'lead1', createdAt:Date.now()-8e8, akqTitel:'Doppelhaushälfte mit Garten', objektart:'DHH', ort:'14624 Dallgow-Döberitz', status:'neu', quelle:'Kleinanzeigen', kaufpreis:529000, wohnflaeche:118, zimmer:'4', verlauf:[] },
      { id:'lead2', createdAt:Date.now()-7e8, akqTitel:'Helle 3-Zimmer-Wohnung', objektart:'Wohnung', ort:'Berlin-Lichterfelde', status:'neu', kaufpreis:329000, wohnflaeche:78, zimmer:'3', verlauf:[] }
    ];
    const ges = [
      { id:'g1', createdAt:Date.now()-5e8, status:'aktiv', name:'Familie Brandt', telefon:'0176 1112223', email:'', arten:['EFH','DHH'], orte:['Falkensee','Dallgow'], preisMax:500000, zimmerMin:4, flaecheMin:0, grundstueckMin:0, nutzung:'kauf', text:'Familie sucht EFH oder DHH in Falkensee oder Dallgow, ab 4 Zi., bis 500.000 €', quelle:'Zeitung', quelleText:'Havelland Kurier', datum:'2026-11-04', wuensche:['garten'] },
      { id:'g2', createdAt:Date.now()-4e8, status:'aktiv', name:'Herr Privat', telefon:'0170 9998887', arten:['EFH'], orte:['Falkensee'], preisMax:600000, nutzung:'kauf', text:'Suche Haus in Falkensee von privat, bitte keine Makler', quelle:'Zeitung' }
    ];
    const alt = { objekte: ob, gesuche: ges, kontakte: [], termine: [], marktanalysen: [], aufgaben: [], notizen: [], mentorFragen: [], meta: { v9neustart: { quittiert: true } } };
    window.pc = { laden: () => JSON.parse(JSON.stringify(alt)), speichern: () => ({ ok:true }), ordner(){}, sicherungSchreiben: () => ({ ok:true }), sicherungLesen: () => null, zwischenablage: async () => '', abruf: async () => ({ ok:false }) };
    window.__geoeffnet = []; window.open = u => { window.__geoeffnet.push(u); };
    window.__kopiert = [];
    try{ Object.defineProperty(navigator, 'clipboard', { value:{ writeText: async t => { window.__kopiert.push(t); } }, configurable:true }); }catch(e){}
  });
  await p.goto('file:///tmp/pc/app/index.html'); await p.waitForTimeout(1500);
  const ev = (f, ...a) => p.evaluate(f, ...a);

  // ── „keine Makler“ raus ──
  ok(await ev(() => db.gesuche.find(g => g.id === 'g2').status === 'keinMakler' && db.gesuche.find(g => g.id === 'g1').status === 'aktiv'), 'Vorhandener Suchkunde mit „keine Makler“ wird aussortiert');
  ok(await ev(() => skTrefferFuer(findObjekt('auf1')).every(x => x.g.id !== 'g2')), 'Aussortierte zählen nicht als Treffer');
  const zr = await ev(() => { const z = (t, y) => ({ x0:0, x1:220, y, yb:y + 9, h:9, text:t, fett:false });
    return zlAnalysieren([{ nr:1, zeilen:[z('Immobilien-Gesuche', 0), z('Suche Haus in Spandau von privat,', 30), z('bis 450.000 €, Tel. 0171 2223334', 40), z('Familie sucht DHH in Spandau, bis', 70), z('480.000 €, Tel. 0172 3334445', 80), z('Suche ETW, provisionsfrei, bis', 110), z('300.000 €, Tel. 0151 4445556', 120)] }], { quelle:'Test' }); });
  ok(zr.gesuche.length === 1 && zr.weg.filter(w => /Keine Makler/.test(w.grund)).length === 2, 'Zeitung: „von privat“ und „provisionsfrei“ werden nicht übernommen');
  const ber = await ev(() => akqImportText(`1.
Anzeigentyp: Gesuch
Name: Frau Möller
Sucht: Einfamilienhaus
Lage: Falkensee
Budget: bis 550.000 €
Details: Garten, bitte keine Makleranfragen
Telefon: 0171 5550001

2.
Anzeigentyp: Gesuch
Name: Herr Yilmaz
Sucht: Doppelhaushälfte
Lage: Dallgow, Falkensee
Budget: bis 560.000 €
Details: ab 4 Zimmer
Telefon: 0171 5550002`));
  ok(ber.suchkunden === 1 && ber.suchkundenKeinMakler === 1 && await ev(() => !db.gesuche.some(g => g.name === 'Frau Möller')), 'KI-Ergebnis: Gesuch mit „keine Makleranfragen“ aussortiert, das andere übernommen');
  ok(await ev(() => skUebernehmen([{ text:'Suche Wohnung, ohne Provision', arten:['Wohnung'], orte:['Spandau'] }]).keinMakler === 1), '„ohne Provision“ wird aussortiert');

  // ── Suchkunden-Tabelle ──
  await ev(() => { KM.tab = 'suchkunden'; wechsleAnsicht('kaeufer'); }); await p.waitForTimeout(150);
  const tab = await ev(() => ({ kopf: [...document.querySelectorAll('.sk-tab th')].map(x => x.textContent).join('|'), zeilen: document.querySelectorAll('.sk-zeile').length, z1: (document.querySelector('.sk-zeile') || {}).textContent || '', sum: document.querySelector('.sk-sum').textContent }));
  ok(tab.kopf === 'Wer|Sucht|Wo|Budget|Größe|Kontakt|Passt zu|' && tab.zeilen === 2, 'Tabelle: Wer · Sucht · Wo · Budget · Größe · Kontakt · Passt zu (2 aktive)');
  ok(/Herr Yilmaz/.test(tab.z1) && /Doppelhaushälfte/.test(tab.z1) && /Dallgow, Falkensee/.test(tab.z1) && /560\.000 €/.test(tab.z1) && /ab 4 Zi\./.test(tab.z1) && /0171 5550002/.test(tab.z1), 'Zeile zeigt auf einen Blick, was gesucht wird: ' + tab.z1.replace(/\s+/g, ' ').slice(0, 160));
  ok(/2 aktive Suchkunden/.test(tab.sum) && /1 aussortiert \(wollen keinen Makler\)/.test(tab.sum), 'Zusammenfassung mit Hinweis auf Aussortierte: ' + tab.sum);
  await ev(() => document.querySelectorAll('.sk-zeile')[1].click()); await p.waitForTimeout(80);
  const det = await ev(() => ({ t: (document.querySelector('.sk-detail') || {}).textContent || '', ok: document.querySelectorAll('.sk-detail .skc.ok').length, warn: document.querySelectorAll('.sk-detail .skc.warn').length }));
  ok(/Passt zu 2 Objekten/.test(det.t) && /Einfamilienhaus mit Garten/.test(det.t) && det.ok >= 6 && det.warn === 1, 'Zeile aufgeklappt: Anzeige, passendes Objekt mit grünen Kriterien (' + det.ok + ' grün, ' + det.warn + ' gelb)');
  await p.screenshot({ path: '/tmp/v22test/1_suchkunden_tabelle.png' });
  await ev(() => { KM.skFilter = 'keinMakler'; kmSuchkunden(); });
  ok(await ev(() => document.querySelectorAll('.sk-zeile').length === 1 && /will keinen Makler/.test(document.querySelector('.sk-zeile').textContent)), 'Filter „Aussortiert: keine Makler“');
  await ev(() => { KM.skFilter = 'aktiv'; KM.skArt = 'Wohnung'; kmSuchkunden(); });
  ok(await ev(() => document.querySelectorAll('.sk-zeile').length === 0), 'Filter nach Objektart');
  await ev(() => { KM.skArt = ''; kmSuchkunden(); });

  // ── An den Objekten gut sichtbar ──
  await ev(() => wechsleAnsicht('objekte')); await p.waitForTimeout(150);
  const objBadge = await ev(() => [...document.querySelectorAll('#objTabelle .obj-sk')].map(x => x.textContent.trim()));
  ok(objBadge.length === 1 && objBadge[0] === '👥 1 Suchkunde', 'Objekte-Liste: „👥 1 Suchkunde“ am Auftrag: ' + JSON.stringify(objBadge));
  await p.screenshot({ path: '/tmp/v22test/2_objekte_badge.png' });
  await ev(() => document.querySelector('#objTabelle .obj-sk').click()); await p.waitForTimeout(150);
  ok(await ev(() => aktuelleAnsicht === 'kaeufer' && KM.sel === 'auf1' && document.querySelectorAll('#kmDetail .sk-treffer').length === 1), 'Klick darauf → Käufer & Markt mit dem Objekt');
  ok(await ev(() => document.querySelectorAll('#kmDetail .sk-treffer .skc.ok').length >= 4), 'Im Detail: Kriterien als grüne Chips');
  await ev(() => { schliesseModal(); oeffneObjektModal('auf1'); }); await p.waitForTimeout(100);
  const md = await ev(() => ({ box: (document.querySelector('#modalInner .sk-im-modal') || {}).textContent || '', pos: (() => { const h = document.querySelector('#modalInner h3'); return h && h.nextElementSibling && h.nextElementSibling.classList.contains('sk-im-modal'); })() }));
  ok(md.pos && /1 Suchkunde sucht so ein Objekt/.test(md.box) && /Familie Brandt/.test(md.box) && /0176 1112223/.test(md.box), 'Objekt-Fenster: Kasten oben mit Suchkunden, was sie suchen + Telefon');
  await p.screenshot({ path: '/tmp/v22test/3_objekt_fenster.png' });
  await ev(() => schliesseModal());
  await ev(() => { AQ2.status = 'alle'; wechsleAnsicht('akquise'); aq2Waehlen('auf1'); }); await p.waitForTimeout(120);
  ok(await ev(() => { const b = document.querySelector('.dp .sk-box'); return !!b && b.querySelectorAll('.sk-r').length === 1 && b.querySelectorAll('.skc.ok').length >= 4 && /📞/.test(b.textContent); }), 'Akquise-Detail: Suchkunden mit Kriterien-Chips und Telefon');
  // Preis knapp über Budget → gelb
  await ev(() => { aq2Waehlen('lead1'); }); await p.waitForTimeout(80);
  ok(await ev(() => { const b = document.querySelector('.dp .sk-box'); return !!b && !!b.querySelector('.skc.warn'); }), 'Preis leicht über Budget wird gelb markiert');

  // ── Suchkunden finden ──
  await ev(() => { wechsleAnsicht('kaeufer'); kgFinden(); }); await p.waitForTimeout(80);
  ok(await ev(() => document.querySelectorAll('#kgModal .sf-karte').length === 3 && /Kleinanzeigen/.test(document.getElementById('kgModal').textContent) && /KI-Websuche/.test(document.getElementById('kgModal').textContent)), 'Dialog „Suchkunden finden“: Kleinanzeigen, KI-Websuche, Zeitung');
  await ev(() => [...document.querySelectorAll('#kgModal .sf-knoepfe button')].find(x => /Häuser/.test(x.textContent)).click());
  ok(await ev(() => window.__geoeffnet.slice(-1)[0] === 'https://www.kleinanzeigen.de/s-haus-kaufen/berlin/anzeige:gesuche/c208l3331r30'), 'Kleinanzeigen-Gesuche Häuser Berlin + 30 km');
  await ev(() => { document.getElementById('kgOrt').value = 'Falkensee'; document.getElementById('kgArt').value = 'wohnung'; [...document.querySelectorAll('#kgModal .sf-ort button')][0].click(); });
  ok(await ev(() => window.__geoeffnet.slice(-1)[0] === 'https://www.kleinanzeigen.de/s-wohnung-kaufen/anzeige:gesuche/falkensee/k0c196'), 'Mit Ort: Wohnungen in Falkensee');
  await ev(() => akqPromptKopieren('gesuche'));
  const pr = await ev(() => window.__kopiert.slice(-1)[0]);
  ok(/KAUFGESUCHE von Privatleuten/.test(pr) && /„keine Makler“, „von privat“, „provisionsfrei“/.test(pr) && /Anzeigentyp: Gesuch/.test(pr), 'KI-Prompt für die ganze Region (ohne „keine Makler“)');
  ok(await ev(() => AKQ_PROMPTS.some(p => p.key === 'gesuche') && /Kaufgesuchen/.test(document.body.textContent + AKQ_PROMPTS.find(p => p.key === 'gesuche').text)), 'Auch unter Akquise → Suchen lassen');
  await ev(() => schliesseModal());
  // Gesuche aus dem Kleinanzeigen-Fenster (Daten wie vom Fenster geliefert)
  const kg = await ev(() => kgDaten({ url:'https://www.kleinanzeigen.de/s-haus-kaufen/berlin/anzeige:gesuche/c208l3331r30', gesuchSeite:true, eintraege:[
    { titel:'Suche Einfamilienhaus in Falkensee', text:'Wir suchen ein EFH mit Garten, ab 4 Zimmer, bis 520.000 €', ort:'14612 Falkensee', datum:'Heute, 10:12', preis:'520.000 €', link:'https://www.kleinanzeigen.de/s-anzeige/suche-efh/111' },
    { titel:'Suche Haus von privat', text:'Bitte keine Makler!', ort:'13585 Spandau', datum:'Gestern, 18:00', link:'https://www.kleinanzeigen.de/s-anzeige/suche-haus/222' },
    { titel:'Wir suchen für vorgemerkte Kunden', text:'Häuser aller Art, Muster Immobilien GmbH', ort:'10115 Berlin', link:'https://www.kleinanzeigen.de/s-anzeige/makler/333' },
    { titel:'Suche Haus in München', text:'bis 900.000 €', ort:'80331 München', link:'https://www.kleinanzeigen.de/s-anzeige/muenchen/444' },
    { titel:'Doppelhaushälfte gesucht', text:'Junge Familie, Dallgow oder Falkensee', ort:'14624 Dallgow-Döberitz', preis:'480.000 € VB', datum:'03.11.2026', link:'https://www.kleinanzeigen.de/s-anzeige/dhh/555' }
  ] }));
  ok(kg.r.neu === 2 && kg.keinMakler === 1 && kg.makler === 1 && kg.aussen === 1, 'Kleinanzeigen-Seite: 2 übernommen, „keine Makler“, Makler und München aussortiert: ' + JSON.stringify({ neu:kg.r.neu, km:kg.keinMakler, m:kg.makler, a:kg.aussen }));
  const kg1 = await ev(() => db.gesuche.find(g => g.link === 'https://www.kleinanzeigen.de/s-anzeige/suche-efh/111'));
  ok(kg1 && kg1.arten.includes('EFH') && kg1.orte.join() === 'Falkensee' && kg1.preisMax === 520000 && kg1.zimmerMin === 4 && kg1.quelle === 'Kleinanzeigen' && kg1.datum === new Date().toISOString().slice(0, 10), 'Gesuch korrekt gelesen (Art, Ort, Budget, Zimmer, Datum „Heute“)');
  const kg2 = await ev(() => db.gesuche.find(g => g.link === 'https://www.kleinanzeigen.de/s-anzeige/dhh/555'));
  ok(kg2 && kg2.arten.join() === 'DHH' && kg2.preisMax === 480000 && kg2.orte.includes('Dallgow'), 'Budget aus dem Preisfeld, Orte aus dem Text');
  ok(await ev(() => kgDaten({ url:'https://www.kleinanzeigen.de/s-haus-kaufen/berlin/anzeige:gesuche/c208l3331r30', gesuchSeite:true, eintraege:[{ titel:'Suche Einfamilienhaus in Falkensee', text:'Wir suchen ein EFH mit Garten, ab 4 Zimmer, bis 520.000 €', ort:'14612 Falkensee', link:'https://www.kleinanzeigen.de/s-anzeige/suche-efh/111' }] }).r.doppelt === 1), 'Zweimal übernehmen → nichts doppelt');
  ok(await ev(() => kgDaten({ url:'https://www.kleinanzeigen.de/s-haus-kaufen/berlin/c208l3331', gesuchSeite:false, eintraege:[{ titel:'Schönes EFH in Falkensee', text:'Verkaufe EFH, 489.000 € VB', ort:'14612 Falkensee', link:'https://www.kleinanzeigen.de/s-anzeige/efh/777' }] }).keinGesuch === 1), 'Auf einer Angebots-Seite werden Angebote nicht als Suchkunden genommen');
  ok(await ev(() => /Kleinanzeigen/.test(document.body.textContent)), 'Hinweis/Meldung erschienen');
  // Lead-Seite: neuer Suchkunde passt
  ok(await ev(() => skTrefferFuer(findObjekt('auf1')).length === 2 && skTrefferFuer(findObjekt('lead1')).length === 3), 'Neue Suchkunden passen: Auftrag Falkensee jetzt 2, DHH Dallgow 3');
  ok(fe.length === 0, 'Keine Seitenfehler');
  console.log('\nFEHLER', fehler); await b.close(); process.exit(fehler ? 1 : 0);
})();
