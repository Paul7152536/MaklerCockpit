// v22 Smoke: Kleinanzeigen-Fenster mit lokaler Testseite (MC_WEB_TEST=1)
const { app, BrowserWindow } = require('electron'); const http = require('http'); const fs = require('fs');
const HOME = '/tmp/claude-0/-home-claude/fcfe88c9-293d-574d-8cfa-b1821c923895/scratchpad/etest/home22';
fs.rmSync(HOME, { recursive: true, force: true });
app.setPath('documents', HOME + '/Dokumente');
process.env.MC_WEB_TEST = '1';

const ad = (id, titel, text, ort, preis, datum) => `<li class="ad-listitem" data-adid="${id}"><article class="aditem" data-adid="${id}" data-href="/s-anzeige/${id}">
  <div class="aditem-main"><div class="aditem-main--top"><div class="aditem-main--top--left">${ort}</div><div class="aditem-main--top--right">${datum}</div></div>
  <div class="aditem-main--middle"><h2 class="text-module-begin"><a class="ellipsis" href="/s-anzeige/${id}">${titel}</a></h2>
  <p class="aditem-main--middle--description">${text}</p><div class="aditem-main--middle--price-shipping"><p class="aditem-main--middle--price-shipping--price">${preis}</p></div></div></div></article></li>`;
const LISTE = `<!doctype html><html><head><meta charset="utf-8"><title>Gesuche</title></head><body><h1>Häuser zum Kauf – Gesuche</h1><ul id="srchrslt-adtable">
${ad('3001', 'Familie sucht Haus in Falkensee', 'Wir suchen ein Einfamilienhaus oder DHH mit Garten in Falkensee, ab 4 Zimmer. Gerne von privat, aber Makler okay.', '14612 Falkensee', '480.000 € VB', 'Heute, 09:12')}
${ad('3002', 'Suche Haus in Pankow – keine Makler!', 'Junges Paar sucht Reihenhaus in Pankow bis 550.000 €. Bitte keine Makler.', '13187 Berlin - Pankow', '550.000 €', 'Gestern, 18:40')}
${ad('3003', 'Suchen Grundstück für Einfamilienhaus', 'Suchen Baugrundstück ab 600 m² in Schönefeld oder Königs Wusterhausen.', '12529 Schönefeld', '250.000 €', '08.11.2026')}
${ad('3004', 'Kaufe alle Immobilien – Immobilienbüro Muster', 'Wir suchen für vorgemerkte Kunden Häuser aller Art. Immobilienbüro Muster GmbH.', '10115 Berlin - Mitte', '', '07.11.2026')}
${ad('3005', 'Suche Haus am See', 'Suche Ferienhaus in München.', '80331 München', '900.000 €', '06.11.2026')}
</ul></body></html>`;

const srv = http.createServer((req, res) => { res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' }); res.end(LISTE); });
srv.listen(0, '127.0.0.1');
require(process.env.MC_MAIN || '/tmp/pc/app/main.js');

const warte = ms => new Promise(r => setTimeout(r, ms));
app.whenReady().then(() => setTimeout(async () => {
  let fehler = 0; const ok = (b, t) => { console.log((b ? 'ok   ' : 'FEHL ') + t); if(!b) fehler++; };
  try{
    const w = BrowserWindow.getAllWindows()[0];
    const port = srv.address().port;
    const url = `http://127.0.0.1:${port}/s-haus-kaufen/berlin/anzeige:gesuche/c208l3331r30`;
    ok(await w.webContents.executeJavaScript(`kgVerfuegbar()`), 'window.pc.webfenster vorhanden');
    const fremd = await w.webContents.executeJavaScript(`window.pc.webfenster('oeffnen', { url: 'https://example.com/' })`);
    ok(fremd && fremd.ok === false, 'Fremde Seite wird abgelehnt: ' + JSON.stringify(fremd));
    await w.webContents.executeJavaScript(`kgOeffnen(${JSON.stringify(url)})`);
    await warte(1500);
    const alle = BrowserWindow.getAllWindows();
    const kw = alle.find(x => x !== w);
    ok(!!kw, 'Kleinanzeigen-Fenster offen (' + alle.length + ' Fenster)');
    const ua = kw.webContents.getUserAgent();
    ok(!/Electron|MaklerCockpit/i.test(ua), 'User-Agent ohne Electron/MaklerCockpit');
    const knopf = await kw.webContents.executeJavaScript(`document.getElementById('__mcNehmen') && document.getElementById('__mcNehmen').textContent`);
    ok(/Gesuche dieser Seite übernehmen \(5\)/.test(knopf || ''), 'Leiste unten mit Zähler: ' + knopf);
    const pcWeg = await kw.webContents.executeJavaScript(`typeof window.pc === 'undefined' && typeof require === 'undefined'`);
    ok(pcWeg, 'Fremde Seite hat keinen Zugriff aufs Programm');
    const vorher = await w.webContents.executeJavaScript(`skListe().length`);
    await w.webContents.executeJavaScript(`window.pc.webfenster('nehmen')`);
    await warte(1500);
    const erg = JSON.parse(await w.webContents.executeJavaScript(`JSON.stringify(skListe().map(g => ({ n: g.name, q: g.quelle, arten: g.arten, orte: g.orte, max: g.preisMax, st: g.status, link: g.link, d: g.datum })))`));
    console.log('GESUCHE', JSON.stringify(erg));
    ok(erg.length - vorher === 2, 'Genau 2 Gesuche übernommen (Falkensee + Schönefeld): ' + (erg.length - vorher));
    ok(erg.some(g => (g.orte || []).join(' ').includes('Falkensee') && g.max === 480000), 'Falkensee mit Budget 480.000 €');
    ok(erg.some(g => (g.arten || []).includes('Grundstück')), 'Grundstücks-Gesuch erkannt');
    ok(!erg.some(g => /Pankow/.test((g.orte || []).join(' '))), '„keine Makler“ (Pankow) nicht übernommen');
    ok(erg.every(g => /\/s-anzeige\/300\d/.test(g.link || '')), 'Links zur Anzeige gespeichert');
    const info = await kw.webContents.executeJavaScript(`document.getElementById('__mcInfo').textContent`);
    console.log('LEISTE', info);
    ok(/2 neu übernommen/.test(info) && /keinen Makler/.test(info) && /Makler-Gesuche ignoriert/.test(info) && /außerhalb/.test(info), 'Rückmeldung in der Leiste');
    // zweites Mal: nichts doppelt
    await w.webContents.executeJavaScript(`window.pc.webfenster('nehmen')`);
    await warte(1200);
    const n2 = await w.webContents.executeJavaScript(`skListe().length`);
    ok(n2 === erg.length, 'Zweites Übernehmen legt nichts doppelt an');
    const info2 = await kw.webContents.executeJavaScript(`document.getElementById('__mcInfo').textContent`);
    console.log('LEISTE2', info2);
    // gespeichert?
    await warte(1500);
    const datei = HOME + '/Dokumente/MaklerCockpit/daten.json';
    const gespeichert = fs.existsSync(datei) ? (JSON.parse(fs.readFileSync(datei, 'utf8')).gesuche || []).length : -1;
    ok(gespeichert === erg.length, 'In daten.json gespeichert: ' + gespeichert);
    await w.webContents.executeJavaScript(`window.pc.webfenster('schliessen')`);
    await warte(500);
    ok(BrowserWindow.getAllWindows().length === 1, 'Fenster schließt');
  }catch(e){ console.log('FEHLER', e && e.stack || e); fehler++; }
  console.log('FEHLER', fehler);
  app.exit(0);
}, 3000));
