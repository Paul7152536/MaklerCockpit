// v45: Objektakte – Inserat-Link / „Aus Zeitung“ im Kopf und bei der Herkunft, eigene Notizen im Verlauf farbig
const { chromium } = require('playwright');
let f = 0; const ok = (b, t) => { console.log((b ? 'ok   ' : 'FEHL ') + t); if(!b) f++; };
const T = Date.parse('2026-11-17T10:00:00');
const D = JSON.stringify({ objekte: [
  { id: 'a1', akqTitel: 'Privatverkauf: Haus mit Garten & Kamin in Berlin-Falkenberg', objektart: 'EFH', ort: '13057 Berlin-Falkenberg', status: 'erstkontakt', quelle: 'Kleinanzeigen', link: 'https://www.kleinanzeigen.de/s-anzeige/haus/123', wohnflaeche: 109, kaufpreis: 524999, createdAt: T - 864e5 * 7,
    verlauf: [{ ts: T - 864e5 * 7, typ: 'import', text: 'Aus Kleinanzeigen übernommen' }, { ts: T - 864e5 * 3, typ: 'notiz', text: 'Eigentümerin wirkt motiviert, will bis Frühjahr verkaufen' }, { ts: T - 864e5 * 2, typ: 'notiz', text: '💶 Preis-Analyse vorbereitet (PA-1)' }, { ts: T - 864e5, typ: 'anruf', text: 'Angerufen – erreicht' }, { ts: T - 36e5, typ: 'gespraech', text: 'Gespräch: Termin vereinbart – Garten sehr gepflegt' }] },
  { id: 'z1', akqTitel: 'EFH aus der Morgenpost', objektart: 'EFH', ort: '12459 Berlin', status: 'neu', quelle: 'Berliner Morgenpost', wohnflaeche: 120, verlauf: [] },
  { id: 'j1', akqTitel: 'Böser Link', objektart: 'EFH', status: 'neu', link: 'javascript:alert(1)', verlauf: [] }],
  kontakte: [], termine: [], aufgaben: [], notizen: [], meta: { v9neustart: { quittiert: true } } });
(async () => {
  const b = await chromium.launch();
  for(const [g, w, h] of [['pc', 1440, 900], ['handy', 412, 915]]){
    const p = await b.newPage({ viewport: { width: w, height: h }, isMobile: g === 'handy' });
    p.fe = []; p.on('pageerror', e => p.fe.push(e.message));
    await p.addInitScript(d => { window.pc = { geraet: 'pc', laden: () => JSON.parse(d), speichern: () => ({ ok: true }), ordner(){}, sicherungSchreiben: () => ({ ok: true }), sicherungLesen: () => null, gekoppelt: () => true, google: async () => ({ ok: false }) }; window.open = (u) => { window.__offen = u; return null; }; }, D);
    await p.goto('file:///tmp/pc/app/index.html'); await p.waitForTimeout(2200);
    await p.evaluate(() => { try{ schliesseModal(); }catch(e){} });
    const akte = id => p.evaluate(id => { MC24.akteId = id; wechsleAnsicht('akte'); }, id).then(() => p.waitForTimeout(400));
    await akte('a1');
    const k = await p.evaluate(() => ({ sub: document.querySelector('.aq-kopf .sub').innerText, chip: !!document.querySelector('.aq-kopf .ak45-inserat'), quelle: [...document.querySelectorAll('.mc24-akte td.mc24-muted a')].map(a => a.textContent) }));
    ok(k.chip && /Inserat öffnen/.test(k.sub) && /kleinanzeigen\.de/.test(k.sub), g + ': Kopf zeigt „🔗 Inserat öffnen kleinanzeigen.de“ (' + k.sub.replace(/\n/g, ' ') + ')');
    await p.click('.aq-kopf .ak45-inserat');
    ok(await p.evaluate(() => window.__offen) === 'https://www.kleinanzeigen.de/s-anzeige/haus/123', g + ': Klick öffnet das Inserat');
    ok(k.quelle.length >= 1 && k.quelle.every(t => t === 'aus dem Inserat ↗'), g + ': Herkunft in Kerndaten „aus dem Inserat ↗“ verlinkt (' + k.quelle.length + ')');
    const v = await p.evaluate(() => [...document.querySelectorAll('.ak45-v')].map(x => ({ eigen: x.classList.contains('eigen'), t: x.querySelector('.ak45-text').innerText, z: x.querySelector('.ak45-zeit').innerText })));
    ok(v.length === 5 && v[0].eigen && /gesprächsnotiz/i.test(v[0].t) && v.find(x => /motiviert/.test(x.t)).eigen && !v.find(x => /Preis-Analyse/.test(x.t)).eigen && !v.find(x => /Angerufen/.test(x.t)).eigen && !v.find(x => /übernommen/.test(x.t)).eigen, g + ': Verlauf: eigene Notiz + Gesprächsnotiz markiert, automatische Einträge neutral');
    ok(/17\.11\.26/.test(v[0].z) && /\d\d:\d\d/.test(v[0].z), g + ': Verlauf mit Datum und Uhrzeit (' + v[0].z.replace(/\n/g, ' ') + ')');
    const farbe = await p.evaluate(() => getComputedStyle(document.querySelector('.ak45-v.eigen')).borderLeftColor);
    ok(/255, 138, 61/.test(farbe), g + ': eigene Einträge orange markiert (' + farbe + ')');
    await p.fill('#ak45Notiz', 'Rückruf Donnerstag, Unterlagen anfordern'); await p.click('.ak45-neu button'); await p.waitForTimeout(400);
    const n = await p.evaluate(() => { const o = findObjekt('a1'), x = o.verlauf[o.verlauf.length - 1]; return { x, oben: document.querySelector('.ak45-v').classList.contains('eigen') && /Rückruf Donnerstag/.test(document.querySelector('.ak45-v').innerText) }; });
    ok(n.x.eigen === true && n.x.typ === 'notiz' && n.oben, g + ': Notiz direkt in der Akte geschrieben → oben, markiert');
    await akte('z1');
    const z = await p.evaluate(() => ({ sub: document.querySelector('.aq-kopf .sub').innerText, link: !!document.querySelector('.aq-kopf .ak45-inserat'), q: [...document.querySelectorAll('.mc24-akte td.mc24-muted')].map(t => t.innerText).join(' | ') }));
    ok(!z.link && /📰 Aus Zeitung \(Berliner Morgenpost\)/.test(z.sub), g + ': ohne Link: „📰 Aus Zeitung (Berliner Morgenpost)“');
    ok(/aus der Zeitung/.test(z.q) && !/aus den Objektdaten/.test(z.q), g + ': Herkunft in Kerndaten „aus der Zeitung“');
    await akte('j1');
    ok(await p.evaluate(() => !document.querySelector('.aq-kopf .ak45-inserat') && /Aus Zeitung/.test(document.querySelector('.aq-kopf .sub').innerText)), g + ': unsicherer Link (javascript:) wird nicht verlinkt');
    // Akquise-Ansicht: eigene Notiz markiert
    const aq = await p.evaluate(() => { AQ2.sel = 'a1'; const h = aqVerlaufHtml(findObjekt('a1')); const d = document.createElement('div'); d.innerHTML = h; return [...d.querySelectorAll('.vl-i')].map(x => ({ e: x.classList.contains('vl-eigen'), t: x.querySelector('.vl-x').textContent })); });
    ok(aq.filter(x => x.e).length === 3 && aq.find(x => /Preis-Analyse/.test(x.t)).e === false, g + ': Akquise-Verlauf: eigene Einträge ebenfalls markiert (' + aq.filter(x => x.e).length + ')');
    if(g === 'handy'){ await akte('a1'); await p.evaluate(() => document.querySelector('.ak45-neu').scrollIntoView()); await p.waitForTimeout(200); await p.screenshot({ path: '/tmp/v44/v45_handy_verlauf.png' }); }
    else { await akte('a1'); await p.screenshot({ path: '/tmp/v44/v45_pc_kopf.png' }); await p.evaluate(() => document.querySelector('.ak45-neu').scrollIntoView()); await p.waitForTimeout(200); await p.screenshot({ path: '/tmp/v44/v45_pc_verlauf.png' }); }
    ok(p.fe.length === 0, g + ': keine Fehler ' + p.fe.join(' | '));
    await p.close();
  }
  await b.close();
  console.log(f ? `${f} FEHLER` : 'ALLES OK'); process.exit(f ? 1 : 0);
})();
