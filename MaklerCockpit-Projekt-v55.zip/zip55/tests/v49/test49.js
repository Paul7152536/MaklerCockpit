// v49: Pauls Kalender 19.11. – alle fünf Telefon-Erstgespräche müssen in EINEN Eintrag um 08:00
const { chromium } = require('playwright');
let f = 0; const ok = (b, t) => { console.log((b ? 'ok   ' : 'FEHL ') + t); if(!b) f++; };
const T = 864e5, jetzt = Date.now();
const dk = n => { const d = new Date(); d.setDate(d.getDate() + n); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); };
const lead = (id, x) => Object.assign({ id, objektart: 'Wohnung', ort: '12555 Berlin', status: 'termin', hatTermin: true, quelle: 'Kleinanzeigen', createdAt: jetzt - 3 * T, verlauf: [] }, x);
const D = JSON.stringify({ objekte: [
  lead('dg', { akqTitel: 'Dachgeschoss zum Ausbau Berlin', verkaeuferTelefon: '0151 17460378', link: 'https://www.kleinanzeigen.de/s-anzeige/dg/1' }),
  lead('gr', { akqTitel: '12557 Berlin-Köpenick/Grünau', verkaeuferTelefon: '0151 17460378' }),
  lead('pf', { akqTitel: 'Provisionsfrei! Modernisierte 3-Zimmer Wohnung in Gropiusstadt' }),
  lead('sb', { akqTitel: 'Silbersteinstraße 82', verkaeuferTelefon: '017648845539' }),
  lead('sa', { akqTitel: 'Privatverkauf: Haus mit Garten & Kamin in Berlin-Falkenberg', status: 'erstkontakt', verkaeuferName: 'Sandra', verkaeuferTelefon: '01633840793' }),
  lead('lz', { akqTitel: 'Nahe Lietzensee - Stilvolle 2-Zimmer Wohnung', ort: '14057 Berlin-Charlottenburg', status: 'kleinanzeigen_geschrieben', verkaeuferTelefon: '0172 4444444' }),
  lead('kh', { akqTitel: 'Königsheideweg 190', verkaeuferName: 'Rene', verkaeuferTelefon: '0151-61689468', verlauf: [{ typ: 'gespraech', text: 'Gespräch', am: jetzt - T }] })],
  kontakte: [],
  termine: [
    { id: 't1', titel: '📞 Erstgespräch', datum: dk(1), uhrzeit: '10:00', dauer: 15, art: 'erstgespraech', wo: 'telefon', ort: '0163 8889671', googleEventId: 'g1' },
    { id: 't2', titel: 'Erstgespräch mit Sandra', datum: dk(1), uhrzeit: '10:00', dauer: 15, art: 'erstgespraech', wo: 'telefon', ort: 'Telefon 01633840793', googleEventId: 'g2' },
    { id: 't3', titel: 'Erstgespräch: Dachgeschoss zum Ausbau Berlin', datum: dk(1), uhrzeit: '10:00', dauer: 15, art: 'erstgespraech', wo: 'telefon', ort: 'Telefon 0151 17460378', objektId: 'dg', googleEventId: 'g3' },
    { id: 't4', titel: 'Erstgespräch: Provisionsfrei! Modernisierte 3-Zimmer', datum: dk(1), uhrzeit: '10:00', dauer: 15, art: 'erstgespraech', wo: 'telefon', ort: 'Telefon 0151 17460378', objektId: 'pf', googleEventId: 'g4' },
    { id: 't5', titel: 'Telefontermin', datum: dk(1), uhrzeit: '10:00', dauer: 15, art: 'rueckruf', ort: 'Telefon 017648845539', objektId: 'sb', googleEventId: 'g5' },
    { id: 'v1', titel: 'Besichtigung Grünau', datum: dk(3), uhrzeit: '11:00', art: 'besichtigung', wo: 'vorort', objektId: 'gr', googleEventId: 'g6' },
    { id: 'b1', titel: 'Besichtigung: Nahe Lietzensee', datum: dk(2), uhrzeit: '10:00', dauer: 60, art: 'besichtigung', wo: 'vorort', objektId: 'lz', googleEventId: 'g8' },
    { id: 'n1', titel: 'Rückruf Rene', datum: dk(1), uhrzeit: '14:00', art: 'rueckruf', objektId: 'kh', googleEventId: 'g7' }],
  aufgaben: [], notizen: [], googleSync: { bekannt: { g1: 't1', g2: 't2', g3: 't3', g4: 't4', g5: 't5', g6: 'v1', g7: 'n1', g8: 'b1' } }, meta: { v9neustart: { quittiert: true } } });
(async () => {
  const b = await chromium.launch();
  for(const [g, w, h] of [['pc', 1440, 900], ['handy', 412, 915]]){
    const p = await b.newPage({ viewport: { width: w, height: h }, isMobile: g === 'handy' });
    p.fe = []; p.on('pageerror', e => p.fe.push(e.message));
    await p.addInitScript(([d, g]) => { window.pc = { geraet: g, laden: () => JSON.parse(d), speichern: () => ({ ok: true }), ordner(){}, sicherungSchreiben: () => ({ ok: true }), sicherungLesen: () => null }; }, [D, g]);
    await p.goto('file:///tmp/pc/app/index.html'); await p.waitForTimeout(3000);
    await p.evaluate(() => { try{ schliesseModal(); }catch(e){} const k = document.getElementById('an31Karte'); if(k) k.remove(); });
    const r = await p.evaluate((m) => ({ ids: db.termine.map(t => t.id).sort(), al: db.termine.find(t => t.id === 'anrufliste-' + m), o: Object.fromEntries(db.objekte.map(o => [o.id, [o.anrufTag || '', o.status, aqTel(o), o.telefonArt || '']])), zus: Object.keys((db.googleSync || {}).zusammen || {}).sort().join() }), await p.evaluate(() => { const d = new Date(); d.setDate(d.getDate() + 1); return toDateKey(d); }));
    ok(['t1', 't2', 't3', 't4', 't5'].every(i => !r.ids.includes(i)), g + ': alle fünf Telefon-Erstgespräche zusammengefügt (übrig: ' + r.ids.join(',') + ')');
    ok(r.ids.includes('v1') && r.ids.includes('n1'), g + ': Besichtigung und Rückruf nach Gespräch bleiben einzeln');
    ok(r.al && r.al.uhrzeit === '08:00' && r.al.dauer === 60 && /Anrufen: 4 Telefontermine/.test(r.al.titel), g + ': EIN Eintrag 08:00, 4 Anrufe × 15 Min (' + (r.al && [r.al.titel, r.al.dauer].join(' | ')) + ')');
    const z = (r.al && r.al.notiz || '').split('\n');
    ok(z.length === 4 && z.includes('Dachgeschoss zum Ausbau Berlin + Provisionsfrei! Modernisierte 3-Zimmer Wohnung in… – 0151 17460378') && z.includes('Silbersteinstraße 82 – 017648845539') && z.some(x => /Kamin in… – Sandra – 01633840793/.test(x)) && z.includes('0163 8889671'), g + ': Zeilen Objekt – Name – Telefon, gleicher Verkäufer = eine Zeile\n       ' + z.join('\n       '));
    ok(r.o.pf[2] === '0151 17460378' && r.o.pf[0] && r.o.dg[0] && r.o.sa[0] && r.o.sb[0], g + ': Leads auf der Liste, Provisionsfrei hat jetzt die Nummer');
    ok(r.o.dg[1] === 'telefontermin' && r.o.gr[1] === 'termin' && r.o.dg[3] === 'erstkontakt', g + ': Status Telefontermin · Erstkontakt; Lead mit Besichtigung bleibt „Termin“');
    ok(r.zus === 'g1,g2,g3,g4,g5', g + ': fünf Google-Einzeltermine ohne Rückfrage zum Löschen vorgemerkt (' + r.zus + ')');
    await p.evaluate(() => { const d = new Date(); d.setDate(d.getDate() + 1); oeffneTerminModal('anrufliste-' + toDateKey(d)); }); await p.waitForTimeout(300);
    const li = await p.evaluate(() => document.getElementById('modalInner').innerText);
    ok(/0163 8889671/.test(li) && /ohne Lead/.test(li) && /Inserat öffnen/.test(li) && /4 Anrufe/.test(li), g + ': Anrufliste zeigt auch den Termin ohne Lead');
    await p.evaluate(() => { const d = new Date(); d.setDate(d.getDate() + 1); const k = toDateKey(d); const e = ek49Extras()[k][0]; ek49ExtraErledigt(k, e.id); }); await p.waitForTimeout(200);
    ok(await p.evaluate(() => { const d = new Date(); d.setDate(d.getDate() + 1); const t = db.termine.find(x => x.id === 'anrufliste-' + toDateKey(d)); return /\(3 offen\)/.test(t.titel) && /✓ 0163 8889671/.test(t.notiz); }), g + ': Abhaken bei Termin ohne Lead → Kalender „(3 offen)“');
    // ── schon gesetzter Termin → „Telefontermin – Erstkontakt“ im Bearbeiten-Dialog ──
    await p.evaluate(() => { schliesseModal(); oeffneTerminModal('b1'); }); await p.waitForTimeout(250);
    ok(await p.evaluate(() => { const k = document.getElementById('ek49Knopf'), tw = document.getElementById('m_t_wo'); return !!k && !!tw && tw.closest('.tw-box').nextElementSibling === k; }), g + ': „Termin bearbeiten“ hat den Knopf direkt unter Telefon/Vor Ort');
    await p.evaluate(() => document.getElementById('ek49Knopf').click()); await p.waitForTimeout(300);
    const u = await p.evaluate((d2) => ({ b1: db.termine.some(t => t.id === 'b1'), al: db.termine.find(t => t.id === 'anrufliste-' + d2), lz: findObjekt('lz') }), await p.evaluate(() => { const d = new Date(); d.setDate(d.getDate() + 2); return toDateKey(d); }));
    ok(!u.b1 && u.al && u.al.uhrzeit === '08:00' && /Lietzensee/.test(u.al.notiz) && u.lz.anrufTag && u.lz.telefonArt === 'erstkontakt', g + ': gesetzter Termin → Anrufliste 08:00 (' + (u.al && u.al.titel) + ')');
    // ── neuer Termin im Kalender nur mit Nummer ──
    await p.evaluate(() => { oeffneTerminModal(); }); await p.waitForTimeout(250);
    await p.evaluate(() => { const d = new Date(); d.setDate(d.getDate() + 2); document.getElementById('m_t_titel').value = 'Erstkontakt Wohnung Spandau'; document.getElementById('m_t_datum').value = toDateKey(d); document.getElementById('m_t_vbtel').value = '0176 9999999'; document.getElementById('ek49Knopf').click(); }); await p.waitForTimeout(300);
    ok(await p.evaluate(() => { const d = new Date(); d.setDate(d.getDate() + 2); const t = db.termine.find(x => x.id === 'anrufliste-' + toDateKey(d)); return /2 Telefontermine/.test(t.titel) && /Wohnung Spandau – 0176 9999999/.test(t.notiz) && !db.termine.some(x => x.titel === 'Erstkontakt Wohnung Spandau'); }), g + ': neuer Termin ohne Lead → in dieselbe Anrufliste');
    ok(!p.fe.length, g + ': keine JS-Fehler ' + p.fe.slice(0, 3).join(' | '));
    await p.close();
  }
  await b.close(); console.log(f ? 'FEHLER ' + f : 'ALLES OK'); process.exit(f ? 1 : 0);
})();
