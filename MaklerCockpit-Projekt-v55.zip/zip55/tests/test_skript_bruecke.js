// v15: Skript-Brücke – Hauptprozess (google.js) + echtes Apps-Skript (kalender_bruecke.gs) in Node nachgestellt
const Module = require('module'); const fs = require('fs'); const os = require('os'); const path = require('path'); const vm = require('vm');
let fehler = 0; const ok = (b, t) => { if(!b){ fehler++; console.log('FEHLER:', t); } else console.log('ok  ', t); };
const ORDNER = fs.mkdtempSync(path.join(os.tmpdir(), 'gs-'));
const electron = { shell: { openExternal: async () => {} }, safeStorage: { isEncryptionAvailable: () => true, encryptString: s => Buffer.from('§' + s), decryptString: b => b.toString().slice(1) } };
const origLoad = Module._load; Module._load = function(req, ...r){ return req === 'electron' ? electron : origLoad.call(this, req, ...r); };
// ── Google REST nachgebaut (was UrlFetchApp im Skript erreicht) ──
let restLog = [], apiAus = false, rest429 = 0;
function googleRest(url, opt){
  restLog.push({ url, opt });
  if(!opt.headers.Authorization.startsWith('Bearer SKRIPT-TOKEN')) return [401, { error: { code: 401 } }];
  if(apiAus) return [403, { error: { code: 403, message: 'Google Calendar API has not been used in project', errors: [{ reason: 'accessNotConfigured' }] } }];
  if(rest429 > 0){ rest429--; return [429, { error: { code: 429, errors: [{ reason: 'rateLimitExceeded' }] } }]; }
  if(url.includes('/users/me/calendarList')) return [200, { items: [{ id: 'paul.kalender@gmail.com', primary: true }] }];
  if(opt.method === 'delete') return [204, null];
  if(opt.method === 'patch') return [200, Object.assign({ id: 'ev1', updated: '2026-11-10T12:00:00Z' }, JSON.parse(opt.payload))];
  return [200, { items: [{ id: 'ev1', summary: 'Test' }] }];
}
// ── Apps-Skript in Sandbox laden ──
function skriptLaden(schluessel){
  const code = fs.readFileSync('/tmp/jvb/kalender_bruecke.gs', 'utf8').replace('%%SCHLUESSEL%%', schluessel);
  const sb = {
    ContentService: { MimeType: { JSON: 'json' }, createTextOutput: t => ({ text: t, setMimeType(){ return this; } }) },
    ScriptApp: { getOAuthToken: () => 'SKRIPT-TOKEN-1' },
    CalendarApp: { getDefaultCalendar: () => ({ getId: () => 'paul.kalender@gmail.com' }) },
    UrlFetchApp: { fetch: (url, opt) => { const [st, data] = googleRest(url, opt); return { getResponseCode: () => st, getContentText: () => data === null ? '' : JSON.stringify(data) }; } },
    JSON, String, Object, encodeURIComponent
  };
  vm.createContext(sb); vm.runInContext(code + '\n;this.doPost = doPost; this.doGet = doGet;', sb);
  return sb;
}
let skript = null, antwortArt = 'skript', skriptAufrufe = 0;
const URL_OK = 'https://script.google.com/macros/s/AKfycbx1234567890abcdefghijklmnop/exec';
global.fetch = async (url, opt = {}) => {
  const u = String(url);
  const antw = (st, text) => ({ ok: st < 300, status: st, text: async () => text, json: async () => JSON.parse(text) });
  if(u.startsWith('https://script.google.com/')){
    skriptAufrufe++;
    if(antwortArt === 'login') return antw(200, '<html><a href="https://accounts.google.com/ServiceLogin">Anmelden</a></html>');
    if(antwortArt === '404') return antw(404, '<html>Seite nicht gefunden</html>');
    if(u !== URL_OK) return antw(404, '<html>nicht gefunden</html>');
    return antw(200, skript.doPost({ postData: { contents: opt.body } }).text);
  }
  if(u.startsWith('https://oauth2.googleapis.com/revoke')) return antw(200, '{}');
  throw new Error('unerwartet ' + u);
};
let handler; require('/tmp/pc/app/google.js')({ handle: (n, f) => handler = f }, ORDNER, null);
const ruf = (a, x) => handler({}, a, x);
(async () => {
  const k1 = (await ruf('skriptSchluessel')).schluessel, k2 = (await ruf('skriptSchluessel')).schluessel;
  ok(k1 && k1.length >= 30 && k1 === k2, 'Schlüssel erzeugt und stabil');
  const datei = () => fs.readFileSync(path.join(ORDNER, 'google-konto.json'), 'utf8');
  ok(!datei().includes(k1) && JSON.parse(datei()).skriptKeyNeu.startsWith('enc:'), 'Schlüssel verschlüsselt gespeichert');
  let r = await ruf('skriptVerbinden', { url: 'https://example.com/x' }); ok(!r.ok && /keine Web-App-Adresse/.test(r.fehler), 'Falsche Adresse abgelehnt');
  r = await ruf('skriptVerbinden', { url: URL_OK.replace('/exec', '/dev') }); ok(!r.ok && /Test-Adresse/.test(r.fehler), '/dev-Adresse erklärt');
  skript = skriptLaden('anderer-schluessel');
  r = await ruf('skriptVerbinden', { url: URL_OK }); ok(!r.ok && /anderer Schlüssel/.test(r.fehler), 'Anderer Schlüssel im Skript erkannt');
  skript = skriptLaden(k1); apiAus = true;
  r = await ruf('skriptVerbinden', { url: URL_OK }); ok(!r.ok && /Dienste/.test(r.fehler) && /Google Calendar API/.test(r.fehler), 'Fehlender Kalender-Dienst erkannt: ' + r.fehler.slice(0, 60));
  apiAus = false; antwortArt = 'login';
  r = await ruf('skriptVerbinden', { url: URL_OK }); ok(!r.ok && /Zugriff: Jeder/.test(r.fehler), 'Falsche Freigabe (Login-Seite) erkannt');
  antwortArt = 'skript';
  r = await ruf('skriptVerbinden', { url: URL_OK + '?foo=1' });
  ok(r.ok && r.verbunden && r.modus === 'skript' && r.email === 'paul.kalender@gmail.com', 'Verbunden über Skript als ' + r.email);
  ok(!datei().includes(URL_OK) && !datei().includes(k1), 'URL + Schlüssel nur verschlüsselt in der Datei');
  // Kalender-Abrufe laufen durchs Skript
  restLog = [];
  r = await ruf('api', { methode: 'GET', pfad: '/calendars/paul.kalender%40gmail.com/events', query: { timeMin: '2026-10-11T00:00:00.000Z', singleEvents: 'true', pageToken: undefined, leer: '', eventTypes: ['default', 'birthday'] } });
  const u = restLog[0] && restLog[0].url;
  ok(r.ok && r.data.items[0].id === 'ev1', 'Termine über das Skript gelesen');
  ok(u === 'https://www.googleapis.com/calendar/v3/calendars/paul.kalender%40gmail.com/events?timeMin=2026-10-11T00%3A00%3A00.000Z&singleEvents=true&eventTypes=default&eventTypes=birthday', 'Abfrage korrekt gebaut: ' + u);
  r = await ruf('api', { methode: 'PATCH', pfad: '/calendars/x/events/ev1', body: { summary: 'Neu', start: { dateTime: '2026-11-12T10:00:00', timeZone: 'Europe/Berlin' } } });
  ok(r.ok && r.data.summary === 'Neu' && restLog.slice(-1)[0].opt.method === 'patch' && restLog.slice(-1)[0].opt.contentType === 'application/json', 'Ändern (PATCH) mit Inhalt');
  r = await ruf('api', { methode: 'DELETE', pfad: '/calendars/x/events/ev1' }); ok(r.ok && r.status === 204 && r.data === null, 'Löschen (204)');
  rest429 = 1; const vor = skriptAufrufe;
  r = await ruf('api', { methode: 'GET', pfad: '/users/me/calendarList' }); ok(r.ok && skriptAufrufe - vor === 2, '429 → automatisch wiederholt');
  r = await ruf('api', { methode: 'GET', pfad: '/../oauth' }); ok(!r.ok && /nicht erlaubt/.test(r.fehler), 'Fremde Pfade gesperrt');
  // Skript gelöscht / Schlüssel geändert
  antwortArt = '404'; r = await ruf('api', { methode: 'GET', pfad: '/users/me/calendarList' }); ok(!r.ok && r.code === 'skript_weg', 'Gelöschte Bereitstellung erkannt');
  antwortArt = 'skript'; skript = skriptLaden('neu'); r = await ruf('api', { methode: 'GET', pfad: '/users/me/calendarList' }); ok(!r.ok && r.code === 'abgelaufen', 'Geänderter Schlüssel → neu verbinden');
  skript = skriptLaden(k1);
  // Neustart
  let h2; require('/tmp/pc/app/google.js')({ handle: (n, f) => h2 = f }, ORDNER, null);
  let s = await h2({}, 'status'); ok(s.verbunden && s.modus === 'skript', 'Nach Neustart weiter verbunden (dauerhaft)');
  r = await h2({}, 'api', { methode: 'GET', pfad: '/users/me/calendarList' }); ok(r.ok, 'Abruf nach Neustart');
  // Trennen und mit gleichem Skript wieder verbinden
  r = await h2({}, 'trennen', {}); ok(r.ok && !r.verbunden, 'Getrennt');
  ok((await h2({}, 'skriptSchluessel')).schluessel === k1, 'Gleicher Schlüssel bleibt → Skript muss nicht neu');
  r = await h2({}, 'skriptVerbinden', { url: URL_OK }); ok(r.ok && r.verbunden, 'Wieder verbunden ohne neuen Code');
  r = await h2({}, 'trennen', { allesLoeschen: true });
  ok((await h2({}, 'skriptSchluessel')).schluessel !== k1, 'Alles löschen → neuer Schlüssel');
  // GET im Browser
  ok(/läuft/.test(skript.doGet().text), 'Skript-Adresse im Browser zeigt „läuft“');
  console.log('\nFEHLER', fehler); process.exit(fehler ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
