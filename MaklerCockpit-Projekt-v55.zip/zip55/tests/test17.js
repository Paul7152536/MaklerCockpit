// v17: PDF-Speichern aus Shooting-Analyse, Marktanalyse und Hauptfenster – ohne Internet
const { chromium } = require('playwright');
let fehler = 0; const ok = (b, t) => { if(!b){ fehler++; console.log('FEHLER:', t); } else console.log('ok  ', t); };
(async () => {
  const b = await chromium.launch(); const ctx = await b.newContext({ acceptDownloads: true, viewport:{ width:1500, height:950 }, deviceScaleFactor: 2 }); const p = await ctx.newPage();
  const fe = []; p.on('pageerror', e => { fe.push(e.message); console.log('SEITENFEHLER', e.message); });
  await ctx.route('https://**', r => r.abort());   // kein Internet
  await p.addInitScript(() => {
    window.__pdfs = [];
    window.pc = { laden: () => ({ objekte:[], kontakte:[], termine:[], marktanalysen:[], aufgaben:[], notizen:[], mentorFragen:[], meta:{ v9neustart:{ quittiert:true } } }), speichern: () => ({ok:true}), ordner(){}, sicherungSchreiben: () => ({ok:true}), sicherungLesen: () => null, zwischenablage: async () => '', abruf: async () => ({ok:false}),
      dateiSpeichern: async (name, b64) => { window.__pdfs.push({ name, kopf: atob(b64.slice(0, 8)), laenge: b64.length }); return { ok:true, pfad:'C:\\\\Users\\\\Paul\\\\Downloads\\\\' + name, name }; },
      dateiOeffnen: (pfad, art) => { window.__geoeffnet = [pfad, art]; } };
  });
  let downloads = 0; p.on('download', () => downloads++);
  await p.goto('file:///tmp/pc/app/index.html'); await p.waitForTimeout(1200);
  ok(await p.evaluate(() => !!(window.jspdf && window.jspdf.jsPDF && window.jspdf.jsPDF.__mc)), 'Hauptfenster: jsPDF lokal geladen + Speichern-Patch');
  // Shooting-Analyse
  await p.evaluate(() => wechsleAnsicht('shooting')); await p.waitForTimeout(2000);
  const sh = p.frames().find(f => f.url() === 'about:srcdoc');
  ok(await sh.evaluate(() => typeof html2canvas === 'function' && !!(window.jspdf && window.jspdf.jsPDF.__mc)), 'Shooting-Analyse: PDF-Bausteine ohne Internet geladen');
  await sh.evaluate(() => { const t = document.getElementById('objTitle'); if(t) t.value = 'Musterstraße 5 Lichtenberg'; document.getElementById('downloadPdfBtn').click(); });
  await p.waitForTimeout(5000);
  const r1 = await p.evaluate(() => ({ pdfs: window.__pdfs.slice(), hinweis: (document.getElementById('mcPdfHinweis')||{}).innerText || '' }));
  const st1 = await sh.evaluate(() => document.getElementById('exportStatus').textContent);
  ok(r1.pdfs.length === 1 && r1.pdfs[0].name === 'Musterstraße_5_Lichtenberg.pdf' && r1.pdfs[0].kopf.startsWith('%PDF') && r1.pdfs[0].laenge > 5000 && r1.pdfs[0].laenge < 4000000, 'Shooting: „Speichern unter“ mit richtigem Namen + echte PDF: ' + JSON.stringify(r1.pdfs[0]));
  ok(/PDF gespeichert/.test(r1.hinweis) && /Öffnen/.test(r1.hinweis) && /Im Ordner zeigen/.test(r1.hinweis), 'Hinweis „PDF gespeichert“ mit Öffnen / Im Ordner zeigen');
  ok(st1 === 'PDF erstellt ✓', 'Status im Modul: ' + st1);
  await p.screenshot({ path: '/tmp/v17test/1_shooting_pdf.png' });
  await p.evaluate(() => document.querySelector('#mcPdfHinweis button').click());
  const go = await p.evaluate(() => window.__geoeffnet); ok(go && go[0].endsWith('Musterstraße_5_Lichtenberg.pdf') && go[1] === 'oeffnen', 'Knopf „Öffnen“ öffnet die gespeicherte Datei');
  // Marktanalyse
  await p.evaluate(() => wechsleAnsicht('immowert')); await p.waitForTimeout(2000);
  const ma = p.frames().find(f => f.url() === 'about:srcdoc' && f !== sh) || p.frames().filter(f => f.url() === 'about:srcdoc').slice(-1)[0];
  const hatBtn = await ma.evaluate(() => !!document.getElementById('downloadPdfBtn'));
  if(hatBtn){
    await ma.evaluate(() => document.getElementById('downloadPdfBtn').click()); await p.waitForTimeout(5000);
    const r2 = await p.evaluate(() => window.__pdfs.slice());
    ok(r2.length === 2 && r2[1].kopf.startsWith('%PDF'), 'Marktanalyse: PDF über „Speichern unter“: ' + (r2[1] && r2[1].name));
  } else ok(false, 'Marktanalyse: Knopf nicht gefunden');
  // Hauptfenster (Bilder zu PDF nutzt dieselbe Bibliothek)
  await p.evaluate(() => { const { jsPDF } = window.jspdf; const d = new jsPDF(); d.text('Test', 10, 10); d.save('Exposé Fotos.pdf'); }); await p.waitForTimeout(300);
  const r3 = await p.evaluate(() => window.__pdfs.slice(-1)[0]);
  ok(r3 && r3.name === 'Exposé Fotos.pdf' && r3.kopf.startsWith('%PDF'), 'Hauptfenster: jsPDF.save → „Speichern unter“');
  ok(downloads === 0, 'Kein namenloser Browser-Download mehr');
  // Ohne PC-Version (Browser): normales Herunterladen bleibt
  await p.evaluate(() => { const alt = window.pc.dateiSpeichern; delete window.pc.dateiSpeichern; const { jsPDF } = window.jspdf; new jsPDF().save('Browser.pdf'); window.pc.dateiSpeichern = alt; }); await p.waitForTimeout(800);
  ok(downloads === 1, 'Ohne PC-Funktion: normaler Download als Rückfall');
  ok(fe.length === 0, 'Keine Seitenfehler');
  console.log('\nFEHLER', fehler); await b.close(); process.exit(fehler ? 1 : 0);
})();
