// v43: Auswahlkatalog 2.0 in der Großen Analyse – 10 Akzeptanzfälle aus dem Prüfbericht + Migration + Regeln
const { chromium } = require('playwright');
let f = 0; const ok = (b, t) => { console.log((b ? 'ok   ' : 'FEHL ') + t); if(!b) f++; };
const ALT = { art: 'DHH', region: 'Berlin', stichtag: '2026-11-17', zweck: 'Verkaufsmarktanalyse', publikum: 'owner', notiz: '', vergleich: [], unterlagen: {},
  werte: { plz: { v: '12487', s: 'documented' }, ort: { v: 'Berlin', s: 'documented' }, adresse: { v: 'Wuhletal 15', s: 'documented' }, wfl: { v: '111,53', s: 'documented' }, grund: { v: '513', s: 'documented' },
    stellung: { v: 'DHH', s: 'owner_statement' }, keller: { v: 'teil', s: 'owner_statement' }, zustand: { v: 'saniert', s: 'owner_statement' }, standard: { v: 'mittel', s: 'owner_statement' },
    heizung: { v: 'Öl-Zentralheizung, Baujahr 1992', s: 'owner_statement' }, dach: { v: 'Satteldach, DG ausgebaut', s: 'owner_statement' }, terrasse: { v: '20', s: 'documented' }, terrasse_anteil: { v: '25', s: 'documented' },
    ea_art: { v: 'keiner', s: 'owner_statement' }, nutzung: { v: 'eigengenutzt', s: 'owner_statement' }, bauweise: { v: 'massiv', s: 'owner_statement' }, wfl_regel: { v: 'WoFlV', s: 'documented' } } };
const D = JSON.stringify({ objekte: [{ id: 'w1', akqTitel: 'DHH Wuhletal', objektart: 'Doppelhaushälfte', status: 'akquise', ort: '12487 Berlin', adresse: 'Wuhletal 15, 12487 Berlin', verlauf: [] },
  { id: 'w2', akqTitel: 'Reihenendhaus Test', objektart: 'Reihenendhaus', status: 'akquise', ort: '12555 Berlin', adresse: 'Testweg 3, 12555 Berlin', verlauf: [] }],
  kontakte: [], termine: [], aufgaben: [], notizen: [], meta: { v9neustart: { quittiert: true } }, grossanalyse: { entwuerfe: { w1: ALT }, laeufe: [] } });
(async () => {
  const b = await chromium.launch();
  for(const [g, w, h] of [['pc', 1440, 900], ['handy', 412, 915]]){
    const p = await b.newPage({ viewport: { width: w, height: h }, isMobile: g === 'handy', hasTouch: g === 'handy' });
    p.fe = []; p.on('pageerror', e => p.fe.push(e.message));
    await p.addInitScript(([d, g]) => { window.pc = { geraet: g, laden: () => JSON.parse(d), speichern: () => ({ ok: true }), ordner(){}, sicherungSchreiben: () => ({ ok: true }), sicherungLesen: () => null, gekoppelt: () => true, google: async () => ({ ok: false }) }; navigator.clipboard.writeText = async t => { window.__kopie = t; }; }, [D, g]);
    await p.goto('file:///tmp/pc/app/index.html'); await p.waitForTimeout(2200);
    await p.evaluate(() => { try{ schliesseModal(); }catch(e){} GA44.alleAuf = true; GA44.quellen = true; GA35.obj = 'w1'; wechsleAnsicht('grossanalyse'); });
    await p.waitForTimeout(500);
    const P = (id) => `[data-g43="${id}"][data-m="v"]`;
    const E = () => p.evaluate(() => JSON.parse(JSON.stringify(ga35Entwurf('w1'))));
    const paket = () => p.evaluate(() => ga35Paket('w1', ga35Entwurf('w1')));
    const grp = (pk, id) => (pk.object_details.groups.find(x => x.group_id === id) || { entries: [] }).entries;
    const offen = async gid => { const o = await p.evaluate(gid => document.getElementById('ga43g-' + gid).open, gid); if(!o){ await p.click(`#ga43g-${gid} > summary`); await p.waitForTimeout(150); } };
    const neu = async gid => { await offen(gid); await p.click(`#ga43g-${gid} .ga43-neu`); await p.waitForTimeout(250); return p.evaluate(gid => { const l = ga35Entwurf('w1').gruppen43[gid]; return l[l.length - 1].id; }, gid); };
    const waehle = async (sel, v) => { await p.selectOption(sel, v); await p.waitForTimeout(200); };
    const tippe = async (sel, v) => { await p.fill(sel, v); await p.waitForTimeout(450); };

    // ── Migration alter Entwurf ──
    let e = await E();
    ok(e.v43 === 1 && e.werte.stellung.v === 'Einseitig angebaut' && e.werte.stellung.alt === 'DHH' && e.werte.keller.v === 'Teilunterkellert' && e.werte.standard.v === 'Mittel / normal' && e.werte.nutzung.v === 'Eigengenutzt', g + ': Migration: Auswahlwerte auf neue Optionen umgestellt, alter Wert gemerkt');
    ok(e.werte.wfl_regel.v === 'Wohnflächenverordnung (WoFlV)' && e.werte.k_energieausweis_unterlagenstand.v === 'Liegt nicht vor' && !e.werte.ea_art.v, g + ': Migration: WoFlV, Energieausweis „keiner“ → Unterlagenstand „Liegt nicht vor“');
    ok(e.alt43.heizung && /Öl-Zentralheizung/.test(e.alt43.heizung.v) && e.alt43.zustand && /saniert/.test(e.alt43.zustand.v) && !e.werte.heizung && e.werte.zustand.v === '', g + ': Migration: Freitexte und nicht eindeutige Werte bleiben als Freitext-Angaben erhalten');
    ok(e.werte.k_tragende_bauweise.v === 'Massivbau' && e.werte.k_dachform.v === 'Satteldach' && e.gruppen43.aussenflaechen.length === 1 && e.gruppen43.aussenflaechen[0].w.wohnflaechenanrechnung.v === '25 %', g + ': Migration: Massivbau, Satteldach, Terrasse 20 m² / 25 % als Außenflächen-Eintrag');
    ok(await p.evaluate(() => /Freitext-Angaben/.test(document.querySelector('.ga43-alt').innerText) && /Öl-Zentralheizung/.test(document.querySelector('.ga43-alt').innerHTML)), g + ': Freitext-Karte sichtbar');
    ok(await p.evaluate(() => !document.querySelector('.ga35-gitter [data-ga]') && document.querySelectorAll('.ga43-gruppe').length === 25), g + ': 25 Gruppen sichtbar (Unterlagen/Notizen bleiben in den bisherigen Karten)');

    // ── Fall 1: nur „zweifach verglast“ ──
    const f1 = await neu('fenster');
    await waehle(P(`g:fenster:${f1}:verglasung_scheibenanzahl`), 'Zweifach verglast (2-fach)');
    let pk = await paket(), fe = grp(pk, 'fenster');
    ok(fe.length === 1 && fe[0].values.length === 1 && fe[0].values[0].value === 'Zweifach verglast (2-fach)', g + ': Fall 1: „2-fach“ allein speicherbar – keine Glasart, kein U-Wert erzwungen');
    // ── Fall 2: unten zweifach, oben dreifach ──
    await tippe(P(`g:fenster:${f1}:bereich_fenstergruppe`), 'EG');
    const f2 = await neu('fenster');
    await tippe(P(`g:fenster:${f2}:bereich_fenstergruppe`), 'DG');
    await waehle(P(`g:fenster:${f2}:verglasung_scheibenanzahl`), 'Dreifach verglast (3-fach)');
    pk = await paket(); fe = grp(pk, 'fenster');
    ok(fe.length === 2 && fe.some(x => x.values.some(v => v.value === 'EG')) && fe[1].values.some(v => v.value === 'Dreifach verglast (3-fach)') && fe[0].values.some(v => v.value === 'Zweifach verglast (2-fach)'), g + ': Fall 2: zwei Fenstergruppen EG/DG mit eigener Verglasung');
    // ── Fall 3 + 6: Gasheizung ohne Technik; läuft, soll aber getauscht werden ──
    const h1 = await neu('heizungen');
    await p.click(`[data-g43="g:heizungen:${h1}:energietraeger"][data-o="Gas, genaue Gasart unbekannt"]`); await p.waitForTimeout(250);
    await waehle(P(`g:heizungen:${h1}:betriebszustand_laut_kenntnisstand`), 'In Betrieb');
    await waehle(P(`g:heizungen:${h1}:geplanter_austausch`), 'Geplant');
    pk = await paket(); let hz = grp(pk, 'heizungen')[0].values;
    ok(hz.find(v => v.field === 'energietraeger').value.join() === 'Gas, genaue Gasart unbekannt' && !hz.some(v => v.field === 'technik_der_waermeerzeugung'), g + ': Fall 3: „Gasheizung“ – Gasart und Kesseltechnik bleiben offen');
    ok(hz.find(v => v.field === 'betriebszustand_laut_kenntnisstand').value === 'In Betrieb' && hz.find(v => v.field === 'geplanter_austausch').value === 'Geplant', g + ': Fall 6: „läuft, soll getauscht werden“ – beides gespeichert');
    ok(!pk.intake_check.missing_items.some(t => /Heizungsanlage fehlt/.test(t)), g + ': Heizungsanlage zählt als erfasst');
    // ── Fall 4: Dach gedämmt ohne Material ──
    await offen('dach');
    await waehle(P('w:k_dachdaemmung_kenntnisstand'), 'Gedämmt, genaue Ausführung offen');
    pk = await paket();
    ok(pk.facts.some(x => x.label === 'Dachdämmung: Kenntnisstand' && x.value === 'Gedämmt, genaue Ausführung offen') && !pk.facts.some(x => /Dämmstoff|Dämmdicke/.test(x.label || '')), g + ': Fall 4: „Dach gedämmt“ ohne Material/Dicke');
    // ── Fall 5: Keller teilweise feucht ──
    const s1 = await neu('schaeden');
    await waehle(P(`g:schaeden:${s1}:befund_verdacht`), 'Feuchtigkeit');
    await p.click(`[data-g43="g:schaeden:${s1}:betroffene_bereiche"][data-o="Keller"]`); await p.waitForTimeout(250);
    await waehle(P(`g:schaeden:${s1}:stand_des_befunds`), 'Sichtbar festgestellt');
    pk = await paket(); let sc = grp(pk, 'schaeden')[0].values;
    ok(sc.length === 3 && sc.find(v => v.field === 'betroffene_bereiche').value.join() === 'Keller', g + ': Fall 5: Feuchtigkeit im Keller als Befund, Ursache offen');
    // ── Fall 7: Baujahr nur Zeitraum ──
    await tippe(P('w:baujahr'), '1936');
    await waehle(P('w:k_genauigkeit_baujahr'), 'Nur Zeitraum bekannt');
    ok(await p.evaluate(() => !document.querySelector('[data-g43="w:baujahr"]') && !!document.querySelector('[data-g43="w:k_baujahr_zeitraum"][data-m="von"]')), g + ': Fall 7: Zeitraum statt Einzeljahr angezeigt');
    await p.fill('[data-g43="w:k_baujahr_zeitraum"][data-m="von"]', '1930'); await p.fill('[data-g43="w:k_baujahr_zeitraum"][data-m="bis"]', '1940'); await p.press('[data-g43="w:k_baujahr_zeitraum"][data-m="bis"]', 'Tab'); await p.waitForTimeout(400);
    pk = await paket();
    const zr = pk.facts.find(x => x.label === 'Baujahr-Zeitraum'), bjf = pk.facts.find(x => x.field === 'gebaeude[0].baujahr');
    ok(zr && zr.value.von === 1930 && zr.value.bis === 1940 && bjf && bjf.excluded_from_valuation === true && !pk.intake_check.missing_items.some(t => /^Baujahr/.test(t)), g + ': Fall 7: 1930–1940 gespeichert, Einzeljahr 1936 nur als Rohwert (excluded_from_valuation)');
    // ── Fall 8: Bäder deckenhoch, Küche Fliesenspiegel ──
    const b1 = await neu('baeder');
    await tippe(P(`g:baeder:${b1}:bad_geschoss`), 'EG');
    await waehle(P(`g:baeder:${b1}:wandbelag_fliesenhoehe`), 'Deckenhoch gefliest');
    const r1 = await neu('raeume');
    await tippe(P(`g:raeume:${r1}:raum_bereich`), 'Küche');
    await waehle(P(`g:raeume:${r1}:wandfliesen_umfang`), 'Fliesenspiegel');
    pk = await paket();
    ok(grp(pk, 'baeder')[0].values.some(v => v.value === 'Deckenhoch gefliest') && grp(pk, 'raeume')[0].values.some(v => v.value === 'Fliesenspiegel') && grp(pk, 'raeume')[0].values.some(v => v.value === 'Küche'), g + ': Fall 8: Bad deckenhoch, Küche Fliesenspiegel – raumbezogen');
    // ── Fall 9: 30 m² BGF Garage ──
    const n1 = await neu('nebenanlagen');
    await waehle(P(`g:nebenanlagen:${n1}:art_der_anlage`), 'Einzelgarage');
    await tippe(P(`g:nebenanlagen:${n1}:flaeche_anlage`), '30');
    pk = await paket();
    ok(pk.intake_check.warnings.some(t => /Fläche ohne Flächenbegriff/.test(t)), g + ': Fall 9: Fläche ohne Flächenbegriff → Hinweis');
    await waehle(P(`g:nebenanlagen:${n1}:flaechenbegriff_der_anlage`), 'Brutto-Grundfläche (BGF)');
    pk = await paket(); const ga = grp(pk, 'nebenanlagen')[0].values;
    ok(ga.find(v => v.field === 'flaeche_anlage').value === 30 && ga.find(v => v.field === 'flaechenbegriff_der_anlage').value === 'Brutto-Grundfläche (BGF)' && pk.facts.find(x => x.field === 'gebaeude[0].wfl_innen_m2').value === 111.53 && !pk.intake_check.warnings.some(t => /Flächenbegriff/.test(t)), g + ': Fall 9: 30 m² bleiben BGF, Wohnfläche unverändert 111,53');
    // ── Fall 10: Sonstiges + Originalnotiz, Quelle/Prüfstatus ──
    await waehle(P('w:k_dachform'), 'Sonstiges');
    await tippe('[data-g43="w:k_dachform"][data-m="so"]', 'Tonnendach');
    await p.click('.ga43-her[data-p="w:k_dachform"]'); await p.waitForTimeout(250);
    await waehle('[data-g43="w:k_dachform"][data-m="q"]', 'Eigentümerangabe');
    await waehle('[data-g43="w:k_dachform"][data-m="p"]', 'Ungeprüfte Angabe');
    await tippe('[data-g43="w:k_dachform"][data-m="n"]', 'so ne runde Dachform');
    pk = await paket(); const df = pk.facts.find(x => x.label === 'Dachform');
    ok(df && df.value === 'Sonstiges: Tonnendach' && df.original_wording === 'so ne runde Dachform' && df.source_type === 'Eigentümerangabe' && df.review_status === 'Ungeprüfte Angabe', g + ': Fall 10: „Sonstiges“ mit Beschreibung, Originalwortlaut, Quelle und Prüfstatus');
    ok(await p.evaluate(() => /Eigentümerangabe · ungeprüft/.test(document.querySelector('.ga43-her[data-p="w:k_dachform"]').textContent)), g + ': Herkunfts-Knopf zeigt „Eigentümerangabe · ungeprüft“');
    // ── Regeln ──
    const a1 = await p.evaluate(() => ga35Entwurf('w1').gruppen43.aussenflaechen[0].id);
    await offen('aussenflaechen'); await waehle(P(`g:aussenflaechen:${a1}:art_der_flaeche`), 'Terrasse');
    ok(await p.evaluate(a1 => { const o = [...document.querySelector(`[data-g43="g:aussenflaechen:${a1}:wohnflaechenanrechnung"][data-m="v"]`).options].find(o => o.value === '100 %'); return o && o.disabled; }, a1), g + ': WoFlV: 100 % für Terrasse gesperrt');
    await p.click('.ga43-her[data-p="w:k_dachform"]'); await p.waitForTimeout(200); await p.click('.ga43-her[data-p="w:k_dachform"]'); await p.waitForTimeout(200);
    await waehle('[data-g43="w:k_dachform"][data-m="p"]', 'Fachlich geprüft');
    pk = await paket();
    ok(pk.intake_check.warnings.some(t => /Fachlich geprüft“ ohne Prüfer/.test(t)), g + ': „Fachlich geprüft“ ohne Prüfer/Datum/Beleg → Hinweis');
    await offen('nutzung');
    await p.click('[data-g43="w:k_bekannte_rechte_beschraenkungen"][data-o="Nießbrauch"]'); await p.waitForTimeout(250);
    await p.click('[data-g43="w:k_bekannte_rechte_beschraenkungen"][data-o="Keine bekannt"]'); await p.waitForTimeout(250);
    e = await E();
    ok(e.werte.k_bekannte_rechte_beschraenkungen.v.join() === 'Keine bekannt', g + ': „Keine bekannt“ schließt andere Auswahl aus');
    await p.click('[data-g43="w:k_bekannte_rechte_beschraenkungen"][data-o="Nießbrauch"]'); await p.waitForTimeout(250);
    e = await E(); pk = await paket();
    ok(e.werte.k_bekannte_rechte_beschraenkungen.v.join() === 'Nießbrauch' && pk.intake_check.warnings.some(t => /je Recht/.test(t)), g + ': Nießbrauch gewählt → Hinweis „je Recht Stand im Verkauf erfassen“');
    // ── Suche ──
    await p.fill('#ga43Such', 'rollo'); await p.waitForTimeout(200);
    let sicht = await p.evaluate(() => [...document.querySelectorAll('.ga43-gruppe')].filter(d => d.style.display !== 'none').map(d => d.dataset.auf));
    ok(sicht.join() === 'sonnenschutz', g + ': Suche „rollo“ → nur Rollläden/Verschattung (' + sicht.join() + ')');
    await p.fill('#ga43Such', 'öl'); await p.waitForTimeout(200);
    sicht = await p.evaluate(() => [...document.querySelectorAll('.ga43-gruppe')].filter(d => d.style.display !== 'none').map(d => d.dataset.auf));
    ok(sicht.includes('heizungen') && sicht.includes('heizdetails') && sicht.length < 8, g + ': Suche „öl“ → Heizung/Brennstofflager (' + sicht.join() + ')');
    await p.fill('#ga43Such', ''); await p.waitForTimeout(200);
    // ── Prompt ──
    await p.evaluate(() => { const e = ga35Entwurf('w1'); e.schnell = { stand: '2026-11-17', typ: 'haus', vergleich: { wert: 512345.678, mittelpreis: 4321.123, anzahl: 3, formel: 'x', werte: [{ label: 'Doppelhaushälfte, Eisenhutweg 8, 12487 Berlin-Johannisthal', wert: 3827.7777777778 }, { label: 'Homeday', wert: 3400 }] } }; save(); });
    pk = await paket();
    const ez = pk.broker_quick_check.vergleichswert.einzelwerte_eur_m2;
    ok(ez[0].label === 'Doppelhaushälfte, Eisenhutweg, 12487 Berlin-Johannisthal' && ez[0].wert === 3828, g + ': Schnellbewertung im Paket: Hausnummer entfernt, 3827,7777… → 3828');
    await p.evaluate(() => ga35PromptKopieren()); await p.waitForTimeout(300);
    const t = await p.evaluate(() => window.__kopie || '');
    ok(/Ergänzung Erfassungskatalog 2\.0/.test(t) && /AUSGABE ZUM KOPIEREN/.test(t) && /"object_details"/.test(t) && /"legacy_notes"/.test(t) && /Öl-Zentralheizung/.test(t) && t.indexOf('Erfassungskatalog') < t.indexOf('## Auftrag'), g + ': Prompt: Katalogregeln vor dem Auftrag, Kopierblock-Regel, Details und Freitext-Angaben enthalten');
    // ── Preis-Analyse ──
    await p.evaluate(() => { const e = ga35Entwurf('w1'); e.werte.brw = { v: '40', s: 'documented' }; e.werte.wunsch = { v: '798000', s: 'owner_statement' }; e.vergleich = [{ art: 'listing', lage: 'Doppelhaushälfte, Eisenhutweg 8, 12487 Berlin', preis: '689000', flaeche: '180', flaeche_art: 'Wfl', quelle: 'https://example.org/2' }]; save(); ga35Neuzeichnen(); });
    ok(await p.evaluate(() => { const b = [...document.querySelectorAll('.ga35-aktion button')].map(x => x.textContent); return /Preis-Analyse/.test(b[0]) && b.some(t => /Ausführlicher Prüfbericht/.test(t)); }), g + ': Knopf „Preis-Analyse“ zuerst, Prüfbericht als zweiter Knopf');
    pk = await paket();
    ok(pk.intake_check.warnings.some(t => /Bodenrichtwert 40 €\/m² ist für Berlin ungewöhnlich niedrig/.test(t)), g + ': Bodenrichtwert 40 €/m² in Berlin → Warnung');
    await p.click('.ga43-preisknopf'); await p.waitForTimeout(300);
    const pt = await p.evaluate(() => window.__kopie || '');
    ok(/Du nennst IMMER einen Preis/.test(pt) && /Wahrscheinlichster Verkaufspreis/.test(pt) && /Warum dieser Preis/.test(pt) && /AUSGABE ZUM KOPIEREN/.test(pt) && /"run_id":"PA-\d{8}-/.test(pt), g + ': Preis-Prompt: Preis-Pflicht, feste Gliederung, Kopierblock mit run_id');
    ok(/Wohnfläche innen: 111,53 m² \[laut Unterlage\]/.test(pt) && /Fenstergruppe 1: Bereich \/ Fenstergruppe: EG/.test(pt) && /Öl-Zentralheizung/.test(pt) && /Wunschpreis: 798\.000 €/.test(pt), g + ': Steckbrief lesbar mit Herkunft, Fenstergruppen, Freitext-Angaben, Wunschpreis');
    ok(!/Wuhletal 15/.test(pt) && /Straße \(ohne Hausnummer\): Wuhletal/.test(pt) && !/Eisenhutweg 8/.test(pt) && !/"schema_version"/.test(pt), g + ': ohne Hausnummern, kein JSON-Datenpaket im Preis-Prompt');
    await p.evaluate(() => ga35ErgebnisDialog()); await p.waitForTimeout(200);
    await p.fill('#ga35ErgText', 'Hier das Ergebnis:\n```json\n{"run_id":"x","status":"vorlaeufig","valuation":{"low_eur":690000,"central_eur":735000,"high_eur":770000,"band_type":"erzielbarer Verkaufspreis","quality_grade":"mittel"},"angebotspreis_eur":779000,"eur_m2":4482,"vergleichsfaelle":8}\n```');
    await p.evaluate(() => ga35ErgebnisSpeichern()); await p.waitForTimeout(300);
    const lauf = await p.evaluate(() => { const l = ga35Db().laeufe.filter(x => x.art === 'preis').pop(); return { e: l.ergebnis, html: document.querySelector('.ga35-lauf').innerHTML }; });
    ok(lauf.e && lauf.e.central === 735000 && lauf.e.low === 690000 && lauf.e.angebot === 779000 && /Angebotspreis <b>779\.000 €/.test(lauf.html), g + ': Kopierblock zurückgeholt: 690–770 Tsd., wahrscheinlich 735 Tsd., Angebotspreis 779 Tsd.');
    // ── Objektart Reihenendhaus + Shooting-Vorbelegung ──
    await p.evaluate(() => { GA35.obj = 'w2'; ga35Neuzeichnen(); });
    e = await p.evaluate(() => JSON.parse(JSON.stringify(ga35Entwurf('w2'))));
    ok(e.art === 'REH' && await p.evaluate(() => GA40_HAUSTYP.REH === '0.9' && ga40Vorbelegung(ga35Entwurf('w2')).fields.haustyp === '0.9'), g + ': Reihenendhaus erkannt, Shooting-Werkzeug bekommt Haustyp 0,9');
    await p.evaluate(() => { const e = ga35Entwurf('w2'); e.art = 'Grundstueck'; ga35Neuzeichnen(); });
    ok(await p.evaluate(() => { const ids = [...document.querySelectorAll('.ga43-gruppe')].map(d => d.dataset.auf); return !ids.includes('fenster') && ids.includes('flurstuecke') && !document.querySelector('[data-g43="w:wfl"]') && !!document.querySelector('[data-g43="w:grund"]'); }), g + ': Unbebautes Grundstück: Gebäude-Gruppen und Wohnfläche ausgeblendet, Grundstück bleibt');
    // ── Ansicht ──
    if(g === 'handy'){
      await p.evaluate(() => { GA35.obj = 'w1'; ga35Neuzeichnen(); });
      const ov = await p.evaluate(() => { const m = document.getElementById('main'); return [...document.querySelectorAll('.ga43 .ga43-feld, .ga43-chips')].filter(el => el.offsetParent && el.getBoundingClientRect().right > window.innerWidth + 1).length; });
      ok(ov === 0, g + ': keine Felder ragen über den Bildschirmrand (' + ov + ')');
      await p.evaluate(() => document.getElementById('ga43g-fenster').scrollIntoView()); await p.waitForTimeout(200);
      await p.screenshot({ path: '/tmp/v43test/handy_fenster.png' });
      await p.evaluate(() => document.querySelector('.ga43').scrollIntoView()); await p.waitForTimeout(200);
      await p.screenshot({ path: '/tmp/v43test/handy_kern.png' });
    } else {
      await p.evaluate(() => { GA35.obj = 'w1'; ga35Neuzeichnen(); document.querySelector('.ga43').scrollIntoView(); }); await p.waitForTimeout(200);
      await p.screenshot({ path: '/tmp/v43test/pc_kern.png' });
    }
    ok(p.fe.length === 0, g + ': keine Fehler ' + p.fe.join(' | '));
    await p.close();
  }
  await b.close();
  console.log(f ? `${f} FEHLER` : 'ALLES OK'); process.exit(f ? 1 : 0);
})();
