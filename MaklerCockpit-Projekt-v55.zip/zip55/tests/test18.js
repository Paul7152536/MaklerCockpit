// v18: Unterlagen im Akquise-Lead und im Objekt-Fenster
const { chromium } = require('playwright');
let fehler = 0; const ok = (b, t) => { if(!b){ fehler++; console.log('FEHLER:', t); } else console.log('ok  ', t); };
(async () => {
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 1536, height: 1000 }, deviceScaleFactor: 2 });
  const fe = []; p.on('pageerror', e => { fe.push(e.message); console.log('SEITENFEHLER', e.message); });
  await p.addInitScript(() => {
    const alt = { objekte: [
        { id:'x1abcdef', createdAt: Date.now()-5000, akqTitel:'3-Zimmer-Eigentumswohnung mit Balkon', objektart:'Wohnung', ort:'10318 Berlin-Karlshorst', adresse:'Treskowallee 100', kaufpreis:499000, auftragsart:'verkauf', status:'termin', quelle:'ImmoScout', privat:'ja', wohnflaeche:95, zimmer:'3', verlauf:[] },
        { id:'o2zzzzzz', createdAt: Date.now()-9000, adresse:'Lindenweg 5', ort:'14974 Ludwigsfelde', objektart:'EFH', auftragsart:'verkauf', status:'auftrag', kaufpreis:620000, verlauf:[] } ],
      kontakte: [], termine: [], marktanalysen: [], aufgaben: [], notizen: [], mentorFragen: [], meta: { v9neustart: { quittiert: true } } };
    window.__dok = { aufrufe: [], auswahl: [] };
    window.pc = { laden: () => JSON.parse(JSON.stringify(alt)), speichern: (t) => { window.__gespeichert = t; return { ok:true }; }, ordner(){}, sicherungSchreiben: () => ({ ok:true }), sicherungLesen: () => null, zwischenablage: async () => '', abruf: async () => ({ ok:false }),
      dok: async (a, x) => { window.__dok.aufrufe.push([a, x]);
        if(a === 'basis') return { ok:true, basis:'/tmp/v18test/unterlagen' };
        if(a === 'auswaehlen'){ const l = window.__dok.auswahl.shift() || []; return l.length ? { ok:true, dateien: l.map(n => ({ name:n, datei: (n === 'wohnzimmer.jpg' ? 'fake' : x.ordner) + '/' + n, groesse: 245000 })) } : { ok:false, abgebrochen:true }; }
        if(a === 'speichern') return { ok:true, datei: { name:x.name, datei: x.ordner + '/' + x.name, groesse: x.daten.length } };
        if(a === 'loeschen') return { ok:true, papierkorb:true };
        return { ok:true }; } };
  });
  await p.goto('file:///tmp/pc/app/index.html'); await p.waitForTimeout(1500);
  const ev = (f, ...a) => p.evaluate(f, ...a);
  await ev(() => { AQ2.status = 'alle'; AQ2.sel = 'x1abcdef'; wechsleAnsicht('akquise'); }); await p.waitForTimeout(300);
  let s = await ev(() => { const el = document.querySelector('#aqDetail .dok-sek'); return el && { leer: !!el.querySelector('.dok-leer'), check: el.querySelector('.dok-check-k').textContent, chips: [...el.querySelectorAll('.dok-chk')].map(c => c.textContent) }; });
  ok(s && s.leer && /0 von 7/.test(s.check) && s.chips.includes('+ Teilungserklärung') && s.chips.includes('+ WEG-Protokolle'), 'Lead (Wohnung): leerer Unterlagen-Bereich + Check 0 von 7');
  // Datei auswählen
  await ev(() => { window.__dok.auswahl.push(['Energieausweis_2023.pdf', 'Grundbuchauszug Blatt 4711.pdf', 'wohnzimmer.jpg']); return dokHinzu('x1abcdef'); }); await p.waitForTimeout(300);
  s = await ev(() => { const o = findObjekt('x1abcdef'); const el = document.querySelector('#aqDetail .dok-sek'); return { kats: o.dokumente.map(d => d.kat), ordner: o.dokOrdner, check: el.querySelector('.dok-check-k').textContent, zeilen: el.querySelectorAll('.dok-z').length, chip: document.querySelector('[data-dokz="x1abcdef"]').textContent, vl: o.verlauf.slice(-1)[0].text, img: (() => { const i = el.querySelector('.dok-ic img'); return i ? i.naturalWidth : -1; })() }; });
  ok(JSON.stringify(s.kats) === '["energie","grundbuch","foto"]', 'Art automatisch erkannt: ' + s.kats);
  ok(s.ordner === 'Treskowallee 100, Berlin-Karlshorst (abcdef)', 'Eigener Ordner je Objekt: ' + s.ordner);
  ok(s.zeilen === 3 && /2 von 7/.test(s.check) && s.chip === '📎 3' && s.vl === '3 Unterlagen hinzugefügt', 'Liste, Check 2/7, 📎 3 auf der Karte, Verlauf');
  await p.waitForTimeout(400);
  ok((await ev(() => { const i = document.querySelector('#aqDetail .dok-ic img'); return i ? i.naturalWidth : -1; })) === 400, 'Foto-Vorschau wird angezeigt');
  // Fehlende Unterlage über den Check hinzufügen (Art vorgegeben)
  await ev(() => { window.__dok.auswahl.push(['scan_0001.pdf']); return dokHinzu('x1abcdef', 'teilung'); }); await p.waitForTimeout(200);
  ok(await ev(() => findObjekt('x1abcdef').dokumente.slice(-1)[0].kat === 'teilung' && /3 von 7/.test(document.querySelector('#aqDetail .dok-check-k').textContent)), '„+ Teilungserklärung“ legt Scan als Teilungserklärung ab');
  // Drag & Drop
  await ev(async () => { const dt = new DataTransfer(); dt.items.add(new File([new Uint8Array(2048)], 'Grundriss_EG.png', { type:'image/png' })); dt.items.add(new File(['x'], 'Protokoll ETV 2025.pdf')); const el = document.querySelector('#aqDetail .dok-sek'); el.dispatchEvent(new DragEvent('drop', { dataTransfer: dt, bubbles:true, cancelable:true })); });
  await p.waitForTimeout(500);
  s = await ev(() => ({ kats: findObjekt('x1abcdef').dokumente.map(d => d.kat), sp: window.__dok.aufrufe.filter(a => a[0] === 'speichern').map(a => [a[1].name, a[1].daten.length]) }));
  ok(JSON.stringify(s.sp) === '[["Grundriss_EG.png",2048],["Protokoll ETV 2025.pdf",1]]' && s.kats.includes('grundriss') && s.kats.includes('weg'), 'Hineinziehen speichert Dateien (Grundriss, WEG-Protokoll erkannt)');
  await ev(() => { document.querySelector('#aqDetail .dok-sek').scrollIntoView({ block:'center' }); });
  const box = await ev(() => { const r = document.querySelector('#aqDetail .dp').getBoundingClientRect(); return { x:r.x, y:r.y, width:r.width, height:r.height }; });
  await p.screenshot({ path: '/tmp/v18test/1_lead_unterlagen.png', clip: box });
  // Öffnen, Art ändern, Entfernen
  await ev(() => document.querySelector('#aqDetail .dok-z').click()); await p.waitForTimeout(100);
  ok(await ev(() => { const a = window.__dok.aufrufe.filter(x => x[0] === 'oeffnen').slice(-1)[0]; return a && /Grundbuchauszug Blatt 4711\.pdf$/.test(a[1].datei); }), 'Klick öffnet die Datei');
  const did = await ev(() => findObjekt('x1abcdef').dokumente.find(d => d.name === 'scan_0001.pdf').id);
  await ev((id) => { const btn = [...document.querySelectorAll('#aqDetail .dok-z')].find(z => z.textContent.includes('scan_0001')).querySelector('button'); btn.click(); }, did); await p.waitForTimeout(100);
  ok(await ev(() => !!document.querySelector('.dok-menue select')), 'Menü mit Art-Auswahl');
  await ev((id) => dokKatSetzen('x1abcdef', id, 'hausgeld'), did); await p.waitForTimeout(100);
  ok(await ev((id) => findObjekt('x1abcdef').dokumente.find(d => d.id === id).kat === 'hausgeld', did), 'Art geändert');
  await ev((id) => { window.bestaetigeUnten = (t, cb) => cb(); return dokEntfernen('x1abcdef', id); }, did); await p.waitForTimeout(200);
  ok(await ev((id) => !findObjekt('x1abcdef').dokumente.some(d => d.id === id) && window.__dok.aufrufe.some(a => a[0] === 'loeschen'), did), 'Entfernen → Papierkorb + aus Liste');
  // Objekt-Fenster (Haus)
  await ev(() => wechsleAnsicht('objekte')); await p.waitForTimeout(200);
  ok(await ev(() => /📎 5/.test(document.getElementById('main').innerText)), 'Objekte-Liste zeigt 📎 5 beim Lead');
  await ev(() => oeffneObjektModal('o2zzzzzz')); await p.waitForTimeout(200);
  s = await ev(() => { const el = document.querySelector('#modalInner .dok-im-modal .dok-sek'); return el && { chips: [...el.querySelectorAll('.dok-chk')].map(c => c.textContent) }; });
  ok(s && s.chips.length === 7 && s.chips.includes('+ Flurkarte / Lageplan') && s.chips.includes('+ Baulastenauskunft'), 'Objekt-Fenster (Haus): Unterlagen + Check mit Flurkarte, Baulast');
  await ev(() => { window.__dok.auswahl.push(['Flurkarte_Ludwigsfelde.pdf', 'Exposé Lindenweg.pdf']); return dokHinzu('o2zzzzzz'); }); await p.waitForTimeout(200);
  ok(await ev(() => document.querySelectorAll('#modalInner .dok-z').length === 2 && /2 von 7/.test(document.querySelector('#modalInner .dok-check-k').textContent)), 'Im Objekt-Fenster hinzugefügt');
  const mb = await ev(() => { const r = document.querySelector('#modalInner .dok-im-modal').getBoundingClientRect(); const m = document.getElementById('modalInner').getBoundingClientRect(); return { x:m.x, y:Math.max(0, r.y - 20), width:m.width, height:Math.min(r.height + 90, 900) }; });
  await ev(() => document.querySelector('#modalInner .dok-im-modal').scrollIntoView({ block:'center' })); await p.waitForTimeout(100);
  const mb2 = await ev(() => { const r = document.querySelector('#modalInner .dok-im-modal').getBoundingClientRect(); const m = document.getElementById('modalInner').getBoundingClientRect(); return { x:m.x, y:Math.max(0, r.y - 20), width:m.width, height:Math.min(r.height + 90, 960 - Math.max(0, r.y - 20)) }; });
  await p.screenshot({ path: '/tmp/v18test/2_objekt_fenster.png', clip: mb2 });
  await ev(() => speichereObjekt('o2zzzzzz')); await p.waitForTimeout(400);
  ok(await ev(() => findObjekt('o2zzzzzz').dokumente.length === 2 && /dokumente/.test(window.__gespeichert || '')), 'Objekt speichern behält die Unterlagen');
  await ev(() => oeffneObjektModal()); await p.waitForTimeout(100);
  ok(await ev(() => /sobald das Objekt gespeichert ist/.test(document.querySelector('#modalInner .dok-im-modal').textContent)), 'Neues Objekt: Hinweis „erst speichern“');
  await ev(() => schliesseModal());
  ok(fe.length === 0, 'Keine Seitenfehler');
  console.log('\nFEHLER', fehler); await b.close(); process.exit(fehler ? 1 : 0);
})();
