// v37: Mietpotenzial + Mietdaten-Auffrischung (Jarvis)
const { chromium } = require('playwright');
let f = 0; const ok = (b, t) => { console.log((b ? 'ok   ' : 'FEHL ') + t); if(!b) f++; };
const D = JSON.stringify({ objekte: [
  { id: 'o1', akqTitel: 'ETW Lichtenberg', objektart: 'Wohnung', status: 'neu', ort: '10365 Berlin', adresse: 'Musterstr. 5, 10365 Berlin', wohnflaeche: 68, baujahr: 1965, kaufpreis: 280000, verlauf: [], mv25: { wohnlage: 'mittel' } },
  { id: 'o2', akqTitel: 'Neubau Mitte', objektart: 'Wohnung', status: 'neu', ort: '10115 Berlin', adresse: 'Neustr. 1, 10115 Berlin', wohnflaeche: 80, baujahr: 2019, verlauf: [] },
  { id: 'o3', akqTitel: 'EFH Falkensee', objektart: 'Einfamilienhaus', status: 'neu', ort: '14612 Falkensee', adresse: 'Weg 2, 14612 Falkensee', wohnflaeche: 140, baujahr: 1998, verlauf: [] },
  { id: 'o4', akqTitel: 'MFH-Whg vermietet', objektart: 'Wohnung', status: 'neu', ort: '12043 Berlin', adresse: 'Karl-Marx-Str. 10, 12043 Berlin', wohnflaeche: 60, baujahr: 1910, miete_ist: 420, vermietung: 'vermietet', verlauf: [], mv25: { wohnlage: 'mittel' } }
], kontakte: [], termine: [], aufgaben: [], notizen: [], meta: { v9neustart: { quittiert: true } } });
async function seite(b, g, w, h){
  const p = await b.newPage({ viewport: { width: w, height: h }, isMobile: g === 'handy', hasTouch: g === 'handy' });
  p.fe = []; p.on('pageerror', e => p.fe.push(e.message)); p.on('dialog', d => d.dismiss());
  await p.addInitScript(([d, g]) => { window.pc = { geraet: g, laden: () => JSON.parse(d), speichern: () => ({ ok: true }), ordner(){}, sicherungSchreiben: () => ({ ok: true }), sicherungLesen: () => null, gekoppelt: () => true, google: async () => ({ ok: false }) }; navigator.clipboard.writeText = async t => { window.__kopie = t; }; }, [D, g]);
  await p.goto('file:///tmp/pc/app/index.html'); await p.waitForTimeout(2200);
  await p.evaluate(() => { try{ schliesseModal(); }catch(e){} }); await p.waitForTimeout(300);
  return p;
}
(async () => {
  const b = await chromium.launch();
  let p = await seite(b, 'pc', 1440, 900);
  // 1) Rechnen Bestand Lichtenberg
  let r = await p.evaluate(() => { const x = mp37Rechnen(findObjekt('o1'), null); return { land: x.lage.land, bez: x.lage.bezirk, ovm: x.ovm, ms: !!x.ms, bremse: x.bremse, grenze: x.grenzeBremse, unten: x.markt.unten, med: x.markt.median, oben: x.markt.oben, von: x.von, bis: x.bis, fl: x.fl, wistg: x.wistg }; });
  console.log(JSON.stringify(r));
  ok(r.land === 'BE' && r.bez === 'Lichtenberg' && r.ms && r.ovm > 5 && r.ovm < 15, `Lichtenberg: Mietspiegel-Vergleichsmiete ${r.ovm && r.ovm.toFixed(2)} €/m²`);
  ok(r.bremse && Math.abs(r.grenze - r.ovm * 1.1) < 0.001 && Math.abs(r.wistg - r.ovm * 1.2) < 0.001, 'Mietpreisbremse: Grenze = Vergleichsmiete +10 %, Bußgeldgrenze +20 %');
  ok(r.unten < r.med && r.med < r.oben, `Markt niedrigste < Ø < höchste (${r.unten} / ${r.med} / ${r.oben})`);
  ok(r.von === r.ovm && Math.abs(r.bis - r.grenze) < 0.001, 'Inserat-Spanne: Vergleichsmiete bis zulässige Obergrenze');
  // Ausstattung +5 → höher
  r = await p.evaluate(() => { const a = mp37Rechnen(findObjekt('o1'), null).ovm; mp37Setzen('o1', 'saldo', 5); const b2 = mp37Rechnen(findObjekt('o1'), null).ovm; mp37Setzen('o1', 'saldo', 0); return [a, b2]; });
  ok(r[1] > r[0], `Ausstattung +5 erhöht die Vergleichsmiete (${r[0].toFixed(2)} → ${r[1].toFixed(2)})`);
  // Vormiete höher → Bestandsschutz
  r = await p.evaluate(() => { mp37Setzen('o1', 'vormiete', 1200); const x = mp37Rechnen(findObjekt('o1'), null); mp37Setzen('o1', 'vormiete', ''); return { g: x.grenzeBremse, v: 1200 / 68, h: x.hinweise.join(' ') }; });
  ok(Math.abs(r.g - r.v) < 0.01 && /Vormiete/.test(r.h), 'Höhere Vormiete wird zur Obergrenze (Bestandsschutz)');
  // 2) Neubau → Ausnahme
  r = await p.evaluate(() => { const x = mp37Rechnen(findObjekt('o2'), null); return { bremse: x.bremse, aus: x.ausnahme, ms: !!x.ms, ovm: x.ovm, real: x.realistisch, med: x.markt.median }; });
  ok(!r.bremse && /Neubau/.test(r.aus), 'Baujahr 2019: Neubau-Ausnahme, keine Bremse');
  ok(r.real != null && r.real === r.med || r.real <= r.med, `Neubau: realistische Miete ${r.real} (Markt ${r.med})`);
  // 3) EFH Falkensee → Brandenburg, Bremse-Gemeinde, kein Mietspiegel
  r = await p.evaluate(() => { const x = mp37Rechnen(findObjekt('o3'), null); return { land: x.lage.land, bremseGebiet: x.bremseGebiet, ms: !!x.ms, fehl: x.msFehler, h: x.hinweise.join(' '), med: x.markt.median }; });
  console.log(JSON.stringify(r));
  ok(r.land === 'BB' && r.bremseGebiet && !r.ms, 'Falkensee: Brandenburg, Mietpreisbremse-Gemeinde, kein Mietspiegel');
  ok(/Vergleichsmiete/.test(r.h) && /Häuser/.test(r.h), 'EFH: Hinweise (Vergleichsmiete von Hand, Angebotsmieten nur grob)');
  r = await p.evaluate(() => { mp37Setzen('o3', 'ovmManuell', 11); const x = mp37Rechnen(findObjekt('o3'), null); return { ovm: x.ovm, g: x.grenzeBremse }; });
  ok(r.ovm === 11 && Math.abs(r.g - 12.1) < 0.001, 'Vergleichsmiete von Hand → Obergrenze 12,10 €/m²');
  // 4) vermietet → Ist-Miete und Erhöhung
  r = await p.evaluate(() => { an24Setzen(findObjekt('o4'), 'miete_ist', { wert: 420, herkunft: 'eigentuemer' }, { aktivieren: true }); const x = mp37Rechnen(findObjekt('o4'), null); return { ist: x.istQm, erh: x.erh, ovm: x.ovm, t: mp37Texte(x).kurz }; });
  console.log('   ' + r.t);
  ok(r.ist === 7 && r.erh && r.erh.ziel <= r.ovm * 60 + 0.01 && r.erh.prozent === 15, `Vermietet: 7,00 €/m², Erhöhung bis ${r.erh && r.erh.ziel.toFixed(2)} (Kappung 15 %)`);
  // 5) Texte
  r = await p.evaluate(() => mp37Texte(mp37Rechnen(findObjekt('o1'), null)));
  ok(/Bei Neuvermietung wird/.test(r.kurz) && /keine Zusicherung/.test(r.kurz) && /€\/m²/.test(r.kurz), 'Kurztext fürs Inserat mit Spanne und Vorbehalt');
  ok(!/Musterstr/.test(r.kurz + r.lang), 'Inserattext ohne genaue Adresse');
  console.log('   ' + r.kurz);
  // 6) Marktanalyse: Karte im Ergebnis + Bericht
  r = await p.evaluate(() => { const a = ma24Anlegen('o1', 'sale', true); MA24.sel = a.id; MA24.schritt = 'ergebnis'; wechsleAnsicht('marktanalyse24'); return a.id; });
  await p.waitForTimeout(600);
  r = await p.evaluate(() => { const k = document.querySelector('.mp37'); return k ? { rows: k.querySelectorAll('.mp37-tab tr').length, t: k.innerText.slice(0, 2000) } : null; });
  ok(r && r.rows >= 8 && /Vergleichsangebote/.test(r.t) && /Höchste zulässige/.test(r.t) && /Median/.test(r.t), 'Marktanalyse → Ergebnis zeigt Mietpotenzial-Karte (' + (r && r.rows) + ' Zeilen)');
  await p.click('.mp37 button:has-text("Text fürs Inserat")'); await p.waitForTimeout(300);
  ok(await p.evaluate(() => /Neuvermietung/.test(window.__kopie || document.querySelector('#akqToast') && document.querySelector('#akqToast').textContent)), 'Knopf „Text fürs Inserat“ kopiert');
  r = await p.evaluate(() => ma24BerichtHtmlFuer(ma24A()));
  ok(/<h2>Mietpotenzial und Ertrag<\/h2>/.test(r) && !/Musterstr/.test(r), 'Eigentümerbericht enthält Abschnitt Mietpotenzial (ohne Adresse)');
  r = await p.evaluate(() => { mp37BerichtSetzen(false); return /Mietpotenzial und Ertrag<\/h2>/.test(ma24BerichtHtmlFuer(ma24A())); });
  ok(!r, 'Abschnitt im Bericht abschaltbar');
  // Auswahl in der Karte ändern (Ausstattung)
  await p.selectOption('.mp37 .mp37-ein select >> nth=1', '3'); await p.waitForTimeout(400);
  ok(await p.evaluate(() => findObjekt('o1').miete37.saldo === 3 && !!document.querySelector('.mp37')), 'Ausstattung in der Karte wählbar, Karte neu gezeichnet');
  // 7) Objekt-Akte: Knopf + Modal
  r = await p.evaluate(() => { mp37FuerObjekt('o2'); return !!document.querySelector('#mp37Modal .mp37'); });
  ok(r, 'Mietpotenzial aus dem Objekt als Fenster');
  await p.evaluate(() => mp37Setzen('o2', 'moebliert', true)); await p.waitForTimeout(200);
  ok(await p.evaluate(() => !!document.querySelector('#mp37Modal') && /möbliert/i.test(document.querySelector('#mp37Modal').innerText)), 'Im Fenster: Änderung zeichnet das Fenster neu (möbliert-Hinweis)');
  await p.evaluate(() => schliesseModal());
  // 8) Glocke + Prompt
  r = await p.evaluate(() => tbHinweise().map(h => h.k));
  ok(r.includes('mp37'), 'Glocke: Mietdaten auffrischen fällig (noch nie)');
  r = await p.evaluate(() => mp37Prompt('Bernau'));
  ok(/JARVIS-IMPORT typ=mieten/.test(r) && /Lichtenberg/.test(r) && /Falkensee/.test(r) && /Bernau/.test(r) && /AUSGABE ZUM KOPIEREN/.test(r) && /Mietendeckel/.test(r), 'Prompt: alle Gebiete, Rechtslage, Kopierblock');
  ok(!/rodolapa|Musterstr/.test(r), 'Prompt ohne private Daten');
  // 9) Import
  const imp = `Hier die Daten:\n\`\`\`\nJARVIS-IMPORT typ=mieten\n{"art":"meta","stand":"2026-11-14","zusammenfassung":"Mieten leicht gestiegen."}\n{"art":"gebiet","gebiet":"Berlin","median":15.9,"unten":7.2,"oben":29,"zeitraum":"Q3 2026","quelle":"Test-Quelle","url":"https://example.org/a","datum":"2026-11-01"}\n{"art":"gebiet","gebiet":"Lichtenberg","median":16.9,"unten":9.1,"oben":24.5,"neubau":19.5,"zeitraum":"Q3 2026","quelle":"Test-Quelle","url":"javascript:alert(1)","datum":"2026-11-01"}\n{"art":"gebiet","gebiet":"Falkensee","median":12.4,"unten":9,"oben":15.5,"zeitraum":"Q3 2026","quelle":"Test"}\n{"art":"gebiet","gebiet":"Spandau","median":300}\n{"art":"recht","thema":"Mietrecht II","stand":"Im Bundestag beschlossen <b>","geaendert":true,"wichtig_fuer_neuvermietung":"Möblierungszuschlag ausweisen","url":"https://example.org/r"}\nJARVIS-ENDE\n\`\`\``;
  r = await p.evaluate(t => mp37ImportText(t), imp);
  console.log('   ' + r);
  ok(/3 Gebiete/.test(r) && /1 Rechtspunkt/.test(r) && /übersprungen/.test(r), 'Import: 3 Gebiete, 1 Rechtspunkt, ungültiger Wert übersprungen');
  r = await p.evaluate(() => { const m = db.mieten37; return { li: m.gebiete.be_li || m.gebiete[Object.keys(m.gebiete).find(k => /li/.test(k))], keys: Object.keys(m.gebiete), stand: m.stand, recht: m.recht[0] }; });
  console.log(JSON.stringify(r.keys));
  ok(r.li && r.li.median === 16.9 && r.li.url === '', 'Lichtenberg gespeichert, unsicherer Link verworfen');
  ok(!/[<>]/.test(r.recht.stand), 'Rechtstext ohne HTML');
  r = await p.evaluate(() => { const x = mp37Rechnen(findObjekt('o1'), null); return { med: x.markt.median, u: x.markt.unten, q: x.markt.quelle, mv: mv25Jarvis('be_li') }; });
  ok(r.med === 16.9 && r.u === 9.1 && r.q === 'Test-Quelle', 'Mietpotenzial nutzt die aufgefrischten Werte');
  ok(r.mv && r.mv.m === 16.9, 'Mietvergleich (v25) nutzt die aufgefrischten Werte ebenfalls');
  r = await p.evaluate(() => mp37Rechnen(findObjekt('o3'), null).markt.median);
  ok(r === 12.4, 'Falkensee aufgefrischt: ' + r);
  r = await p.evaluate(() => tbHinweise().map(h => h.k));
  ok(!r.includes('mp37') && r.includes('mp37r'), 'Glocke: Auffrischung erledigt, Rechtsänderung gemeldet');
  r = await p.evaluate(() => { db.mieten37.importiert = Date.now() - 15 * 864e5; return tbHinweise().map(h => h.k).includes('mp37'); });
  ok(r, 'Nach 15 Tagen wieder fällig');
  // Dialog
  await p.evaluate(() => mp37Dialog()); await p.waitForTimeout(300);
  ok(await p.evaluate(() => !!document.getElementById('mp37Text')), 'Dialog „Mietdaten auffrischen“ öffnet');
  await p.evaluate(() => schliesseModal());
  // 10) Jarvis
  await p.evaluate(() => wechsleAnsicht('jarvis')); await p.waitForTimeout(1500);
  const fr = await (await p.$('#jvFrame')).contentFrame();
  r = await fr.evaluate(() => { try{ return { titel: TITEL.mieten, plan: PLAN_STANDARD.mieten, info: !!PROMPT_INFO.mieten, prompt: promptErzeugen('mieten', ''), faellig: faelligeSuchen().map(x => x.typ) }; }catch(e){ return { err: e.message }; } });
  ok(r.titel && r.plan && r.plan.alle === 2 && r.info, 'Jarvis: Typ „Mieten & Mietrecht auffrischen“, alle 2 Wochen');
  ok(/JARVIS-IMPORT typ=mieten/.test(r.prompt || ''), 'Jarvis: Prompt kommt aus dem Cockpit');
  await fr.evaluate(() => tab('suchen'));
  await p.waitForTimeout(500);
  r = await fr.evaluate(() => !!document.getElementById('pz_mieten'));
  ok(r, 'Jarvis „Suchen“: Karte mit Prompt-Knopf vorhanden');
  r = await fr.evaluate(t => einlesen(t), imp.replace('16.9', '17.3').replace('2026-11-14', '2026-11-15'));
  ok(/Gebiete aktualisiert/.test(r), 'Jarvis-Import „typ=mieten“ landet im Cockpit: ' + r.slice(0, 80));
  ok(await p.evaluate(() => db.mieten37.gebiete.be_li.median === 17.3), 'Wert aus Jarvis-Import übernommen');
  r = await fr.evaluate(() => (S.plan_status || {}).mieten);
  ok(!!r, 'Jarvis-Plan: Mieten als erledigt markiert');
  ok(p.fe.length === 0, 'PC: keine Fehler ' + p.fe.join(' | '));
  await p.close();
  // 11) Handy: Karte lesbar
  p = await seite(b, 'handy', 412, 915);
  await p.evaluate(() => { const a = ma24Anlegen('o1', 'rent', true); MA24.sel = a.id; MA24.schritt = 'ergebnis'; wechsleAnsicht('marktanalyse24'); }); await p.waitForTimeout(700);
  r = await p.evaluate(() => { const k = document.querySelector('.mp37'); if(!k) return null; return { w: k.getBoundingClientRect().width, sw: k.scrollWidth, vw: innerWidth }; });
  ok(r && r.w <= r.vw && r.sw <= r.w + 2, 'Handy: Karte passt in die Breite ' + JSON.stringify(r));
  ok(p.fe.length === 0, 'Handy: keine Fehler ' + p.fe.join(' | '));
  await b.close(); console.log('FEHLER', f);
})();
