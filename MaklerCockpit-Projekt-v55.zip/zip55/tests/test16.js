// v16: Exposé-Link (Prompt, Parser, Lead-Karte, Detail), Kaufpreis nicht als Monatsmiete
const { chromium } = require('playwright');
let fehler = 0; const ok = (b, t) => { if(!b){ fehler++; console.log('FEHLER:', t); } else console.log('ok  ', t); };
(async () => {
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 1536, height: 1000 }, deviceScaleFactor: 2 });
  const fe = []; p.on('pageerror', e => { fe.push(e.message); console.log('SEITENFEHLER', e.message); });
  await p.addInitScript(() => {
    const alt = { objekte: [
        { id:'alt1', createdAt: Date.now()-5000, akqTitel:'Stilvolle, gepflegte 3-Zimmer-Wohnung mit Balkon - direkt vom Eigentümer', objektart:'ETW', ort:'10318 Berlin-Karlshorst', kaufpreis:499000, auftragsart:'vermietung', status:'neu', quelle:'ImmoScout', privat:'ja', wohnflaeche:95, zimmer:'3', verlauf:[] },
        { id:'alt2', createdAt: Date.now()-9000, akqTitel:'Bezugsfreie 2-Zi.-Neubauwohnung (Bj. 2021)', objektart:'ETW', ort:'10315 Berlin-Lichtenberg', kaufpreis:299000, auftragsart:'verkauf', status:'neu', quelle:'Direktakquise', privat:'ja', wohnflaeche:48, zimmer:'2', verlauf:[] } ],
      kontakte: [], termine: [], marktanalysen: [], aufgaben: [], notizen: [], mentorFragen: [], meta: { v9neustart: { quittiert: true } } };
    window.__geoeffnet = [];
    window.open = (u) => { window.__geoeffnet.push(u); return null; };
    window.pc = { laden: () => JSON.parse(JSON.stringify(alt)), speichern: () => ({ ok:true }), ordner(){}, sicherungSchreiben: () => ({ ok:true }), sicherungLesen: () => null, zwischenablage: async () => '', abruf: async () => ({ ok:false }) };
  });
  await p.goto('file:///tmp/pc/app/index.html'); await p.waitForTimeout(1500);
  const ev = (f, ...a) => p.evaluate(f, ...a);

  // ── Prompts ──
  const pr = await ev(() => ({ portale: AKQ_PROMPTS.find(x=>x.key==='portale').prompt(akqDb().einst), ka: AKQ_PROMPTS.find(x=>x.key==='kleinanzeigen').prompt(akqDb().einst), zeitung: AKQ_PROMPTS.find(x=>x.key==='zeitung').prompt(akqDb().einst) }));
  ok(/LINK-REGEL/.test(pr.portale) && /Link = PFLICHT: direkter Link zum Exposé/.test(pr.portale) && /immobilienscout24\.de\/expose/.test(pr.portale), 'Portale-Prompt: Exposé-Link Pflicht');
  ok(/Link = PFLICHT: direkter Link zur einzelnen Anzeige/.test(pr.ka), 'Kleinanzeigen-Prompt: Link Pflicht');
  ok(/Webadresse oder ein Online-Code/.test(pr.zeitung) && /LINK-REGEL/.test(pr.zeitung), 'Zeitungs-Prompt: Link wenn vorhanden');

  // ── Parser ──
  const text = `1.
Name: Nicht angegeben
Objekt: 3-Zimmer-Eigentumswohnung mit Balkon
Lage: 10318 Berlin-Karlshorst
Preis: 499.000 €
Telefon: Nicht angegeben
E-Mail: Nicht angegeben
Eingestellt am: 09.11.2026
Privat eindeutig: 🟢 Ja – Privatanbieter
Details: 95 m², 3 Zimmer, Hausgeld 380 € mtl., vermietet für 900 € Miete
Quelle: ImmoScout24
Seite: Nicht angegeben
Link: https://www.immobilienscout24.de/expose/159012345.
Status: Privatangebot ohne Kontaktdaten

2.
Objekt: Reihenhaus
Lage: Teltow
Preis: VB 420.000 €
Link: [Exposé ansehen](https://www.immowelt.de/expose/2abc3de)
Privat eindeutig: 🟢 Ja

3.
Objekt: Baugrundstück 800 m²
Lage: Mahlow
Preis: 210.000 €
Exposé: <https://www.kleinanzeigen.de/s-anzeige/baugrundstueck-mahlow/2912345678-208-3398>

4.
Objekt: Einfamilienhaus
Lage: Falkensee
Preis: 549.000 €
Link: Nicht angegeben
Details: Gefunden über https://www.immobilienscout24.de/Suche/de/brandenburg/haus-kaufen?sorting=2 – Inserat https://www.immobilienscout24.de/expose/155555555

5.
Objekt: 2-Zimmer-Mietwohnung
Lage: Berlin-Friedrichshain
Preis: 850 € kalt
Telefon: 0170 1234567

6.
Objekt: Doppelhaushälfte
Lage: Zeuthen
Preis: 610.000 €
Telefon: 0171 7654321
Link: Nicht angegeben

Gesamt: 6 Anzeigen`;
  const e = await ev((t) => akqLesen(t).eintraege.map(x => ({ titel:x.titel, link:x.link, quelle:x.quelle, auftrag:x.auftragsart, preis:x.preis })), text);
  ok(e.length === 6, '6 Anzeigen erkannt');
  ok(e[0].link === 'https://www.immobilienscout24.de/expose/159012345' && e[0].quelle === 'ImmoScout', 'Link erkannt, Punkt am Ende entfernt: ' + e[0].link);
  ok(e[0].auftrag === 'verkauf', 'ETW mit „Hausgeld mtl.“ und Mieteinnahme bleibt Verkauf (kein „/ Monat“)');
  ok(e[1].link === 'https://www.immowelt.de/expose/2abc3de', 'Markdown-Link [Text](URL) erkannt');
  ok(e[2].link === 'https://www.kleinanzeigen.de/s-anzeige/baugrundstueck-mahlow/2912345678-208-3398' && e[2].quelle === 'Kleinanzeigen', '„Exposé: <URL>“ erkannt');
  ok(e[3].link === 'https://www.immobilienscout24.de/expose/155555555', 'Ohne Link-Zeile: Exposé aus dem Text, Suchseite übergangen');
  ok(e[4].auftrag === 'vermietung', 'Echte Mietwohnung (850 € kalt) bleibt Vermietung');
  ok(e[5].link === '', 'Ohne Link: leer');

  // ── Übernehmen + Ansicht ──
  await ev((t) => akqUebernehmen(akqLesen(t).eintraege, 'test'), text);
  await ev(() => { AQ2.status = 'alle'; wechsleAnsicht('akquise'); }); await p.waitForTimeout(300);
  const mig = await ev(() => ({ a: findObjekt('alt1').auftragsart }));
  ok(mig.a === 'verkauf', 'Alter Lead: Kaufpreis nicht mehr als Miete');
  const k = await ev(() => { const o = db.objekte.find(x => x.link === 'https://www.immobilienscout24.de/expose/159012345'); const c = document.getElementById('lc-' + o.id); return { id:o.id, chip: !!c.querySelector('.lc-expose'), text: c.querySelector('.lc-expose') && c.querySelector('.lc-expose').textContent }; });
  ok(k.chip && /Exposé öffnen/.test(k.text), 'Lead-Karte ohne Telefon: Knopf „Exposé öffnen“');
  await ev((id) => document.querySelector('#lc-' + id + ' .lc-expose').click(), k.id);
  ok((await ev(() => window.__geoeffnet.slice(-1)[0])) === 'https://www.immobilienscout24.de/expose/159012345', 'Klick öffnet das Exposé (ohne den Lead zu wechseln)');
  const tz = await ev(() => { const o = db.objekte.find(x => x.verkaeuferTelefon === '0171 7654321'); return document.getElementById('lc-' + o.id).querySelector('.tel').textContent; });
  ok(/0171 7654321/.test(tz), 'Mit Telefon: weiterhin Nummer');
  await ev((id) => aq2Waehlen(id), k.id); await p.waitForTimeout(150);
  const d = await ev(() => ({ txt: document.getElementById('aqDetail').innerText, erster: document.querySelector('.dp-aktionen button').textContent, hinweis: !!document.querySelector('.dp-hinweis-expose') }));
  ok(/Exposé öffnen/.test(d.txt) && /immobilienscout24\.de/.test(d.txt) && /Exposé/.test(d.erster) && d.hinweis, 'Detail: Exposé in den Kontaktdaten, Hinweis, Aktion „Exposé“ statt Anrufen');
  await p.screenshot({ path: '/tmp/v16test/1_akquise_expose.png' });
  // Lead ohne Link: Link nachtragen
  await ev(() => aq2Waehlen('alt2')); await p.waitForTimeout(100);
  ok(await ev(() => !!document.getElementById('dpLink') && /füg oben den Link/.test(document.querySelector('.dp-hinweis-expose').textContent)), 'Ohne Link: Eingabefeld + Hinweis');
  const box = await ev(() => { const r = document.querySelector('#aqDetail .dp').getBoundingClientRect(); return { x:r.x, y:r.y, width:r.width, height:Math.min(r.height, 900) }; });
  await p.screenshot({ path: '/tmp/v16test/2_detail_ohne_link.png', clip: box });
  await ev(() => aq2LinkSetzen('kaputt')); 
  ok(await ev(() => !findObjekt('alt2').link), 'Ungültiger Link wird abgelehnt');
  await ev(() => aq2LinkSetzen('https://www.immobilienscout24.de/expose/160000001')); await p.waitForTimeout(100);
  const l2 = await ev(() => { const o = findObjekt('alt2'); return { link:o.link, quelle:o.quelle, vl:o.verlauf.slice(-1)[0].text, chip: !!document.querySelector('#lc-alt2 .lc-expose') }; });
  ok(l2.link === 'https://www.immobilienscout24.de/expose/160000001' && l2.quelle === 'ImmoScout' && /Exposé-Link hinzugefügt/.test(l2.vl) && l2.chip, 'Link nachgetragen: Quelle, Verlauf, Karte aktualisiert');
  // Link per Strg+V einfügen
  const ohne = await ev(() => db.objekte.find(x => x.verkaeuferTelefon === '0171 7654321').id);
  await ev((id) => { aq2Waehlen(id); const dt = new DataTransfer(); dt.setData('text/plain', 'https://www.immowelt.de/expose/zz99'); document.dispatchEvent(new ClipboardEvent('paste', { clipboardData: dt, bubbles: true })); }, ohne);
  await p.waitForTimeout(100);
  ok((await ev((id) => findObjekt(id).link, ohne)) === 'https://www.immowelt.de/expose/zz99', 'Strg+V mit einem Link setzt ihn beim gewählten Lead');
  // Bearbeiten-Stift
  await ev(() => { AQ2.linkEdit = true; aq2Detail(); });
  ok(await ev(() => document.getElementById('dpLink').value === 'https://www.immowelt.de/expose/zz99'), 'Stift öffnet Feld mit vorhandenem Link');
  await ev(() => aq2Waehlen('alt1')); await p.waitForTimeout(100);
  ok(await ev(() => !/Monat/.test(document.querySelector('#aqDetail .preis').textContent)), 'Detail: 499.000 € ohne „/ Monat“');
  ok(await ev(() => { const o = db.objekte.find(x => x.ort === 'Falkensee'); return !o.verkaeuferTelefon && !aqTel(o); }), 'Nummer aus dem Exposé-Link wird nicht als Telefon gelesen');
  await ev(async () => { window.pc.zwischenablage = async () => '1.\nObjekt: Haus\nLage: Teltow\nPreis: 300.000 €\nTelefon: 0170 1\nE-Mail: a@b.de\nPrivat eindeutig: Ja\n'; await jvZwischenablagePruefen(); window.dispatchEvent(new Event('focus')); });
  await p.waitForTimeout(400);
  ok(await ev(() => !document.getElementById('jvClipBanner')), 'Kein automatisches „KI-Ergebnis erkannt“-Banner mehr');
  ok(fe.length === 0, 'Keine Seitenfehler');
  console.log('\nFEHLER', fehler); await b.close(); process.exit(fehler ? 1 : 0);
})();
