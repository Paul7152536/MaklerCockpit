// v14: Google-Kalender-Abgleich + Termine am Lead (mit nachgebautem Google)
const { chromium } = require('playwright');
const fs = require('fs');
let fehler = 0; const ok = (b, t) => { if(!b){ fehler++; console.log('FEHLER:', t); } else console.log('ok  ', t); };
(async () => {
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 1536, height: 1000 }, deviceScaleFactor: 2 });
  const fe = []; p.on('pageerror', e => { fe.push(e.message); console.log('SEITENFEHLER', e.message); });
  let dialogAntwort = 'accept'; const dialoge = [];
  p.on('dialog', d => { dialoge.push(d.message()); dialogAntwort === 'accept' ? d.accept() : d.dismiss(); });
  await p.addInitScript({ path: '/tmp/v15test/fake_google.js' });
  await p.addInitScript(() => {
    const T = window.__G.tag;
    const alt = { objekte: [{ id:'x1', createdAt: Date.now()-864e5, akqTitel:'Einfamilienhaus mit Garten', objektart:'EFH', adresse:'Lindenweg 5', ort:'14974 Ludwigsfelde', kaufpreis:489000, status:'erstkontakt', statusAm: Date.now()-3600e3, quelle:'Kleinanzeigen', privat:'ja', verkaeuferName:'Frau Weber', verkaeuferTelefon:'0171 2345678', link:'https://www.kleinanzeigen.de/s-anzeige/efh-ludwigsfelde/123', verlauf:[{ts:Date.now()-864e5, typ:'import', text:'Aus Kleinanzeigen übernommen'}] },
        { id:'x2', createdAt: Date.now()-2*864e5, akqTitel:'Baugrundstück 1.000 m²', objektart:'Grundstück', ort:'Mahlow', status:'neu', quelle:'Zeitung', privat:'ja', verkaeuferEmail:'frawewa@mail.de', verlauf:[] }],
      kontakte: [], marktanalysen: [], aufgaben: [], notizen: [], mentorFragen: [], meta: { v9neustart: { quittiert: true } },
      termine: [
        { id:'t1', createdAt: 1, titel:'Besichtigung: Einfamilienhaus mit Garten (Ludwigsfelde)', datum: T(2), uhrzeit:'10:00', art:'besichtigung', objektId:'x1', notiz:'Exposé mitnehmen' },
        { id:'tAlt', createdAt: 1, titel:'Alter Termin', datum: T(-60), uhrzeit:'09:00', art:'termin' },
        { id:'tSame', createdAt: 1, titel:'Notar Termin Kaufvertrag', datum: T(3), uhrzeit:'14:00', art:'eigene', artEigene:'Notar', notiz:'Ausweis mitnehmen' },
        { id:'tLeer', createdAt: 1, titel:'Ohne Datum', datum:'', uhrzeit:'' }
      ] };
    const G = window.__G;
    G.neu({ id:'eHandy1', summary:'Zahnarzt', start:{ dateTime: T(1)+'T09:30:00' }, end:{ dateTime: T(1)+'T10:00:00' } });
    G.neu({ id:'eGanz', summary:'Urlaub Ostsee', start:{ date: T(5) }, end:{ date: T(8) }, colorId:'7' });
    G.neu({ id:'eSame', summary:'Notar-Termin Kaufvertrag', start:{ dateTime: T(3)+'T14:00:00' }, end:{ dateTime: T(3)+'T15:00:00' }, location:'Notariat Mitte' });
    G.neu({ id:'eWork', summary:'Büro', eventType:'workingLocation', start:{ date: T(1) }, end:{ date: T(2) } });
    G.neu({ id:'eWeg', summary:'Abgesagt', status:'cancelled', start:{ dateTime: T(4)+'T08:00:00' }, end:{ dateTime: T(4)+'T09:00:00' } });
    G.neu({ id:'eWeit', summary:'Eigentümerversammlung', start:{ dateTime: T(200)+'T18:00:00' }, end:{ dateTime: T(200)+'T20:00:00' }, description:'<b>TOP 3</b>: Dach<br>Bitte Vollmacht' });
    G.neu({ id:'eAlt', summary:'Ganz alt', start:{ dateTime: T(-100)+'T18:00:00' }, end:{ dateTime: T(-100)+'T19:00:00' } });
    window.__gespeichert = null;
    window.pc = { laden: () => JSON.parse(JSON.stringify(alt)), speichern: (t) => { window.__gespeichert = t; return { ok:true }; }, ordner(){}, sicherungSchreiben: () => ({ ok:true }), sicherungLesen: () => null,
      zwischenablage: async () => '', abruf: async () => ({ ok:false }), google: (a, x) => window.__googleStub(a, x) };
  });
  await p.goto('file:///tmp/pc/app/index.html'); await p.waitForTimeout(2200);
  const ev = (f, ...a) => p.evaluate(f, ...a);
  const G = (f) => p.evaluate(f);

  // ── 1) Noch nicht verbunden: Einladung auf der Termine-Seite ──
  await ev(() => wechsleAnsicht('termine')); await p.waitForTimeout(200);
  ok(await ev(() => !!document.querySelector('.gs-leiste.einladung')), 'Termine-Seite zeigt „Mit Google Kalender verbinden“');
  await p.screenshot({ path: '/tmp/v15test/1_termine_nicht_verbunden.png' });
  ok(await ev(() => TERMIN_ARTEN.some(a => a[0]==='rueckruf') && TERMIN_ARTEN.some(a => a[0]==='termin')), 'Terminarten erweitert');

  // ── 2) Einrichtung über eigenes Google-Skript (v15) ──
  await ev(() => gsAssistent()); await p.waitForTimeout(300);
  const an = await ev(() => ({ n: document.querySelectorAll('.gs-schritte li').length, code: document.querySelector('.gs-code pre').textContent, url: !!document.getElementById('gsUrl'), cloud: !!document.querySelector('.gs-details') }));
  ok(an.n === 6 && an.url && an.cloud, 'Skript-Anleitung: 6 Schritte, URL-Feld, Cloud-Weg als Alternative');
  ok(/MaklerCockpit – (Kalender|Google)-Brücke/.test(an.code) && /TESTSCHLUESSEL-123456789/.test(an.code), 'Code-Vorschau mit eigenem Schlüssel');
  ok(await ev(() => GS.skriptCode.includes("const SCHLUESSEL = 'TESTSCHLUESSEL-123456789';") && GS.skriptCode.includes('function doPost(e)') && !GS.skriptCode.includes('%%')), 'Vollständiger Code zum Kopieren');
  await p.context().grantPermissions(['clipboard-read','clipboard-write']);
  await ev(() => gsCodeKopieren()); await p.waitForTimeout(150);
  ok((await ev(() => navigator.clipboard.readText())).includes('function abruf_('), 'Code-kopieren-Knopf füllt die Zwischenablage');
  await p.screenshot({ path: '/tmp/v15test/2_anleitung_skript.png' });
  await p.fill('#gsUrl', 'https://script.google.com/macros/s/kurz/dev'); await ev(() => gsSkriptVerbinden()); await p.waitForTimeout(500);
  ok(await ev(() => /keine Web-App-Adresse/.test(document.querySelector('.gs-fehler').textContent) && document.getElementById('gsUrl').value.includes('/dev')), 'Falsche URL → Meldung, Eingabe bleibt stehen');
  await p.fill('#gsUrl', 'https://script.google.com/macros/s/AKfycbx1234567890abcdefghijklmnop/exec');
  await ev(() => { gsSkriptVerbinden(); }); await p.waitForTimeout(100);
  ok(await ev(() => /Prüfe die Verbindung/.test(document.getElementById('gsUrlStatus').textContent)), 'Zeigt „Prüfe die Verbindung …“');
  await p.screenshot({ path: '/tmp/v15test/3_pruefe.png' });
  await p.waitForTimeout(900);
  ok(await ev(() => document.querySelectorAll('input[name=gsKal]').length === 2), 'Kalenderauswahl (2 Kalender)');
  ok(await ev(() => /2 Termine/.test(document.querySelector('.gs-frage').textContent)), 'Frage: 2 Termine bisher nur am PC');
  // Cloud-Weg weiterhin erreichbar
  ok(await ev(() => typeof gsAnleitungCloud === 'function'), 'Cloud-Anleitung vorhanden');
  await p.screenshot({ path: '/tmp/v15test/4_kalenderwahl.png' });
  await ev(() => gsKalenderUebernehmen()); await p.waitForTimeout(800);

  // ── 3) Erster Abgleich ──
  const r1 = await ev(() => {
    const G = window.__G, t = id => db.termine.find(x => x.id === id);
    const gT1 = G.aktive().find(e => e.extendedProperties && e.extendedProperties.private.mcId === 't1');
    return { cfg: db.googleSync.kalenderId, t1: t('t1').googleEventId, gT1, sameLink: t('tSame').googleEventId, sameOrt: t('tSame').ort, gSame: G.events.get('eSame'),
      alt: t('tAlt').googleEventId || null, leer: t('tLeer').googleEventId || null,
      importiert: db.termine.filter(x => x.quelle === 'google').map(x => x.titel).sort(),
      ganz: db.termine.find(x => x.googleEventId === 'eGanz'), weit: db.termine.find(x => x.googleEventId === 'eWeit'),
      zahlGoogle: G.aktive().length, zahlLokal: db.termine.length, bekannt: Object.keys(db.googleSync.bekannt).length, leiste: document.querySelector('.gs-leiste').innerText, gespeichert: !!window.__gespeichert };
  });
  ok(r1.cfg === 'paul@example.com' && (await ev(() => db.googleSync.kalenderName)) === 'Hauptkalender', 'Hauptkalender gewählt');
  ok(r1.t1 && r1.gT1, 'PC-Termin t1 in Google eingetragen');
  ok(r1.gT1 && r1.gT1.start.dateTime.startsWith(await ev(() => window.__G.tag(2)) + 'T10:00') && r1.gT1.end.dateTime.includes('T11:00'), 'Zeit + 60 Min. Dauer korrekt');
  ok(r1.gT1 && r1.gT1.colorId === '7', 'v20: Termin aus dem Cockpit in Blau (Google-Farbe 7 „Pfau“)');
  ok(r1.gT1 && /Exposé mitnehmen\n\n— aus dem MaklerCockpit —\n(📍 Termin vor Ort\n)?Objekt: Einfamilienhaus mit Garten – Lindenweg 5, 14974 Ludwigsfelde\nKontakt: Frau Weber\nTelefon: 0171 2345678/.test(r1.gT1.description) && /Anzeige: https/.test(r1.gT1.description), 'Beschreibung mit Lead-Infos: ' + JSON.stringify(r1.gT1 && r1.gT1.description));
  ok(r1.sameLink === 'eSame', 'Gleicher Termin erkannt und verknüpft (kein Doppel)');
  ok(r1.sameOrt === 'Notariat Mitte' && /Ausweis mitnehmen/.test(r1.gSame.description), 'Zusammengeführt: Ort aus Google, Notiz vom PC nach Google');
  ok(!r1.alt && !r1.leer, 'Alter Termin (−60 Tage) und Termin ohne Datum bleiben nur am PC');
  ok(JSON.stringify(r1.importiert) === JSON.stringify(['Eigentümerversammlung','Urlaub Ostsee','Zahnarzt']), 'Aus Google geholt (ohne Arbeitsort, Abgesagtes, Uralt): ' + r1.importiert.join(', '));
  ok(r1.ganz && r1.ganz.uhrzeit === '' && r1.ganz.bisDatum === await ev(() => window.__G.tag(7)) && r1.ganz.farbe, 'Mehrtägig ganztägig mit Ende + Farbe');
  ok(r1.weit && r1.weit.notiz === 'TOP 3: Dach\nBitte Vollmacht' && r1.weit.dauer === 120, 'HTML-Beschreibung → Text, Dauer 120');
  ok(r1.zahlGoogle === 7 && r1.zahlLokal === 7, `Zahlen: Google ${r1.zahlGoogle} aktiv, PC ${r1.zahlLokal}`);
  ok(r1.bekannt === 5, 'Verknüpfungen gemerkt: ' + r1.bekannt);
  ok(/Synchron mit Google Kalender/.test(r1.leiste) && r1.gespeichert, 'Leiste grün + gespeichert');
  const vorher = await G(() => window.__G.log.length);
  await ev(() => gsSync('leise')); await p.waitForTimeout(300);
  const zweiter = await G(() => window.__G.log.slice(-10));
  ok(zweiter.length && (await G(() => window.__G.log.length)) - vorher === 1, 'Zweiter Abgleich ohne Änderungen: nur 1 Abruf (' + zweiter.slice(-1) + ')');
  // v20: früher orange eingetragene Termine werden einmalig blau
  await ev(() => { const G = window.__G; const e = G.neu({ id:'eOrange', summary:'Akquise-Termin: Altbau', start:{ dateTime: G.tag(6)+'T09:00:00' }, end:{ dateTime: G.tag(6)+'T10:00:00' }, colorId:'6' });
    const t = { id:'tOr', createdAt:1, titel:'Akquise-Termin: Altbau', datum:G.tag(6), uhrzeit:'09:00', dauer:60, art:'akquise', ort:'', notiz:'', googleEventId:'eOrange', gUpdated:G.events.get('eOrange').updated };
    t.gHash = gsHash(t); db.termine.push(t); db.googleSync.bekannt.eOrange = 'tOr'; });
  await ev(() => gsSync('leise')); await p.waitForTimeout(300);
  const orange = await ev(() => ({ g: window.__G.events.get('eOrange').colorId, l: db.termine.find(x => x.id === 'tOr') }));
  ok(orange.g === '7' && orange.l.farbe === '#039be5' && orange.l.farbe20 === true, 'Alter oranger Termin in Google auf Blau umgestellt');
  const vorher2 = await G(() => window.__G.log.length);
  await ev(() => gsSync('leise')); await p.waitForTimeout(300);
  ok((await G(() => window.__G.log.length)) - vorher2 === 1, 'Danach kein weiteres Umfärben (nur 1 Abruf)');
  await ev(() => { db.termine = db.termine.filter(x => x.id !== 'tOr'); window.__G.events.get('eOrange').status = 'cancelled'; delete db.googleSync.bekannt.eOrange; });
  await ev(() => gsSync('leise')); await p.waitForTimeout(200);
  await p.screenshot({ path: '/tmp/v15test/5_termine_verbunden.png' });

  // ── 4) Änderungen am Handy ──
  await ev(() => { const G = window.__G; G.handyAendern('eHandy1', { start:{ dateTime: G.tag(1)+'T11:00:00' }, end:{ dateTime: G.tag(1)+'T11:45:00' }, summary:'Zahnarzt Dr. Kim' });
    G.neu({ id:'eNeuHandy', summary:'Rückruf Herr Lange', start:{ dateTime: G.tag(0)+'T17:00:00' }, end:{ dateTime: G.tag(0)+'T17:15:00' } });
    const t1g = db.termine.find(x=>x.id==='t1').googleEventId; G.handyAendern(t1g, { start:{ dateTime: G.tag(2)+'T15:00:00' }, end:{ dateTime: G.tag(2)+'T16:00:00' } }); });
  await ev(() => gsSync('aenderung')); await p.waitForTimeout(300);
  const r2 = await ev(() => { const z = db.termine.find(x => x.googleEventId === 'eHandy1'); const t1 = db.termine.find(x=>x.id==='t1');
    return { z: [z.titel, z.uhrzeit, z.dauer], neu: !!db.termine.find(x => x.googleEventId === 'eNeuHandy'), t1: t1.uhrzeit, vl: findObjekt('x1').verlauf.slice(-1)[0].text }; });
  ok(r2.z.join() === 'Zahnarzt Dr. Kim,11:00,45', 'Am Handy verschoben → am PC übernommen: ' + r2.z);
  ok(r2.neu, 'Am Handy neu eingetragen → am PC da');
  ok(r2.t1 === '15:00' && /Im Google Kalender verschoben auf .* 15:00 Uhr/.test(r2.vl), 'Lead-Termin am Handy verschoben → im Lead-Verlauf: ' + r2.vl);

  // ── 5) Änderungen am PC über den Termin-Dialog ──
  await ev(() => oeffneTerminModal('t1')); await p.waitForTimeout(150);
  ok(await ev(() => !!document.getElementById('m_t_dauer') && !!document.getElementById('m_t_ort') && /Im Google Kalender/.test(document.querySelector('.gs-hinweis').textContent)), 'Termin-Dialog mit Dauer, Ort, Google-Status');
  await p.screenshot({ path: '/tmp/v15test/6_termin_dialog.png' });
  await p.fill('#m_t_zeit', '16:30'); await ev(() => { document.getElementById('m_t_dauer').value = '90'; document.getElementById('m_t_ort').value = 'Lindenweg 5, Ludwigsfelde'; });
  await ev(() => speichereTermin('t1')); await p.waitForTimeout(1500);
  const r3 = await ev(() => { const t1 = db.termine.find(x=>x.id==='t1'); const g = window.__G.events.get(t1.googleEventId); return { g: [g.start.dateTime, g.end.dateTime, g.location], hashOk: gsHash(t1) === t1.gHash, vl: findObjekt('x1').verlauf.slice(-1)[0].text }; });
  ok(r3.g[0].includes('T16:30') && r3.g[1].includes('T18:00') && r3.g[2] === 'Lindenweg 5, Ludwigsfelde', 'Am PC geändert → automatisch nach Google (ohne Klick): ' + r3.g.join(' | '));
  ok(r3.hashOk && /verlegt auf/.test(r3.vl), 'Stand gemerkt + Verlauf „verlegt auf“');
  // ganztägig ↔ Uhrzeit (PUT)
  await ev(() => { const t = db.termine.find(x=>x.googleEventId==='eHandy1'); t.uhrzeit = ''; t.dauer = null; t.geaendertAm = Date.now(); save(); });
  await ev(() => gsSync('leise')); await p.waitForTimeout(200);
  const r4 = await ev(() => ({ g: window.__G.events.get('eHandy1'), put: window.__G.log.filter(x=>x.startsWith('PUT')).length }));
  ok(r4.g.start.date && !r4.g.start.dateTime && r4.put === 1, 'Auf ganztägig umgestellt → per PUT ersetzt');

  // ── 6) Konflikt: beide geändert ──
  await ev(() => { const t = db.termine.find(x=>x.googleEventId==='eNeuHandy'); t.titel = 'Rückruf Lange (PC)'; t.geaendertAm = Date.now() - 60000; window.__G.zeitVersatz = 0; window.__G.handyAendern('eNeuHandy', { summary:'Rückruf Lange (Handy)' }); });
  await ev(() => gsSync('leise')); await p.waitForTimeout(200);
  ok(await ev(() => db.termine.find(x=>x.googleEventId==='eNeuHandy').titel === 'Rückruf Lange (Handy)'), 'Konflikt: neuere Änderung (Handy) gewinnt');
  await ev(() => { window.__G.handyAendern('eNeuHandy', { summary:'Rückruf Lange (Handy 2)' }); const t = db.termine.find(x=>x.googleEventId==='eNeuHandy'); t.titel = 'Rückruf Lange (PC neuer)'; t.geaendertAm = Date.now() + 3600e3; });
  await ev(() => gsSync('leise')); await p.waitForTimeout(200);
  ok(await ev(() => window.__G.events.get('eNeuHandy').summary === '📞 Rückruf Lange (PC neuer)'), 'Konflikt: neuere Änderung (PC) gewinnt (v23: mit 📞 im Google-Titel)');

  // ── 7) Löschen in beide Richtungen, „nur am PC“ ──
  await ev(() => { db.termine = db.termine.filter(x=>x.googleEventId!=='eNeuHandy'); save(); });
  await ev(() => gsSync('leise')); await p.waitForTimeout(200);
  ok(await ev(() => window.__G.events.get('eNeuHandy').status === 'cancelled'), 'Am PC gelöscht → in Google gelöscht');
  const t1g = await ev(() => db.termine.find(x=>x.id==='t1').googleEventId);
  await ev((id) => window.__G.handyLoeschen(id), t1g);
  await ev(() => gsSync('leise')); await p.waitForTimeout(200);
  const r5 = await ev(() => ({ da: !!db.termine.find(x=>x.id==='t1'), vl: findObjekt('x1').verlauf.slice(-1)[0].text }));
  ok(!r5.da && /Termin im Google Kalender gelöscht/.test(r5.vl), 'Am Handy gelöscht → am PC weg + im Lead-Verlauf');
  await ev(() => { const t = db.termine.find(x=>x.id==='tSame'); t.nurLokal = true; save(); });
  await ev(() => gsSync('leise')); await p.waitForTimeout(200);
  const r6 = await ev(() => ({ g: window.__G.events.get('eSame').status, t: db.termine.find(x=>x.id==='tSame') }));
  ok(r6.g === 'cancelled' && r6.t && !r6.t.googleEventId, '„Nur am PC“ → aus Google entfernt, am PC bleibt er');
  await ev(() => gsSync('leise')); await p.waitForTimeout(200);
  ok(await ev(() => !window.__G.aktive().some(e => e.summary.startsWith('Notar'))), '… und wird nicht wieder hochgeladen');

  // ── 8) Schutz vor Massenlöschung ──
  await ev(() => { for(let i=0;i<9;i++) window.__G.neu({ id:'eM'+i, summary:'Serie '+i, start:{ dateTime: window.__G.tag(10+i)+'T08:00:00' }, end:{ dateTime: window.__G.tag(10+i)+'T09:00:00' } }); });
  await ev(() => gsSync('leise')); await p.waitForTimeout(300);
  const nVor = await ev(() => db.termine.filter(x=>x.googleEventId).length);
  await ev(() => { db.termine = db.termine.filter(x => !(x.googleEventId||'').startsWith('eM')); save(); });
  dialogAntwort = 'dismiss';
  await ev(() => gsSync('leise')); await p.waitForTimeout(300);
  const r7 = await ev(() => ({ google: window.__G.aktive().filter(e=>e.id.startsWith('eM')).length, lokal: db.termine.filter(x=>(x.googleEventId||'').startsWith('eM')).length }));
  ok(dialoge.some(d => /fehlen am PC 9 Termine/.test(d)), 'Rückfrage bei 9 fehlenden Terminen');
  ok(r7.google === 9 && r7.lokal === 9, 'Abgelehnt → nichts in Google gelöscht, Termine wieder geholt');
  dialogAntwort = 'accept';
  ok(nVor === 12, 'Vorher verknüpft: ' + nVor);

  // ── 8b) Gleicher Termin am PC nochmal eingetragen → zusammengeführt, kein Doppel in Google ──
  const vorZ = await ev(() => ({ g: window.__G.aktive().length, l: db.termine.length }));
  await ev(() => { const z = db.termine.find(x=>x.googleEventId==='eM2'); db.termine.push({ id:'dupl1', createdAt:Date.now(), geaendertAm:Date.now(), titel: z.titel, datum: z.datum, uhrzeit: z.uhrzeit, dauer:60, art:'besichtigung', notiz:'Schlüssel beim Nachbarn', objektId:'x2' }); save(); });
  await ev(() => gsSync('leise')); await p.waitForTimeout(250);
  const rz = await ev(() => { const z = db.termine.find(x=>x.googleEventId==='eM2'); return { g: window.__G.aktive().length, l: db.termine.length, dupl: !!db.termine.find(x=>x.id==='dupl1'), notiz: z.notiz, objekt: z.objektId, art: z.art, gNotiz: window.__G.events.get('eM2').description||'' }; });
  ok(rz.g === vorZ.g && rz.l === vorZ.l && !rz.dupl, 'Doppelt eingetragener Termin wird zusammengeführt (kein Doppel)');
  await ev(() => gsSync('leise')); await p.waitForTimeout(200);
  const rz2 = await ev(() => window.__G.events.get('eM2').description || '');
  ok(rz.notiz === 'Schlüssel beim Nachbarn' && rz.objekt === 'x2' && rz.art === 'besichtigung' && /Schlüssel beim Nachbarn/.test(rz2), 'Notiz/Lead/Art übernommen und nach Google übertragen');

  // ── 9) Akquise: Termin direkt am Lead ──
  await ev(() => { AQ2.status = 'alle'; AQ2.sel = 'x1'; wechsleAnsicht('akquise'); }); await p.waitForTimeout(300);
  ok(await ev(() => document.querySelectorAll('.dp-aktionen button').length === 4 && !!document.getElementById('dpTermine')), 'Lead: Termin-Knopf + Termine-Abschnitt');
  await ev(() => aq2TerminNeu()); await p.waitForTimeout(150);
  const r8 = await ev(() => ({ titel: document.getElementById('tq_titel').value, ort: document.getElementById('tq_ort').value, st: document.getElementById('tq_st_text').textContent }));
  ok(r8.titel === 'Besichtigung: Einfamilienhaus mit Garten (Ludwigsfelde)' && r8.ort === 'Lindenweg 5, 14974 Ludwigsfelde' && /„Termin“/.test(r8.st), 'Dialog vorausgefüllt: ' + r8.titel + ' | ' + r8.ort);
  // Überschneidung mit „Zahnarzt“ morgen (ganztägig jetzt) → 18 Uhr am Tag mit Serie testen
  await ev(() => { document.getElementById('tq_datum').value = window.__G.tag(10); document.getElementById('tq_zeit').value = '08:30'; aq2TqTag(); });
  ok(await ev(() => /überschneidet sich mit einem Termin/.test(document.getElementById('tq_tag').textContent)), 'Überschneidung wird angezeigt');
  await p.screenshot({ path: '/tmp/v15test/7_lead_termin_dialog.png' });
  await ev(() => aq2TqArt('rueckruf'));
  const r9 = await ev(() => ({ titel: document.getElementById('tq_titel').value, ort: document.getElementById('tq_ort').value, dauer: document.getElementById('tq_dauer').value }));
  ok(r9.titel.startsWith('Rückruf:') && r9.ort === 'Telefon 0171 2345678' && r9.dauer === '15', 'Art Rückruf: Titel, Ort „Telefon …“, 15 Min.');
  await ev(() => aq2TqArt('besichtigung'));
  await ev(() => { aq2TqDatum(1); document.getElementById('tq_zeit').value = '14:00'; document.getElementById('tq_notiz').value = 'Grundbuchauszug ansprechen'; aq2TqTag(); });
  await ev(() => aq2TerminAnlegen()); await p.waitForTimeout(1200);
  const r10 = await ev(() => { const o = findObjekt('x1'); const t = db.termine.filter(x=>x.objektId==='x1').slice(-1)[0]; const g = t && window.__G.events.get(t.googleEventId);
    return { status: o.status, vl: o.verlauf.slice(-1)[0], t, g: g && [g.summary, g.start.dateTime, g.location, g.colorId, /Telefon: 0171 2345678/.test(g.description)], chip: (document.querySelector('[data-lct="x1"]')||{}).textContent, abschnitt: document.getElementById('dpTermine').innerText }; });
  ok(r10.status === 'termin', 'Status → Termin');
  ok(r10.vl.typ === 'termin' && /^Besichtigung \(vor Ort\) am \S+ \d\d\.\d\d\.\d* 14:00 Uhr$/.test(r10.vl.text), 'Verlauf: ' + r10.vl.text);
  ok(r10.g && r10.g[0].startsWith('📍 Besichtigung:') && r10.g[1].includes('T14:00') && r10.g[2] === 'Lindenweg 5, 14974 Ludwigsfelde' && r10.g[3] === '7' && r10.g[4], 'Lead-Termin automatisch in Google: ' + JSON.stringify(r10.g));
  ok(r10.chip === '📍 Morgen 14:00', 'Lead-Karte zeigt nächsten Termin: ' + r10.chip);
  ok(/Morgen/.test(r10.abschnitt) && /Besichtigung/.test(r10.abschnitt), 'Termine-Abschnitt im Lead');
  await ev(() => { document.getElementById('dpTermine').scrollIntoView({block:'center'}); });
  const box = await ev(() => { const r = document.querySelector('#aqDetail .dp').getBoundingClientRect(); return { x:r.x, y:r.y, width:r.width, height:r.height }; });
  await p.screenshot({ path: '/tmp/v15test/8_lead_detail.png', clip: box });
  await p.screenshot({ path: '/tmp/v15test/9_akquise_gesamt.png' });
  // Nach Anruf: „Termin“ öffnet denselben Dialog
  await ev(() => { AQ2.sel = 'x2'; aq2Liste(); aq2TerminFrage('nochmal_anrufen'); }); await p.waitForTimeout(100);
  ok(await ev(() => document.querySelector('.tq-art.an').dataset.k === 'rueckruf' && document.getElementById('tq_ort').value === 'Telefon'), 'Nach Anruf → Rückruf-Dialog (ohne Nummer: Ort „Telefon“)');
  await ev(() => schliesseModal());

  // ── 10) Termine-Seite + Einstellungen ──
  await ev(() => wechsleAnsicht('termine')); await p.waitForTimeout(200);
  ok(await ev(() => document.querySelectorAll('#tmNaechste .tm-z').length >= 5), 'Als Nächstes: Liste gefüllt');
  await p.screenshot({ path: '/tmp/v15test/10_termine_seite.png' });
  await ev(() => oeffneTagModal(window.__G.tag(1))); await p.waitForTimeout(100);
  ok(await ev(() => document.querySelectorAll('.modal .tm-z').length >= 2), 'Tagesansicht listet Termine');
  await ev(() => gsAssistent()); await p.waitForTimeout(250);
  ok(await ev(() => /Verbunden/.test(document.getElementById('modalInner').textContent) && /Verknüpfte Termine/.test(document.getElementById('modalInner').textContent)), 'Einstellungen bei bestehender Verbindung');
  ok(await ev(() => /dauerhaft verbunden/.test(document.getElementById('modalInner').textContent)), 'Einstellungen: über Google-Skript, dauerhaft');
  await p.screenshot({ path: '/tmp/v15test/11_einstellungen.png' });
  await ev(() => schliesseModal());

  // ── 10b) Offline: nur gelber Hinweis ──
  await ev(() => { window.__G.fehlerBei = { methode:'GET', einmal:true, antwort:{ ok:false, code:'netz', fehler:'Google ist gerade nicht erreichbar (keine Internetverbindung?).' } }; });
  await ev(() => gsSync('leise')); await p.waitForTimeout(200);
  const rn = await ev(() => ({ cls: document.querySelector('.gs-leiste').className, txt: document.querySelector('.gs-leiste').innerText, glocke: tbHinweise().some(x => /Google/.test(x.t)) }));
  ok(!/warn/.test(rn.cls) && /offline/.test(rn.txt) && !rn.glocke, 'Offline → gelber Hinweis, keine Glocke');
  await ev(() => gsSync('leise')); await p.waitForTimeout(200);
  ok(await ev(() => /Synchron/.test(document.querySelector('.gs-leiste').innerText)), 'Wieder online → wieder grün');
  // ── 11) Verbindung abgelaufen ──
  await ev(() => { window.__G.fehlerBei = { methode:'GET', antwort:{ ok:false, code:'abgelaufen', fehler:'Die Google-Verbindung ist abgelaufen oder wurde widerrufen – bitte neu verbinden.' } }; });
  await ev(() => gsSync('leise')); await p.waitForTimeout(250);
  const r11 = await ev(() => ({ leiste: document.querySelector('.gs-leiste').className + ' ' + document.querySelector('.gs-leiste').innerText, hinweis: tbHinweise().map(x=>x.t) }));
  ok(/warn/.test(r11.leiste) && /abgelaufen/.test(r11.leiste), 'Abgelaufen → Leiste rot mit „Neu verbinden“');
  ok(r11.hinweis.some(t => /abgelaufen/.test(t)), 'Glocke meldet abgelaufene Verbindung');
  await p.screenshot({ path: '/tmp/v15test/12_abgelaufen.png' });
  await ev(() => { window.__G.fehlerBei = null; });
  const nTermine = await ev(() => db.termine.length);
  ok(nTermine > 10, 'Termine bleiben trotz Fehler erhalten: ' + nTermine);

  // ── 12) Neu verbinden → kein Doppel; Trennen ──
  await ev(() => { window.__G.st.verbunden = true; window.__G.st.email = 'paul@example.com'; return gsStatusLaden(); });
  await ev(() => gsSync('leise')); await p.waitForTimeout(300);
  const r12 = await ev(() => ({ g: window.__G.aktive().filter(e=>!['eWork','eAlt'].includes(e.id)).length, l: db.termine.filter(x=>x.googleEventId).length, fehler: GS.fehler }));
  ok(!r12.fehler && r12.g === r12.l, `Nach neuer Anmeldung alles verknüpft: Google ${r12.g} = PC ${r12.l}`);
  await ev(() => gsTrennen(false)); await p.waitForTimeout(300);
  const r13 = await ev(() => ({ lokal: db.termine.length, verkn: db.termine.filter(x=>x.googleEventId).length, cfg: db.googleSync.kalenderId, leiste: document.querySelector('.gs-leiste') ? document.querySelector('.gs-leiste').innerText : '' }));
  ok(r13.verkn === 0 && !r13.cfg && r13.lokal === nTermine, 'Getrennt: Termine bleiben, Verknüpfungen gelöst');
  // wieder verbinden: gleiche Termine werden erkannt
  await ev(() => { window.__G.st.verbunden = true; window.__G.st.email = 'paul@example.com'; });
  await ev(() => gsAssistent()); await p.waitForTimeout(400);
  await ev(() => gsKalenderUebernehmen()); await p.waitForTimeout(800);
  const r14 = await ev(() => ({ g: window.__G.aktive().filter(e=>!['eWork','eAlt'].includes(e.id)).length, l: db.termine.filter(x=>x.googleEventId).length, lokal: db.termine.length }));
  ok(r14.g === r14.l && r14.lokal === nTermine, `Wieder verbunden ohne Doppelte: Google ${r14.g}, PC verknüpft ${r14.l}, PC gesamt ${r14.lokal}`);

  // gespeicherte Datei enthält keine Zugangsdaten
  const datei = await ev(() => window.__gespeichert || '');
  ok(!/GOCSPX|refresh|access_token/.test(datei) && /googleSync/.test(datei), 'daten.json ohne Google-Zugangsdaten');
  ok(fe.length === 0, 'Keine Seitenfehler');
  console.log('\nFEHLER', fehler); await b.close(); process.exit(fehler ? 1 : 0);
})();
