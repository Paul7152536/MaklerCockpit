// v19: Glocke – Hinweise abhaken, Zahl, Erinnerungen einstellen
const { chromium } = require('playwright');
let fehler = 0; const ok = (b, t) => { if(!b){ fehler++; console.log('FEHLER:', t); } else console.log('ok  ', t); };
(async () => {
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 1536, height: 1000 }, deviceScaleFactor: 2 });
  const fe = []; p.on('pageerror', e => { fe.push(e.message); console.log('SEITENFEHLER', e.message); });
  await p.addInitScript(() => {
    const heute = new Date(); const k = d => `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
    const ob = []; for(let i=0;i<5;i++) ob.push({ id:'n'+i, createdAt:Date.now()-i*1000, akqTitel:'Lead '+i, objektart:'EFH', ort:'Teltow', status:'neu', verlauf:[] });
    const alt = { objekte: ob, kontakte: [], termine: [1,2,3].map(i => ({ id:'t'+i, titel:'Termin '+i, datum:k(heute), uhrzeit:'1'+i+':00', art:'termin' })), marktanalysen: [], aufgaben: [], notizen: [], mentorFragen: [], meta: { v9neustart: { quittiert: true } } };
    window.pc = { laden: () => JSON.parse(JSON.stringify(alt)), speichern: () => ({ ok:true }), ordner(){}, sicherungSchreiben: () => ({ ok:true }), sicherungLesen: () => null, zwischenablage: async () => '', abruf: async () => ({ ok:false }) };
  });
  await p.goto('file:///tmp/pc/app/index.html'); await p.waitForTimeout(1500);
  const ev = (f, ...a) => p.evaluate(f, ...a);
  const zahl = () => ev(() => { const x = document.querySelector('#tbGlocke .punkt'); return x ? x.textContent : ''; });
  await ev(() => { akqDb().zuletzt.gesuche = new Date().toISOString(); tbGlockeAktualisieren(); });
  ok(await zahl() === '6', 'Glocke zeigt Zahl 6 (4 Suchen + neue Leads + Termine)');
  await ev(() => document.getElementById('tbGlocke').click()); await p.waitForTimeout(100);
  ok(await ev(() => document.querySelectorAll('#tbMenue .hw-ok').length === 6 && !!document.querySelector('#tbMenue .hw-fuss')), 'Jeder Hinweis hat ✓, unten „Alle abhaken“ + „Erinnerungen“');
  await p.screenshot({ path: '/tmp/v19test/1_glocke.png', clip: { x: 1100, y: 0, width: 436, height: 520 } });
  await ev(() => document.querySelectorAll('#tbMenue .hw-ok')[0].click()); await p.waitForTimeout(100);
  ok(await zahl() === '5' && await ev(() => !!document.getElementById('tbMenue') && document.querySelectorAll('#tbMenue .hw-ok').length === 5), '✓ bei „Zeitung“: Zahl 5, Menü bleibt offen');
  ok(await ev(() => !!akqDb().zuletzt.zeitung), 'Suche gilt als erledigt (nächste Erinnerung nach Abstand)');
  const iNeu = await ev(() => tbHinweiseOffen().findIndex(h => h.k === 'neu'));
  await ev((i) => document.querySelectorAll('#tbMenue .hw-ok')[i].click(), iNeu); await p.waitForTimeout(100);
  ok(await zahl() === '4', '„5 neue Leads“ abgehakt → 4');
  await ev(() => { db.objekte.push({ id:'n9', createdAt:Date.now(), akqTitel:'Neu', objektart:'EFH', status:'neu', verlauf:[] }); tbGlockeAktualisieren(); });
  ok(await zahl() === '5' && await ev(() => tbHinweiseOffen().some(h => h.t === '6 neue Leads noch nicht kontaktiert')), 'Neuer Lead dazu → Hinweis kommt mit 6 wieder');
  await ev(() => { db.objekte = db.objekte.filter(o => o.id !== 'n9'); tbGlockeAktualisieren(); });
  ok(await zahl() === '4', 'Wieder 5 Leads → bleibt abgehakt');
  await ev(() => { document.getElementById('tbGlocke').click(); }); await p.waitForTimeout(80);
  if(!(await ev(() => !!document.getElementById('tbMenue')))) await ev(() => document.getElementById('tbGlocke').click());
  await ev(() => document.querySelector('#tbMenue .hw-fuss button').click()); await p.waitForTimeout(100);
  ok(await zahl() === '' && await ev(() => /Alles erledigt/.test(document.getElementById('tbMenue').textContent)), '„Alle abhaken“ → Glocke ohne Zahl, „Alles erledigt“');
  // Nächster Tag: Zähl-Hinweise kommen wieder, Suchen nach Abstand
  await ev(() => { Object.values(db.hinweisEinst.aus).forEach(a => a.tag = '2000-01-01'); tbGlockeAktualisieren(); });
  ok(await zahl() === '2', 'Am nächsten Tag wieder da: neue Leads + Termine (Suchen erst nach Abstand)');
  // Einstellungen
  await ev(() => { tbMenueZu(); tbErinnerungenEinstellen(); }); await p.waitForTimeout(100);
  ok(await ev(() => document.querySelectorAll('.hw-zeile').length === 5 && document.querySelectorAll('#modalInner .gs-chk input').length === 11), 'Einstellungen: 5 Suchen mit Abstand + 6 Schalter (v20: + Preis gesenkt, v21: + Suchkunden, v22: + Käufer-Gesuche)');
  await p.screenshot({ path: '/tmp/v19test/2_erinnerungen.png' });
  await ev(() => { tbEinstSuche('kleinanzeigen', 'tage', 7); const a = akqDb(); a.zuletzt.kleinanzeigen = new Date(Date.now() - 4*864e5).toISOString(); a.zuletzt.hv = new Date(Date.now() - 30*864e5).toISOString(); tbEinstSuche('hv', 'aus', true); tbEinstSetzen('termine', false); });
  const r = await ev(() => tbHinweiseOffen().map(h => h.k));
  ok(!r.includes('suche:kleinanzeigen') && !r.includes('suche:hv') && !r.includes('termine') && r.includes('neu'), 'Kleinanzeigen alle 7 Tage (vor 4 Tagen → nicht fällig), Hausverwaltungen aus, Termine-Hinweis aus: ' + r.join(','));
  await ev(() => { document.querySelector('#modalInner .modal-actions button').click(); });
  ok(await ev(() => Object.keys(db.hinweisEinst.aus).length === 0), '„Abgehakte wieder zeigen“ setzt zurück');
  ok(fe.length === 0, 'Keine Seitenfehler');
  console.log('\nFEHLER', fehler); await b.close(); process.exit(fehler ? 1 : 0);
})();
