// v31: Anschreib-Tage, nach 4 Wochen ohne Antwort löschen; „Nachricht“ öffnet das Exposé nicht doppelt
const { chromium } = require('playwright');
let f = 0; const ok = (b, t) => { console.log((b ? 'ok   ' : 'FEHL ') + t); if(!b) f++; };
const T = 864e5, jetzt = Date.now();
const L = (id, x) => Object.assign({ id, createdAt: jetzt - 60 * T, akqTitel: 'Lead ' + id, ort: '12527 Berlin-Grünau', objektart: 'EFH', quelle: 'Kleinanzeigen', verlauf: [], prioritaet: 'mittel' }, x);
const D = { objekte: [
  L('l1', { status: 'neu', link: 'https://www.kleinanzeigen.de/s-anzeige/l1' }),
  L('l2', { status: 'email_geschrieben', emailAm: jetzt - 35 * T, statusAm: jetzt - 35 * T, verlauf: [{ ts: jetzt - 35 * T, typ: 'email', text: 'E-Mail geschrieben' }], link: 'https://www.kleinanzeigen.de/s-anzeige/l2', verkaeuferTelefon: '0171 5550001', verkaeuferEmail: 'l2@example.org' }),
  L('l3', { status: 'kleinanzeigen_geschrieben', kleinanzeigenAm: jetzt - 20 * T, statusAm: jetzt - 40 * T, nachgefasstAm: jetzt - 20 * T, nachgefasst: 1, verlauf: [{ ts: jetzt - 40 * T, typ: 'email', text: 'Per Kleinanzeigen angeschrieben' }, { ts: jetzt - 20 * T, typ: 'email', text: 'Nachgefasst per Kleinanzeigen' }], link: 'https://www.kleinanzeigen.de/s-anzeige/l3' }),
  L('l4', { status: 'email_geschrieben', emailAm: jetzt - 30 * T, statusAm: jetzt - 30 * T, favorit: true }),
  L('l5', { status: 'erstkontakt', emailAm: jetzt - 50 * T, statusAm: jetzt - 45 * T }),
  L('l6', { status: 'kleinanzeigen_geschrieben', kleinanzeigenAm: jetzt - 29 * T, statusAm: jetzt - 29 * T, link: 'https://www.kleinanzeigen.de/s-anzeige/l6', verkaeuferTelefon: '0176 5550006' }),
  L('l7', { status: 'email_geschrieben' }),
  L('m1', { status: 'neu', link: 'https://www.kleinanzeigen.de/s-anzeige/m1' }),
  L('m2', { status: 'neu', link: 'https://www.kleinanzeigen.de/s-anzeige/m2' }),
  L('m3', { status: 'neu', link: 'https://www.kleinanzeigen.de/s-anzeige/m3', verkaeuferEmail: 'm3@example.org' }),
], kontakte: [], termine: [], aufgaben: [], notizen: [], gesuche: [], marktanalysen: [], mentorFragen: [], meta: { v9neustart: { quittiert: true } } };
(async () => {
  const b = await chromium.launch();
  const ctx = await b.newContext({ viewport: { width: 1440, height: 900 } });
  const p = await ctx.newPage(); const fe = []; p.on('pageerror', e => fe.push(e.message));
  await p.addInitScript(d => { window.pc = { geraet: 'pc', laden: () => JSON.parse(sessionStorage.getItem('d') || 'null') || JSON.parse(d), speichern: t => { sessionStorage.setItem('d', t); return { ok: true }; }, ordner(){}, sicherungSchreiben: () => ({ ok: true }), sicherungLesen: () => null, zwischenablage: async () => '', abruf: async () => ({ ok: false }) };
    window.__auf = []; window.open = u => { window.__auf.push(String(u)); return null; }; }, JSON.stringify(D));
  await p.goto('file:///tmp/pc/app/index.html'); await p.waitForTimeout(4500);
  let r = await p.evaluate(() => Object.fromEntries(db.objekte.map(o => [o.id, (o.angeschrieben || []).map(x => x.art[0] + Math.round((Date.now() - x.am) / 864e5))])));
  ok(JSON.stringify(r.l2) === '["a35"]' && JSON.stringify(r.l3) === '["a40","n20"]' && JSON.stringify(r.l6) === '["a29"]' && JSON.stringify(r.l7) === '["a0"]' && JSON.stringify(r.l1) === '[]', 'Anschreib-Tage aus vorhandenen Daten übernommen ' + JSON.stringify({ l2: r.l2, l3: r.l3, l6: r.l6, l7: r.l7 }));
  r = await p.evaluate(() => an31Liste().map(o => o.id));
  ok(JSON.stringify(r) === '["l2","l6","l3"]', 'v47 – nach 2 Wochen ohne Antwort: l2, l6 und l3 (nachgefasst vor 20 Tagen); nicht Favorit, geantwortet, heute ' + JSON.stringify(r));
  r = await p.evaluate(() => ({ karte: document.getElementById('an31Karte') ? document.getElementById('an31Karte').innerText.replace(/\s+/g, ' ') : '', hinweis: tbHinweise().find(h => h.k === 'an31') }));
  ok(/3 Leads seit 2 Wochen ohne Antwort/.test(r.karte) && /Alle löschen\?/.test(r.karte) && r.hinweis && r.hinweis.n === 3, 'Meldung beim Start (Karte mit großem Knopf) und in der Glocke');
  await p.screenshot({ path: '/tmp/v31test/start_karte.png' });
  await p.click('#an31Karte button:has-text("Ansehen")'); await p.waitForTimeout(300);
  r = await p.evaluate(() => ({ zeilen: document.querySelectorAll('.an31-wahl').length, an: document.querySelectorAll('.an31-wahl:checked').length, knopf: document.getElementById('an31Los').textContent, text: document.getElementById('modalInner').innerText }));
  console.log(JSON.stringify(r).slice(0,700)); ok(r.zeilen === 3 && r.an === 3 && r.knopf === '🗑 3 Leads löschen' && /✉️ \d\d\.\d\d\.\d{4}/.test(r.text) && /vor 35 Tagen/.test(r.text), 'Auswahl: 2 Leads angehakt, Anschreib-Tage + „vor 35 Tagen“, großer Knopf „2 Leads löschen“');
  await p.screenshot({ path: '/tmp/v31test/auswahl.png' });
  await p.click('.an31-wahl[value="l6"]'); await p.click('.an31-wahl[value="l3"]'); await p.waitForTimeout(100);
  ok(await p.evaluate(() => document.getElementById('an31Los').textContent) === '🗑 1 Lead löschen', 'Haken weg → „1 Lead löschen“');
  await p.click('#an31Los'); await p.waitForTimeout(400);
  r = await p.evaluate(() => ({ weg: !findObjekt('l2'), l6: findObjekt('l6') && Math.round((findObjekt('l6').an31Spaeter - Date.now()) / 864e5), liste: an31Liste().length, reg: akqDb().ausgeschlossen.map(x => [x.link, x.tel, x.mail]) }));
  ok(r.weg && r.l6 === 14 && r.liste === 0, 'l2 gelöscht, l6 behalten (Nachfrage in 14 Tagen), nichts mehr offen');
  ok(JSON.stringify(r.reg) === JSON.stringify([['https://www.kleinanzeigen.de/s-anzeige/l2', '01715550001', 'l2@example.org']]), 'Sperrliste: Link, Nummer, E-Mail von l2');
  r = await p.evaluate(() => { const vor = db.objekte.length; const ber = akqUebernehmen([{ titel: 'Wieder da', ort: '12527 Berlin', objektart: 'EFH', link: 'https://www.kleinanzeigen.de/s-anzeige/l2', preis: 300000 }, { titel: 'Gleiche Nummer', ort: '10365 Berlin', objektart: 'Wohnung', telefon: '+49 171 5550001', preis: 200000 }, { titel: 'Ganz neu', ort: '12527 Berlin', objektart: 'EFH', link: 'https://www.kleinanzeigen.de/s-anzeige/neu1', preis: 310000 }], 'Test'); return { neu: db.objekte.length - vor, aus: ber.ausgeschlossen, titel: db.objekte.slice(-1)[0].akqTitel }; });
  ok(r.neu === 1 && r.aus === 2 && r.titel === 'Ganz neu', 'Neue KI-Suche: gelöschter Lead (Link) und gleiche Nummer übersprungen, neuer übernommen');
  await p.waitForTimeout(1900);
  ok(/2 schon früher angeschriebene Leads ohne Antwort übersprungen/.test(await p.evaluate(() => document.getElementById('akqToast').textContent)), 'Hinweis „2 schon früher angeschriebene … übersprungen“');
  // Anschreiben im Lead → Tag gespeichert, Nachfassen → zweiter Tag
  await p.evaluate(() => { wechsleAnsicht('akquise'); AQ2.status = 'alle'; AQ2.sel = 'l1'; renderMain(); aq2StatusSetzen('kleinanzeigen_geschrieben'); }); await p.waitForTimeout(700);
  r = await p.evaluate(() => (findObjekt('l1').angeschrieben || []).map(x => x.art));
  ok(JSON.stringify(r) === '["anschreiben"]', 'Status „angeschrieben“ → Tag gespeichert');
  await p.evaluate(() => { const o = findObjekt('l1'); o.angeschrieben[0].am -= 7 * 864e5; o.kleinanzeigenAm -= 7 * 864e5; o.statusAm -= 7 * 864e5; o.verlauf.forEach(v => { if(v.typ === 'email') v.ts -= 7 * 864e5; }); aq2Nachgefasst('Kleinanzeigen'); }); await p.waitForTimeout(700);
  r = await p.evaluate(() => (findObjekt('l1').angeschrieben || []).map(x => x.art[0] + Math.round((Date.now() - x.am) / 864e5)));
  ok(JSON.stringify(r) === '["a7","n0"]', 'Nachfassen → zweiter Tag (' + JSON.stringify(r) + ')');
  r = await p.evaluate(() => { const b = document.querySelector('#aqDetail .an31-box'); const k = document.querySelector('#lc-l1 .an31-am'); return { box: b ? b.innerText.replace(/\s+/g, ' ') : '', karte: k ? k.innerText : '' }; });
  ok(/Angeschrieben: ✉️ .* · 🔁 /.test(r.box) && /Vorschlag zum Löschen/.test(r.box) && /nachgefasst \d\d\.\d\d\.\d{4} · vor 0 T\./.test(r.karte), 'Lead zeigt Anschreib-Tage (Detail + Liste): ' + r.box.slice(0, 90));
  // Status im Objekt-Dialog von Hand → Tag wird trotzdem gespeichert
  await p.evaluate(() => { const o = findObjekt('m2'); o.status = 'email_geschrieben'; save(); }); await p.waitForTimeout(500);
  ok(await p.evaluate(() => (findObjekt('m2').angeschrieben || []).length === 1), 'Status von Hand gesetzt → Tag gespeichert');
  await p.evaluate(() => { findObjekt('m2').status = 'neu'; save(); });
  // Akquise-Balken bei fälligen Leads
  await p.evaluate(() => { const o = findObjekt('l6'); delete o.an31Spaeter; aq2Liste(); }); await p.waitForTimeout(200);
  r = await p.evaluate(() => ({ balken: document.getElementById('an31Balken') ? document.getElementById('an31Balken').innerText.replace(/\s+/g, ' ') : '', alt: !!document.querySelector('#lc-l6 .an31-am.alt') }));
  ok(/1 Lead seit 2 Wochen ohne Antwort/.test(r.balken) && /Alle löschen\?/.test(r.balken) && r.alt, 'Akquise: roter Balken mit Knopf, Lead-Karte rot markiert');
  await p.evaluate(() => { AQ2.sel = 'l6'; aq2Detail(); }); await p.waitForTimeout(200);
  await p.screenshot({ path: '/tmp/v31test/akquise.png' });
  await p.click('#aqDetail .an31-box .an31-gross'); await p.waitForTimeout(200);
  await p.evaluate(() => { const b = Array.from(document.querySelectorAll('button')).find(x => /^(Ja|Löschen|OK|Bestätigen)/.test(x.innerText.trim()) && x.offsetParent); if(b) b.click(); }); await p.waitForTimeout(400);
  ok(await p.evaluate(() => !findObjekt('l6') && akqDb().ausgeschlossen.length === 2), 'Einzeln löschen im Lead (mit Bestätigung)');
  // Nachricht öffnet das Exposé nicht doppelt
  await p.evaluate(() => { window.__auf = []; AQ2.sel = 'm1'; aq2Detail(); aqLinkOeffnen('m1'); aq2Senden(); }); await p.waitForTimeout(400);
  r = await p.evaluate(() => ({ auf: window.__auf.slice(), toast: document.getElementById('akqToast').textContent, knopf: !!document.querySelector('#dpErgebnis .ex31-nochmal') }));
  ok(r.auf.length === 1 && /schon offen/.test(r.toast) && r.knopf, 'Exposé schon geöffnet → „Nachricht“ kopiert nur, kein zweiter Tab (' + r.toast + ')');
  await p.click('#dpErgebnis .ex31-nochmal'); await p.waitForTimeout(150);
  ok(await p.evaluate(() => window.__auf.length) === 2, 'Knopf „Anzeige nicht mehr offen? Öffnen“ öffnet sie doch');
  await p.evaluate(() => { window.__auf = []; AQ2.sel = 'm2'; aq2Detail(); aq2Senden(); }); await p.waitForTimeout(300);
  r = await p.evaluate(() => ({ auf: window.__auf.slice(), toast: document.getElementById('akqToast').textContent }));
  ok(r.auf.length === 1 && /wird geöffnet/.test(r.toast), 'Noch nicht geöffnet → „Nachricht“ öffnet die Anzeige einmal');
  await p.evaluate(() => { aq2Senden(); }); await p.waitForTimeout(300);
  ok(await p.evaluate(() => window.__auf.length) === 1, 'Zweites Mal „Nachricht“ → kein weiterer Tab');
  await p.evaluate(() => { window.__auf = []; ex29Oeffnen(); }); await p.waitForTimeout(1500);
  await p.evaluate(() => { window.__auf = []; AQ2.sel = 'l1'; findObjekt('l1').status = 'neu'; }); 
  await p.evaluate(() => { window.__auf = []; AQ2.sel = 'm3'; aq2Detail(); aq2Senden(); }); await p.waitForTimeout(300);
  r = await p.evaluate(() => window.__auf.slice());
  ok(r.length === 1 && /^mailto:/.test(r[0]), 'Lead mit E-Mail: E-Mail-Programm wie bisher, keine Anzeige');
  // Karte nur einmal am Tag
  await p.reload(); await p.waitForTimeout(4500);
  ok(!(await p.$('#an31Karte')), 'Start-Meldung höchstens einmal am Tag');
  ok(fe.length === 0, 'Keine Fehler ' + JSON.stringify(fe));
  console.log('FEHLER', f); await b.close();
})();
