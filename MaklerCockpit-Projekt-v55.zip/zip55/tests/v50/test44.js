// v44: Erfassung im Fragebogen-Aufbau, Dachform-Bilder, Fragebogen-PDF erstellen → ausfüllen → einlesen
const { chromium } = require('playwright'); const fs = require('fs');
let f = 0; const ok = (b, t) => { console.log((b ? 'ok   ' : 'FEHL ') + t); if(!b) f++; };
const D = JSON.stringify({ objekte: [{ id: 'k1', akqTitel: 'EFH Königsheideweg', objektart: 'Einfamilienhaus', status: 'akquise', ort: '12487 Berlin', adresse: 'Königsheideweg 190, 12487 Berlin', verlauf: [] }, { id: 'k2', akqTitel: 'Anderes Haus', objektart: 'Einfamilienhaus', status: 'akquise', verlauf: [] }],
  kontakte: [], termine: [], aufgaben: [], notizen: [], meta: { v9neustart: { quittiert: true } },
  grossanalyse: { entwuerfe: { k1: { v43: 1, art: 'EFH', region: 'Berlin', stichtag: '2026-11-17', vergleich: [], unterlagen: {}, notiz: '', gruppen43: {}, alt43: {}, werte: { wfl: { v: '164', p: 'Annahme / Schätzung', s: 'assumed' }, adresse: { v: 'Königsheideweg 190', s: 'documented' }, plz: { v: '12487' }, ort: { v: 'Berlin' } } } }, laeufe: [] } });
(async () => {
  const b = await chromium.launch();
  for(const [g, w, h] of [['pc', 1440, 900], ['handy', 412, 915]]){
    const p = await b.newPage({ viewport: { width: w, height: h }, isMobile: g === 'handy', hasTouch: g === 'handy' });
    p.fe = []; p.on('pageerror', e => p.fe.push(e.message));
    await p.addInitScript(([d, g]) => { window.pc = { geraet: g, laden: () => JSON.parse(d), speichern: () => ({ ok: true }), ordner(){}, sicherungSchreiben: () => ({ ok: true }), sicherungLesen: () => null, gekoppelt: () => true, google: async () => ({ ok: false }), dateiSpeichern: async (name, b64) => { window.__pdf = { name, b64 }; return { ok: true, name }; } }; navigator.clipboard.writeText = async t => { window.__kopie = t; }; }, [D, g]);
    await p.goto('file:///tmp/pc/app/index.html'); await p.waitForTimeout(2200);
    await p.evaluate(() => { try{ schliesseModal(); }catch(e){} GA35.obj = 'k1'; wechsleAnsicht('grossanalyse'); }); await p.waitForTimeout(500);
    const E = () => p.evaluate(() => JSON.parse(JSON.stringify(ga35Entwurf('k1'))));
    // ── Aufbau ──
    const auf = await p.evaluate(() => ({ sek: [...document.querySelectorAll('.ga44-bogen .ga44-sek h4')].map(x => x.textContent.trim()), herSicht: [...document.querySelectorAll('.ga44-bogen .ga43-her')].filter(x => x.offsetParent).length, alle: !!document.querySelector('details.ga44-alle:not([open]) .ga43'), dach: document.querySelectorAll('.ga44-bogen .ga44-dt').length, logo: document.querySelector('.sb-logo') ? document.querySelector('.sb-logo').textContent : '' }));
    ok(auf.sek.length === 9 && /1\. Das Gebäude/.test(auf.sek[0]) && /9\. Nutzung und Rechtliches/.test(auf.sek[8]), g + ': Erfassung in 9 Abschnitten wie der Fragebogen (' + auf.sek.length + ')');
    ok(auf.herSicht === 0 && auf.alle, g + ': Quellen-Knöpfe ausgeblendet, Gutachten-Detailfelder zugeklappt darunter');
    ok(auf.dach === 9, g + ': Dachform mit 9 Bildern im Abschnitt „Das Gebäude“');
    ok(/v(4[4-9]|[5-9]\d)/.test(auf.logo) || g === 'handy', g + ': Version ab v44 (' + auf.logo + ')');
    await p.click('.ga44-bogen .ga44-dt[data-o="Walmdach"]'); await p.waitForTimeout(300);
    ok((await E()).werte.k_dachform.v === 'Walmdach' && await p.evaluate(() => !!document.querySelector('.ga44-bogen .ga44-dach-klein img')), g + ': Dachform per Bild gewählt → Walmdach, kleines Bild bleibt stehen');
    // virtueller Platz: Fenstergruppe 2 erst beim Tippen anlegen, jeder Tastendruck im selben Eintrag
    await p.fill('.ga44-bogen [data-g43="g:fenster:~1:bereich_fenstergruppe"][data-m="v"]', 'EG');
    await p.type('.ga44-bogen [data-g43="g:fenster:~1:bereich_fenstergruppe"][data-m="v"]', ' und OG'); await p.waitForTimeout(500);
    let e = await E();
    ok(e.gruppen43.fenster.length === 1 && e.gruppen43.fenster[0].w.bereich_fenstergruppe.v === 'EG und OG', g + ': Fenstergruppe 1 entsteht beim ersten Tippen – genau ein Eintrag');
    await p.selectOption('.ga44-bogen [data-g43="g:modernisierungen:~1:bauteil_massnahme"]', 'Heizung'); await p.waitForTimeout(300);
    await p.fill(`.ga44-bogen [data-g43^="g:modernisierungen:"][data-g43$=":jahr_der_massnahme"] >> nth=0`, '2019'); await p.waitForTimeout(500);
    e = await E();
    ok(e.gruppen43.modernisierungen.length === 1 && e.gruppen43.modernisierungen[0].w.bauteil_massnahme.v.join() === 'Heizung' && e.gruppen43.modernisierungen[0].w.jahr_der_massnahme.v === '2019', g + ': Modernisierung Zeile 1: Heizung 2019 (Mehrfachfeld als Einzelauswahl)');
    await p.check('.ga44-q input'); await p.waitForTimeout(300);
    ok(await p.evaluate(() => [...document.querySelectorAll('.ga44-bogen .ga43-her')].filter(x => x.offsetParent).length > 20), g + ': „Quellen zeigen“ blendet die Herkunft wieder ein');
    await p.uncheck('.ga44-q input'); await p.waitForTimeout(300);
    // ── PDF erstellen ──
    await p.click('.ga44-knoepfe button:has-text("Fragebogen als PDF")'); await p.waitForTimeout(2500);
    const pdf = await p.evaluate(() => window.__pdf && { name: window.__pdf.name, n: window.__pdf.b64.length });
    ok(pdf && /^Objekt-Fragebogen EFH Königsheideweg\.pdf$/.test(pdf.name) && pdf.n > 100000, g + ': PDF erstellt und gespeichert: ' + (pdf && pdf.name));
    // ausfüllen wie ein Eigentümer
    const gefuellt = await p.evaluate(async () => {
      const P = window.PDFLib, d = await P.PDFDocument.load(ga44Bytes(window.__pdf.b64)), fo = d.getForm();
      const info = { felder: fo.getFields().length, kw: d.getKeywords(), art: fo.getDropdown('@art').getSelected()[0], adr: fo.getTextField('@objekt').getText() };
      fo.getDropdown('w|k_dachform').select('Satteldach');
      fo.getTextField('w|wfl').setText('150');
      fo.getTextField('w|grund').setText('716');
      fo.getTextField('w|baujahr').setText('2009');
      fo.getDropdown('w|k_tragende_bauweise').select('Massivbau');
      fo.getCheckBox('w|k_bodenbelaege|0').check(); fo.getCheckBox('w|k_bodenbelaege|4').check();
      fo.getDropdown('g|fenster|2|verglasung_scheibenanzahl').select('Dreifach verglast (3-fach)');
      fo.getTextField('g|fenster|2|bereich_fenstergruppe').setText('DG');
      fo.getDropdown('g|heizungen|1|versorgungsart').select('Zentralheizung');
      fo.getCheckBox('g|heizungen|1|energietraeger|0').check();
      fo.getDropdown('g|modernisierungen|2|bauteil_massnahme').select('Fenster');
      fo.getTextField('g|modernisierungen|2|jahr_der_massnahme').setText('2021');
      fo.getDropdown('w|nutzung').select('Eigengenutzt');
      fo.getTextField('@wunsch').setText('798.000');
      fo.getTextField('@notiz').setText('Garten 2024 neu angelegt.');
      fo.getTextField('@name').setText('Max Mustermann'); fo.getTextField('@datum').setText('18.11.2026');
      fo.getCheckBox('@unterlagen|0').check();
      return { info, b64: ga44B64(await d.save()) };
    });
    ok(gefuellt.info.felder > 230 && /MaklerCockpit-Fragebogen/.test(gefuellt.info.kw) && /obj:k1/.test(gefuellt.info.kw) && gefuellt.info.art === 'Einfamilienhaus' && /Königsheideweg 190/.test(gefuellt.info.adr), g + ': PDF: ' + gefuellt.info.felder + ' Felder, Objektart und Adresse vorbelegt, Kennung für das Objekt');
    // ── einlesen ──
    await p.evaluate(b64 => ga44EinlesenBytes(ga44Bytes(b64)), gefuellt.b64); await p.waitForTimeout(800);
    e = await E();
    const modal = await p.evaluate(() => document.getElementById('modalInner').innerText);
    ok(e.werte.grund.v === '716' && e.werte.grund.q === 'Eigentümerangabe' && e.werte.grund.p === 'Ungeprüfte Angabe' && e.werte.k_tragende_bauweise.v === 'Massivbau' && e.werte.nutzung.v === 'Eigengenutzt', g + ': Werte übernommen als „Eigentümerangabe, ungeprüft“');
    ok(e.werte.k_bodenbelaege.v.join() === 'Parkett,Fliesen' || e.werte.k_bodenbelaege.v.length === 2, g + ': Kästchen → Mehrfachauswahl (' + e.werte.k_bodenbelaege.v.join() + ')');
    ok(e.werte.wfl.v === '164' && e.werte.k_dachform.v === 'Walmdach' && /Wohnfläche/.test(modal) && /Dachform/.test(modal) && /150/.test(modal), g + ': Abweichungen (Wohnfläche 164↔150, Dachform Walm↔Sattel) NICHT überschrieben, im Dialog gelistet');
    ok(e.gruppen43.fenster.length === 2 && e.gruppen43.fenster[1].w.verglasung_scheibenanzahl.v === 'Dreifach verglast (3-fach)' && e.gruppen43.fenster[0].w.bereich_fenstergruppe.v === 'EG und OG', g + ': Fenstergruppe 2 aus dem PDF ergänzt, Gruppe 1 unverändert');
    ok(e.gruppen43.heizungen[0].w.energietraeger.v.join() === 'Erdgas' && e.gruppen43.modernisierungen.length === 2 && e.gruppen43.modernisierungen[1].w.bauteil_massnahme.v.join() === 'Fenster', g + ': Heizung (Erdgas) und Modernisierung Zeile 2 (Fenster 2021) übernommen');
    ok(e.werte.wunsch && e.werte.wunsch.v === '798.000' && /Garten 2024/.test(e.notiz) && /bereitstellen: Exposé/.test(e.notiz) && !/Mustermann/.test(e.notiz) && e.fragebogen.name === 'Max Mustermann', g + ': Preisvorstellung, Hinweis und Unterlagen in Notizen – Name nur am Entwurf');
    await p.evaluate(() => ga43PreisKopieren()); await p.waitForTimeout(300);
    const pt = await p.evaluate(() => window.__kopie || '');
    ok(!/Mustermann/.test(pt) && /Grundstücksfläche: 716 m² \[Eigentümerangabe\]/.test(pt), g + ': Preis-Prompt enthält Eigentümerangaben, aber keinen Namen');
    // Abweichungen übernehmen
    await p.evaluate(() => ga44ErgebnisDialog(0, 0)); await p.waitForTimeout(200);
    await p.click('#modalBg button:has-text("Alle markieren")'); await p.click('#modalBg button:has-text("Markierte übernehmen")'); await p.waitForTimeout(400);
    e = await E();
    ok(e.werte.wfl.v === '150' && e.werte.wfl.alt === '164' && e.werte.k_dachform.v === 'Satteldach', g + ': Markierte Abweichungen übernommen, alter Wert gemerkt');
    // falsches Objekt / fremde PDF
    await p.evaluate(() => { GA35.obj = 'k2'; ga35Neuzeichnen(); });
    await p.evaluate(b64 => ga44EinlesenBytes(ga44Bytes(b64)), gefuellt.b64); await p.waitForTimeout(300);
    ok(await p.evaluate(() => /für „EFH Königsheideweg“ erstellt/.test(document.body.innerText)), g + ': Fragebogen eines anderen Objekts → Rückfrage');
    const fremd = await p.evaluate(async () => { const d = await PDFLib.PDFDocument.create(); d.addPage(); try{ await ga44EinlesenBytes(await d.save()); return 'kein Fehler'; }catch(err){ return err.message; } });
    ok(/kein MaklerCockpit-Fragebogen/.test(fremd), g + ': Fremdes PDF wird abgelehnt');
    if(g === 'handy'){
      await p.evaluate(() => { try{ schliesseModal(); }catch(e){} GA35.obj = 'k1'; ga35Neuzeichnen(); });
      const ov = await p.evaluate(() => [...document.querySelectorAll('.ga44-bogen .ga43-feld, .ga44-zeile')].filter(el => el.offsetParent && el.getBoundingClientRect().right > window.innerWidth + 1).length);
      ok(ov === 0, g + ': nichts ragt über den Bildschirmrand (' + ov + ')');
      for(const [sel, n] of [['.ga44-bogen', 'handy_bogen1'], ['.ga44-bogen .ga44-sek:nth-of-type(6)', 'handy_bogen_modern']]){ await p.evaluate(s => document.querySelector(s).scrollIntoView(), sel); await p.waitForTimeout(200); await p.screenshot({ path: `/tmp/v44/${n}.png` }); }
    } else {
      await p.evaluate(() => { try{ schliesseModal(); }catch(e){} GA35.obj = 'k1'; ga35Neuzeichnen(); document.querySelector('.ga44-bogen').scrollIntoView(); }); await p.waitForTimeout(200);
      await p.screenshot({ path: '/tmp/v44/pc_bogen1.png' });
    }
    ok(p.fe.length === 0, g + ': keine Fehler ' + p.fe.join(' | '));
    await p.close();
  }
  await b.close();
  console.log(f ? `${f} FEHLER` : 'ALLES OK'); process.exit(f ? 1 : 0);
})();
