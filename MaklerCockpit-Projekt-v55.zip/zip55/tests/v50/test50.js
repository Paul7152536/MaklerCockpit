// v50: doppelte Inserate – erkennen, beim Import verhindern, vorhandene zusammenführen
const { chromium } = require('playwright');
let f = 0; const ok = (b, t) => { console.log((b ? 'ok   ' : 'FEHL ') + t); if(!b) f++; };
const T = 864e5, jetzt = Date.now();
const lead = (id, x) => Object.assign({ id, objektart: 'Wohnung', ort: '12555 Berlin', status: 'neu', quelle: 'Kleinanzeigen', createdAt: jetzt - 5 * T, verlauf: [{ ts: jetzt - 5 * T, typ: 'import', text: 'Import ' + id }] }, x);
const KA = 'https://www.kleinanzeigen.de/s-anzeige/dachgeschoss-zum-ausbau-berlin/3212345678-196-3401';
const SUCHE = 'https://www.kleinanzeigen.de/s-wohnung-kaufen/berlin/c196l3331';
const D = JSON.stringify({ objekte: [
  lead('a', { akqTitel: 'Dachgeschoss zum Ausbau Berlin', link: KA, status: 'termin', verlauf: [{ ts: jetzt - 4 * T, typ: 'notiz', text: 'Eigene Notiz A' }, { ts: jetzt - 3 * T, typ: 'termin', text: 'Termin' }] }),
  lead('a_2', { akqTitel: 'Dachgeschoss zum Ausbau Berlin', link: 'https://kleinanzeigen.de/s-anzeige/dachgeschoss/3212345678-196-3401?utm_source=x', verkaeuferTelefon: '0151 17460378', kaufpreis: 139000, notizen: 'Notiz vom Handy', verlauf: [{ ts: jetzt - 2 * T, typ: 'notiz', text: 'Notiz am Handy' }] }),
  lead('b1', { akqTitel: 'Wohnung 1 vom gleichen Verkäufer', link: 'https://www.kleinanzeigen.de/s-anzeige/wohnung-1/3200000001-196-3401', verkaeuferTelefon: '0160 1111111' }),
  lead('b2', { akqTitel: 'Wohnung 2 vom gleichen Verkäufer', link: 'https://www.kleinanzeigen.de/s-anzeige/wohnung-2/3200000002-196-3401', verkaeuferTelefon: '0160 1111111' }),
  lead('s1', { akqTitel: 'Erste Wohnung aus der Suche', link: SUCHE }),
  lead('s2', { akqTitel: 'Zweite Wohnung aus der Suche', link: SUCHE }),
  lead('z1', { akqTitel: 'Einfamilienhaus mit großem Garten', quelle: 'Zeitung', objektart: 'EFH', verkaeuferTelefon: '030 1234567', link: '' }),
  lead('z2', { akqTitel: 'Einfamilienhaus mit großem Garten', quelle: 'Zeitung', objektart: 'EFH', verkaeuferTelefon: '030 1234567', link: '', createdAt: jetzt - T }),
  lead('i1', { akqTitel: 'ImmoScout Wohnung', link: 'https://www.immobilienscout24.de/expose/150000001#/' }),
  lead('i2', { akqTitel: 'ImmoScout Wohnung', link: 'https://immobilienscout24.de/expose/150000001?referrer=RESULT_LIST' })],
  kontakte: [], aufgaben: [{ id: 'au1', titel: 'Unterlagen', objektId: 'a_2', status: 'offen' }], notizen: [],
  termine: [{ id: 't1', titel: 'Besichtigung', datum: '2026-12-01', uhrzeit: '10:00', art: 'besichtigung', wo: 'vorort', objektId: 'a_2' }],
  analysen24: [{ id: 'an1', objektId: 'a_2', erstellt: jetzt }], grossanalyse: { entwuerfe: { a_2: { art: 'ETW', werte: {} } }, laeufe: [] },
  meta: { v9neustart: { quittiert: true } } });
(async () => {
  const b = await chromium.launch();
  for(const [g, w, h] of [['pc', 1440, 900], ['handy', 412, 915]]){
    const p = await b.newPage({ viewport: { width: w, height: h }, isMobile: g === 'handy' });
    p.fe = []; p.on('pageerror', e => p.fe.push(e.message));
    await p.addInitScript(([d, g]) => { window.pc = { geraet: g, laden: () => JSON.parse(d), speichern: () => ({ ok: true }), ordner(){}, sicherungSchreiben: () => ({ ok: true }), sicherungLesen: () => null }; }, [D, g]);
    await p.goto('file:///tmp/pc/app/index.html'); await p.waitForTimeout(2800);
    await p.evaluate(() => { try{ schliesseModal(); }catch(e){} const k = document.getElementById('an31Karte'); if(k) k.remove(); });
    const r = await p.evaluate(() => ({ ids: db.objekte.map(o => o.id).sort().join(), a: findObjekt('a'), t1: db.termine.find(t => t.id === 't1').objektId, au: db.aufgaben[0].objektId, an: db.analysen24[0].objektId, ga: Object.keys(db.grossanalyse.entwuerfe).join() }));
    ok(r.ids === 'a,b1,b2,i1,s1,s2,z1', g + ': Doppel zusammengeführt, verschiedene Inserate bleiben (' + r.ids + ')');
    ok(r.a.status === 'termin' && r.a.verkaeuferTelefon === '0151 17460378' && r.a.kaufpreis === 139000 && r.a.link.includes('www.kleinanzeigen.de'), g + ': behalten wird der weitere Lead, fehlende Angaben ergänzt');
    ok(['Eigene Notiz A', 'Notiz am Handy'].every(x => r.a.verlauf.some(v => v.text === x)) && /Notiz vom Handy/.test(r.a.notizen) && r.a.verlauf.some(v => /Doppeltes Inserat/.test(v.text)), g + ': Verlauf und Notizen beider Doppel erhalten');
    ok(r.t1 === 'a' && r.au === 'a' && r.an === 'a' && r.ga === 'a', g + ': Termin, Aufgabe, Analyse und Große Analyse hängen am behaltenen Lead (' + [r.t1, r.au, r.an, r.ga] + ')');
    // ── Import ──
    const imp = await p.evaluate(() => {
      const vor = db.objekte.length;
      const r1 = akqUebernehmen([{ titel: 'Dachgeschoss zum Ausbau Berlin', ort: '12555 Berlin', objektart: 'Wohnung', link: 'https://m.kleinanzeigen.de/s-anzeige/3212345678-196-3401?ref=abc', quelle: 'Kleinanzeigen' }], 'test');
      const n1 = db.objekte.length - vor;
      const r2 = akqUebernehmen([{ titel: 'Wohnung 3 vom gleichen Verkäufer', ort: '12555 Berlin', objektart: 'Wohnung', telefon: '0160 1111111', link: 'https://www.kleinanzeigen.de/s-anzeige/wohnung-3/3200000003-196-3401', quelle: 'Kleinanzeigen' }], 'test');
      const n2 = db.objekte.length - vor - n1;
      const r3 = akqUebernehmen([{ titel: 'Neue Wohnung Treptow X', ort: '12435 Berlin', objektart: 'Wohnung', preis: 300000, link: 'https://www.kleinanzeigen.de/s-anzeige/neu/3299999999-196-3401' }, { titel: 'Neue Wohnung Treptow X', ort: '12435 Berlin', objektart: 'Wohnung', preis: 300000, telefon: '0170 5555555', link: 'https://kleinanzeigen.de/s-anzeige/3299999999-196-3401?utm=1' }], 'test');
      const n3 = db.objekte.length - vor - n1 - n2;
      const neu = db.objekte.find(o => /3299999999/.test(o.link));
      const r4 = akqUebernehmen([{ titel: 'Dritte Wohnung aus der Suche', ort: '12555 Berlin', objektart: 'Wohnung', link: 'https://www.kleinanzeigen.de/s-wohnung-kaufen/berlin/c196l3331' }], 'test');
      const n4 = db.objekte.length - vor - n1 - n2 - n3;
      return { n1, d1: r1.doppelt, n2, n3, d3: r3.doppelt, tel: neu && neu.verkaeuferTelefon, n4 };
    });
    ok(imp.n1 === 0 && imp.d1 === 1, g + ': gleiches Inserat mit anderem Link → „schon bekannt“, kein neuer Lead');
    ok(imp.n2 === 1, g + ': weiteres Inserat desselben Verkäufers → eigener Lead');
    ok(imp.n3 === 1 && imp.d3 === 1 && imp.tel === '0170 5555555', g + ': zweimal im selben Einfügen → ein Lead, Angaben ergänzt');
    ok(imp.n4 === 1, g + ': Such-/Listenlink ist kein Erkennungsmerkmal → eigener Lead');
    await p.waitForTimeout(500);
    ok(await p.evaluate(() => db.objekte.length === new Set(db.objekte.map(o => dl50Key(o) || o.id)).size), g + ': nach dem Speichern keine Doppel');
    await p.evaluate(() => wechsleAnsicht('akquise')); await p.waitForTimeout(300);
    ok(!p.fe.length, g + ': keine JS-Fehler ' + p.fe.slice(0, 3).join(' | '));
    await p.close();
  }
  await b.close(); console.log(f ? 'FEHLER ' + f : 'ALLES OK'); process.exit(f ? 1 : 0);
})();
