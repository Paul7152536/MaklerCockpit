// v51: KI-Suche unter Jarvis, Marketing lädt (eingebettet, Speicher, Reiter)
const { chromium } = require('playwright');
let f = 0; const ok = (b, t) => { console.log((b ? 'ok   ' : 'FEHL ') + t); if(!b) f++; };
const D = JSON.stringify({ objekte: [{ id: 'o1', akqTitel: 'Testwohnung Köpenick', adresse: 'Teststr. 1', ort: '12555 Berlin', objektart: 'Wohnung', status: 'auftrag', kaufpreis: 300000, wohnflaeche: 70 }], kontakte: [], termine: [], aufgaben: [], notizen: [], meta: { v9neustart: { quittiert: true } } });
(async () => { const b = await chromium.launch();
  for(const [g, w, h] of [['pc', 1440, 900], ['handy', 412, 915]]){
    const p = await b.newPage({ viewport: { width: w, height: h }, isMobile: g === 'handy' });
    const fe = []; p.on('pageerror', e => fe.push(e.message));
    await p.addInitScript(([d, g]) => { window.pc = { geraet: g, laden: () => JSON.parse(d), speichern: () => ({ ok: true }), ordner(){}, sicherungSchreiben: () => ({ ok: true }), sicherungLesen: () => null }; }, [D, g]);
    await p.goto('file:///tmp/pc/app/index.html'); await p.waitForTimeout(2500);
    await p.evaluate(() => { try{ schliesseModal(); }catch(e){} const k = document.getElementById('an31Karte'); if(k) k.remove(); });
    const nav = await p.evaluate(() => NAV.filter(n => n.key).map(n => n.key + ':' + n.label));
    const ij = nav.indexOf('jarvis:Jarvis');
    ok(ij >= 0 && nav[ij + 1] === 'jv-suchen:KI-Suche' && !nav.some(x => /Investment-Suchen/.test(x)), g + ': „KI-Suche“ direkt unter Jarvis (' + nav.slice(ij, ij + 3).join(', ') + ')');
    await p.evaluate(() => wechsleAnsicht('marketing')); await p.waitForTimeout(3500);
    const fr = p.frame({ name: 'marketingFrame' }) || p.frames().find(x => x !== p.mainFrame() && /Marketing-Hub/.test(x.url() + ''));
    const info = await p.evaluate(() => { const f = document.getElementById('marketingFrame'), d = f.contentDocument; return { src: f.getAttribute('src'), srcdoc: (f.srcdoc || '').length, hub: !!(f.contentWindow && f.contentWindow.__hub), tab: !!(d && d.body.classList.contains('ih-tabmodus')), sichtbar: d ? Array.from(d.querySelectorAll('.card')).filter(c => c.offsetHeight > 0).map(c => c.id) : [], text: d ? d.body.innerText.slice(0, 600) : '', hoehe: f.offsetHeight }; });
    ok(!info.src && info.srcdoc > 1000000 && info.hub && info.hoehe > 400, g + ': Marketing-Tool eingebettet und geladen (' + info.hoehe + ' px)');
    ok(info.tab && info.sichtbar.join() === 's0', g + ': Reiter-Modus aktiv, nur „Objekte“ sichtbar (' + info.sichtbar.join() + ')');
    ok(!/Speichern ist in diesem Browser nicht verfügbar/.test(info.text), g + ': Speichern im Marketing-Tool funktioniert');
    for(const [sec, wort] of [['s4', 'Content erzeugen'], ['s6', 'Meine Videos'], ['s7', 'Post'], ['s8', 'Trend'], ['s9', 'Einstellungen']]){
      await p.evaluate(s => document.querySelector(`#marketingTabs [data-sec="${s}"]`).click(), sec); await p.waitForTimeout(250);
      const v = await p.evaluate(() => { const d = document.getElementById('marketingFrame').contentDocument; const s = Array.from(d.querySelectorAll('.card')).filter(c => c.offsetHeight > 0); return s.map(c => c.id + ':' + (c.querySelector('h2') || {}).textContent).join(' | '); });
      ok(v.split(' | ').length === 1 && v.startsWith(sec) && new RegExp(wort, 'i').test(v), g + ': Reiter ' + sec + ' zeigt „' + v + '“');
    }
    await p.evaluate(() => { marketingObjektGewaehlt('o1'); }); await p.waitForTimeout(500);
    const pre = await p.evaluate(() => { const hub = document.getElementById('marketingFrame').contentWindow.__hub; return hub && hub.state && hub.state.d ? [hub.state.d.ort, hub.state.d.preis] : null; });
    ok(pre && /Berlin/.test(pre[0]) && pre[1] === '300.000', g + ': Objekt wählen füllt das Marketing-Tool vor (' + JSON.stringify(pre) + ')');
    if(g === 'handy') await p.screenshot({ path: '/tmp/v51/test51_handy.png' });
    await p.evaluate(() => wechsleAnsicht('jv-suchen')); await p.waitForTimeout(800);
    ok(await p.evaluate(() => getComputedStyle(document.getElementById('marketingOverlay')).display === 'none' && aktuelleAnsicht === 'jv-suchen'), g + ': KI-Suche öffnet, Marketing zu');
    ok(!fe.length, g + ': keine JS-Fehler ' + fe.slice(0, 3).join(' | '));
    await p.close();
  } await b.close(); console.log(f ? 'FEHLER ' + f : 'ALLES OK'); process.exit(f ? 1 : 0); })();
