// v25 Abnahme im Browser: Verbund (Name/Telefon), Mietvergleich, Abgleich PC ↔ Handy mit simulierter Google-Brücke
const { chromium } = require('playwright');
const fs = require('fs'), vm = require('vm');
let f = 0; const ok = (b, t) => { console.log((b ? 'ok   ' : 'FEHL ') + t); if(!b) f++; };
function server(){
  const props = {}, dateien = {}, ordner = {}; let nid = 1;
  const api = id => ({ getId: () => id, getBlob: () => ({ getDataAsString: () => dateien[id].inhalt }), setContent: c => { dateien[id].inhalt = c; }, getSize: () => dateien[id].inhalt.length });
  const ordnerApi = id => ({ getId: () => id, getFilesByName: n => { const l = Object.values(dateien).filter(d => d.ordner === id && d.name === n); let i = 0; return { hasNext: () => i < l.length, next: () => api(l[i++].id) }; }, createFile: (n, c) => { const fid = 'f' + nid++; dateien[fid] = { id: fid, name: n, inhalt: c, ordner: id }; return api(fid); } });
  const ctx = { PropertiesService: { getScriptProperties: () => ({ getProperty: k => props[k] || null, setProperty: (k, v) => { props[k] = v; } }) },
    DriveApp: { getFolderById: id => { if(!ordner[id]) throw new Error('weg'); return ordnerApi(id); }, getFoldersByName: n => { const l = Object.values(ordner).filter(o => o.name === n); let i = 0; return { hasNext: () => i < l.length, next: () => ordnerApi(l[i++].id) }; }, createFolder: n => { const id = 'o' + nid++; ordner[id] = { id, name: n }; return ordnerApi(id); }, getFileById: id => { if(!dateien[id]) throw new Error('weg'); return api(id); } },
    LockService: { getScriptLock: () => ({ tryLock: () => true, releaseLock: () => {} }) }, ContentService: { createTextOutput: s => ({ s, setMimeType(){ return this; } }), MimeType: { JSON: 'json' } },
    UrlFetchApp: { fetch: () => ({ getResponseCode: () => 200, getContentText: () => '{"items":[]}' }) }, ScriptApp: { getOAuthToken: () => 't' }, CalendarApp: { getDefaultCalendar: () => ({ getId: () => 'p@x.de' }) }, JSON, Date, Math, Object, Number, String };
  vm.createContext(ctx); vm.runInContext(fs.readFileSync('/tmp/jvb/bruecke_v2.gs', 'utf8').replace('%%SCHLUESSEL%%', 'k'), ctx);
  return p => JSON.parse(ctx.doPost({ postData: { contents: JSON.stringify(Object.assign({ key: 'k' }, p)) } }).s);
}
const HEUTE = new Date().toISOString().slice(0, 10);
const FIX = { objekte: [{ id: 'o1', createdAt: 1, akqTitel: 'Helle 3-Zimmer-Wohnung', objektart: 'Wohnung', adresse: 'Musterstraße 12', ort: '10365 Berlin-Lichtenberg', status: 'termin', kaufpreis: 349000, wohnflaeche: 75, baujahr: '1995', verkaeuferName: 'Frau Krüger', verkaeuferTelefon: '0171 2223334', eigentuemerId: 'k1', verlauf: [], quelle: 'Kleinanzeigen' },
    { id: 'o2', createdAt: 2, akqTitel: 'ETW vermietet', objektart: 'Wohnung', ort: '10365 Berlin', status: 'neu', kaufpreis: 189000, wohnflaeche: 60, baujahr: '1965', verkaeuferName: 'Herr Lange', verkaeuferTelefon: '0152 777888', verlauf: [], quelle: 'Kleinanzeigen' },
    { id: 'o3', createdAt: 3, akqTitel: 'Haus Falkensee', objektart: 'Wohnung', ort: '14612 Falkensee', status: 'neu', wohnflaeche: 80, verlauf: [], quelle: 'Zeitung' }],
  kontakte: [{ id: 'k1', createdAt: 1, name: 'Petra Krüger', telefon: '0171 2223334', email: '', kontaktart: 'eigentuemer', status: 'lead', prioritaet: 'mittel', notizen: '' },
    { id: 'k9', createdAt: 1, name: 'Klaus Kunde', telefon: '0160 555', email: 'kk@x.de', kontaktart: 'kaeufer', status: 'interessent', prioritaet: 'mittel', notizen: '' },
    { id: 'kh', createdAt: 1, name: 'HV Nord GmbH', telefon: '030 111', email: '', kontaktart: 'hausverwaltung', organisation: true, koop: { status: 'kontaktiert', hvId: 'h1' } }],
  termine: [{ id: 't1', createdAt: 1, titel: 'Rückruf Frau Krüger', datum: HEUTE, uhrzeit: '14:00', dauer: 30, art: 'rueckruf', objektId: 'o1', wo: 'telefon', ort: 'Telefon 0171 2223334', googleEventId: 'g1', gHash: 'alt' }],
  aufgaben: [{ id: 'a1', titel: 'Frau Krüger anrufen 0171 2223334', faellig: HEUTE, prioritaet: 'mittel', objektId: 'o1', kontaktId: null, status: 'offen', notiz: '' }],
  gesuche: [{ id: 'g1', name: 'Klaus Kunde', telefon: '0160 555', email: 'kk@x.de', kontaktId: 'k9', arten: ['Wohnung'], orte: [], nutzung: 'kauf' }],
  hv: { verwaltungen: [{ id: 'h1', name: 'HV Nord GmbH', telefon: '030 111', status: 'offen' }], dupIgnore: [] },
  notizen: [], marktanalysen: [], mentorFragen: [], meta: { v9neustart: { quittiert: true } } };
async function seite(b, geraet, start, senden){
  const p = await b.newPage(geraet === 'handy' ? { viewport: { width: 412, height: 915 }, isMobile: true, hasTouch: true } : { viewport: { width: 1500, height: 950 } });
  const fe = []; p.on('pageerror', e => fe.push(e.message)); p.on('dialog', d => d.accept());
  await p.exposeFunction('__senden', x => senden(x));
  await p.addInitScript(([geraet, start]) => {
    const key = 'mc25_' + geraet;
    const lade = () => { try{ return JSON.parse(sessionStorage.getItem(key) || 'null'); }catch(e){ return null; } };
    window.pc = { geraet, laden: () => lade() || (start ? JSON.parse(JSON.stringify(start)) : null), speichern: t => { sessionStorage.setItem(key, t); return { ok: true }; }, importieren: t => { sessionStorage.setItem(key, t); return { ok: true }; },
      ordner(){}, sicherungSchreiben: () => ({ ok: true }), sicherungLesen: () => null, zwischenablage: async () => '', abruf: async () => ({ ok: false }),
      abgleichStand: (a, t) => { if(a === 'lesen') return sessionStorage.getItem(key + '_st'); if(a === 'schreiben'){ sessionStorage.setItem(key + '_st', t); return { ok: true }; } if(a === 'loeschen'){ sessionStorage.removeItem(key + '_st'); return { ok: true }; } },
      google: async (a, x) => { if(a === 'status') return { ok: true, modus: 'skript', verbunden: geraet !== 'handy' || sessionStorage.getItem('gekoppelt') === '1', email: 'p@x.de' }; if(a === 'abgleich') return await window.__senden(x); if(a === 'kopplung') return { ok: true, code: 'MC1-' + 'eyJ1IjoiaHR0cHM6Ly9zY3JpcHQuZ29vZ2xlLmNvbS9tYWNyb3Mvcy9BS2Z5Y2J4eHh4eHh4eHh4eHh4eHgvZXhlYyIsImsiOiJrIn0' }; if(a === 'skriptSchluessel') return { ok: true, schluessel: 'k' }; if(a === 'api') return { ok: true, status: 200, data: { items: [] } }; return { ok: false }; },
      gekoppelt: () => sessionStorage.getItem('gekoppelt') === '1', koppeln: async c => { sessionStorage.setItem('gekoppelt', '1'); return { ok: true }; }, entkoppeln: () => sessionStorage.removeItem('gekoppelt') };
  }, [geraet, start]);
  await p.goto('file:///tmp/pc/app/index.html'); await p.waitForTimeout(2200);
  return { p, fe };
}
(async () => {
  const b = await chromium.launch();
  const senden = server();
  const { p: pc, fe: fePC } = await seite(b, 'pc', FIX, senden);
  // ── A) Verbund ──
  let r = await pc.evaluate(() => ({ n: findObjekt('o1').verkaeuferName, alt: (findObjekt('o1').vb25alt || {}).n, k: findKontakt('k1').name }));
  ok(r.n === 'Petra Krüger' && r.alt === 'Frau Krüger', 'Altbestand: Objekt zeigt den Kontaktnamen, alter Name gemerkt');
  await pc.evaluate(() => { oeffneObjektModal('o1'); });
  r = await pc.evaluate(() => ({ t: document.getElementById('m_verkaeufer_telefon').value, n: document.getElementById('m_verkaeufer_name').value, hinweis: /gelten überall/.test(document.getElementById('modalInner').innerText) }));
  ok(r.t === '0171 2223334' && r.n === 'Petra Krüger' && r.hinweis, 'Objekt-Dialog zeigt die Kontaktdaten mit Hinweis „gelten überall“');
  await pc.fill('#m_verkaeufer_telefon', '0176 9998887'); await pc.evaluate(() => speichereObjekt('o1')); await pc.waitForTimeout(500);
  r = await pc.evaluate(() => ({ k: findKontakt('k1').telefon, ort: db.termine[0].ort, auf: db.aufgaben[0].titel, gh: db.termine[0].gHash, aq: aqTel(findObjekt('o1')), quelle: (findKontakt('k1').quellen || {}).telefon, log: JSON.stringify(findObjekt('o1').verlauf || []) }));
  ok(r.k === '0176 9998887' && r.aq === '0176 9998887', 'Telefon im Objekt geändert → Kontakt und Akquise zeigen die neue Nummer');
  ok(r.ort === 'Telefon 0176 9998887' && r.auf === 'Frau Krüger anrufen 0176 9998887', 'Termin-Ort und Aufgabe mit alter Nummer aktualisiert');
  ok(r.gh === '' && /Kontaktdaten aktualisiert/.test(r.log) && /von Hand/.test(r.quelle || ''), 'Google-Termin wird neu übertragen, Verlauf und Quelle vermerkt');
  await pc.evaluate(() => { wechsleAnsicht('kontakte'); });
  // Kontakt-Dialog → Objekt
  await pc.evaluate(() => oeffneKontaktModal('k1')); await pc.fill('#m_telefon', '0176 1112223'); await pc.fill('#m_name', 'Petra Krüger-Hahn'); await pc.evaluate(() => speichereKontakt('k1')); await pc.waitForTimeout(400);
  r = await pc.evaluate(() => ({ o: findObjekt('o1').verkaeuferTelefon, n: findObjekt('o1').verkaeuferName, ort: db.termine[0].ort, an: aqName(findObjekt('o1')) }));
  ok(r.o === '0176 1112223' && r.n === 'Petra Krüger-Hahn' && r.ort === 'Telefon 0176 1112223' && r.an === 'Petra Krüger-Hahn', 'Kontakt geändert → Objekt, Akquise und Termin aktualisiert');
  // Neuer Name + Nummer ohne Kontakt → Kontakt angelegt
  await pc.evaluate(() => oeffneObjektModal('o2')); await pc.fill('#m_verkaeufer_telefon', '0152 7778889'); await pc.evaluate(() => speichereObjekt('o2')); await pc.waitForTimeout(400);
  r = await pc.evaluate(() => { const o = findObjekt('o2'); const k = o.eigentuemerId && findKontakt(o.eigentuemerId); return { k: k && k.name, t: k && k.telefon, rolle: (o.kontakte || []).some(x => x.kontaktId === o.eigentuemerId) }; });
  ok(r.k === 'Herr Lange' && r.t === '0152 7778889' && r.rolle, 'Nummer am Lead ohne Kontakt eingetragen → Kontakt „Herr Lange“ angelegt und verknüpft');
  // Nummer eines vorhandenen Kontakts → verknüpft statt doppelt
  const nK = await pc.evaluate(() => db.kontakte.length);
  await pc.evaluate(() => oeffneObjektModal('o3')); await pc.fill('#m_verkaeufer_name', 'Klaus Kunde'); await pc.fill('#m_verkaeufer_telefon', '0160555'); await pc.evaluate(() => speichereObjekt('o3')); await pc.waitForTimeout(400);
  r = await pc.evaluate(() => ({ id: findObjekt('o3').eigentuemerId, n: db.kontakte.length }));
  ok(r.id === 'k9' && r.n === nK, 'Gleiche Nummer wie vorhandener Kontakt → verknüpft, kein doppelter Kontakt');
  // Suchkunde + HV
  await pc.evaluate(() => { findKontakt('k9').telefon = '0160 999'; save(); }); await pc.waitForTimeout(500);
  r = await pc.evaluate(() => ({ g: db.gesuche[0].telefon, o3: findObjekt('o3').verkaeuferTelefon }));
  ok(r.g === '0160 999' && r.o3 === '0160 999', 'Kontakt-Nummer geändert → Suchkunde und Lead folgen');
  await pc.evaluate(() => { db.hv.verwaltungen[0].telefon = '030 222'; window.__HV_HOST.set(db.hv); }); await pc.waitForTimeout(500);
  r = await pc.evaluate(() => findKontakt('kh').telefon);
  ok(r === '030 222', 'Nummer im Hausverwaltungen-Modul geändert → Kooperations-Kontakt folgt');
  // Widerspruch (beide Seiten geändert) → Klärung
  await pc.evaluate(() => { findKontakt('k1').email = 'a@x.de'; findObjekt('o1').verkaeuferEmail = 'b@x.de'; vb25Abgleichen(); save(); });
  r = await pc.evaluate(() => ({ n: vb25Offen().length, h: tbHinweise().some(x => x.k === 'vb25') }));
  ok(r.n === 1 && r.h, 'Gleiches Feld an zwei Stellen unterschiedlich → Klärungspunkt mit Hinweis');
  await pc.evaluate(() => { vb25KlaerenDialog(); const c = vb25Offen()[0]; vb25Entscheiden(c.id, 'kopie'); });
  r = await pc.evaluate(() => ({ k: findKontakt('k1').email, o: findObjekt('o1').verkaeuferEmail, n: vb25Offen().length }));
  ok(r.k === 'b@x.de' && r.o === 'b@x.de' && r.n === 0, 'Klärung „Objekt/Lead“ gewählt → überall gleich');
  // ── B) Mietvergleich ──
  await pc.evaluate(() => { const o = findObjekt('o2'); an24Setzen ? an24Setzen(o, 'miete_ist', 600, { herkunft: 'eigentuemer' }) : null; if(!an24Wert(o, 'miete_ist')){ o.angaben = o.angaben || {}; o.angaben.miete_ist = { werte: [{ id: 'm1', wert: 600, herkunft: 'eigentuemer', pruef: 'ungeprueft' }], aktiv: 'm1' }; } o.angaben.vermietung = { werte: [{ id: 'v1', wert: 'vermietet', herkunft: 'eigentuemer', pruef: 'ungeprueft' }], aktiv: 'v1' }; save(); ob24Oeffnen('o2'); });
  await pc.waitForTimeout(400);
  r = await pc.evaluate(() => { const k = document.querySelector('.mv25-karte'); return { da: !!k, text: k ? k.innerText : '', chip: k && k.querySelector('.mv25-chip') ? k.querySelector('.mv25-chip').innerText : '' }; });
  ok(r.da && /10,00 €\/m²/.test(r.text) && /PLZ 10365[\s\S]*12,83/.test(r.text) && /Lichtenberg[\s\S]*13,33/.test(r.text), 'Objektakte: Ist 10,00 €/m², PLZ 10365 12,83 €/m², Bezirk Lichtenberg 13,33 €/m²');
  ok(/−?-?22 %|-22 %/.test(r.chip) && /unter dem Schnitt/.test(r.chip), 'Einstufung: 22 % unter dem Schnitt (Neuvermietung PLZ)');
  ok(/Mietspiegel 2026[\s\S]*je nach Wohnlage/.test(r.text), 'Mietspiegel 2026: Spanne je nach Wohnlage ohne Wohnlage');
  await pc.evaluate(() => mv25WohnlageSetzen('o2', 'mittel')); await pc.waitForTimeout(300);
  r = await pc.evaluate(() => { const res = mv25Rechnen(mv25AusObjekt(findObjekt('o2'))); return { qm: res.ms.qm, pot: res.potenzial558, text: document.querySelector('.mv25-karte').innerText }; });
  ok(r.qm > 5 && r.qm < 12 && /Wohnlage mittel/.test(r.text), `Mit Wohnlage mittel: Vergleichsmiete ${r.qm && r.qm.toFixed(2)} €/m²`);
  ok(r.pot ? /Erhöhung bis zur Vergleichsmiete/.test(r.text) : /bereits auf oder über/.test(r.text), 'Erhöhungspotenzial nach § 558 bzw. Hinweis „bereits auf/über Vergleichsmiete“');
  await pc.evaluate(() => { db.jarvis = db.jarvis || {}; db.jarvis.markt_gebiete = { be_li: { miete_m2: 14.1, stand: '11/2026', quelle: 'Testquelle' } }; renderMain(); });
  r = await pc.evaluate(() => { const res = mv25Rechnen(mv25AusObjekt(findObjekt('o2'))); return { b: res.ref.bezirk.m, j: res.ref.bezirk.jarvis, t: document.querySelector('.mv25-karte').innerText }; });
  ok(r.b === 14.1 && r.j && /über Jarvis aktualisiert/.test(r.t), 'Über Jarvis aufgefrischte Bezirksmiete hat Vorrang (mit Quelle)');
  r = await pc.evaluate(() => { const res = mv25Rechnen({ miete: 900, flaeche: 60, ort: '14612 Falkensee', objektart: 'Wohnung' }); return { l: res.lage.land, m: res.ref.angebot && res.ref.angebot.m, ms: res.ms.fehler }; });
  ok(r.l === 'BB' && r.m === 14.95 && /nur in Berlin/.test(r.ms), 'Brandenburg (Falkensee): Angebotsmiete aus den Jarvis-Marktdaten, kein Berliner Mietspiegel');
  r = await pc.evaluate(() => [mv25Lage('Berlin-Prenzlauer Berg').bezirk, mv25Lage('Berlin Wedding').bezirk, mv25Lage('Hohenschönhausen, Berlin').bezirk, mv25Lage('Berlin-Charlottenburg-Nord').bezirk]);
  ok(r.join('|') === 'Pankow|Mitte|Lichtenberg|Charlottenburg-Wilmersdorf', 'Ortsteile ohne PLZ werden dem Bezirk zugeordnet');
  await pc.evaluate(() => { const p = iv24Anlegen('o2', true); IV24.sel = p.id; wechsleAnsicht('investments24'); });
  await pc.waitForTimeout(400);
  ok(await pc.evaluate(() => !!document.querySelector('.ma24-haupt .mv25-karte')), 'Investments: Mietvergleich in der Prüfung');
  // ── C) Abgleich ──
  await pc.evaluate(() => ab25Einschalten()); await pc.waitForTimeout(2500);
  r = await pc.evaluate(() => ({ aktiv: ab25Aktiv(), st: ab25Stand().letzteZahlen, f: ab25Stand().fehler, kal: db.ab25Kalender }));
  ok(r.aktiv && r.st && r.st.gesendet > 10 && !r.f, `PC: Abgleich eingeschaltet, ${r.st && r.st.gesendet} Einträge hochgeladen`);
  await pc.evaluate(() => { ab25Dialog(true); }); await pc.waitForTimeout(400); await pc.evaluate(() => ab25KopplungZeigen()); await pc.waitForTimeout(300);
  ok(await pc.evaluate(() => !!document.querySelector('.ab25-qr svg') && /MC1-/.test(document.querySelector('.ab25-kopp textarea').value)), 'Kopplungscode mit QR-Code wird angezeigt');
  await pc.screenshot({ path: '/tmp/v25test/pc_abgleich.png' }); await pc.evaluate(() => schliesseModal());
  const { p: handy, fe: feH } = await seite(b, 'handy', null, senden);
  ok(await handy.evaluate(() => /Mit PC koppeln/.test(document.getElementById('modalInner').innerText)), 'Handy ohne Kopplung zeigt „Mit PC koppeln“');
  await handy.fill('#ab25Code', 'MC1-eyJ1IjoiaHR0cHM6Ly9zY3JpcHQuZ29vZ2xlLmNvbS9tYWNyb3Mvcy9BS2Z5Y2J4eHh4eHh4eHh4eHh4eHgvZXhlYyIsImsiOiJrIn0');
  await handy.evaluate(() => ab25Koppeln()); await handy.waitForTimeout(2500);
  r = await handy.evaluate(() => ({ o: db.objekte.length, k: db.kontakte.length, t: findKontakt('k1') && findKontakt('k1').telefon, ans: aktuelleAnsicht, hv: ((db.hv || {}).verwaltungen || []).length, kal: (db.googleSync || {}).kalenderId }));
  ok(r.o === 3 && r.k >= 4 && r.t === '0176 1112223' && r.hv === 1, `Handy gekoppelt: ${r.o} Objekte, ${r.k} Kontakte geholt`);
  await handy.screenshot({ path: '/tmp/v25test/handy_nach_kopplung.png' });
  // Handy ändert Nummer am Lead, legt Termin an
  await handy.evaluate(() => { oeffneObjektModal('o1'); });
  await handy.fill('#m_verkaeufer_telefon', '0171 5550001'); await handy.evaluate(() => speichereObjekt('o1')); await handy.waitForTimeout(300);
  await handy.evaluate(() => { db.termine.push({ id: 'tH', createdAt: Date.now(), titel: 'Besichtigung', datum: new Date().toISOString().slice(0, 10), uhrzeit: '17:00', dauer: 60, art: 'besichtigung', objektId: 'o2', wo: 'vorort' }); save(); });
  await handy.waitForTimeout(500); await handy.evaluate(() => ab25Sync('test')); await handy.waitForTimeout(800);
  r = await handy.evaluate(() => ({ tH: db.termine.find(t => t.id === 'tH').erstelltAuf, g: ab25Stand().geraet, darf: ab25DarfAnlegen(db.termine.find(t => t.id === 'tH')), imp: ab25ImportErlaubt() }));
  ok(r.tH === r.g && r.darf === true && r.imp === false, 'Handy-Termin gehört dem Handy (trägt ihn selbst in Google ein); Google-Import macht nur der PC');
  await pc.evaluate(() => ab25Sync('test')); await pc.waitForTimeout(1500);
  r = await pc.evaluate(() => ({ k: findKontakt('k1').telefon, o: findObjekt('o1').verkaeuferTelefon, ort: db.termine.find(t => t.id === 't1').ort, tH: db.termine.find(t => t.id === 'tH'), darf: ab25DarfAnlegen(db.termine.find(t => t.id === 'tH')) }));
  ok(r.k === '0171 5550001' && r.o === '0171 5550001' && r.ort === 'Telefon 0171 5550001', 'Nummer am Handy geändert → am PC in Kontakt, Lead und Termin');
  ok(r.tH && r.darf === false, 'PC trägt den frischen Handy-Termin nicht doppelt in Google ein');
  // PC ändert Notiz, Handy ändert Status desselben Leads → beides bleibt
  await pc.evaluate(() => { findObjekt('o2').notizen = 'Mieter seit 2012'; save(); }); await pc.waitForTimeout(400);
  await handy.evaluate(() => { findObjekt('o2').status = 'erstkontakt'; save(); }); await handy.waitForTimeout(400);
  await pc.evaluate(() => ab25Sync('test')); await pc.waitForTimeout(800); await handy.evaluate(() => ab25Sync('test')); await handy.waitForTimeout(800); await pc.evaluate(() => ab25Sync('test')); await pc.waitForTimeout(800);
  r = [await pc.evaluate(() => [findObjekt('o2').notizen, findObjekt('o2').status].join('|')), await handy.evaluate(() => [findObjekt('o2').notizen, findObjekt('o2').status].join('|'))];
  ok(r[0] === 'Mieter seit 2012|erstkontakt' && r[1] === r[0], 'Gleicher Lead auf beiden Geräten geändert → beide Änderungen auf beiden Geräten');
  // Neu laden: Stand bleibt (gespeichert)
  await handy.reload(); await handy.waitForTimeout(2500);
  r = await handy.evaluate(() => ({ aktiv: ab25Aktiv(), o: db.objekte.length, modal: document.getElementById('modalBg').classList.contains('show') }));
  ok(r.aktiv && r.o === 3 && !r.modal, 'Handy nach Neustart: gekoppelt, Daten da, kein Kopplungsdialog');
  await handy.screenshot({ path: '/tmp/v25test/handy_heute.png' });
  ok(fePC.length === 0 && feH.length === 0, 'Keine Fehler im Browser ' + JSON.stringify(fePC.concat(feH).slice(0, 3)));
  console.log('FEHLER', f);
  await b.close();
})();
