const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch();
  const p = await b.newPage({ viewport: { width: 412, height: 915 }, deviceScaleFactor: 1, isMobile: true, hasTouch: true });
  const fe = []; p.on('pageerror', e => fe.push(e.message));
  await p.addInitScript({ path: '/tmp/v25test/mock_pc.js' });
  await p.goto('file:///tmp/pc/app/index.html'); await p.waitForTimeout(2500);
  const shot = async n => { await p.waitForTimeout(400); await p.screenshot({ path: '/tmp/v25test/m_' + n + '.png' }); };
  const schritte = (process.argv[2] || 'heute,akquise,lead,termine,kontakte,objekt,menue,akte').split(',');
  for(const s of schritte){
    if(s === 'heute'){ await p.evaluate(() => wechsleAnsicht('heute')); await shot('heute'); }
    if(s === 'akquise'){ await p.evaluate(() => wechsleAnsicht('akquise')); await shot('akquise'); }
    if(s === 'lead'){ await p.evaluate(() => wechsleAnsicht('akquise')); await p.waitForTimeout(300); const z = await p.$('#aqListe [onclick]'); if(z) await z.click(); await shot('lead'); await p.evaluate(() => h25DetailZu()); }
    if(s === 'termine'){ await p.evaluate(() => wechsleAnsicht('termine')); await shot('termine'); }
    if(s === 'kontakte'){ await p.evaluate(() => wechsleAnsicht('kontakte')); await shot('kontakte'); }
    if(s === 'objekt'){ await p.evaluate(() => oeffneObjektModal('o1')); await shot('objekt'); await p.evaluate(() => schliesseModal()); }
    if(s === 'menue'){ await p.evaluate(() => h25Schublade(true)); await shot('menue'); await p.evaluate(() => h25Schublade(false)); }
    if(s === 'akte'){ await p.evaluate(() => ob24Oeffnen('o2')); await shot('akte'); }
    if(s === 'abschluss'){ await p.evaluate(() => ak24Abschluss({ objektId: 'o1' })); await shot('abschluss'); await p.evaluate(() => schliesseModal()); }
    if(s === 'abgleich'){ await p.evaluate(() => ab25Dialog()); await p.waitForTimeout(800); await shot('abgleich'); await p.evaluate(() => schliesseModal()); }
  }
  console.log(JSON.stringify(await p.evaluate(() => ({ breite: document.documentElement.scrollWidth }))), 'Fehler', fe);
  await b.close();
})();
