(() => {
    const heute = new Date().toISOString().slice(0, 10);
    const alt = { objekte: [{ id: 'o1', createdAt: Date.now() - 5e8, akqTitel: 'Helle 3-Zimmer-Wohnung', objektart: 'Wohnung', adresse: 'Musterstraße 12', ort: '10365 Berlin-Lichtenberg', status: 'termin', kaufpreis: 349000, wohnflaeche: 75, baujahr: '1995', zimmer: '3', verkaeuferName: 'Frau Krüger', verkaeuferTelefon: '0171 2223334', eigentuemerId: 'k1', verlauf: [], quelle: 'Kleinanzeigen' },
      { id: 'o2', createdAt: Date.now() - 2e8, akqTitel: 'ETW vermietet Spandau', objektart: 'Wohnung', ort: '13597 Berlin', status: 'neu', kaufpreis: 189000, wohnflaeche: 50, baujahr: '1965', verkaeuferName: 'Herr Lange', verkaeuferTelefon: '0152 777888', verlauf: [], quelle: 'Kleinanzeigen' }],
      kontakte: [{ id: 'k1', createdAt: 1, name: 'Petra Krüger', telefon: '0171 2223334', email: '', kontaktart: 'eigentuemer', status: 'lead', prioritaet: 'mittel', notizen: '' }],
      termine: [{ id: 't1', createdAt: 1, titel: 'Rückruf Frau Krüger', datum: heute, uhrzeit: '14:00', dauer: 30, art: 'rueckruf', objektId: 'o1', wo: 'telefon', ort: 'Telefon 0171 2223334' }], aufgaben: [{ id: 'a1', titel: 'Frau Krüger anrufen 0171 2223334', faellig: heute, prioritaet: 'mittel', objektId: 'o1', kontaktId: null, status: 'offen', notiz: '' }], notizen: [], marktanalysen: [], mentorFragen: [], meta: { v9neustart: { quittiert: true } } };
    let gespeichert = null;
    window.pc = { laden: () => JSON.parse(JSON.stringify(gespeichert || alt)), speichern: t => { gespeichert = JSON.parse(t); window.__gespeichert = gespeichert; return { ok: true }; }, ordner(){}, sicherungSchreiben: () => ({ ok: true }), sicherungLesen: () => null, zwischenablage: async () => '', abruf: async () => ({ ok: false }),
      abgleichStand: (a, t) => { if(a === 'lesen') return window.__stand || null; if(a === 'schreiben'){ window.__stand = t; return { ok: true }; } return { ok: true }; },
      google: async (a, x) => a === 'status' ? { ok: true, modus: 'skript', verbunden: true, email: 'p@x.de' } : a === 'abgleich' ? { ok: true, version: 2, abgleich: true } : { ok: false } };
})();
