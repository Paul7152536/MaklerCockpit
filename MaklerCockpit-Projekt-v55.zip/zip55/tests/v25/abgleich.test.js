// Test: Brücke v2 (Apps Script mit Attrappen) + Abgleich-Kern mit zwei Geräten
const fs = require('fs'), vm = require('vm');
const K = require(require('path').join(__dirname, '../../quellen/abgleich25_kern.js'));
let f = 0; const ok = (b, t) => { console.log((b ? 'ok   ' : 'FEHL ') + t); if(!b) f++; };
function server(){
  const props = {}; const dateien = {}; const ordner = {}; let nid = 1;
  const datei = (name, inhalt) => { const id = 'f' + nid++; dateien[id] = { id, name, inhalt }; return api(id); };
  const api = id => ({ getId: () => id, getBlob: () => ({ getDataAsString: () => dateien[id].inhalt }), setContent: c => { if(c.length > 10e6) throw new Error('zu groß'); dateien[id].inhalt = c; }, getSize: () => dateien[id].inhalt.length });
  const ordnerApi = id => ({ getId: () => id, getFilesByName: n => { const l = Object.values(dateien).filter(d => d.ordner === id && d.name === n); let i = 0; return { hasNext: () => i < l.length, next: () => api(l[i++].id) }; }, createFile: (n, c) => { const d = datei(n, c); dateien[d.getId()].ordner = id; return d; } });
  const ctx = {
    PropertiesService: { getScriptProperties: () => ({ getProperty: k => props[k] || null, setProperty: (k, v) => { props[k] = v; } }) },
    DriveApp: { getFolderById: id => { if(!ordner[id]) throw new Error('weg'); return ordnerApi(id); }, getFoldersByName: n => { const l = Object.values(ordner).filter(o => o.name === n); let i = 0; return { hasNext: () => i < l.length, next: () => ordnerApi(l[i++].id) }; }, createFolder: n => { const id = 'o' + nid++; ordner[id] = { id, name: n }; return ordnerApi(id); }, getFileById: id => { if(!dateien[id]) throw new Error('weg'); return api(id); } },
    LockService: { getScriptLock: () => ({ tryLock: () => true, releaseLock: () => {} }) },
    ContentService: { createTextOutput: s => ({ s, setMimeType(){ return this; } }), MimeType: { JSON: 'json' } },
    UrlFetchApp: { fetch: () => ({ getResponseCode: () => 200, getContentText: () => '{"items":[]}' }) }, ScriptApp: { getOAuthToken: () => 't' }, CalendarApp: { getDefaultCalendar: () => ({ getId: () => 'paul@example.org' }) },
    JSON, Date, Math, Object, Number, String
  };
  vm.createContext(ctx);
  vm.runInContext(fs.readFileSync(require('path').join(__dirname, '../../quellen/bruecke_v2.gs'), 'utf8').replace('%%SCHLUESSEL%%', 'geheim123'), ctx);
  let anfragen = 0;
  const senden = async p => { anfragen++; const r = ctx.doPost({ postData: { contents: JSON.stringify(Object.assign({ key: 'geheim123' }, p)) } }); return JSON.parse(r.s); };
  return { senden, ctx, dateien, anfragen: () => anfragen };
}
(async () => {
  const S = server();
  const t0 = await S.senden({ aktion: 'test' }); ok(t0.ok && t0.version === 2 && t0.abgleich, 'Brücke v2 meldet Version 2 mit Abgleich');
  const falsch = JSON.parse(S.ctx.doPost({ postData: { contents: JSON.stringify({ key: 'x', aktion: 'abgleich' }) } }).s); ok(!falsch.ok && falsch.code === 'schluessel', 'Falscher Schlüssel wird abgewiesen');
  const pc = { objekte: [{ id: 'o1', akqTitel: 'ETW Lichtenberg', status: 'termin', notizen: '', verkaeuferTelefon: '0171 111' }, { id: 'o2', akqTitel: 'Haus Spandau', status: 'neu' }],
    kontakte: [{ id: 'k1', name: 'Frau Krüger', telefon: '0171 111' }, { id: 'k2', name: 'Herr Meier', telefon: '030 222' }],
    termine: [{ id: 't1', titel: 'Erstgespräch', datum: '2026-11-20', googleEventId: 'g1', createdAt: 1 }], aufgaben: [], gesuche: [],
    meta: { schema24: 1, v9neustart: { quittiert: true } }, module: { akquise24: true }, hv: { verwaltungen: [{ id: 'h1', name: 'HV Nord', telefon: '030 9' }], dupIgnore: ['a'], ziel: 200 },
    jarvis: { einstellungen: { apiKey: 'sk-geheim', modell: 'x' }, leads: [], geo_cache: { a: 1 } }, googleSync: { kalenderId: 'pc-kal', bekannt: { g1: 't1' } }, sicherung: { ziel: 'C:/Cloud' } };
  const stPC = { geraet: 'pc-test' };
  const e1 = await K.runde(pc, stPC, S.senden); ok(e1.gesendet > 8 && e1.erstabgleich, `PC Erstabgleich: ${e1.gesendet} Einträge hochgeladen`);
  const roh = Object.values(S.dateien).map(d => d.inhalt).join('');
  ok(!roh.includes('sk-geheim') && !roh.includes('C:/Cloud') && !roh.includes('pc-kal') && !roh.includes('geo_cache'), 'API-Schlüssel, Sicherungsziel, Kalender-Einstellung und Geo-Cache bleiben auf dem Gerät');
  // Handy frisch (mit Voreinstellungen)
  const handy = { objekte: [], kontakte: [], termine: [], aufgaben: [], gesuche: [], meta: { schema24: 1 }, module: { akquise24: false }, jarvis: { einstellungen: { apiKey: '' } } };
  const stH = { geraet: 'handy-test' };
  const e2 = await K.runde(handy, stH, S.senden);
  ok(handy.objekte.length === 2 && handy.kontakte.length === 2 && handy.hv.verwaltungen.length === 1 && handy.module.akquise24 === true, 'Handy holt alles; Voreinstellung des Handys überschreibt den PC nicht');
  ok(handy.meta.v9neustart && handy.meta.v9neustart.quittiert === true && !handy.googleSync && handy.jarvis.einstellungen.apiKey === '' && handy.jarvis.einstellungen.modell === 'x', 'Einzelwerte übernommen, gerätebezogene Werte nicht');
  const e2b = await K.runde(handy, stH, S.senden); ok(e2b.gesendet === 0 && !e2b.geaendert, 'Zweiter Lauf am Handy: nichts zu tun');
  // Gleichzeitige Änderungen am selben Lead (verschiedene Felder)
  handy.objekte.find(o => o.id === 'o1').verkaeuferTelefon = '0171 999';
  pc.objekte.find(o => o.id === 'o1').notizen = 'Rückruf nach 18 Uhr';
  await K.runde(handy, stH, S.senden); await K.runde(pc, stPC, S.senden); await K.runde(handy, stH, S.senden);
  const oP = pc.objekte.find(o => o.id === 'o1'), oH = handy.objekte.find(o => o.id === 'o1');
  ok(oP.verkaeuferTelefon === '0171 999' && oP.notizen === 'Rückruf nach 18 Uhr' && K.gleich(oP, oH), 'Verschiedene Felder am selben Lead: beide Änderungen bleiben');
  // Echter Widerspruch: gleiches Feld, PC später
  handy.objekte.find(o => o.id === 'o2').status = 'termin'; await K.runde(handy, stH, S.senden);
  stPC.lokalSeit = stPC.lokalSeit || {};
  pc.objekte.find(o => o.id === 'o2').status = 'auftrag';
  // PC hat den Handy-Stand noch nicht → wird abgelehnt und zusammengeführt (PC-Änderung ist neuer)
  await new Promise(r => setTimeout(r, 5));
  const e3 = await K.runde(pc, stPC, S.senden); await K.runde(handy, stH, S.senden);
  ok(pc.objekte.find(o => o.id === 'o2').status === 'auftrag' && handy.objekte.find(o => o.id === 'o2').status === 'auftrag' && e3.protokoll.some(p => p.art === 'widerspruch'), 'Widerspruch: neuere Änderung gewinnt, steht im Protokoll');
  // Löschen
  pc.kontakte = pc.kontakte.filter(k => k.id !== 'k2'); await K.runde(pc, stPC, S.senden); await K.runde(handy, stH, S.senden);
  ok(!handy.kontakte.some(k => k.id === 'k2'), 'Löschung am PC kommt am Handy an');
  // Gelöscht am Handy, geändert am PC → bleibt
  handy.objekte = handy.objekte.filter(o => o.id !== 'o2'); pc.objekte.find(o => o.id === 'o2').status = 'abgeschlossen';
  await K.runde(pc, stPC, S.senden); const e4 = await K.runde(handy, stH, S.senden); await K.runde(pc, stPC, S.senden);
  ok(handy.objekte.some(o => o.id === 'o2' && o.status === 'abgeschlossen') && pc.objekte.some(o => o.id === 'o2'), 'Hier gelöscht, dort geändert → Eintrag bleibt erhalten');
  // Massenlöschung wird gestoppt
  for(let i = 0; i < 60; i++) pc.objekte.push({ id: 'm' + i, akqTitel: 'Lead ' + i }); await K.runde(pc, stPC, S.senden); await K.runde(handy, stH, S.senden);
  const sicher = handy.objekte; handy.objekte = [];
  let stopp = null; try{ await K.runde(handy, stH, S.senden); }catch(e){ stopp = e; }
  ok(stopp && stopp.code === 'massenloeschung' && pc.objekte.length > 60, 'Massenlöschung (z. B. leere Liste) wird gestoppt, nichts gelöscht');
  handy.objekte = sicher;
  // Bereich fehlt komplett (z. B. Modul nicht geladen) → keine Löschung
  const jv = handy.jarvis; delete handy.jarvis; const e5 = await K.runde(handy, stH, S.senden); handy.jarvis = jv;
  await K.runde(pc, stPC, S.senden); ok(pc.jarvis && pc.jarvis.einstellungen && pc.jarvis.einstellungen.modell === 'x', 'Fehlender Bereich auf einem Gerät löscht nichts auf dem anderen');
  // Große Datenmenge in mehreren Paketen
  for(let i = 0; i < 2500; i++) pc.notizen = (pc.notizen || []).concat([{ id: 'n' + i, text: 'x'.repeat(900) + i, datum: '2026-11-11' }]);
  const a0 = S.anfragen(); const e6 = await K.runde(pc, stPC, S.senden); const a1 = S.anfragen();
  const e7 = await K.runde(handy, stH, S.senden); const a2 = S.anfragen();
  ok(e6.gesendet === 2500 && a1 - a0 >= 3 && handy.notizen.length === 2500 && a2 - a1 >= 2, `2.500 Notizen (~2,3 MB) in ${a1 - a0} Paketen hoch, in ${a2 - a1} Abrufen herunter`);
  ok(Object.values(S.dateien).every(d => d.inhalt.length < 10e6), 'Jede Speicherdatei bleibt unter 10 MB');
  // Doppelte Termine mit gleichem Google-Termin
  handy.termine.push({ id: 't9', titel: 'Erstgespräch', datum: '2026-11-20', googleEventId: 'g1', createdAt: 5, notiz: 'vom Handy' });
  await K.runde(handy, stH, S.senden); await K.runde(pc, stPC, S.senden); await K.runde(handy, stH, S.senden);
  ok(pc.termine.length === 1 && handy.termine.length === 1 && pc.termine[0].notiz === 'vom Handy', 'Doppelter Google-Termin wird zusammengelegt');
  // Stand ist auf beiden Geräten gleich (ohne Gerätewerte)
  const ohne = d => { const x = JSON.parse(JSON.stringify(d)); delete x.googleSync; delete x.sicherung; if(x.jarvis){ delete x.jarvis.geo_cache; if(x.jarvis.einstellungen) delete x.jarvis.einstellungen.apiKey; } x.objekte.sort((a, b) => a.id < b.id ? -1 : 1); const leer = o => { for(const k of Object.keys(o)) { if(Array.isArray(o[k]) && !o[k].length) delete o[k]; else if(o[k] && typeof o[k] === 'object' && !Array.isArray(o[k])) leer(o[k]); } }; leer(x); return K.stabil(x); };
  { const A = JSON.parse(ohne(pc)), B = JSON.parse(ohne(handy)); for(const k of new Set(Object.keys(A).concat(Object.keys(B)))) if(K.stabil(A[k]) !== K.stabil(B[k])) console.log('  Unterschied', k, K.stabil(A[k]).slice(0, 300), '|', K.stabil(B[k]).slice(0, 300)); }
  ok(ohne(pc) === ohne(handy), 'PC und Handy haben denselben Stand');
  // Server geleert → Geräte merken es und fangen neu an
  await S.senden({ aktion: 'abgleichLeeren', bestaetigung: 'LEEREN' });
  let neu = null; try{ await K.runde(pc, stPC, S.senden); }catch(e){ neu = e; }
  ok(neu && neu.code === 'neustart' && Object.keys(stPC.basis).length === 0, 'Geleerter Server wird erkannt');
  const e8 = await K.runde(pc, stPC, S.senden); const e9 = await K.runde(handy, stH, S.senden).catch(e => e);
  const e10 = await K.runde(handy, stH, S.senden).catch(e => e);
  ok(e8.gesendet > 2500 && handy.notizen.length === 2500 && (e10 && !e10.code), 'Neuaufbau nach dem Leeren klappt auf beiden Geräten');
  const st = await S.senden({ aktion: 'abgleichStatus' }); ok(st.ok && st.eintraege > 2500, `Status: ${st.eintraege} Einträge, ${Math.round(st.bytes / 1024)} KB`);
  console.log('FEHLER', f);
})();
