// Test der Handy-App-Brücke (android25.js) mit nachgebautem Android-Objekt „MCAndroid“
const { chromium } = require('playwright');
const fs = require('fs'), vm = require('vm');
let f = 0; const ok = (b, t) => { console.log((b ? 'ok   ' : 'FEHL ') + t); if(!b) f++; };
const T = fs.readFileSync('/tmp/v25test/test25.js', 'utf8');
eval(T.slice(T.indexOf('function server(){'), T.indexOf('const HEUTE')));
const HEUTE = new Date().toISOString().slice(0, 10);
(async () => {
  const b = await chromium.launch();
  const senden = server();
  // PC lädt Daten hoch
  const pc = await b.newPage();
  await pc.exposeFunction('__senden', x => senden(x));
  await pc.addInitScript(() => {
    const start = { objekte: [{ id: 'o1', createdAt: 1, akqTitel: 'ETW Lichtenberg', objektart: 'Wohnung', ort: '10365 Berlin', status: 'termin', verkaeuferName: 'Petra Krüger', verkaeuferTelefon: '0171 2223334', eigentuemerId: 'k1', verlauf: [] }], kontakte: [{ id: 'k1', createdAt: 1, name: 'Petra Krüger', telefon: '0171 2223334', kontaktart: 'eigentuemer', status: 'lead', prioritaet: 'mittel', notizen: '' }], termine: [], aufgaben: [], notizen: [], meta: { v9neustart: { quittiert: true } } };
    window.pc = { geraet: 'pc', laden: () => JSON.parse(sessionStorage.getItem('d') || 'null') || start, speichern: t => { sessionStorage.setItem('d', t); return { ok: true }; }, ordner(){}, sicherungSchreiben: () => ({ ok: true }), sicherungLesen: () => null,
      abgleichStand: (a, t) => a === 'lesen' ? sessionStorage.getItem('st') : (sessionStorage.setItem('st', t), { ok: true }), google: async (a, x) => a === 'status' ? { ok: true, modus: 'skript', verbunden: true } : a === 'abgleich' ? await window.__senden(x) : { ok: false } };
  });
  await pc.goto('file:///tmp/pc/app/index.html'); await pc.waitForTimeout(1500);
  await pc.evaluate(() => ab25Einschalten()); await pc.waitForTimeout(1500);
  // Handy mit nachgebautem MCAndroid
  const h = await b.newPage({ viewport: { width: 412, height: 915 }, isMobile: true, hasTouch: true });
  const fe = []; h.on('pageerror', e => fe.push(e.message));
  await h.exposeFunction('__senden', x => senden(x));
  await h.exposeFunction('__log', x => { h.__log = (h.__log || []).concat([x]); });
  await h.addInitScript(() => {
    const dateien = {}; let tresor = null; const geoeffnet = []; window.__geoeffnet = geoeffnet;
    const spaeter = (id, o) => setTimeout(() => window.__mcAntwort(id, JSON.stringify(o)), 5);
    window.MCAndroid = {
      laden: () => dateien.daten || 'null', speichern: t => { dateien.daten = t; return '{"ok":true}'; }, importieren: t => { dateien.daten = t; return '{"ok":true}'; },
      sicherungSchreiben: () => '{"ok":true}', sicherungLesen: () => null,
      standLesen: () => dateien.stand || null, standSchreiben: t => { dateien.stand = t; return '{"ok":true}'; }, standLoeschen: () => { delete dateien.stand; return '{"ok":true}'; },
      google: (id, aktion, arg) => { const a = JSON.parse(arg); if(aktion === 'status') return spaeter(id, { ok: true, modus: 'skript', verbunden: !!tresor, email: tresor ? 'p@x.de' : '' }); if(aktion === 'abgleich'){ if(!tresor) return spaeter(id, { ok: false, code: 'nicht_verbunden', fehler: 'nicht gekoppelt' }); return window.__senden(a).then(r => spaeter(id, r)); } if(aktion === 'api') return spaeter(id, { ok: true, status: 200, data: { items: [] } }); spaeter(id, { ok: false, fehler: 'Am Handy nicht verfügbar' }); },
      koppeln: (id, code) => { try{ const d = JSON.parse(atob(code.slice(4).replace(/-/g, '+').replace(/_/g, '/'))); window.__senden({ aktion: 'test' }).then(t => { if(t.version >= 2){ tresor = d; spaeter(id, { ok: true, email: 'p@x.de' }); } else spaeter(id, { ok: false, fehler: 'alt' }); }); }catch(e){ spaeter(id, { ok: false, fehler: 'Code ungültig' }); } },
      gekoppelt: () => tresor ? 'true' : 'false', entkoppeln: () => { tresor = null; },
      abruf: (id, url) => spaeter(id, { ok: false, fehler: 'offline' }), seite: (id, url) => spaeter(id, { ok: false }),
      zwischenablage: () => 'Kopierter Text', dateiSpeichern: (id, n, b64) => spaeter(id, { ok: true, pfad: 'content://media/1', name: n }), dateiOeffnen: p => geoeffnet.push(p),
      drucken: (html, titel) => { window.__gedruckt = { titel, laenge: html.length }; }, teilen: () => {}, oeffnen: u => geoeffnet.push(u), sperre: () => 'true'
    };
  });
  await h.goto('file:///tmp/pc/app/index.html'); await h.waitForTimeout(2000);
  let r = await h.evaluate(() => ({ geraet: window.pc.geraet, logo: document.querySelector('.sb-logo').textContent, dialog: /Mit PC koppeln/.test(document.getElementById('modalInner').innerText), app: document.body.classList.contains('h25-app') }));
  ok(r.geraet === 'handy' && /Handy v9/.test(r.logo) && r.dialog && r.app, 'App-Brücke erkannt: window.pc aus MCAndroid, Logo „Handy v9“, Kopplungsdialog');
  const code = 'MC1-' + Buffer.from(JSON.stringify({ u: 'https://script.google.com/macros/s/AKfycbxxxxxxxxxxxxxxxxxxxxxx/exec', k: 'k' })).toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  await h.fill('#ab25Code', code); await h.evaluate(() => ab25Koppeln()); await h.waitForTimeout(2000);
  r = await h.evaluate(() => ({ o: db.objekte.length, k: (findKontakt('k1') || {}).name, aktiv: ab25Aktiv(), gesp: !!window.MCAndroid.laden().length }));
  ok(r.o === 1 && r.k === 'Petra Krüger' && r.aktiv && r.gesp, 'Kopplung über die App-Brücke: Daten geholt und in der App gespeichert');
  // Anrufen-Link → Android
  await h.evaluate(() => { const a = document.createElement('a'); a.href = 'tel:01712223334'; a.textContent = 'x'; document.body.appendChild(a); a.click(); window.open('https://wa.me/491712223334'); });
  r = await h.evaluate(() => window.__geoeffnet);
  ok(r.includes('tel:01712223334') && r.some(x => /wa\.me/.test(x)), 'Telefon- und WhatsApp-Links gehen an Android (Anrufen, WhatsApp)');
  // PDF → Druckdialog
  await h.evaluate(() => mc24Pdf('<html><body>Bericht</body></html>', 'Bericht.pdf')); await h.waitForTimeout(100);
  r = await h.evaluate(() => window.__gedruckt);
  ok(r && r.titel === 'Bericht.pdf', 'Bericht/Briefing am Handy über den Android-Druckdialog („Als PDF speichern“)');
  // Zurück-Taste
  await h.evaluate(() => { wechsleAnsicht('kontakte'); oeffneKontaktModal('k1'); });
  const z1 = await h.evaluate(() => [window.h25Zurueck(), document.getElementById('modalBg').classList.contains('show')]);
  const z2 = await h.evaluate(() => [window.h25Zurueck(), aktuelleAnsicht]);
  const z3 = await h.evaluate(() => window.h25Zurueck());
  ok(z1[0] === true && z1[1] === false && z2[0] === true && z2[1] === 'heute' && z3 === false, 'Zurück-Taste: Dialog zu → Startseite → App in den Hintergrund');
  // Änderung am Handy → PC
  await h.evaluate(() => { findObjekt('o1').status = 'auftrag'; save(); }); await h.waitForTimeout(500); await h.evaluate(() => ab25Sync('test')); await h.waitForTimeout(500);
  await pc.evaluate(() => ab25Sync('test')); await pc.waitForTimeout(800);
  ok(await pc.evaluate(() => findObjekt('o1').status) === 'auftrag', 'Änderung am Handy (über die App-Brücke) kommt am PC an');
  ok(fe.length === 0, 'Keine Fehler in der App-Oberfläche ' + JSON.stringify(fe.slice(0, 2)));
  console.log('FEHLER', f); await b.close();
})();
