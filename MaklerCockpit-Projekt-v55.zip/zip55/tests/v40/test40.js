const { chromium } = require('playwright');
let f = 0; const ok = (b, t) => { console.log((b ? 'ok   ' : 'FEHL ') + t); if(!b) f++; };
const D = JSON.stringify({ objekte: [{ id: 'm1', akqTitel: 'DHH Mahlsdorf', objektart: 'Doppelhaushälfte', status: 'akquise', ort: '12623 Berlin', adresse: 'Musterweg 12, 12623 Berlin', verlauf: [] }, { id: 'm2', akqTitel: 'ETW Lichtenberg', objektart: 'Wohnung', status: 'akquise', ort: '10365 Berlin', adresse: 'Testweg 1', verlauf: [] }], kontakte: [], termine: [], aufgaben: [], notizen: [], shooting: { saved: [] }, meta: { v9neustart: { quittiert: true } } });
(async () => {
  const b = await chromium.launch();
  for(const [g, w, h] of [['pc', 1440, 900], ['handy', 412, 915]]){
    const p = await b.newPage({ viewport: { width: w, height: h }, isMobile: g === 'handy', hasTouch: g === 'handy' });
    p.fe = []; p.on('pageerror', e => p.fe.push(e.message));
    await p.addInitScript(([d, g]) => { window.pc = { geraet: g, laden: () => JSON.parse(d), speichern: () => ({ ok: true }), ordner(){}, sicherungSchreiben: () => ({ ok: true }), sicherungLesen: () => null, gekoppelt: () => true, google: async () => ({ ok: false }) }; navigator.clipboard.writeText = async t => { window.__kopie = t; }; }, [D, g]);
    await p.goto('file:///tmp/pc/app/index.html'); await p.waitForTimeout(2200);
    await p.evaluate(() => { try{ schliesseModal(); }catch(e){} GA35.obj = 'm1'; const e = ga35Entwurf('m1'); e.art = 'DHH'; e.region = 'Berlin';
      Object.assign(e.werte, { plz: { v: '12623', s: 'documented' }, ort: { v: 'Berlin', s: 'documented' }, ortsteil: { v: 'Mahlsdorf', s: 'documented' }, wfl: { v: '118', s: 'documented' }, grund: { v: '380', s: 'documented' }, brw: { v: '620', s: 'documented' }, wunsch: { v: '690000', s: 'owner_statement' } });
      delete e.werte.baujahr; e.vergleich = []; save(); wechsleAnsicht('grossanalyse'); });
    await p.waitForTimeout(600);
    ok(await p.evaluate(() => document.querySelectorAll('.ga40-reiter button').length === 2 && !!document.querySelector('.ga40-karte')), g + ': Reiter „Erfassung / Schnellbewertung“ und Karte in der Erfassung');
    await p.click('.ga40-reiter button:has-text("Schnellbewertung")'); await p.waitForTimeout(1800);
    const fr = await (await p.$('#ga40Frame')).contentFrame();
    let r = await fr.evaluate(() => ({ fl: document.getElementById('flaeche').value, typ: document.querySelector('.wrap').dataset.type, ht: document.getElementById('haustyp').value, brw: document.getElementById('erBodenrichtwert').value, mfh: document.getElementById('mfhGrundstueck').value, gs: document.getElementById('erGrundstueck').value, ang: document.getElementById('objAngebot').value, adr: document.getElementById('adresse').value, host: !!window.ga40Werte }));
    console.log('   ' + JSON.stringify(r));
    ok(r.fl === '118' && r.typ === 'haus' && r.ht === '0.97' && r.brw === '620' && r.gs === '380' && r.mfh === '' && r.ang === '690.000' && r.host, g + ': Werkzeug vorbelegt (Haus, DHH 0,97, 118 m², BRW 620, Grund 380, Preis 690.000)');
    ok(!/Musterweg/.test(r.adr) && /12623/.test(r.adr), g + ': ohne Straße/Hausnummer');
    // Eingaben im Werkzeug
    await fr.evaluate(() => { const s = (id, v) => { const el = document.getElementById(id); el.value = v; el.dispatchEvent(new Event('input', { bubbles: true })); };
      s('vgHomeday', '4800'); s('vgImmoscout', '5100'); document.getElementById('vgImmoweltExclude').checked = true; document.getElementById('vgImmoweltExclude').dispatchEvent(new Event('change'));
      s('insAddr1', 'Mahlsdorf-Nord'); s('insPreis1', '649000'); s('insFlaeche1', '125'); s('insLink1', 'https://example.org/1');
      s('insAddr2', 'Kaulsdorf'); s('insPreis2', '599000'); s('insFlaeche2', '112');
      s('baujahr', '1998'); });
    await p.waitForTimeout(1600);
    ok(await p.evaluate(() => { const e = ga35Entwurf('m1'); return !!e.schnellEntwurf && e.schnellEntwurf.fields.insPreis1 === '649000'; }), g + ': Werkzeug speichert seinen Stand im Entwurf der Großen Analyse');
    await p.click('button:has-text("In die Große Analyse übernehmen")'); await p.waitForTimeout(300);
    r = await p.evaluate(() => [...document.querySelectorAll('.ga40-liste label')].map(l => [l.textContent.trim().slice(0, 60), l.querySelector('input').checked]));
    console.log('   ' + JSON.stringify(r));
    ok(r.length === 6 && /^Ergebnisse/.test(r[0][0]) && r.some(x => /Homeday/.test(x[0])) && !r.some(x => /Immowelt/.test(x[0])) && r.some(x => /Baujahr: 1998 /.test(x[0])) && !r.some(x => /Wohnfläche/.test(x[0])), g + ': Vorschläge: Ergebnis, 2 Inserate, 3 Portalwerte (Immowelt ausgeschlossen/unverändert → nicht angeboten), Baujahr (fehlte); Wohnfläche nicht (schon da)');
    await p.click('#modalBg button:has-text("Übernehmen")'); await p.waitForTimeout(600);
    r = await p.evaluate(() => { const e = ga35Entwurf('m1'); return { v: e.vergleich.map(x => [x.art, x.preis, x.preisbasis, x.beleg]), bj: e.werte.baujahr, s: e.schnell, tab: GA35.tab, karte: (document.querySelector('.ga40-karte') || {}).innerText || '' }; });
    ok(r.v.length === 4 && r.v.every(x => x[0] === 'listing' && x[3] === false) && r.v.filter(x => /Portal/.test(x[2])).length === 2, g + ': 2 Inserate + 2 Portalwerte als „Angebot“, nie belegt');
    ok(r.bj && r.bj.v === '1998' && r.bj.s === 'assumed', g + ': fehlendes Baujahr als „Annahme“ übernommen');
    const erw = 118 * ((4800 + 5100 + 649000 / 125 + 599000 / 112) / 4) * 0.97 * 1.0;
    ok(r.s && r.s.vergleich && Math.abs(r.s.vergleich.wert - erw) < 1 && !r.s.ertrag, g + `: Vergleichswert ${Math.round(r.s.vergleich.wert)} € (nachgerechnet), Ertrag nicht genutzt → nicht übernommen`);
    ok(r.tab === 'erfassung' && /Vergleichswert \(Schnell\)/.test(r.karte), g + ': zurück in der Erfassung, Karte zeigt das Ergebnis');
    // Nochmal übernehmen → keine Dubletten
    await p.evaluate(() => ga40Tab('schnell')); await p.waitForTimeout(1800);
    const fr2 = await (await p.$('#ga40Frame')).contentFrame();
    ok(await fr2.evaluate(() => document.getElementById('insPreis1').value === '649000'), g + ': Werkzeug lädt den gespeicherten Stand wieder');
    await p.evaluate(() => ga40UebernahmeDialog()); await p.waitForTimeout(300); await p.click('#modalBg button:has-text("Übernehmen")'); await p.waitForTimeout(500);
    ok(await p.evaluate(() => ga35Entwurf('m1').vergleich.length === 4), g + ': zweites Übernehmen legt nichts doppelt an');
    // Paket
    r = await p.evaluate(() => { const pa = ga35Paket('m1', ga35Entwurf('m1')); return pa.broker_quick_check; });
    ok(r && r.vergleichswert && r.vergleichswert.status === 'assumed' && /nicht als Wertquelle/.test(r.hinweis) && r.ertragswert === null, g + ': Analysepaket enthält die Schnellbewertung nur zur Plausibilität');
    ok(await p.evaluate(() => { ga35Prompt && 0; const t = ga35Prompt('m1', ga35Entwurf('m1')).text; return /broker_quick_check/.test(t); }), g + ': Prompt enthält broker_quick_check');
    // Ertrag
    await p.evaluate(() => ga40Tab('schnell')); await p.waitForTimeout(1800);
    const fr3 = await (await p.$('#ga40Frame')).contentFrame();
    await fr3.evaluate(() => { const s = (id, v) => { const el = document.getElementById(id); el.value = v; el.dispatchEvent(new Event('input', { bubbles: true })); }; s('erMiete', '13.5'); });
    await p.waitForTimeout(300);
    await p.evaluate(() => ga40UebernahmeDialog()); await p.waitForTimeout(300); await p.click('#modalBg button:has-text("Übernehmen")'); await p.waitForTimeout(500);
    r = await p.evaluate(() => ga35Entwurf('m1').schnell.ertrag);
    ok(r && r.ertragswert > 0 && r.miete_qm === 13.5 && r.liegzinsProz === 3, g + ': Ertragswert übernommen, sobald Miete eingetragen (' + Math.round(r && r.ertragswert) + ' €)');
    // Objektwechsel → eigener Entwurf
    await p.evaluate(() => { GA35.tab = 'schnell'; const e2 = ga35Entwurf('m2'); e2.art = 'ETW'; Object.assign(e2.werte, { wfl: { v: '68', s: 'documented' }, plz: { v: '10365', s: 'documented' } }); ga35ObjWaehlen('m2'); }); await p.waitForTimeout(1800);
    const fr4 = await (await p.$('#ga40Frame')).contentFrame();
    r = await fr4.evaluate(() => ({ fl: document.getElementById('flaeche').value, typ: document.querySelector('.wrap').dataset.type, ins: document.getElementById('insPreis1').value }));
    ok(r.fl === '68' && r.typ === 'wohnung' && r.ins === '', g + ': anderes Objekt → eigener Stand (Wohnung, 68 m², leere Inserate)');
    await p.evaluate(() => { GA35.tab = 'erfassung'; ga35ObjWaehlen('m1'); }); await p.waitForTimeout(400);
    if(g === 'handy'){ await p.evaluate(() => ga40Tab('schnell')); await p.waitForTimeout(1800); await p.screenshot({ path: '/tmp/v40test/handy_schnell.png' }); await p.evaluate(() => ga40Tab('erfassung')); await p.waitForTimeout(400);
      await p.evaluate(() => document.querySelector('.ga40-karte').scrollIntoView()); await p.screenshot({ path: '/tmp/v40test/handy_karte.png' }); }
    ok(p.fe.length === 0, g + ': keine Fehler ' + p.fe.join(' | '));
    await p.close();
  }
  await b.close(); console.log('FEHLER', f);
})();
