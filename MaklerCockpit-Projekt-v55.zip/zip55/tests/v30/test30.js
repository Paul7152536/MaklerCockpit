// v30: Detailfeld wandert mit (siehe sticky2.js) + Uhrzeit per Zifferblatt
const { chromium } = require('playwright');
let f = 0; const ok = (b, t) => { console.log((b ? 'ok   ' : 'FEHL ') + t); if(!b) f++; };
async function seite(b, geraet, w, h){
  const p = await b.newPage({ viewport: { width: w || 1440, height: h || 900 } }); p.fe = []; p.on('pageerror', e => p.fe.push(e.message));
  await p.addInitScript(g => { window.pc = { geraet: g, laden: () => ({ objekte: [{ id: 'o1', createdAt: 1, akqTitel: 'EFH Grünau', adresse: 'Am Wald 1', ort: '12527 Berlin', objektart: 'EFH', status: 'neu', link: 'https://www.kleinanzeigen.de/s-anzeige/1', verlauf: [] }], kontakte: [], termine: [], aufgaben: [], notizen: [], gesuche: [], marktanalysen: [], mentorFragen: [], meta: { v9neustart: { quittiert: true } } }), speichern: () => ({ ok: true }), ordner(){}, sicherungSchreiben: () => ({ ok: true }), sicherungLesen: () => null, zwischenablage: async () => '', abruf: async () => ({ ok: false }) }; }, geraet);
  await p.goto('file:///tmp/pc/app/index.html'); await p.waitForTimeout(1800); return p;
}
const klickBlatt = async (p, x, y) => { const r = await p.evaluate(() => { const b = document.querySelector('.uhr30-blatt').getBoundingClientRect(); return { l: b.left, t: b.top }; }); await p.mouse.click(r.l + x, r.t + y); await p.waitForTimeout(120); };
const pos = (schritt, von, rad) => { const w = (schritt / von) * 2 * Math.PI - Math.PI / 2; return [130 + rad * Math.cos(w), 130 + rad * Math.sin(w)]; };
(async () => {
  const b = await chromium.launch();
  let p = await seite(b, 'pc');
  await p.evaluate(() => oeffneTerminModal()); await p.waitForTimeout(300);
  ok(await p.evaluate(() => document.documentElement.classList.contains('uhr30-an') && Array.from(document.styleSheets).some(sh => { try{ return Array.from(sh.cssRules).some(r => /uhr30-an input\[type="time"\]::-webkit-calendar-picker-indicator/.test(r.cssText) && /display: none/.test(r.cssText)); }catch(e){ return false; } })), 'Alte Auswahlliste am Uhrzeit-Feld ausgeblendet');
  await p.click('#m_t_zeit'); await p.waitForTimeout(200);
  let r = await p.evaluate(() => { const u = document.querySelector('.uhr30'); if(!u) return null; const i = document.getElementById('m_t_zeit').getBoundingClientRect(), x = u.getBoundingClientRect(); return { zahlen: u.querySelectorAll('.uhr30-z').length, innen: u.querySelectorAll('.uhr30-z.innen').length, unter: x.top >= i.bottom - 1 || x.bottom <= i.top + 1, imBild: x.left >= 0 && x.right <= innerWidth && x.top >= 0 && x.bottom <= innerHeight, fokus: document.activeElement.id }; });
  ok(r && r.zahlen === 24 && r.innen === 12 && r.unter && r.imBild && r.fokus === 'm_t_zeit', 'Klick ins Feld öffnet das Zifferblatt (1–12 außen, 13–00 innen), Feld behält den Fokus');
  await p.screenshot({ path: '/tmp/v30test/uhr_stunden.png' });
  await klickBlatt(p, ...pos(2, 12, 64));
  r = await p.evaluate(() => ({ v: document.getElementById('m_t_zeit').value, kopf: document.querySelector('.uhr30-kopf').innerText.replace(/\s/g, ''), dauer: document.getElementById('m_t_dauer') ? document.getElementById('m_t_dauer').disabled : null, z: document.querySelectorAll('.uhr30-z').length }));
  ok(r.v === '14:00' && r.kopf === '14:00' && r.z === 12, 'Innen „14“ angeklickt → 14:00, weiter zu den Minuten (' + JSON.stringify(r) + ')');
  ok(r.dauer === false, 'Feld-Ereignis ausgelöst (Dauer-Auswahl wird aktiv)');
  await p.screenshot({ path: '/tmp/v30test/uhr_minuten.png' });
  await klickBlatt(p, ...pos(30, 60, 100)); await p.waitForTimeout(350);
  r = await p.evaluate(() => ({ v: document.getElementById('m_t_zeit').value, offen: !!document.querySelector('.uhr30'), modal: !!document.querySelector('#modalInner #m_t_zeit') }));
  ok(r.v === '14:30' && !r.offen && r.modal, 'Minute „30“ → 14:30, Zifferblatt schließt, Termin-Dialog bleibt offen');
  // Ziehen: Stunde außen 9, dann Minuten ziehen auf 45
  await p.click('#m_t_zeit'); await p.waitForTimeout(150);
  const bl = await p.evaluate(() => { const x = document.querySelector('.uhr30-blatt').getBoundingClientRect(); return { l: x.left, t: x.top }; });
  const [x1, y1] = pos(6, 12, 100), [x2, y2] = pos(9, 12, 100);
  await p.mouse.move(bl.l + x1, bl.t + y1); await p.mouse.down(); await p.mouse.move(bl.l + 130 + 50, bl.t + 230, { steps: 4 }); await p.mouse.move(bl.l + x2, bl.t + y2, { steps: 6 }); await p.mouse.up(); await p.waitForTimeout(150);
  r = await p.evaluate(() => document.getElementById('m_t_zeit').value);
  ok(r === '09:30', 'Stunde ziehen von 6 nach 9 (außen) → 09:30 (Minuten bleiben)');
  await klickBlatt(p, ...pos(45, 60, 100)); await p.waitForTimeout(350);
  ok(await p.evaluate(() => document.getElementById('m_t_zeit').value) === '09:45', 'Minuten 45 → 09:45');
  // Abbrechen stellt den alten Wert wieder her, Escape schließt nur das Zifferblatt
  await p.click('#m_t_zeit'); await p.waitForTimeout(150);
  await klickBlatt(p, ...pos(0, 12, 64)); // 00 innen
  ok(await p.evaluate(() => document.getElementById('m_t_zeit').value) === '00:45', 'Innen oben = 00');
  await p.click('.uhr30 [data-uhr="ab"]'); await p.waitForTimeout(150);
  ok(await p.evaluate(() => document.getElementById('m_t_zeit').value) === '09:45' && !(await p.$('.uhr30')), 'Abbrechen → wieder 09:45');
  await p.click('#m_t_zeit'); await p.waitForTimeout(150); await p.keyboard.press('Escape'); await p.waitForTimeout(150);
  ok(!(await p.$('.uhr30')) && await p.evaluate(() => !!document.getElementById('m_t_zeit')), 'Escape schließt nur das Zifferblatt, nicht den Dialog');
  // Eintippen geht weiter und bewegt das Zifferblatt
  await p.click('#m_t_zeit'); await p.waitForTimeout(150);
  await p.evaluate(() => { const i = document.getElementById('m_t_zeit'); i.value = '16:15'; i.dispatchEvent(new Event('input', { bubbles: true })); });
  ok(await p.evaluate(() => document.querySelector('.uhr30-kopf').innerText.replace(/\s/g, '')) === '16:15', 'Eingetippte Zeit erscheint im Zifferblatt');
  await p.mouse.click(5, 5); await p.waitForTimeout(150);
  ok(!(await p.$('.uhr30')), 'Klick daneben schließt das Zifferblatt');
  await p.evaluate(() => schliesseModal());
  // Lead-Termin (Schnell-Termin im Lead)
  await p.evaluate(() => { wechsleAnsicht('akquise'); AQ2.status = 'alle'; AQ2.sel = 'o1'; aq2Detail(); if(typeof aq2TerminNeu === 'function') aq2TerminNeu(); }); await p.waitForTimeout(400);
  const tq = await p.$('#tq_zeit');
  if(tq){
    await p.click('#tq_zeit'); await p.waitForTimeout(150);
    await klickBlatt(p, ...pos(11, 12, 100)); await klickBlatt(p, ...pos(15, 60, 100)); await p.waitForTimeout(350);
    ok(await p.evaluate(() => document.getElementById('tq_zeit').value) === '11:15', 'Lead-Termin: Zifferblatt → 11:15');
  } else console.log('     (Lead-Termin-Feld nicht gefunden – übersprungen)');
  ok(p.fe.length === 0, 'Keine Fehler ' + JSON.stringify(p.fe)); await p.close();
  // Handy: Android-Uhr bleibt
  p = await seite(b, 'handy', 390, 844);
  await p.evaluate(() => oeffneTerminModal()); await p.waitForTimeout(300);
  await p.click('#m_t_zeit'); await p.waitForTimeout(200);
  ok(!(await p.$('.uhr30')), 'Handy: kein eigenes Zifferblatt (Android zeigt seine Uhr)');
  await p.close();
  console.log('FEHLER', f); await b.close();
})();
