// Detailfeld wandert mit: Akquise, Käufer & Markt, Kooperationen – verschiedene Fenstergrößen
const { chromium } = require('playwright');
let f = 0; const ok = (b, t) => { console.log((b ? 'ok   ' : 'FEHL ') + t); if(!b) f++; };
(async () => {
  const b = await chromium.launch();
  const o = []; for(let i = 0; i < 30; i++) o.push({ id: 'n' + i, createdAt: Date.now() - i * 1000, akqTitel: 'Einfamilienhaus ' + i, adresse: 'Teststr. ' + i, ort: '12527 Berlin-Grünau', objektart: 'EFH', status: i % 3 ? 'neu' : 'auftrag', kaufpreis: 499999, wohnflaeche: 103, quelle: 'Kleinanzeigen', link: 'https://www.kleinanzeigen.de/s-anzeige/' + i, verlauf: [], notizen: '' });
  const k = []; for(let i = 0; i < 80; i++) k.push({ id: 'k' + i, createdAt: 1, name: 'Hausverwaltung ' + i, firma: 'HV ' + i, telefon: '030 ' + (100000 + i), kontaktart: 'hausverwaltung', organisation: true, status: 'lead', prioritaet: 'mittel', koop: { typ: 'hausverwaltung', status: 'neu' } });
  const D = JSON.stringify({ objekte: o, kontakte: k, termine: [], aufgaben: [], notizen: [], gesuche: [], marktanalysen: [], mentorFragen: [], meta: { v9neustart: { quittiert: true } } });
  for(const [w, h] of [[1920, 1080], [1440, 800], [1366, 768], [1280, 720], [1024, 700]]){
    const p = await b.newPage({ viewport: { width: w, height: h } });
    await p.addInitScript(d => { window.pc = { geraet: 'pc', laden: () => JSON.parse(d), speichern: () => ({ ok: true }), ordner(){}, sicherungSchreiben: () => ({ ok: true }), sicherungLesen: () => null, zwischenablage: async () => '', abruf: async () => ({ ok: false }) }; }, D);
    await p.goto('file:///tmp/pc/app/index.html'); await p.waitForTimeout(1800);
    for(const [name, js, sel] of [['Akquise', "wechsleAnsicht('akquise'); AQ2.status='alle'; AQ2.sel='n1'; aq2Detail();", '#aqDetail'], ['Käufer & Markt', "wechsleAnsicht('kaeufer'); KM.sel='n0'; kmListe(); kmDetail();", '#kmDetail'], ['Kooperationen', "wechsleAnsicht('kooperationen'); AK24_KOOP.sel = (db.kontakte.find(x => x.koop) || {}).id; renderMain();", '.aq-layout > :nth-child(2)']]){
      const da = await p.evaluate(js => { try{ eval(js); return true; }catch(e){ return e.message; } }, js); await p.waitForTimeout(300);
      const m = await p.evaluate(() => { const m = document.getElementById('main'); return { h: m.scrollHeight, c: m.clientHeight }; });
      if(da !== true || m.h <= m.c + 50){ console.log('     ' + name + ' ' + w + 'x' + h + ': übersprungen (' + (da === true ? 'Seite scrollt nicht' : da) + ')'); continue; }
      await p.evaluate(() => { document.getElementById('main').scrollTop = 0; }); await p.waitForTimeout(100);
      await p.mouse.move(Math.round(w * 0.35), Math.round(h * 0.6)); await p.mouse.wheel(0, 1600); await p.waitForTimeout(400);
      const r = await p.evaluate(sel => { const e = document.querySelector(sel); const x = e.getBoundingClientRect(); const knopf = e.querySelector('.dp-aktionen'); const kb = knopf ? knopf.getBoundingClientRect() : null; return { top: Math.round(x.top), bottom: Math.round(x.bottom), knopf: kb ? Math.round(kb.bottom) : null, st: document.getElementById('main').scrollTop }; }, sel);
      ok(r.st > 300 && r.top >= 60 && r.top < 140 && r.bottom <= h && (r.knopf == null || r.knopf <= h), `${name} ${w}×${h}: nach Scrollen sichtbar (oben ${r.top}, unten ${r.bottom}${r.knopf != null ? ', Knöpfe ' + r.knopf : ''})`);
    }
    if(w === 1366) await p.screenshot({ path: '/tmp/v30test/akquise_1366.png' });
    await p.close();
  }
  // Handy: kein Mitwandern (eigene Vollbild-Ansicht)
  const p = await b.newPage({ viewport: { width: 390, height: 844 } });
  await p.addInitScript(d => { window.pc = { geraet: 'handy', laden: () => JSON.parse(d), speichern: () => ({ ok: true }), ordner(){}, sicherungSchreiben: () => ({ ok: true }), sicherungLesen: () => null, zwischenablage: async () => '', abruf: async () => ({ ok: false }) }; }, D);
  await p.goto('file:///tmp/pc/app/index.html'); await p.waitForTimeout(1800);
  await p.evaluate(() => wechsleAnsicht('akquise')); await p.waitForTimeout(300);
  ok(await p.evaluate(() => getComputedStyle(document.getElementById('aqDetail')).position !== 'sticky'), 'Handy: Detail bleibt Vollbild-Ansicht (nicht mitwandernd)');
  console.log('FEHLER', f); await b.close();
})();
