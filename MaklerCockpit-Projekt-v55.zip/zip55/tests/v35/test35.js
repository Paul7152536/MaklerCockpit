// v35: Große Analyse – Navigation, Vorbelegung, Prompt mit Analysepaket, Datenschutz, Ergebnis zurück, Handy
const { chromium } = require('playwright');
let f = 0; const ok = (b, t) => { console.log((b ? 'ok   ' : 'FEHL ') + t); if(!b) f++; };
function daten(){
  return { objekte: [
    { id: 'o1', akqTitel: 'Einfamilienhaus mit Garten', adresse: 'Wuhletal 15, 12683 Berlin', ort: '12683 Berlin', objektart: 'Haus', objekttyp: 'Einfamilienhaus', wohnflaeche: 112, grundstueck: 551, baujahr: 1996, zimmer: 5, kaufpreis: 489000, status: 'auftrag', verkaeuferName: 'Erika Mustermann', verkaeuferTelefon: '0171 9998877', verkaeuferEmail: 'erika@example.org', verlauf: [],
      expose: { eingelesen: Date.now(), felder: { 'Heizungsart': 'Gas-Brennwert (2019)', 'Energieausweis': 'Bedarfsausweis', 'Endenergiebedarf': '128,4 kWh/(m²a)', 'Energieeffizienzklasse': 'D', 'Garage/Stellplatz': 'Garage' } } },
    { id: 'o2', akqTitel: '3-Zi-Wohnung Lichtenberg', adresse: 'Frankfurter Allee 200, 10365 Berlin', ort: '10365 Berlin', objektart: 'Wohnung', wohnflaeche: 72, status: 'neu', link: 'https://www.kleinanzeigen.de/s-anzeige/x/1', kaufpreis: 299000, verlauf: [] }],
    kontakte: [], termine: [], aufgaben: [], notizen: [], meta: { v9neustart: { quittiert: true } } };
}
async function seite(b, geraet, breite){
  const p = await b.newPage({ viewport: { width: breite || 1440, height: 900 } });
  p.fe = []; p.on('pageerror', e => p.fe.push(e.message)); p.on('dialog', d => d.dismiss());
  await p.addInitScript(([d, g]) => {
    window.__kopie = []; window.__gesp = [];
    window.pc = { geraet: g, laden: () => JSON.parse(d), speichern: t => { window.__gesp.push(t); return { ok: true }; }, ordner(){}, sicherungSchreiben: () => ({ ok: true }), sicherungLesen: () => null, zwischenablage: async () => '', abruf: async () => ({ ok: false }) };
    Object.defineProperty(navigator, 'clipboard', { value: { writeText: async t => { window.__kopie.push(t); } }, configurable: true });
  }, [JSON.stringify(daten()), geraet || 'pc']);
  await p.goto('file:///tmp/pc/app/index.html'); await p.waitForTimeout(2200);
  return p;
}
(async () => {
  const b = await chromium.launch();
  let p = await seite(b);
  // Navigation
  const nav = await p.evaluate(() => { const i = NAV.findIndex(x => x.key === 'shooting'); return { nach: (NAV[i + 1] || {}).key, label: (NAV[i + 1] || {}).label, inLeiste: !!document.querySelector('#nav [onclick*="grossanalyse"]') }; });
  ok(nav.nach === 'grossanalyse' && nav.label === 'Große Analyse' && nav.inLeiste, 'Menüpunkt „Große Analyse“ direkt unter Shooting-Analyse');
  await p.evaluate(() => wechsleAnsicht('grossanalyse')); await p.waitForTimeout(300);
  ok(await p.evaluate(() => !!document.querySelector('.ga35') && /Große Analyse/.test(document.querySelector('.ga35 h2').textContent)), 'Seite öffnet sich');
  // Objekt wählen → Vorbelegung
  await p.selectOption('#ga35Obj', 'o1'); await p.waitForTimeout(300);
  let r = await p.evaluate(() => { const e = ga35Entwurf('o1'); const v = k => (e.werte[k] || {}).v; const s = k => (e.werte[k] || {}).s;
    return { art: e.art, adr: v('adresse'), plz: v('plz'), ort: v('ort'), wfl: v('wfl'), grund: v('grund'), bj: v('baujahr'), heiz: v('heizung'), ea: v('ea_art'), kw: v('ea_kw'), kl: v('ea_klasse'), wunsch: v('wunsch'), angebot: v('angebot'), region: e.region, adrS: s('adresse'), expose: e.unterlagen.expose,
      felder: document.querySelectorAll('.ga35 [data-ga]').length, etwFeld: !!document.querySelector('[data-ga="hausgeld"]') }; });
  ok(r.art === 'EFH' && r.adr === 'Wuhletal 15' && r.plz === '12683' && r.ort === 'Berlin' && r.region === 'Berlin', 'Vorbelegung: Objektart EFH, Adresse/PLZ/Ort getrennt, Region Berlin');
  ok(r.wfl === '112' && r.grund === '551' && r.bj === '1996', 'Vorbelegung: Wohnfläche, Grundstück, Baujahr');
  ok(/Gas-Brennwert/.test(r.heiz) && r.ea === 'Bedarf' && r.kw === '128,4' && r.kl === 'D' && r.expose, 'Exposé-Daten übernommen (Heizung, Bedarfsausweis, 128,4 kWh, Klasse D)');
  ok(r.wunsch === '489000' && !r.angebot, 'Preis eines Auftrags (nicht inseriert) als Wunschpreis, nicht als Angebot');
  ok(!r.etwFeld && r.felder > 30, `Haus: keine WEG-Felder (${r.felder} Felder)`);
  // Ampel: STOP? (nutzung, erbbau, wfl ok …)
  r = await p.evaluate(() => ({ t: document.querySelector('.ga35-ampel').innerText }));
  ok(/STOP/.test(r.t) && /Nutzung/.test(r.t) && /Erbbaurecht/.test(r.t), 'Ampel zeigt fehlende Pflichtangaben (Nutzung, Erbbaurecht)');
  ok(/Immobilienpreis-Info/.test(r.t), 'Hinweis: tatsächliche Kaufpreise über Immobilienpreis-Info Berlin');
  // Eingaben
  await p.selectOption('[data-ga="nutzung"]', 'eigengenutzt'); await p.waitForTimeout(150);
  await p.selectOption('[data-ga="erbbau"]', 'nein'); await p.waitForTimeout(150);
  await p.fill('[data-ga="besichtigt"]', '2026-11-10');
  await p.selectOption('[data-gs="wfl"]', 'documented');
  await p.selectOption('[data-ga="wfl_regel"]', 'WoFlV'); await p.waitForTimeout(150);
  await p.fill('[data-ga="lasten"]', 'keine bekannt laut Eigentümer');
  await p.fill('[data-ga="bauweise"]', 'massiv');
  await p.selectOption('[data-ga="standard"]', 'mittel'); await p.waitForTimeout(150);
  await p.selectOption('[data-ga="zustand"]', 'gepflegt'); await p.waitForTimeout(150);
  await p.click('text=＋ Vergleichsfall'); await p.waitForTimeout(150);
  await p.fill('[data-gv="0"] [data-gc="preis"]', '455000'); await p.fill('[data-gv="0"] [data-gc="flaeche"]', '118'); await p.fill('[data-gv="0"] [data-gc="datum"]', '05/2026'); await p.fill('[data-gv="0"] [data-gc="lage"]', 'Kaulsdorf'); await p.fill('[data-gv="0"] [data-gc="quelle"]', 'eigener Abschluss Nr. 12');
  await p.selectOption('[data-gv="0"] [data-gc="art"]', 'own_closing'); await p.waitForTimeout(200);
  await p.click('text=＋ Vergleichsfall'); await p.waitForTimeout(150);
  await p.fill('[data-gv="1"] [data-gc="preis"]', '520000'); await p.selectOption('[data-gv="1"] [data-gc="art"]', 'listing'); await p.fill('[data-gv="1"] [data-gc="quelle"]', 'https://www.kleinanzeigen.de/s-anzeige/y/2'); await p.waitForTimeout(150);
  await p.check('[data-gu="grundriss"]'); await p.check('[data-gu="energie"]'); await p.waitForTimeout(600);
  r = await p.evaluate(() => document.querySelector('.ga35-ampel').innerText);
  ok(!/STOP/.test(r), 'Nach Eingaben kein STOP mehr: ' + r.split('\n')[0]);
  // Prompt
  await p.click('text=Prompt erzeugen'); await p.waitForTimeout(500);
  r = await p.evaluate(() => { const t = window.__kopie[window.__kopie.length - 1] || ''; const m = /ANALYSEPAKET_JSON:\n```json\n([\s\S]*?)\n```/.exec(t); let j = null; try{ j = JSON.parse(m[1]); }catch(e){} return { t, j, laeufe: db.grossanalyse.laeufe.length }; });
  const t = r.t, j = r.j;
  ok(/Master-Prompt: Immobilienmarktanalyse/.test(t) && /B1\. Tatsächliche Verkaufspreise/.test(t), 'Prompt enthält den Master-Prompt v1.1 (inkl. B1 Kaufpreise)');
  ok(/Ergänzung für die Nutzung in diesem Chat/.test(t) && /## Auftrag/.test(t) && !/<Hier das durch das separate System/.test(t), 'Chat-Ergänzung + Auftrag, Platzhalter ersetzt');
  ok(j && j.schema_version === '1.0' && /^GA-\d{8}-wuhletal-15-v1$/.test(j.request.run_id), 'Analysepaket ist gültiges JSON mit run_id ' + (j && j.request.run_id));
  ok(j && j.subject.object_type === 'EFH' && j.subject.address === 'Wuhletal 15' && j.request.region === 'Berlin' && j.request.quality_date === '2026-11-10', 'subject/request korrekt');
  const fakt = k => j && j.facts.find(x => x.field === k);
  ok(fakt('gebaeude[0].wfl_innen_m2') && fakt('gebaeude[0].wfl_innen_m2').value === 112 && fakt('gebaeude[0].wfl_innen_m2').status === 'documented' && fakt('gebaeude[0].wfl_innen_m2').unit === 'm²', 'Fakt Wohnfläche: Zahl, Einheit, Status „documented“');
  ok(fakt('grundstueck[0].flaeche_m2').value === 551 && fakt('lage.besichtigungsdatum').valid_at === '2026-11-10', 'Grundstück 551 m², Besichtigungsdatum');
  ok(j.request.owner_wish_price_eur === 489000 && /niemals zur Steuerung/.test(j.request.owner_wish_price_note), 'Wunschpreis getrennt, mit Hinweis „nur Vergleich“');
  ok(j.comparables.length === 2 && j.comparables[0].price_type === 'own_closing' && j.comparables[0].price_eur === 455000 && j.comparables[0].area_type === 'Wfl' && j.comparables[1].price_type === 'listing' && j.comparables[1].verification_status === 'listing_only', 'Vergleichsfälle: Abschluss und Inserat getrennt');
  ok(j.sources.some(s => s.source_id === 'D1' && /Exposé/.test(s.title)) && j.sources.some(s => /Grundriss/.test(s.title)) && /Beigefügte Unterlagen: D1 = Exposé; D2 = Grundrisse; D3 = Energieausweis/.test(t), 'Unterlagen als Quellen D1–D3 und im Auftrag genannt');
  ok(j.facts.some(x => x.field === 'expose.Heizungsart' && x.source_id === 'D1'), 'Exposé-Objektinformationen als Dokumentangaben (Quelle D1)');
  ok(!/Mustermann|9998877|erika@example/.test(t), 'Keine Eigentümer-Kontaktdaten im Prompt');
  ok(j.report_options.include_personal_data === false && j.calibration.available === false && j.model_profiles.length === 0, 'Datenschutz-Option, keine erfundenen Modelle/Kalibrierung');
  ok(r.laeufe === 1 && await p.evaluate(() => /Bisherige Analysen/.test(document.querySelector('.ga35').innerText)), 'Analyse-Lauf gespeichert und angezeigt');
  // Hausnummer weglassen
  await p.check('[data-gk="ohneHausnr"]'); await p.waitForTimeout(500);
  r = await p.evaluate(() => JSON.stringify(ga35Paket('o1', ga35Entwurf('o1'))));
  ok(!/Wuhletal 15/.test(r) && /Wuhletal/.test(r), 'Option „Hausnummer nicht an die KI“ wirkt');
  // Ergebnis zurück
  await p.click('text=Ergebnis (report.json) einfügen'); await p.waitForTimeout(300);
  await p.fill('#ga35ErgText', 'Hier ist das Ergebnis:\n```json\n{"schema_version":"1.0","run_id":"' + j.request.run_id + '","status":"ready_for_review","valuation":{"central_eur":432000.4,"low_eur":405000,"high_eur":455000,"band_type":"Szenarioband","confidence_level":null,"quality_grade":"C<script>"}}\n```');
  await p.click('#modalInner button:has-text("Übernehmen")'); await p.waitForTimeout(400);
  r = await p.evaluate(() => ({ e: db.grossanalyse.laeufe[0].ergebnis, html: document.querySelector('.ga35').innerHTML }));
  ok(r.e.central === 432000 && r.e.low === 405000 && r.e.high === 455000 && r.e.grade === 'Cscript' && r.e.status === 'ready_for_review', 'report.json eingelesen (nur Zahlen/kurze Texte, „<“ entfernt)');
  ok(/432\.000 €/.test(r.html), 'Ergebnis in der Liste angezeigt');
  await p.click('text=Als Einschätzung ins Objekt'); await p.waitForTimeout(300);
  ok(await p.evaluate(() => findObjekt('o1').einschaetzung === 432000), 'Als Einschätzung ins Objekt übernommen');
  // blocked → kein Wert
  r = await p.evaluate(() => ga35ErgebnisLesen('{"status":"blocked","valuation":{"central_eur":400000}}'));
  ok(r.central === null, 'Status „blocked“ → kein zentraler Wert übernommen');
  // ETW
  await p.selectOption('#ga35Obj', 'o2'); await p.waitForTimeout(300);
  r = await p.evaluate(() => { const e = ga35Entwurf('o2'); return { art: e.art, angebot: (e.werte.angebot || {}).v, hausgeld: !!document.querySelector('[data-ga="hausgeld"]'), grund: !!document.querySelector('[data-ga="grund"]'), weg: !!document.querySelector('[data-gu="weg"]') }; });
  ok(r.art === 'ETW' && r.angebot === '299000' && r.hausgeld && !r.grund && r.weg, 'Wohnung: ETW-Felder (Hausgeld, WEG-Unterlagen), kein Grundstück; inserierter Preis = Angebotspreis');
  // Nachforderung
  await p.click('text=Unterlagen beim Eigentümer anfragen'); await p.waitForTimeout(300);
  r = await p.evaluate(() => window.__kopie[window.__kopie.length - 1]);
  ok(/Teilungserklärung/.test(r) && /Energieausweis/.test(r) && /Paul Görner/.test(r), 'Anfrage-Text an den Eigentümer mit fehlenden Unterlagen');
  // Master-Prompt bearbeiten
  await p.evaluate(() => { ga35MasterDialog(); document.getElementById('ga35Master').value = 'EIGENE REGELN'; ga35MasterSpeichern(); });
  r = await p.evaluate(() => ga35Prompt('o2', ga35Entwurf('o2')).text);
  ok(/^EIGENE REGELN/.test(r), 'Eigener Master-Prompt wird verwendet');
  await p.evaluate(() => ga35MasterStd());
  ok(/^# Master-Prompt/.test(await p.evaluate(() => ga35Prompt('o2', ga35Entwurf('o2')).text)), 'Standard wiederherstellbar');
  // Gespeichert + Neuladen
  r = await p.evaluate(() => { const d = JSON.parse(window.__gesp[window.__gesp.length - 1]); return d.grossanalyse && d.grossanalyse.entwuerfe.o1 && d.grossanalyse.entwuerfe.o1.werte.nutzung.v; });
  ok(r === 'eigengenutzt', 'Erfassung wird gespeichert');
  ok(p.fe.length === 0, 'Keine Fehler ' + p.fe.join(' | '));
  await p.screenshot({ path: '/tmp/v35test/pc.png', fullPage: false });
  await p.close();
  // Handy
  p = await seite(b, 'handy', 390);
  await p.evaluate(() => { GA35.obj = 'o1'; wechsleAnsicht('grossanalyse'); }); await p.waitForTimeout(400);
  r = await p.evaluate(() => ({ breit: document.documentElement.scrollWidth, n: document.querySelectorAll('.ga35 [data-ga]').length }));
  ok(r.n > 30 && r.breit <= 392, `Handy: Seite passt in die Breite (${r.breit}px)`);
  await p.screenshot({ path: '/tmp/v35test/handy.png', fullPage: false });
  ok(p.fe.length === 0, 'Handy: keine Fehler ' + p.fe.join(' | '));
  await b.close(); console.log('FEHLER', f);
})();
