const { chromium } = require('playwright'); const fs = require('fs');
(async () => {
  const b = await chromium.launch(); const p = await b.newPage();
  await p.addInitScript(d => { window.pc = { geraet: 'pc', laden: () => JSON.parse(d), speichern: () => ({ ok: true }), ordner(){}, sicherungSchreiben: () => ({ ok: true }), sicherungLesen: () => null }; }, JSON.stringify({ objekte: [], kontakte: [], termine: [], aufgaben: [], notizen: [], meta: { v9neustart: { quittiert: true } } }));
  await p.goto('file:///tmp/pc/app/index.html'); await p.waitForTimeout(1800);
  const t = await p.evaluate(() => ga35Prompt(null, ga35Entwurf(null)).text);
  fs.writeFileSync('/tmp/v35test/Grosse-Analyse-Prompt-Vorlage.md', t); console.log(t.length); await b.close();
})();
