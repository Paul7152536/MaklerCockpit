// v18: dokumente.js (Hauptprozess) mit nachgebautem Electron
const Module = require('module'); const fs = require('fs'); const os = require('os'); const path = require('path');
let fehler = 0; const ok = (b, t) => { if(!b){ fehler++; console.log('FEHLER:', t); } else console.log('ok  ', t); };
const ORDNER = fs.mkdtempSync(path.join(os.tmpdir(), 'dok-')); const QUELLE = fs.mkdtempSync(path.join(os.tmpdir(), 'quelle-'));
fs.writeFileSync(path.join(QUELLE, 'Energieausweis.pdf'), '%PDF-1.4 test'); fs.writeFileSync(path.join(QUELLE, 'Foto.jpg'), 'JPEG');
let auswahl = [], geoeffnet = [], gezeigt = [], papierkorb = [], trashFehler = false;
const electron = {
  dialog: { showOpenDialog: async () => auswahl.length ? { canceled:false, filePaths: auswahl } : { canceled:true, filePaths:[] } },
  shell: { openPath: async p => { geoeffnet.push(p); return fs.existsSync(p) ? '' : 'nicht gefunden'; }, showItemInFolder: p => gezeigt.push(p),
    trashItem: async p => { if(trashFehler) throw new Error('kein Papierkorb'); papierkorb.push(p); fs.unlinkSync(p); } }
};
const orig = Module._load; Module._load = function(r, ...a){ return r === 'electron' ? electron : orig.call(this, r, ...a); };
let h; require('/tmp/pc/app/dokumente.js')({ handle: (n, f) => h = f }, ORDNER, () => null);
const ruf = (a, x) => h({}, a, x);
(async () => {
  let r = await ruf('basis'); ok(r.ok && r.basis === path.resolve(ORDNER, 'Unterlagen') && fs.existsSync(r.basis), 'Basisordner angelegt');
  auswahl = [path.join(QUELLE, 'Energieausweis.pdf'), path.join(QUELLE, 'Foto.jpg')];
  r = await ruf('auswaehlen', { ordner: 'Lindenweg 5, Ludwigsfelde (abc123)' });
  ok(r.ok && r.dateien.length === 2 && r.dateien[0].datei === 'Lindenweg 5, Ludwigsfelde (abc123)/Energieausweis.pdf' && r.dateien[0].groesse === 13, 'Dateien in Objekt-Ordner kopiert');
  r = await ruf('auswaehlen', { ordner: 'Lindenweg 5, Ludwigsfelde (abc123)' });
  ok(r.dateien[0].datei.endsWith('Energieausweis (2).pdf'), 'Gleicher Name → „(2)“ statt überschreiben');
  auswahl = []; r = await ruf('auswaehlen', { ordner: 'X' }); ok(!r.ok && r.abgebrochen, 'Abbrechen erkannt');
  r = await ruf('speichern', { ordner: 'Lindenweg 5, Ludwigsfelde (abc123)', name: 'Grundriss EG.png', daten: new Uint8Array([1,2,3,4]) });
  ok(r.ok && fs.readFileSync(path.join(ORDNER, 'Unterlagen', r.datei.datei)).length === 4, 'Gezogene Datei gespeichert');
  r = await ruf('speichern', { ordner: 'Y', name: 'a/../../böse.txt', daten: new Uint8Array([1]) });
  ok(r.ok && r.datei.datei.split('/').length === 2 && r.datei.datei.startsWith('Y/') && fs.existsSync(path.join(ORDNER, 'Unterlagen', r.datei.datei)), 'Schrägstriche im Namen entschärft: ' + r.datei.datei);
  for(const o of ['..', '../x', 'a/b', 'C:\\x', '']){ r = await ruf('auswaehlen', { ordner: o }); ok(!r.ok && /Ungültiger Ordnername/.test(r.fehler), 'Ordnername gesperrt: ' + JSON.stringify(o)); }
  r = await ruf('oeffnen', { datei: '../../daten.json' }); ok(!r.ok && /nicht erlaubt/.test(r.fehler), 'Öffnen außerhalb gesperrt');
  r = await ruf('loeschen', { datei: '../Unterlagen/../daten.json' }); ok(!r.ok, 'Löschen außerhalb gesperrt');
  r = await ruf('oeffnen', { datei: 'Lindenweg 5, Ludwigsfelde (abc123)/Energieausweis.pdf' }); ok(r.ok && geoeffnet.length === 1, 'Öffnen');
  r = await ruf('zeigen', { datei: 'Lindenweg 5, Ludwigsfelde (abc123)/Foto.jpg' }); ok(r.ok && gezeigt.length === 1, 'Im Ordner zeigen');
  r = await ruf('oeffnen', { datei: 'Lindenweg 5, Ludwigsfelde (abc123)/fehlt.pdf' }); ok(!r.ok && r.code === 'weg', 'Fehlende Datei erkannt');
  r = await ruf('vorhanden', { dateien: ['Lindenweg 5, Ludwigsfelde (abc123)/Foto.jpg', 'x/fehlt.pdf', '../../x'] }); ok(JSON.stringify(r.da) === '[true,false,false]', 'Vorhanden-Prüfung');
  r = await ruf('loeschen', { datei: 'Lindenweg 5, Ludwigsfelde (abc123)/Foto.jpg' }); ok(r.ok && r.papierkorb && papierkorb.length === 1, 'Entfernen → Papierkorb');
  trashFehler = true; r = await ruf('loeschen', { datei: 'Lindenweg 5, Ludwigsfelde (abc123)/Energieausweis.pdf' });
  ok(r.ok && r.papierkorb === false && fs.existsSync(path.join(ORDNER, 'Unterlagen', '_Papierkorb', 'Energieausweis.pdf')), 'Ohne Papierkorb → Unterlagen\\_Papierkorb');
  r = await ruf('ordner', { ordner: 'Neues Objekt (zz9)' }); ok(r.ok && fs.existsSync(path.join(ORDNER, 'Unterlagen', 'Neues Objekt (zz9)')), 'Ordner wird angelegt und geöffnet');
  console.log('\nFEHLER', fehler); process.exit(fehler ? 1 : 0);
})();
