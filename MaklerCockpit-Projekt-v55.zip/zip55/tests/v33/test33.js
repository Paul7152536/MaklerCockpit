// v33: PDF-Werkzeuge im Cockpit + Leiste/Seiten springen nicht nach oben
const { chromium } = require('playwright'); const fs = require('fs');
let f = 0; const ok = (b, t) => { console.log((b ? 'ok   ' : 'FEHL ') + t); if(!b) f++; };
const T = 864e5;
(async () => {
  const b = await chromium.launch();
  const p = await b.newPage({ viewport: { width: 1440, height: 900 } });
  const fe = []; p.on('pageerror', e => fe.push('Seite: ' + e.message)); p.on('dialog', d => d.dismiss());
  const netz = []; p.on('request', r => { if(/^https?:/.test(r.url())) netz.push(r.url()); });
  const obj = []; for(let i = 0; i < 40; i++) obj.push({ id: 'n' + i, createdAt: Date.now() - i * 1000, akqTitel: 'Lead ' + i, ort: '10365 Berlin', objektart: 'Wohnung', status: 'neu', quelle: 'Kleinanzeigen', link: 'https://www.kleinanzeigen.de/s-anzeige/' + i, verlauf: [] });
  await p.addInitScript(d => { window.__gespeichert = []; window.pc = { geraet: 'pc', laden: () => JSON.parse(d), speichern: () => ({ ok: true }), ordner(){}, sicherungSchreiben: () => ({ ok: true }), sicherungLesen: () => null, zwischenablage: async () => '', abruf: async () => ({ ok: false }),
    dateiSpeichern: async (name, b64) => { window.__gespeichert.push({ name, kopf: atob(b64.slice(0, 8)).slice(0, 4), laenge: b64.length }); return { ok: true, pfad: 'C:/x/' + name, name }; }, dateiOeffnen(){} }; }, JSON.stringify({ objekte: obj, kontakte: [], termine: [], aufgaben: [], notizen: [], gesuche: [], marktanalysen: [], mentorFragen: [], meta: { v9neustart: { quittiert: true } } }));
  await p.goto('file:///tmp/pc/app/index.html'); await p.waitForTimeout(2500);
  // pdf.js im Cockpit ohne eval
  let r = await p.evaluate(() => ({ flag: !!pdfjsLib.__mc33 }));
  ok(r.flag, 'pdf.js im Cockpit abgesichert (ohne eval)');
  // Navigation zu PDF-Werkzeuge
  ok(await p.evaluate(() => /PDF-Werkzeuge/.test(document.getElementById('nav').innerText) && !/Bilder zu PDF/.test(document.getElementById('nav').innerText)), 'Seitenleiste: „PDF-Werkzeuge“ statt „Bilder zu PDF“');
  await p.evaluate(() => wechsleAnsicht('pdfs')); await p.waitForTimeout(2500);
  const fr = await (await p.$('#pdf33Frame')).contentFrame();
  ok(!!fr, 'PDF-Werkzeuge geladen (eigener Rahmen)');
  r = await fr.evaluate(() => ({ tabs: Array.from(document.querySelectorAll('.tab-btn')).map(x => x.innerText), libs: [typeof jspdf, typeof Tesseract, typeof pdfjsLib, typeof PDFLib, typeof Sortable, typeof Peer].join(','), sicher: pdfjsLib.getDocument.toString().includes('isEvalSupported') }));
  ok(r.tabs.length === 4 && r.libs === 'object,object,object,object,function,function' && r.sicher, 'Vier Reiter, alle Bausteine lokal geladen ' + r.libs);
  const box = await p.evaluate(() => { const d = document.getElementById('pdf33').getBoundingClientRect(), m = document.getElementById('main').getBoundingClientRect(); return [Math.round(d.left - m.left), Math.round(d.top - m.top), Math.round(d.width - m.width), Math.round(d.bottom)]; });
  ok(box[0] === 0 && box[1] === 0 && box[2] === 0 && box[3] === 900, 'Rahmen deckt genau den Hauptbereich ab ' + JSON.stringify(box));
  // Dateien hinzufügen: Exposé-PDF (11 Seiten) + Foto + Datei mit präpariertem Namen
  const inp = await fr.$('#fileInput');
  await inp.setInputFiles(['/tmp/v27test/ex/beispiel.pdf', '/tmp/v33test/foto.jpg', '/tmp/v33test/<img src=x onerror=window.parent.__xss=1>.jpg']);
  await fr.waitForFunction(() => document.querySelectorAll('.pageCard').length >= 12, null, { timeout: 90000 }).catch(() => {});
  await p.waitForTimeout(800);
  r = await fr.evaluate(() => ({ n: document.querySelectorAll('.pageCard').length, status: document.getElementById('status').textContent, namen: Array.from(document.querySelectorAll('.srcName')).map(x => x.textContent) }));
  ok(r.n === 12 && /1 doppelte Seite/.test(r.status), '11 Seiten aus der PDF + 1 Foto, gleiches Foto (2. Datei) als doppelt übersprungen: ' + r.n + ' · ' + r.status);
  await inp.setInputFiles(['/tmp/v33test/<img src=x onerror=window.parent.__xss=1>.jpg']);  // erneut, autoDedup → übersprungen; nun ausschalten
  await fr.evaluate(() => { document.getElementById('autoDedup').checked = false; });
  await inp.setInputFiles(['/tmp/v33test/<img src=x onerror=window.parent.__xss=1>.jpg']); await p.waitForTimeout(1200);
  r = await p.evaluate(() => window.__xss || 0); const nm = await fr.evaluate(() => document.querySelectorAll('.pageCard').length + '|' + document.querySelector('.pageCard:last-child .srcName').textContent);
  ok(r === 0 && /<img src=x/.test(nm), 'Dateiname mit HTML wird als Text gezeigt, nichts ausgeführt (' + nm + ')');
  // Drehen + Seite entfernen
  r = await fr.evaluate(() => { const vor = document.querySelectorAll('.pageCard').length; while(document.querySelectorAll('.pageCard').length > 12) document.querySelector('.pageCard:last-child [data-action="remove"]').click(); const c = document.querySelector('.pageCard canvas'); const hoch = c.height > c.width; document.querySelector('.pageCard [data-action="rotate-right"]').click(); const c2 = document.querySelector('.pageCard canvas'); return { vor, nach: document.querySelectorAll('.pageCard').length, gedreht: hoch && c2.width > c2.height }; });
  ok(r.vor > 12 && r.nach === 12 && r.gedreht, 'Seiten entfernen und drehen (' + r.vor + ' → ' + r.nach + ', Seite 1 quer)');
  // Seite wechseln und zurück → Seiten noch da
  await p.evaluate(() => wechsleAnsicht('akquise')); await p.waitForTimeout(400);
  ok(await p.evaluate(() => document.getElementById('pdf33').style.display) === 'none', 'Andere Seite: PDF-Werkzeuge ausgeblendet');
  await p.evaluate(() => wechsleAnsicht('pdfs')); await p.waitForTimeout(400);
  ok(await fr.evaluate(() => document.querySelectorAll('.pageCard').length) === 12, 'Zurück: alle 12 Seiten noch da (nichts geht verloren)');
  // PDF erstellen & speichern
  await fr.evaluate(() => { document.getElementById('outName').value = 'Exposé Beuthstraße'; document.getElementById('previewBtn').click(); });
  await p.waitForTimeout(800);
  ok(await fr.evaluate(() => document.querySelectorAll('#previewPages canvas').length) === 12, 'Vorschau mit 12 Seiten');
  await fr.evaluate(() => document.getElementById('downloadFromPreviewBtn').click());
  await p.waitForFunction(() => window.__gespeichert.length >= 1, null, { timeout: 60000 }).catch(() => {});
  r = await p.evaluate(() => ({ g: window.__gespeichert.slice(), hinweis: document.getElementById('mcPdfHinweis') ? document.getElementById('mcPdfHinweis').innerText : '' }));
  ok(r.g.length === 1 && /^Exposé Beuthstraße_\d{4}-\d\d-\d\d-\d\d-\d\d-\d\d\.pdf$/.test(r.g[0].name) && r.g[0].kopf === '%PDF' && /PDF gespeichert/.test(r.hinweis), 'PDF über „Speichern unter“ des Cockpits gespeichert: ' + (r.g[0] || {}).name);
  // Texterkennung im Editor (lokal, deutsch)
  await fr.evaluate(() => document.querySelector('.pageCard [data-action="edit"]').click());
  await fr.waitForFunction(() => /Textzeilen erkannt|fehlgeschlagen/.test(document.getElementById('ocrStatus').textContent), null, { timeout: 120000 }).catch(() => {});
  r = await fr.evaluate(() => document.getElementById('ocrStatus').textContent);
  if(/origin 'null'/.test(r)) console.log('     Texterkennung: im Test-Browser (file://) gesperrt – im echten Programm geprüft (pdf33_electron.js)');
  else ok(/^\d+ Textzeilen erkannt/.test(r) && parseInt(r) > 5, 'Texterkennung offline: ' + r);
  await fr.evaluate(() => document.getElementById('closeEditorBtn').click());
  // Komprimieren
  await fr.evaluate(() => mcTab('tab-compress'));
  await (await fr.$('#cmpFileInput')).setInputFiles('/tmp/v27test/ex/beispiel.pdf');
  await fr.evaluate(() => { document.getElementById('cmpQuality').value = 60; document.getElementById('cmpRunBtn').click(); });
  await fr.waitForFunction(() => /Fertig|Fehler/.test(document.getElementById('cmpResultText').textContent + document.getElementById('cmpStatus').textContent), null, { timeout: 120000 }).catch(() => {});
  r = await fr.evaluate(() => document.getElementById('cmpResultText').textContent);
  ok(/Fertig: 3,4 MB → .* kleiner/.test(r), 'Komprimieren: ' + r);
  await fr.evaluate(() => document.getElementById('cmpDownloadBtn').click()); await p.waitForTimeout(1500);
  ok(await p.evaluate(() => window.__gespeichert.length === 2 && /_komprimiert\.pdf$/.test(window.__gespeichert[1].name)), 'Komprimierte PDF gespeichert');
  // Aufteilen (Limit 1 MB)
  await fr.evaluate(() => mcTab('tab-split'));
  await (await fr.$('#spFile')).setInputFiles('/tmp/v27test/ex/beispiel.pdf'); await p.waitForTimeout(1500);
  await fr.evaluate(() => { document.getElementById('spMax').value = 1; document.getElementById('spRun').click(); });
  await fr.waitForFunction(() => /Teile erstellt|Fehler|kleiner als/.test(document.getElementById('spStatus').textContent), null, { timeout: 120000 }).catch(() => {});
  r = await fr.evaluate(() => ({ s: document.getElementById('spStatus').textContent, z: document.querySelectorAll('.teilZeile').length, zip: !!Array.from(document.querySelectorAll('#spResult button')).find(x => /ZIP/.test(x.textContent)) }));
  ok(/Teile erstellt/.test(r.s) && r.z >= 3 && r.zip, 'Aufteilen: ' + r.s + ' (' + r.z + ' Teile, ZIP-Knopf am PC)');
  await fr.evaluate(() => document.querySelector('.teilZeile button').click()); await p.waitForTimeout(1500);
  ok(await p.evaluate(() => window.__gespeichert.length === 3 && /_Teil1von\d+\.pdf$/.test(window.__gespeichert[2].name) && window.__gespeichert[2].kopf === '%PDF'), 'Teil 1 gespeichert');
  // Übertragen-Reiter
  await fr.evaluate(() => mcTab('tab-transfer'));
  r = await fr.evaluate(() => ({ empf: document.getElementById('trRecv').style.display !== 'none', peer: typeof Peer }));
  ok(r.empf && r.peer === 'function', 'Am PC: „Empfangen“ vorausgewählt, Übertragungs-Baustein da');
  ok(netz.filter(u => !/peerjs|kleinanzeigen/.test(u)).length === 0, 'Kein Abruf aus dem Internet (außer bewusst gestarteter Übertragung) ' + JSON.stringify(netz.slice(0, 3)));
  // Leiste und Seiten springen nicht nach oben
  await p.evaluate(() => wechsleAnsicht('akquise')); await p.waitForTimeout(400);
  await p.evaluate(() => { const l = document.querySelector('.sb-liste'); l.style.maxHeight = '300px'; });
  const st0 = await p.evaluate(() => { const l = document.querySelector('.sb-liste'); l.scrollTop = 150; return l.scrollTop; });
  await p.evaluate(() => { document.getElementById('main').scrollTop = 900; });
  const akqPos = await p.evaluate(() => document.getElementById('main').scrollTop);
  await p.evaluate(() => { const e = Array.from(document.querySelectorAll('#nav [onclick*="wechsleAnsicht(\'termine\')"]'))[0]; e.click(); }); await p.waitForTimeout(400);
  r = await p.evaluate(() => ({ leiste: document.querySelector('.sb-liste').scrollTop, main: document.getElementById('main').scrollTop, seite: aktuelleAnsicht }));
  ok(st0 > 0 && r.leiste === st0 && r.seite === 'termine', 'Klick in der Leiste: Leiste bleibt stehen (' + r.leiste + ' px)');
  ok(r.main === 0, 'Neue Seite beginnt oben');
  await p.evaluate(() => { const e = Array.from(document.querySelectorAll('#nav [onclick*="wechsleAnsicht(\'akquise\')"]'))[0]; e.click(); }); await p.waitForTimeout(400);
  r = await p.evaluate(() => ({ leiste: document.querySelector('.sb-liste').scrollTop, main: document.getElementById('main').scrollTop }));
  ok(akqPos > 500 && r.main === akqPos && r.leiste === st0, 'Zurück zur Akquise über die Leiste: wieder an derselben Stelle (' + r.main + ' px)');
  await p.evaluate(() => { const e = Array.from(document.querySelectorAll('#nav [onclick*="wechsleAnsicht(\'akquise\')"]'))[0]; e.click(); }); await p.waitForTimeout(300);
  ok(await p.evaluate(() => document.getElementById('main').scrollTop) === akqPos, 'Klick auf die Seite, auf der man schon ist: nichts springt');
  ok(fe.length === 0, 'Keine Fehler ' + JSON.stringify(fe));
  await p.close();
  // Handy: Senden vorausgewählt, Rahmen über der unteren Leiste, kein ZIP
  const h = await b.newPage({ viewport: { width: 390, height: 844 } });
  await h.addInitScript(() => { window.pc = { geraet: 'handy', laden: () => null, speichern: () => ({ ok: true }), ordner(){}, sicherungSchreiben: () => ({ ok: true }), sicherungLesen: () => null, zwischenablage: async () => '', abruf: async () => ({ ok: false }), dateiSpeichern: async () => ({ ok: true }) }; });
  await h.goto('file:///tmp/pc/app/index.html'); await h.waitForTimeout(2000);
  await h.evaluate(() => wechsleAnsicht('pdfs')); await h.waitForTimeout(2000);
  const hf = await (await h.$('#pdf33Frame')).contentFrame();
  r = await hf.evaluate(() => ({ senden: document.getElementById('trSend').style.display !== 'none', zip: getComputedStyle(document.getElementById('trZipBtn')).display, breit: document.documentElement.scrollWidth }));
  const lage = await h.evaluate(() => { const d = document.getElementById('pdf33').getBoundingClientRect(); const t = document.getElementById('h25Tabs'); return [Math.round(d.bottom), t ? Math.round(t.getBoundingClientRect().top) : 844, Math.round(d.width)]; });
  ok(r.senden && r.zip === 'none' && r.breit <= 392, 'Handy: „Senden“ vorausgewählt, kein ZIP, passt in die Breite');
  ok(lage[0] <= lage[1] && lage[2] === 390, 'Handy: Rahmen endet über der unteren Leiste ' + JSON.stringify(lage));
  await h.screenshot({ path: '/tmp/v33test/handy.png' });
  console.log('FEHLER', f); await b.close();
})();
