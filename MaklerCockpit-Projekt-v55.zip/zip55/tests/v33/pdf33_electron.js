// v33: PDF-Werkzeuge im echten Programm – Texterkennung (offline), Speichern, Leiste
const { app, BrowserWindow, dialog } = require('electron'); const fs = require('fs');
const HOME = '/tmp/claude-0/-home-claude/fcfe88c9-293d-574d-8cfa-b1821c923895/scratchpad/etest/home33p';
fs.rmSync(HOME, { recursive: true, force: true }); app.setPath('documents', HOME + '/Dokumente');
fs.mkdirSync(HOME + '/aus', { recursive: true });
dialog.showSaveDialog = async (w, o) => ({ canceled: false, filePath: HOME + '/aus/' + require('path').basename(o.defaultPath) });
require(process.env.MC_MAIN || '/tmp/pc/app/main.js');
let f = 0; const ok = (b, t) => { console.log((b ? 'ok   ' : 'FEHL ') + t); if(!b) f++; };
const warte = ms => new Promise(r => setTimeout(r, ms));
app.whenReady().then(() => setTimeout(async () => {
  try{
    const w = BrowserWindow.getAllWindows()[0]; const js = s => w.webContents.executeJavaScript(s);
    await js(`wechsleAnsicht('pdfs')`); await warte(3000);
    const fr = () => w.webContents.mainFrame.frames.find(x => /about:srcdoc/.test(x.url) && x.name !== 'jv');
    const frames = w.webContents.mainFrame.framesInSubtree.map(x => x.url);
    const ifr = w.webContents.mainFrame.framesInSubtree.find(x => x !== w.webContents.mainFrame && x.parent === w.webContents.mainFrame && x.frameTreeNodeId && true);
    // den richtigen Rahmen finden (der mit #pageGrid)
    let ziel = null;
    for(const x of w.webContents.mainFrame.framesInSubtree){ if(x === w.webContents.mainFrame) continue; try{ if(await x.executeJavaScript(`!!document.getElementById('pageGrid')`)) ziel = x; }catch(e){} }
    ok(!!ziel, 'PDF-Werkzeuge-Rahmen gefunden');
    const fj = s => ziel.executeJavaScript(s);
    ok((await fj(`[typeof jspdf, typeof Tesseract, typeof pdfjsLib, typeof PDFLib, typeof Sortable, typeof Peer].join(',')`)) === 'object,object,object,object,function,function', 'Alle Bausteine im echten Programm geladen');
    // Seite mit Text erzeugen und Texterkennung starten
    const ocr = await fj(`(async () => {
      const c = document.createElement('canvas'); c.width = 1200; c.height = 500; const x = c.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, 1200, 500); x.fillStyle = '#000'; x.font = '48px Arial';
      x.fillText('Exposé Beuthstraße 29', 60, 120); x.fillText('Kaufpreis 190.000 Euro', 60, 220); x.fillText('Wohnfläche 43 Quadratmeter', 60, 320);
      const blob = await new Promise(r => c.toBlob(r, 'image/png'));
      await window.addFilesToPdfTab([new File([blob], 'text.png', { type: 'image/png' })]);
      document.querySelector('.pageCard:last-child [data-action="edit"]').click();
      for(let i = 0; i < 240; i++){ await new Promise(r => setTimeout(r, 500)); const s = document.getElementById('ocrStatus').textContent; if(/erkannt|fehlgeschlagen/.test(s)) return s; }
      return document.getElementById('ocrStatus').textContent;
    })()`);
    ok(/^\d+ Textzeilen erkannt/.test(ocr) && parseInt(ocr) >= 3, 'Texterkennung im echten Programm (offline, deutsch): ' + ocr);
    const zeilen = await fj(`document.getElementById('closeEditorBtn').click(), 'ok'`);
    // PDF erstellen und über „Speichern unter“ speichern
    await fj(`document.getElementById('outName').value = 'Test33'; document.getElementById('previewBtn').click(); setTimeout(() => document.getElementById('downloadFromPreviewBtn').click(), 300); 'ok'`);
    await warte(4000);
    const dateien = fs.readdirSync(HOME + '/aus');
    ok(dateien.some(d => /^Test33_.*\.pdf$/.test(d)) && fs.readFileSync(HOME + '/aus/' + dateien.find(d => /^Test33_/.test(d))).slice(0, 4).toString() === '%PDF', 'PDF im echten Programm gespeichert: ' + dateien.join(', '));
    ok(/PDF gespeichert/.test(await js(`(document.getElementById('mcPdfHinweis') || {}).innerText || ''`)), 'Hinweis „PDF gespeichert – Öffnen“');
    ok(await js(`!!pdfjsLib.__mc33`), 'pdf.js im Cockpit abgesichert');
  }catch(e){ console.log('FEHLER', e); f++; }
  console.log('FEHLER', f); app.exit(0);
}, 3000));
