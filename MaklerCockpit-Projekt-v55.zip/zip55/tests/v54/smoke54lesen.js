// v54 Smoke: Inserat nur lesen (ohne Fenster) über die Kleinanzeigen-Sitzung
const { app, BrowserWindow } = require('electron'); const http = require('http'); const fs = require('fs');
const HOME = '/tmp/claude-0/-home-claude/fcfe88c9-293d-574d-8cfa-b1821c923895/scratchpad/etest/home54';
fs.rmSync(HOME, { recursive: true, force: true }); app.setPath('documents', HOME + '/Dokumente'); process.env.MC_WEB_TEST = '1';
const srv = http.createServer((req, res) => { res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' }); res.end('<!doctype html><html><body><h1 id="viewad-title">Helle 3-Zimmer-Wohnung in Köpenick</h1><h2 id="viewad-price">329.000 €</h2><div id="viewad-description-text">Text<br>Zeile 2</div><script>document.title="JS lief"</script></body></html>'); });
srv.listen(0, '127.0.0.1');
require(process.env.MC_MAIN || '/tmp/pc/app/main.js');
app.whenReady().then(() => setTimeout(async () => {
  let fehler = 0; const ok = (b, t) => { console.log((b ? 'ok   ' : 'FEHL ') + t); if(!b) fehler++; };
  try{
    const w = BrowserWindow.getAllWindows()[0], port = srv.address().port, vorher = BrowserWindow.getAllWindows().length;
    const r = await w.webContents.executeJavaScript(`window.pc.webfenster('lesen', { url: 'http://127.0.0.1:${port}/s-anzeige/x/1' })`);
    ok(r && r.ok && /Helle 3-Zimmer-Wohnung in Köpenick/.test(r.text), 'Inserat gelesen (Status ' + (r && r.status) + ')');
    ok(BrowserWindow.getAllWindows().length === vorher, 'kein zusätzliches Fenster geöffnet');
    const p = await w.webContents.executeJavaScript(`(() => { const r = ak54Parse(${JSON.stringify('')} + ${JSON.stringify('<h1 id="viewad-title">T</h1>')}); return r.titel; })()`);
    ok(p === 'T', 'Auslesen im Programm');
    const f = await w.webContents.executeJavaScript(`window.pc.webfenster('lesen', { url: 'https://evil.example/s-anzeige/x' })`);
    ok(f && !f.ok, 'fremde Seiten werden nicht gelesen');
  }catch(e){ ok(false, 'Ausnahme: ' + e.message); }
  console.log(fehler ? 'FEHLER ' + fehler : 'FEHLER 0'); app.exit(fehler ? 1 : 0);
}, 3500));
