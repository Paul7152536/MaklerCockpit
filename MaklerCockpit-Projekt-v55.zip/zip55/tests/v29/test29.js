// v29: alle neuen Exposés auf Knopfdruck öffnen
const { chromium } = require('playwright');
let f = 0; const ok = (b, t) => { console.log((b ? 'ok   ' : 'FEHL ') + t); if(!b) f++; };
function daten(n){
  const o = [];
  for(let i = 0; i < n; i++) o.push({ id: 'n' + i, createdAt: Date.now() - i * 1000, akqTitel: 'Bezugsfreie Wohnung ' + i, adresse: '', ort: i % 2 ? '12524 Berlin-Altglienicke' : '10365 Berlin', objektart: 'Wohnung', status: 'neu', quelle: 'Kleinanzeigen', link: 'https://www.kleinanzeigen.de/s-anzeige/wohnung/' + (1000 + i), verlauf: [] });
  o.push({ id: 'd1', createdAt: 1, akqTitel: 'Doppelt', ort: '10365 Berlin', objektart: 'Wohnung', status: 'neu', link: 'https://www.kleinanzeigen.de/s-anzeige/wohnung/1000', verlauf: [] });
  o.push({ id: 'j1', createdAt: 1, akqTitel: 'Böser Link', ort: '10365 Berlin', objektart: 'Wohnung', status: 'neu', link: 'javascript:alert(1)', verlauf: [] });
  o.push({ id: 'x1', createdAt: 1, akqTitel: 'Ohne Link', ort: '10365 Berlin', objektart: 'Wohnung', status: 'neu', link: '', verlauf: [] });
  o.push({ id: 'e1', createdAt: 1, akqTitel: 'Schon angeschrieben', ort: '10365 Berlin', objektart: 'Wohnung', status: 'email_geschrieben', link: 'https://www.kleinanzeigen.de/s-anzeige/x/1', verlauf: [] });
  o.push({ id: 'b1', createdAt: 1, akqTitel: 'Betreut', ort: '10365 Berlin', objektart: 'Wohnung', status: 'auftrag', link: 'https://www.immobilienscout24.de/expose/1', verlauf: [], bereich: 'betreut' });
  return { objekte: o, kontakte: [], termine: [], aufgaben: [], notizen: [], gesuche: [], marktanalysen: [], mentorFragen: [], meta: { v9neustart: { quittiert: true } } };
}
async function seite(b, n, geraet, breite){
  const p = await b.newPage({ viewport: { width: breite || 1440, height: breite ? 844 : 900 } });
  p.fe = []; p.on('pageerror', e => p.fe.push(e.message));
  await p.addInitScript(([d, g]) => { window.pc = { geraet: g, laden: () => JSON.parse(d), speichern: () => ({ ok: true }), ordner(){}, sicherungSchreiben: () => ({ ok: true }), sicherungLesen: () => null, zwischenablage: async () => '', abruf: async () => ({ ok: false }) };
    window.__auf = []; window.open = (u) => { window.__auf.push(u); return null; }; }, [JSON.stringify(daten(n)), geraet]);
  await p.goto('file:///tmp/pc/app/index.html'); await p.waitForTimeout(2200);
  await p.evaluate(() => { window.open = (u) => { window.__auf.push(u); return null; }; wechsleAnsicht('akquise'); }); await p.waitForTimeout(300);
  return p;
}
(async () => {
  const b = await chromium.launch();
  // PC, 12 neue
  let p = await seite(b, 12, 'pc');
  let r = await p.evaluate(() => { const x = document.querySelector('.ex29-balken'); return x ? x.innerText.replace(/\s+/g, ' ') : ''; });
  ok(/12 neue Leads mit Exposé-Link/.test(r) && /Alle 12 öffnen/.test(r), 'Balken über der Liste: ' + r);
  await p.click('.ex29-balken button'); await p.waitForTimeout(12 * 350 + 600);
  r = await p.evaluate(() => window.__auf.slice());
  ok(r.length === 12 && new Set(r).size === 12 && r.every(u => /^https:\/\/www\.kleinanzeigen\.de\/s-anzeige\/wohnung\/10\d\d$/.test(u)), '12 Exposés im Browser geöffnet (ohne Doppelte, ohne unsichere Links, ohne angeschriebene/betreute)');
  ok(!(await p.$('#ex29Leiste')) && /12 Exposés werden im Browser geöffnet/.test(await p.evaluate(() => document.getElementById('akqToast').textContent)), 'Hinweis „12 Exposés werden geöffnet“, keine Leiste');
  // Filter Ort
  await p.evaluate(() => { AQ2.ort = aqOrtKurz(findObjekt('n1')); renderAkquise(document.getElementById('main')); }); await p.waitForTimeout(200);
  r = await p.evaluate(() => document.querySelector('.ex29-balken').innerText.replace(/\s+/g, ' '));
  ok(/6 neue Leads/.test(r) && /gefiltert/.test(r), 'Mit Ort-Filter: nur passende (' + r + ')');
  await p.evaluate(() => { AQ2.ort = ''; findObjekt('n1').status = 'email_geschrieben'; aq2Liste(); });
  r = await p.evaluate(() => document.querySelector('.ex29-balken').innerText);
  ok(/11 neue/.test(r), 'Status geändert → Zahl passt sich an (11)');
  ok(p.fe.length === 0, 'Keine Fehler ' + JSON.stringify(p.fe)); await p.close();
  // PC, 25 neue → Auswahl, Portionen
  p = await seite(b, 25, 'pc');
  await p.click('.ex29-balken button'); await p.waitForTimeout(300);
  r = await p.evaluate(() => document.getElementById('modalInner').innerText);
  ok(/25 Exposés öffnen/.test(r) && /In 10er-Portionen/.test(r), 'Ab 16: Auswahl „Alle 25“ oder „10er-Portionen“');
  await p.click('#modalInner button:has-text("In 10er-Portionen")'); await p.waitForTimeout(10 * 350 + 500);
  r = await p.evaluate(() => ({ n: window.__auf.length, l: document.getElementById('ex29Leiste') ? document.getElementById('ex29Leiste').innerText.replace(/\s+/g, ' ') : '' }));
  ok(r.n === 10 && /10 von 25 Exposés geöffnet/.test(r.l) && /Nächste 10 öffnen/.test(r.l), 'Erste Portion: 10 offen, Leiste „10 von 25“');
  await p.click('#ex29Leiste button:has-text("Nächste")'); await p.waitForTimeout(10 * 350 + 500);
  r = await p.evaluate(() => ({ n: window.__auf.length, l: document.getElementById('ex29Leiste').innerText.replace(/\s+/g, ' ') }));
  ok(r.n === 20 && /Nächste 5 öffnen/.test(r.l), 'Zweite Portion: 20 offen, noch 5');
  await p.click('#ex29Leiste button:has-text("Nächste")'); await p.waitForTimeout(5 * 350 + 500);
  r = await p.evaluate(() => ({ n: window.__auf.length, u: new Set(window.__auf).size, l: !!document.getElementById('ex29Leiste') }));
  ok(r.n === 25 && r.u === 25 && !r.l, 'Alle 25 geöffnet, jedes genau einmal, Leiste weg');
  await p.evaluate(() => { window.__auf = []; ex29Oeffnen(); }); await p.click('#modalInner button:has-text("Alle 25 öffnen")'); await p.waitForTimeout(25 * 350 + 600);
  ok(await p.evaluate(() => window.__auf.length) === 25, '„Alle 25 öffnen“ öffnet alle');
  await p.screenshot({ path: '/tmp/v29test/pc.png' });
  ok(p.fe.length === 0, 'Keine Fehler ' + JSON.stringify(p.fe)); await p.close();
  // Handy: nacheinander
  p = await seite(b, 4, 'handy', 390);
  r = await p.evaluate(() => document.querySelector('.ex29-balken').innerText.replace(/\s+/g, ' '));
  ok(/4 neue/.test(r) && /Nacheinander öffnen/.test(r), 'Handy: „Nacheinander öffnen“');
  await p.click('.ex29-balken button'); await p.waitForTimeout(300);
  r = await p.evaluate(() => ({ n: window.__auf.length, l: document.getElementById('ex29Leiste').innerText.replace(/\s+/g, ' ') }));
  ok(r.n === 1 && /Exposé 1 von 4/.test(r.l) && /Bezugsfreie Wohnung 0/.test(r.l) && /Nächstes/.test(r.l), 'Handy: erstes Exposé offen, Leiste „Exposé 1 von 4“ mit Titel');
  const box = await p.evaluate(() => { const x = document.getElementById('ex29Leiste').getBoundingClientRect(); return [Math.round(x.left), Math.round(x.right), Math.round(x.bottom)]; });
  const tabs = await p.evaluate(() => { const t = document.getElementById('h25Tabs'); return t ? Math.round(t.getBoundingClientRect().top) : 844; });
  ok(box[0] >= 0 && box[1] <= 390 && box[2] <= tabs, 'Handy: Leiste passt über die untere Leiste ' + JSON.stringify(box) + ' Tabs ab ' + tabs);
  await p.screenshot({ path: '/tmp/v29test/handy.png' });
  await p.click('#ex29Leiste button:has-text("Lead")'); await p.waitForTimeout(400);
  ok(await p.evaluate(() => AQ2.sel) === 'n0', 'Handy: „Lead anzeigen“ springt zum Lead');
  for(let i = 0; i < 3; i++){ await p.click('#ex29Leiste button:has-text("Nächstes")'); await p.waitForTimeout(250); }
  r = await p.evaluate(() => ({ n: window.__auf.length, l: !!document.getElementById('ex29Leiste') }));
  ok(r.n === 4 && !r.l, 'Handy: alle 4 nacheinander, danach Leiste weg');
  ok(p.fe.length === 0, 'Keine Fehler ' + JSON.stringify(p.fe)); await p.close();
  // ohne neue Leads: kein Balken
  p = await seite(b, 0, 'pc');
  await p.evaluate(() => { db.objekte.forEach(o => { if(o.status === 'neu') o.status = 'kein_interesse'; }); aq2Liste(); });
  ok(!(await p.evaluate(() => document.querySelector('.ex29-balken'))), 'Ohne neue Leads mit Link: kein Balken'); await p.close();
  console.log('FEHLER', f); await b.close();
})();
