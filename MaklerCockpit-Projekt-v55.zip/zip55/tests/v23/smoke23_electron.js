// v23 Smoke im echten Electron: Start ohne Fehler, Telefon/Vor-Ort-Termin anlegen, gespeichert in daten.json
const { app, BrowserWindow } = require('electron'); const fs = require('fs');
const HOME = '/tmp/claude-0/-home-claude/fcfe88c9-293d-574d-8cfa-b1821c923895/scratchpad/etest/home23';
fs.rmSync(HOME, { recursive: true, force: true }); app.setPath('documents', HOME + '/Dokumente');
const fehlerLog = [];
app.on('web-contents-created', (e, wc) => wc.on('console-message', (...a) => { const ev = a[0]; const lvl = ev && ev.level !== undefined ? ev.level : a[1]; const msg = ev && ev.message !== undefined ? ev.message : a[2]; if(lvl === 3 || lvl === 'error') fehlerLog.push(msg); }));
require(process.env.MC_MAIN || '/tmp/pc/app/main.js');
const warte = ms => new Promise(r => setTimeout(r, ms));
app.whenReady().then(() => setTimeout(async () => {
  let f = 0; const ok = (b, t) => { console.log((b ? 'ok   ' : 'FEHL ') + t); if(!b) f++; };
  try{
    const w = BrowserWindow.getAllWindows()[0], js = s => w.webContents.executeJavaScript(s);
    ok(/v23/.test(await js(`document.querySelector('.sb-logo').textContent`)), 'v23 gestartet');
    await js(`wechsleAnsicht('termine'); oeffneTerminModal(); document.getElementById('m_t_titel').value='Telefonat Test'; document.getElementById('m_t_zeit').value='11:00'; document.querySelector('#m_t_wo .tw-telefon').click(); speichereTermin('');`);
    await js(`oeffneTerminModal(); document.getElementById('m_t_titel').value='Besichtigung Test'; document.querySelector('#m_t_wo .tw-vorort').click(); document.getElementById('m_t_ort').value='Lindenweg 5, Falkensee'; speichereTermin('');`);
    await warte(1500);
    const d = JSON.parse(fs.readFileSync(HOME + '/Dokumente/MaklerCockpit/daten.json', 'utf8'));
    ok(d.termine.length === 2 && d.termine[0].wo === 'telefon' && d.termine[1].wo === 'vorort', 'In daten.json: ' + d.termine.map(t => t.titel + '=' + t.wo).join(', '));
    const z = await js(`[...document.querySelectorAll('#tmNaechste .tw')].map(x=>x.textContent).join(' / ')`);
    ok(/📞 Telefon/.test(z) && /📍 Vor Ort/.test(z), 'Anzeige: ' + z);
  }catch(e){ console.log('FEHLER', e.stack || e); f++; }
  ok(fehlerLog.length === 0, 'Keine Konsolenfehler ' + JSON.stringify(fehlerLog.slice(0, 3)));
  console.log('FEHLER', f); app.exit(0);
}, 3000));
