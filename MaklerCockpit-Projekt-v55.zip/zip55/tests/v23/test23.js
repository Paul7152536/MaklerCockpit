// v23: Telefon-Termin oder Vor-Ort-Termin – Auswahl, Anzeige überall, Google-Titel
const { chromium } = require('playwright');
let fehler = 0; const ok = (b, t) => { if(!b){ fehler++; console.log('FEHLER:', t); } else console.log('ok  ', t); };
(async () => {
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 1536, height: 1000 }, deviceScaleFactor: 1 });
  const fe = []; p.on('pageerror', e => { fe.push(e.message); console.log('SEITENFEHLER', e.message); });
  await p.addInitScript(() => {
    const d = new Date(), k = x => x.getFullYear() + '-' + String(x.getMonth() + 1).padStart(2, '0') + '-' + String(x.getDate()).padStart(2, '0');
    const heute = k(d), morgen = k(new Date(d.getFullYear(), d.getMonth(), d.getDate() + 1));
    const ob = [
      { id:'auf1', createdAt:Date.now()-9e8, akqTitel:'Einfamilienhaus mit Garten', objektart:'EFH', adresse:'Lindenweg 5', ort:'14612 Falkensee', status:'auftrag', kaufpreis:459000, verkaeuferName:'Frau Krüger', verkaeuferTelefon:'0171 2223334', verlauf:[] },
      { id:'lead1', createdAt:Date.now()-8e8, akqTitel:'Doppelhaushälfte mit Garten', objektart:'DHH', adresse:'Birkenallee 12', ort:'14624 Dallgow-Döberitz', status:'neu', quelle:'Kleinanzeigen', kaufpreis:529000, verkaeuferName:'Herr Lange', verkaeuferTelefon:'0160 5556667', verlauf:[] }
    ];
    const termine = [
      { id:'t1', createdAt:1, titel:'Rückruf: Doppelhaushälfte', datum:heute, uhrzeit:'23:40', dauer:15, art:'rueckruf', ort:'', objektId:'lead1' },
      { id:'t2', createdAt:2, titel:'Besichtigung Lindenweg 5', datum:heute, uhrzeit:'14:00', dauer:60, art:'besichtigung', ort:'Lindenweg 5, 14612 Falkensee', objektId:'auf1' },
      { id:'t3', createdAt:3, titel:'Gespräch Bank', datum:morgen, uhrzeit:'09:00', dauer:60, art:'termin', ort:'' },
      { id:'t4', createdAt:4, titel:'Call Daniel', datum:heute, uhrzeit:'18:00', dauer:30, art:'eigene', artEigene:'Jarvis', ort:'' }
    ];
    const alt = { objekte: ob, gesuche: [], kontakte: [], termine, marktanalysen: [], aufgaben: [], notizen: [], mentorFragen: [], meta: { v9neustart: { quittiert: true } } };
    window.pc = { laden: () => JSON.parse(JSON.stringify(alt)), speichern: () => ({ ok:true }), ordner(){}, sicherungSchreiben: () => ({ ok:true }), sicherungLesen: () => null, zwischenablage: async () => '', abruf: async () => ({ ok:false }) };
    window.__toasts = [];
  });
  await p.goto('file:///tmp/pc/app/index.html'); await p.waitForTimeout(1500);
  const ev = (f, ...a) => p.evaluate(f, ...a);
  await ev(() => { const alt = akqToast; akqToast = function(t){ window.__toasts.push(String(t)); return alt.apply(this, arguments); }; });
  ok(await ev(() => /v23/.test(document.body.innerHTML)), 'Version v23 sichtbar');

  // ── Ableitung für alte Termine ──
  const ab = await ev(() => db.termine.map(t => t.id + ':' + twWo(t)).join(' '));
  ok(ab === 't1:telefon t2:vorort t3: t4:telefon', 'Alte Termine: Rückruf/Call → Telefon, Besichtigung → Vor Ort, Unklares bleibt offen: ' + ab);
  ok(await ev(() => twWo({ art:'termin', titel:'Übergabe Wohnung' }) === 'vorort' && twWo({ art:'termin', titel:'Termin', ort:'0176 1234567' }) === 'telefon' && twWo({ art:'termin', titel:'Treffen', ort:'Karl-Marx-Allee 90, Berlin' }) === 'vorort' && twWo({ art:'rueckruf', wo:'vorort' }) === 'vorort'), 'Ableitung aus Titel/Ort, eigene Angabe hat Vorrang');

  // ── Termine-Seite ──
  await ev(() => wechsleAnsicht('termine')); await p.waitForTimeout(200);
  const ts = await ev(() => ({
    kal: [...document.querySelectorAll('#kalGrid .eintrag')].map(e => e.textContent.trim()),
    chips: [...document.querySelectorAll('#tmNaechste .tm-z')].map(z => ((z.querySelector('.tw') || {}).textContent || '–') + ' | ' + z.querySelector('.tm-titel').textContent.trim() + ' | ' + ((z.querySelector('.tm-unter') || {}).textContent || ''))
  }));
  console.log(JSON.stringify(ts, null, 1));
  ok(ts.kal.some(x => /^📞 18:00 Call Daniel/.test(x)) && ts.kal.some(x => /^📍 14:00 Besichtigung/.test(x)), 'Kalender: 📞/📍 vor jedem Eintrag');
  ok(ts.chips.some(x => /^📞 Telefon \|.*Rückruf.*\| .*Tel\. 0160 5556667/.test(x)), '„Als Nächstes“: Rückruf als 📞 Telefon mit Nummer');
  ok(ts.chips.some(x => /^📍 Vor Ort \|.*Besichtigung.*\|.*Lindenweg 5, 14612 Falkensee/.test(x)), '„Als Nächstes“: Besichtigung als 📍 Vor Ort mit Adresse');
  ok(ts.chips.some(x => /^– \|.*Gespräch Bank/.test(x)), 'Unklarer Termin ohne Kennzeichnung');
  await p.screenshot({ path: '/tmp/v23test/1_termine.png' });

  // ── Glocke ──
  const gl = await ev(() => (tbHinweise().find(x => x.k === 'termine') || {}).t || '');
  ok(/3 Termine heute \(📞 2 Telefon · 📍 1 vor Ort\)/.test(gl), 'Glocke: ' + gl);

  // ── Neuer Termin: Auswahl Pflicht ──
  await ev(() => oeffneTerminModal()); await p.waitForTimeout(100);
  ok(await ev(() => !!document.getElementById('m_t_wo') && twGewaehlt('m_t_wo') === '' && document.getElementById('m_t_wo').previousElementSibling.textContent === 'Telefon oder vor Ort?'), 'Dialog: Auswahl „📞 Telefon-Termin / 📍 Vor-Ort-Termin“ unter dem Titel');
  await ev(() => { document.getElementById('m_t_titel').value = 'Telefonat Frau Krüger'; speichereTermin(''); }); await p.waitForTimeout(80);
  ok(await ev(() => document.getElementById('modalBg').classList.contains('show') && document.getElementById('m_t_wo').classList.contains('fehlt') && db.termine.length === 4 && /Telefon-Termin oder/.test(window.__toasts.slice(-1)[0])), 'Ohne Auswahl wird nicht gespeichert – Hinweis');
  await ev(() => { const s = document.getElementById('m_t_objekt'); s.value = 'auf1'; s.dispatchEvent(new Event('change')); document.querySelector('#m_t_wo .tw-telefon').click(); });
  ok(await ev(() => document.getElementById('m_t_ort').value === 'Telefon 0171 2223334' && document.querySelector('#m_t_wo .tw-telefon').classList.contains('an')), 'Telefon gewählt → Ort = Telefonnummer des Verkäufers');
  await p.screenshot({ path: '/tmp/v23test/2_dialog.png' });
  await ev(() => document.querySelector('#m_t_wo .tw-vorort').click());
  ok(await ev(() => document.getElementById('m_t_ort').value === 'Lindenweg 5, 14612 Falkensee'), 'Vor Ort gewählt → Ort = Objektadresse');
  await ev(() => document.querySelector('#m_t_wo .tw-telefon').click());
  await ev(() => speichereTermin('')); await p.waitForTimeout(80);
  const neu = await ev(() => Object.assign({ offen: document.getElementById('modalBg').classList.contains('show') }, db.termine.find(t => t.titel === 'Telefonat Frau Krüger')));
  ok(neu && neu.wo === 'telefon' && neu.ort === 'Telefon 0171 2223334' && !neu.offen, 'Gespeichert als Telefon-Termin');
  ok(await ev(() => (findObjekt('auf1').verlauf || []).some(v => /\(Telefon\) am/.test(v.text || v.t || JSON.stringify(v)))), 'Verlauf am Objekt: „… (Telefon) am …“');

  // Art wechselt → Vorschlag (solange nicht selbst gewählt); Ort selbst getippt bleibt
  await ev(() => oeffneTerminModal()); await p.waitForTimeout(60);
  await ev(() => { const s = document.getElementById('m_t_objekt'); s.value = 'lead1'; s.dispatchEvent(new Event('change')); const a = document.getElementById('m_t_art'); a.value = 'besichtigung'; a.dispatchEvent(new Event('change')); });
  ok(await ev(() => twGewaehlt('m_t_wo') === 'vorort' && document.getElementById('m_t_ort').value === 'Birkenallee 12, 14624 Dallgow-Döberitz'), 'Art Besichtigung → automatisch Vor Ort + Adresse');
  await ev(() => { const a = document.getElementById('m_t_art'); a.value = 'rueckruf'; a.dispatchEvent(new Event('change')); });
  ok(await ev(() => twGewaehlt('m_t_wo') === 'telefon' && document.getElementById('m_t_ort').value === 'Telefon 0160 5556667'), 'Art Rückruf → automatisch Telefon + Nummer');
  await ev(() => { const o = document.getElementById('m_t_ort'); o.value = 'Handy Herr Lange 0151 000'; o.dispatchEvent(new Event('input')); document.querySelector('#m_t_wo .tw-vorort').click(); document.querySelector('#m_t_wo .tw-telefon').click(); });
  ok(await ev(() => document.getElementById('m_t_ort').value === 'Handy Herr Lange 0151 000'), 'Selbst eingetippter Ort wird nicht überschrieben');
  await ev(() => schliesseModal());

  // Bestehender unklarer Termin
  await ev(() => oeffneTerminModal('t3')); await p.waitForTimeout(60);
  ok(await ev(() => twGewaehlt('m_t_wo') === ''), 'Alter Termin ohne Angabe: nichts vorausgewählt');
  await ev(() => { document.querySelector('#m_t_wo .tw-vorort').click(); speichereTermin('t3'); });
  ok(await ev(() => db.termine.find(t => t.id === 't3').wo === 'vorort' && db.termine.find(t => t.id === 't3').ort === ''), 't3 jetzt Vor Ort (ohne Objekt bleibt Ort leer)');
  await ev(() => oeffneTerminModal('t1')); await p.waitForTimeout(60);
  ok(await ev(() => twGewaehlt('m_t_wo') === 'telefon'), 'Alter Rückruf: Telefon vorausgewählt');
  await ev(() => schliesseModal());

  // ── Termin am Lead (Akquise) ──
  await ev(() => { wechsleAnsicht('akquise'); }); await p.waitForTimeout(150);
  await ev(() => { AQ2.sel = 'lead1'; aq2TerminNeu('rueckruf'); }); await p.waitForTimeout(80);
  ok(await ev(() => twGewaehlt('tq_wo') === 'telefon' && document.getElementById('tq_ort').value === 'Telefon 0160 5556667' && document.querySelector('.tq-arten').nextElementSibling.querySelector('.tw-wahl')), 'Lead-Dialog: Rückruf → 📞 vorausgewählt, Nummer als Ort');
  await ev(() => aq2TqArt('besichtigung'));
  ok(await ev(() => twGewaehlt('tq_wo') === 'vorort' && document.getElementById('tq_ort').value === 'Birkenallee 12, 14624 Dallgow-Döberitz'), 'Besichtigung → 📍 + Adresse');
  await ev(() => aq2TqArt('erstgespraech'));
  ok(await ev(() => twGewaehlt('tq_wo') === ''), 'Erstgespräch → selbst wählen');
  await p.screenshot({ path: '/tmp/v23test/3_lead_dialog.png' });
  await ev(() => aq2TerminAnlegen()); await p.waitForTimeout(60);
  ok(await ev(() => document.getElementById('modalBg').classList.contains('show') && document.getElementById('tq_wo').classList.contains('fehlt')), 'Ohne Auswahl nicht gespeichert');
  await ev(() => { document.querySelector('#tq_wo .tw-telefon').click(); aq2TerminAnlegen(); }); await p.waitForTimeout(120);
  const lt = await ev(() => db.termine.filter(t => t.objektId === 'lead1' && t.art === 'erstgespraech').map(t => ({ wo: t.wo, ort: t.ort }))[0]);
  ok(lt && lt.wo === 'telefon' && lt.ort === 'Telefon 0160 5556667', 'Erstgespräch als Telefon-Termin gespeichert: ' + JSON.stringify(lt));
  ok(await ev(() => (findObjekt('lead1').verlauf || []).some(v => /Erstgespräch \(Telefon\) am/.test(JSON.stringify(v)))), 'Lead-Verlauf: „Erstgespräch (Telefon) am …“');
  const ld = await ev(() => { AQ2.sel = 'lead1'; return aq2TermineHtml(findObjekt('lead1')); });
  ok(/tw tw-telefon/.test(ld) && /📞 Telefon/.test(ld) && /Tel\. 0160 5556667/.test(ld), 'Lead-Details: Termine mit 📞 Telefon + Nummer');
  ok(await ev(() => aqTerminChip(db.termine.find(t => t.id === 't1')).startsWith('📞 ') && aqTerminChip(db.termine.find(t => t.id === 't2')).startsWith('📍 ')), 'Lead-Liste: Termin-Chip mit 📞/📍');

  // ── Objekte-Liste ──
  await ev(() => wechsleAnsicht('objekte')); await p.waitForTimeout(150);
  const oc = await ev(() => [...document.querySelectorAll('#objTabelle .tw-obj')].map(x => x.className + ' ' + x.textContent.trim()));
  ok(oc.length === 2 && oc.some(x => /tw-telefon/.test(x) && /^\S+ \S+ 📞 Heute$/.test(x)) && oc.some(x => /📞 Heute 23:40/.test(x)), 'Objekte-Liste: nächster Termin mit Symbol (ganztägiges Telefonat vor der Besichtigung): ' + JSON.stringify(oc));
  ok(await ev(() => { const t = db.termine.find(x => x.titel === 'Telefonat Frau Krüger'); t.datum = '2099-01-01'; return /tw-vorort/.test(twObjektChip(findObjekt('auf1'))) && /📍 Heute 14:00/.test(twObjektChip(findObjekt('auf1'))); }), 'Danach kommt die Besichtigung: 📍 Heute 14:00');
  await p.screenshot({ path: '/tmp/v23test/4_objekte.png' });

  // ── Google Kalender ──
  const gg = await ev(() => {
    const t1 = db.termine.find(t => t.id === 't1'), t2 = db.termine.find(t => t.id === 't2'), t5 = { id:'x', titel:'Ohne', datum:'2026-12-01', uhrzeit:'10:00', dauer:60, art:'termin', ort:'' };
    const k1 = gsEventKoerper(t1), k2 = gsEventKoerper(t2), k5 = gsEventKoerper(t5);
    const e1 = gsAusEvent({ summary:'📍 Besichtigung Seestraße', start:{ dateTime:'2026-12-02T10:00:00+01:00' }, end:{ dateTime:'2026-12-02T11:00:00+01:00' } });
    const e2 = gsAusEvent({ summary:'Rückruf Meier', extendedProperties:{ private:{ mcWo:'telefon' } }, start:{ dateTime:'2026-12-02T10:00:00+01:00' }, end:{ dateTime:'2026-12-02T10:15:00+01:00' } });
    const e3 = gsAusEvent({ summary:'Zahnarzt', start:{ date:'2026-12-03' }, end:{ date:'2026-12-04' } });
    return { s1:k1.summary, w1:k1.extendedProperties.private.mcWo, id1:k1.extendedProperties.private.mcId, s2:k2.summary, s5:k5.summary, w5:k5.extendedProperties.private.mcWo,
      d1:k1.description, e1, e2, e3wo: 'wo' in e3,
      gleich: gsGleich({ summary:'📞 ' + t1.titel, start:{ dateTime:t1.datum + 'T23:40:00+01:00' }, end:{ dateTime:t1.datum + 'T23:55:00+01:00' } }, t1),
      hashMit: gsHash(t1) !== _twHash(t1), hashOhne: gsHash(t5) === _twHash(t5) };
  });
  console.log(JSON.stringify(gg));
  ok(gg.s1 === '📞 Rückruf: Doppelhaushälfte' && gg.w1 === 'telefon' && gg.id1 === 't1' && gg.s2 === '📍 Besichtigung Lindenweg 5', 'Google-Titel bekommt 📞/📍 vorne, mcWo + mcId gesetzt');
  ok(gg.s5 === 'Ohne' && gg.w5 === '', 'Termin ohne Angabe: Titel unverändert');
  ok(/— aus dem MaklerCockpit —\n📞 Telefon-Termin\n/.test(gg.d1) && /Telefon: 0160 5556667/.test(gg.d1), 'Beschreibung in Google: „📞 Telefon-Termin“ + Nummer');
  ok(gg.e1.titel === 'Besichtigung Seestraße' && gg.e1.wo === 'vorort' && gg.e2.titel === 'Rückruf Meier' && gg.e2.wo === 'telefon' && !gg.e3wo, 'Vom Handy: 📍/📞 im Titel wird erkannt und abgeschnitten, ohne Angabe bleibt alles wie es war');
  ok(gg.gleich, 'Doppelt-Erkennung ignoriert das Symbol im Titel');
  ok(gg.hashMit && gg.hashOhne, 'Änderung Telefon/Vor Ort wird zu Google übertragen (Hash), Termine ohne Angabe bleiben unverändert');

  ok(fe.length === 0, 'Keine Seitenfehler (' + fe.length + ')');
  console.log('FEHLER', fehler);
  await b.close();
})();
