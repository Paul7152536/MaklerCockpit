// v36: Toast blockiert Reiter nicht, Termin-Dauer nach Art, große Tippflächen
const { chromium } = require('playwright');
let f = 0; const ok = (b, t) => { console.log((b ? 'ok   ' : 'FEHL ') + t); if(!b) f++; };
const D = JSON.stringify({ objekte: [{ id: 'o1', akqTitel: 'DHH Köpenick', status: 'kleinanzeigen_geschrieben', ort: '12557 Berlin', adresse: 'Musterweg 1, 12557 Berlin', telefon: '0171 1234567', kaufpreis: 595000, verlauf: [] }], kontakte: [], termine: [], aufgaben: [], notizen: [], meta: { v9neustart: { quittiert: true } } });
async function seite(b, g, w, h){
  const p = await b.newPage({ viewport: { width: w, height: h }, isMobile: g === 'handy', hasTouch: g === 'handy' });
  p.fe = []; p.on('pageerror', e => p.fe.push(e.message)); p.on('dialog', d => d.dismiss());
  await p.addInitScript(([d, g]) => { window.pc = { geraet: g, laden: () => JSON.parse(d), speichern: () => ({ ok: true }), ordner(){}, sicherungSchreiben: () => ({ ok: true }), sicherungLesen: () => null, gekoppelt: () => true, google: async () => ({ ok: false }) }; }, [D, g]);
  await p.goto('file:///tmp/pc/app/index.html'); await p.waitForTimeout(2200);
  await p.evaluate(() => { try{ schliesseModal(); }catch(e){} }); await p.waitForTimeout(300);
  return p;
}
(async () => {
  const b = await chromium.launch();
  let p = await seite(b, 'handy', 412, 915);
  await p.evaluate(() => akqToast('Ein längerer Hinweis zum Testen der Reiter', 800)); await p.waitForTimeout(400);
  let r = await p.evaluate(() => { const t = document.getElementById('akqToast'); return { pe: getComputedStyle(t).pointerEvents, bottom: t.getBoundingClientRect().bottom, tabsTop: document.getElementById('h25Tabs').getBoundingClientRect().top }; });
  ok(r.pe === 'none' && r.bottom <= r.tabsTop + 1, `Toast nicht anklickbar und über den Reitern (Toast bis ${Math.round(r.bottom)}, Reiter ab ${Math.round(r.tabsTop)})`);
  await p.waitForTimeout(1500);
  r = await p.evaluate(() => [...document.querySelectorAll('#h25Tabs [onclick]')].map(t => { const q = t.getBoundingClientRect(); const e = document.elementFromPoint(q.left + q.width / 2, q.top + q.height / 2); return t.contains(e); }));
  ok(r.length === 5 && r.every(Boolean), 'Alle 5 Reiter antippbar nach einem Hinweis');
  await p.tap('#h25Tabs [onclick*="termine"]'); await p.waitForTimeout(400);
  ok(await p.evaluate(() => aktuelleAnsicht === 'termine'), 'Antippen von „Termine“ wechselt die Ansicht');
  // Aktiver Lead: Tippflächen
  await p.evaluate(() => wechsleAnsicht('akquise')); await p.waitForTimeout(400);
  await p.tap('#lc-o1'); await p.waitForTimeout(700);
  r = await p.evaluate(() => [...document.querySelectorAll('.tb-icon:not(.mini)')].filter(e => e.offsetParent && e.getBoundingClientRect().top < 120).map(e => Math.round(e.getBoundingClientRect().width) + 'x' + Math.round(e.getBoundingClientRect().height)));
  ok(r.length >= 3 && r.every(x => x === '44x44'), 'Symbole oben bei „Aktiver Lead“ sind 44×44: ' + r.join(' '));
  // Termin am Lead
  await p.evaluate(() => aq2TerminNeu('besichtigung')); await p.waitForTimeout(400);
  const dauer = () => p.evaluate(() => document.getElementById('tq_dauer').value);
  r = await p.evaluate(() => twGewaehlt('tq_wo'));
  ok(r === 'vorort' && await dauer() === '60', `Besichtigung → Vor-Ort, 1 Std. (${r}, ${await dauer()})`);
  await p.click('#tq_wo [data-wo="telefon"]'); await p.waitForTimeout(200);
  ok(await dauer() === '15', 'Telefon-Termin angetippt → 15 Min. (' + await dauer() + ')');
  await p.click('#tq_wo [data-wo="vorort"]'); await p.waitForTimeout(200);
  ok(await dauer() === '60', 'Vor-Ort-Termin angetippt → 1 Std.');
  await p.evaluate(() => aq2TqArt('rueckruf')); await p.waitForTimeout(200);
  r = await p.evaluate(() => twGewaehlt('tq_wo'));
  ok(await dauer() === (r === 'telefon' ? '15' : '60'), `Art gewechselt (Rückruf → ${r}) → Dauer ${await dauer()}`);
  await p.evaluate(() => schliesseModal());
  // allgemeiner Termin-Dialog
  await p.evaluate(() => oeffneTerminModal()); await p.waitForTimeout(400);
  const md = () => p.evaluate(() => document.getElementById('m_t_dauer').value);
  await p.click('#m_t_wo [data-wo="telefon"]'); await p.waitForTimeout(200);
  ok(await md() === '15', 'Allgemeiner Termin: Telefon → 15 Min.');
  await p.click('#m_t_wo [data-wo="vorort"]'); await p.waitForTimeout(200);
  ok(await md() === '60', 'Allgemeiner Termin: Vor Ort → 1 Std.');
  ok(p.fe.length === 0, 'Keine Fehler ' + p.fe.join(' | '));
  await p.close();
  // PC: Symbole unverändert
  p = await seite(b, 'pc', 1440, 900);
  r = await p.evaluate(() => { const e = document.querySelector('.tb-icon'); return e ? Math.round(e.getBoundingClientRect().width) : 0; });
  ok(r > 0 && r < 44, 'PC: Symbolgröße unverändert (' + r + ' px)');
  await p.evaluate(() => { wechsleAnsicht('termine'); oeffneTerminModal(); }); await p.waitForTimeout(300);
  await p.click('#m_t_wo [data-wo="telefon"]'); await p.waitForTimeout(200);
  ok(await p.evaluate(() => document.getElementById('m_t_dauer').value) === '15', 'PC: Telefon-Termin → 15 Min.');
  ok(p.fe.length === 0, 'PC: keine Fehler ' + p.fe.join(' | '));
  await b.close(); console.log('FEHLER', f);
})();
