// v36: alle KI-Prompts mit „AUSGABE ZUM KOPIEREN“, Nachrichten an Verkäufer ohne
const { chromium } = require('playwright');
let f = 0; const ok = (b, t) => { console.log((b ? 'ok   ' : 'FEHL ') + t); if(!b) f++; };
const D = JSON.stringify({ objekte: [{ id: 'o1', akqTitel: 'DHH Köpenick', status: 'neu', ort: '12557 Berlin', adresse: 'Musterweg 1, 12557 Berlin', objektart: 'Haus', kaufpreis: 595000, wohnflaeche: 138, link: 'https://www.kleinanzeigen.de/s-anzeige/x/1', verlauf: [] }], kontakte: [], termine: [], aufgaben: [], notizen: [], meta: { v9neustart: { quittiert: true } } });
(async () => {
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 1440, height: 900 } });
  const fe = []; p.on('pageerror', e => fe.push(e.message)); p.on('dialog', d => d.dismiss());
  await p.addInitScript(d => { window.__k = []; window.pc = { geraet: 'pc', laden: () => JSON.parse(d), speichern: () => ({ ok: true }), ordner(){}, sicherungSchreiben: () => ({ ok: true }), sicherungLesen: () => null };
    Object.defineProperty(navigator, 'clipboard', { value: { writeText: async t => { window.__k.push(t); } }, configurable: true }); }, D);
  await p.goto('file:///tmp/pc/app/index.html'); await p.waitForTimeout(2200);
  const M = 'AUSGABE ZUM KOPIEREN';
  const r = await p.evaluate(M => {
    const o = findObjekt('o1'), z = t => typeof t === 'string' && t.includes(M) && t.split(M).length === 2;
    const erg = {};
    erg.akq = AKQ_PROMPTS.map(x => { try{ return [x.key, z(x.prompt(Object.assign({}, akqDb().einst || {})))]; }catch(e){ return [x.key, 'Fehler ' + e.message]; } });
    erg.hv = z(hvRecherchePrompt({ menge: 15 }));
    erg.sk = z(skKiPrompt(o));
    erg.umg = z(baueUmgebungsPrompt(o, 'kauf', false));
    erg.ga = z(ga35Prompt('o1', ga35Entwurf('o1')).text) || ga35Prompt('o1', ga35Entwurf('o1')).text.includes(M);
    return erg;
  }, M);
  ok(r.akq.length >= 3 && r.akq.every(x => x[1] === true), 'Akquise-/Gesuche-Prompts: ' + r.akq.map(x => x[0] + '=' + x[1]).join(', '));
  ok(r.hv && r.sk && r.umg && r.ga, `Hausverwaltung ${r.hv}, Käufer & Markt ${r.sk}, Umgebung ${r.umg}, Große Analyse ${r.ga}`);
  // Nachricht an Verkäufer bleibt sauber
  const msg = await p.evaluate(async () => { window.__k = []; akqKopieren('Hallo, ich bin Makler …', 'x'); await new Promise(r => setTimeout(r, 300)); return window.__k.join('|'); });
  ok(!/AUSGABE ZUM KOPIEREN/.test(msg), 'Normale Texte (z. B. Nachricht an Verkäufer) ohne Zusatz');
  // Jarvis im iframe
  await p.evaluate(() => wechsleAnsicht('jarvis')); await p.waitForTimeout(1500);
  const fr = await (await p.$('#jvFrame')).contentFrame();
  await fr.evaluate(() => { Object.defineProperty(navigator, 'clipboard', { value: { writeText: async t => { window.parent.__k.push('JV:' + t); } }, configurable: true }); });
  const jv = await fr.evaluate(async () => { try{ await promptKopieren('akquise', 'Test', {}); }catch(e){ return 'Fehler ' + e.message; } return 'ok'; });
  await p.waitForTimeout(400);
  let k = await p.evaluate(() => window.__k.filter(x => x.startsWith('JV:')));
  ok(jv === 'ok' && k.length && k[k.length - 1].includes(M), 'Jarvis: kopierter Prompt mit Zusatz');
  const direkt = await fr.evaluate(() => { const t = promptErzeugen('akquise', 'Test', {}); return t ? t.includes('AUSGABE ZUM KOPIEREN') : 'leer'; });
  ok(direkt === false, 'Jarvis direkt (ohne Kopieren): Prompt unverändert');
  ok(fe.length === 0, 'Keine Fehler ' + fe.join(' | '));
  await b.close(); console.log('FEHLER', f);
})();
