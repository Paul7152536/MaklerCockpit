const { chromium } = require('playwright');
let f = 0; const ok = (b, t) => { console.log((b ? 'ok   ' : 'FEHL ') + t); if(!b) f++; };
(async () => {
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 1440, height: 900 } });
  const fe = []; p.on('pageerror', e => fe.push(e.message));
  await p.addInitScript(() => { window.pc = { geraet: 'pc', laden: () => ({ objekte: [], kontakte: [], termine: [], aufgaben: [], notizen: [], meta: { v9neustart: { quittiert: true } } }), speichern: () => ({ ok: true }), ordner(){}, sicherungSchreiben: () => ({ ok: true }), sicherungLesen: () => null }; });
  await p.goto('file:///tmp/pc/app/index.html'); await p.waitForTimeout(2000);
  const r = await p.evaluate(() => ['ma24Prompt', 'ak24KiPrompt', 'ak24EinwandPrompt'].map(n => n + ':' + /mc36Kopierbar/.test(String(window[n]))));
  ok(r.every(x => x.endsWith('true')), 'Hauptfenster umhüllt: ' + r.join(' '));
  for(const [ansicht, frame] of [['shooting', 'shFrame'], ['immowert', 'maFrame']]){
    await p.evaluate(a => wechsleAnsicht(a), ansicht); await p.waitForTimeout(1200);
    const el = await p.$('#' + frame); if(!el){ ok(false, frame + ' fehlt'); continue; }
    const fr = await el.contentFrame();
    const t = await fr.evaluate(() => { const b = document.getElementById('kiMake'); if(!b) return 'kein Knopf'; Object.defineProperty(navigator, 'clipboard', { value: { writeText: async () => {} }, configurable: true }); b.click(); return new Promise(r => setTimeout(() => r((document.getElementById('kiPrompt') || {}).value || ''), 400)); });
    ok(typeof t === 'string' && t.includes('AUSGABE ZUM KOPIEREN'), ansicht + ': Prompt mit Zusatz');
  }
  await p.evaluate(() => wechsleAnsicht('jarvis')); await p.waitForTimeout(1500);
  const jf = await (await p.$('#jvFrame')).contentFrame();
  const h = await jf.evaluate(async () => { let got = ''; const k = kopieren; const d = document.getElementById('handFrage'); if(!d) return 'kein Feld'; d.value = 'Testfrage'; const orig = navigator.clipboard; Object.defineProperty(navigator, 'clipboard', { value: { writeText: async t => { got = t; } }, configurable: true }); handPrompt(); await new Promise(r => setTimeout(r, 200)); return got.includes('AUSGABE ZUM KOPIEREN') && kopieren === k; });
  ok(h === true, 'Jarvis „Frage an Claude“: Zusatz, kopieren danach wieder normal (' + h + ')');
  ok(fe.length === 0, 'Keine Fehler ' + fe.join(' | '));
  await b.close(); console.log('FEHLER', f);
})();
