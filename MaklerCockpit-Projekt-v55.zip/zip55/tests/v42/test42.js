// v42: Handy-Sicherung außerhalb der App + Wiederherstellen aus Datei
const { chromium } = require('playwright'); const fs = require('fs');
let f = 0; const ok = (b, t) => { console.log((b ? 'ok   ' : 'FEHL ') + t); if(!b) f++; };
const SICH = { objekte: [{ id: 'o1', akqTitel: 'Aus Sicherung', verlauf: [] }, { id: 'o2', akqTitel: 'Zweites', verlauf: [] }], kontakte: [{ id: 'k1', name: 'Frau Muster' }], termine: [], aufgaben: [], notizen: [], meta: { v9neustart: { quittiert: true } } };
fs.writeFileSync('/tmp/v42test/MaklerCockpit-Handy-Sicherung-2026-11-16.json', JSON.stringify(SICH));
fs.writeFileSync('/tmp/v42test/kaputt.json', '{"hallo":1}');
async function handy(b, daten, stand, gekoppelt){
  const p = await b.newPage({ viewport: { width: 412, height: 915 }, isMobile: true, hasTouch: true });
  p.fe = []; p.on('pageerror', e => p.fe.push(e.message)); p.on('dialog', d => d.accept());
  p.rec = []; await p.exposeFunction('__rec', (...a) => { p.rec.push(a); });
  await p.addInitScript(([daten, stand, gek]) => {
    const ls = window.localStorage; window.__ext = JSON.parse(ls.getItem('__t42ext') || '[]'); window.__imp = ls.getItem('__t42imp');
    window.pc = { geraet: 'handy', laden: () => window.__imp ? JSON.parse(window.__imp) : (daten ? JSON.parse(daten) : null), speichern: () => ({ ok: true }), ordner(){}, sicherungSchreiben: () => ({ ok: true }), sicherungLesen: () => null,
      importieren: t => { ls.setItem('__t42imp', t); window.__rec('imp', t); return { ok: true }; },
      sicherungExtern: (t, art) => { const l = JSON.parse(ls.getItem('__t42ext') || '[]'); l.push({ art, n: JSON.parse(t).objekte.length }); ls.setItem('__t42ext', JSON.stringify(l)); window.__ext = l; window.__rec('ext', art, l[l.length - 1].n); return { ok: true }; },
      abgleichStand: (a, t) => { if(a === 'lesen') return ls.getItem('st') || stand; if(a === 'schreiben') ls.setItem('st', t); if(a === 'loeschen') ls.setItem('st', ''); return { ok: true }; },
      gekoppelt: () => gek, entkoppeln: () => { ls.setItem('__t42entk', '1'); window.__rec('entk'); }, koppeln: async () => ({ ok: true }),
      google: async (a) => a === 'status' ? { ok: true, verbunden: gek, modus: 'skript' } : a === 'abgleich' ? { ok: true, rev: 0, epoche: 0, bis: 0, mehr: false, aenderungen: [], angenommen: [], abgelehnt: [] } : { ok: false } };
  }, [daten ? JSON.stringify(daten) : null, stand, gekoppelt]);
  await p.goto('file:///tmp/pc/app/index.html'); await p.waitForTimeout(2400);
  return p;
}
(async () => {
  const b = await chromium.launch();
  // 1) Leeres, ungekoppeltes Handy → Dialog mit Wiederherstellen
  let ctx = await b.newContext(); let p = await (async () => { const pg = await handy({ newPage: o => ctx.newPage(o) }, null, null, false); return pg; })();
  ok(await p.evaluate(() => /Daten weg\?/.test(document.querySelector('#modalBg').innerText) && /Downloads\/MaklerCockpit\/Sicherungen/.test(document.querySelector('#modalBg').innerText)), 'Leeres Handy: Koppeln-Dialog bietet „Aus Sicherungsdatei wiederherstellen“ an');
  // ungültige Datei
  let [fc] = await Promise.all([p.waitForEvent('filechooser'), p.click('button:has-text("Aus Sicherungsdatei wiederherstellen")')]);
  await fc.setFiles('/tmp/v42test/kaputt.json'); await p.waitForTimeout(400);
  ok(await p.evaluate(() => /keine MaklerCockpit-Sicherung/.test((document.getElementById('akqToast') || document.body).innerText)), 'Falsche Datei → verständliche Meldung, nichts ersetzt');
  [fc] = await Promise.all([p.waitForEvent('filechooser'), p.evaluate(() => mc42Wiederherstellen())]);
  await fc.setFiles('/tmp/v42test/MaklerCockpit-Handy-Sicherung-2026-11-16.json'); await p.waitForTimeout(400);
  ok(await p.evaluate(() => /2 Objekte, 1 Kontakte/.test(document.body.innerText)), 'Vorschau: Sicherung enthält 2 Objekte, 1 Kontakt');
  await Promise.all([p.waitForNavigation({ timeout: 8000 }).catch(() => null), p.click('#bc_ja')]);
  await p.waitForTimeout(2600);
  await p.waitForTimeout(1500);
  const imp = p.rec.find(r => r[0] === 'imp');
  ok(imp && JSON.parse(imp[1]).objekte.length === 2 && JSON.parse(imp[1]).objekte[0].akqTitel === 'Aus Sicherung', 'Wiederherstellen spielt die Sicherung ein (2 Objekte, 1 Kontakt) und lädt neu');
  ok(p.fe.length === 0, 'keine Fehler ' + p.fe.join(' | '));
  await ctx.close();
  // 2) Gekoppeltes Handy: Jetzt sichern, Entkoppeln sichert vorher
  ctx = await b.newContext();
  p = await handy({ newPage: o => ctx.newPage(o) }, SICH, JSON.stringify({ aktiv: true, geraet: 'handy-x', basis: {}, lokalSeit: {}, seit: 0, protokoll: [] }), true);
  await p.evaluate(() => { try{ schliesseModal(); }catch(e){} ab25HandyDialog(); }); await p.waitForTimeout(300);
  ok(await p.evaluate(() => /Tägliche Sicherung/.test(document.querySelector('#modalBg').innerText)), 'Gekoppelt: Dialog zeigt, wo die tägliche Sicherung liegt');
  await p.click('button:has-text("Jetzt sichern")'); await p.waitForTimeout(300);
  ok(await p.evaluate(() => window.__ext.some(x => x.art === 'manuell' && x.n === 2)), '„Jetzt sichern“ legt eine Sicherung in Downloads ab');
  await p.evaluate(() => { schliesseModal(); ab25Entkoppeln(); }); await p.waitForTimeout(300);
  await Promise.all([p.waitForNavigation({ timeout: 8000 }).catch(() => null), p.click('#bc_ja')]);
  await p.waitForTimeout(1500);
  await p.waitForTimeout(1500);
  const ie = p.rec.findIndex(r => r[0] === 'ext' && r[1] === 'vor-entkoppeln' && r[2] === 2), ik = p.rec.findIndex(r => r[0] === 'entk');
  ok(ie >= 0 && ik > ie, 'Entkoppeln legt VOR dem Löschen eine Sicherung ab');
  await ctx.close();
  // 3) Alte App ohne sicherungExtern (Brücke über MCAndroid)
  ctx = await b.newContext(); p = await ctx.newPage();
  await p.addInitScript(() => { window.MCAndroid = { laden: () => 'null', speichern: () => '{"ok":true}', sicherungLesen: () => null, standLesen: () => null, gekoppelt: () => 'false' }; });
  await p.goto('file:///tmp/pc/app/index.html'); await p.waitForTimeout(1500);
  ok(await p.evaluate(() => { const r = window.pc.sicherungExtern('{"objekte":[]}', 'manuell'); return r && r.ok === false && /App-Version 18/.test(r.fehler); }), 'Alte App (v17): klare Meldung statt Absturz');
  await ctx.close(); await b.close(); console.log('FEHLER', f);
})();
