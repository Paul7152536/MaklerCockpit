// v47 (Browser): „Keine Makler“, Anrufliste morgen (ein Kalendereintrag je Tag), 2-Wochen-Meldung mit „Alle löschen?“
const { chromium } = require('playwright');
let f = 0; const ok = (b, t) => { console.log((b ? 'ok   ' : 'FEHL ') + t); if(!b) f++; };
const T = 864e5, jetzt = Date.now();
const lead = (id, x) => Object.assign({ id, objektart: 'EFH', ort: '12487 Berlin', status: 'neu', quelle: 'Kleinanzeigen', createdAt: jetzt - 20 * T, verlauf: [] }, x);
const D = JSON.stringify({ objekte: [
  lead('a1', { akqTitel: 'Haus mit Garten in Johannisthal', verkaeuferTelefon: '0151 1111111', verkaeuferName: 'Frau Meier', link: 'https://www.kleinanzeigen.de/s-anzeige/haus/1' }),
  lead('a2', { akqTitel: 'DHH Adlershof – bitte keine Makler!', verkaeuferTelefon: '0152 2222222', link: 'https://www.kleinanzeigen.de/s-anzeige/dhh/2' }),
  lead('a3', { akqTitel: 'Bungalow Grünau', details: 'Makleranfragen zwecklos.', verkaeuferTelefon: '030 3333333' }),
  lead('a4', { akqTitel: 'EFH Rudow von privat', details: 'Von privat, Makler sind willkommen.' }),
  lead('w1', { akqTitel: 'Angeschrieben vor 15 Tagen', status: 'kleinanzeigen_geschrieben', statusAm: jetzt - 15 * T, kleinanzeigenAm: jetzt - 15 * T }),
  lead('w2', { akqTitel: 'Angeschrieben vor 16 Tagen', status: 'email_geschrieben', statusAm: jetzt - 16 * T, emailAm: jetzt - 16 * T }),
  lead('w3', { akqTitel: 'Angeschrieben vor 10 Tagen', status: 'email_geschrieben', statusAm: jetzt - 10 * T, emailAm: jetzt - 10 * T })],
  kontakte: [], termine: [], aufgaben: [], notizen: [], meta: { v9neustart: { quittiert: true } } });
(async () => {
  const b = await chromium.launch();
  for(const [g, w, h] of [['pc', 1440, 900], ['handy', 412, 915]]){
    const p = await b.newPage({ viewport: { width: w, height: h }, isMobile: g === 'handy' });
    p.fe = []; p.on('pageerror', e => p.fe.push(e.message));
    await p.addInitScript(([d, g]) => { window.pc = { geraet: g, laden: () => JSON.parse(d), speichern: () => ({ ok: true }), ordner(){}, sicherungSchreiben: () => ({ ok: true }), sicherungLesen: () => null, gekoppelt: () => true, google: async () => ({ ok: false }),
      webfenster: async (aktion, arg) => { (window.__wf = window.__wf || []).push([aktion, arg]); return { ok: true }; }, onWebfenster: () => {} }; window.__offen = []; window.open = u => { window.__offen.push(u); return null; }; }, [D, g === 'pc' ? 'pc' : 'handy']);
    await p.goto('file:///tmp/pc/app/index.html'); await p.waitForTimeout(2200);
    await p.evaluate(() => { try{ schliesseModal(); }catch(e){} document.getElementById('an31Karte') && document.getElementById('an31Karte').remove(); wechsleAnsicht('akquise'); }); await p.waitForTimeout(500);
    // ── Keine Makler ──
    const km = await p.evaluate(() => ['a1', 'a2', 'a3', 'a4'].map(id => !!document.querySelector('#lc-' + id + ' .ak47-km')));
    ok(km.join() === 'false,true,true,false', g + ': „🚫 Keine Makler“ an a2 (Titel) und a3 (Text), nicht an a1 und „Makler willkommen“ (' + km.join() + ')');
    await p.evaluate(() => { AQ2.sel = 'a2'; aq2Detail(); });
    ok(await p.evaluate(() => /Keine Makler gewünscht/.test(document.getElementById('aqDetail').innerText)), g + ': Detail warnt „Keine Makler gewünscht“');
    // ── Nachricht: PC → Kleinanzeigen-Fenster mit Text, Handy → wie bisher ──
    await p.evaluate(() => { AQ2.sel = 'a1'; aq2Detail(); aq2Senden(); }); await p.waitForTimeout(300);
    const wf = await p.evaluate(() => ({ wf: window.__wf || [], offen: window.__offen.slice() }));
    if(g === 'pc') ok(wf.wf.length === 1 && wf.wf[0][0] === 'nachricht' && wf.wf[0][1].url === 'https://www.kleinanzeigen.de/s-anzeige/haus/1' && wf.wf[0][1].text.length > 40 && !wf.offen.includes('https://www.kleinanzeigen.de/s-anzeige/haus/1'), g + ': „Nachricht“ öffnet das Kleinanzeigen-Fenster mit dem Text (kein externer Browser)');
    else ok(!wf.wf.length && wf.offen.includes('https://www.kleinanzeigen.de/s-anzeige/haus/1'), g + ': Handy: Anzeige öffnen wie bisher (Text in der Zwischenablage)');
    if(g === 'pc'){
      await p.evaluate(() => kgDaten({ art: 'nachricht', ergebnis: 'keinMakler', id: 'a1' })); await p.waitForTimeout(200);
      ok(await p.evaluate(() => findObjekt('a1').keinMakler === true && !!document.querySelector('#lc-a1 .ak47-km')), g + ': Fenster meldet „keine Makler“ → Lead markiert');
      await p.evaluate(() => ak47KmSetzen('a1', false));
    }
    // ── Anrufliste ──
    await p.evaluate(() => { AQ2.sel = 'a1'; aq2Detail(); });
    ok(await p.evaluate(() => !!document.querySelector('#aqDetail .ak47-morgen') && !!document.querySelector('#lc-a1 .ak47-morgen') && !document.querySelector('#lc-a4 .ak47-morgen')), g + ': „📞 Morgen anrufen“ bei Leads mit Nummer (Detail + Liste), nicht ohne Nummer');
    await p.click('#lc-a1 .ak47-morgen'); await p.waitForTimeout(200);
    await p.click('#lc-a2 .ak47-morgen'); await p.waitForTimeout(200);
    await p.click('#lc-a3 .ak47-morgen'); await p.waitForTimeout(200);
    const k = await p.evaluate(() => { const m = ak47Morgen(); return { m, t: db.termine.filter(t => t.anrufliste), lead: findObjekt('a1').anrufTag }; });
    ok(k.t.length === 1 && k.t[0].datum === k.m && k.lead === k.m && /Anrufliste: 3 Anrufe/.test(k.t[0].titel) && /0151 1111111 – Frau Meier/.test(k.t[0].notiz) && /0152 2222222/.test(k.t[0].notiz) && /030 3333333/.test(k.t[0].notiz), g + ': drei Leads → EIN Kalendereintrag „📞 Anrufliste: 3 Anrufe“ mit allen Nummern (' + (k.t[0] || {}).titel + ')');
    ok(k.t[0].uhrzeit === '09:00' && k.t[0].dauer === 30 && new Date(k.m + 'T12:00').getDay() !== 0, g + ': morgen 09:00, 30 Min., nie am Sonntag');
    ok(await p.evaluate(() => /📞 \w\w\.?, \d\d\.\d\d/.test(document.querySelector('#lc-a1 .ak47-geplant').textContent)), g + ': Liste zeigt „📞 Fr., 20.11.“ statt Knopf');
    await p.click('#lc-a2 .ak47-x'); await p.waitForTimeout(200);
    ok(await p.evaluate(() => { const t = db.termine.find(t => t.anrufliste); return /2 Anrufe/.test(t.titel) && !/0152/.test(t.notiz) && !findObjekt('a2').anrufTag; }), g + ': ✕ nimmt einen Lead heraus, Eintrag wird angepasst');
    // „heute“ simulieren: Liste, erledigt, Glocke
    await p.evaluate(() => { const m = ak47Morgen(), h = ak47Heute(); db.termine = db.termine.filter(t => !t.anrufliste); ['a1', 'a3'].forEach(id => { findObjekt(id).anrufTag = h; }); ak47TerminAktualisieren(h); save(); aq2Neu(); });
    ok(await p.evaluate(() => /Anrufliste heute: 2 Anrufe offen/.test(JSON.stringify(tbHinweise())) && !!document.querySelector('#ak47Balken')), g + ': heute: Glocke „Anrufliste heute: 2 Anrufe offen“ + Balken in Akquise');
    await p.evaluate(() => ak47ListeDialog()); await p.waitForTimeout(200);
    ok(await p.evaluate(() => document.querySelectorAll('.ak47-z').length === 2), g + ': Anrufliste zeigt 2 Einträge');
    await p.evaluate(() => { AQ2.sel = 'a1'; aq2Anruf('nicht_erreicht'); }); await p.waitForTimeout(200);
    const er = await p.evaluate(() => ({ e: findObjekt('a1').anrufErledigt === ak47Heute(), t: db.termine.find(t => t.anrufliste).titel, morgen: /Morgen nochmal anrufen/.test(document.getElementById('dpErgebnis').innerText) }));
    ok(er.e && /\(1 offen\)/.test(er.t) && er.morgen, g + ': Anruf „nicht erreicht“ → ✓ abgehakt, Eintrag „(1 offen)“, Angebot „Morgen nochmal anrufen“');
    await p.evaluate(() => { schliesseModal(); });
    // ── Telefontermin ──
    await p.evaluate(() => { schliesseModal(); AQ2.sel = 'a3'; aq2Detail(); aq2TerminNeu('rueckruf'); }); await p.waitForTimeout(250);
    const tq = await p.evaluate(() => ({ art: [...document.querySelectorAll('.tq-art')].map(b => b.textContent.trim()).join('|'), wahl: (document.querySelector('input[name="ak47telart"]:checked') || {}).value, st: document.getElementById('tq_st_text').textContent, titel: document.getElementById('tq_titel').value }));
    ok(/📞 Telefontermin/.test(tq.art) && tq.wahl === 'erstkontakt' && /Telefontermin/.test(tq.st) && /^📞 Telefontermin: Bungalow Grünau/.test(tq.titel), g + ': Termin-Dialog „📞 Telefontermin“, Vorschlag Erstkontakt, Status-Haken „Telefontermin“');
    await p.evaluate(() => aq2TerminAnlegen()); await p.waitForTimeout(250);
    const tt = await p.evaluate(() => { const o = findObjekt('a3'); return { st: o.status, art: o.telefonArt, pill: (document.querySelector('#lc-a3 .pill') || {}).textContent }; });
    ok(tt.st === 'telefontermin' && tt.art === 'erstkontakt' && tt.pill === '📞 Telefontermin · Erstkontakt', g + ': gespeichert → Status „📞 Telefontermin · Erstkontakt“ (' + tt.pill + ')');
    await p.evaluate(() => { const o = findObjekt('a1'); o.verlauf.push({ ts: Date.now(), typ: 'gespraech', text: 'Gespräch: Interesse' }); AQ2.sel = 'a1'; aq2Detail(); aq2TerminNeu('rueckruf'); }); await p.waitForTimeout(200);
    ok(await p.evaluate(() => document.querySelector('input[name="ak47telart"]:checked').value) === 'nachfassen', g + ': nach einem Gespräch schlägt der Dialog „Nachfassen“ vor');
    await p.evaluate(() => { schliesseModal(); AQ2.sel = 'a3'; aq2Detail(); }); await p.waitForTimeout(150);
    await p.evaluate(() => ak47TelArt('a3', 'nachfassen')); await p.waitForTimeout(150);
    ok(await p.evaluate(() => document.querySelector('#lc-a3 .pill').textContent === '📞 Telefontermin · Nachfassen' && OBJEKT_STATUS.some(s => s[0] === 'telefontermin') && AQ_OFFEN.includes('telefontermin')), g + ': Umschalten auf Nachfassen; Status in Auswahl + „offene“ Leads');
    await p.evaluate(() => { AQ2.sel = 'a3'; aq2StatusSetzen('nochmal_anrufen'); }); await p.waitForTimeout(150);
    ok(await p.evaluate(() => document.querySelector('#lc-a3 .pill').textContent) === 'Nochmal anrufen', g + ': Status „Nochmal anrufen“ heißt in der Liste auch so (nicht „Rückruf“)');
    // ── 2 Wochen ohne Antwort ──
    const an = await p.evaluate(() => ({ l: an31Liste().map(o => o.id).sort(), hin: tbHinweise().map(x => x.t).join(' | '), nf: (db.hinweisEinst || {}).nachfassen }));
    ok(an.l.join() === 'w1,w2', g + ': Meldung erst ab 14 Tagen: w1 (15 T.) + w2 (16 T.), nicht w3 (10 T.) (' + an.l.join() + ')');
    ok(/2 angeschriebene Leads seit 2 Wochen ohne Antwort/.test(an.hin) && !/seit 5|Kleinanzeige.*nachfassen|E-Mails? ohne Antwort/i.test(an.hin) && an.nf === false, g + ': Glocke nur „seit 2 Wochen“, Nachfass-Hinweise nach 5 Tagen aus');
    await p.evaluate(() => { const a = akqDb(); a.an31GezeigtAm = ''; an31KarteZeigen(); }); await p.waitForTimeout(200);
    ok(await p.evaluate(() => /Alle löschen\?/.test(document.getElementById('an31Karte').innerText)), g + ': Meldung mit Knopf „🗑 Alle löschen?“');
    await p.click('#an31Karte button:has-text("Alle löschen?")'); await p.waitForTimeout(200);
    await p.click('#bc_ja'); await p.waitForTimeout(400);
    ok(await p.evaluate(() => !findObjekt('w1') && !findObjekt('w2') && !!findObjekt('w3') && !document.getElementById('an31Karte') && akqDb().ausgeschlossen.length >= 2), g + ': „Alle löschen?“ → bestätigt → beide gelöscht, w3 bleibt, Sperrliste ergänzt');
    if(g === 'pc'){ await p.evaluate(() => { AQ2.sel = 'a1'; aq2Neu(); }); await p.waitForTimeout(200); await p.screenshot({ path: '/tmp/v46/v47_akquise_pc.png' }); }
    else { await p.evaluate(() => { ak47ListeDialog(); }); await p.waitForTimeout(200); await p.screenshot({ path: '/tmp/v46/v47_anrufliste_handy.png' }); }
    ok(p.fe.length === 0, g + ': keine Fehler ' + p.fe.join(' | '));
    await p.close();
  }
  await b.close();
  console.log(f ? `${f} FEHLER` : 'ALLES OK'); process.exit(f ? 1 : 0);
})();
