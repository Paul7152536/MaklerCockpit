// v47 Smoke: Kleinanzeigen-Fenster trägt Nachricht ins Feld ein (nicht senden), „keine Makler“ → erst auf Nachfrage
const { app, BrowserWindow } = require('electron'); const http = require('http'); const fs = require('fs');
const HOME = '/tmp/claude-0/-home-claude/fcfe88c9-293d-574d-8cfa-b1821c923895/scratchpad/etest/home47ka';
fs.rmSync(HOME, { recursive: true, force: true });
app.setPath('documents', HOME + '/Dokumente');
process.env.MC_WEB_TEST = '1';
const seite = (titel, text) => `<!doctype html><html><head><meta charset="utf-8"><title>${titel}</title></head><body>
<h1 id="viewad-title">${titel}</h1><div id="viewad-description-text">${text}</div>
<button id="kontakt" onclick="setTimeout(()=>{document.getElementById('f').style.display='block'},500)">Nachricht schreiben</button>
<form id="f" style="display:none"><textarea name="message" placeholder="Deine Nachricht"></textarea><button type="button" id="senden" onclick="window.__gesendet=true">Nachricht senden</button></form>
<script>window.__inputs=0;document.querySelector('textarea').addEventListener('input',()=>window.__inputs++);</script></body></html>`;
const srv = http.createServer((req, res) => {
  res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' });
  res.end(/km/.test(req.url) ? seite('DHH in Adlershof', 'Schöne DHH. Bitte keine Makleranfragen!') : seite('Haus mit Garten in Johannisthal', 'Gepflegtes Haus, Garten, Keller.'));
});
srv.listen(0, '127.0.0.1');
require(process.env.MC_MAIN || '/tmp/pc/app/main.js');
const warte = ms => new Promise(r => setTimeout(r, ms));
app.whenReady().then(() => setTimeout(async () => {
  let fehler = 0; const ok = (b, t) => { console.log((b ? 'ok   ' : 'FEHL ') + t); if(!b) fehler++; };
  try{
    const w = BrowserWindow.getAllWindows()[0], port = srv.address().port;
    await w.webContents.executeJavaScript(`window.__nd = []; (function(){ const _k = kgDaten; kgDaten = function(d){ if(d && d.art === 'nachricht') window.__nd.push(d.ergebnis); return _k.apply(this, arguments); }; })(); true`);
    const TEXT = 'Guten Tag,\nich bin Makler bei BETTERHOMES … „Test“ mit Umlauten äöü.';
    const r = await w.webContents.executeJavaScript(`window.pc.webfenster('nachricht', { url: 'http://127.0.0.1:${port}/s-anzeige/haus/1', text: ${JSON.stringify(TEXT)}, id: 'x1' })`);
    ok(r && r.ok, 'Nachricht-Aktion angenommen');
    await warte(3500);
    const kw = BrowserWindow.getAllWindows().find(x => x !== w);
    ok(!!kw, 'Kleinanzeigen-Fenster offen');
    const st = JSON.parse(await kw.webContents.executeJavaScript(`JSON.stringify({ v: document.querySelector('textarea').value, n: window.__inputs, g: !!window.__gesendet, info: document.getElementById('__mcInfo').textContent })`));
    ok(st.v === TEXT && st.n >= 1, 'Text steht im Nachrichtenfeld (nach Klick auf „Nachricht schreiben“), input-Ereignis ausgelöst');
    ok(!st.g, 'NICHT gesendet – Senden klickt Paul selbst');
    ok(/prüfen und selbst auf „Senden“/.test(st.info), 'Leiste: ' + st.info);
    ok(require('electron').clipboard.readText() === TEXT, 'Text zusätzlich in der Zwischenablage');
    ok(JSON.parse(await w.webContents.executeJavaScript(`JSON.stringify(window.__nd)`)).includes('ok'), 'Cockpit bekommt Rückmeldung „ok“');
    // keine Makler
    await w.webContents.executeJavaScript(`window.pc.webfenster('nachricht', { url: 'http://127.0.0.1:${port}/s-anzeige/km/2', text: 'Hallo', id: 'x2' })`);
    await warte(2500);
    const km = JSON.parse(await kw.webContents.executeJavaScript(`JSON.stringify({ v: document.querySelector('textarea').value, info: document.getElementById('__mcInfo').textContent, knopf: !!document.getElementById('__mcTrotzdem') })`));
    ok(km.v === '' && /keine Makler/.test(km.info) && km.knopf, '„Bitte keine Makleranfragen“ → nichts eingetragen, Knopf „Trotzdem eintragen“');
    ok(JSON.parse(await w.webContents.executeJavaScript(`JSON.stringify(window.__nd)`)).includes('keinMakler'), 'Cockpit bekommt „keinMakler“');
    await kw.webContents.executeJavaScript(`document.getElementById('__mcTrotzdem').click()`);
    await warte(2000);
    ok(await kw.webContents.executeJavaScript(`document.querySelector('textarea').value`) === 'Hallo', '„Trotzdem eintragen“ trägt den Text ein');
    ok(await kw.webContents.executeJavaScript(`typeof window.pc === 'undefined' && typeof require === 'undefined'`), 'Fremde Seite hat weiterhin keinen Zugriff aufs Programm');
    const fremd = await w.webContents.executeJavaScript(`window.pc.webfenster('nachricht', { url: 'https://example.com/x', text: 'a' })`);
    ok(fremd && fremd.ok === false, 'Fremde Adresse abgelehnt');
    await w.webContents.executeJavaScript(`window.pc.webfenster('schliessen')`);
  }catch(e){ console.log('FEHLER', e && e.stack || e); fehler++; }
  console.log('FEHLER', fehler);
  app.exit(0);
}, 3000));
