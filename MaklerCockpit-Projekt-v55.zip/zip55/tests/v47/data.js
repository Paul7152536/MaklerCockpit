const T = 864e5, jetzt = Date.now();
const dk = n => { const d = new Date(); d.setDate(d.getDate() + n); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); };
const lead = (id, x) => Object.assign({ id, objektart: 'Wohnung', ort: '12487 Berlin', status: 'neu', quelle: 'Kleinanzeigen', createdAt: jetzt - 2 * T, verlauf: [] }, x);
const D = JSON.stringify({ objekte: [
  lead('n1', { akqTitel: 'Neu 1' }), lead('n2', { akqTitel: 'Neu 2', verkaeuferTelefon: '0151 2222222' }),
  lead('s1', { akqTitel: 'Angeschrieben', status: 'kleinanzeigen_geschrieben', statusAm: jetzt }),
  lead('t1', { akqTitel: 'Provisionsfrei 3-Zimmer Gropiusstadt', status: 'termin', hatTermin: true }),
  lead('t2', { akqTitel: 'Telefontermin', status: 'telefontermin' }),
  lead('r1', { akqTitel: 'Nochmal anrufen', status: 'nochmal_anrufen', hatTermin: true }),
  lead('x1', { akqTitel: 'Königsheideweg', adresse: 'Königsheideweg 190', status: 'erstkontakt' }),
  lead('k1', { akqTitel: 'Kontakt im Termin', status: 'termin' })],
  kontakte: [{ id: 'kk', name: 'Sandra Beispiel', telefon: '01633 840793' }],
  termine: [
    { id: 'h1', titel: 'Akquise heute', datum: dk(0), uhrzeit: '11:00', art: 'akquise', objektId: 'n1' },
    { id: 'm1', titel: 'Besichtigung morgen', datum: dk(1), uhrzeit: '10:00', art: 'besichtigung', objektId: 'n2' },
    { id: 'm2', titel: 'Erstgespräch morgen', datum: dk(1), uhrzeit: '12:00', art: 'erstgespraech', objektId: 'r1' },
    { id: 'g1', titel: 'Termin Gropiusstadt', datum: dk(1), uhrzeit: '10:00', art: 'termin', objektId: 't1', notiz: 'Eigentümer: Herr Lange\nTel. 0176 48845539' },
    { id: 'g2', titel: 'Besichtigung Königsheideweg 190', datum: dk(2), uhrzeit: '09:00', art: 'termin', notiz: 'Rene 0151-61689468' },
    { id: 'g3', titel: 'Termin', datum: dk(2), uhrzeit: '15:00', art: 'termin', objektId: 'k1', kontaktId: 'kk' }],
  aufgaben: [], notizen: [], meta: { v9neustart: { quittiert: true } } });
module.exports = D;
