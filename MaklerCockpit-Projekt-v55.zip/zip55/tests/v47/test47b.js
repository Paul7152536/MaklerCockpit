// v47 Nachtrag: Heute nur heute, Pipeline, Name/Telefon aus Terminen
const { chromium } = require('playwright');
let f = 0; const ok = (b, t) => { console.log((b ? 'ok   ' : 'FEHL ') + t); if(!b) f++; };
const T = 864e5, jetzt = Date.now();
const dk = n => { const d = new Date(); d.setDate(d.getDate() + n); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); };
const lead = (id, x) => Object.assign({ id, objektart: 'Wohnung', ort: '12487 Berlin', status: 'neu', quelle: 'Kleinanzeigen', createdAt: jetzt - 2 * T, verlauf: [] }, x);
const D = JSON.stringify({ objekte: [
  lead('n1', { akqTitel: 'Neu 1' }), lead('n2', { akqTitel: 'Neu 2', verkaeuferTelefon: '0151 2222222' }),
  lead('s1', { akqTitel: 'Angeschrieben', status: 'kleinanzeigen_geschrieben', statusAm: jetzt }),
  lead('t1', { akqTitel: 'Provisionsfrei 3-Zimmer Gropiusstadt', status: 'termin', hatTermin: true }),
  lead('t2', { akqTitel: 'Telefontermin', status: 'telefontermin' }),
  lead('r1', { akqTitel: 'Nochmal anrufen', status: 'nochmal_anrufen', hatTermin: true }),
  lead('x1', { akqTitel: 'Königsheideweg', adresse: 'Königsheideweg 190', status: 'erstkontakt' }),
  lead('k1', { akqTitel: 'Kontakt im Termin', status: 'termin' })],
  kontakte: [{ id: 'kk', name: 'Sandra Beispiel', telefon: '01633 840793' }],
  termine: [
    { id: 'h1', titel: 'Akquise heute', datum: dk(0), uhrzeit: '11:00', art: 'akquise', objektId: 'n1' },
    { id: 'm1', titel: 'Besichtigung morgen', datum: dk(1), uhrzeit: '10:00', art: 'besichtigung', objektId: 'n2' },
    { id: 'm2', titel: 'Erstgespräch morgen', datum: dk(1), uhrzeit: '12:00', art: 'erstgespraech', objektId: 'r1' },
    { id: 'g1', titel: 'Termin Gropiusstadt', datum: dk(1), uhrzeit: '10:00', art: 'termin', objektId: 't1', notiz: 'Eigentümer: Herr Lange\nTel. 0176 48845539' },
    { id: 'g2', titel: 'Besichtigung Königsheideweg 190', datum: dk(2), uhrzeit: '09:00', art: 'termin', notiz: 'Rene 0151-61689468' },
    { id: 'g3', titel: 'Termin', datum: dk(2), uhrzeit: '15:00', art: 'termin', objektId: 'k1', kontaktId: 'kk' }],
  aufgaben: [], notizen: [], meta: { v9neustart: { quittiert: true } } });
(async () => {
  const b = await chromium.launch();
  for(const [g, w, h] of [['pc', 1440, 900], ['handy', 412, 915]]){
    const p = await b.newPage({ viewport: { width: w, height: h }, isMobile: g === 'handy' });
    p.fe = []; p.on('pageerror', e => p.fe.push(e.message));
    await p.addInitScript(([d, g]) => { window.pc = { geraet: g, laden: () => JSON.parse(d), speichern: () => ({ ok: true }), ordner(){}, sicherungSchreiben: () => ({ ok: true }), sicherungLesen: () => null }; }, [D, g]);
    await p.goto('file:///tmp/pc/app/index.html'); await p.waitForTimeout(2500);
    await p.evaluate(() => { try{ schliesseModal(); }catch(e){} document.getElementById('an31Karte') && document.getElementById('an31Karte').remove(); });
    // ── Name/Telefon aus Terminen ──
    const v = await p.evaluate(() => ({ t1: [aqName(findObjekt('t1')), aqTel(findObjekt('t1'))], x1: [aqName(findObjekt('x1')), aqTel(findObjekt('x1'))], g2: db.termine.find(t => t.id === 'g2').objektId, k1: [aqName(findObjekt('k1')), aqTel(findObjekt('k1'))], n2: aqTel(findObjekt('n2')) }));
    ok(v.t1[0] === 'Herr Lange' && v.t1[1] === '0176 48845539', g + ': Name und Telefon aus der Terminnotiz ins Objekt (' + v.t1 + ')');
    ok(v.g2 === 'x1' && v.x1[1] === '0151-61689468', g + ': Kalendertermin ohne Objekt über Adresse zugeordnet, Telefon übernommen (' + v.g2 + ' ' + v.x1 + ')');
    ok(v.k1[0] === 'Sandra Beispiel' && v.k1[1] === '01633 840793', g + ': Kontakt im Termin → Eigentümer im Objekt (' + v.k1 + ')');
    ok(v.n2 === '0151 2222222', g + ': vorhandene Nummer bleibt');
    // ── Heute ──
    await p.evaluate(() => wechsleAnsicht('heute')); await p.waitForTimeout(400);
    const hu = await p.evaluate(() => ({ txt: document.getElementById('main').innerText, liste: ak24Prioritaeten().liste.map(x => x.datum) }));
    ok(hu.liste.every(d => !d || d <= dk(0)), g + ': Heute-Liste nur bis heute (' + hu.liste.join(',') + ')');
    ok(!/Besichtigung morgen|Erstgespräch morgen/.test(hu.txt), g + ': keine Termine von morgen auf „Heute“');
    ok(/Morgen: 3 Termine/.test(hu.txt), g + ': kleine Zeile „Morgen: 3 Termine“');
    // ── Pipeline Akquise ──
    await p.evaluate(() => wechsleAnsicht('akquise')); await p.waitForTimeout(400);
    const pl = await p.evaluate(() => Array.from(document.querySelectorAll('.pl47-st')).map(b => b.innerText.replace(/\s+/g, ' ').trim()));
    ok(pl.length === 4 && /Neu/.test(pl[0]) && /Angeschrieben/.test(pl[1]) && /Termin/.test(pl[2]) && /Nochmal anrufen/.test(pl[3]), g + ': Pipeline Neu › Angeschrieben › Termin › Nochmal anrufen (' + pl.join(' | ') + ')');
    const z = await p.evaluate(() => pl47Zahlen());
    ok(z.neu === 2 && z.angeschrieben === 2 && z.termin === 3 && z.anrufen === 1, g + ': Zahlen ' + JSON.stringify(z));
    await p.evaluate(() => pl47Filter('aq', 'termin')); await p.waitForTimeout(300);
    const ids = await p.evaluate(() => Array.from(document.querySelectorAll('#aqListe .lc')).map(x => x.id.replace('lc-', '')).sort().join());
    ok(ids === 'k1,t1,t2', g + ': Klick auf „Termin“ filtert (' + ids + ')');
    await p.evaluate(() => { AQ2.status = 'offen'; AQ2.sel = 's1'; renderAkquise(document.getElementById('main')); aq2Waehlen('s1'); }); await p.waitForTimeout(300);
    ok(await p.evaluate(() => !!document.querySelector('#aqDetail .pl47-sch.an') && /Angeschrieben/.test(document.querySelector('#aqDetail .pl47-sch.an').textContent)), g + ': Detail zeigt Stufe „Angeschrieben“');
    await p.evaluate(() => pl47Setzen('anrufen')); await p.waitForTimeout(200);
    ok(await p.evaluate(() => findObjekt('s1').status === 'nochmal_anrufen'), g + ': Klick „Nochmal anrufen“ setzt Status');
    if(g === 'pc'){
      // ── Objekte-Seite ──
      await p.evaluate(() => { wechsleAnsicht('objekte'); ob26Wechseln('akquise'); }); await p.waitForTimeout(400);
      const ob = await p.evaluate(() => ({ pl: document.querySelectorAll('#main .pl47-st').length, dop: Array.from(document.querySelectorAll('#objTabelle .badge')).filter(b => b.textContent.trim() === '📅 Termin').length }));
      ok(ob.pl === 4 && ob.dop === 0, 'pc: Objekte-Seite mit Pipeline, kein doppeltes „📅 Termin“ (' + JSON.stringify(ob) + ')');
      await p.evaluate(() => pl47Filter('ob', 'anrufen')); await p.waitForTimeout(300);
      const rows = await p.evaluate(() => Array.from(document.querySelectorAll('#objTabelle tr.row')).map(r => r.innerText.split('\n')[0]));
      ok(rows.length === 2 && rows.every(r => /anrufen|Angeschrieben/i.test(r)), 'pc: Objekte-Pipeline-Filter „Nochmal anrufen“ (' + rows.join(' / ') + ')');
      const rowT1 = await p.evaluate(() => { PL47F.ob = ''; renderMain(); return Array.from(document.querySelectorAll('#objTabelle tr.row')).find(r => /Gropiusstadt/.test(r.innerText)).innerText; });
      ok(/Herr Lange/.test(rowT1) && /0176 48845539/.test(rowT1), 'pc: Eigentümer-Spalte zeigt Name und Telefon aus dem Termin');
      // ── Termin-Dialog: Telefon eintragen → Objekt ──
      await p.evaluate(() => { oeffneTerminModal('h1'); }); await p.waitForTimeout(200);
      await p.fill('#m_t_vbtel', '0170 5555555'); await p.fill('#m_t_vbname', 'Frau Neu');
      await p.evaluate(() => speichereTermin('h1')); await p.waitForTimeout(200);
      ok(await p.evaluate(() => aqTel(findObjekt('n1')) === '0170 5555555' && aqName(findObjekt('n1')) === 'Frau Neu'), 'pc: Telefon/Name im Termin-Dialog → Objekt');
      const zeile = await p.evaluate(() => gsTerminZeile(db.termine.find(t => t.id === 'h1'), false));
      ok(/Frau Neu/.test(zeile) && /0170 5555555/.test(zeile), 'pc: Terminzeile zeigt Eigentümer und Telefon');
    }
    ok(!p.fe.length, g + ': keine JS-Fehler ' + p.fe.slice(0, 3).join(' | '));
    await p.close();
  }
  await b.close(); console.log(f ? 'FEHLER ' + f : 'ALLES OK'); process.exit(f ? 1 : 0);
})();
