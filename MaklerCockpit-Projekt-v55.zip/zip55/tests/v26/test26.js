// v26: Zwei Felder (betreut/Akquise), Exposé-Import ins Feld, Kaufgesuche bis 100
const { chromium } = require('playwright');
let f = 0; const ok = (b, t) => { console.log((b ? 'ok   ' : 'FEHL ') + t); if(!b) f++; };
const HEUTE = new Date().toISOString().slice(0, 10);
(async () => {
  const b = await chromium.launch();
  const p = await b.newPage({ viewport: { width: 1500, height: 950 } });
  const fe = []; p.on('pageerror', e => fe.push(e.message)); p.on('dialog', d => d.accept());
  await p.addInitScript(([HEUTE]) => {
    const start = { objekte: [
      { id: 'a1', createdAt: 1, akqTitel: 'Lead ohne Termin', objektart: 'Wohnung', ort: '10365 Berlin', status: 'neu', verlauf: [], quelle: 'Kleinanzeigen', link: 'https://www.kleinanzeigen.de/s-anzeige/haus/123', verkaeuferName: 'Herr Neumann', verkaeuferTelefon: '01633840793', anschreibenText: 'KI-Text alt', anschreibenEigen: true },
      { id: 'z1', createdAt: 1, akqTitel: 'Anwesen mit zwei Wohnungen', objektart: 'Wohnung', ort: 'Südlich von Berlin', status: 'neu', verlauf: [], quelle: 'Zeitung', verkaeuferName: 'Jürgen Koch', verkaeuferTelefon: '0172 5550123' },
      { id: 'a2', createdAt: 2, akqTitel: 'Lead mit Termin', objektart: 'EFH', ort: '14612 Falkensee', status: 'termin', verlauf: [] },
      { id: 'b1', createdAt: 3, akqTitel: 'Auftrag Spandau', objektart: 'Wohnung', ort: '13597 Berlin', status: 'auftrag', verlauf: [] },
      { id: 'b2', createdAt: 4, akqTitel: 'Online Pankow', objektart: 'Wohnung', ort: '13187 Berlin', status: 'online', verlauf: [] }],
      kontakte: [], termine: [{ id: 't1', createdAt: 1, titel: 'Besichtigung', datum: HEUTE, uhrzeit: '15:00', objektId: 'a2', art: 'besichtigung', wo: 'vorort' }], aufgaben: [], notizen: [], gesuche: [], marktanalysen: [], mentorFragen: [], meta: { v9neustart: { quittiert: true } } };
    window.pc = { laden: () => JSON.parse(sessionStorage.getItem('d') || 'null') || start, speichern: t => { sessionStorage.setItem('d', t); return { ok: true }; }, ordner(){}, sicherungSchreiben: () => ({ ok: true }), sicherungLesen: () => null, zwischenablage: async () => '', abruf: async () => ({ ok: false }) };
  }, [HEUTE]);
  await p.goto('file:///tmp/pc/app/index.html'); await p.waitForTimeout(2000);
  let r = await p.evaluate(() => db.objekte.map(o => o.id + ':' + o.bereich).join(','));
  ok(r === 'a1:akquise,z1:akquise,a2:akquise,b1:betreut,b2:betreut', 'Bestand eingeteilt: Leads → Akquise, Auftrag/online → betreut');
  await p.evaluate(() => wechsleAnsicht('objekte')); await p.waitForTimeout(300);
  r = await p.evaluate(() => ({ felder: document.querySelectorAll('.ob26-feld').length, aktiv: document.querySelector('.ob26-feld.aktiv').innerText, zeilen: Array.from(document.querySelectorAll('#objTabelle tbody tr')).map(z => z.innerText).join(' | ') }));
  ok(r.felder === 2 && /Objekte, die ich betreue/.test(r.aktiv) && /Spandau/.test(r.zeilen) && /Pankow/.test(r.zeilen) && !/Lead/.test(r.zeilen), 'Objekte-Seite: zwei Felder, „betreut“ zeigt nur die 2 Aufträge');
  await p.screenshot({ path: '/tmp/v26test/1_betreut.png' });
  await p.evaluate(() => ob26Wechseln('akquise')); await p.waitForTimeout(300);
  r = await p.evaluate(() => Array.from(document.querySelectorAll('#objTabelle tbody tr')).map(z => z.innerText).join(' | '));
  ok(/Lead ohne Termin/.test(r) && /Lead mit Termin/.test(r) && !/Spandau/.test(r), 'Feld „Akquise-Objekte“ zeigt beide Leads (mit und ohne Termin)');
  await p.screenshot({ path: '/tmp/v26test/2_akquise.png' });
  r = await p.evaluate(() => Array.from(document.querySelectorAll('#objTabelle tbody tr')).find(z => /Lead ohne Termin/.test(z.innerText)).children[3].innerText);
  ok(/Herr Neumann/.test(r) && /01633840793/.test(r), 'Spalte Eigentümer zeigt Name + Nummer auch ohne verknüpften Kontakt: ' + r.replace(/\n/g, ' / '));
  // Anschreiben: Kleinanzeigen- und Zeitungs-Text
  await p.evaluate(() => { window.__kopiert = []; akqKopieren = (t) => window.__kopiert.push(t); window.open = () => null; wechsleAnsicht('akquise'); AQ2.status = 'alle'; AQ2.sel = 'a1'; aq2Senden(); AQ2.sel = 'z1'; aq2Senden(); });
  r = await p.evaluate(() => ({ k: window.__kopiert, alt: findObjekt('a1').anschreibenAlt26, gruss: vl26Gruss(), knoepfe: document.body.innerText.includes('WhatsApp') }));
  ok(/^Guten Tag,\n\nist die Immobilie noch zum Verkauf\?\nFalls ja, dann senden Sie mir bitte Ihre Telefonnummer/.test(r.k[0] || '') && /Paul Görner$/.test(r.k[0] || ''), 'Kleinanzeigen-Lead: neuer Kleinanzeigen-Text (alter KI-Text gesichert: ' + r.alt + ')');
  ok((r.k[1] || '').startsWith(r.gruss + ',\nich bin auf Ihre Immobilienanzeige in der Zeitung aufmerksam geworden') && /Freundliche Grüße$/.test(r.k[1] || '') && r.knoepfe, 'Zeitungs-Lead: Zeitungs-Text mit „' + r.gruss + '“, WhatsApp/SMS-Knöpfe bei Handynummer');
  r = await p.evaluate(() => [vl26Gruss(new Date(2026, 10, 12, 8)), vl26Gruss(new Date(2026, 10, 12, 14)), vl26Gruss(new Date(2026, 10, 12, 19))].join('|'));
  ok(r === 'Guten Morgen|Guten Tag|Guten Abend', 'Begrüßung nach Uhrzeit: ' + r);
  r = await p.evaluate(() => { akqVorlageBearbeiten && akqVorlageBearbeiten('zeitung'); return document.getElementById('modalInner').innerText; });
  ok(/Zeitung/.test(r) && /Kleinanzeigen/.test(r), 'Vorlagen-Editor kennt „Kleinanzeigen“ und „Zeitung“');
  await p.evaluate(() => { schliesseModal(); wechsleAnsicht('objekte'); ob26Wechseln('akquise'); });
  // Status → Auftrag: wandert automatisch
  await p.evaluate(() => { oeffneObjektModal('a2'); document.getElementById('m_status').value = 'auftrag'; speichereObjekt('a2'); }); await p.waitForTimeout(800);
  r = await p.evaluate(() => ({ b: findObjekt('a2').bereich, akq: aqGefiltert().some(o => o.id === 'a2') || AQ2.status !== 'alle' }));
  ok(r.b === 'betreut', 'Akquise-Objekt bekommt „Auftrag erhalten“ → automatisch zu „betreut“');
  // Von Hand zurück in die Akquise → bleibt dort
  await p.evaluate(() => { oeffneObjektModal('a2'); ob26WahlSetzen('akquise'); speichereObjekt('a2'); }); await p.waitForTimeout(600);
  r = await p.evaluate(() => ({ b: findObjekt('a2').bereich, fest: findObjekt('a2').bereichFest }));
  ok(r.b === 'akquise' && r.fest, 'Bereich von Hand gesetzt → bleibt, auch mit Status Auftrag');
  // Neues betreutes Objekt im Feld „betreut“
  await p.evaluate(() => { ob26Wechseln('betreut'); oeffneObjektModal(); });
  r = await p.evaluate(() => ({ wahl: document.getElementById('ob26Bereich').dataset.wert, st: document.getElementById('m_status').value }));
  ok(r.wahl === 'betreut' && r.st === 'auftrag', 'Neues Objekt im Feld „betreut“: Bereich betreut, Status „Auftrag erhalten“ vorbelegt');
  await p.fill('#m_adresse', 'Teststraße 1'); await p.fill('#m_ort', '10247 Berlin'); await p.evaluate(() => speichereObjekt()); await p.waitForTimeout(500);
  r = await p.evaluate(() => { const o = db.objekte.find(x => x.adresse === 'Teststraße 1'); return { b: o.bereich, h: o.herkunftBereich, inAkq: aqGefiltert.call ? (() => { AQ2.status = 'alle'; return aqGefiltert().some(x => x.id === o.id); })() : null }; });
  ok(r.b === 'betreut' && r.h === 'direkt' && r.inAkq === false, 'Direkt angelegtes betreutes Objekt erscheint nicht in der Akquise-Liste');
  // Exposé-Import ins Feld „betreut“
  await p.evaluate(() => { ob26Wechseln('betreut'); });
  await p.setInputFiles('#exposeInput2', ['/tmp/v26test/Expose-Lichtenberg-Wohnung.pdf', '/tmp/v26test/Expose-Falkensee-Haus.pdf']);
  await p.waitForFunction(() => db.objekte.filter(o => o.quelle === 'Exposé').length >= 2, null, { timeout: 60000 }).catch(() => {});
  await p.waitForTimeout(800);
  r = await p.evaluate(() => db.objekte.filter(o => o.quelle === 'Exposé').map(o => ({ adr: o.adresse, ort: o.ort, art: o.objektart, kp: o.kaufpreis, wf: o.wohnflaeche, gs: o.grundstueck, bj: o.baujahr, b: o.bereich, st: o.status, tel: o.verkaeuferTelefon, name: o.verkaeuferName, notiz: (o.notizen || '').replace(/<br>/g, ' | ').slice(0, 300) })));
  console.log(JSON.stringify(r, null, 1));
  const w = r.find(x => /Frankfurter/.test(x.adr || '')), h = r.find(x => /Gutspark|Falkensee/.test((x.adr || '') + (x.ort || '')));
  ok(r.length === 2 && r.every(x => x.b === 'betreut' && x.st === 'auftrag' && !x.tel && !x.name), 'Zwei Exposés eingelesen → „betreut“, Status Auftrag, keine Platzhalter-Kontakte');
  ok(w && Number(w.kp) === 349000 && Number(w.wf) === 75 && String(w.bj) === '1995' && /10365/.test(w.ort || ''), 'Wohnung: Adresse, PLZ, Kaufpreis 349.000, 75 m², Baujahr 1995 erkannt');
  ok(h && Number(h.kp) === 589000 && Number(h.wf) === 140 && Number(h.gs) === 650 && String(h.bj) === '2004', 'Haus: Kaufpreis 589.000, 140 m², Grundstück 650 m², Baujahr 2004 erkannt');
  ok(!(r.some(x => /0176 12345678/.test(x.tel || ''))), 'Makler-Telefon aus dem Exposé wird nicht als Eigentümer eingetragen');
  await p.evaluate(() => renderMain()); await p.screenshot({ path: '/tmp/v26test/3_expose.png' });
  // Kaufgesuche bis 100
  r = await p.evaluate(() => { const pr = AKQ_PROMPTS.find(x => x.key === 'gesuche'); const t = pr.prompt(akqDb().einst); return { t, titel: pr.titel }; });
  ok(/bis zu 100 aktuelle KAUFGESUCHE/.test(r.t) && /letzten 60 Tage/.test(r.t) && /FORTSETZUNG: weiter ab Nr\. X/.test(r.t) && /100/.test(r.titel), 'Prompt „Käufer-Gesuche“: bis zu 100, 60 Tage, mit Fortsetzung');
  await p.evaluate(() => gs26Setzen('anzahlGesuche', '250')); r = await p.evaluate(() => akqDb().einst.anzahlGesuche);
  ok(r === 100, 'Anzahl wird auf höchstens 100 begrenzt');
  await p.evaluate(() => gs26Setzen('anzahlGesuche', '80'));
  r = await p.evaluate(() => skKiPrompt(findObjekt('b1')));
  ok(/Suche bis zu 80 aktuelle KAUFGESUCHE/.test(r) && /FORTSETZUNG/.test(r), 'Objekt-Prompt „KI fragen“: bis zu 80 (Einstellung) mit Fortsetzung');
  await p.evaluate(() => gs26Setzen('anzahlGesuche', '100'));
  await p.evaluate(() => aq2Suchen()); r = await p.evaluate(() => !!document.querySelector('#modalInner .gs26-felder'));
  await p.evaluate(() => schliesseModal()); await p.evaluate(() => kgFinden());
  const r2 = await p.evaluate(() => ({ felder: !!document.querySelector('#kgModal .gs26-felder'), text: document.getElementById('kgModal').innerText }));
  ok(r && r2.felder && /Bis zu 100/.test(r2.text), 'Einstellungen in „Suchen lassen“ und „Suchkunden finden“');
  await p.evaluate(() => schliesseModal());
  const orte = ['Lichtenberg', 'Pankow', 'Spandau', 'Köpenick', 'Falkensee', 'Bernau', 'Potsdam', 'Neukölln', 'Marzahn', 'Hellersdorf'];
  const eintrag = i => `${i}.\nAnzeigentyp: Gesuch\nName: Familie Test ${i}\nSucht: ${i % 2 ? 'Einfamilienhaus' : 'Eigentumswohnung'}\nLage: ${orte[i % 10]}\nBudget: bis ${300 + i}.000 €\nDetails: ${3 + (i % 3)} Zimmer, Kauf\nTelefon: Nicht angegeben\nE-Mail: Nicht angegeben\nLink: https://www.kleinanzeigen.de/s-anzeige/suche-haus-${i}/30${String(i).padStart(5, '0')}-208-1\nEingestellt am: ${String(1 + (i % 28)).padStart(2, '0')}.10.2026\nQuelle: kleinanzeigen.de`;
  const teil1 = Array.from({ length: 50 }, (_, i) => eintrag(i + 1)).join('\n\n') + '\n\nFORTSETZUNG: weiter ab Nr. 51';
  const teil2 = Array.from({ length: 50 }, (_, i) => eintrag(i + 51)).join('\n\n') + '\n\nGesamt: 100 Gesuche';
  const vorher = await p.evaluate(() => db.gesuche.length);
  for(const t of [teil1, teil2, teil1]){ await p.evaluate(t => { kgKiEinfuegen(); document.getElementById('kgKiText').value = t; kgKiUebernehmen(); }, t); await p.waitForTimeout(400); }
  r = await p.evaluate(() => ({ n: db.gesuche.length, ohneLink: db.gesuche.filter(g => !g.link).length }));
  ok(r.n - vorher === 100, `100 Kaufgesuche aus zwei Teilen übernommen, erneutes Einfügen ohne Doppelte (${r.n - vorher})`);
  // Handy-Ansicht: Felder untereinander
  await p.setViewportSize({ width: 412, height: 900 }); await p.evaluate(() => wechsleAnsicht('objekte')); await p.waitForTimeout(400);
  await p.screenshot({ path: '/tmp/v26test/4_handy.png' });
  r = await p.evaluate(() => document.documentElement.scrollWidth);
  ok(r <= 420, 'Handy-Breite: zwei Felder untereinander, nichts ragt raus');
  ok(fe.length === 0, 'Keine Fehler ' + JSON.stringify(fe.slice(0, 3)));
  console.log('FEHLER', f); await b.close();
})();
