// Beispiel-Exposés als PDF (mit Textebene) erzeugen
const { chromium } = require('playwright');
const wohnung = `<h1>Exposé</h1><h2>Helle 3-Zimmer-Wohnung mit Südbalkon in Lichtenberg</h2>
<p>Objekt-Nr.: BH-2026-114</p>
<table><tr><td>Adresse</td><td>Frankfurter Allee 120, 10365 Berlin</td></tr>
<tr><td>Objektart</td><td>Etagenwohnung</td></tr><tr><td>Kaufpreis</td><td>349.000 €</td></tr>
<tr><td>Wohnfläche</td><td>ca. 75 m²</td></tr><tr><td>Zimmer</td><td>3</td></tr><tr><td>Etage</td><td>2. OG</td></tr>
<tr><td>Baujahr</td><td>1995</td></tr><tr><td>Zustand</td><td>gepflegt</td></tr><tr><td>Hausgeld</td><td>310 € monatlich</td></tr>
<tr><td>Heizungsart</td><td>Fernwärme</td></tr><tr><td>Energieausweis</td><td>Verbrauchsausweis, Endenergieverbrauch 98 kWh/(m²·a)</td></tr>
<tr><td>Käuferprovision</td><td>3,57 % inkl. MwSt.</td></tr></table>
<h3>Beschreibung</h3><p>Die helle Wohnung liegt im 2. Obergeschoss eines gepflegten Hauses. Balkon nach Süden, Einbauküche, Tageslichtbad.</p>
<h3>Ihr Ansprechpartner</h3><p>Paul Görner · BETTERHOMES · Telefon 0176 12345678 · paul.goerner@example.org</p>`;
const haus = `<h1>Exposé</h1><h2>Einfamilienhaus mit großem Garten in Falkensee</h2>
<p>Lage: Am Gutspark 7, 14612 Falkensee</p><p>Objekttyp: Einfamilienhaus</p>
<p>Kaufpreis: 589.000 EUR</p><p>Wohnfläche: 140 m²</p><p>Grundstücksfläche: 650 m²</p><p>Zimmer: 5</p><p>Baujahr: 2004</p>
<p>Heizung: Gas-Brennwert</p><p>Provision für Käufer: 3,57 % inkl. gesetzlicher MwSt.</p>
<p>Kontakt: Paul Görner, Tel. 0176 12345678</p>`;
(async () => {
  const b = await chromium.launch(); const p = await b.newPage();
  for(const [n, h] of [['Expose-Lichtenberg-Wohnung', wohnung], ['Expose-Falkensee-Haus', haus]]){
    await p.setContent(`<html><body style="font-family:Arial;font-size:12pt;padding:30px">${h}</body></html>`);
    await p.pdf({ path: '/tmp/v26test/' + n + '.pdf', format: 'A4' });
  }
  await b.close(); console.log('ok');
})();
