// v38: Mietpotenzial nach Handbuch – Vergleichsangebote, IBB-Daten, § 558, Status, Texte, Auffrischung
const { chromium } = require('playwright');
let f = 0; const ok = (b, t) => { console.log((b ? 'ok   ' : 'FEHL ') + t); if(!b) f++; };
const D = JSON.stringify({ objekte: [
  { id: 'o1', akqTitel: 'ETW Lichtenberg', objektart: 'Wohnung', status: 'neu', ort: '10365 Berlin', adresse: 'Musterstr. 5, 10365 Berlin', wohnflaeche: 68, baujahr: 1965, kaufpreis: 280000, verlauf: [], mv25: { wohnlage: 'mittel' } },
  { id: 'o2', akqTitel: 'Neubau Mitte', objektart: 'Wohnung', status: 'neu', ort: '10115 Berlin', adresse: 'Neustr. 1, 10115 Berlin', wohnflaeche: 80, baujahr: 2019, verlauf: [] },
  { id: 'o3', akqTitel: 'EFH Falkensee', objektart: 'Einfamilienhaus', status: 'neu', ort: '14612 Falkensee', adresse: 'Weg 2, 14612 Falkensee', wohnflaeche: 140, baujahr: 1998, verlauf: [] },
  { id: 'o5', akqTitel: 'Vermietet 558', objektart: 'Wohnung', status: 'neu', ort: '12043 Berlin', adresse: 'Karl-Marx-Str. 10, 12043 Berlin', wohnflaeche: 60, baujahr: 1910, miete_ist: 660, kaufpreis: 200000, verlauf: [], miete37: { ovmManuell: 12 } },
  { id: 'o6', akqTitel: 'Kapitalanlage', objektart: 'Wohnung', status: 'neu', ort: '13585 Berlin', adresse: 'Seestr. 3, 13585 Berlin', wohnflaeche: 80, baujahr: 1975, miete_ist: 800, kaufpreis: 250000, verlauf: [], mv25: { wohnlage: 'mittel' } },
  { id: 'o7', akqTitel: 'Rundung', objektart: 'Wohnung', status: 'neu', ort: '10365 Berlin', adresse: 'Testweg 1, 10365 Berlin', wohnflaeche: 60, baujahr: 1955, verlauf: [], miete37: { ovmManuell: 7.75 } }
], kontakte: [], termine: [], aufgaben: [], notizen: [], meta: { v9neustart: { quittiert: true } } });
async function seite(b, g, w, h){
  const p = await b.newPage({ viewport: { width: w, height: h }, isMobile: g === 'handy', hasTouch: g === 'handy' });
  p.fe = []; p.on('pageerror', e => p.fe.push(e.message)); p.on('dialog', d => d.dismiss());
  await p.addInitScript(([d, g]) => { window.pc = { geraet: g, laden: () => JSON.parse(d), speichern: () => ({ ok: true }), ordner(){}, sicherungSchreiben: () => ({ ok: true }), sicherungLesen: () => null, gekoppelt: () => true, google: async () => ({ ok: false }) }; navigator.clipboard.writeText = async t => { window.__kopie = t; }; }, [D, g]);
  await p.goto('file:///tmp/pc/app/index.html'); await p.waitForTimeout(2200);
  await p.evaluate(() => { try{ schliesseModal(); }catch(e){} for(const [id, m] of [['o5', 660], ['o6', 800]]) an24Setzen(findObjekt(id), 'miete_ist', { wert: m, herkunft: 'eigentuemer' }, { aktivieren: true }); }); await p.waitForTimeout(300);
  return p;
}
const R = (p, id, felder) => p.evaluate(([id, felder]) => { const x = mp37Rechnen(findObjekt(id), null); const o = {}; for(const k of felder){ let v = x; for(const t of k.split('.')) v = v == null ? v : v[t]; o[k] = v; } return o; }, [id, felder]);
const eq = (a, b, t) => Math.abs(a - b) < (t || 0.006);
const angebot = (i, qm, mehr) => { const fl = (mehr && mehr.flaeche) || 100; return JSON.stringify(Object.assign({ art: 'angebot', portal: 'immoscout24.de', portal_id: 'A' + i, url: 'https://example.org/expose/' + i, titel: 'Angebot ' + i, plz: '10365', ortsteil: 'Lichtenberg', objektart: 'wohnung', flaeche: fl, zimmer: 3, nettokalt: Math.round(qm * fl * 100) / 100, baujahr: 1970, abruf: '2026-11-14', geeignet: true }, mehr || {})); };
(async () => {
  const b = await chromium.launch();
  let p = await seite(b, 'pc', 1440, 900), r;
  // 1) Grundfall Lichtenberg
  r = await R(p, 'o1', ['ovm', 'grenzeBremse', 'ibb.median', 'ibb.mittel', 'ibb.p10', 'ibb.p90', 'status.code', 'stat.n', 'markt.median', 'von', 'bis', 'region.unten', 'region.oben']);
  console.log(JSON.stringify(r));
  ok(r.ovm > 5 && eq(r.grenzeBremse, r.ovm * 1.1, 1e-9), 'Lichtenberg: Vergleichsmiete aus Mietspiegel, Grenze +10 %');
  ok(r['ibb.median'] === 13.33 && r['ibb.mittel'] === 13.71 && r['region.unten'] === 7 && r['region.oben'] === 21.44, 'IBB 2025: Median 13,33 · Durchschnitt 13,71 · 80-%-Spanne 7,00–21,44');
  ok(r['status.code'] === 'vorlaeufig' && r['stat.n'] === 0, 'Status VORLÄUFIG (alles da, noch nicht geprüft), keine Stichprobe');
  ok(eq(r.von, r.ovm) && eq(r.bis, r.grenzeBremse), 'Empfehlung: Vergleichsmiete bis zulässige Obergrenze');
  // 2) Rundung: 7,75 €/m² × 60 m² → 465 € → 511,50 €
  r = await p.evaluate(() => { const o = findObjekt('o7'); const x = mp37Rechnen(o, null), t = mp37Texte(x), k = mp37KarteHtml(o, null, false); return { g: x.grenzeBremse, t: t.kurz, k511: /511,50 €/.test(k), k512: /512 €|511,80/.test(k) }; });
  ok(eq(r.g, 8.525, 1e-9) && r.k511 && !r.k512, 'Obergrenze centgenau 511,50 € (kein 512 € / 511,80 €)');
  ok(/465–511 € mtl\./.test(r.t) && !/512/.test(r.t), 'Inserattext rundet die Obergrenze nicht auf: ' + (r.t.match(/ca\. [^)]*\)/) || [''])[0]);
  // 3) Vormiete → Bestandsschutz, aber erst mit Nachweis freigegeben
  r = await p.evaluate(() => { mp37Setzen('o1', 'vormiete', 1200); const x = mp37Rechnen(findObjekt('o1'), null); mp37Setzen('o1', 'belegt', true); const y = mp37Rechnen(findObjekt('o1'), null); mp37Setzen('o1', 'vormiete', ''); mp37Setzen('o1', 'belegt', false); return { g: x.grenzeBremse, c1: x.status.code, g1: x.status.gruende.join('|'), c2: y.status.code }; });
  ok(eq(r.g, 1200 / 68) && r.c1 === 'pruefbedarf' && /Vormiete nicht belegt/.test(r.g1) && r.c2 === 'vorlaeufig', 'Höhere Vormiete = Obergrenze; ohne Nachweis PRÜFBEDARF, mit Nachweis frei');
  // 4) Neubau nur vermutet → gesperrt
  r = await p.evaluate(() => { const x = mp37Rechnen(findObjekt('o2'), null), t = mp37Texte(x); return { v: x.neubauVermutet, c: x.status.code, art: t.art, t: t.kurz, h: x.hinweise.join(' ') }; });
  ok(r.v && r.c === 'pruefbedarf' && r.art === 'region' && /noch zu prüfen/.test(r.t) && /erstmals genutzt UND vermietet/.test(r.h), 'Baujahr 2019: Ausnahme nur vermutet → PRÜFBEDARF, Text nur regionale Orientierung');
  ok(!/Bei Neuvermietung wird/.test(r.t) && /Durchschnitt 19,73/.test(r.t), 'Gesperrter Text nennt keinen Objektbetrag, aber Bezirks-Durchschnitt (Mitte 19,73)');
  r = await p.evaluate(() => { mp37Setzen('o2', 'neubau', 'ja'); mp37Setzen('o2', 'belegt', true); mp37Setzen('o2', 'wohnlage', 'gut'); const x = mp37Rechnen(findObjekt('o2'), null), t = mp37Texte(x); return { c: x.status.code, art: t.art, bremse: x.bremse, t: t.kurz }; });
  ok(r.c === 'vorlaeufig' && r.art === 'leer' && !r.bremse, 'Mit Nachweis: Ausnahme anerkannt, Text mit Betrag');
  // 5) Haus in Brandenburg
  r = await p.evaluate(() => { const x = mp37Rechnen(findObjekt('o3'), null); mp37Setzen('o3', 'ovmManuell', 11); const y = mp37Rechnen(findObjekt('o3'), null); return { land: x.lage.land, c: x.status.code, g: x.status.gruende.join('|'), g2: y.grenzeBremse, c2: y.status.code }; });
  ok(r.land === 'BB' && r.c === 'pruefbedarf' && /Vergleichsmiete fehlt/.test(r.g) && eq(r.g2, 12.1) && r.c2 === 'vorlaeufig', 'EFH Falkensee: ohne Vergleichsmiete gesperrt; von Hand 11 € → Grenze 12,10 €');
  // 6) § 558 mit Dreijahresbasis (600 → 660, Vergleichsmiete 720, 15 %)
  r = await p.evaluate(() => { mp37Setzen('o5', 'letzteErh', '2025-06-01'); mp37Setzen('o5', 'mieteVorher', 600); const x = mp37Rechnen(findObjekt('o5'), null); return { erh: x.erh, fe: x.erhFehler, ist: x.istQm, rist: x.rendite.ist }; });
  console.log('   ' + JSON.stringify(r.erh));
  ok(r.erh && eq(r.erh.ziel, 690) && eq(r.erh.mehr, 30) && r.erh.bindet === 'Kappungsgrenze' && r.erh.basis === 600, '§ 558: Ziel 690 €, +30 € (nicht 660 × 1,15)');
  ok(/^\d\d\.\d\d\.20\d\d$/.test(r.erh.wirksam) && eq(r.rist, 660 * 12 / 200000 * 100), 'Frühester Wirkungstermin ' + r.erh.wirksam + ', Ist-Rendite ' + r.rist.toFixed(2) + ' %');
  r = await p.evaluate(() => { mp37Setzen('o5', 'mietart', 'index'); const x = mp37Rechnen(findObjekt('o5'), null); mp37Setzen('o5', 'mietart', ''); return x.erhFehler; });
  ok(/§ 558 ausgeschlossen/.test(r), 'Indexmiete: § 558 gesperrt');
  // 7) Rendite Ist / Potenzial getrennt (800 € · 250.000 € → 3,84 %)
  r = await p.evaluate(() => { const x = mp37Rechnen(findObjekt('o6'), null), t = mp37Texte(x); return { ist: x.rendite.ist, pot: x.rendite.potenzial, t: t.kurz, art: t.art }; });
  ok(eq(r.ist, 3.84) && r.art === 'vermietet' && /Ist-Bruttorendite 3,84 %/.test(r.t) && /kein gegenwärtiger Ertrag/.test(r.t), 'Vermietet: Ist-Rendite 3,84 %, Neuvermietung klar als Szenario');
  ok(!/Seestr|Musterstr/.test(r.t), 'Text ohne Adresse');
  console.log('   ' + r.t);
  // 8) Vergleichsangebote: Prompt
  r = await p.evaluate(() => mp38Prompt('o1'));
  ok(/JARVIS-IMPORT typ=mietvergleiche/.test(r) && /"objekt":"o1"/.test(r) && /PLZ 10365/.test(r) && /AUSGABE ZUM KOPIEREN/.test(r) && /nicht schätzen/.test(r), 'Prompt „Vergleichsangebote“: Format, Objekt-ID, PLZ, Kopierblock');
  ok(!/Musterstr|rodolapa/.test(r), 'Prompt ohne Straße und private Daten');
  // Import: 10 geeignete (10…16), 1 Dublette anderes Portal, 1 nur warm, 1 möbliert, 1 Haus, 1 ungültiger Link
  const werte = [10, 10.5, 11, 11.5, 12, 12, 12.5, 13, 14, 16];
  const block = 'Ergebnis:\n```\nJARVIS-IMPORT typ=mietvergleiche\n' + JSON.stringify({ art: 'meta', objekt: 'o1', stand: '2026-11-14', suchprofil: 'Wohnung, 10365, 55–80 m², 90 Tage' }) + '\n'
    + werte.map((v, i) => angebot(i, v, { flaeche: 100 + i })).join('\n') + '\n'
    + angebot(90, 10, { portal: 'immowelt.de', portal_id: 'W1', url: 'https://example.com/w1', flaeche: 100 }) + '\n'
    + JSON.stringify({ art: 'angebot', url: 'https://example.org/warm', flaeche: 70, warm: 1100, plz: '10365' }) + '\n'
    + angebot(91, 25, { moebliert: true }) + '\n' + angebot(92, 9, { objektart: 'einfamilienhaus' }) + '\n'
    + angebot(93, 11, { url: 'javascript:alert(1)', flaeche: 77 }) + '\n'
    + JSON.stringify({ art: 'ausschluss', url: 'https://example.org/x', grund: 'WG-Zimmer' }) + '\nJARVIS-ENDE\n```';
  r = await p.evaluate(t => mp38ImportText(t, null), block);
  console.log('   ' + r);
  ok(/eingelesen/.test(r) && /Dublette/.test(r), 'Import Vergleichsangebote über die Objekt-ID im Block');
  r = await R(p, 'o1', ['stat.n', 'stat.mittel', 'stat.median', 'stat.min', 'stat.max', 'stat.p25', 'stat.p75', 'stat.stufe', 'markt.median', 'markt.medianText', 'vglStand']);
  console.log(JSON.stringify(r));
  // 11 geeignete: die zehn + Angebot 93 (11 €/m²) → hier bewusst nachrechnen
  r.erw = await p.evaluate(() => db.objekte.find(o => o.id === 'o1').miete37.vergleiche.map(x => ({ qm: x.qm, g: x.geeignet, grund: x.grund, q: (x.quellen || []).length, url: x.url })));
  const gut = r.erw.filter(x => x.g).map(x => x.qm).sort((a, b) => a - b), mittel = gut.reduce((s, x) => s + x, 0) / gut.length;
  ok(r['stat.n'] === gut.length && gut.length === 11 && eq(r['stat.mittel'], mittel, 1e-9) && eq(r['stat.min'], 10) && eq(r['stat.max'], 16) && eq(mittel, 133.5 / 11, 1e-6) && r['stat.stufe'] === 'voll', `Statistik aus ${gut.length} geeigneten Angeboten: Min 10, Max 16, Ø ${mittel.toFixed(2)}`);
  ok(r.erw.some(x => x.q === 2) && r.erw.length === 14, 'Dublette (zweites Portal) zusammengeführt: ein Objekt, zwei Quellen');
  ok(r.erw.some(x => /Warmmiete/.test(x.grund) && x.qm === null) && r.erw.some(x => /möbliert/.test(x.grund)) && r.erw.some(x => /Haus statt Wohnung/.test(x.grund)), 'Nur-Warm, möbliert und Haus nicht gewertet (mit Grund)');
  ok(r.erw.every(x => !/^javascript/.test(x.url || '')), 'Unsicherer Link verworfen');
  ok(eq(r['markt.median'], r['stat.median']) && /Vergleichsangeboten/.test(r['markt.medianText']), 'Ab 5 Angeboten ist der Stichproben-Median der Marktwert');
  // Schalter, Löschen, von Hand
  r = await p.evaluate(() => { const o = findObjekt('o1'), id = o.miete37.vergleiche.find(x => Math.abs(x.qm - 16) < 1e-9).id; mp38VglSchalter('o1', id); const a = mp37Rechnen(findObjekt('o1'), null).stat; mp38VglSchalter('o1', id); const b2 = mp37Rechnen(findObjekt('o1'), null).stat; const m = findObjekt('o1').miete37.vergleiche.find(x => /möbliert/.test(x.grund)).id; mp38VglSchalter('o1', m); const c = mp37Rechnen(findObjekt('o1'), null).stat; mp38VglWeg('o1', m); return { a: [a.n, a.max], b: [b2.n, b2.max], c: [c.n, c.max], rest: findObjekt('o1').miete37.vergleiche.length }; });
  ok(r.a[0] === 10 && eq(r.a[1], 14) && r.b[0] === 11 && eq(r.b[1], 16) && r.c[0] === 12 && eq(r.c[1], 25) && r.rest === 13, 'Angebot ausschließen / wieder aufnehmen / Ungeeignetes bewusst aufnehmen / löschen');
  // Karte in der Marktanalyse
  await p.evaluate(() => { const a = ma24Anlegen('o1', 'sale', true); MA24.sel = a.id; MA24.schritt = 'ergebnis'; wechsleAnsicht('marktanalyse24'); }); await p.waitForTimeout(700);
  r = await p.evaluate(() => { const k = document.querySelector('.mp37'); return k ? { t: k.innerText, grp: k.querySelectorAll('.mp38-grp').length, st: (k.querySelector('.mp38-status') || {}).textContent, vgl: k.querySelectorAll('.mp38-vgl tr').length } : null; });
  ok(r && r.grp === 3 && /Niedrigstes Angebot/.test(r.t) && /Höchstes Angebot/.test(r.t) && /Durchschnitt/.test(r.t) && /Überwiegende Angebote/.test(r.t) && /Höchste zulässige Miete/.test(r.t), 'Karte: drei Blöcke (Vergleichsangebote · Region · Recht)');
  ok(r.st === 'VORLÄUFIG' && r.vgl === 14, 'Karte: Status-Marke und Angebotstabelle (' + r.vgl + ' Zeilen)');
  await p.click('.mp37 button:has-text("Text fürs Inserat")'); await p.waitForTimeout(300);
  ok(await p.evaluate(() => /Bei Neuvermietung wird auf Grundlage/.test(window.__kopie || '')), 'Knopf „Text fürs Inserat“ kopiert den Text');
  // Freigabe
  await p.click('.mp37 button:has-text("Als geprüft markieren")'); await p.waitForTimeout(300);
  ok(await p.evaluate(() => document.querySelectorAll('.mp38-pruef li').length >= 8), 'Prüfdialog mit Prüfliste');
  await p.click('button:has-text("Geprüft – freigeben")'); await p.waitForTimeout(500);
  r = await p.evaluate(() => ({ c: mp37Rechnen(findObjekt('o1'), null).status.code, m: (document.querySelector('.mp38-status') || {}).textContent }));
  ok(r.c === 'geprueft' && r.m === 'GEPRÜFT', 'Freigabe → Status GEPRÜFT');
  await p.selectOption('.mp37 .mp37-ein select >> nth=1', '3'); await p.waitForTimeout(400);
  ok(await p.evaluate(() => (document.querySelector('.mp38-status') || {}).textContent === 'VERALTET'), 'Ausstattung geändert → Freigabe VERALTET');
  await p.evaluate(() => mp37Setzen('o1', 'saldo', 0));
  ok(await p.evaluate(() => mp37Rechnen(findObjekt('o1'), null).status.code === 'geprueft'), 'Zurückgestellt → wieder GEPRÜFT');
  // Bericht
  r = await p.evaluate(() => ma24BerichtHtmlFuer(ma24A()));
  ok(/<h2>Mietpotenzial und Ertrag<\/h2>/.test(r) && /Niedrigstes Angebot/.test(r) && /Überwiegende Angebote/.test(r) && /<thead>/.test(r) && !/Musterstr/.test(r), 'Eigentümerbericht: Kapitel „Mietpotenzial und Ertrag“ mit Angebotsliste, ohne Adresse');
  ok(await p.evaluate(() => { mp37BerichtSetzen(false); const x = !/Mietpotenzial und Ertrag/.test(ma24BerichtHtmlFuer(ma24A())); mp37BerichtSetzen(true); return x; }), 'Kapitel im Bericht abschaltbar');
  // Dialoge
  await p.evaluate(() => mp38VglDialog('o1')); await p.waitForTimeout(250);
  ok(await p.evaluate(() => !!document.getElementById('mp38Text')), 'Dialog „Vergleichsangebote suchen“');
  await p.evaluate(() => mp38VglNeu('o1')); await p.waitForTimeout(250);
  await p.fill('#mp38f', '70'); await p.fill('#mp38k', '910'); await p.fill('#mp38o', '10365 Lichtenberg'); await p.click('button:has-text("Speichern")'); await p.waitForTimeout(400);
  ok(await p.evaluate(() => findObjekt('o1').miete37.vergleiche.some(x => x.von === 'hand' && Math.abs(x.qm - 13) < 0.001)), 'Angebot von Hand ergänzt (13,00 €/m²)');
  // Objekt-Fenster
  r = await p.evaluate(() => { wechsleAnsicht('objekte'); mp37FuerObjekt('o6'); return !!document.querySelector('#mp37Modal .mp37'); });
  ok(r, 'Mietpotenzial aus dem Objekt als Fenster');
  await p.evaluate(() => mp38VglDialog('o6')); await p.waitForTimeout(200);
  await p.fill('#mp38Text', block.replace('"objekt":"o1"', '"objekt":"gibtsnicht"')); await p.click('button:has-text("Einlesen")'); await p.waitForTimeout(600);
  ok(await p.evaluate(() => !!document.querySelector('#mp37Modal .mp37') && findObjekt('o6').miete37.vergleiche.length > 5), 'Einlesen im Objekt-Fenster (Objekt aus dem Dialog), danach zurück im Fenster');
  await p.evaluate(() => schliesseModal());
  // 9) Auffrischungs-Prompt und Import
  r = await p.evaluate(() => mp37Prompt('Bernau'));
  ok(/JARVIS-IMPORT typ=mieten/.test(r) && /mittlere_80_prozent/.test(r) && /"entwurf"|entwurf/.test(r) && /"art":"vpi"/.test(r) && /fehlgeschlagen/.test(r) && /Bezugsjahr/.test(r) && /AUSGABE ZUM KOPIEREN/.test(r) && /Bernau/.test(r), 'Auffrischungs-Prompt: Spannenart, Rechtsstatus, VPI, Abruf-Fehler, Kopierblock');
  const imp = 'JARVIS-IMPORT typ=mieten\n{"art":"meta","stand":"2026-11-14","zusammenfassung":"Test."}\n'
    + '{"art":"gebiet","gebiet":"Lichtenberg","median":16.9,"durchschnitt":17.4,"spanne_von":9.1,"spanne_bis":24.5,"spannenart":"mittlere_80_prozent","bezugszeitraum":"Q3 2026","quelle":"Test-Quelle","url":"javascript:alert(1)","abruf":"ok"}\n'
    + '{"art":"gebiet","gebiet":"Falkensee","median":12.4,"bezugszeitraum":"Q3 2026","quelle":"Test","abruf":"ok"}\n'
    + '{"art":"gebiet","gebiet":"Spandau","median":300,"abruf":"ok"}\n{"art":"gebiet","gebiet":"Pankow","median":null,"abruf":"fehlgeschlagen"}\n'
    + '{"art":"recht","thema":"Mietrechtspaket","stand":"Zweite Lesung <b>","status":"entwurf","geaendert":true,"url":"https://example.org/r","abruf":"ok"}\n'
    + '{"art":"recht","thema":"Kappungsgrenze Berlin","stand":"verlängert","status":"geltend","geaendert":true,"url":"https://example.org/k","abruf":"ok"}\n'
    + '{"art":"recht","thema":"Mietspiegel","stand":"?","status":"geltend","geaendert":false,"abruf":"fehlgeschlagen"}\n'
    + '{"art":"vpi","monat":"2026-10","wert":127.1,"basis":"2020=100","endgueltig":true}\n{"art":"vpi","monat":"2026-11","wert":127.4,"basis":"2020=100","endgueltig":false}\n{"art":"vpi","monat":"2026-09","wert":99,"basis":"2020=100","endgueltig":true}\n'
    + '{"art":"fehler","quelle":"gesetze-im-internet.de","grund":"Abruf fehlgeschlagen"}\nJARVIS-ENDE';
  r = await p.evaluate(t => mp37ImportText(t), imp);
  console.log('   ' + r);
  ok(/2 Gebiete/.test(r) && /3 Rechtspunkte/.test(r) && /Entwurf/.test(r) && /VPI/.test(r) && /fehlgeschlagen/.test(r) && /übersprungen/.test(r), 'Import: Gebiete, Recht, Entwurf erkannt, VPI, Fehlabrufe, Ungültiges übersprungen');
  r = await p.evaluate(() => { const m = db.mieten37; return { li: m.gebiete.be_li, neu: m.rechtNeu, vpi: m.vpi, kern: MR.vpi({ y: 2026, m: 10 }), sep: MR.vpi({ y: 2026, m: 9 }), recht: m.recht }; });
  ok(r.li.median === 16.9 && r.li.durchschnitt === 17.4 && r.li.spannenart === 'mittlere_80_prozent' && r.li.url === '', 'Gebiet mit Durchschnitt und Spannenart gespeichert, unsicherer Link verworfen');
  ok(r.neu && r.neu.punkte.length === 1 && /Kappungsgrenze/.test(r.neu.punkte[0]), 'Nur geltendes Recht meldet eine Rechtsänderung – der Entwurf nicht');
  ok(r.vpi['2026-10'] === 127.1 && !r.vpi['2026-11'] && !r.vpi['2026-9'] && r.kern && r.kern[1] === 127.1 && r.sep[1] === 126.6, 'VPI 10/2026 übernommen (endgültig), vorläufiger Wert und eingebauter Monat nicht');
  ok(!/[<>]/.test(r.recht[0].stand) && r.recht[2].abruf === 'fehlgeschlagen' && r.recht[2].geaendert === false, 'Rechtstext ohne HTML; fehlgeschlagener Abruf gilt nicht als „unverändert geprüft“');
  r = await p.evaluate(() => { const x = mp37Rechnen(findObjekt('o7'), null); const k = mp37KarteHtml(findObjekt('o7'), null, false); return { med: x.region.median, art: x.region.spanneArt, k: /mittlere 80 % der Angebote/.test(k) && /Test-Quelle/.test(k), mv: mv25Jarvis('be_li') }; });
  ok(r.med === 16.9 && r.art === 'mittlere 80 % der Angebote' && r.k && r.mv.m === 16.9, 'Aufgefrischte Werte in Karte und Mietvergleich (mit Spannenart)');
  r = await p.evaluate(() => tbHinweise().map(h => h.k));
  ok(!r.includes('mp37') && r.includes('mp37r'), 'Glocke: aufgefrischt, Rechtsänderung gemeldet');
  ok(await p.evaluate(() => /Entwurf, gilt noch nicht/.test(mp37RechtHtml()) && /Abruf fehlgeschlagen/.test(mp37RechtHtml())), 'Rechtslage zeigt „Entwurf“ und „Abruf fehlgeschlagen“');
  // 10) Jarvis
  await p.evaluate(() => wechsleAnsicht('jarvis')); await p.waitForTimeout(1500);
  const fr = await (await p.$('#jvFrame')).contentFrame();
  r = await fr.evaluate(() => { try{ return { plan: PLAN_STANDARD.mieten, prompt: promptErzeugen('mieten', ''), vpi: MR.vpi({ y: 2026, m: 10 }) }; }catch(e){ return { err: e.message }; } });
  ok(r.plan && r.plan.alle === 2 && /mittlere_80_prozent/.test(r.prompt || '') && r.vpi && r.vpi[1] === 127.1, 'Jarvis: Plan alle 2 Wochen, neuer Prompt, VPI im Mietrechner angekommen');
  r = await fr.evaluate(t => einlesen(t), block.replace('"objekt":"o1"', '"objekt":"o3"'));
  ok(/eingelesen/.test(r) && await p.evaluate(() => findObjekt('o3').miete37.vergleiche.length > 5), 'Jarvis-Import „typ=mietvergleiche“ landet beim Objekt: ' + r.slice(0, 60));
  r = await p.evaluate(() => mp37Rechnen(findObjekt('o3'), null).vgl.filter(x => x.geeignet).length);
  ok(r === 1, 'Beim Haus zählt nur das Haus-Angebot (Wohnungen ausgeschlossen): ' + r);
  r = await fr.evaluate(t => einlesen(t), imp.replace('16.9', '17.3'));
  ok(/Gebiete aktualisiert/.test(r) && await p.evaluate(() => db.mieten37.gebiete.be_li.median === 17.3), 'Jarvis-Import „typ=mieten“ weiterhin ok');
  ok(p.fe.length === 0, 'PC: keine Fehler ' + p.fe.join(' | '));
  await p.close();
  // 11) Handy
  p = await seite(b, 'handy', 412, 915);
  await p.evaluate(t => { mp38ImportText(t, null); const a = ma24Anlegen('o1', 'rent', true); MA24.sel = a.id; MA24.schritt = 'ergebnis'; wechsleAnsicht('marktanalyse24'); }, block); await p.waitForTimeout(700);
  r = await p.evaluate(() => { const k = document.querySelector('.mp37'); if(!k) return null; return { w: k.getBoundingClientRect().width, sw: k.scrollWidth, vw: innerWidth }; });
  ok(r && r.w <= r.vw && r.sw <= r.w + 2, 'Handy: Karte passt in die Breite ' + JSON.stringify(r));
  ok(p.fe.length === 0, 'Handy: keine Fehler ' + p.fe.join(' | '));
  await b.close(); console.log('FEHLER', f);
})();
