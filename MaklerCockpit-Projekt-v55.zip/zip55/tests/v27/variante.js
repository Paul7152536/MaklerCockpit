// BETTERHOMES-ähnliches Exposé (Haus) mit Abweichungen: zweizeiliger Titel, umbrechende Werte, Käuferprovision als Tabellenzeile, Objektbeschreibung auf Seite 3
const { chromium } = require('playwright'); const fs = require('fs');
const b64 = f => 'data:' + (f.endsWith('png') ? 'image/png' : 'image/jpeg') + ';base64,' + fs.readFileSync('/tmp/v27test/gen/' + f).toString('base64');
const S = 'position:absolute;';
const seite1 = `<div class="s"><img src="${b64('logo.png')}" style="${S}right:40px;top:30px;width:200px">
<div style="${S}left:60px;top:110px;width:680px;font-size:26px;font-weight:800;color:#e6007e;line-height:1.15">CHARMANTES EINFAMILIENHAUS MIT GROSSEM GARTEN AM STADTRAND</div>
<img src="${b64('haus.jpg')}" style="${S}left:60px;top:200px;width:680px;height:453px;object-fit:cover">
<div style="${S}left:500px;top:520px;width:240px;background:#e6007e;color:#fff;font-size:10px;padding:8px">Ihr Immobilienmakler<br><b>Herr Paul Görner</b><br>+49 1515 465 76 73<br>paul.goerner@example.org</div>
<div style="${S}left:60px;top:690px;width:320px;font-size:10px;text-align:justify;line-height:1.35">Das freistehende Einfamilienhaus wurde 2004 in massiver Bauweise errichtet und seitdem fortlaufend gepflegt. Im Erdgeschoss befinden sich ein großzügiger Wohn- und Essbereich mit Kamin sowie eine moderne Küche. Im Obergeschoss liegen drei Schlafzimmer und ein Tageslichtbad. Der sonnige Garten ist liebevoll angelegt.</div>
<div style="${S}left:420px;top:690px;width:320px;font-size:10px;line-height:1.35"><b>Dieses BETTERHOMES-Angebot zeichnet sich durch folgende Vorteile aus:</b><br><br>- ruhige Lage in einer Anliegerstraße<br>- Kamin im Wohnzimmer<br>- Doppelgarage mit elektrischem Tor und zusätzlichem<br>Stellplatz vor dem Haus<br>- Fußbodenheizung im gesamten Erdgeschoss<br>- S-Bahn in 10 Minuten zu Fuß</div>
<div style="${S}left:60px;bottom:30px;font-size:8px">Alle Angaben beruhen auf Aussagen des Eigentümers</div></div>`;
const kv = (l, w) => `<tr><td style="width:150px;vertical-align:top">${l}</td><td>${w}</td></tr>`;
const seite2 = `<div class="s"><div style="${S}left:60px;top:40px;font-size:11px">Informationen zum Objekt:<br><b style="font-size:14px">CHARMANTES EINFAMILIENHAUS MIT GROSSEM GARTEN AM STADTRAND</b></div>
<img src="${b64('innen.jpg')}" style="${S}left:60px;top:120px;width:300px">
<div style="${S}left:420px;top:120px;width:330px;font-size:10px;line-height:1.3"><b style="font-size:13px">Objektinformationen</b><br>Einfamilienhaus<br>Am Gutspark 7a<br>14612 Falkensee<br><br>
<table style="font-size:10px;border-collapse:collapse">${kv('Referenz-Nr.', 'bh77x21c')}${kv('Kaufpreis', '589.000 EUR')}${kv('Käuferprovision', '3,57 % inkl. MwSt.')}<tr><td>&nbsp;</td></tr>${kv('Endenergiebedarf', '62,5 kWh/m²a (B)')}${kv('Energieausweistyp', 'Bedarfsausweis')}${kv('Zimmer', '5')}${kv('Baujahr', '2004')}${kv('Wohnfläche', '140 m²')}${kv('Grundstücksfläche', '650 m²')}${kv('Verfügbar ab', 'nach Vereinbarung, frühestens zum<br>01.03.2027')}</table><br>
Zustand:<br>gepflegt<br><br>Heizsystem:<br>Fußbodenheizung; Gas-Brennwert<br><br>Ausstattung:<br>Kamin, Garten, Garage, Terrasse, Einbauküche, Keller, Gäste-WC,<br>Rollläden<br></div>
<div style="${S}left:60px;bottom:30px;font-size:8px">Alle Angaben beruhen auf Aussagen des Eigentümers</div></div>`;
const seite3 = `<div class="s"><div style="${S}left:60px;top:60px;width:330px;font-size:10px;line-height:1.35"><b style="font-size:13px">Lagebeschreibung</b><br>Falkensee liegt direkt an der westlichen Berliner Stadtgrenze. Kitas, Schulen und Einkaufsmöglichkeiten sind fußläufig erreichbar, die S-Bahn bringt Sie in rund 30 Minuten nach Berlin-Mitte.</div>
<div style="${S}left:420px;top:60px;width:330px;font-size:10px">Ihr Ansprechpartner<br>BETTERHOMES Deutschland GmbH<br>Musterweg 1, 70173 Stuttgart</div></div>`;
(async () => {
  const br = await chromium.launch(); const p = await br.newPage();
  await p.setContent(`<html><head><style>body{margin:0;font-family:Arial} .s{position:relative;width:794px;height:1123px;page-break-after:always;overflow:hidden}</style></head><body>${seite1}${seite2}${seite3}</body></html>`);
  await p.waitForTimeout(300);
  await p.pdf({ path: '/tmp/v27test/ex/variante-haus.pdf', width: '794px', height: '1123px', printBackground: true });
  await br.close(); console.log('ok');
})();
