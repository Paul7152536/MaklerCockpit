// Rohausgabe von ex27Lesen für eine PDF
const { chromium } = require('playwright');
const datei = process.argv[2];
(async () => {
  const b = await chromium.launch();
  const p = await b.newPage({ viewport: { width: 1400, height: 900 } });
  const fe = []; p.on('pageerror', e => fe.push(e.message));
  await p.addInitScript(() => { window.pc = { laden: () => ({ objekte: [], kontakte: [], termine: [], aufgaben: [], notizen: [], gesuche: [], marktanalysen: [], mentorFragen: [], meta: { v9neustart: { quittiert: true } } }), speichern: () => ({ ok: true }), ordner(){}, sicherungSchreiben: () => ({ ok: true }), sicherungLesen: () => null, zwischenablage: async () => '', abruf: async () => ({ ok: false }) }; });
  await p.goto('file:///tmp/pc/app/index.html'); await p.waitForTimeout(1500);
  await p.evaluate(() => { const i = document.createElement('input'); i.type = 'file'; i.id = 'roh'; document.body.appendChild(i); });
  await p.setInputFiles('#roh', datei);
  const r = await p.evaluate(async () => { const ex = await ex27Lesen(document.getElementById('roh').files[0]); if(ex.bild){ window.__b = ex.bild.url; } if(ex.bild) ex.bild = { breite: ex.bild.breite, hoehe: ex.bild.hoehe, laenge: ex.bild.url.length, anfang: ex.bild.url.slice(0, 30) }; return ex; });
  console.log(JSON.stringify(r)); if(process.argv[3]){ const u = await p.evaluate(() => window.__b); if(u) require('fs').writeFileSync(process.argv[3], Buffer.from(u.split(',')[1], 'base64')); } console.log('Fehler:', fe);
  await b.close();
})();
