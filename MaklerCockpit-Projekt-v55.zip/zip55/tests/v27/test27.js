// v27: Exposé-Import nach Aufbau (Titel, Vorteile, Objektinformationen, Titelbild)
const { chromium } = require('playwright');
let f = 0; const ok = (b, t) => { console.log((b ? 'ok   ' : 'FEHL ') + t); if(!b) f++; };
(async () => {
  const b = await chromium.launch();
  const p = await b.newPage({ viewport: { width: 1500, height: 950 } });
  const fe = []; p.on('pageerror', e => fe.push(e.message)); p.on('dialog', d => d.accept());
  await p.addInitScript(() => {
    const start = { objekte: [{ id: 'l1', createdAt: 1, akqTitel: 'Wohnung Beuthstraße (Kleinanzeigen)', adresse: 'Beuthstr. 29', ort: '13156 Berlin', objektart: 'Wohnung', status: 'neu', verlauf: [], quelle: 'Kleinanzeigen', verkaeuferName: 'Frau Schulz', verkaeuferTelefon: '01701234567' }],
      kontakte: [], termine: [], aufgaben: [], notizen: [], gesuche: [], marktanalysen: [], mentorFragen: [], meta: { v9neustart: { quittiert: true } } };
    window.pc = { laden: () => JSON.parse(sessionStorage.getItem('d') || 'null') || start, speichern: t => { sessionStorage.setItem('d', t); return { ok: true }; }, ordner(){}, sicherungSchreiben: () => ({ ok: true }), sicherungLesen: () => null, zwischenablage: async () => '', abruf: async () => ({ ok: false }) };
  });
  await p.goto('file:///tmp/pc/app/index.html'); await p.waitForTimeout(1800);
  // 1) Beispiel-Exposé ins Feld „betreut“ – gleiche Adresse wie ein Lead → kein Doppel, Lead wird zum Auftrag
  await p.evaluate(() => { wechsleAnsicht('objekte'); ob26Wechseln('betreut'); });
  await p.setInputFiles('#exposeInput2', '/tmp/v27test/ex/beispiel.pdf');
  await p.waitForFunction(() => db.objekte.some(o => o.expose), null, { timeout: 60000 }).catch(() => {});
  await p.waitForTimeout(600);
  let o = await p.evaluate(() => { const o = db.objekte.find(x => x.expose); return o ? JSON.parse(JSON.stringify(o)) : null; });
  ok(!!o, 'Exposé eingelesen');
  const anzahl = await p.evaluate(() => db.objekte.length);
  ok(anzahl === 1 && o.id === 'l1', 'Gleiche Adresse wie vorhandener Lead (Beuthstr. 29 / 13156) → aktualisiert, nicht doppelt angelegt');
  ok(o.bereich === 'betreut' && o.status === 'auftrag', 'Eigenes Exposé → Status „Auftrag erhalten“, Feld „betreut“');
  ok(o.akqTitel === 'RUHIG WOHNEN MIT TERRASSE INS GRÜNE', 'Titel von Seite 1 (fett oben): ' + o.akqTitel);
  ok(o.adresse === 'Beuthstraße 29' && o.ort === '13156 Niederschönhausen (Pankow)' && o.objektart === 'Wohnung' && o.objekttyp === 'Etagen-Wohnung', 'Adresse/Ort/Objektart: ' + [o.adresse, o.ort, o.objektart, o.objekttyp].join(' | '));
  ok(o.kaufpreis === 190000 && o.wohnflaeche === 43 && o.zimmer === 1 && o.baujahr === 1998 && o.etage === '1' && o.hausgeld === 250 && o.referenz === '046a7aa779', 'Zahlen: 190.000 € · 43 m² · 1 Zi. · Bj. 1998 · Etage 1 · Hausgeld 250 · Ref. 046a7aa779');
  ok(/2,98 %/.test(o.provisionText || ''), 'Provision: ' + o.provisionText);
  ok((o.vorteile || []).length === 9 && o.vorteile[5] === 'KFZ-Stellplatz zzgl. 10.000EUR (Totaler Verkaufspreis: 200.000EUR)' && o.vorteile[7] === 'sehr schöne Wohngegend, viele Ausflugsmöglichkeiten ins Grüne', '9 Vorteile („-“) inkl. umbrochener Zeilen');
  const fl = Object.fromEntries(o.expose.felder);
  ok(o.expose.felder.length === 17 && fl['Heizsystem'] === 'Zentralheizung; Gas' && fl['Ausstattung'] === 'Balkon, Parkplatz, Keller, Terrasse, Einbauküche, Gartensitzplatz' && fl['Endenergieverbrauch'] === '87 kWh/m²a (C)' && fl['Geschäfte'] === 'Supermarkt (300 m), Restaurants und Coffee Shops (300 m)', 'Objektinformationen: alle 17 Angaben (Heizung, Ausstattung, Energie, Lage …)');
  ok(/^Diese sehr helle, ruhige 1-Zimmer-Wohnung/.test(o.expose.beschreibung) && /10\.000 Euro erhältlich\.$/.test(o.expose.beschreibung), 'Beschreibung von Seite 1 vollständig');
  ok(/^data:image\/jpeg;base64,/.test(o.titelbild || '') && o.titelbild.length > 100000 && o.titelbild.length < 400000, 'Titelbild = erstes Foto (' + Math.round((o.titelbild || '').length / 1024) + ' KB)');
  const roh = JSON.stringify(o);
  ok(!/1515|465 76 73|Stuttgart|betterhomes\.de/i.test(roh.replace(o.titelbild, '')), 'Makler-Telefon/-Mail und BETTERHOMES-Adresse nicht im Objekt');
  ok(o.verkaeuferName === 'Frau Schulz' && o.verkaeuferTelefon === '01701234567', 'Eigentümer vom Lead bleibt erhalten');
  const an = await p.evaluate(() => { const o = db.objekte.find(x => x.expose); return ['wohnflaeche', 'zimmer', 'baujahr', 'kaufpreis', 'hausgeld', 'zustand', 'energie'].map(k => { const a = an24Aktiv(o, k); return k + '=' + (a ? a.wert + '/' + a.herkunft : '–'); }).join(' '); });
  ok(/wohnflaeche=43\/eigentuemer/.test(an) && /zustand=gepflegt/.test(an) && /energie=Zentralheizung; Gas · Endenergieverbrauch 87/.test(an), 'Objektakte-Angaben mit Herkunft: ' + an);
  let r = await p.evaluate(() => ({ t: document.getElementById('modalInner').innerText, img: !!document.querySelector('#modalInner .ex27-z img') }));
  ok(/1 Exposé eingelesen/.test(r.t) && /aktualisiert/.test(r.t) && r.img && /9 Vorteile · 17 Angaben/.test(r.t), 'Ergebnis-Dialog mit Titelbild und Zusammenfassung');
  await p.screenshot({ path: '/tmp/v27test/1_ergebnis.png' });
  await p.evaluate(() => schliesseModal()); await p.waitForTimeout(300);
  r = await p.evaluate(() => { const tr = document.querySelector('#objTabelle tbody tr.row'); return { mini: !!tr.querySelector('img.ex27-mini'), text: tr.children[1].innerText }; });
  ok(r.mini && /RUHIG WOHNEN/.test(r.text) && /Beuthstraße 29 · Etagen-Wohnung · 13156/.test(r.text) && (r.text.match(/RUHIG WOHNEN/g) || []).length === 1, 'Objekte-Liste: Mini-Titelbild + Titel + Adresse');
  await p.screenshot({ path: '/tmp/v27test/2_liste.png' });
  // 2) Objektakte
  await p.evaluate(() => ob24Oeffnen(db.objekte.find(x => x.expose).id)); await p.waitForTimeout(800);
  r = await p.evaluate(() => { const k = document.querySelector('.ex27-karte'); const img = k && k.querySelector('img.ex27-bild'); return { da: !!k, erst: k && k.parentElement.firstElementChild === k, breit: img ? img.naturalWidth : 0, li: k ? k.querySelectorAll('li').length : 0, tr: k ? k.querySelectorAll('tr').length : 0, kopf: !!document.querySelector('.aq-kopf .ic img'), h1: document.querySelector('.aq-kopf h1').innerText }; });
  ok(r.da && r.erst && r.breit === 1598 && r.li === 9 && r.tr >= 18 && r.kopf && /RUHIG WOHNEN/.test(r.h1), 'Objektakte: Exposé-Karte ganz oben mit Titelbild (1598 px), 9 Vorteilen, Objektinformationen; Bild auch im Kopf');
  await p.screenshot({ path: '/tmp/v27test/3_akte.png', fullPage: false });
  // 3) Gleiches Exposé nochmal → kein Doppel
  await p.evaluate(() => { wechsleAnsicht('objekte'); ob26Wechseln('betreut'); });
  await p.setInputFiles('#exposeInput2', '/tmp/v27test/ex/beispiel.pdf');
  await p.waitForFunction(() => /aktualisiert/.test(document.getElementById('modalInner').innerText), null, { timeout: 60000 }).catch(() => {});
  r = await p.evaluate(() => ({ n: db.objekte.length, notiz: (findObjekt('l1').notizen.match(/📄 Aus Exposé/g) || []).length }));
  ok(r.n === 1 && r.notiz === 1, 'Erneut eingelesen: weiterhin 1 Objekt, Hinweis-Notiz nicht doppelt');
  await p.evaluate(() => schliesseModal());
  // 4) Variante (Haus) ins Feld Akquise
  await p.evaluate(() => ob26Wechseln('akquise'));
  await p.setInputFiles('#exposeInput2', '/tmp/v27test/ex/variante-haus.pdf');
  await p.waitForFunction(() => db.objekte.length === 2, null, { timeout: 60000 }).catch(() => {});
  await p.waitForTimeout(500);
  o = await p.evaluate(() => JSON.parse(JSON.stringify(db.objekte.find(x => x.referenz === 'bh77x21c') || null)));
  ok(o && o.bereich === 'akquise' && o.status === 'neu' && o.objektart === 'EFH' && o.grundstueck === 650 && o.wohnflaeche === 140 && o.kaufpreis === 589000, 'Haus-Exposé → Akquise, EFH, 140 m², 650 m² Grundstück, 589.000 €');
  ok(o && o.akqTitel === 'CHARMANTES EINFAMILIENHAUS MIT GROSSEM GARTEN AM STADTRAND' && o.vorteile.length === 5 && /Doppelgarage mit elektrischem Tor und zusätzlichem Stellplatz vor dem Haus/.test(o.vorteile[2]), 'Zweizeiliger Titel + umbrochener Vorteil');
  ok(o && Object.fromEntries(o.expose.felder)['Verfügbar ab'] === 'nach Vereinbarung, frühestens zum 01.03.2027' && /3,57/.test(o.provisionText) && o.expose.abschnitte.some(a => a.titel === 'Lagebeschreibung'), 'Umbrochener Tabellenwert, Käuferprovision, Lagebeschreibung von Seite 3');
  ok(o && o.titelbild && o.titelbild.length > 20000, 'Titelbild = Hausfoto (nicht Logo, nicht Innenfoto)');
  await p.evaluate(() => { schliesseModal(); wechsleAnsicht('akquise'); AQ2.status = 'alle'; AQ2.sel = db.objekte.find(x => x.referenz === 'bh77x21c').id; renderMain(); }); await p.waitForTimeout(700);
  r = await p.evaluate(() => { const o = db.objekte.find(x => x.referenz === 'bh77x21c'); return { f: aq2Fotos(o).length, img: Array.from(document.querySelectorAll('#main img')).some(i => i.src.startsWith('data:image/jpeg')) }; });
  ok(r.f === 1 && r.img, 'Akquise-Ansicht zeigt das Titelbild');
  await p.screenshot({ path: '/tmp/v27test/4_akquise.png' });
  // 5) Titel im Objekt-Dialog änderbar
  await p.evaluate(() => { oeffneObjektModal('l1'); }); await p.waitForTimeout(200);
  r = await p.evaluate(() => document.getElementById('m_titel27') && document.getElementById('m_titel27').value);
  ok(r === 'RUHIG WOHNEN MIT TERRASSE INS GRÜNE', 'Objekt bearbeiten: Feld „Titel“ mit Exposé-Titel');
  await p.fill('#m_titel27', 'Ruhig wohnen mit Terrasse'); await p.evaluate(() => speichereObjekt('l1')); await p.waitForTimeout(500);
  r = await p.evaluate(() => ({ t: findObjekt('l1').akqTitel, k: findObjekt('l1').kaufpreis, b: !!findObjekt('l1').titelbild }));
  ok(r.t === 'Ruhig wohnen mit Terrasse' && r.k === 190000 && r.b, 'Titel geändert, Preis und Bild bleiben');
  // 6) Titelbild entfernen
  await p.evaluate(() => { ob24Oeffnen('l1'); }); await p.waitForTimeout(300);
  await p.evaluate(() => ex27BildWeg('l1')); r = await p.evaluate(() => ({ b: findObjekt('l1').titelbild, k: !!document.querySelector('.ex27-karte'), img: !!document.querySelector('.ex27-karte img') }));
  ok(r.b === undefined && r.k && !r.img, 'Titelbild entfernen: Bild weg, Exposé-Daten bleiben');
  // 7) Handy-Breite
  await p.evaluate(() => { ob24Oeffnen(db.objekte.find(x => x.referenz === 'bh77x21c').id); });
  await p.setViewportSize({ width: 390, height: 844 }); await p.waitForTimeout(500);
  r = await p.evaluate(() => ({ sw: document.documentElement.scrollWidth, k: document.querySelector('.ex27-karte').getBoundingClientRect().width }));
  ok(r.sw <= 392 && r.k <= 390, 'Handy-Breite: Exposé-Karte passt (' + r.sw + ' px)');
  await p.screenshot({ path: '/tmp/v27test/5_handy.png' });
  ok(fe.length === 0, 'Keine Fehler ' + JSON.stringify(fe));
  console.log('FEHLER', f); await b.close();
})();
