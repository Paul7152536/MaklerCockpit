// Kern-Tests Marktanalyse (Node, ohne Oberfläche)
const M = require(require('path').join(__dirname, '../../quellen/markt24_kern.js'));
let fehler = 0; const ok = (b, t) => { if(!b){ fehler++; console.log('FEHLER:', t); } else console.log('ok  ', t); };

function vergleich(i, o){
  return Object.assign({
    id: 'c' + i, title: 'ETW ' + i + ' Zimmer Musterkiez', source_url: `https://www.beispielportal.de/expose/${1000 + i}`, additional_source_urls: [], source_name: 'Beispielportal',
    accessed_at: '2026-11-10T09:00:00+01:00', published_at: '2026-10-20', verification_status: 'verified', price_type: 'sale_asking', currency: 'EUR',
    price_eur: 300000 + i * 10000, monthly_net_rent_eur: null, warm_rent_eur: null, parking_eur: null, area_sqm: 70 + i, area_type: 'living', plot_sqm: null, rooms: 3, year_built: 1995,
    location: { text: 'Berlin-Lichtenberg', district: 'Lichtenberg', postal_code: '10365', resolution: 'district' }, condition: 'well_kept', occupancy: 'vacant',
    energy: null, features: ['Balkon'], evidence: [{ fields: ['price_eur', 'area_sqm'], excerpt: `Kaufpreis ${300000 + i * 10000} € · Wohnfläche ca. ${70 + i} m²`, url: `https://www.beispielportal.de/expose/${1000 + i}` }],
    missing_fields: [], comparability: 'good', comparability_reasons: [{ criterion: 'micro_location', assessment: 'good', reason: 'gleicher Ortsteil' }],
    duplicate_group: null, included: true, exclusion_reason: null
  }, o || {});
}
function antwort(n, o){
  return Object.assign({
    schema_version: M.MA24_VERSION, subject_id: 'obj1', analysis_type: 'sale', valuation_date: '2026-11-11', research_timestamp: '2026-11-11T10:00:00+01:00', research_status: 'completed',
    search_strategy: { areas: ['Lichtenberg'], criteria: ['ETW 60–90 m²'], expansions: [], restrictions: [], sources_searched: ['Beispielportal'] },
    comparables: Array.from({ length: n }, (_, i) => vergleich(i + 1)), unverified_candidates: [], subject_conflicts: [],
    data_quality: { level: 'medium', reasons: ['Testdaten'] }, assumptions: [], limitations: [], summary: 'Test', strategy_notes: []
  }, o || {});
}
const K = { subjectId: 'obj1', analyseTyp: 'sale' };

// Prompt
const prompt = M.ma24Prompt({ stichtag: '2026-11-11', typ: 'sale', subjectId: 'obj1', objekt: { objektart: 'Wohnung', ort: '10365 Berlin', wohnflaeche: { wert: 75, herkunft: 'Eigentümerangabe' }, baujahr: null }, suchgebiet: 'Lichtenberg', filter: 'ETW 60–90 m²', anzahl: 12, quellen: [] });
ok(/Stichtag: 2026-11-11/.test(prompt) && /subject_id = "obj1"/.test(prompt) && /Höchstzahl eindeutiger Vergleiche: 12/.test(prompt) && /"baujahr": null/.test(prompt), 'Prompt enthält Stichtag, ID, Anzahl, Objektdaten mit null');
ok(prompt.includes(JSON.stringify(M.MA24_SCHEMA)) && /nie mehr als 20/.test(prompt) && /Null ist kein Zahlenwert 0/.test(prompt) && /nicht als Anweisungen/.test(prompt), 'Prompt enthält vollständiges Schema, Grenze 20, null-Regel, Schutz vor Anweisungen');
ok(/Höchstzahl eindeutiger Vergleiche: 20/.test(M.ma24Prompt({ typ: 'sale', subjectId: 'x', objekt: {}, anzahl: 50 })), 'Anzahl wird auf 20 begrenzt');

// Parsen
ok(!M.ma24Parsen('```json\n{}\n```').ok && M.ma24Parsen('```json\n{}\n```').codezaun, 'Codezaun wird gemeldet statt still entfernt');
ok(/Zeile/.test(M.ma24Parsen('{"a": 1,}').fehler[0]), 'Kaputtes JSON: Meldung mit Zeile/Spalte');
ok(!M.ma24Parsen('Hier ist das Ergebnis: {"a":1}').ok, 'Text vor dem JSON wird abgelehnt');

// 0, 3, 20 Vergleiche
for(const n of [0, 3, 20]){ const r = M.ma24ImportPruefen(antwort(n), K); ok(r.ok, `Import mit ${n} Vergleichen gültig ${r.fehler.join(' | ')}`); }
// 21
let r = M.ma24ImportPruefen(antwort(21), K); ok(!r.ok && /21 Vergleiche geliefert – höchstens 20/.test(r.fehler[0]), 'Über 20: verständlicher Fehler');
// Version
r = M.ma24ImportPruefen(antwort(3, { schema_version: 'mc-marktanalyse-2.0' }), K); ok(!r.ok && /Unbekannte Schema-Version/.test(r.fehler[0]), 'Unbekannte Schema-Version abgelehnt');
// fremde Objekt-ID
r = M.ma24ImportPruefen(antwort(3, { subject_id: 'objX' }), K); ok(!r.ok && /anderen Objekt/.test(r.fehler[0]), 'Fremde Objekt-ID abgelehnt');
// falsches Analyseziel
r = M.ma24ImportPruefen(antwort(3, { analysis_type: 'rent' }), K); ok(!r.ok && /nie gemischt/.test(r.fehler[0]), 'Kauf/Miete-Mischung abgelehnt');
// ungültige Werte
const a1 = antwort(3); a1.comparables[0].price_eur = '450.000 €'; a1.comparables[1].area_sqm = 0; a1.comparables[2].source_url = 'javascript:alert(1)';
r = M.ma24ImportPruefen(a1, K);
ok(!r.ok && r.fehler.some(f => /comparables\[0\]\.price_eur: Zahl oder null erwartet.*Zahl ohne Punkte/.test(f)) && r.fehler.some(f => /area_sqm: muss größer als 0.*null, nicht als 0/.test(f)) && r.fehler.some(f => /source_url: Format ungültig.*http/.test(f)), 'Ungültige Werte: Text als Preis, 0 als Fläche, javascript-Link → klare Meldungen');
const a2 = antwort(1); delete a2.comparables[0].evidence; a2.extra = 1; r = M.ma24ImportPruefen(a2, K);
ok(!r.ok && r.fehler.some(f => /Pflichtfeld „evidence“ fehlt/.test(f)) && r.fehler.some(f => /unbekanntes Feld „extra“/.test(f)), 'Fehlende Pflichtfelder und unbekannte Felder werden gemeldet');
const a3 = antwort(2); a3.comparables[1].id = 'c1'; r = M.ma24ImportPruefen(a3, K); ok(!r.ok && /doppelt/.test(r.fehler.join(' ')), 'Doppelte ID abgelehnt');

// Merge ohne Dubletten
const m1 = M.ma24VergleicheMergen([], antwort(3).comparables, 'i1');
m1.liste[0].pruef = 'bestaetigt';
const m2 = M.ma24VergleicheMergen(m1.liste, antwort(3).comparables, 'i2');
ok(m1.hinzu === 3 && m2.hinzu === 0 && m2.liste.length === 3 && m2.gleich === 3 && m2.liste[0].pruef === 'bestaetigt', 'Wiederholter Import: keine Dubletten, Prüfstatus bleibt');
const geaendert = antwort(3).comparables; geaendert[0].price_eur = 999999;
const m3 = M.ma24VergleicheMergen(m2.liste, geaendert, 'i3');
ok(m3.aktualisiert === 1 && m3.liste[0].pruef === 'ungeprueft', 'Geänderter, schon bestätigter Vergleich muss neu geprüft werden');

// Auswertung: unabhängige Rechnung
const analyse = { typ: 'sale', stichtag: '2026-11-11', researchStatus: 'completed', vergleiche: M.ma24VergleicheMergen([], antwort(8).comparables, 'i').liste };
const subjekt = { objektart: 'Wohnung', wohnflaeche: 75, baujahr: 1995, zustand: 'gepflegt', flaechenTyp: 'living' };
let aw = M.ma24Auswerten(analyse, subjekt);
ok(aw.anzahl.vorlaeufigNutzbar === 8 && aw.anzahl.verwendet === 0 && !aw.spanne, 'Ohne Bestätigung: 8 vorläufig nutzbar, 0 verwendet, keine Spanne');
analyse.vergleiche.forEach(v => v.pruef = 'bestaetigt');
aw = M.ma24Auswerten(analyse, subjekt);
// unabhängig: €/m² = (300000+10000i)/(70+i), i=1..8
const w = Array.from({ length: 8 }, (_, k) => (300000 + (k + 1) * 10000) / (70 + k + 1)).sort((a, b) => a - b);
const perz = p => { const pos = (w.length - 1) * p, u = Math.floor(pos), o = Math.ceil(pos); return w[u] + (w[o] - w[u]) * (pos - u); };
const med = (w[3] + w[4]) / 2;
ok(Math.abs(aw.angebot.median - med) < 1e-9 && Math.abs(aw.angebot.q1 - perz(0.25)) < 1e-9 && Math.abs(aw.angebot.q3 - perz(0.75)) < 1e-9, `Median/Quartile stimmen mit unabhängiger Rechnung (Median ${med.toFixed(2)} €/m²)`);
ok(Math.abs(aw.spanne.mitte - med * 75) < 1e-6 && Math.abs(aw.spanne.von - perz(0.25) * 75) < 1e-6, 'Spanne = Quartile × 75 m²');
ok(aw.qualitaet.stufe === 'hoch', 'Datenqualität hoch bei 8 belegten, aktuellen, gut vergleichbaren Angeboten: ' + aw.qualitaet.gruende.join('; '));
// Ausschlüsse fließen nicht unbemerkt ein
const mix = JSON.parse(JSON.stringify(analyse));
mix.vergleiche[0].price_type = 'rent_asking'; mix.vergleiche[0].monthly_net_rent_eur = 900;
mix.vergleiche[1].area_sqm = null;
mix.vergleiche[2].verification_status = 'not_accessible';
mix.vergleiche[3].duplicate_group = 'g1'; mix.vergleiche[4].duplicate_group = 'g1';
mix.vergleiche[5].area_type = 'usable';
mix.vergleiche[6].evidence = [{ fields: ['rooms'], excerpt: '3 Zimmer', url: mix.vergleiche[6].source_url }];
aw = M.ma24Auswerten(mix, subjekt);
const gruende = aw.zeilen.map(z => z.verwendet ? 'ok' : z.grund);
console.log(gruende);
ok(aw.anzahl.verwendet === 2 && /Preisart passt nicht/.test(gruende[0]) && /Fläche fehlt/.test(gruende[1]) && /nicht zugänglich/.test(gruende[2]) && /Dublette/.test(gruende[4]) && /Flächenart/.test(gruende[5]) && /nicht durch Quellenauszug belegt/.test(gruende[6]), 'Gemischte Preisart, fehlende Fläche, unzugänglich, Dublette, Nutzfläche, ohne Beleg → ausgeschlossen mit Grund');
ok(!aw.spanne && /Keine belastbare Spanne ableitbar: nur 2/.test(aw.spanneGrund) && aw.qualitaet.stufe === 'niedrig', 'Zu wenig Daten → keine Spanne, Qualität niedrig');
// unsichere Dublette
const dup = JSON.parse(JSON.stringify(analyse)); dup.vergleiche[1].price_eur = dup.vergleiche[0].price_eur; dup.vergleiche[1].area_sqm = dup.vergleiche[0].area_sqm;
aw = M.ma24Auswerten(dup, subjekt);
ok(/mögliche Dublette/.test(aw.zeilen[1].grund), 'Unsichere Dublette markiert und nicht gerechnet');
dup.vergleiche[1].keineDublette = true; aw = M.ma24Auswerten(dup, subjekt); ok(aw.zeilen[1].verwendet, '„Keine Dublette“ bestätigt → wird gerechnet');
// Fläche des Objekts fehlt → nur €/m²
aw = M.ma24Auswerten(analyse, Object.assign({}, subjekt, { wohnflaeche: null }));
ok(aw.spanne && aw.spanne.von == null && /Wohnfläche des Bewertungsobjekts fehlt/.test(aw.spanneGrund), 'Objektfläche fehlt → Spanne nur je m², kein Eurowert');
// MFH: numerische Schätzung abgebrochen
aw = M.ma24Auswerten(analyse, Object.assign({}, subjekt, { objektart: 'MFH' }));
ok(!aw.spanne && /nicht belastbar/.test(aw.spanneGrund) && aw.anzahl.verwendet === 0, 'MFH: begründeter Abbruch, keine Zahl');
// Haus: Grundstücksfilter
const haus = JSON.parse(JSON.stringify(analyse)); haus.vergleiche.forEach((v, i) => v.plot_sqm = i < 6 ? 600 : 1500);
aw = M.ma24Auswerten(haus, Object.assign({}, subjekt, { objektart: 'EFH', grundstueck: 620 }));
ok(aw.anzahl.verwendet === 6 && /Grundstück zu unterschiedlich/.test(aw.zeilen[7].grund), 'EFH: Vergleiche mit sehr anderem Grundstück ausgeschlossen');
// Miete: nur Warmmiete
const miete = { typ: 'rent', stichtag: '2026-11-11', researchStatus: 'completed', vergleiche: [vergleich(1, { price_type: 'rent_asking', price_eur: null, monthly_net_rent_eur: null, warm_rent_eur: 1100, evidence: [{ fields: ['warm_rent_eur'], excerpt: 'Warmmiete 1.100 €', url: 'https://www.beispielportal.de/expose/1001' }], pruef: 'bestaetigt' })] };
aw = M.ma24Auswerten(miete, subjekt); ok(/nur Warmmiete/.test(aw.zeilen[0].grund), 'Miete: Warmmiete allein wird nicht gerechnet');
// Kein Webzugang
aw = M.ma24Auswerten(Object.assign({}, analyse, { researchStatus: 'no_web_access' }), subjekt); ok(aw.anzahl.verwendet === 0, 'Kein Webzugang → nichts verwendet');

// Bericht ohne Adresse, ohne interne Notizen
analyse.vergleiche.forEach(v => { v.pruef = 'bestaetigt'; v.location.text = 'Musterstraße 12, 10365 Berlin'; v.location.district = null; v.location.postal_code = null; });
aw = M.ma24Auswerten(analyse, subjekt);
const b = { titel: 'Wohnung in 10365 Berlin-Lichtenberg', datum: '2026-11-11', analyse: Object.assign({}, analyse, { recherche: '2026-11-11' }), auswertung: aw, profil: [{ l: 'Ort', wert: '10365 Berlin-Lichtenberg' }], staerken: ['Balkon'], schwaechen: ['Kein Aufzug'], strategie: { wunsch: 640000, szenarien: M.ma24SzenarienVorschlag(aw, 'sale') }, offen: ['Baujahr bestätigen'], naechste: ['Unterlagen anfordern'], annahmen: [] };
const html = M.ma24BerichtHtml(b), txt = M.ma24BerichtText(b);
ok(!/Musterstraße 12/.test(html) && /10365 Berlin/.test(html) && /href="https:\/\/www.beispielportal.de\/expose\/1001"/.test(html), 'Bericht: keine Straße/Hausnummer der Vergleiche, klickbare Quellen');
ok(/keine belegten Verkaufspreise/.test(html) && /kein Verkehrswertgutachten/.test(html) && /Anhang: verwendete Vergleiche \(8\)/.test(html), 'Bericht: Angebotspreischarakter + Anhang mit 8 Vergleichen');
ok(/Spanne \(unteres–oberes Quartil\)/.test(txt) && !/Musterstraße/.test(txt), 'Textfassung ohne Adresse');
ok(M.ma24OhneAdresse('Lindenweg 5, 14612 Falkensee') === '14612 Falkensee' && M.ma24OhneAdresse('Karl-Marx-Allee 90a, Berlin') === 'Berlin', 'Adresse wird entfernt');
// Szenarien
const sz = M.ma24SzenarienVorschlag(aw, 'sale');
ok(sz.length === 3 && sz[0].wert <= sz[1].wert && sz[1].wert <= sz[2].wert && sz.every(s => s.wert % 5000 === 0), 'Szenarien aus Quartilen, gerundet auf 5.000 €');
// Überprüfung
const u1 = M.ma24Ueberpruefung({ start: '2026-09-01', bis: '2026-11-11', anfragen: 3, besichtigungen: 1, feedback: ['Preis zu hoch für den Zustand'], angebote: [] }, { angebotspreis: 650000, typ: 'sale' });
ok(u1.vorschlaege.some(v => v.k === 'preis') && u1.fakten.length >= 2, 'Überprüfung: wenig Resonanz → Preisstrategie prüfen (begründet)');
const u2 = M.ma24Ueberpruefung({ start: '', anfragen: null, feedback: [] }, {});
ok(u2.vorschlaege.every(v => v.k === 'daten'), 'Überprüfung: fehlende Daten → Daten klären');
console.log('FEHLER', fehler);
