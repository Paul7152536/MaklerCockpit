const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 1536, height: 1000 } });
  const fe = []; p.on('pageerror', e => fe.push(e.message));
  await p.addInitScript(() => { const alt = { objekte: [{ id: 'm1', createdAt: 1, akqTitel: '2-Zimmer zur Miete', objektart: 'Wohnung', auftragsart: 'vermietung', ort: '10247 Berlin-Friedrichshain', wohnflaeche: 60, kaufpreis: 950, status: 'auftrag', verlauf: [] }], kontakte: [], termine: [], aufgaben: [], notizen: [], marktanalysen: [], mentorFragen: [], meta: { v9neustart: { quittiert: true } } };
    window.pc = { laden: () => JSON.parse(JSON.stringify(alt)), speichern: () => ({ ok: true }), ordner(){}, sicherungSchreiben: () => ({ ok: true }), sicherungLesen: () => null, zwischenablage: async () => '', abruf: async () => ({ ok: false }) }; });
  await p.goto('file:///tmp/pc/app/index.html'); await p.waitForTimeout(1500);
  const r = await p.evaluate(() => {
    const a = ma24Anlegen('m1', 'rent', true); MA24.sel = a.id;
    const v = i => ({ id: 'r' + i, title: 'Mietwohnung ' + i, source_url: 'https://www.beispielportal.de/miete/' + i, additional_source_urls: [], source_name: 'Beispielportal', accessed_at: '2026-11-10T09:00:00+01:00', published_at: '2026-11-01', verification_status: 'verified', price_type: 'rent_asking', currency: 'EUR', price_eur: null, monthly_net_rent_eur: 900 + i * 25, warm_rent_eur: 1100 + i * 25, parking_eur: null, area_sqm: 58 + i, area_type: 'living', plot_sqm: null, rooms: 2, year_built: 1910, location: { text: 'Friedrichshain', district: 'Friedrichshain', postal_code: '10247', resolution: 'district' }, condition: 'renovated', occupancy: 'vacant', energy: null, features: [], evidence: [{ fields: ['monthly_net_rent_eur', 'area_sqm'], excerpt: 'Kaltmiete ' + (900 + i * 25) + ' €', url: 'https://www.beispielportal.de/miete/' + i }], missing_fields: [], comparability: 'good', comparability_reasons: [], duplicate_group: null, included: true, exclusion_reason: null });
    const j = { schema_version: 'mc-marktanalyse-1.0', subject_id: 'm1', analysis_type: 'rent', valuation_date: '2026-11-11', research_timestamp: '2026-11-11T10:00:00+01:00', research_status: 'completed', search_strategy: { areas: ['Friedrichshain'], criteria: [], expansions: [], restrictions: [], sources_searched: ['Beispielportal'] }, comparables: [1, 2, 3, 4, 5, 6].map(v), unverified_candidates: [], subject_conflicts: [], data_quality: { level: 'medium', reasons: ['x'] }, assumptions: [], limitations: [], summary: '', strategy_notes: [] };
    MA24.roh = JSON.stringify(j); MA24.schritt = 'import'; wechsleAnsicht('marktanalyse24'); ma24ImportPruefenKlick(true); ma24Uebernehmen(); ma24AlleBestaetigen(); MA24.schritt = 'ergebnis'; renderMain();
    const rr = ma24AnalyseAuswerten(ma24A()); const txt = document.querySelector('.ma24-inhalt').innerText;
    const bericht = ma24BerichtHtmlFuer(ma24A());
    return { n: rr.anzahl.verwendet, m2: rr.angebot.median, rechtlich: /Rechtlich zulässige Miete/.test(txt) && /begründet keine rechtliche Zulässigkeit/.test(txt), mtl: /mtl\./.test(txt), berichtHinweis: /begründet keine rechtliche Zulässigkeit/.test(bericht), prompt: /Nettokaltmiete pro Monat/.test(ma24Prompt(ma24PromptDaten(ma24A()))) };
  });
  console.log(JSON.stringify(r), 'Fehler:', fe);
  await p.screenshot({ path: '/tmp/v24test/12_miete.png' });
  await b.close();
})();
