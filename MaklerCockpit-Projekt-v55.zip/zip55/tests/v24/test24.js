// v24 Abnahme im Browser: Migration, Akquise (Gespräch, Briefing, Prioritäten, Kooperation), Marktanalyse (Prompt, Import, Prüfung, Bericht), Investments, Löschen, Modul-Schalter
const { chromium } = require('playwright');
let fehler = 0; const ok = (b, t) => { if(!b){ fehler++; console.log('FEHLER:', t); } else console.log('ok  ', t); };
const HEUTE = (() => { const d = new Date(); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); })();
const tag = n => { const d = new Date(); d.setDate(d.getDate() + n); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); };

function fixture(){
  return {
    objekte: [
      { id: 'o1', createdAt: Date.now() - 5e8, akqTitel: 'Helle 3-Zimmer-Wohnung', objektart: 'Wohnung', adresse: 'Musterstraße 12', ort: '10365 Berlin-Lichtenberg', status: 'termin', kaufpreis: 349000, wohnflaeche: 75, baujahr: '1995', zimmer: '3', verkaeuferName: 'Frau Krüger', verkaeuferTelefon: '0171 2223334', eigentuemerId: 'k1', verlauf: [], link: 'https://www.beispielportal.de/expose/999' },
      { id: 'o2', createdAt: Date.now() - 4e8, akqTitel: 'Doppelhaushälfte mit Garten', objektart: 'DHH', adresse: 'Birkenallee 3', ort: '14624 Dallgow-Döberitz', status: 'neu', kaufpreis: 529000, wohnflaeche: 118, grundstueck: 400, verkaeuferName: 'Herr Lange', verkaeuferTelefon: '0160 5556667', verlauf: [] },
      { id: 'o3', createdAt: Date.now() - 3e8, akqTitel: 'Kapitalanlage Spandau', objektart: 'Wohnung', adresse: 'Seestraße 7', ort: '13597 Berlin-Spandau', status: 'erstkontakt', kaufpreis: 189500, wohnflaeche: 50, verlauf: [] }
    ],
    kontakte: [
      { id: 'k1', createdAt: 1, name: 'Frau Krüger', telefon: '0171 2223334', email: '', kontaktart: 'eigentuemer', status: 'lead', prioritaet: 'mittel', notizen: '' },
      { id: 'k2', createdAt: 2, name: 'Herr Stopp', telefon: '0151 999', email: '', kontaktart: 'eigentuemer', status: 'lead', prioritaet: 'mittel', notizen: '', kontaktstopp: { aktiv: true, am: '2026-10-01', grund: 'ausdrücklich gewünscht' } }
    ],
    termine: [
      { id: 't1', createdAt: 1, titel: 'Rückruf: Doppelhaushälfte', datum: tag(-1), uhrzeit: '10:00', dauer: 15, art: 'rueckruf', ort: '', objektId: 'o2', wo: 'telefon' },
      { id: 't2', createdAt: 2, titel: 'Erstgespräch Wohnung', datum: tag(1), uhrzeit: '14:00', dauer: 60, art: 'erstgespraech', ort: 'Musterstraße 12, 10365 Berlin', objektId: 'o1', kontaktId: 'k1', wo: 'vorort' }
    ],
    aufgaben: [
      { id: 'a1', createdAt: 1, titel: 'Grundriss nachfragen', faellig: HEUTE, status: 'offen', prioritaet: 'mittel', objektId: 'o1', kontaktId: 'k1', notiz: '' },
      { id: 'a2', createdAt: 2, titel: 'Alte Aufgabe', faellig: tag(-3), status: 'erledigt', prioritaet: 'mittel', objektId: 'o1', notiz: '' },
      { id: 'a3', createdAt: 3, titel: 'Nachfassen Herr Stopp', faellig: tag(-1), status: 'offen', prioritaet: 'mittel', kontaktId: 'k2', notiz: '' },
      { id: 'a4', createdAt: 4, titel: 'Rückruf Lange', faellig: tag(-1), status: 'offen', prioritaet: 'mittel', objektId: 'o2', typ: 'rueckruf', notiz: '' }
    ],
    notizen: [{ id: 'n1', createdAt: 1, text: 'Alte Inbox-Notiz', verarbeitet: false }],
    marktanalysen: [], mentorFragen: [], gesuche: [{ id: 'g1', status: 'aktiv', name: 'Familie Brandt', arten: ['DHH'], orte: ['Dallgow'] }],
    hv: { verwaltungen: [{ id: 'hv1', name: 'Muster Hausverwaltung GmbH', ansprechpartner: 'Frau Weber', telefon: '030 123456', bezirk: 'Lichtenberg', status: 'interesse', einheiten: '800', quelle: 'Website Impressum' }, { id: 'hv2', name: 'Zweite Verwaltung KG', ansprechpartner: '', telefon: '030 7654321', bezirk: 'Pankow', status: 'offen' }] },
    meta: { v9neustart: { quittiert: true } }
  };
}
function vergleich(i, o){
  return Object.assign({ id: 'c' + i, title: 'ETW ' + (2 + i % 3) + ' Zimmer Lichtenberg ' + i, source_url: `https://www.beispielportal.de/expose/${1000 + i}`, additional_source_urls: [], source_name: 'Beispielportal', accessed_at: '2026-11-10T09:00:00+01:00', published_at: '2026-10-20', verification_status: 'verified', price_type: 'sale_asking', currency: 'EUR', price_eur: 300000 + i * 10000, monthly_net_rent_eur: null, warm_rent_eur: null, parking_eur: null, area_sqm: 70 + i, area_type: 'living', plot_sqm: null, rooms: 3, year_built: 1995, location: { text: 'Irgendweg ' + i + ', 10365 Berlin', district: 'Lichtenberg', postal_code: '10365', resolution: 'district' }, condition: 'well_kept', occupancy: 'vacant', energy: null, features: ['Balkon'], evidence: [{ fields: ['price_eur', 'area_sqm'], excerpt: `Kaufpreis ${300000 + i * 10000} € · ca. ${70 + i} m²`, url: `https://www.beispielportal.de/expose/${1000 + i}` }], missing_fields: [], comparability: 'good', comparability_reasons: [{ criterion: 'micro_location', assessment: 'good', reason: 'gleicher Ortsteil' }], duplicate_group: null, included: true, exclusion_reason: null }, o || {});
}
function antwort(n, o){
  return Object.assign({ schema_version: 'mc-marktanalyse-1.0', subject_id: 'o1', analysis_type: 'sale', valuation_date: HEUTE, research_timestamp: HEUTE + 'T10:00:00+01:00', research_status: 'completed', search_strategy: { areas: ['Lichtenberg'], criteria: ['ETW 60–90 m²'], expansions: [{ step: 'Fläche ±30 %', reason: 'zu wenige Treffer' }], restrictions: [], sources_searched: ['Beispielportal'] }, comparables: Array.from({ length: n }, (_, i) => vergleich(i + 1)), unverified_candidates: [{ title: 'Anzeige nicht erreichbar', url: 'https://www.anderesportal.de/x/1', source_name: 'Anderes Portal', reason: 'Seite lädt nicht', snippet: '3 Zimmer, 74 m²' }], subject_conflicts: [], data_quality: { level: 'medium', reasons: ['Testdaten'] }, assumptions: ['Angebotspreise, keine Kaufpreise'], limitations: ['nur ein Portal'], summary: 'Testzusammenfassung', strategy_notes: ['Einstieg in der Mitte'] }, o || {});
}

(async () => {
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 1536, height: 1000 } });
  const fe = []; p.on('pageerror', e => { fe.push(e.message); console.log('SEITENFEHLER', e.message); });
  await p.addInitScript(fx => {
    window.__speicher = () => sessionStorage.getItem('mc24test');
    window.pc = { laden: () => { const t = sessionStorage.getItem('mc24test'); return t ? JSON.parse(t) : JSON.parse(JSON.stringify(fx)); }, speichern: t => { sessionStorage.setItem('mc24test', t); return { ok: true }; }, ordner(){}, sicherungSchreiben: () => ({ ok: true }), sicherungLesen: () => null, zwischenablage: async () => '', abruf: async () => ({ ok: false }),
      htmlZuPdf: async html => { window.__pdfHtml = html; return { ok: true, base64: btoa('%PDF-1.4 test') }; }, dateiSpeichern: async (name) => ({ ok: true, name, pfad: '/tmp/' + name }), dateiOeffnen(){} };
    window.__kopiert = [];
    try{ Object.defineProperty(navigator, 'clipboard', { value: { writeText: async t => { window.__kopiert.push(t); } }, configurable: true }); }catch(e){}
  }, fixture());
  await p.goto('file:///tmp/pc/app/index.html'); await p.waitForTimeout(1500);
  const ev = (f, ...a) => p.evaluate(f, ...a);

  // ── 1) Migration ──
  const mig = await ev(() => ({ zweimal: mc24Migrieren(), json1: JSON.stringify(db), o1: db.objekte.find(o => o.id === 'o1'), wo: db.termine.find(t => t.id === 't2').wo, ges: db.gesuche.length, notiz: db.notizen[0].text }));
  const mig2 = await ev(() => { mc24Migrieren(); return JSON.stringify(db); });
  ok(mig.zweimal === false && mig.json1 === mig2, 'Migration erneut ausführen ändert nichts (idempotent)');
  ok(mig.o1.kaufpreis === 349000 && mig.o1.wohnflaeche === 75 && mig.o1.kontakte.length === 1 && mig.o1.kontakte[0].rolle === 'eigentuemer' && mig.o1.angaben.wohnflaeche.werte[0].herkunft === 'offen' && mig.wo === 'vorort' && mig.ges === 1 && mig.notiz === 'Alte Inbox-Notiz', 'v23-Daten ohne Verlust geladen; Eigentümer als Rolle; Herkunft „offen“ für Bestandswerte');
  ok(await ev(() => mc24Verweise().length === 0), 'Keine verwaisten Verweise nach der Migration');
  ok(await ev(() => aktuelleAnsicht === 'heute' && NAV.some(n => n.key === 'heute') && NAV.some(n => n.key === 'marktanalyse24') && NAV.some(n => n.key === 'investments24')), 'Startseite „Heute“, Navigation mit Marktanalyse und Investments');

  // ── 3) Prioritäten ──
  let pr = await ev(() => { const x = ak24Prioritaeten(); return { l: x.liste.map(i => ({ key: i.key, regel: i.regel, anlass: i.anlass, f: i.faellig.t, o: i.objektId })), gesperrt: x.gesperrt.length }; });
  console.log(JSON.stringify(pr.l));
  ok(pr.l.some(x => x.regel === 'rueckruf' && /Rückruf/.test(x.anlass) && /überfällig/.test(x.f) && x.o === 'o2'), 'Überfälliger Rückruf mit Anlass und Fälligkeit');
  ok(pr.l.filter(x => x.regel === 'rueckruf' && x.o === 'o2').length === 1, 'Rückruf-Termin und Rückruf-Aufgabe für dasselbe Objekt am selben Tag: nur ein Eintrag');
  ok(pr.l.some(x => x.key === 'a:a1' && /Grundriss/.test(x.anlass)) && !pr.l.some(x => x.key === 'a:a2'), 'Fällige Aufgabe drin, erledigte nicht');
  ok(!pr.l.some(x => x.key === 'a:a3') && pr.gesperrt >= 1, 'Kontakt mit Kontaktstopp wird nicht zum Nachfassen vorgeschlagen');
  ok(pr.l.some(x => x.regel === 'termin' && /Briefing und Marktanalyse fehlt/.test(x.anlass)), 'Bevorstehender Eigentümertermin: Briefing und Analyse fehlen');
  await ev(() => ak24PrioSetzen('a:a1', 'oben'));
  ok(await ev(() => ak24Prioritaeten().liste[0].key === 'a:a1'), 'Manuelle Priorität „ganz oben“ wirkt');
  await ev(() => wechsleAnsicht('heute')); await p.waitForTimeout(150);
  const heuteTxt = await ev(() => document.getElementById('main').innerText);
  ok(/Regel: Vereinbarter Rückruf/.test(heuteTxt) && /Gespräch abschließen/.test(heuteTxt) && /wegen dokumentiertem Kontaktstopp nicht angezeigt/.test(heuteTxt), 'Heute-Seite: Regel sichtbar, direkte Aktion, Hinweis auf Kontaktstopp');
  await p.screenshot({ path: '/tmp/v24test/1_heute.png' });

  // ── 2) Gesprächsabschluss → genau eine Folgeaufgabe, im Briefing sichtbar ──
  const vorA = await ev(() => db.aufgaben.length), vorT = await ev(() => db.termine.length);
  await ev(() => ak24Abschluss({ objektId: 'o1' })); await p.waitForTimeout(100);
  await p.screenshot({ path: '/tmp/v24test/2_abschluss.png' });
  await ev(() => { const g = x => document.getElementById(x); g('ab_erg').value = 'interesse'; g('ab_erg').dispatchEvent(new Event('change')); g('ab_ergt').value = 'will Unterlagen sehen'; g('ab_schritt').value = 'unterlagen'; g('ab_schritt').dispatchEvent(new Event('change')); g('ab_schrittt').value = 'Grundriss und Energieausweis senden'; g('ab_wann').value = '2026-11-20'; g('ab_notiz').value = 'Freundliches Gespräch'; g('ab_ew').value = 'provision'; g('ab_eww').value = 'Die Provision ist mir zu hoch.'; g('ab_mg').value = 'Umzug nach Hamburg'; });
  await ev(() => ak24AbschlussSpeichern()); await p.waitForTimeout(100);
  const g1 = await ev(() => ({ a: db.aufgaben.length, t: db.termine.length, n: db.notizen.filter(n => n.typ === 'gespraech').length, neu: db.aufgaben[db.aufgaben.length - 1], k: db.kontakte.find(k => k.id === 'k1'), m: db.objekte.find(o => o.id === 'o1').motivation }));
  ok(g1.a === vorA + 1 && g1.t === vorT && g1.n === 1 && /Unterlagen senden: .*Grundriss/.test(g1.neu.titel) && g1.neu.faellig === '2026-11-20' && g1.neu.objektId === 'o1' && g1.neu.kontaktId === 'k1', 'Gespräch erzeugt genau eine verknüpfte Aufgabe (kein Termin)');
  ok(g1.k.einwaende.length === 1 && g1.k.einwaende[0].kategorie === 'provision' && g1.m.verkaufsgrund === 'Umzug nach Hamburg', 'Einwand beim Kontakt und Motivation aktualisiert');
  await ev(() => ak24Briefing({ objektId: 'o1' })); await p.waitForTimeout(100);
  const br = await ev(() => document.getElementById('modalInner').innerText);
  ok(/will Unterlagen sehen/.test(br) && /Vereinbart: Unterlagen senden/.test(br) && /Grundriss und Energieausweis senden/.test(br) && /Provision zu hoch/.test(br) && /Umzug nach Hamburg/.test(br) && /Erstgespräch Wohnung/.test(br), 'Briefing zeigt Gespräch, Vereinbarung, Einwand, Motivation, nächsten Termin');
  ok(!/Erwartungen an den Makler|Zeitraum/.test(br) && /Verkaufsgrund/.test(br), 'Briefing zeigt nur erfasste Motivation – nichts ergänzt');
  await p.screenshot({ path: '/tmp/v24test/3_briefing.png' });
  const prompt = await ev(() => ak24KiPrompt(AK24_BRIEF.d));
  ok(!/Krüger|0171|2223334/.test(prompt) && /Erfinde keine Motive/.test(prompt), 'KI-Prompt fürs Briefing ohne Namen/Telefon und mit Erfindungsverbot');
  await ev(() => schliesseModal());
  // Termin vor Ort mit Uhrzeit → genau ein Termin
  const t0 = await ev(() => ({ a: db.aufgaben.length, t: db.termine.length }));
  await ev(() => { AK24_AB = { objektId: 'o2' }; return ak24AbschlussSpeichern({ kontaktId: null, ergebnis: 'termin', ergebnisText: 'Termin vereinbart', schritt: 'vorort', schrittText: 'Bewertung', wann: '2026-11-25', zeit: '11:00', notiz: '', einwand: '', einwandWort: '', motiv: null }); });
  const t1 = await ev(() => ({ a: db.aufgaben.length, t: db.termine.length, letzt: db.termine[db.termine.length - 1], o2: db.objekte.find(o => o.id === 'o2'), k: db.kontakte.find(k => k.name === 'Herr Lange') }));
  ok(t1.t === t0.t + 1 && t1.a === t0.a && t1.letzt.wo === 'vorort' && t1.letzt.uhrzeit === '11:00' && t1.letzt.objektId === 'o2' && t1.k && t1.o2.eigentuemerId === t1.k.id && t1.o2.status === 'termin', 'Vor-Ort-Termin: genau ein Termin (📍), Verkäufer-Kontakt aus Lead angelegt, Status Termin');
  // Kein weiterer Schritt / Kontaktstopp
  const s0 = await ev(() => ({ a: db.aufgaben.length, t: db.termine.length }));
  await ev(() => { AK24_AB = { kontaktId: 'k1' }; ak24AbschlussSpeichern({ kontaktId: 'k1', ergebnis: 'abgeschlossen', ergebnisText: '', schritt: 'keiner', schrittText: '', wann: '', zeit: '', notiz: 'erledigt', einwand: '', motiv: null }); });
  await ev(() => { AK24_AB = { objektId: 'o3' }; ak24AbschlussSpeichern({ kontaktId: null, ergebnis: 'kontaktstopp', ergebnisText: 'möchte keine Anrufe', schritt: 'rueckruf', schrittText: '', wann: '2026-12-01', zeit: '', notiz: '', einwand: '', motiv: null }); });
  const s1 = await ev(() => ({ a: db.aufgaben.length, t: db.termine.length, stopp: (ob24Hauptkontakt(findObjekt('o3'), false) || {}).kontaktstopp }));
  ok(s1.a === s0.a && s1.t === s0.t && s1.stopp && s1.stopp.aktiv, 'Kein Folgeschritt erzwungen; Kontaktstopp ohne Folgeaufgabe und dokumentiert');
  // Rückruf aus „Heute“ abschließen → Quelle erledigt, verschwindet
  await ev(w => { AK24_AB = { objektId: 'o2', aufgabeId: 'a4' }; ak24AbschlussSpeichern({ kontaktId: null, ergebnis: 'nicht_erreicht', ergebnisText: '', schritt: 'rueckruf', schrittText: '', wann: w, zeit: '', notiz: '', einwand: '', motiv: null }); }, tag(2));
  pr = await ev(() => ak24Prioritaeten().liste.map(i => i.key));
  ok(!pr.includes('a:a4') && !pr.includes('t:t1'), 'Erledigter Rückruf (Gespräch dokumentiert) erscheint nicht mehr');

  // ── 4) Hausverwaltung ──
  const hv1 = await ev(() => ak24HvUebernehmen());
  const hv2 = await ev(() => ak24HvUebernehmen());
  const org = await ev(() => { const o = db.kontakte.find(k => k.organisation && k.koop && k.koop.hvId === 'hv1'); return { o, ap: mc24Ansprechpartner(o.id).map(x => x.name), n: db.kontakte.filter(k => k.organisation).length }; });
  ok(hv1.neu === 2 && hv1.ap === 1 && hv2.neu === 0 && org.n === 2 && org.o.koop.status === 'interesse' && org.o.quellen.telefon === 'Website Impressum' && org.ap.join() === 'Frau Weber', 'Hausverwaltungen übernommen: Organisation, Status, Quelle; zweiter Lauf ohne Dubletten');
  await ev(o => { AK24_KOOP.sel = o; ak24ApNeu(o); document.getElementById('ap_n').value = 'Herr Klein'; document.getElementById('ap_r').value = 'Vermietung'; ak24ApSpeichern(o); ak24ApNeu(o); document.getElementById('ap_n').value = 'herr klein'; ak24ApSpeichern(o); schliesseModal(); }, org.o.id);
  ok(await ev(o => mc24Ansprechpartner(o).length === 2 && db.kontakte.filter(k => /klein/i.test(k.name)).length === 1, org.o.id), 'Mehrere Ansprechpartner, gleicher Name wird nicht doppelt angelegt');
  await ev(([o, w]) => { AK24_AB = { kontaktId: o }; ak24AbschlussSpeichern({ kontaktId: db.kontakte.find(k => k.name === 'Herr Klein').id, ergebnis: 'interesse', ergebnisText: 'Bedarf bei Leerständen', schritt: 'telefontermin', schrittText: 'Konditionen besprechen', wann: w, zeit: '09:30', notiz: '', einwand: '', motiv: null }); }, [org.o.id, tag(3)]);
  ok(await ev(o => { const k = findKontakt(o); return k.koop.letzterAustausch === mc24Heute() && /Telefontermin/.test(k.koop.naechsterSchritt) && db.termine.some(t => t.wo === 'telefon' && /Muster Hausverwaltung|Herr Klein/.test(t.titel + (findKontakt(t.kontaktId) || {}).name)); }, org.o.id), 'Gespräch mit Ansprechpartner aktualisiert die Kooperationsakte und legt genau einen Telefontermin an');
  await ev(() => { wechsleAnsicht('kooperationen'); }); await p.waitForTimeout(150);
  ok(await ev(() => /Muster Hausverwaltung GmbH/.test(document.getElementById('main').innerText) && /Konkreter Anlass/.test(document.getElementById('main').innerText)), 'Kooperationen-Seite mit Akte');
  await p.screenshot({ path: '/tmp/v24test/4_kooperationen.png' });

  // ── 5) Prompt ──
  await ev(() => { const o = findObjekt('o1'); an24Pruefen('o1', 'wohnflaeche'); });
  const aid = await ev(() => ma24Anlegen('o1', 'sale', true).id);
  const pt = await ev(id => ma24Prompt(ma24PromptDaten(ma24A(id))), aid);
  ok(/"wohnflaeche": \{\s*"wert": 75/.test(pt) && /Lichtenberg/.test(pt) && /Höchstzahl eindeutiger Vergleiche: 12/.test(pt) && /mc-marktanalyse-1.0/.test(pt) && /"\$defs"/.test(pt) && /Fläche 60–90 m²/.test(pt), 'Prompt: aktuelle Objektdaten, Suchgebiet, Filter, Grenze, vollständiges Schema');
  ok(!/Krüger|0171 2223334/.test(pt) && /expose\/999/.test(pt), 'Prompt ohne Eigentümerkontaktdaten; eigenes Inserat als Ausschluss');
  await ev(id => { MA24.sel = id; MA24.schritt = 'suche'; wechsleAnsicht('marktanalyse24'); }, aid); await p.waitForTimeout(150);
  await ev(() => ma24PromptKopieren()); await p.waitForTimeout(100);
  ok(await ev(() => window.__kopiert.length && /Du recherchierst Vergleichsinserate/.test(window.__kopiert[window.__kopiert.length - 1]) && MA24.schritt === 'import'), 'Ein Klick kopiert den Prompt, weiter zum Import');

  // ── 6) Importe ──
  const imp = async (json, roh) => { await ev(t => { MA24.roh = t; ma24ImportPruefenKlick(true); }, roh || JSON.stringify(json)); await p.waitForTimeout(80); return ev(() => ({ fehler: (MA24.vorschau || {}).fehler || [], text: document.querySelector('.ma24-inhalt').innerText })); };
  let r = await imp(antwort(21)); ok(r.fehler.length && /21 Vergleiche geliefert – höchstens 20/.test(r.text), 'UI: über 20 Vergleiche → verständliche Meldung');
  r = await imp(antwort(3, { schema_version: 'mc-marktanalyse-9' })); ok(/Unbekannte Schema-Version/.test(r.text), 'UI: unbekannte Schema-Version');
  r = await imp(antwort(3, { subject_id: 'o2' })); ok(/anderen Objekt/.test(r.text), 'UI: falsche Objekt-ID → nichts übernommen');
  const kaputt = antwort(2); kaputt.comparables[0].price_eur = 'ca. 400.000 €'; r = await imp(kaputt); ok(/price_eur: Zahl oder null erwartet/.test(r.text), 'UI: ungültiger Wert mit Feldpfad');
  r = await imp(null, '```json\n' + JSON.stringify(antwort(1)) + '\n```'); ok(/Codezaun/.test(r.text) && await ev(() => !!document.querySelector('.ma24-fehler button')), 'UI: Codezaun gemeldet, Entfernen nur auf Klick');
  r = await imp(antwort(0)); ok(!r.fehler.length && /0\s*Vergleiche geliefert/.test(r.text), 'UI: Import mit 0 Vergleichen – Vorschau');
  // 20 mit Widerspruch zur bestätigten Wohnfläche
  const a20 = antwort(20, { subject_conflicts: [{ field: 'Wohnfläche', values: [{ value: 82, source: 'Inserat 2024' }, { value: 75, source: 'Eigentümer' }], significance: 'Ändert €/m²-Bezug', question: 'Wohnflächenberechnung anfordern?' }] });
  a20.comparables[18].verification_status = 'not_accessible'; a20.comparables[19].duplicate_group = 'g'; a20.comparables[17].duplicate_group = 'g';
  a20.comparables[16].price_type = 'rent_asking'; a20.comparables[16].monthly_net_rent_eur = 950; a20.comparables[15].area_sqm = null;
  r = await imp(a20); ok(!r.fehler.length && /20\s*Vergleiche geliefert/.test(r.text) && /Quelle nicht zugänglich/.test(r.text) && /Preisart passt nicht/.test(r.text), 'UI: 20 Vergleiche – Vorschau mit Quellen und Ausschlüssen');
  await p.screenshot({ path: '/tmp/v24test/5_import_vorschau.png' });
  await ev(() => ma24Uebernehmen()); await p.waitForTimeout(100);
  const nach = await ev(id => { const a = ma24A(id), o = findObjekt('o1'); return { n: a.vergleiche.length, h: a.unbestaetigt.length, fl: o.wohnflaeche, aktiv: an24Wert(o, 'wohnflaeche'), vors: o.angaben.wohnflaeche.werte.filter(w => w.pruef === 'vorschlag').map(w => w.wert), konf: an24Konflikte(o).length, kk: a.kiKonflikte.length }; }, aid);
  ok(nach.n === 20 && nach.h === 1 && nach.fl === 75 && nach.aktiv === 75 && nach.vors.join() === '82' && nach.konf === 1 && nach.kk === 1, 'KI-Import überschreibt die bestätigte Wohnfläche nicht – 82 m² nur als Vorschlag + Widerspruch');
  await ev(() => { MA24.schritt = 'import'; });
  r = await imp(a20); ok(/bereits importiert/.test(r.text), 'Gleiche Antwort erneut: als bereits importiert erkannt');
  await ev(() => { MA24.vorschau = null; });
  // ── 7) Prüfen und bestätigen ──
  await ev(() => { MA24.schritt = 'vergleiche'; renderMain(); }); await p.waitForTimeout(100);
  let aw = await ev(id => { const r = ma24AnalyseAuswerten(ma24A(id)); return { verw: r.anzahl.verwendet, vorl: r.anzahl.vorlaeufigNutzbar, spanne: !!r.spanne, gr: r.zeilen.map(z => z.grund) }; }, aid);
  ok(aw.verw === 0 && aw.vorl === 16 && !aw.spanne, 'Vor Bestätigung: nichts verwendet, keine Spanne (16 vorläufig nutzbar)');
  ok(aw.gr.some(g => /nicht zugänglich/.test(g)) && aw.gr.some(g => /Dublette/.test(g)) && aw.gr.some(g => /Preisart/.test(g)) && aw.gr.some(g => /Fläche fehlt/.test(g)), 'Unzugänglich, Dublette, gemischte Preisart, fehlende Fläche: ausgeschlossen mit Grund');
  await ev(() => ma24AlleBestaetigen()); await p.waitForTimeout(80);
  await ev(id => { const a = ma24A(id); ma24VStatus(a.vergleiche[0].id, 'ausgeschlossen'); }, aid);
  aw = await ev(id => { const a = ma24A(id), r = ma24AnalyseAuswerten(a); return { verw: r.anzahl.verwendet, best: r.anzahl.bestaetigt, ge: r.anzahl.gefunden, med: r.angebot.median, q1: r.angebot.q1, q3: r.angebot.q3, von: r.spanne.von, werte: r.zeilen.filter(z => z.verwendet).map(z => z.proM2) }; }, aid);
  const w = aw.werte.slice().sort((x, y) => x - y), perz = q => { const pos = (w.length - 1) * q, u = Math.floor(pos), o = Math.ceil(pos); return w[u] + (w[o] - w[u]) * (pos - u); };
  ok(aw.verw === 15 && aw.ge === 20 && Math.abs(aw.med - perz(0.5)) < 1e-9 && Math.abs(aw.von - perz(0.25) * 75) < 1e-6, `Nach Bestätigung: 15 verwendet, Median ${Math.round(aw.med)} €/m² = unabhängig berechnet, Spanne × 75 m²`);
  await p.screenshot({ path: '/tmp/v24test/6_vergleiche.png' });
  // ── Ergebnis, Strategie, Widerspruch → Aufgabe, Abschluss ──
  await ev(() => { MA24.schritt = 'ergebnis'; renderMain(); }); await p.waitForTimeout(100);
  const erg = await ev(() => document.querySelector('.ma24-inhalt').innerText);
  ok(/Datenqualität: (hoch|mittel)/.test(erg) && /Zügiger Verkauf/.test(erg) && /Ausgewogener Einstieg/.test(erg) && /Wohnfläche/.test(erg) && /Keine garantierten Verkaufszeiten/.test(erg), 'Ergebnis: Datenqualität, drei Szenarien, Widerspruch Wohnfläche sichtbar');
  await ev(id => { const a = ma24A(id); ma24KiKonfliktAufgabe(a.kiKonflikte[0].key); }, aid);
  ok(await ev(() => db.aufgaben.some(a => a.typ === 'klaerung' && /Klären: Wohnfläche/.test(a.titel) && a.objektId === 'o1')), 'Widerspruch → Klärungsaufgabe');
  await ev(() => { ma24Strat('wunsch', 420000); ma24Strat('angebotspreis', 379000); ma24Liste('staerken', 'Balkon nach Süden\nruhige Lage'); ma24Liste('naechste', 'Wohnflächenberechnung anfordern'); });
  await p.screenshot({ path: '/tmp/v24test/7_ergebnis.png', fullPage: false });
  await ev(() => ma24Abschliessen()); await p.waitForTimeout(80);
  ok(await ev(id => ma24A(id).status === 'abgeschlossen' && ma24A(id).eingabe && ma24A(id).eingabe.werte.wohnflaeche.wert === 75, aid), 'Analyse abgeschlossen mit versioniertem Eingabestand');
  await ev(id => ma24VStatus(ma24A(id).vergleiche[1].id, 'ausgeschlossen'), aid);
  ok(await ev(id => ma24A(id).vergleiche[1].pruef === 'bestaetigt', aid), 'Abgeschlossene Analyse ist gegen Änderungen gesperrt');
  // ── 10) Bericht ──
  await ev(() => { MA24.schritt = 'bericht'; renderMain(); }); await p.waitForTimeout(150);
  const bericht = await ev(id => ma24BerichtHtmlFuer(ma24A(id)), aid);
  ok(!/Musterstraße/.test(bericht) && !/Krüger|0171/.test(bericht) && !/Umzug nach Hamburg|Provision ist mir zu hoch|Freundliches Gespräch/.test(bericht) && !/Irgendweg/.test(bericht), 'Bericht: keine Adresse, keine Kontaktdaten, keine internen Notizen/Motivation/Einwände');
  [/10365 Berlin-Lichtenberg/, /href="https:\/\/www.beispielportal.de\/expose\/1002"/, /Angebotspreise sind keine belegten Verkaufspreise/, /Anhang: verwendete Vergleiche \(15\)/, /Wohnfläche: abweichende Angaben/].forEach(rx => { if(!rx.test(bericht)) console.log('BERICHT fehlt', rx); });
  ok(/10365 Berlin-Lichtenberg/.test(bericht) && /href="https:\/\/www.beispielportal.de\/expose\/1002"/.test(bericht) && /Angebotspreise sind keine belegten Verkaufspreise/.test(bericht) && /Angebotspreise, keine Kaufpreise|Annahmen/.test(bericht) && /Anhang: verwendete Vergleiche \(15\)/.test(bericht) && /Wohnfläche: abweichende Angaben/.test(bericht), 'Bericht: Ort, klickbare Quellen, Angebotspreischarakter, Annahmen, Anhang, offene Punkte');
  ok(await ev(() => [...document.querySelectorAll('.ma24-pruef span')].every(s => s.classList.contains('ok'))), 'Export-Vorschau: alle Prüfhaken grün');
  await p.screenshot({ path: '/tmp/v24test/8_bericht.png' });
  await ev(() => ma24BerichtPdf()); await p.waitForTimeout(200);
  ok(await ev(id => (ma24A(id).berichte || []).length === 1 && /Marktanalyse/.test(window.__pdfHtml), aid), 'PDF-Export über den Hauptprozess angestoßen, im Verlauf vermerkt');
  // Akte zeigt Vorschlag + Konflikt + Analyse
  await ev(() => ob24Oeffnen('o1')); await p.waitForTimeout(150);
  const akte = await ev(() => document.getElementById('main').innerText);
  ok(/Vorschlag: 82 m²/.test(akte) && /Widersprüche und Klärung/.test(akte) && /Entscheidung dokumentieren/.test(akte) && /Verkaufspreis · Version 1/.test(akte) && /Provision zu hoch/.test(akte) && /Unterlagen senden/.test(akte), 'Objektakte: Vorschlag, Widerspruch, Analyse, Einwand, Aufgabe');
  await p.screenshot({ path: '/tmp/v24test/9_akte.png' });
  // Entscheidung im Widerspruch: Quelle bleibt erhalten
  await ev(() => { an24KlaerenDialog('o1', 'wohnflaeche'); document.querySelector('input[name="an_k"][value]').checked = true; const r = [...document.querySelectorAll('input[name="an_k"]')].find(x => findObjekt('o1').angaben.wohnflaeche.werte.find(w => w.id === x.value).wert === 75); r.checked = true; document.getElementById('an_begr').value = 'laut Wohnflächenberechnung 2019'; an24KlaerenSpeichern('o1', 'wohnflaeche'); });
  ok(await ev(() => { const o = findObjekt('o1'), b = o.angaben.wohnflaeche; return an24Konflikte(o).length === 0 && o.wohnflaeche === 75 && b.werte.some(w => w.wert === 82 && w.pruef === 'abgelehnt' && /Inserat 2024/.test(w.quelle)) && /Wohnflächenberechnung/.test(b.entscheidung.text); }), 'Klärung dokumentiert, verworfene Angabe mit Quelle erhalten');

  // ── 11) Investments ──
  const pid = await ev(() => iv24Anlegen('o3', true).id);
  const iv = await ev(id => { const p = iv24P(id); p.e.miete = 625; p.e.eigenkapital = 0; p.e.darlehenModus = 'betrag'; p.e.darlehenBetrag = 189500; p.e.verwaltung = 35; p.e.instandhaltung = 746 / 12; save(); IV24.sel = id; IV24.tab = 'pruefung'; wechsleAnsicht('investments24'); const r = iv24ErgebnisVon(p); return { cf: r.cashflowMonat, luecke: r.finanzierungsluecke, ek: r.ekRendite, grest: p.e.nebenkosten[0].wert, text: document.getElementById('main').innerText }; }, pid);
  ok(iv.grest === 6 && Math.abs(iv.cf + 417.95) < 0.05 && Math.abs(iv.luecke - 21925.15) < 0.01 && iv.ek === null, 'Investment: Berlin 6 % GrESt-Vorschlag, Cashflow −418 €/Monat, Lücke 21.925 €, EK-Rendite undefiniert');
  ok(/nicht definiert/.test(iv.text) && /nicht gedeckt/.test(iv.text) && /Rechenkonventionen/.test(iv.text) && /vor Steuern/.test(iv.text), 'Investment-Seite: Lücke und undefinierte EK-Rendite sichtbar, Konventionen offengelegt');
  await p.screenshot({ path: '/tmp/v24test/10_invest.png' });
  await ev(id => { const p = iv24P(id); p.e.hausgeld = 300; p.e.hausgeldUmlagefaehig = null; save(); renderMain(); }, pid);
  ok(await ev(() => /nicht berechenbar/.test(document.getElementById('main').innerText) && /Aufteilung Hausgeld/.test(document.getElementById('main').innerText)), 'Hausgeld ohne Aufteilung → Cashflow nicht berechenbar, Lücke benannt');
  await ev(id => { const p = iv24P(id); p.e.hausgeldUmlagefaehig = 180; p.e.ruecklage = 60; p.e.darlehenModus = 'rest'; p.e.eigenkapital = 40000; p.ziel = { art: 'cashflow', wert: 500, finanzierungGedeckt: false }; save(); IV24.max = { id, res: iv24MaxPreis(p.e, p.ziel, p.ansicht) }; renderMain(); }, pid);
  ok(await ev(() => /Unter diesen Annahmen nicht erreichbar/.test(document.getElementById('main').innerText)), 'Unerreichbarer Ziel-Cashflow wird erklärt');
  await ev(id => { const p = iv24P(id); p.e.miete = 900; p.ziel = { art: 'cashflow', wert: -100 }; save(); IV24.max = { id, res: iv24MaxPreis(p.e, p.ziel, p.ansicht) }; renderMain(); }, pid);
  const mx = await ev(id => { const p = iv24P(id), m = IV24.max.res, vor = iv24Rechnen(Object.assign({}, p.e, { kaufpreis: m.preis })); return { preis: m.preis, cf: vor.cashflowMonat, txt: document.getElementById('main').innerText }; }, pid);
  ok(mx.preis > 0 && mx.cf >= -100 && /Gegenprobe/.test(mx.txt) && /unter diesen Annahmen/.test(mx.txt), `Max. Kaufpreis ${mx.preis} € mit Gegenprobe (CF ${mx.cf.toFixed(2)} €)`);
  // Potenzial getrennt, Vergleich
  await ev(id => { iv24Set('e.potenzial.miete', 1000); iv24Set('ansicht', 'potenzial'); }, pid);
  ok(await ev(() => /Potenzialannahmen aktiv – nicht gesichert/.test(document.getElementById('main').innerText)), 'Potenzial-Ansicht klar als ungesichert gekennzeichnet');
  const pid2 = await ev(() => iv24Anlegen('o1', true).id);
  await ev(() => { IV24.tab = 'vergleich'; IV24.vergleich = {}; IV24.vergleichAnsicht = 'eigene'; renderMain(); }); await p.waitForTimeout(100);
  ok(await ev(() => /mischen Ist- und Potenzialbasis/.test(document.getElementById('main').innerText)), 'Vergleich warnt bei Mischung aus Ist und Potenzial');
  await ev(() => { IV24.vergleichAnsicht = 'ist'; renderMain(); });
  ok(await ev(() => !/mischen Ist- und Potenzialbasis/.test(document.getElementById('main').innerText) && document.querySelectorAll('.iv24-vgl th').length === 3), 'Vergleich „alle Ist“ ohne Mischung');
  await p.screenshot({ path: '/tmp/v24test/11_vergleich.png' });
  // Entscheidung: Ablehnung braucht Grund, Verlauf bleibt
  await ev(id => { IV24.tab = 'pruefung'; IV24.sel = id; renderMain(); document.getElementById('ie_st').value = 'ablehnen'; iv24EntscheidungSpeichern(); }, pid);
  ok(await ev(id => !iv24P(id).entscheidung, pid), 'Ablehnen ohne Begründung wird nicht gespeichert');
  await ev(() => { document.getElementById('ie_st').value = 'ablehnen'; document.getElementById('ie_b').value = 'Cashflow zu negativ'; iv24EntscheidungSpeichern(); document.getElementById('ie_st').value = 'weiterpruefen'; document.getElementById('ie_b').value = 'Preis gesenkt'; iv24EntscheidungSpeichern(); });
  ok(await ev(id => iv24P(id).entscheidungen.length === 2 && iv24P(id).entscheidungen[0].begruendung === 'Cashflow zu negativ', pid), 'Ablehnungsgrund bleibt im Verlauf erhalten');

  // ── Löschen ohne verwaiste Verweise ──
  await ev(() => { loescheObjekt('o1'); }); await p.waitForTimeout(80);
  const conf = await ev(() => (document.getElementById('bottomConfirm') || {}).innerText || '');
  ok(/1 Marktanalyse/.test(conf) && /Investmentprüfung/.test(conf) && /Gesprächsnotiz/.test(conf) && /Frau Krüger“ bleibt erhalten/.test(conf), 'Löschdialog nennt verknüpfte Analysen/Prüfungen/Notizen: ' + conf.replace(/\s+/g, ' ').slice(0, 160));
  await ev(() => { const b = [...document.querySelectorAll('#bottomConfirm button')].find(x => /löschen|ja/i.test(x.textContent)) || document.querySelectorAll('#bottomConfirm button')[1]; b.click(); }); await p.waitForTimeout(100);
  ok(await ev(() => !findObjekt('o1') && mc24Verweise().length === 0 && db.analysen24.every(a => a.objektId !== 'o1' || a.objektGeloescht) && db.notizen.some(n => n.objektTitel === 'Helle 3-Zimmer-Wohnung') && findKontakt('k1') && findKontakt('k1').einwaende.length === 1), 'Nach dem Löschen: keine verwaisten Verweise, Analysen archiviert, Kontakt mit Historie bleibt');
  await ev(() => wechsleAnsicht('marktanalyse24')); await p.waitForTimeout(100);
  ok(await ev(() => /Objekt gelöscht/.test(document.getElementById('main').innerText)), 'Archivierte Analyse sichtbar markiert');

  // ── Gespeicherte Daten enthalten alles Neue (für Sicherung) ──
  await p.waitForTimeout(500);
  const ges = await ev(() => JSON.parse(window.__speicher()));
  console.log('SPEICHER', ges.analysen24 && ges.analysen24.length, ges.invest24 && ges.invest24.pruefungen.length, !!ges.ak24, ges.notizen.filter(n => n.typ === 'gespraech').length, ges.kontakte.filter(k => k.koop).length, JSON.stringify(ges.module));
  ok(ges.analysen24.length >= 1 && ges.invest24.pruefungen.length === 2 && ges.ak24 && ges.notizen.some(n => n.typ === 'gespraech') && ges.kontakte.some(k => k.koop) && ges.module.akquise24 === true, 'daten.json enthält Analysen, Investments, Akquise-Daten (Sicherung schließt sie ein)');

  // ── 14) Keine ausgeschlossenen Funktionen neu ──
  const html = await ev(() => document.documentElement.innerHTML);
  ok(!/Inseratsverlauf|Inseratsmonitoring|Kanal-Conversion|Raumliste|Lichtplanung/.test(html.replace(/kein Inseratsmonitoring|Keine Kanal-Auswertung, kein Inseratsmonitoring/g, '')), 'Keine Inseratsverlaufs-, Kanalstatistik- oder Shooting-Erweiterungen');

  // ── Modul-Schalter Akquise ──
  await ev(() => { mc24ModuleDialog(); document.getElementById('mod_ak').checked = false; mc24Module().akquise24 = false; save(); });
  await p.reload(); await p.waitForTimeout(1500);
  const aus = await ev(() => { ob24Oeffnen('o2'); return { nav: NAV.map(n => n.key).join(','), ansicht: MC24.zurueck, akte: document.getElementById('main').innerText, daten: db.notizen.filter(n => n.typ === 'gespraech').length + '/' + db.kontakte.filter(k => k.koop).length }; });
  ok(!/heute|kooperationen/.test(aus.nav) && !/Gespräch vorbereiten|Gespräch abschließen|Verkäufermotivation|Einwände/.test(aus.akte) && aus.daten.split('/')[0] >= 3, 'Akquise-Erweiterung aus: kein „Heute“, keine Kooperationen, keine Gesprächs-Knöpfe – Daten bleiben (' + aus.daten + ')');
  ok(await ev(() => aktuelleAnsicht !== 'heute' && NAV.some(n => n.key === 'marktanalyse24')), 'Start wieder in der Akquise, Marktanalyse/Investments bleiben');
  await ev(() => { mc24Module().akquise24 = true; save(); });
  await p.reload(); await p.waitForTimeout(1500);
  ok(await ev(() => aktuelleAnsicht === 'heute' && NAV.some(n => n.key === 'kooperationen') && db.kontakte.find(k => k.name === 'Frau Krüger').einwaende.length === 1), 'Wieder eingeschaltet: alles wieder da (inkl. Einwände)');

  ok(fe.length === 0, 'Keine Seitenfehler (' + fe.length + ')');
  console.log('FEHLER', fehler);
  await b.close();
})();
