// Kern-Tests Investment (Node). Unabhängige Vergleichswerte aus der Recherche „Immobilien Investment und Recht Berlin“ (Spandau-Beispiel)
const I = require(require('path').join(__dirname, '../../quellen/invest24_kern.js'));
let fehler = 0; const ok = (b, t) => { if(!b){ fehler++; console.log('FEHLER:', t); } else console.log('ok  ', t); };
const nah = (a, b, tol) => a != null && Math.abs(a - b) <= (tol == null ? 0.01 : tol);

const spandau = {
  kaufpreis: 189500,
  nebenkosten: [{ name: 'Grunderwerbsteuer', art: 'prozent', wert: 6 }, { name: 'Notar/Grundbuch', art: 'prozent', wert: 2 }, { name: 'Makler', art: 'prozent', wert: 3.57 }],
  sanierung: 0, finanzierungskosten: 0, eigenkapital: 0,
  darlehenModus: 'betrag', darlehenBetrag: 189500, zins: 3.91, tilgungModus: 'prozent', tilgung: 2, zinsbindung: 10, anschlusszins: 3.91,
  miete: 625, sonstigeEinnahmen: 0, mietausfall: 2, hausgeld: null, hausgeldUmlagefaehig: null, ruecklage: 0,
  verwaltung: 35, sonstigeKosten: 0, instandhaltungModus: 'zusaetzlich', instandhaltung: 746 / 12
};
let r = I.iv24Rechnen(spandau);
ok(nah(r.nebenkosten.summe, 21925.15), 'Nebenkosten 21.925 € (GrESt 6 %, Notar 2 %, Makler 3,57 %)');
ok(nah(r.bruttomietrendite, 7500 / 189500 * 100, 1e-9) && nah(r.bruttomietrendite, 3.96, 0.005), 'Bruttomietrendite 3,96 %: ' + r.bruttomietrendite);
ok(nah(r.nettorendite, (7350 - 1166) / 211425.15 * 100, 1e-9) && nah(r.nettorendite, 2.92, 0.01), 'Nettorendite 2,92 % (Nenner Kaufpreis+NK): ' + r.nettorendite);
ok(nah(r.schuldendienstMonat * 12, 11199.45, 0.01), 'Annuität 11.199 €/Jahr');
ok(nah(r.cashflowMonat * 12, -5015.45, 0.02) && nah(r.cashflowMonat, -417.95, 0.01), 'Cashflow vor Steuern −5.015 €/Jahr (−418 €/Monat): ' + r.cashflowMonat);
ok(nah(r.finanzierungsluecke, 21925.15) && r.warnungen.some(w => /Finanzierungslücke/.test(w)), 'Finanzierungslücke = Nebenkosten (Vollfinanzierung des Kaufpreises)');
ok(r.ekRendite === null && /nicht definiert/.test(r.ekRenditeHinweis), 'Eigenkapital 0 → keine (unendliche) EK-Rendite');
// Zins Jahr 1 aus dem Monatsplan (unabhängig nachgerechnet), nicht konstant 7.409 €
let rest = 189500, zs = 0; const rate = 189500 * 0.0591 / 12;
for(let m = 0; m < 12; m++){ const z = rest * 0.0391 / 12; zs += z; rest -= rate - z; }
ok(nah(r.zinsJahr1, zs, 1e-6) && r.zinsJahr1 < 7409.45, `Zins Jahr 1 aus Monatsplan ${zs.toFixed(2)} € (< 7.409 € bei konstanter Annahme)`);
ok(nah(r.vermoegensaufbauMonat * 12 + r.zinsJahr1, 11199.45, 0.02), 'Tilgung separat als Vermögensaufbau, Zins + Tilgung = Rate');

// Hausgeldaufteilung und Instandhaltung ohne Doppelzählung
const hg = Object.assign({}, spandau, { hausgeld: 300, hausgeldUmlagefaehig: 180, ruecklage: 60, instandhaltungModus: 'gesamt', instandhaltung: 100, verwaltung: 0, mietausfall: 0 });
r = I.iv24Rechnen(hg);
ok(nah(r.kosten.hausgeldBetrieb, 60) && nah(r.kosten.instandhaltungZusaetzlich, 40) && nah(r.liquiditaetsvorsorge, 100) && nah(r.eigentuemerkosten, 60), 'Hausgeld 300 → 180 umlagefähig, 60 Rücklage, 60 Eigentümerkosten; Instandhaltung gesamt 100 → nur 40 zusätzlich');
ok(nah(r.ueberschussVorFinanzierung, 625 - 60 - 100), 'Überschuss vor Finanzierung: Hausgeld nicht pauschal abgezogen');
const hg2 = Object.assign({}, hg, { instandhaltungModus: 'zusaetzlich' }); r = I.iv24Rechnen(hg2); ok(nah(r.liquiditaetsvorsorge, 160), 'Modus „zusätzlich“: Rücklage + 100');
r = I.iv24Rechnen(Object.assign({}, hg, { hausgeldUmlagefaehig: null }));
ok(r.cashflowMonat === null && r.nettorendite === null && r.fehlend.some(f => /Aufteilung Hausgeld/.test(f)) && r.bruttomietrendite != null, 'Hausgeld ohne Aufteilung: kein Cashflow, Lücke gemeldet, Brutto weiter berechnet');
r = I.iv24Rechnen(Object.assign({}, hg, { ruecklage: 150 })); ok(r.warnungen.some(w => /Rücklage/.test(w)), 'Rücklage größer als nicht umlagefähiger Anteil → Warnung');

// Leerstand
r = I.iv24Rechnen(Object.assign({}, hg, { mietausfall: 10 }));
ok(nah(r.einnahmenNachAusfall, 625 * 0.9) && nah(r.kosten.ausfallUmlage, 18), 'Leerstand 10 %: Einnahmen −10 %, 18 € umlagefähige Kosten bleiben beim Eigentümer');

// Anschlusszins erst nach Zinsbindung
const an = Object.assign({}, spandau, { anschlusszins: 6, zinsbindung: 10, jahre: 15 });
r = I.iv24Rechnen(an);
const m120 = r.plan.monate[119], m121 = r.plan.monate[120];
ok(nah(m120.zins, r.plan.monate[118].rest * 0.0391 / 12, 1e-6) && nah(m121.zins, r.plan.restNachBindung * 0.06 / 12, 1e-6), 'Monat 120 noch 3,91 %, Monat 121 mit 6 % auf die Restschuld');
ok(r.jahre[10].schuldendienst > r.jahre[9].schuldendienst && r.cashflowNachBindungMonat < r.cashflowMonat, 'Höherer Anschlusszins senkt den Cashflow erst ab Jahr 11');
// Restschuld unabhängig
let rs = 189500; for(let m = 0; m < 120; m++){ const z = rs * 0.0391 / 12; rs -= rate - z; }
ok(nah(r.restschuldNachBindung, rs, 0.01), `Restschuld nach 10 Jahren ${Math.round(rs).toLocaleString('de-DE')} €`);

// Finanzierung „rest“ und Eigenkapital
r = I.iv24Rechnen(Object.assign({}, spandau, { darlehenModus: 'rest', eigenkapital: 50000 }));
ok(nah(r.darlehen, 211425.15 - 50000) && r.finanzierungsluecke === 0 && nah(r.ekRendite, r.cashflowMonat * 12 / 50000 * 100, 1e-9), 'Darlehen = Bedarf − EK, EK-Cashflow-Rendite definiert');

// Ziel-Cashflow nicht erreichbar
let mp = I.iv24MaxPreis(spandau, { art: 'cashflow', wert: 500 });
ok(mp.preis === null && /nicht erreichbar/.test(mp.erklaerung), 'Unerreichbarer Ziel-Cashflow wird erklärt: ' + mp.erklaerung);
// Maximaler Kaufpreis mit Gegenprobe (kaufpreisabhängige Finanzierung)
const basis = Object.assign({}, spandau, { darlehenModus: 'rest', eigenkapital: 40000, miete: 900 });
mp = I.iv24MaxPreis(basis, { art: 'cashflow', wert: -100 });
const vor = I.iv24Rechnen(Object.assign({}, basis, { kaufpreis: mp.preis })), danach = I.iv24Rechnen(Object.assign({}, basis, { kaufpreis: mp.preis + 100 }));
ok(mp.preis > 0 && vor.cashflowMonat >= -100 && danach.cashflowMonat < -100 && mp.gegenprobe.erfuellt && !mp.gegenprobe.naechsterErfuellt, `Max. Kaufpreis ${mp.preis.toLocaleString('de-DE')} €: Vorwärtsrechnung CF ${vor.cashflowMonat.toFixed(2)} ≥ −100, bei +100 € nicht mehr`);
ok(nah(vor.nebenkosten.summe, mp.preis * 0.1157, 0.01), 'Prozentuale Nebenkosten am gefundenen Preis neu berechnet');
mp = I.iv24MaxPreis(basis, { art: 'brutto', wert: 5 });
ok(mp.preis === Math.floor(900 * 12 / 0.05 / 100) * 100, 'Max. Preis für 5 % brutto = Jahresmiete / 5 %: ' + mp.preis);
mp = I.iv24MaxPreis(Object.assign({}, basis, { darlehenModus: 'betrag', darlehenBetrag: 200000 }), { art: 'cashflow', wert: -1000, finanzierungGedeckt: true });
const vk = I.iv24Rechnen(Object.assign({}, basis, { darlehenModus: 'betrag', darlehenBetrag: 200000, kaufpreis: mp.preis }));
ok(mp.preis && vk.finanzierungsluecke <= 0.5 && mp.grenzen.length === 1, 'Mit fixem Darlehen begrenzt die Finanzierungslücke den Preis: ' + mp.preis);

// Szenarien und Stress
const sz = I.iv24Szenarien(hg, I.IV24_SZENARIEN_STD);
ok(sz.length === 3 && sz[0].r.cashflowMonat < sz[1].r.cashflowMonat && sz[1].r.cashflowMonat < sz[2].r.cashflowMonat, 'Szenarien: vorsichtig < Basis < optimistisch');
ok(nah(sz[1].r.cashflowMonat, I.iv24Rechnen(hg).cashflowMonat, 1e-9), 'Basis-Szenario = Grundrechnung');
const st = I.iv24Stress(Object.assign({}, hg, { sanierung: 10000, darlehenModus: 'rest', eigenkapital: 30000, mietsteigerung: 2 }));
ok(st.faelle.find(f => f.k === 'sanierung').r.gesamtkapitalbedarf > st.basis.gesamtkapitalbedarf && nah(st.faelle.find(f => f.k === 'anschluss').r.cashflowMonat, st.basis.cashflowMonat, 1e-9) && st.faelle.find(f => f.k === 'anschluss').r.cashflowNachBindungMonat < st.basis.cashflowNachBindungMonat, 'Stress: Sanierung erhöht Bedarf; Anschlusszins wirkt erst nach Zinsbindung');
ok(st.faelle.find(f => f.k === 'keineSteigerung').r.jahre[5].einnahmen < st.basis.jahre[5].einnahmen, 'Stress „keine Mietsteigerung“ senkt spätere Einnahmen');

// Potenzial: ungesichert, Leerstandsphase
const pot = Object.assign({}, hg, { potenzial: { miete: 750, massnahmen: 20000, zeitbedarfMonate: 3, leerstandMonate: 3, rechtlichGeklaert: 'unbekannt', pruef: 'ungeprueft' } });
const rp = I.iv24Rechnen(pot, 'potenzial'), ri = I.iv24Rechnen(pot, 'ist');
ok(rp.potenzialGesichert === false && rp.warnungen.some(w => /nicht als gesicherte Einnahme/.test(w)) && rp.sanierung === 20000 && ri.sanierung === 0, 'Potenzial getrennt: Maßnahmen nur dort, rechtlich ungeklärt → Warnung');
ok(nah(rp.cashflowJahr1, rp.cashflowMonat * 12 - 3 * 750 - 3 * 180), 'Leerstandsphase im ersten Jahr abgezogen (3 Monate Miete + Umlagen)');

// Profil
const pr = I.iv24ProfilPruefen({ kriterien: { objektarten: { werte: ['Wohnung'], muss: true }, regionen: { werte: ['Spandau'], muss: false }, cashflow: { wert: 0, muss: true }, vermietung: { wert: 'vermietet', muss: false } } }, { objektart: 'Wohnung', ort: '13597 Berlin-Spandau', vermietung: 'unbekannt' }, I.iv24Rechnen(spandau));
ok(pr.liste.find(x => x.k === 'cashflow').status === 'nein' && pr.mussVerletzt === 1 && pr.liste.find(x => x.k === 'vermietung').status === 'unbekannt', 'Ankaufprofil: Muss-Kriterium Cashflow verletzt, Vermietung unbekannt, kein Score');
ok(I.iv24UnterlagenListe('Wohnung').some(x => /Wirtschaftsplan/.test(x)) && I.iv24UnterlagenListe('MFH').some(x => /Mietaufstellung/.test(x)), 'Unterlagenliste je Objektart');
console.log('FEHLER', fehler);
