const P = require('/tmp/pc/app/vendor/pdf-lib.min.js'), fs = require('fs');
const src = fs.readFileSync('/tmp/jvb/katalog43.js', 'utf8').replace('const GA43_KAT', 'global.GA43_KAT'); eval(src);
const { ga44FragebogenErstellen } = require('/tmp/jvb/fragebogen44.js');
const arten = [['EFH','Einfamilienhaus'],['DHH','Doppelhaushälfte'],['RMH','Reihenmittelhaus'],['REH','Reihenendhaus'],['RH','Reihenhaus (ohne nähere Angabe)'],['ZFH','Zweifamilienhaus'],['MFH','Mehrfamilienhaus'],['ETW','Eigentumswohnung'],['WGH','Wohn- und Geschäftshaus'],['Grundstueck','Unbebautes Grundstück'],['Gewerbe','Gewerbeobjekt']];
const unterlagen = ['Grundbuchauszug','Flurkarte','Baubeschreibung / Bauakte','Grundrisse','Wohnflächenberechnung','BGF-/wGF-Berechnung','Energieausweis','Modernisierungsrechnungen','Besichtigungsprotokoll','Gutachten','Mietverträge','WEG-Unterlagen','Baulastenauskunft','Denkmalauskunft','Weitere amtliche Auskünfte'].map(x => ['', x]);
ga44FragebogenErstellen({ PDFLib: P, kat: GA43_KAT, arten, unterlagen, art: 'EFH', objektId: 'k1', titel: 'Königsheideweg', adresse: 'Königsheideweg 190, 12487 Berlin', absender: 'Görner Immobilien', dachBild: fs.readFileSync('/tmp/v44/dachformen_600.jpg') })
 .then(b => { fs.writeFileSync('/tmp/v44/Objekt-Fragebogen-Vorschau.pdf', b); console.log('ok', b.length); }).catch(e => { console.error(e); process.exit(1); });
