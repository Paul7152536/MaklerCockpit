// v34 Smoke im echten Electron (gepackter Code): beschädigte daten.json, Absturz der Oberfläche, Import, doppelte ids, Sicherung
const { app, BrowserWindow } = require('electron'); const fs = require('fs'); const path = require('path');
const BASIS = '/tmp/claude-0/-home-claude/fcfe88c9-293d-574d-8cfa-b1821c923895/scratchpad/etest';
const HOME = BASIS + '/home48';
fs.rmSync(HOME, { recursive: true, force: true });
const ORD = HOME + '/Dokumente/MaklerCockpit', BK = ORD + '/backups';
fs.mkdirSync(BK, { recursive: true });
// Vorbereitung: gestrige gute Sicherung, heutige daten.json kaputt (halb geschrieben)
const gut = { objekte: [{ id: 'o1', akqTitel: 'Aus der Sicherung', status: 'neu', verlauf: [] }, { id: 'o1', akqTitel: 'Zweiter mit gleicher id', status: 'neu', verlauf: [] }], kontakte: [], termine: [], aufgaben: [], notizen: [], marktanalysen: [], mentorFragen: [], meta: { v9neustart: { quittiert: true } } };
fs.writeFileSync(BK + '/daten-2026-11-10.json', JSON.stringify(gut));
fs.writeFileSync(BK + '/daten-2026-11-09.json', JSON.stringify({ objekte: [], kontakte: [] }));
fs.writeFileSync(ORD + '/daten.json', JSON.stringify(gut).slice(0, 120));
app.setPath('documents', HOME + '/Dokumente');
const fehlerLog = [];
app.on('web-contents-created', (e, wc) => wc.on('console-message', (...a) => { const ev = a[0]; const lvl = ev && ev.level !== undefined ? ev.level : a[1]; const msg = ev && ev.message !== undefined ? ev.message : a[2]; if((lvl === 3 || lvl === 'error') && !/ERR_|Failed to load resource|Oberfläche abgestürzt/.test(msg)) fehlerLog.push(msg); }));
require(process.env.MC_MAIN || '/tmp/pc/app/main.js');
const warte = ms => new Promise(r => setTimeout(r, ms));
app.whenReady().then(() => setTimeout(async () => {
  let f = 0; const ok = (b, t) => { console.log((b ? 'ok   ' : 'FEHL ') + t); if(!b) f++; };
  try{
    let w = BrowserWindow.getAllWindows()[0]; const js = s => w.webContents.executeJavaScript(s);
    const logo = await js(`(document.querySelector('.sb-logo') || {}).textContent + ' | ' + (document.body.innerText.match(/PC-Version v\\d+/) || [''])[0]`); ok(/v48/.test(logo), "v48 startet: " + logo);
    const r = JSON.parse(await js(`JSON.stringify({ n: db.objekte.length, ids: db.objekte.map(o => o.id), t: db.objekte[0].akqTitel, modal: (document.getElementById('modalInner') || {}).innerText || '' })`));
    ok(r.n === 2 && r.t === 'Aus der Sicherung', 'Beschädigte daten.json → neueste gute Sicherung (10.11.) geladen');
    ok(r.ids[0] === 'o1' && r.ids[1] === 'o1_2', 'Doppelte id aus der Sicherung repariert: ' + r.ids.join(','));
    if(!/beschädigt/.test(r.modal)) console.log('MODAL:', JSON.stringify(r.modal).slice(0, 300));
    ok(/beschädigt/.test(r.modal) && /10\.11\.2026/.test(r.modal), 'Hinweis „Datendatei war beschädigt“ mit Datum');
    const kaputt = fs.readdirSync(BK).filter(n => /^beschaedigt-/.test(n));
    ok(kaputt.length === 1 && fs.readFileSync(BK + '/' + kaputt[0], 'utf8').length === 120, 'Beschädigte Datei aufbewahrt: ' + kaputt[0]);
    const heute = (() => { const d = new Date(); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); })();
    ok(!fs.existsSync(BK + '/daten-' + heute + '.json'), 'Kaputte Datei wurde NICHT als heutige Tagessicherung abgelegt');
    await js('schliesseModal()'); await warte(600);
    const mp = JSON.parse(await js(`(() => { const o = db.objekte[0]; o.ort = '10365 Berlin'; o.wohnflaeche = 68; o.baujahr = 1965; o.objektart = 'Wohnung'; const x = mp37Rechnen(o, null); return JSON.stringify({ ovm: x.ovm, g: x.grenzeBremse, t: mp37Prompt('').length, st: x.status.code, ibb: x.ibb && x.ibb.mittel, p: /typ=mietvergleiche/.test(mp38Prompt(o.id)), q: MP38K.quantil([10, 10.5, 11, 11.5, 12, 12, 12.5, 13, 14, 16], 0.25) }); })()`));
    ok(JSON.stringify(await js(`window.pc.google('koppeln', 'MC1-kaputt').then(r => r.ok === false && /gültiger/.test(r.fehler))`)) === 'true', 'v41: Koppeln mit Code im echten Programm (Hauptprozess) – ungültiger Code abgelehnt');
    ok(await js(`typeof GA43_KAT === 'object' && GA43_KAT.length === 26 && GA43_KAT.reduce((s, g) => s + g.f.length, 0) === 205 && typeof ga43PreisPrompt === 'function'`) === true, 'v43: Auswahlkatalog (26 Gruppen, 205 Felder) und Preis-Analyse im echten Programm');
    ok(await js(`(() => { GA35.obj = db.objekte[0].id; const e = ga35Entwurf(GA35.obj); e.art = 'EFH'; wechsleAnsicht('grossanalyse'); return document.querySelectorAll('.ga43-gruppe').length > 20 && !!document.querySelector('.ga43-preisknopf') && /IMMER einen Preis/.test(ga43PreisPrompt(GA35.obj, e).text); })()`) === true, 'v43: Große Analyse mit Auswahlfeldern und Preis-Knopf rendert');
    ok(await js(`(async () => { const id = db.objekte[0].id, e = ga35Entwurf(id); wechsleAnsicht('grossanalyse'); const b = await ga44PdfBytes(id, e); const d = await PDFLib.PDFDocument.load(b); return document.querySelectorAll('.ga44-bogen .ga44-sek').length === 9 && document.querySelectorAll('.ga44-bogen .ga44-dt').length === 9 && d.getForm().getFields().length > 230 && /MaklerCockpit-Fragebogen/.test(d.getKeywords()); })()`) === true, 'v44: Fragebogen-Aufbau, Dachform-Bilder und ausfüllbares PDF im echten Programm');
    ok(await js(`(() => { const o = db.objekte[0]; o.link = 'https://www.kleinanzeigen.de/s-anzeige/x/1'; MC24.akteId = o.id; wechsleAnsicht('akte'); return !!document.querySelector('.aq-kopf .ak45-inserat') && !!document.getElementById('ak45Notiz'); })()`) === true, 'v45: Objektakte mit Inserat-Link und Notizfeld im echten Programm');
    ok(await js(`typeof ga46KarteHtml === 'function' && /hv46Mail/.test(HV_HTML)`) === true, 'v46: Shooting-Karte und Mail-Knopf der Hausverwaltungen im echten Programm');
    ok(await js(`typeof ak47Planen === 'function' && OBJEKT_STATUS.some(s => s[0] === 'telefontermin') && AN31_TAGE === 14 && typeof pl47Stufe === 'function' && typeof vb47Abgleichen === "function" && typeof ek48Zusammenfuegen === "function" && ak47Zeit() === "08:00"`) === true, 'v47: Anrufliste, Telefontermin und 2-Wochen-Regel im echten Programm');
    ok(await js(`typeof ab41KoppelDialog === 'function' && typeof ab25IstHaupt === 'function'`) === true, 'v41: Geräte-Kopplung im echten Programm');
    ok(await js(`typeof ga40Html === 'function' && ga40Html().includes('__GA40_HOST') && ga40Html().includes('ga40Werte')`) === true, 'v40: Shooting-Werkzeug für die Große Analyse im echten Programm');
    ok(await js(`typeof ga39Prompt === 'function' && typeof ga39Import === 'function'`) === true, 'v39: Vergleichsfälle-Prompt im echten Programm');
    ok(mp.st && mp.ibb === 13.71 && mp.p && Math.abs(mp.q - 11.125) < 1e-9, 'v38: Status, IBB-Daten, Vergleichs-Prompt, Quantil im echten Programm');
    ok(mp.ovm > 5 && mp.g > mp.ovm && mp.t > 1500, 'Mietpotenzial im echten Programm: ' + JSON.stringify(mp));
    const neu = JSON.parse(fs.readFileSync(ORD + '/daten.json', 'utf8'));
    ok(neu.objekte.length === 2 && neu.objekte[1].id === 'o1_2', 'daten.json wieder gültig gespeichert (repariert)');
    // zweiter Start: kein Hinweis mehr
    await js('location.reload()'); await warte(3000); w = BrowserWindow.getAllWindows()[0];
    ok(await js(`!document.getElementById('modalBg').classList.contains('show')`), 'Neustart: kein Hinweis mehr (Datei ist wieder gut)');
    // Absturz der Oberfläche → lädt sich selbst neu
    await js(`db.objekte.push({ id: uid(), akqTitel: 'Vor dem Absturz', status: 'neu', verlauf: [] }); _schreibe(); window.__vorAbsturz = 1;`);
    w.webContents.forcefullyCrashRenderer();
    await warte(4500); w = BrowserWindow.getAllWindows()[0];
    const nach = JSON.parse(await w.webContents.executeJavaScript(`JSON.stringify({ alt: !!window.__vorAbsturz, n: db.objekte.length, logo: document.querySelector('.sb-logo').textContent })`));
    ok(!nach.alt && nach.n === 3 && /v48/.test(nach.logo), 'Oberfläche abgestürzt → von selbst neu geladen, Daten da ' + JSON.stringify(nach));
    // Import: atomar, Sicherung vorher
    const vorImp = fs.readdirSync(BK).filter(n => /^vor-import-/.test(n)).length;
    const imp = await w.webContents.executeJavaScript(`window.pc.importieren(JSON.stringify({ objekte: [{ id: 'x1', akqTitel: 'Import' }], kontakte: [] }))`);
    ok(imp.ok && fs.readdirSync(BK).filter(n => /^vor-import-/.test(n)).length === vorImp + 1 && !fs.existsSync(ORD + '/daten.json.tmp') && JSON.parse(fs.readFileSync(ORD + '/daten.json', 'utf8')).objekte[0].id === 'x1', 'Import: vorher gesichert, sauber geschrieben (keine .tmp übrig)');
    // Tagessicherung: gültig, nach Ortszeit benannt
    ok(fs.readdirSync(BK).some(n => n === 'daten-' + heute + '.json') === false || JSON.parse(fs.readFileSync(BK + '/daten-' + heute + '.json', 'utf8')), 'Tagessicherung (falls schon angelegt) ist gültig');
    // ladeHinweis-Schnittstelle liefert danach nichts mehr
    ok(await w.webContents.executeJavaScript('window.pc.ladeHinweis() === null'), 'Hinweis wird nur einmal gemeldet');
  }catch(e){ console.log('FEHLER', e && e.stack || e); f++; }
  ok(fehlerLog.length === 0, 'Keine Konsolenfehler ' + JSON.stringify(fehlerLog.slice(0, 3)));
  console.log('FEHLER', f); app.exit(0);
}, 3500));
