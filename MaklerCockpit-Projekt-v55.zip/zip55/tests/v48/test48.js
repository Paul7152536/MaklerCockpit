// v48: Telefontermin-Erstkontakt 8:00 · 15 Min · ein Kalendereintrag je Tag; vorhandene Termine werden automatisch zusammengefügt
const { chromium } = require('playwright');
let f = 0; const ok = (b, t) => { console.log((b ? 'ok   ' : 'FEHL ') + t); if(!b) f++; };
const T = 864e5, jetzt = Date.now();
const dk = n => { const d = new Date(); d.setDate(d.getDate() + n); if(n > 0 && d.getDay() === 0) d.setDate(d.getDate() + 1); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); };
const lead = (id, x) => Object.assign({ id, objektart: 'Wohnung', ort: '12487 Berlin', status: 'kleinanzeigen_geschrieben', quelle: 'Kleinanzeigen', createdAt: jetzt - 2 * T, verlauf: [] }, x);
const D = JSON.stringify({ objekte: [
  lead('a', { akqTitel: 'Silberstein 82 Dachgeschoss', verkaeuferTelefon: '017648845539', verkaeuferName: 'Herr A', link: 'https://www.kleinanzeigen.de/s-anzeige/a/1' }),
  lead('b', { akqTitel: 'Grünauer Str. 54', verkaeuferTelefon: '0151 17460378' }),
  lead('c', { akqTitel: 'Nachfass-Lead', verkaeuferTelefon: '0160 1234567', status: 'erstkontakt', telefonArt: 'nachfassen' }),
  lead('d', { akqTitel: 'Neuer Lead für Knopf', verkaeuferTelefon: '0170 7777777', verkaeuferName: 'Frau D', link: 'https://www.kleinanzeigen.de/s-anzeige/d/4' }),
  lead('e', { akqTitel: 'Ohne Nummer' })],
  kontakte: [],
  termine: [
    { id: 'x1', titel: 'Rückruf Silberstein', datum: dk(1), uhrzeit: '10:00', dauer: 15, art: 'rueckruf', objektId: 'a', googleEventId: 'gev1', notiz: 'nach 17 Uhr besser' },
    { id: 'x2', titel: 'Anruf Grünau', datum: dk(1), uhrzeit: '14:30', dauer: 30, art: 'termin', wo: 'telefon', objektId: 'b' },
    { id: 'x3', titel: 'Telefontermin Nachfassen', datum: dk(1), uhrzeit: '16:00', art: 'rueckruf', objektId: 'c' },
    { id: 'x4', titel: 'Besichtigung', datum: dk(1), uhrzeit: '11:00', art: 'besichtigung', objektId: 'b' },
    { id: 'anrufliste-' + dk(2), titel: 'alt', datum: dk(2), uhrzeit: '09:00', dauer: 30, art: 'rueckruf', anrufliste: true, notiz: 'alt' }],
  aufgaben: [], notizen: [], googleSync: { bekannt: { gev1: 'x1' } }, meta: { v9neustart: { quittiert: true } } });
(async () => {
  const b = await chromium.launch();
  for(const [g, w, h] of [['pc', 1440, 900], ['handy', 412, 915]]){
    const p = await b.newPage({ viewport: { width: w, height: h }, isMobile: g === 'handy' });
    p.fe = []; p.on('pageerror', e => p.fe.push(e.message));
    await p.addInitScript(([d, g]) => { window.pc = { geraet: g, laden: () => JSON.parse(d), speichern: () => ({ ok: true }), ordner(){}, sicherungSchreiben: () => ({ ok: true }), sicherungLesen: () => null }; }, [D, g]);
    await p.goto('file:///tmp/pc/app/index.html'); await p.waitForTimeout(2800);
    await p.evaluate(() => { try{ schliesseModal(); }catch(e){} const k = document.getElementById('an31Karte'); if(k) k.remove(); });
    const m1 = await p.evaluate((m) => ({ ids: db.termine.map(t => t.id).sort(), al: db.termine.find(t => t.id === 'anrufliste-' + m), a: findObjekt('a'), zus: (db.googleSync || {}).zusammen || {}, alt2: db.termine.find(t => /anrufliste-/.test(t.id) && t.titel === 'alt') }), await p.evaluate(() => ak47Morgen()));
    ok(!m1.ids.includes('x1') && !m1.ids.includes('x2'), g + ': vorhandene Erstkontakt-Telefontermine automatisch zusammengefügt (' + m1.ids.join(',') + ')');
    ok(m1.ids.includes('x3') && m1.ids.includes('x4'), g + ': Nachfassen-Telefontermin und Besichtigung bleiben eigene Termine');
    ok(m1.al && m1.al.uhrzeit === '08:00' && m1.al.dauer === 30 && /Anrufen: 2 Telefontermine/.test(m1.al.titel), g + ': EIN Kalendereintrag 08:00, 2×15 Min (' + (m1.al && [m1.al.titel, m1.al.uhrzeit, m1.al.dauer].join(' | ')) + ')');
    ok(m1.al && m1.al.notiz === 'Silberstein 82 Dachgeschoss – Herr A – 017648845539\nGrünauer Str. 54 – 0151 17460378', g + ': im Kalender nur Objekt – Name – Telefon (' + (m1.al && JSON.stringify(m1.al.notiz)) + ')');
    ok(m1.zus.gev1 > 0, g + ': Google-Termin zum Löschen vorgemerkt (ohne Rückfrage)');
    ok(m1.a.status === 'telefontermin' && m1.a.telefonArt === 'erstkontakt' && (m1.a.verlauf || []).some(v => /nach 17 Uhr besser/.test(v.text)), g + ': Lead: Status Telefontermin · Erstkontakt, Notiz übernommen');
    ok(!m1.alt2, g + ': alte Anrufliste (09:00) aufs neue Format gebracht');
    // ── Knopf im Termin-Dialog ──
    await p.evaluate(() => { wechsleAnsicht('akquise'); AQ2.status = 'alle'; AQ2.sel = 'd'; aq2Liste(); aq2TerminNeu('besichtigung'); }); await p.waitForTimeout(300);
    const pos = await p.evaluate(() => { const k = document.getElementById('ek48Knopf'), tw = document.querySelector('#modalInner .tw-box'); return !!k && !!tw && tw.nextElementSibling === k; });
    ok(pos, g + ': Knopf „Telefontermin – Erstkontakt“ direkt unter Telefon/Vor Ort');
    await p.evaluate(() => ek48Waehlen()); await p.waitForTimeout(150);
    const dlg = await p.evaluate(() => ({ zeit: document.getElementById('tq_zeit').value, dauer: document.getElementById('tq_dauer').value, art: AQ_TQ.art, hin: document.getElementById('ek48Hinweis').innerText }));
    ok(dlg.zeit === '08:00' && dlg.dauer === '15' && dlg.art === 'rueckruf' && /Frau D/.test(dlg.hin), g + ': 08:00, 15 Min, Telefontermin vorbelegt (' + JSON.stringify(dlg).slice(0, 160) + ')');
    await p.evaluate(() => { document.getElementById('tq_datum').value = ak47Morgen(); aq2TerminAnlegen(); }); await p.waitForTimeout(300);
    const m2 = await p.evaluate(() => { const m = ak47Morgen(); return { al: db.termine.find(t => t.id === 'anrufliste-' + m), einzeln: db.termine.filter(t => t.objektId === 'd').length, d: findObjekt('d') }; });
    ok(m2.einzeln === 0 && m2.al && /3 Telefontermine/.test(m2.al.titel) && m2.al.dauer === 45 && /Neuer Lead für Knopf – Frau D – 0170 7777777/.test(m2.al.notiz), g + ': Knopf → in denselben Kalendereintrag (' + (m2.al && m2.al.titel) + ')');
    ok(m2.d.anrufTag && m2.d.telefonArt === 'erstkontakt' && m2.d.status === 'telefontermin', g + ': Lead d: Telefontermin · Erstkontakt');
    // ohne Nummer → Hinweis, nichts angelegt
    await p.evaluate(() => { AQ2.sel = 'e'; aq2TerminNeu('besichtigung'); ek48Waehlen(); document.getElementById('tq_datum').value = ak47Morgen(); aq2TerminAnlegen(); }); await p.waitForTimeout(200);
    ok(await p.evaluate(() => !findObjekt('e').anrufTag && document.getElementById('modalBg').classList.contains('show')), g + ': ohne Telefonnummer wird nichts angelegt, Dialog bleibt offen');
    await p.evaluate(() => { document.getElementById('tq_ort').value = 'Tel 0157 3333333'; aq2TerminAnlegen(); }); await p.waitForTimeout(200);
    ok(await p.evaluate(() => findObjekt('e').verkaeuferTelefon === '0157 3333333' && findObjekt('e').anrufTag === ak47Morgen()), g + ': Nummer aus „Ort“ übernommen und eingeplant');
    // ── Anrufliste im Cockpit mit Link ──
    await p.evaluate(() => oeffneTerminModal('anrufliste-' + ak47Morgen())); await p.waitForTimeout(200);
    const li = await p.evaluate(() => document.getElementById('modalInner').innerText);
    ok(/Anrufliste/.test(li) && /Inserat öffnen/.test(li) && /Erstkontakt/.test(li) && /Frau D/.test(li), g + ': Kalendereintrag öffnet die Anrufliste mit Link und Erstkontakt');
    // ── Später angelegter Telefontermin über den normalen Dialog wird auch zusammengefügt ──
    await p.evaluate(() => { schliesseModal(); db.termine.push({ id: 'x9', titel: 'Telefonat', datum: ak47Morgen(), uhrzeit: '13:00', art: 'rueckruf', objektId: 'b' }); findObjekt('b').anrufTag = ''; save(); }); await p.waitForTimeout(700);
    ok(await p.evaluate(() => !db.termine.some(t => t.id === 'x9') && findObjekt('b').anrufTag === ak47Morgen()), g + ': neuer Telefontermin (Erstkontakt) wird beim Speichern sofort zusammengefügt');
    ok(!p.fe.length, g + ': keine JS-Fehler ' + p.fe.slice(0, 3).join(' | '));
    await p.close();
  }
  await b.close(); console.log(f ? 'FEHLER ' + f : 'ALLES OK'); process.exit(f ? 1 : 0);
})();
