// v46: Shooting-Übernahme oben gesondert + Hausverwaltungen: Anschreiben per Knopf in Outlook (mailto)
const { chromium } = require('playwright');
let f = 0; const ok = (b, t) => { console.log((b ? 'ok   ' : 'FEHL ') + t); if(!b) f++; };
const D = JSON.stringify({ objekte: [{ id: 'k1', akqTitel: 'EFH Königsheideweg', objektart: 'Einfamilienhaus', status: 'akquise', verlauf: [] }, { id: 'k2', akqTitel: 'Alt-Entwurf', objektart: 'Einfamilienhaus', status: 'akquise', verlauf: [] }],
  kontakte: [], termine: [], aufgaben: [], notizen: [], meta: { v9neustart: { quittiert: true } },
  grossanalyse: { entwuerfe: { k2: { v43: 1, art: 'EFH', region: 'Berlin', stichtag: '2026-11-17', unterlagen: {}, notiz: '', gruppen43: {}, alt43: {}, schnell: { stand: '2026-11-15', typ: 'haus', vergleich: { wert: 700000, mittelpreis: 4200, anzahl: 4, werte: [] } },
    vergleich: [{ art: 'listing', lage: 'Baumschulenweg', preis: '4100', preisbasis: 'EUR/m² Wfl (Portal-Preisatlas, Angebotsbasis)', quelle: 'Homeday Preisatlas (Schnellbewertung)' }, { art: 'purchase', lage: 'Eigener Abschluss', preis: '650000', flaeche: '150', quelle: 'eigene Akte' }],
    werte: { wfl: { v: '164', s: 'assumed' }, grund: { v: '716', s: 'owner_statement', q: 'Eigentümerangabe' } } } }, laeufe: [] },
  hv: { verwaltungen: [{ id: 'h1', name: 'Muster Hausverwaltung GmbH', ansprechpartner: 'Frau Schulz', telefon: '030 1234567', status: 'interesse', letzterAnruf: Date.now(), bezirk: 'Treptow-Köpenick' }, { id: 'h2', name: 'Ohne Ansprech GmbH', ansprechpartner: '', telefon: '030 999', status: 'rueckruf', email: 'info@ohne.de' }] } });
(async () => {
  const b = await chromium.launch();
  for(const [g, w, h] of [['pc', 1440, 900], ['handy', 412, 915]]){
    const p = await b.newPage({ viewport: { width: w, height: h }, isMobile: g === 'handy' });
    p.fe = []; p.on('pageerror', e => p.fe.push(e.message)); p.on('dialog', d => { p.dialog = d.message(); d.dismiss(); });
    await p.addInitScript(d => { window.pc = { geraet: 'pc', laden: () => JSON.parse(d), speichern: () => ({ ok: true }), ordner(){}, sicherungSchreiben: () => ({ ok: true }), sicherungLesen: () => null, gekoppelt: () => true, google: async () => ({ ok: false }) }; window.__offen = []; window.open = u => { window.__offen.push(u); return null; }; }, D);
    await p.goto('file:///tmp/pc/app/index.html'); await p.waitForTimeout(2200);
    await p.evaluate(() => { try{ schliesseModal(); }catch(e){} GA35.obj = 'k1'; wechsleAnsicht('grossanalyse'); }); await p.waitForTimeout(400);
    ok(await p.evaluate(() => !document.querySelector('.ga46')), g + ': ohne Übernahme keine Shooting-Karte');
    // Übernahme simulieren (wie Dialog „Übernehmen“ in der Schnellbewertung)
    await p.evaluate(() => {
      window.__ga40Liste = [{ k: 'ergebnis', ergebnis: { stand: '2026-11-18', typ: 'haus', vergleich: { wert: 736804.4, mittelpreis: 4318.2, anzahl: 6, formel: 'x', werte: [] }, ertrag: { ertragswert: 690000, rohertrag: 31000 } } },
        { k: 'ins1', fall: { art: 'listing', datum: '', lage: 'Johannisthal, Eisenhutweg 8', preis: '793000', preisbasis: '', flaeche: '167', flaeche_art: 'Wfl', quelle: 'Schnellbewertung (Inserat)' } },
        { k: 'feld_baujahr', feld: ['baujahr', '2009'] }, { k: 'feld_wfl', feld: ['wfl', '164'] }];
      const d = document.createElement('div'); d.id = 'fakeListe'; d.innerHTML = [0, 1, 2, 3].map(i => `<input type="checkbox" data-ga40="${i}" checked>`).join(''); document.body.appendChild(d);
      ga40Uebernehmen(); d.remove();
    }); await p.waitForTimeout(400);
    const k = await p.evaluate(() => { const c = document.querySelector('.ga46'); const gitter = document.querySelector('.ga35-gitter'); return c && { text: c.innerText, vorGitter: !!(gitter && (c.compareDocumentPosition(gitter) & Node.DOCUMENT_POSITION_FOLLOWING)), e: JSON.parse(JSON.stringify(ga35Entwurf('k1'))) }; });
    ok(k && k.vorGitter, g + ': Karte „⚡ Aus der Shooting-Analyse übernommen“ steht oben (vor Lage & Co.)');
    ok(k && /736\.804 €/.test(k.text) && /690\.000 €/.test(k.text) && /Ø 4\.318 €\/m²/.test(k.text), g + ': Ergebnisse: Vergleichswert, Ertragswert, Ø €/m²');
    ok(k && /Baujahr: 2009/.test(k.text) && /Wohnfläche[^:]*: 164 m²/.test(k.text) && /1 Vergleichsfall\b/.test(k.text) && /Johannisthal, Eisenhutweg(?! 8)/.test(k.text), g + ': Eckdaten (Annahme) und Vergleichsfall gelistet, Hausnummer ausgeblendet');
    ok(k && k.e.werte.baujahr.von === 'shooting' && k.e.vergleich[0].von === 'shooting' && k.e.shooting46.felder.length === 2, g + ': Übernahme markiert (von: shooting)');
    ok(await p.evaluate(() => [...document.querySelectorAll('.ga44-bogen .ga46-badge')].length >= 2), g + ': übernommene Felder in den Objektdaten mit „⚡ Shooting“ markiert');
    await p.click('.ga46-kopf'); await p.waitForTimeout(300);
    ok(await p.evaluate(() => !document.querySelector('.ga46-kacheln') && /▸/.test(document.querySelector('.ga46-pfeil').textContent)), g + ': Karte lässt sich zuklappen');
    await p.click('.ga46-kopf'); await p.waitForTimeout(300);
    ok(await p.evaluate(() => !!document.querySelector('.ga46-kacheln')), g + ': … und wieder aufklappen');
    // älterer Entwurf ohne Markierung
    await p.evaluate(() => { GA35.obj = 'k2'; ga35Neuzeichnen(); }); await p.waitForTimeout(300);
    const alt = await p.evaluate(() => (document.querySelector('.ga46') || {}).innerText || '');
    ok(/700\.000 €/.test(alt) && /Wohnfläche[^:]*: 164 m²/.test(alt) && /1 Vergleichsfall\b/.test(alt) && !/Grundstück/.test(alt) && !/Eigener Abschluss/.test(alt), g + ': älterer Entwurf: Shooting-Daten erkannt, eigene Angaben/Abschlüsse nicht');
    if(g === 'pc'){ await p.evaluate(() => { GA35.obj = 'k1'; ga35Neuzeichnen(); document.querySelector('.ga46').scrollIntoView({ block: 'start' }); window.scrollBy(0, -70); }); await p.waitForTimeout(200); await p.screenshot({ path: '/tmp/v45/v46_shooting_pc.png' }); }
    else { await p.evaluate(() => { GA35.obj = 'k1'; ga35Neuzeichnen(); document.querySelector('.ga46').scrollIntoView({ block: 'start' }); }); await p.waitForTimeout(200); await p.screenshot({ path: '/tmp/v45/v46_shooting_handy.png' }); }
    // ── Hausverwaltungen ──
    await p.evaluate(() => wechsleAnsicht('hausverwaltungen')); await p.waitForTimeout(1200);
    const fr = p.frame({ url: /about:srcdoc/ }) || p.frames().find(x => x !== p.mainFrame());
    await fr.evaluate(() => oeffneHVModal('h1')); await fr.waitForTimeout(200);
    ok(await fr.evaluate(() => !!document.querySelector('.hv46-mail #h_mail_schnell') && /Anschreiben in Outlook öffnen/.test(document.querySelector('.hv46-mail').innerText)), g + ': HV ohne E-Mail: Eingabefeld + Knopf „Anschreiben in Outlook öffnen“');
    await fr.click('.hv46-mail button'); await fr.waitForTimeout(200);
    ok(/E-Mail-Adresse/.test(p.dialog || '') && (await p.evaluate(() => window.__offen.length)) === 0, g + ': ohne gültige Adresse kein Öffnen, Hinweis');
    await fr.fill('#h_mail_schnell', 'vermietung@muster-hv.de');
    await fr.fill('#h_notizen', 'Will Unterlagen per Mail');
    await fr.click('.hv46-mail button'); await fr.waitForTimeout(300);
    const url = await p.evaluate(() => window.__offen.pop());
    const dec = s => decodeURIComponent(s);
    ok(/^mailto:vermietung@muster-hv\.de\?subject=/.test(url), g + ': mailto an vermietung@muster-hv.de');
    const body = dec(url.split('&body=')[1]), betreff = dec(url.split('subject=')[1].split('&')[0]);
    ok(betreff === 'Vermietung – wie telefonisch besprochen' && /^Guten Tag Frau Schulz,\r\n\r\nvielen Dank für das freundliche Telefonat heute\./.test(body) && /1,79 Nettokaltmieten/.test(body) && /Paul Görner/.test(body) && /\r\n/.test(body), g + ': Betreff + fertiges Anschreiben (Anrede, „heute“, Konditionen, Gruß)');
    const hv = await p.evaluate(() => JSON.parse(JSON.stringify(db.hv.verwaltungen.find(x => x.id === 'h1'))));
    ok(hv.email === 'vermietung@muster-hv.de' && hv.mailAm && /Will Unterlagen per Mail\n✉️ Anschreiben per Mail geöffnet/.test(hv.notizen), g + ': Adresse gespeichert, Notiz „Anschreiben per Mail geöffnet“ ergänzt, Gesprächsnotiz erhalten');
    ok(await fr.evaluate(() => /vermietung@muster-hv\.de/.test(document.querySelector('.hv46-mail').innerText) && /zuletzt geöffnet/.test(document.querySelector('.hv46-mail').innerText) && document.getElementById('h_mail').value === 'vermietung@muster-hv.de'), g + ': Dialog zeigt Adresse und „zuletzt geöffnet“, E-Mail auch in den Stammdaten');
    // ohne Ansprechpartner + eigene Vorlage
    await fr.evaluate(() => oeffneHVModal('h2')); await fr.waitForTimeout(200);
    await fr.click('.hv46-mail a'); await fr.waitForTimeout(200);
    await fr.fill('#hv46Text', 'Betreff: Kooperation {firma}\n\n{anrede}\n\nkurz wie besprochen{wann}.\n\nGruß Paul');
    await fr.click('#modalInner button:has-text("Speichern")'); await fr.waitForTimeout(200);
    await fr.click('.hv46-mail button'); await fr.waitForTimeout(300);
    const u2 = await p.evaluate(() => window.__offen.pop()), b2 = dec(u2.split('&body=')[1]), s2 = dec(u2.split('subject=')[1].split('&')[0]);
    ok(/^mailto:info@ohne\.de/.test(u2) && s2 === 'Kooperation Ohne Ansprech GmbH' && /^Sehr geehrte Damen und Herren,\r\n\r\nkurz wie besprochen\./.test(b2), g + ': eigene Vorlage mit {firma}; ohne Ansprechpartner „Sehr geehrte Damen und Herren“');
    ok(await p.evaluate(() => typeof db.hv.mailVorlage === 'string' && /Kooperation \{firma\}/.test(db.hv.mailVorlage)), g + ': Vorlage im Cockpit gespeichert (wird mit abgeglichen)');
    if(g === 'pc'){ await fr.evaluate(() => oeffneHVModal('h1')); await fr.waitForTimeout(200); await p.screenshot({ path: '/tmp/v45/v46_hv_pc.png' }); }
    else { await fr.evaluate(() => oeffneHVModal('h1')); await fr.waitForTimeout(200); await p.screenshot({ path: '/tmp/v45/v46_hv_handy.png' }); }
    ok(p.fe.length === 0, g + ': keine Fehler ' + p.fe.join(' | '));
    await p.close();
  }
  await b.close();
  console.log(f ? `${f} FEHLER` : 'ALLES OK'); process.exit(f ? 1 : 0);
})();
