// v32: Autostart im echten Programm (Windows-Autostart nachgebildet)
const { app, BrowserWindow } = require('electron'); const fs = require('fs'); const path = require('path');
const LAUF = process.env.LAUF || 'A';
const HOME = '/tmp/claude-0/-home-claude/fcfe88c9-293d-574d-8cfa-b1821c923895/scratchpad/etest/home32' + LAUF;
fs.rmSync(HOME, { recursive: true, force: true }); app.setPath('documents', HOME + '/Dokumente');
fs.mkdirSync(HOME + '/Dokumente/MaklerCockpit/backups', { recursive: true });
process.env.MC_AUTOSTART_TEST = '1';
process.env.PORTABLE_EXECUTABLE_FILE = 'C:\\Users\\Paul\\Downloads\\MaklerCockpit-PC-v32.exe';
let reg = null; const log = [];
if(LAUF === 'B'){ reg = { path: 'C:\\Users\\Paul\\Downloads\\MaklerCockpit-PC-v31.exe', args: ['--minimiert'] }; fs.writeFileSync(HOME + '/Dokumente/MaklerCockpit/pc-einstellungen.json', JSON.stringify({ autostart: true, autostartMinimiert: true })); }
if(LAUF === 'C'){ fs.writeFileSync(HOME + '/Dokumente/MaklerCockpit/pc-einstellungen.json', JSON.stringify({ autostart: false })); }
app.setLoginItemSettings = (o) => { log.push(JSON.stringify(o)); reg = o.openAtLogin ? { path: o.path, args: o.args || [] } : null; };
app.getLoginItemSettings = (o) => ({ openAtLogin: !!reg && reg.path === o.path && JSON.stringify(reg.args) === JSON.stringify(o.args || []) });
require(process.env.MC_MAIN || '/tmp/pc/app/main.js');
let f = 0; const ok = (b, t) => { console.log((b ? 'ok   ' : 'FEHL ') + '[' + LAUF + '] ' + t); if(!b) f++; };
const warte = ms => new Promise(r => setTimeout(r, ms));
const einst = () => JSON.parse(fs.readFileSync(HOME + '/Dokumente/MaklerCockpit/pc-einstellungen.json', 'utf8'));
app.whenReady().then(() => setTimeout(async () => {
  try{
    const w = BrowserWindow.getAllWindows()[0]; const js = s => w.webContents.executeJavaScript(s);
    if(LAUF === 'A'){
      ok(reg && reg.path.endsWith('MaklerCockpit-PC-v32.exe') && JSON.stringify(reg.args) === '["--minimiert"]', 'Erster Start: Autostart eingetragen (minimiert) ' + JSON.stringify(reg));
      ok(einst().autostart === true, 'Wahl gespeichert (pc-einstellungen.json, nicht in daten.json)');
      await warte(3500);
      ok(/startet ab jetzt automatisch mit Windows/.test(await js(`(document.getElementById('akqToast') || {}).textContent || ''`)), 'Hinweis beim ersten Start');
      ok(einst().autostartNeu === undefined, 'Hinweis nur einmal');
      await js(`tbMenue({ stopPropagation(){}, currentTarget: document.body, target: document.body })`); await warte(500);
      const mi = await js(`(document.querySelector('.as32-mi') || {}).innerText || ''`);
      ok(/Mit Windows starten/.test(mi) && /an – startet minimiert/.test(mi), 'Zahnrad-Menü: „Mit Windows starten – an, minimiert“');
      await js(`tbMenueZu && tbMenueZu(); as32Dialog()`); await warte(400);
      ok(/An – minimiert \(empfohlen\)/.test(await js(`document.getElementById('modalInner').innerText`)) && await js(`document.querySelector('input[name=as32][value=mini]').checked`), 'Dialog mit drei Möglichkeiten, „minimiert“ gewählt');
      await js(`as32Setzen('offen')`); await warte(300);
      ok(reg && JSON.stringify(reg.args) === '[]' && einst().autostartMinimiert === false, '„Fenster gleich öffnen“ → Eintrag ohne --minimiert');
      await js(`as32Setzen('aus')`); await warte(300);
      ok(reg === null && einst().autostart === false, '„Aus“ → Eintrag entfernt');
      await js(`as32Setzen('mini')`); await warte(300);
      ok(reg && JSON.stringify(reg.args) === '["--minimiert"]' && einst().autostart === true, 'wieder an (minimiert)');
      const d = fs.readFileSync(HOME + '/Dokumente/MaklerCockpit/daten.json', 'utf8');
      ok(!/autostart/i.test(d), 'daten.json (und damit Handy/Cloud) bleibt ohne Autostart-Einstellung');
    }
    if(LAUF === 'B'){
      ok(reg && reg.path.endsWith('MaklerCockpit-PC-v32.exe') && JSON.stringify(reg.args) === '["--minimiert"]', 'Neue Version gestartet: Autostart zeigt jetzt auf v32 statt v31');
      await warte(3500);
      ok(!/startet ab jetzt automatisch/.test(await js(`(document.getElementById('akqToast') || {}).textContent || ''`)), 'Kein erneuter Hinweis');
    }
    if(LAUF === 'C'){
      ok(reg === null && log.length === 0, 'Autostart war ausgeschaltet → bleibt aus');
    }
    const fe = await js(`JSON.stringify(window.__fehlerLog || [])`).catch(() => '[]');
  }catch(e){ console.log('FEHLER', e); f++; }
  console.log('FEHLER', f); app.exit(0);
}, 2500));
