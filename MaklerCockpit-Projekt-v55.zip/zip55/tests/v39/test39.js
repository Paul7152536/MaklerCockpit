const { chromium } = require('playwright');
let f = 0; const ok = (b, t) => { console.log((b ? 'ok   ' : 'FEHL ') + t); if(!b) f++; };
const D = JSON.stringify({ objekte: [{ id: 'm1', akqTitel: 'DHH Mahlsdorf', objektart: 'Doppelhaushälfte', status: 'akquise', ort: '12623 Berlin', adresse: 'Musterweg 12, 12623 Berlin', verlauf: [] }], kontakte: [], termine: [], aufgaben: [], notizen: [], meta: { v9neustart: { quittiert: true } } });
const ANT = 'Hier die Fälle:\n```\nJARVIS-IMPORT typ=kaufvergleiche\n{"art":"meta","stand":"2026-11-16","suchprofil":"DHH 12623, 95–150 m²","erweiterungen":"Kaulsdorf","hinweis":"Marktbericht nur Zusammenfassung frei"}\n'
 + '{"art":"fall","typ":"angebot","datum":"10/2026","lage":"Mahlsdorf-Nord","preis":649000,"preisbasis":"Gesamtpreis","flaeche":125,"flaeche_art":"Wfl","grund":420,"baujahr":2001,"zustand":"gepflegt","objektart":"DHH","quelle":"ImmoScout24","url":"https://example.org/expose/1","fallzahl":null,"notiz":"<b>EBK</b>"}\n'
 + '{"art":"fall","typ":"angebot","datum":"11/2026","lage":"Kaulsdorf","preis":"599.000","preisbasis":"Gesamtpreis","flaeche":112,"flaeche_art":"Wfl","grund":350,"baujahr":1995,"zustand":"renovierungsbedürftig","quelle":"Immowelt","url":"javascript:alert(1)"}\n'
 + '{"art":"fall","typ":"statistik","datum":"2025","lage":"Berlin, DHH/RH, mittlere Wohnlage","preis":4950,"preisbasis":"EUR/m² Wfl (Median)","flaeche":null,"flaeche_art":"Wfl","objektart":"DHH/RH Bj. 1990–2005","quelle":"Immobilienmarktbericht Berlin 2025/26, S. 57","url":"https://example.org/imb","fallzahl":23}\n'
 + '{"art":"fall","typ":"verkauf","datum":"06/2026","lage":"Mahlsdorf","preis":610000,"preisbasis":"Gesamtpreis","flaeche":120,"flaeche_art":"Wfl","quelle":"Zwangsversteigerung, Zuschlag","url":"https://example.org/zv"}\n'
 + '{"art":"fall","typ":"angebot","preis":12,"preisbasis":"Gesamtpreis"}\n{"art":"fall","typ":"irgendwas","preis":500000}\nJARVIS-ENDE\n```';
(async () => {
  const b = await chromium.launch();
  for(const [g, w, h] of [['pc', 1440, 900], ['handy', 412, 915]]){
    const p = await b.newPage({ viewport: { width: w, height: h }, isMobile: g === 'handy', hasTouch: g === 'handy' });
    p.fe = []; p.on('pageerror', e => p.fe.push(e.message));
    await p.addInitScript(([d, g]) => { window.pc = { geraet: g, laden: () => JSON.parse(d), speichern: () => ({ ok: true }), ordner(){}, sicherungSchreiben: () => ({ ok: true }), sicherungLesen: () => null, gekoppelt: () => true, google: async () => ({ ok: false }) }; navigator.clipboard.writeText = async t => { window.__kopie = t; }; }, [D, g]);
    await p.goto('file:///tmp/pc/app/index.html'); await p.waitForTimeout(2200);
    await p.evaluate(() => { try{ schliesseModal(); }catch(e){} GA35.obj = 'm1'; const e = ga35Entwurf('m1'); e.art = 'DHH'; e.region = 'Berlin'; e.werte.wfl = { v: '118', s: 'documented' }; e.werte.grund = { v: '380', s: 'documented' }; e.werte.baujahr = { v: '1998', s: 'documented' }; e.werte.zustand = { v: 'gepflegt', s: 'visually_inferred' }; save(); wechsleAnsicht('grossanalyse'); });
    await p.waitForTimeout(600);
    ok(await p.$('button:has-text("Per KI suchen")') !== null, g + ': Knopf „Per KI suchen“ in den Vergleichsfällen');
    await p.click('button:has-text("Per KI suchen")'); await p.waitForTimeout(300);
    ok(await p.evaluate(() => /Immobilienpreis-Info/.test(document.querySelector('.ga39-quellen').innerText) && /Kaufpreissammlung/.test(document.querySelector('.ga39-quellen').innerText)), g + ': Dialog erklärt, woher Vergleichsfälle kommen');
    await p.click('#modalBg button:has-text("Prompt kopieren")'); await p.waitForTimeout(300);
    const pr = await p.evaluate(() => window.__kopie || '');
    ok(/typ=kaufvergleiche/.test(pr) && /12623/.test(pr) && /118 m²/.test(pr) && /380 m²/.test(pr) && /Baujahr: 1998/.test(pr) && /AUSGABE ZUM KOPIEREN/.test(pr) && /Angebotspreis ist KEIN Verkaufspreis/.test(pr), g + ': Prompt mit Objektdaten und Kopierblock');
    ok(!/Musterweg/.test(pr), g + ': Prompt ohne Straße/Hausnummer');
    await p.fill('#ga39Text', ANT); await p.click('#modalBg button:has-text("Einlesen")'); await p.waitForTimeout(600);
    const v = await p.evaluate(() => ga35Entwurf('m1').vergleich);
    ok(v.length === 4 && v.filter(x => x.art === 'listing').length === 2 && v.filter(x => x.art === 'official_aggregate').length === 1 && v.filter(x => x.art === 'purchase').length === 1, g + ': 4 Fälle übernommen (2 Angebote, 1 Statistik, 1 Verkauf), 2 ungültige übersprungen');
    ok(v.every(x => x.beleg === false) && /NICHT belegt/.test(v.find(x => x.art === 'purchase').notiz), g + ': KI-Funde nie als belegt, Verkauf mit Prüfhinweis');
    ok(!/javascript/.test(JSON.stringify(v)) && !/<b>/.test(JSON.stringify(v)) && v[1].preis === '599000', g + ': unsicherer Link und HTML entfernt, „599.000“ gelesen');
    ok(/n = 23/.test(v[2].quelle) && v[2].preisbasis === 'EUR/m² Wfl (Median)', g + ': Statistik mit Fallzahl und €/m²-Basis');
    ok(await p.evaluate(() => /Letzte KI-Recherche/.test(document.querySelector('.ga35').innerText) && document.querySelectorAll('.ga35-tab tbody tr').length === 4), g + ': Tabelle zeigt die Fälle und den Recherche-Stand');
    const r2 = await p.evaluate(t => ga39Import(t).t, ANT);
    ok(/Nichts übernommen/.test(r2) && /4 schon vorhanden/.test(r2), g + ': nochmal einlesen → keine Dubletten');
    const pk = await p.evaluate(() => { const pa = ga35Paket('m1', ga35Entwurf('m1')); return pa.comparables.map(c => [c.price_type, c.verification_status, !!c.note]); });
    ok(pk.length === 4 && pk.every(c => c[2]) && pk.find(c => c[0] === 'purchase')[1] === 'unverified', g + ': Analysepaket führt die Fälle mit Notiz, Verkauf „unverified“');
    const pr2 = await p.evaluate(() => { const r = ga35Pruefen(ga35Entwurf('m1')); const v = ga35Entwurf('m1').vergleich.find(x => x.art === 'purchase'); v.beleg = true; const r2 = ga35Pruefen(ga35Entwurf('m1')); v.beleg = false; return [r.kauf, r2.kauf, r.warn.some(w => /Beleg/.test(w))]; });
    ok(pr2[0] === 1 && pr2[1] === 2 && pr2[2], g + ': unbelegter KI-Verkauf zählt nicht als Kaufpreis, erst mit Haken „Beleg“');
    if(g === 'pc'){
      await p.evaluate(() => { ga35Entwurf('m1').vergleich = []; save(); wechsleAnsicht('jarvis'); }); await p.waitForTimeout(1500);
      const fr = await (await p.$('#jvFrame')).contentFrame();
      const r = await fr.evaluate(t => einlesen(t), ANT);
      ok(/übernommen/.test(r) && await p.evaluate(() => ga35Entwurf('m1').vergleich.length === 4), 'Jarvis-Import „typ=kaufvergleiche“ landet in der Großen Analyse');
    } else {
      await p.evaluate(() => { const k = [...document.querySelectorAll('.ga35-karte h3')].find(h => /Vergleichsf/.test(h.textContent)); k.scrollIntoView(); }); await p.waitForTimeout(200);
      await p.screenshot({ path: '/tmp/v39test/handy_vergleich.png' });
      await p.click('button:has-text("Per KI suchen")'); await p.waitForTimeout(300); await p.screenshot({ path: '/tmp/v39test/handy_dialog.png' });
    }
    ok(p.fe.length === 0, g + ': keine Fehler ' + p.fe.join(' | '));
    await p.close();
  }
  await b.close(); console.log('FEHLER', f);
})();
