const fs = require('fs'), vm = require('vm');
function server(){
  const props = {}; const dateien = {}; const ordner = {}; let nid = 1;
  const datei = (name, inhalt) => { const id = 'f' + nid++; dateien[id] = { id, name, inhalt }; return api(id); };
  const api = id => ({ getId: () => id, getBlob: () => ({ getDataAsString: () => dateien[id].inhalt }), setContent: c => { if(c.length > 10e6) throw new Error('zu groß'); dateien[id].inhalt = c; }, getSize: () => dateien[id].inhalt.length });
  const ordnerApi = id => ({ getId: () => id, getFilesByName: n => { const l = Object.values(dateien).filter(d => d.ordner === id && d.name === n); let i = 0; return { hasNext: () => i < l.length, next: () => api(l[i++].id) }; }, createFile: (n, c) => { const d = datei(n, c); dateien[d.getId()].ordner = id; return d; } });
  const ctx = {
    PropertiesService: { getScriptProperties: () => ({ getProperty: k => props[k] || null, setProperty: (k, v) => { props[k] = v; } }) },
    DriveApp: { getFolderById: id => { if(!ordner[id]) throw new Error('weg'); return ordnerApi(id); }, getFoldersByName: n => { const l = Object.values(ordner).filter(o => o.name === n); let i = 0; return { hasNext: () => i < l.length, next: () => ordnerApi(l[i++].id) }; }, createFolder: n => { const id = 'o' + nid++; ordner[id] = { id, name: n }; return ordnerApi(id); }, getFileById: id => { if(!dateien[id]) throw new Error('weg'); return api(id); } },
    LockService: { getScriptLock: () => ({ tryLock: () => true, releaseLock: () => {} }) },
    ContentService: { createTextOutput: s => ({ s, setMimeType(){ return this; } }), MimeType: { JSON: 'json' } },
    UrlFetchApp: { fetch: () => ({ getResponseCode: () => 200, getContentText: () => '{"items":[]}' }) }, ScriptApp: { getOAuthToken: () => 't' }, CalendarApp: { getDefaultCalendar: () => ({ getId: () => 'paul@example.org' }) },
    JSON, Date, Math, Object, Number, String
  };
  vm.createContext(ctx);
  vm.runInContext(fs.readFileSync('/tmp/jvb/bruecke_v2.gs', 'utf8').replace('%%SCHLUESSEL%%', 'geheim123'), ctx);
  let anfragen = 0;
  const senden = async p => { anfragen++; const r = ctx.doPost({ postData: { contents: JSON.stringify(Object.assign({ key: 'geheim123' }, p)) } }); return JSON.parse(r.s); };
  return { senden, ctx, dateien, anfragen: () => anfragen };
}

module.exports = server;
