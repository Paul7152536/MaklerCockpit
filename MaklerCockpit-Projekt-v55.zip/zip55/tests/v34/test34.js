// v34: doppelte Kennungen, eindeutige uid, beschädigte Datei → Hinweis + Abgleich-Neustart, Speichern repariert, Texte
const { chromium } = require('playwright');
let f = 0; const ok = (b, t) => { console.log((b ? 'ok   ' : 'FEHL ') + t); if(!b) f++; };
const T = 864e5;
function daten(){
  const obj = []; for(let i = 0; i < 20; i++) obj.push({ id: 'o' + i, createdAt: Date.now() - i * 1000, akqTitel: 'Lead ' + i, ort: '10365 Berlin', objektart: 'Wohnung', status: 'neu', quelle: 'Kleinanzeigen', verlauf: [] });
  obj.push({ id: 'o3', createdAt: 1, akqTitel: 'Anderer Lead mit gleicher id', ort: '13156 Berlin', objektart: 'EFH', status: 'neu', verlauf: [] });
  obj.push(JSON.parse(JSON.stringify(obj[5])));    // echtes Doppel
  return { objekte: obj, kontakte: [{ id: 'k1', name: 'A' }, { id: 'k1', name: 'B' }], termine: [], aufgaben: [], notizen: [], gesuche: [{ id: 'g1', name: 'S1', status: 'aktiv' }, { id: 'g1', name: 'S2', status: 'aktiv' }], marktanalysen: [], mentorFragen: [],
    hv: { verwaltungen: [{ id: 'h1', name: 'HV 1' }, { id: 'h1', name: 'HV 2' }] }, meta: { v9neustart: { quittiert: true } } };
}
async function seite(b, opt){
  const p = await b.newPage({ viewport: { width: 1440, height: 900 } });
  p.fe = []; p.on('pageerror', e => p.fe.push('Seite: ' + e.message)); p.on('dialog', d => d.dismiss());
  await p.addInitScript(([d, o]) => {
    window.__gespeichert = []; window.__stand = o.stand || null;
    window.pc = { geraet: o.geraet || 'pc', laden: () => JSON.parse(d), speichern: t => { window.__gespeichert.push(t); return { ok: !o.speicherFehler, fehler: o.speicherFehler ? 'EACCES' : undefined }; }, ordner(){}, sicherungSchreiben: () => ({ ok: true }), sicherungLesen: () => null,
      zwischenablage: async () => '', abruf: async () => ({ ok: false }), dateiSpeichern: async () => ({ ok: true }), dateiOeffnen(){},
      ladeHinweis: () => o.hinweis || null,
      abgleichStand: (a, t) => { if(a === 'lesen') return window.__stand; if(a === 'schreiben'){ window.__stand = t; return { ok: true }; } return { ok: true }; },
      google: async (aktion) => aktion === 'status' ? { ok: true, verbunden: false } : { ok: false, fehler: 'offline (Test)' } };
  }, [JSON.stringify(opt.daten || daten()), opt]);
  await p.goto('file:///tmp/pc/app/index.html'); await p.waitForTimeout(opt.warte || 2600);
  return p;
}
(async () => {
  const b = await chromium.launch();
  // 1) uid: eindeutig auch in einer engen Schleife
  let p = await seite(b, {});
  let r = await p.evaluate(() => { const s = new Set(); for(let i = 0; i < 200000; i++) s.add(uid()); const x = uid(); return { n: s.size, form: /^id\d{13}[0-9a-z]{6}$/.test(x), bsp: x }; });
  ok(r.n === 200000 && r.form, `uid(): 200.000 Kennungen in einer Schleife, alle verschieden (${r.bsp})`);
  // 2) Reparatur beim Start
  r = await p.evaluate(() => {
    const ids = l => l.map(x => x.id); const eindeutig = l => new Set(ids(l)).size === l.length;
    const letzte = window.__gespeichert.length ? JSON.parse(window.__gespeichert[window.__gespeichert.length - 1]) : null;
    return { obj: db.objekte.length, eo: eindeutig(db.objekte), ek: eindeutig(db.kontakte), eg: eindeutig(db.gesuche), eh: eindeutig(db.hv.verwaltungen),
      o3: db.objekte.filter(o => /^o3/.test(o.id)).map(o => o.id + ':' + o.akqTitel).join(' | '), k: db.kontakte.map(k => k.id + ':' + k.name).join(','), gespeichert: !!(letzte && new Set(letzte.objekte.map(o => o.id)).size === letzte.objekte.length),
      toast: (document.getElementById('akqToast') || document.querySelector('.akq-toast') || {}).textContent || '' };
  });
  ok(r.obj === 21 && r.eo && r.ek && r.eg && r.eh, `Start: doppelte ids in Leads, Kontakten, Suchkunden, Hausverwaltungen repariert, echtes Doppel entfernt (Leads ${r.obj})`);
  ok(/o3:Lead 3 \| o3_2:Anderer Lead/.test(r.o3) && r.k === 'k1:A,k1_2:B', 'Erster Eintrag behält seine id, zweiter bekommt „_2“: ' + r.o3);
  ok(r.gespeichert, 'Reparierter Stand wurde gespeichert');
  await p.waitForTimeout(900);
  ok(await p.evaluate(() => /doppelte Kennung/.test(document.body.innerText)), 'Hinweis (Toast) „doppelte Kennungen repariert“');
  // 3) Doppel zur Laufzeit → beim Speichern repariert
  r = await p.evaluate(async () => { db.objekte.push(JSON.parse(JSON.stringify(Object.assign({}, db.objekte[0], { akqTitel: 'X' })))); _schreibe(); const t = JSON.parse(window.__gespeichert[window.__gespeichert.length - 1]); return { n: t.objekte.length, eind: new Set(t.objekte.map(o => o.id)).size === t.objekte.length }; });
  ok(r.n === 22 && r.eind, 'Doppel während der Arbeit: beim Speichern sofort repariert');
  // 4) Akquise-Import von 100 Leads in einem Rutsch → 100 verschiedene ids
  r = await p.evaluate(() => { const vor = db.objekte.length; const e = []; for(let i = 0; i < 100; i++) e.push({ typ: 'angebot', titel: 'Import ' + i, ort: '10365 Berlin', telefon: '0171 9' + String(100000 + i), quelle: 'Kleinanzeigen', link: 'https://www.kleinanzeigen.de/s-anzeige/imp' + i }); try{ akqUebernehmen(e.map(x => akqAufbereiten ? akqAufbereiten({ f: x, titel: x.titel }) : x), 'Test'); }catch(err){ return { fehler: err.message }; } return { neu: db.objekte.length - vor, eind: new Set(db.objekte.map(o => o.id)).size === db.objekte.length }; });
  ok(r.neu >= 90 && r.eind, `Import von 100 Leads auf einmal: ${r.neu} neu, alle ids verschieden ${r.fehler || ''}`);
  // 5) Speicherfehler-Text ohne altes „Limit 1000 KB“
  r = await p.evaluate(() => { zeigeSpeicherFehler(new Error('EACCES')); const t = document.getElementById('speicherFehler').innerText; document.getElementById('speicherFehler').remove(); return t; });
  ok(!/1000 KB/.test(r) && /Tipp/.test(r), 'Speicherfehler-Meldung ohne veraltetes „Limit ca. 1000 KB“');
  // 6) „heute“ nach deutscher Zeit (an31)
  r = await p.evaluate(() => { const d = new Date(); return new Date(Date.now() - new Date().getTimezoneOffset() * 6e4).toISOString().slice(0, 10) === `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; });
  ok(r, '„heute“ wird nach Ortszeit gebildet');
  ok(p.fe.length === 0, 'Keine Fehler auf der Seite ' + p.fe.join(' | '));
  await p.close();
  // 7) Beschädigte Datei: Hinweis + Abgleich-Neustart
  const stand = JSON.stringify({ aktiv: true, geraet: 'pc-test', basis: { 'objekte|o1': { r: 5, h: 'x1' } }, lokalSeit: { a: 1 }, seit: 77, protokoll: [] });
  p = await seite(b, { hinweis: { sicherung: 'daten-2026-11-10.json', kopie: 'beschaedigt-2026-11-12T08-00-00-000Z.json' }, stand, daten: { objekte: [{ id: 'o1', akqTitel: 'A' }], kontakte: [], termine: [], aufgaben: [], notizen: [], meta: { v9neustart: { quittiert: true } } }, warte: 1200 });
  r = await p.evaluate(() => ({ modal: (document.getElementById('modalInner') || {}).innerText || '', stand: JSON.parse(window.__stand || '{}') }));
  ok(/beschädigt/.test(r.modal) && /10\.11\.2026/.test(r.modal) && /beschaedigt-2026/.test(r.modal), 'Beschädigte Datendatei: Hinweis mit Datum der geladenen Sicherung und Name der aufbewahrten Datei');
  ok(r.stand.aktiv && r.stand.seit === 0 && Object.keys(r.stand.basis).length === 0, 'Abgleich holt danach alles neu (alte Sicherung überschreibt das Handy nicht)');
  ok(/Handy-Abgleich/.test(r.modal), 'Hinweis erwähnt den Abgleich');
  await p.close();
  // ohne Hinweis: kein Dialog
  p = await seite(b, { daten: { objekte: [], kontakte: [], termine: [], aufgaben: [], notizen: [], meta: { v9neustart: { quittiert: true } } }, warte: 1500 });
  ok(await p.evaluate(() => !document.getElementById('modalBg').classList.contains('show')), 'Normale Datei: kein Hinweis');
  await p.close();
  // 8) Handy-Ansicht: Reparatur läuft auch dort
  p = await seite(b, { geraet: 'handy' });
  ok(await p.evaluate(() => new Set(db.objekte.map(o => o.id)).size === db.objekte.length && db.objekte.length === 21), 'Handy: Reparatur beim Start ebenso');
  ok(p.fe.length === 0, 'Handy: keine Fehler ' + p.fe.join(' | '));
  await b.close();
  console.log('FEHLER', f);
})();
