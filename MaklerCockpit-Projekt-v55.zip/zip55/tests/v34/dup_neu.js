// v34: doppelte ids beim Abgleich – neue/alte Geräte gemischt
const ALT = require('/tmp/jvb/abgleich25_kern_v33.js');
delete require.cache[require.resolve('/tmp/jvb/abgleich25_kern.js')];
const NEU = require('/tmp/jvb/abgleich25_kern.js');
const server = require('/tmp/v34test/server_sim.js');
let f = 0; const ok = (b, t) => { console.log((b ? 'ok   ' : 'FEHL ') + t); if(!b) f++; };
const daten = () => ({ objekte: Array.from({ length: 12 }, (_, i) => ({ id: 'o' + i, akqTitel: 'Lead ' + i })), kontakte: Array.from({ length: 40 }, (_, i) => ({ id: 'k' + i, name: 'K' + i })), termine: [], hv: { verwaltungen: [{ id: 'h1', name: 'HV' }] } });
(async () => {
  // 1) Reparatur selbst
  const a = [{ id: 'x', n: 1 }, { id: 'x', n: 2 }, { id: 'x', n: 1 }, { id: 'y' }, { id: 'x_2', n: 9 }];
  const n = NEU.listeReparieren(a, 't');
  ok(n === 2 && a.length === 4 && a.map(x => x.id).join() === 'x,x_3,y,x_2', 'Reparatur: echtes Doppel weg, anderer Inhalt bekommt freie id (' + a.map(x => x.id).join() + ')');
  const b1 = [{ id: 'q', v: 1 }, { id: 'q', v: 2 }], b2 = JSON.parse(JSON.stringify(b1)); NEU.listeReparieren(b1); NEU.listeReparieren(b2);
  ok(JSON.stringify(b1) === JSON.stringify(b2), 'Reparatur ist auf allen Geräten gleich');
  const c = [{ id: 'q', v: 1 }, { id: 'q_2', v: 2 }, { id: 'q', v: 2 }]; NEU.listeReparieren(c);
  ok(c.length === 2, 'Schon reparierter Eintrag (vom anderen Gerät) wird nicht verdoppelt');
  const db = { objekte: [{ id: 1 }, { id: 1, a: 2 }], hv: { verwaltungen: [{ id: 'h', a: 1 }, { id: 'h', a: 2 }] }, googleSync: { x: [{ id: 'g' }, { id: 'g', z: 1 }] } };
  ok(NEU.idsReparieren(db) === 2 && db.objekte[1].id === '1_2' && db.hv.verwaltungen[1].id === 'h_2', 'Auch Unterlisten (hv.verwaltungen) und Zahlen-ids');

  // 2) beide Geräte neu: Doppel am PC entsteht
  { const S = server(); const pc = daten(), stP = { geraet: 'pc-1' }, h = daten(), stH = { geraet: 'handy-1' };
    h.objekte = []; h.kontakte = []; h.hv = {};
    await NEU.runde(pc, stP, S.senden); await NEU.runde(h, stH, S.senden);
    pc.objekte.push({ id: 'o99', akqTitel: 'A' }, { id: 'o99', akqTitel: 'B' });
    await NEU.runde(pc, stP, S.senden); await NEU.runde(h, stH, S.senden); await NEU.runde(pc, stP, S.senden);
    ok(pc.objekte.length === 14 && h.objekte.length === 14 && h.objekte.some(o => o.id === 'o99_2' && o.akqTitel === 'B'), 'Neu/Neu: kein Verlust, Doppel repariert (14/14)');
  }
  // 3) PC neu, Handy alt – Doppel entsteht am alten Handy
  { const S = server(); const pc = daten(), stP = { geraet: 'pc-2' }, h = { objekte: [], kontakte: [], termine: [] }, stH = { geraet: 'handy-2' };
    await NEU.runde(pc, stP, S.senden); await ALT.runde(h, stH, S.senden);
    h.objekte.push({ id: 'o77', akqTitel: 'C' }, { id: 'o77', akqTitel: 'D' });
    let fehler = ''; try{ await ALT.runde(h, stH, S.senden); }catch(e){ fehler = e.code; }
    await NEU.runde(pc, stP, S.senden);
    ok(pc.objekte.length === 14, 'Neu-PC verliert nichts, obwohl das alte Handy die Leads „löscht“ (PC: ' + pc.objekte.length + ')');
    await NEU.runde(pc, stP, S.senden); try{ await ALT.runde(h, stH, S.senden); }catch(e){}
    await NEU.runde(pc, stP, S.senden);
    ok(pc.objekte.length === 14, 'Auch nach weiteren Runden alles da (PC: ' + pc.objekte.length + ', altes Handy: ' + h.objekte.length + ')');
    // Handy wird aktualisiert
    await NEU.runde(h, stH, S.senden); await NEU.runde(pc, stP, S.senden); await NEU.runde(h, stH, S.senden);
    ok(h.objekte.length === 14 && pc.objekte.length === 14 && NEU.gleich(h.objekte.map(o => o.id).sort(), pc.objekte.map(o => o.id).sort()), 'Nach Update des Handys: beide gleich, 14 Leads');
    // frisch gekoppeltes Gerät bekommt keinen Doppelbestand
    const neu = { objekte: [], kontakte: [], termine: [] }; await NEU.runde(neu, { geraet: 'handy-3' }, S.senden);
    ok(neu.objekte.length === 14, 'Neu gekoppeltes Gerät: 14 Leads (' + neu.objekte.length + ')');
  }
  // 4) ganze Liste leer → Schutz
  { const S = server(); const pc = daten(), stP = { geraet: 'pc-4' };
    await NEU.runde(pc, stP, S.senden); pc.objekte = [];
    let code = ''; try{ await NEU.runde(pc, stP, S.senden); }catch(e){ code = e.code; }
    ok(code === 'massenloeschung', 'Alle Leads auf einmal weg → Schutz greift (auch bei nur 12)');
    const e = await NEU.runde(pc, stP, S.senden, { loeschenErlaubt: true }); ok(e && pc.objekte.length === 0, 'Mit Bestätigung wird gelöscht');
  }
  console.log('FEHLER', f);
})();
