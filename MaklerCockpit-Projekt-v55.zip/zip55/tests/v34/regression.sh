#!/bin/bash
# alle bisherigen Tests nacheinander, Zusammenfassung
cd /tmp/v26test
for t in /tmp/v14test/test14.js /tmp/v15test/test15_v24.js /tmp/v16test/test16.js /tmp/v17test/test17.js /tmp/v18test/test18_v25.js /tmp/v19test/test19_v21.js /tmp/v20test/test20.js /tmp/v21test/test21.js /tmp/v22test/test22.js /tmp/v23test/test23.js /tmp/v24test/test24.js /tmp/v25test/test25.js /tmp/v25test/abgleich.test.js /tmp/v25test/android_shim_v26.test.js /tmp/v24test/kern_invest.test.js /tmp/v24test/kern_markt.test.js /tmp/v26test/test26.js /tmp/v27test/test27.js /tmp/v28test/test28.js /tmp/v28test/rundgang.js /tmp/v29test/test29.js /tmp/v30test/test30.js /tmp/v31test/test31.js /tmp/v33test/test33.js /tmp/v34test/dup_neu.js /tmp/v34test/test34.js /tmp/v34test/test34_abgleich.js; do
  [ -f "$t" ] || { echo "?? $t fehlt"; continue; }
  out=$(timeout 600 node "$t" 2>&1)
  fl=$(echo "$out" | grep -c "^FEHL ")
  echo "$(basename $t): $(echo "$out" | grep -c '^ok') ok, $fl FEHL"
  [ "$fl" != "0" ] && echo "$out" | grep "^FEHL \|^FEHLER [1-9]\|Error" | head -8 | sed 's/^/     /'
done
