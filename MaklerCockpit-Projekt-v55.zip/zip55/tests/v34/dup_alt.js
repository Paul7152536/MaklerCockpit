// Nachweis: doppelte id in einer Sammlung → was passiert beim Abgleich (alter Kern)?
const K = require(process.argv[2] || '/tmp/jvb/abgleich25_kern.js');
const server = require('/tmp/v34test/server_sim.js');
(async () => {
  const S = server();
  const pc = { objekte: Array.from({ length: 12 }, (_, i) => ({ id: 'o' + i, akqTitel: 'Lead ' + i })), kontakte: Array.from({ length: 40 }, (_, i) => ({ id: 'k' + i, name: 'K' + i })), termine: [] };
  const stPC = { geraet: 'pc-x' }, handy = { objekte: [], kontakte: [], termine: [] }, stH = { geraet: 'handy-x' };
  await K.runde(pc, stPC, S.senden); await K.runde(handy, stH, S.senden);
  console.log('Start: PC', pc.objekte.length, 'Handy', handy.objekte.length);
  // Import am PC erzeugt doppelte id (zwei verschiedene Leads, gleiche id)
  pc.objekte.push({ id: 'o99', akqTitel: 'Neu A' }, { id: 'o99', akqTitel: 'Neu B' });
  try{ const e = await K.runde(pc, stPC, S.senden); console.log('PC-Runde ok, gesendet', e.gesendet); }catch(e){ console.log('PC-Runde Fehler:', e.code, e.message); }
  try{ await K.runde(handy, stH, S.senden); }catch(e){ console.log('Handy-Runde Fehler:', e.code, e.message); }
  console.log('Nach Abgleich: PC', pc.objekte.length, 'Handy', handy.objekte && handy.objekte.length, (handy.objekte||[]).map(o => o.akqTitel).join(','));
  try{ await K.runde(handy, stH, S.senden); await K.runde(pc, stPC, S.senden); }catch(e){ console.log('2. Runde Fehler:', e.code, e.message); }
  console.log('Nach 2. Runde: PC', pc.objekte && pc.objekte.length, 'Handy', handy.objekte && handy.objekte.length);
})();
