// Klick-Roboter: jede Seite, jeder Knopf (eindeutige onclick-Signaturen), eine Ebene Dialog-Knöpfe. Sammelt Fehler.
const { chromium } = require('playwright'); const fs = require('fs');
const BREITE = +(process.argv[2] || 1440), GERAET = process.argv[3] || 'pc', NUR = process.argv[4] ? process.argv[4].split(',') : null;
const heute = new Date(); const tag = d => { const t = new Date(heute); t.setDate(t.getDate() + d); return t.toISOString().slice(0, 10); };
const T = 864e5, jetzt = Date.now();
function daten(){
  const orte = ['13156 Berlin', '10365 Berlin', '14612 Falkensee', '15366 Neuenhagen', '10317 Berlin'];
  const st = ['neu', 'email_geschrieben', 'kleinanzeigen_geschrieben', 'erstkontakt', 'termin', 'auftrag', 'online', 'abgeschlossen', 'kein_interesse', 'nicht_erreicht'];
  const kontakte = Array.from({ length: 14 }, (_, i) => ({ id: 'k' + i, createdAt: jetzt - i * T, name: ['Petra Krüger', 'Hans Schulz', 'Familie Brandt', 'HV Müller GmbH', 'Sabine Koch', 'Tom Richter', 'Erika Neumann', 'Klaus Wolf', 'Andrea Schröder', 'Bauträger Nord', 'Notar Dr. Weiß', 'Bank Süd', 'Frau Yilmaz', 'Herr Becker'][i], telefon: '0171 22' + (33400 + i), email: i % 2 ? '' : 'k' + i + '@example.org', kontaktart: ['eigentuemer', 'kaeufer', 'interessent', 'hausverwaltung', 'eigentuemer', 'kaeufer', 'eigentuemer', 'sonstige', 'interessent', 'bautraeger', 'notar', 'bank', 'kaeufer', 'interessent'][i], organisation: [3, 9, 10, 11].includes(i), firma: [3, 9, 10, 11].includes(i) ? 'Firma ' + i : '', koop: [3, 9].includes(i) ? { typ: i === 3 ? 'hausverwaltung' : 'bautraeger', status: 'neu' } : undefined, status: 'lead', prioritaet: ['hoch', 'mittel', 'niedrig'][i % 3], notizen: 'Notiz <b>fett</b>' }));
  const objekte = Array.from({ length: 16 }, (_, i) => ({ id: 'o' + i, createdAt: jetzt - i * 3 * T, akqTitel: 'Objekt ' + i + ' ' + ['Wohnung mit Balkon', 'EFH mit Garten', 'Kapitalanlage', 'Grundstück'][i % 4], adresse: 'Teststraße ' + (i + 1), ort: orte[i % 5], objektart: ['Wohnung', 'EFH', 'Wohnung', 'Grundstück'][i % 4], status: st[i % st.length], kaufpreis: 150000 + i * 25000, wohnflaeche: 40 + i * 7, grundstueck: i % 4 === 1 ? 600 : 0, baujahr: 1960 + i * 3, zimmer: 2 + i % 4, verkaeuferName: i % 3 ? 'Eigentümer ' + i : '', verkaeuferTelefon: i % 3 ? '0176 55' + (10000 + i) : '', verkaeuferEmail: i % 4 === 0 ? 'e' + i + '@example.org' : '', eigentuemerId: i < 3 ? 'k' + [0, 4, 6][i] : null, quelle: ['Kleinanzeigen', 'Zeitung', 'Immoscout', 'Empfehlung'][i % 4], link: i % 2 ? 'https://www.kleinanzeigen.de/s-anzeige/' + i : '', verlauf: [{ ts: jetzt - 40 * T, typ: 'email', text: 'E-Mail geschrieben' }], emailAm: i % 10 === 1 ? jetzt - 40 * T : undefined, statusAm: jetzt - (i % 10 === 1 ? 40 : 3) * T, prioritaet: 'mittel', favorit: i === 5, vermietet: i % 4 === 2, miete_ist: i % 4 === 2 ? 650 : undefined, notizen: 'Bemerkung <i>kursiv</i>', inseratDatum: tag(-i), bereich: i >= 5 && i <= 7 ? 'betreut' : undefined }));
  const termine = [-3, -1, 0, 0, 1, 2, 5, 9].map((d, i) => ({ id: 't' + i, createdAt: 1, titel: ['Erstgespräch', 'Besichtigung', 'Rückruf', 'Notar', 'Fotos', 'Bewertung', 'Call Daniel', 'Übergabe'][i], datum: tag(d), uhrzeit: ['10:00', '14:30', '', '11:00', '16:00', '09:00', '18:00', '12:00'][i], dauer: 60, art: ['erstgespraech', 'besichtigung', 'rueckruf', 'notar', 'termin', 'bewertung', 'termin', 'termin'][i], objektId: 'o' + i, kontaktId: 'k' + i, wo: i % 2 ? 'vorort' : 'telefon', ort: 'Teststraße ' + (i + 1) }));
  const aufgaben = Array.from({ length: 6 }, (_, i) => ({ id: 'a' + i, titel: 'Aufgabe ' + i, faellig: tag(i - 2), prioritaet: ['hoch', 'mittel', 'niedrig'][i % 3], objektId: 'o' + i, kontaktId: 'k' + i, status: i === 5 ? 'erledigt' : 'offen', notiz: '' }));
  const gesuche = Array.from({ length: 5 }, (_, i) => ({ id: 'g' + i, status: 'aktiv', name: 'Suchkunde ' + i, telefon: '0152 ' + (3000000 + i), kontaktId: i === 0 ? 'k1' : null, arten: [['Wohnung'], ['EFH', 'DHH'], ['Wohnung'], ['MFH'], ['Grundstück']][i], orte: [['Lichtenberg'], ['Falkensee'], ['Pankow'], ['Berlin'], ['Neuenhagen']][i], budgetMax: 300000 + i * 100000, zimmerMin: 2, flaecheMin: 50 }));
  const notizen = [{ id: 'n1', createdAt: jetzt, text: 'Frau Krüger will erst nach Ostern verkaufen', verarbeitet: false }, { id: 'n2', createdAt: jetzt - T, text: 'Rückruf Schulz', verarbeitet: true }];
  return { objekte, kontakte, termine, aufgaben, notizen, gesuche, marktanalysen: [], mentorFragen: [{ id: 'm1', text: 'Wie Provision verhandeln?', erledigt: false, createdAt: 1 }], meta: { v9neustart: { quittiert: true } } };
}
(async () => {
  const b = await chromium.launch();
  const D = JSON.stringify(daten());
  const fehler = []; let klicks = 0;
  async function neueSeite(){
    const p = await b.newPage({ viewport: { width: BREITE, height: BREITE < 600 ? 844 : 900 } });
    p.fe = []; p.on('pageerror', e => p.fe.push(e.message.slice(0, 220))); p.on('console', m => { if(m.type() === 'error' && !/net::|Failed to load resource|ERR_|favicon|Fehler beim Abgleich/.test(m.text())) p.fe.push('console: ' + m.text().slice(0, 220)); });
    p.on('dialog', d => d.dismiss().catch(() => {})); p.on('filechooser', () => {}); p.on('popup', pp => pp.close().catch(() => {}));
    await p.addInitScript(([d, g]) => {
      window.__auf = []; window.open = u => { window.__auf.push(String(u)); return null; };
      const ok = () => ({ ok: true });
      window.pc = { geraet: g, laden: () => JSON.parse(d), speichern: ok, ordner(){}, sicherungSchreiben: ok, sicherungLesen: () => null, zwischenablage: async () => '', abruf: async () => ({ ok: false, fehler: 'offline (Test)' }),
        dateiSpeichern: async () => ({ ok: true, pfad: '/x.pdf', name: 'x.pdf' }), dateiOeffnen(){}, drucken: async () => ({ ok: true }), oeffnen(){}, autostart: async () => false, autostart2: async () => ({ an: false, gewaehlt: false, minimiert: true, neu: false, moeglich: false, datei: 'x.exe' }),
        sicherung: async () => ({ ok: false }), abgleichStand: () => null, google: async () => ({ ok: false, fehler: 'nicht verbunden (Test)' }) };
    }, [D, GERAET]);
    await p.goto('file:///tmp/pc/app/index.html'); await p.waitForTimeout(1800);
    return p;
  }
  let p = await neueSeite();
  const ansichten = await p.evaluate(() => Array.from(new Set(Array.from(document.querySelectorAll('[onclick*="wechsleAnsicht("]')).map(e => (e.getAttribute('onclick').match(/wechsleAnsicht\('([^']+)'\)/) || [])[1]).filter(Boolean))));
  ['akte', 'dashboard'].forEach(a => { if(!ansichten.includes(a)) ansichten.push(a); });
  console.log('Ansichten:', ansichten.join(', '));
  const oeffnen = { akte: "ob24Oeffnen('o2')" };
  for(const ansicht of ansichten){
    if(NUR && !NUR.includes(ansicht)) continue;
    if(/^jv-|^jarvis$|^marketing$|^pdfs$|^immowert$|^hausverwaltungen$|^shooting$|^marktanalyse$/.test(ansicht) && !(NUR || []).includes(ansicht)) continue; // eigene Werkzeug-Rahmen
    await p.close(); p = await neueSeite();
    const zeige = oeffnen[ansicht] || `wechsleAnsicht('${ansicht}')`;
    await p.evaluate(z => { try{ eval(z); }catch(e){ window.__f = e.message; } }, zeige); await p.waitForTimeout(300);
    const sig = await p.evaluate(() => {
      const els = Array.from(document.querySelectorAll('#main [onclick], #main button, #main summary, #main .lc'));
      const seen = new Map();
      els.forEach((e, i) => { if(!e.offsetParent && getComputedStyle(e).position !== 'fixed') return; const s = (e.getAttribute('onclick') || ('BTN:' + (e.innerText || '').trim().slice(0, 30))).replace(/'[a-z]\d+'/g, "'ID'").replace(/\d{3,}/g, 'N'); if(!seen.has(s)) seen.set(s, i); });
      return Array.from(seen.entries()).slice(0, 90);
    });
    const vorFe = p.fe.length;
    for(const [s, idx] of sig){
      if(/löschen|Loeschen|entfernen|Entfernen|leeren|zuruecksetzen|alleKontakteLoeschen/i.test(s) && !/Hinweis|Filter|suche/i.test(s)){ /* Löschen trotzdem testen, aber auf frischer Seite */ }
      await p.evaluate(z => { try{ schliesseModal(); }catch(e){} try{ eval(z); }catch(e){} }, zeige); await p.waitForTimeout(80);
      const r = await p.evaluate(([idx]) => {
        const els = Array.from(document.querySelectorAll('#main [onclick], #main button, #main summary, #main .lc'));
        const e = els[idx]; if(!e) return 'weg';
        try{ e.click(); }catch(x){ return 'Fehler beim Klick: ' + x.message; }
        return 'ok';
      }, [idx]);
      klicks++;
      await p.waitForTimeout(160);
      // eine Ebene: Knöpfe im geöffneten Dialog
      const modal = await p.evaluate(() => document.getElementById('modalBg') && document.getElementById('modalBg').classList.contains('show') ? Array.from(document.querySelectorAll('#modalInner [onclick], #modalInner button')).filter(e => e.offsetParent).map((e, i) => [(e.getAttribute('onclick') || 'BTN:' + (e.innerText || '').trim().slice(0, 25)), i]).slice(0, 30) : []);
      for(const [ms, mi] of modal){
        await p.evaluate(([z, idx]) => { try{ schliesseModal(); }catch(e){} try{ eval(z); }catch(e){} const els = Array.from(document.querySelectorAll('#main [onclick], #main button, #main summary, #main .lc')); if(els[idx]) els[idx].click(); }, [zeige, idx]);
        await p.waitForTimeout(120);
        await p.evaluate(mi => { const els = Array.from(document.querySelectorAll('#modalInner [onclick], #modalInner button')).filter(e => e.offsetParent); if(els[mi]) try{ els[mi].click(); }catch(e){} }, mi);
        klicks++;
        await p.waitForTimeout(140);
        if(p.fe.length > vorFe){ const neu = p.fe.splice(vorFe); neu.forEach(x => fehler.push(`[${ansicht}] ${s.slice(0, 70)} → Dialog: ${ms.slice(0, 60)} :: ${x}`)); }
        if(await p.evaluate(() => typeof aktuelleAnsicht !== 'undefined' && document.getElementById('main') ? false : true)) break;
      }
      if(p.fe.length > vorFe){ const neu = p.fe.splice(vorFe); neu.forEach(x => fehler.push(`[${ansicht}] ${s.slice(0, 90)} :: ${x}`)); }
    }
    console.log(`${ansicht}: ${sig.length} Knöpfe geprüft`);
  }
  // Glocke, Zahnrad, Suche
  await p.close(); p = await neueSeite();
  const tb = await p.evaluate(() => Array.from(document.querySelectorAll('header [onclick], .topbar [onclick], #topbar [onclick], .tb [onclick]')).map(e => e.getAttribute('onclick')).slice(0, 20));
  for(const z of tb){
    await p.evaluate(z => { try{ eval(z.replace(/event/g, '({stopPropagation(){},currentTarget:document.body,target:document.body})')); }catch(e){ window.__x = e.message; } }, z); await p.waitForTimeout(200);
    const mi = await p.evaluate(() => Array.from(document.querySelectorAll('#tbMenue .mi[onclick]')).map(e => e.getAttribute('onclick')));
    for(const m of mi){ await p.evaluate(m => { try{ eval(m); }catch(e){} }, m); await p.waitForTimeout(250); await p.evaluate(() => { try{ schliesseModal(); }catch(e){} }); klicks++; }
  }
  if(p.fe.length) p.fe.forEach(x => fehler.push('[Kopfleiste/Menü] ' + x));
  console.log('Klicks:', klicks);
  console.log('FEHLER gesamt:', fehler.length);
  fs.writeFileSync(`/tmp/v34test/roboter_${GERAET}_${BREITE}.txt`, fehler.join('\n'));
  const zaehl = {}; fehler.forEach(f => { const k = f.replace(/^\[[^\]]+\] /, '').split(' :: ').pop(); zaehl[k] = (zaehl[k] || 0) + 1; });
  Object.entries(zaehl).sort((a, b) => b[1] - a[1]).slice(0, 40).forEach(([k, n]) => console.log(String(n).padStart(4), k));
  await b.close();
})();
