// v34: Änderung während eines laufenden Abgleichs wird direkt danach nachgeschickt; offline-Hinweis nicht in der Glocke
const { chromium } = require('playwright');
let f = 0; const ok = (b, t) => { console.log((b ? 'ok   ' : 'FEHL ') + t); if(!b) f++; };
(async () => {
  const b = await chromium.launch();
  const p = await b.newPage({ viewport: { width: 1440, height: 900 } });
  const fe = []; p.on('pageerror', e => fe.push(e.message)); p.on('dialog', d => d.dismiss());
  await p.addInitScript(d => {
    window.__stand = JSON.stringify({ aktiv: true, geraet: 'pc-t', basis: {}, lokalSeit: {}, seit: 0, protokoll: [] });
    window.__rufe = []; let rev = 0;
    window.pc = { geraet: 'pc', laden: () => JSON.parse(d), speichern: () => ({ ok: true }), ordner(){}, sicherungSchreiben: () => ({ ok: true }), sicherungLesen: () => null, zwischenablage: async () => '', abruf: async () => ({ ok: false }),
      abgleichStand: (a, t) => { if(a === 'lesen') return window.__stand; if(a === 'schreiben') window.__stand = t; return { ok: true }; },
      google: async (aktion, arg) => {
        if(aktion === 'status') return { ok: true, verbunden: true, modus: 'skript' };
        if(aktion !== 'abgleich') return { ok: false };
        await new Promise(r => setTimeout(r, 400));
        const aend = (arg && arg.aenderungen) || [];
        window.__rufe.push({ t: Date.now(), n: aend.length, ids: aend.map(c => c.s + '|' + c.id) });
        return { ok: true, rev: rev + aend.length, epoche: 0, bis: rev + aend.length, mehr: false, aenderungen: [], angenommen: aend.map(c => ({ s: c.s, id: c.id, r: ++rev })), abgelehnt: [] };
      } };
  }, JSON.stringify({ objekte: [{ id: 'o1', akqTitel: 'A' }], kontakte: [], termine: [], aufgaben: [], notizen: [], meta: { v9neustart: { quittiert: true } } }));
  await p.goto('file:///tmp/pc/app/index.html');
  await p.waitForFunction(() => window.__rufe.length >= 1, null, { timeout: 15000 });
  await p.waitForFunction(() => !AB25.laeuft, null, { timeout: 15000 });
  await p.waitForTimeout(300);
  // neuen Abgleich starten und währenddessen etwas ändern
  const vor = await p.evaluate(() => window.__rufe.length);
  await p.evaluate(() => { ab25Sync('manuell'); });
  await p.waitForTimeout(150);
  await p.evaluate(() => { db.objekte.push({ id: uid(), akqTitel: 'Während Abgleich' }); _schreibe(); });
  await p.waitForTimeout(4500);
  const r = await p.evaluate(() => ({ rufe: window.__rufe, laeuft: AB25.laeuft }));
  const neu = r.rufe.slice(r.vor);
  const gesendet = r.rufe.some(x => x.ids.some(i => /^objekte\|id/.test(i)));
  ok(gesendet, 'Änderung während des Abgleichs wurde gleich danach gesendet (nicht erst nach 2 Minuten)');
  const anzahl = r.rufe.length - vor;
  ok(anzahl <= 4, 'Keine Abgleich-Schleife (' + anzahl + ' Anfragen)');
  await p.waitForTimeout(3000);
  ok(await p.evaluate(n => window.__rufe.length, 0) - r.rufe.length <= 1, 'Danach Ruhe');
  // offline: Fehler nicht in der Glocke
  const g = await p.evaluate(() => { Object.defineProperty(navigator, 'onLine', { get: () => false, configurable: true }); return ab25Sync('test').then(() => ({ code: ab25Stand().code, hinweise: tbHinweise().filter(h => h.k === 'ab25').length })); });
  ok(g.code === 'offline' && g.hinweise === 0, 'Offline: kein roter Hinweis in der Glocke');
  ok(fe.length === 0, 'Keine Fehler ' + fe.join(' | '));
  await b.close(); console.log('FEHLER', f);
})();
