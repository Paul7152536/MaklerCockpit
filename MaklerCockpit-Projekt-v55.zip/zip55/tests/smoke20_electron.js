const { app, BrowserWindow } = require('electron'); const fs = require('fs'); const path = require('path');
const HOME = '/tmp/claude-0/-home-claude/fcfe88c9-293d-574d-8cfa-b1821c923895/scratchpad/etest/home20';
process.env.OneDrive = HOME + '/OneDrive';
app.setPath('documents', HOME + '/Dokumente');
require('/tmp/pc/app/main.js');
app.whenReady().then(() => setTimeout(async () => {
  const w = BrowserWindow.getAllWindows()[0];
  try{
    const r = await w.webContents.executeJavaScript(`(async()=>{
      db.objekte.push({id:'smoke1', createdAt:Date.now(), akqTitel:'Helle Wohnung', objektart:'Wohnung', ort:'10115 Berlin-Mitte', status:'neu', kaufpreis:600000, wohnflaeche:80, verlauf:[]}); save();
      const hinweisVorher = tbHinweise().some(h => /Sicherung einrichten/.test(h.t));
      await siAssistent();
      const ziele = X20.si.ziele;
      const i = X20.si.liste.findIndex(x => /OneDrive/.test(x.pfad));
      const res = await siZielSetzen(i);
      const mv = aqMarktVergleich(findObjekt('smoke1'));
      schliesseModal(); aqMarktanalyse('smoke1');
      await new Promise(r => setTimeout(r, 2500));
      const d = document.getElementById('maFrame').contentDocument;
      return JSON.stringify({ hinweisVorher, ziele, res, cfg: db.sicherung, mv: mv && mv.abw, ma: [d.getElementById('objTitle').value, d.getElementById('flaeche').value], v20: document.body.innerText.includes('v20') });
    })()`);
    console.log('ERGEBNIS', r);
    const basis = path.join(HOME, 'OneDrive/MaklerCockpit-Sicherung');
    console.log('SICHERUNG', fs.readdirSync(basis).join(' | '), '|| Daten:', fs.readdirSync(path.join(basis, 'Daten')).join(' | '));
    const j = JSON.parse(fs.readFileSync(path.join(basis, 'daten-aktuell.json'), 'utf8'));
    console.log('INHALT', j.objekte.some(o => o.id === 'smoke1'), 'google-konto mitkopiert:', fs.existsSync(path.join(basis, 'google-konto.json')));
  }catch(e){ console.log('FEHLER', e); }
  app.exit(0);
}, 3000));
