// v20: Sicherung, Vorlagen, Preis gesenkt, Preis-Check, Auswertung, belegte Zeiten im Termin-Dialog
const { chromium } = require('playwright');
let fehler = 0; const ok = (b, t) => { if(!b){ fehler++; console.log('FEHLER:', t); } else console.log('ok  ', t); };
(async () => {
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 1536, height: 1000 }, deviceScaleFactor: 1 });
  const fe = []; p.on('pageerror', e => { fe.push(e.message); console.log('SEITENFEHLER', e.message); });
  await p.addInitScript(() => {
    const k = d => `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
    const morgen = new Date(Date.now() + 864e5);
    const ALT = `Guten Tag{anrede},

ich habe Ihre Anzeige „{objekt}“ in {ort} gesehen{quelle_satz}. Mein Name ist Paul Görner, ich bin Immobilienmakler bei BETTERHOMES in Berlin.

Falls Sie beim Verkauf Unterstützung möchten – etwa bei der Preisfindung, den Unterlagen oder der Auswahl geprüfter Käufer –, melde ich mich gern kurz telefonisch. Wenn nicht, ist das völlig in Ordnung; dann wünsche ich Ihnen viel Erfolg beim Verkauf.

Viele Grüße
Paul Görner
BETTERHOMES · Görner Immobilien`;
    const fuell = (o, n) => ALT.replace('{anrede}', n ? ' ' + n : '').replace('{objekt}', o).replace('{ort}', '10115 Berlin-Mitte').replace('{quelle_satz}', ' (Kleinanzeigen)');
    const ob = [
      { id:'ka', createdAt:Date.now()-1000, importId:'i1', akqTitel:'Schönes Einfamilienhaus mit Garten', objektart:'EFH', ort:'14612 Falkensee', quelle:'Kleinanzeigen', link:'https://www.kleinanzeigen.de/s-anzeige/haus/123', status:'neu', kaufpreis:489000, wohnflaeche:140, verlauf:[], anschreibenText: fuell('Schönes Einfamilienhaus mit Garten') },
      { id:'ml', createdAt:Date.now()-2000, importId:'i1', akqTitel:'Helle 3-Zimmer-Wohnung mit Balkon', objektart:'Wohnung', ort:'10115 Berlin-Mitte', quelle:'ImmoScout', verkaeuferEmail:'verkaeufer@example.org', verkaeuferName:'Herr Meier', status:'email_geschrieben', emailAm:Date.now()-6*864e5, kaufpreis:600000, wohnflaeche:80, verlauf:[], anschreibenText: fuell('Helle 3-Zimmer-Wohnung mit Balkon', 'Herr Meier') },
      { id:'ki', createdAt:Date.now()-3000, importId:'i1', akqTitel:'Grundstück am See', objektart:'Grundstück', ort:'Teltow', quelle:'Zeitung', verkaeuferEmail:'see@example.org', status:'neu', kaufpreis:250000, verlauf:[], anschreibenText:'Sehr geehrte Damen und Herren, ganz eigener KI-Text zum Grundstück.' },
      { id:'zt', createdAt:Date.now()-4000, akqTitel:'Reihenhaus ruhige Lage', objektart:'Reihenhaus', ort:'Kleinmachnow', quelle:'Zeitung', verkaeuferTelefon:'030 1234567', status:'termin', hatTermin:true, kaufpreis:520000, wohnflaeche:120, verlauf:[] }
    ];
    const alt = { objekte: ob, kontakte: [], termine: [{ id:'t1', titel:'Besichtigung Müller', datum:k(morgen), uhrzeit:'10:00', dauer:60, art:'termin' }, { id:'t2', titel:'Urlaub', datum:k(morgen), uhrzeit:'', art:'termin' }],
      marktanalysen: [], aufgaben: [], notizen: [], mentorFragen: [], meta: { v9neustart: { quittiert: true } }, akquise:{ vorlage: ALT } };
    window.__si = []; window.__siAntwort = { ok:true, zeit:Date.now(), ordner:'C:\\Users\\Paul\\OneDrive\\MaklerCockpit-Sicherung', unterlagenGesamt:3, kopiert:3 };
    window.pc = { laden: () => JSON.parse(JSON.stringify(alt)), speichern: () => ({ ok:true }), ordner(){}, sicherungSchreiben: () => ({ ok:true }), sicherungLesen: () => null, zwischenablage: async () => '', abruf: async () => ({ ok:false }),
      sicherung: async (aktion, arg) => { window.__si.push([aktion, arg]);
        if(aktion === 'ziele') return { ok:true, ziele:[{ name:'OneDrive', pfad:'C:\\Users\\Paul\\OneDrive' }, { name:'Google Drive', pfad:'G:\\Meine Ablage' }] };
        if(aktion === 'pruefen') return { ok:true, da:true };
        if(aktion === 'jetzt') return Object.assign({}, window.__siAntwort, { zeit:Date.now() });
        if(aktion === 'waehlen') return { ok:true, pfad:'E:\\Stick', name:'Stick' };
        return { ok:true }; } };
    window.__geoeffnet = []; window.open = u => { window.__geoeffnet.push(u); };
    window.__kopiert = [];
    try{ Object.defineProperty(navigator, 'clipboard', { value:{ writeText: async t => { window.__kopiert.push(t); } }, configurable:true }); }catch(e){}
  });
  await p.goto('file:///tmp/pc/app/index.html'); await p.waitForTimeout(1500);
  const ev = (f, ...a) => p.evaluate(f, ...a);
  const O = id => ev(i => JSON.parse(JSON.stringify(findObjekt(i))), id);

  // ── Vorlagen + Umstellung alter Texte ──
  let o = await O('ka');
  ok(o.anschreibenText === '' && o.anschreibenEigen === false, 'Alter Vorlagen-Text wird an die Vorlage gekoppelt (Kleinanzeigen-Lead)');
  ok((await O('ml')).anschreibenEigen === false, 'Auch mit Anrede');
  o = await O('ki'); ok(o.anschreibenEigen === true && /eigener KI-Text/.test(o.anschreibenText), 'Eigener KI-Text bleibt erhalten');
  ok(await ev(() => { const V = akqVorlagen(); return V.email.text.startsWith('Guten Tag') && /Kleinanzeigen|Hallo/.test(V.kurz.text) && /vor ein paar Tagen/.test(V.nachfassen.text); }), 'Drei Vorlagen: E-Mail, Kurznachricht, Nachfassen');
  await ev(() => { AQ2.status = 'alle'; wechsleAnsicht('akquise'); aq2Waehlen('ka'); }); await p.waitForTimeout(200);
  await ev(() => aq2Email()); await p.waitForTimeout(150);
  let k = await ev(() => window.__kopiert.slice(-1)[0] || '');
  ok(/^Hallo,/.test(k) && /Schönes Einfamilienhaus mit Garten/.test(k) && /in Falkensee gesehen/.test(k) && !/Guten Tag/.test(k), 'Kleinanzeigen ohne E-Mail → Kurznachricht kopiert (Ort ohne PLZ)');
  ok(await ev(() => /Nachricht bei Kleinanzeigen verschickt/.test(document.getElementById('dpErgebnis').textContent) && !!document.querySelector('#dpErgebnis .vl-wahl') && window.__geoeffnet.slice(-1)[0].includes('kleinanzeigen.de')), 'Anzeige geöffnet, Frage + „Anderen Text kopieren“');
  await ev(() => aq2TextKopieren('email'));
  ok(/^Guten Tag,/.test(await ev(() => window.__kopiert.slice(-1)[0])), 'Anderen Text (E-Mail) kopierbar');
  await ev(() => aq2Waehlen('ml')); await p.waitForTimeout(80);
  ok(await ev(() => /Nachfassen/.test(document.querySelector('.dp-aktionen').textContent)), 'Lead „E-Mail geschrieben“: Knopf heißt „Nachfassen“');
  await ev(() => aq2Email()); await p.waitForTimeout(100);
  let u = await ev(() => decodeURIComponent(window.__geoeffnet.slice(-1)[0]));
  ok(u.startsWith('mailto:verkaeufer@example.org') && /subject=Nochmal zu Ihrer Anzeige: Helle 3-Zimmer-Wohnung/.test(u) && /Hallo Herr Meier,/.test(u) && /vor ein paar Tagen/.test(u), 'Nachfassen-Mail mit Betreff und Anrede');
  await ev(() => [...document.querySelectorAll('#dpErgebnis button')].find(x => /nachgefasst/.test(x.textContent)).click()); await p.waitForTimeout(100);
  o = await O('ml'); ok(o.nachgefasst === 1 && Date.now() - o.emailAm < 60000 && o.verlauf.some(v => /Nachgefasst per E-Mail/.test(v.text)), 'Nachgefasst: Zähler, Verlauf, Erinnerung neu gestartet');
  await ev(() => aq2Waehlen('ki')); await ev(() => aq2Email());
  u = await ev(() => decodeURIComponent(window.__geoeffnet.slice(-1)[0]));
  ok(/eigener KI-Text/.test(u) && /subject=Ihre Anzeige: Grundstück am See in Teltow/.test(u), 'Eigener Text hat Vorrang beim ersten Anschreiben');
  // Editor
  await ev(() => akqVorlageBearbeiten()); await p.waitForTimeout(100);
  ok(await ev(() => document.querySelectorAll('.vl-tabs button').length === 3 && !!document.getElementById('vlBetreff') && /Guten Tag/.test(document.getElementById('vlVorschau').textContent)), 'Editor: 3 Reiter, Betreff, Vorschau');
  await ev(() => akqVorlageTab('kurz')); await p.waitForTimeout(60);
  ok(await ev(() => !document.getElementById('vlBetreff')), 'Kurznachricht ohne Betreff');
  await ev(() => { const t = document.getElementById('vlText'); t.value = 'Moin{anrede}, Anzeige {objekt} für {preis}. '; t.selectionStart = t.selectionEnd = t.value.length; t.focus(); akqVorlageEingabe(); akqVorlageEinfuegen('{ort}'); });
  ok(await ev(() => /Moin, Anzeige Grundstück am See für 250\.000 €\. Teltow/.test(document.getElementById('vlVorschau').textContent)), 'Platzhalter einfügen + Vorschau mit dem gewählten Lead');
  await p.screenshot({ path:'/tmp/v20test/1_vorlagen.png' });
  await ev(() => akqVorlageSpeichern());
  ok(await ev(() => akqDb().vorlagen.kurz.text.startsWith('Moin{anrede}') && akqDb().vorlagen.email.text.startsWith('Guten Tag')), 'Gespeichert, andere Vorlagen unverändert');

  // ── Preis gesenkt ──
  await ev(() => akqUebernehmen([{ titel:'Schönes Einfamilienhaus mit Garten', objektart:'EFH', ort:'14612 Falkensee', quelle:'Kleinanzeigen', link:'https://www.kleinanzeigen.de/s-anzeige/haus/123', preis:459000, wohnflaeche:140 }]));
  o = await O('ka'); ok(o.kaufpreis === 459000 && o.preisStart === 489000 && o.preisGesenktAm > 0 && o.verlauf.some(v => /Preis gesenkt: 489\.000 € → 459\.000 €/.test(v.text)), 'Gleiche Anzeige mit niedrigerem Preis → Preis gesenkt erkannt');
  ok(await ev(() => db.objekte.length === 4), 'Keine Dublette angelegt');
  await ev(() => akqUebernehmen([{ titel:'Reihenhaus ruhige Lage', objektart:'Reihenhaus', ort:'Kleinmachnow', quelle:'Zeitung', preis:505000, wohnflaeche:120 }]));
  o = await O('zt'); ok(o.kaufpreis === 505000 && o.preisStart === 520000, 'Ohne Link: gleicher Titel/Ort/Fläche → als dieselbe Anzeige erkannt');
  await ev(() => akqUebernehmen([{ titel:'Reihenhaus ruhige Lage', objektart:'Reihenhaus', ort:'Kleinmachnow', quelle:'Zeitung', preis:499000, wohnflaeche:120, telefon:'0171 9999999' }]));
  ok(await ev(() => db.objekte.length === 5), 'Anderer Verkäufer (andere Telefonnummer) → eigener Lead');
  await ev(() => { AQ2.status = 'alle'; renderAkquise(document.getElementById('main')); aq2Waehlen('ka'); }); await p.waitForTimeout(150);
  ok(await ev(() => /−6,1 %/.test(document.querySelector('#lc-ka .chip.preis-ab').textContent) && /vorher 489\.000 €/.test(document.querySelector('.dp .preis-alt').textContent)), 'Karte: „📉 −6,1 %“, Detail: vorher 489.000 €');
  ok(await ev(() => { const s = [...document.querySelectorAll('.aq-filter select')][0]; return [...s.options].some(x => x.value === 'preis_gesenkt'); }), 'Filter „Preis gesenkt“ angeboten');
  await ev(() => { AQ2.status = 'preis_gesenkt'; aq2Liste(); });
  ok(await ev(() => document.querySelectorAll('#aqListe .lc').length === 2), 'Filter zeigt die 2 Leads mit gesenktem Preis');
  ok(await ev(() => tbHinweiseOffen().some(h => h.k === 'preis' && /2 Leads mit gesenktem Preis/.test(h.t))), 'Glocke: „2 Leads mit gesenktem Preis“');
  // von Hand im Formular
  await ev(() => { oeffneObjektModal('ml'); });
  ok(await ev(() => /Ihre Anzeige „Helle 3-Zimmer-Wohnung mit Balkon“ in Berlin-Mitte/.test(document.getElementById('m_anschreiben').value)), 'Objekt-Formular schlägt den Text aus der Vorlage vor');
  await ev(() => { const f = document.getElementById('m_kaufpreis'); f.value = '575.000'; speichereObjekt('ml'); }); await p.waitForTimeout(80);
  o = await O('ml'); ok(o.kaufpreis === 575000 && o.preisStart === 600000 && o.preisHistorie.length === 1 && o.anschreibenText === '' && o.anschreibenEigen === false, 'Preis von Hand gesenkt → Verlauf; unveränderter Vorschlag bleibt an die Vorlage gekoppelt');
  await ev(() => { oeffneObjektModal('ml'); document.getElementById('m_anschreiben').value = 'Mein ganz eigener Text'; speichereObjekt('ml'); });
  o = await O('ml'); ok(o.anschreibenEigen === true && o.anschreibenText === 'Mein ganz eigener Text', 'Text im Formular geändert → gilt als eigener Text');

  // ── Preis-Check ──
  const mv = await ev(() => ({ ka: aqMarktVergleich(findObjekt('ka')), ml: aqMarktVergleich(findObjekt('ml')), zt: aqMarktVergleich(findObjekt('zt')), ki: aqMarktVergleich(findObjekt('ki')) }));
  ok(mv.ka.geht && mv.ka.name === 'Falkensee' && mv.ka.m2 === Math.round(4386 * 0.95) && mv.ka.abw === Math.round((459000/140/(4386*0.95) - 1) * 100), 'EFH Falkensee: Hauspreise −5 % → ' + mv.ka.abw + ' %');
  ok(mv.ml.geht && mv.ml.name === 'Mitte' && mv.ml.m2 === 6490 && mv.ml.stufe === 'hoch', 'Wohnung Mitte (PLZ 10115): echte Verkäufe 6.490 €/m² → ' + mv.ml.abw + ' % (etwas über Markt)');
  ok(mv.zt.geht && /Reihenhaus −10 %/.test(mv.zt.q), 'Reihenhaus mit Abschlag');
  ok(mv.ki && mv.ki.geht === false && mv.ki.grund === 'art', 'Grundstück: keine €/m²-Schnellprüfung');
  await ev(() => { AQ2.status = 'alle'; aq2Liste(); aq2Waehlen('ka'); }); await p.waitForTimeout(100);
  ok(await ev(() => !!document.querySelector('.dp .mv.tief') && /−21 %/.test(document.querySelector('.dp .mv').textContent) && /−21 % zum Markt/.test(document.querySelector('#lc-ka .chip.mv-tief').textContent)), 'Detail: Preis-Check-Box, Karte: „−21 % zum Markt“');
  await p.screenshot({ path:'/tmp/v20test/2_lead_preis.png' });
  await ev(() => aqMarktanalyse('ml')); await p.waitForTimeout(1500);
  const ma = await ev(() => { const d = document.getElementById('maFrame').contentDocument; return { titel:d.getElementById('objTitle').value, fl:d.getElementById('flaeche').value, preis:d.getElementById('objAngebot').value, sel:d.getElementById('hostObjSelect').value, typ:(d.querySelector('.type-btn.active, .type-btn.aktiv, .type-btn.on')||{}).dataset }; });
  ok(ma.titel === 'Helle 3-Zimmer-Wohnung mit Balkon' && ma.fl === '80' && /575/.test(ma.preis) && ma.sel === 'ml', '„Genau prüfen“ → Marktanalyse mit dem Lead (Titel, Fläche, Preis): ' + JSON.stringify(ma));
  await ev(() => window.__MA_HOST.setEinschaetzung('ml', 540000));
  o = await O('ml'); ok(o.einschaetzung === 540000 && o.verlauf.some(v => /Marktanalyse: Einschätzung 540\.000 €/.test(v.text)), 'Einschätzung aus der Marktanalyse → im Verlauf');
  await ev(() => { window.__maVorwahl = 'ka'; wechsleAnsicht('immowert'); }); await p.waitForTimeout(400);
  ok(await ev(() => document.getElementById('maFrame').contentDocument.getElementById('objTitle').value === 'Schönes Einfamilienhaus mit Garten'), 'Marktanalyse schon offen → Vorwahl wird auch übernommen');

  // ── Auswertung ──
  await ev(() => { wechsleAnsicht('akquise'); akqVerworfenMerken(findObjekt('ki')); db.objekte = db.objekte.filter(x => x.id !== 'ki'); aqAuswertung(0); }); await p.waitForTimeout(100);
  const aw = await ev(() => aqAuswertungDaten(0));
  const zz = aw.rows.find(r => r.q === 'Zeitung');
  ok(zz && zz.leads === 3 && zz.weg === 1 && zz.st[3] === 1 && aw.sum.leads === 5, 'Zeitung: 3 Leads (1 verworfen), 1 Termin; gesamt 5');
  ok(await ev(() => document.querySelectorAll('.aw-tabelle tbody tr').length === 4 && /Die meisten Leads kommen aus/.test(document.querySelector('#awModal .gs-tipp').textContent)), 'Tabelle mit 3 Quellen + Summe, Fazit');
  await p.screenshot({ path:'/tmp/v20test/3_auswertung.png' });
  await ev(() => schliesseModal());

  // ── Sicherung ──
  await ev(() => tbGlockeAktualisieren());
  ok(await ev(() => tbHinweiseOffen().some(h => /Automatische Sicherung einrichten/.test(h.t))), 'Glocke: „Automatische Sicherung einrichten“');
  await ev(() => siAssistent()); await p.waitForTimeout(150);
  ok(await ev(() => document.querySelectorAll('#siModal .si-ziel').length === 2 && /OneDrive/.test(document.getElementById('siModal').textContent)), 'Assistent findet OneDrive + Google Drive');
  await p.screenshot({ path:'/tmp/v20test/4_sicherung_wahl.png' });
  await ev(() => document.querySelector('#siModal .si-ziel input').click()); await p.waitForTimeout(300);
  const si = await ev(() => ({ c: db.sicherung, letzte: window.__si.filter(x => x[0] === 'jetzt').slice(-1)[0] }));
  ok(si.c.ziel === 'C:\\Users\\Paul\\OneDrive' && si.c.letzte > 0 && !si.c.fehler && si.letzte && si.letzte[1].ziel === si.c.ziel && si.letzte[1].unterlagen === true, 'Ordner gewählt → sofort gesichert (mit Unterlagen)');
  ok(await ev(() => /Aktiv – OneDrive/.test(document.getElementById('siModal').textContent) && /heute/.test(document.getElementById('siModal').textContent)), 'Status „Aktiv – letzte Sicherung heute …“');
  await p.screenshot({ path:'/tmp/v20test/5_sicherung_aktiv.png' });
  ok(await ev(() => !tbHinweise().some(h => /Sicherung/.test(h.t)) && siFaellig() === false), 'Kein Sicherungs-Hinweis mehr, nicht fällig');
  await ev(() => { db.sicherung.letzte = Date.now() - 5 * 36e5; });
  ok(await ev(() => siFaellig() === true), 'Nach 5 Stunden wieder fällig');
  await ev(async () => { window.__siAntwort = { ok:false, code:'ziel', fehler:'Der Sicherungsordner ist nicht erreichbar' }; await siJetzt('auto'); });
  ok(await ev(() => tbHinweiseOffen().some(h => /Sicherung hat nicht geklappt/.test(h.t)) && siFaellig() === false), 'Fehler → Hinweis in der Glocke, nächster Versuch später');
  await ev(async () => { window.__siAntwort = { ok:true, ordner:'x', unterlagenGesamt:0, kopiert:0 }; await siJetzt(); });
  ok(await ev(() => !db.sicherung.fehler && !tbHinweise().some(h => /Sicherung/.test(h.t))), 'Erfolgreich → Fehler weg');
  await ev(() => { siAusschalten(); });
  ok(await ev(() => db.sicherung.aus === true && siFaellig() === false), 'Ausschalten');
  await ev(() => schliesseModal());
  await ev(() => { document.querySelector('#tbZahnrad, [onclick*="tbMenue(event,\'nutzer\')"]') && document.querySelector('[onclick*="tbMenue(event,\'nutzer\')"]').click(); }); await p.waitForTimeout(80);
  ok(await ev(() => { const m = document.getElementById('tbMenue'); return !!m && /Automatische Sicherung/.test(m.textContent) && /Anschreiben-Vorlagen/.test(m.textContent) && /PC-Version v[2-9][0-9]/.test(m.textContent); }), 'Zahnrad-Menü: Sicherung, Anschreiben-Vorlagen, Version');
  await ev(() => tbMenueZu());

  // ── Termin: belegte Zeiten grau, trotzdem wählbar ──
  await ev(() => { AQ2.status = 'alle'; renderAkquise(document.getElementById('main')); aq2Waehlen('ka'); aq2TerminNeu('besichtigung'); }); await p.waitForTimeout(150);
  const ts = await ev(() => ({ n: document.querySelectorAll('#tq_slots .ts-s').length, belegt: [...document.querySelectorAll('#tq_slots .ts-s.belegt')].map(x => x.textContent), ganz: (document.querySelector('#tq_slots .ts-ganz')||{}).textContent || '', an: [...document.querySelectorAll('#tq_slots .ts-s.an')].map(x => x.textContent) }));
  ok(ts.n === 28 && ts.belegt.join() === '10:00,10:30' && /Urlaub/.test(ts.ganz), 'Lead-Termin: 07–21 Uhr, 10:00–11:00 grau, ganztägig „Urlaub“: ' + JSON.stringify(ts));
  ok(ts.an.length >= 1 && ts.an[0] === '10:00', 'Vorgabe 10:00 als gewählt markiert');
  ok(await ev(() => /Besichtigung Müller/.test(document.querySelector('#tq_slots .ts-s.belegt').title)), 'Beim Drüberfahren: welcher Termin dort liegt');
  await ev(() => [...document.querySelectorAll('#tq_slots .ts-s')].find(x => x.textContent === '14:30').click()); await p.waitForTimeout(60);
  ok(await ev(() => document.getElementById('tq_zeit').value === '14:30' && [...document.querySelectorAll('#tq_slots .ts-s.an')].map(x => x.textContent).join() === '14:30,15:00' && !/überschneidet/.test(document.getElementById('tq_tag').textContent)), 'Klick auf 14:30 → Zeit übernommen, 1 Std. markiert');
  await ev(() => [...document.querySelectorAll('#tq_slots .ts-s')].find(x => x.textContent === '10:30').click()); await p.waitForTimeout(60);
  ok(await ev(() => document.getElementById('tq_zeit').value === '10:30' && !!document.querySelector('#tq_slots .ts-s.an.belegt') && /überschneidet/.test(document.getElementById('tq_tag').textContent)), 'Belegte Zeit trotzdem wählbar (mit Hinweis „überschneidet sich“)');
  await p.screenshot({ path:'/tmp/v20test/6_termin_lead.png' });
  await ev(() => schliesseModal());
  await ev(() => { const k = d => `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`; oeffneTerminModal(null, null, k(new Date(Date.now()+864e5))); }); await p.waitForTimeout(100);
  ok(await ev(() => document.querySelectorAll('#m_t_slots .ts-s.belegt').length === 2 && /2 Termine/.test(document.querySelector('#m_t_slots .ts-kopf').textContent)), 'Termine-Seite „Neuer Termin“: belegte Zeiten grau');
  await ev(() => [...document.querySelectorAll('#m_t_slots .ts-s')].find(x => x.textContent === '16:00').click());
  ok(await ev(() => document.getElementById('m_t_zeit').value === '16:00' && !document.getElementById('m_t_dauer').disabled && document.querySelector('#m_t_slots .ts-s.an').textContent === '16:00'), 'Klick setzt Uhrzeit, Dauer wird wählbar');
  await p.screenshot({ path:'/tmp/v20test/7_termin_neu.png' });
  await ev(() => { schliesseModal(); oeffneTerminModal('t1'); }); await p.waitForTimeout(80);
  ok(await ev(() => document.querySelectorAll('#m_t_slots .ts-s.belegt').length === 0 && document.querySelectorAll('#m_t_slots .ts-s.an').length === 2), 'Termin bearbeiten: eigener Termin zählt nicht als belegt');
  await ev(() => schliesseModal());

  // ── Objekte-Seite: nur Objekte mit Termin ──
  await ev(() => { db.termine.push({ id:'t3', titel:'Rückruf: Wohnung', datum:'2030-01-01', uhrzeit:'09:00', art:'rueckruf', objektId:'ml' }); db.termine.push({ id:'t4', titel:'Akquise-Termin: EFH', datum:'2030-01-02', uhrzeit:'10:00', art:'akquise', objektId:'ka' }); OB26.aktiv = 'akquise'; OB26.filterGesetzt = true; X20.objFilter = 'termin'; wechsleAnsicht('objekte'); }); await p.waitForTimeout(150);
  const zeilen = () => ev(() => [...document.querySelectorAll('#objTabelle table tr')].slice(1).map(r => r.textContent.replace(/\s+/g, ' ').trim().slice(0, 60)));
  let z = await zeilen();
  ok(z.length === 2 && z.some(x => /Schönes Einfamilienhaus/.test(x)) && z.some(x => /Reihenhaus ruhige Lage/.test(x)) && /2 Akquise-Leads ohne Termin ausgeblendet/.test(await ev(() => (document.querySelector('.obj-filter-hinweis')||{}).textContent || '')), 'Objekte: nur mit Termin (Akquise-Termin bzw. Status Termin), Rückruf zählt nicht: ' + JSON.stringify(z));
  await p.screenshot({ path:'/tmp/v20test/8_objekte.png' });
  await ev(() => objFilterSetzen('alle')); z = await zeilen();
  ok(z.length === 4 && !(await ev(() => document.querySelector('.obj-filter-hinweis'))), '„Alle“ zeigt auch Leads ohne Termin');
  await ev(() => objFilterSetzen('termin'));
  // ── Kalender: Standardfarbe Blau ──
  await ev(() => { db.termine.push({ id:'t5', titel:'Akquise-Termin heute', datum: toDateKey(new Date()), uhrzeit:'12:00', art:'akquise' }); wechsleAnsicht('termine'); }); await p.waitForTimeout(200);
  const farbe = await ev(() => { const e = [...document.querySelectorAll('.kal-tag .eintrag')].find(x => /Akquise-Termin heute/.test(x.textContent)); return e ? getComputedStyle(e).backgroundColor + ' | ' + getComputedStyle(e).color : 'kein Eintrag'; });
  ok(/96, 165, 250/.test(farbe), 'Kalender: Termine standardmäßig blau (' + farbe + ')');
  await p.screenshot({ path:'/tmp/v20test/9_kalender.png' });
  ok(fe.length === 0, 'Keine Seitenfehler');
  console.log('\nFEHLER', fehler); await b.close(); process.exit(fehler ? 1 : 0);
})();
