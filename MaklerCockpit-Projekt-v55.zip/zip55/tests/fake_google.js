// Nachgebauter Google Kalender für die Tests (läuft in der Seite als window.pc.google)
(function(){
  const tag = n => { const d = new Date(); d.setDate(d.getDate()+n); const p = x => String(x).padStart(2,'0'); return `${d.getFullYear()}-${p(d.getMonth()+1)}-${p(d.getDate())}`; };
  let uhr = Date.parse('2026-11-01T08:00:00Z');
  const neuUpdated = () => { uhr += 1000; return new Date(Math.max(uhr, Date.now() + (window.__G ? window.__G.zeitVersatz : 0))).toISOString(); };
  const mitOffset = s => s && s.dateTime && !/[+-]\d\d:\d\d$|Z$/.test(s.dateTime) ? Object.assign({}, s, { dateTime: s.dateTime + '+01:00' }) : s;
  let nr = 0;
  const G = window.__G = {
    zeitVersatz: 0,
    st: { ok:true, eingerichtet:false, verbunden:false, email:'', projekt:'' },
    events: new Map(),
    log: [],
    fehlerBei: null,          // z. B. { methode:'GET', antwort:{ok:false,code:'abgelaufen',fehler:'…'} }
    neu(ev){ const id = ev.id || ('g' + (++nr)); const e = Object.assign({ kind:'calendar#event', status:'confirmed', htmlLink:'https://calendar.google.com/event?eid=' + id }, JSON.parse(JSON.stringify(ev)), { id, updated: neuUpdated() }); e.start = mitOffset(e.start); e.end = mitOffset(e.end); G.events.set(id, e); return e; },
    handyAendern(id, patch){ const e = G.events.get(id); Object.assign(e, JSON.parse(JSON.stringify(patch))); e.start = mitOffset(e.start); e.end = mitOffset(e.end); e.updated = neuUpdated(); return e; },
    handyLoeschen(id){ const e = G.events.get(id); e.status = 'cancelled'; e.updated = neuUpdated(); },
    aktive(){ return [...G.events.values()].filter(e => e.status !== 'cancelled'); },
    tag
  };
  async function api(a){
    G.log.push(a.methode + ' ' + a.pfad);
    if(G.fehlerBei && (!G.fehlerBei.methode || G.fehlerBei.methode === a.methode)){ const f = G.fehlerBei.antwort; if(G.fehlerBei.einmal) G.fehlerBei = null; if(f.code === 'abgelaufen'){ G.st.verbunden = false; } return f; }
    if(a.pfad === '/users/me/calendarList') return { ok:true, status:200, data:{ items:[ { id:'paul@example.com', summary:'paul@example.com', primary:true, backgroundColor:'#f4511e', accessRole:'owner' }, { id:'arbeit123@group.calendar.google.com', summary:'Makler Termine', backgroundColor:'#33b679', accessRole:'owner' } ] } };
    const m = /^\/calendars\/([^/]+)\/events(?:\/([^/]+))?$/.exec(a.pfad); if(!m) return { ok:false, status:404, fehler:'?' };
    const id = m[2] ? decodeURIComponent(m[2]) : null;
    if(a.methode === 'GET' && !id){
      let l = [...G.events.values()]; if(!a.query.showDeleted) l = l.filter(e => e.status !== 'cancelled');
      const min = a.query.timeMin, max = a.query.timeMax;
      l = l.filter(e => { const s = e.start.dateTime || e.start.date; const en = e.end.dateTime || e.end.date; return new Date(en) > new Date(min) && new Date(s) < new Date(max); });
      return { ok:true, status:200, data:{ items: JSON.parse(JSON.stringify(l)) } };
    }
    if(a.methode === 'GET'){ const e = G.events.get(id); return e ? { ok:true, status:200, data: JSON.parse(JSON.stringify(e)) } : { ok:false, status:404, code:'weg', fehler:'Nicht gefunden.' }; }
    if(a.methode === 'POST'){ const e = G.neu(a.body); return { ok:true, status:200, data: JSON.parse(JSON.stringify(e)) }; }
    if(a.methode === 'DELETE'){ const e = G.events.get(id); if(!e || e.status === 'cancelled') return { ok:false, status:410, code:'weg', fehler:'Gelöscht.' }; e.status = 'cancelled'; e.updated = neuUpdated(); return { ok:true, status:204, data:null }; }
    if(a.methode === 'PATCH' || a.methode === 'PUT'){
      const e = G.events.get(id); if(!e || e.status === 'cancelled') return { ok:false, status:404, code:'weg', fehler:'Nicht gefunden.' };
      if(G.nurLesen && G.nurLesen.has(id)) return { ok:false, status:403, code:'kein_recht', fehler:'Diesen Termin darfst du in Google nicht ändern.' };
      if(a.methode === 'PATCH' && a.body.start && ((a.body.start.date && e.start.dateTime) || (a.body.start.dateTime && e.start.date))) return { ok:false, status:400, code:'api', fehler:'Google meldet Fehler 400: Mischung date/dateTime' };
      const neu = a.methode === 'PUT' ? Object.assign({ id, htmlLink:e.htmlLink, status:'confirmed' }, JSON.parse(JSON.stringify(a.body))) : Object.assign(e, JSON.parse(JSON.stringify(a.body)));
      if(a.methode === 'PATCH' && a.body.extendedProperties) neu.extendedProperties = a.body.extendedProperties;
      neu.start = mitOffset(neu.start); neu.end = mitOffset(neu.end); neu.updated = neuUpdated(); neu.id = id;
      G.events.set(id, neu); return { ok:true, status:200, data: JSON.parse(JSON.stringify(neu)) };
    }
    return { ok:false, status:400, fehler:'?' };
  }
  window.__googleStub = async function(aktion, arg){
    await new Promise(r => setTimeout(r, window.__latenz ? Math.random()*60 : 5));
    if(aktion === 'status') return JSON.parse(JSON.stringify(G.st));
    if(aktion === 'einrichten'){ let d; try{ d = JSON.parse(arg.json); }catch(e){ return { ok:false, fehler:'Das ist keine gültige Zugangsdatei von Google (JSON erwartet).' }; } if(!d.installed) return { ok:false, fehler:'Typ Desktop-App nötig' }; G.st.eingerichtet = true; G.st.projekt = d.installed.project_id; return JSON.parse(JSON.stringify(G.st)); }
    if(aktion === 'verbinden'){ await new Promise(r => setTimeout(r, 400)); G.st.verbunden = true; G.st.email = 'paul@example.com'; return JSON.parse(JSON.stringify(G.st)); }
    if(aktion === 'trennen'){ G.st.verbunden = false; G.st.email = ''; if(arg && arg.allesLoeschen) G.st.eingerichtet = false; return JSON.parse(JSON.stringify(G.st)); }
    if(aktion === 'skriptSchluessel') return { ok:true, schluessel:'TESTSCHLUESSEL-123456789' };
    if(aktion === 'skriptVerbinden'){ await new Promise(r => setTimeout(r, 300)); if(!/^https:\/\/script\.google\.com\/macros\/s\/[\w-]{20,}\/exec$/.test(arg.url)) return { ok:false, fehler:'Das ist keine Web-App-Adresse von Google. Sie beginnt mit https://script.google.com/macros/s/ und endet auf /exec.' };
      Object.assign(G.st, { verbunden:true, eingerichtet:true, modus:'skript', email:'paul@example.com' }); return JSON.parse(JSON.stringify(G.st)); }
    if(aktion === 'abbrechen') return { ok:true };
    if(aktion === 'api') return api(arg);
    return { ok:false };
  };
})();
