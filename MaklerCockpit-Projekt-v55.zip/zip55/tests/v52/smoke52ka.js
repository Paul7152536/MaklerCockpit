// v52 Smoke: Anmeldung bei Kleinanzeigen bleibt im Fenster (login.kleinanzeigen.de), fremde Seiten gehen in den Browser, Bestätigungslink per Knopf
const { app, BrowserWindow } = require('electron'); const http = require('http'); const fs = require('fs');
const HOME = '/tmp/claude-0/-home-claude/fcfe88c9-293d-574d-8cfa-b1821c923895/scratchpad/etest/home52ka';
fs.rmSync(HOME, { recursive: true, force: true });
app.setPath('documents', HOME + '/Dokumente');
process.env.MC_WEB_TEST = '1';
const extern = []; require('electron').shell.openExternal = u => { extern.push(u); return Promise.resolve(); };
const srv = http.createServer((req, res) => { res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' }); res.end('<!doctype html><html><head><meta charset="utf-8"><title>Login</title></head><body><form id="f"><input name="email" value="x@y.de"><button>Weiter</button></form></body></html>'); });
srv.listen(0, '127.0.0.1');
require(process.env.MC_MAIN || '/tmp/pc/app/main.js');
const warte = ms => new Promise(r => setTimeout(r, ms));
app.whenReady().then(() => setTimeout(async () => {
  let fehler = 0; const ok = (b, t) => { console.log((b ? 'ok   ' : 'FEHL ') + t); if(!b) fehler++; };
  try{
    const w = BrowserWindow.getAllWindows()[0], port = srv.address().port;
    const r = await w.webContents.executeJavaScript(`window.pc.webfenster('oeffnen', { url: 'http://127.0.0.1:${port}/m-einloggen.html' })`);
    ok(r && r.ok, 'Kleinanzeigen-Fenster geöffnet');
    await warte(2000);
    const kw = BrowserWindow.getAllWindows().find(x => x !== w);
    const navs = []; kw.webContents.on('did-start-navigation', (...a) => { const d = a[0]; navs.push(typeof d?.url === 'string' ? d.url : a[1]); });
    ok(await kw.webContents.executeJavaScript(`!!document.getElementById('__mcLink')`), 'Leiste hat „🔗 Kopierten Link öffnen“');
    // Weiter nach E-Mail → login.kleinanzeigen.de
    await kw.webContents.executeJavaScript(`location.href = 'https://login.kleinanzeigen.de/u/login/password?state=abc'; true`).catch(() => {});
    await warte(2500);
    ok(!extern.length && navs.some(u => /^https:\/\/login\.kleinanzeigen\.de\//.test(u)), 'Anmeldeseite login.kleinanzeigen.de bleibt im Fenster (kein Windows-Browser) ' + JSON.stringify({ extern, navs: navs.slice(-2) }));
    // fremde Seite → Browser
    await kw.loadURL(`http://127.0.0.1:${port}/m-einloggen.html`); await warte(1500);
    await kw.webContents.executeJavaScript(`location.href = 'https://www.example.com/hilfe'; true`).catch(() => {});
    await warte(1500);
    ok(extern.some(u => /example\.com/.test(u)), 'fremde Seite öffnet weiter im normalen Browser');
    // Bestätigungslink aus der Mail
    await kw.loadURL(`http://127.0.0.1:${port}/m-einloggen.html`); await warte(1500);
    require('electron').clipboard.writeText('https://www.kleinanzeigen.de/m-login-bestaetigen.html?token=xyz');
    navs.length = 0;
    await kw.webContents.executeJavaScript(`document.getElementById('__mcLink').click(); true`);
    await warte(2000);
    ok(navs.some(u => /m-login-bestaetigen\.html\?token=xyz/.test(u)), 'Knopf öffnet den kopierten Bestätigungslink im selben Fenster');
    await kw.loadURL(`http://127.0.0.1:${port}/m-einloggen.html`); await warte(1500);
    require('electron').clipboard.writeText('https://phishing.example/login');
    await kw.webContents.executeJavaScript(`document.getElementById('__mcLink').click(); true`);
    await warte(800);
    const info = await kw.webContents.executeJavaScript(`document.getElementById('__mcInfo').textContent`);
    ok(/kein Kleinanzeigen-Link/.test(info) && /127\.0\.0\.1/.test(kw.webContents.getURL()), 'fremder Link wird nicht geöffnet: ' + info);
  }catch(e){ ok(false, 'Ausnahme: ' + e.message); }
  console.log(fehler ? 'FEHLER ' + fehler : 'FEHLER 0'); app.exit(fehler ? 1 : 0);
}, 3500));
