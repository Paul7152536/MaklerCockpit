// v41: PC → Handy → Tablet koppeln, Abgleich zwischen drei Geräten, Kalender-Hauptgerät
const { chromium } = require('playwright');
const server = require('/tmp/v34test/server_sim.js');
let f = 0; const ok = (b, t) => { console.log((b ? 'ok   ' : 'FEHL ') + t); if(!b) f++; };
const S = server();
const CODE = 'MC1-' + Buffer.from(JSON.stringify({ u: 'https://script.google.com/macros/s/AKfycbTESTtestTESTtestTEST123/exec', k: 'geheim123', e: '' })).toString('base64url');
const PCDATEN = { objekte: [{ id: 'o1', akqTitel: 'ETW Lichtenberg', objektart: 'Wohnung', ort: '10365 Berlin', verlauf: [] }, { id: 'o2', akqTitel: 'DHH Mahlsdorf', objektart: 'DHH', ort: '12623 Berlin', verlauf: [] }],
  kontakte: [{ id: 'k1', name: 'Frau Muster' }], termine: [{ id: 't1', titel: 'Besichtigung', datum: '2026-11-20', zeit: '10:00', erstelltAuf: 'pc-haupt' }], aufgaben: [], notizen: [], meta: { v9neustart: { quittiert: true } } };
async function geraet(b, name, art, daten, stand, verbunden){
  const p = await b.newPage({ viewport: art === 'handy' ? { width: 412, height: 915 } : { width: 1280, height: 800 }, isMobile: art === 'handy' });
  p.fe = []; p.on('pageerror', e => p.fe.push(name + ': ' + e.message)); p.on('dialog', d => d.dismiss());
  await p.exposeFunction('__srv', x => S.senden(x));
  await p.addInitScript(([art, daten, stand, verbunden]) => {
    window.__stand = stand ? JSON.stringify(stand) : null; window.__verbunden = verbunden;
    window.pc = { geraet: art, laden: () => daten ? JSON.parse(daten) : null, speichern: () => ({ ok: true }), ordner(){}, sicherungSchreiben: (n) => { window.__sicherung = n; return { ok: true }; }, sicherungLesen: () => null, zwischenablage: async () => '',
      abgleichStand: (a, t) => { if(a === 'lesen') return window.__stand; if(a === 'schreiben') window.__stand = t; if(a === 'loeschen') window.__stand = null; return { ok: true }; },
      gekoppelt: () => window.__verbunden, koppeln: async c => { if(!/^MC1-/.test(c)) return { ok: false, fehler: 'falsch' }; window.__verbunden = true; return { ok: true }; },
      google: async (aktion, arg) => {
        if(aktion === 'status') return { ok: true, verbunden: window.__verbunden, eingerichtet: window.__verbunden, modus: window.__verbunden ? 'skript' : '' };
        if(aktion === 'koppeln'){ if(!/^MC1-[\w-]{20,}$/.test(arg)) return { ok: false, fehler: 'kein gültiger Code' }; window.__verbunden = true; window.__gekoppeltMit = arg; return { ok: true, verbunden: true, modus: 'skript' }; }
        if(aktion === 'kopplung') return window.__verbunden ? { ok: true, code: window.__CODE } : { ok: false, fehler: 'nicht gekoppelt' };
        if(aktion === 'abgleich') return window.__srv(arg);
        if(aktion === 'api') return { ok: true, status: 200, data: { items: [] } };
        return { ok: false };
      } };
  }, [art, daten ? JSON.stringify(daten) : null, stand, verbunden]);
  await p.addInitScript(c => { window.__CODE = c; }, CODE);
  await p.goto('file:///tmp/pc/app/index.html'); await p.waitForTimeout(2600);
  await p.evaluate(() => { try{ schliesseModal(); }catch(e){} });
  return p;
}
const sync = async p => { await p.evaluate(async () => { while(AB25.laeuft) await new Promise(r => setTimeout(r, 100)); await ab25Sync('test'); }); };
(async () => {
  const b = await chromium.launch();
  // PC: eingerichtet, Abgleich an
  const pc = await geraet(b, 'PC', 'pc', PCDATEN, { aktiv: true, geraet: 'pc-haupt', basis: {}, lokalSeit: {}, seit: 0, protokoll: [] }, true);
  await sync(pc); await sync(pc);
  ok(await pc.evaluate(() => db.ab25Haupt === 'pc-haupt' && ab25IstHaupt()), 'PC wird automatisch Kalender-Hauptgerät');
  await pc.evaluate(() => ab25Dialog(true)); await pc.waitForTimeout(500);
  ok(await pc.evaluate(() => /Geräte & Abgleich/.test(document.querySelector('#modalBg h3').textContent) && /Weiteres Gerät koppeln \(Handy, Tablet, zweiter PC\)/.test(document.querySelector('#modalBg').innerText)), 'PC-Dialog: „Geräte & Abgleich“ mit Anleitung für Handy, Tablet, zweiten PC');
  await pc.click('button:has-text("Kopplungscode anzeigen")'); await pc.waitForTimeout(400);
  ok(await pc.evaluate(c => document.querySelector('#ab25Kopplung textarea').value === c && !!document.querySelector('#ab25Kopplung svg'), CODE), 'PC zeigt Kopplungscode mit QR-Code');
  await pc.evaluate(() => schliesseModal());
  // Handy: neu, koppeln mit Code vom PC
  const h = await geraet(b, 'Handy', 'handy', null, null, false);
  await h.evaluate(() => ab25HandyDialog()); await h.waitForTimeout(300);
  ok(await h.evaluate(() => /schon gekoppelten Gerät \(PC, Tablet oder Handy\)/.test(document.querySelector('#modalBg').innerText)), 'Handy: Koppeln-Dialog nennt PC, Tablet oder Handy als Quelle');
  await h.fill('#ab25Code', CODE); await h.click('button:has-text("Koppeln")'); await h.waitForTimeout(2500);
  ok(await h.evaluate(() => db.objekte.length === 2 && db.kontakte.length === 1 && ab25Stand().aktiv), 'Handy gekoppelt: 2 Objekte, 1 Kontakt geholt');
  ok(await h.evaluate(() => !ab25IstHaupt() && !ab25ImportErlaubt()), 'Handy ist nicht Kalender-Hauptgerät, holt keine Google-Termine');
  await h.evaluate(() => ab25Dialog()); await h.waitForTimeout(400);
  await h.click('#ab25Kopplung button'); await h.waitForTimeout(400);
  const hcode = await h.evaluate(() => (document.querySelector('#ab25Kopplung textarea') || {}).value);
  ok(hcode === CODE, 'Handy zeigt den Kopplungscode für das nächste Gerät');
  await h.evaluate(() => schliesseModal());
  // Tablet (Windows-exe, frisch): mit Code vom Handy verbinden
  const t = await geraet(b, 'Tablet', 'pc', null, null, false);
  await t.evaluate(() => ab25Dialog()); await t.waitForTimeout(500);
  ok(await t.evaluate(() => /Mit Kopplungscode verbinden/.test(document.querySelector('#modalBg').innerText) && /Erstes Gerät einrichten/.test(document.querySelector('#modalBg').innerText)), 'Tablet: Dialog bietet „Mit Kopplungscode verbinden“ vor dem Skript-Einrichten an');
  await t.click('button:has-text("Mit Kopplungscode verbinden")'); await t.waitForTimeout(300);
  await t.fill('#ab41Code', 'MC1-kaputt'); await t.click('#modalBg button:has-text("Verbinden")'); await t.waitForTimeout(300);
  ok(await t.evaluate(() => /kein gültiger/.test(document.getElementById('ab41Status').innerText)), 'Tablet: kaputter Code → verständliche Meldung');
  await t.fill('#ab41Code', hcode + '\n'); await t.click('#modalBg button:has-text("Verbinden")'); await t.waitForTimeout(3000);
  let r = await t.evaluate(() => ({ o: db.objekte.length, k: db.kontakte.length, term: db.termine.length, aktiv: ab25Stand().aktiv, rolle: ab25Stand().rolle, haupt: ab25IstHaupt(), imp: ab25ImportErlaubt(), sich: window.__sicherung || '' }));
  ok(r.o === 2 && r.k === 1 && r.term === 1 && r.aktiv && r.rolle === 'zweit', 'Tablet gekoppelt: alle Daten da (2 Objekte, 1 Kontakt, 1 Termin)');
  ok(!r.haupt && !r.imp, 'Tablet ist Zweitgerät: holt keine Google-only-Termine (keine doppelten Termine)');
  ok(/^vor-kopplung-\d+\.json$/.test(r.sich), 'Vor dem Koppeln wurde eine Sicherung angelegt');
  ok(await t.evaluate(() => ab25DarfAnlegen({ erstelltAuf: 'pc-haupt' }) === false && ab25DarfAnlegen({ erstelltAuf: ab25Stand().geraet }) === true), 'Tablet trägt nur eigene neue Termine in Google ein');
  // Änderungen kreuz und quer
  await t.evaluate(() => { db.objekte.push({ id: uid(), akqTitel: 'Vom Tablet', verlauf: [] }); db.objekte.find(o => o.id === 'o1').akqTitel = 'ETW Lichtenberg (Tablet)'; save(); });
  await t.waitForTimeout(500); await sync(t);
  await h.evaluate(() => { db.kontakte.push({ id: uid(), name: 'Vom Handy' }); db.objekte = db.objekte.filter(o => o.id !== 'o2'); save(); });
  await h.waitForTimeout(500); await sync(h);
  await pc.evaluate(() => { db.termine.push({ id: uid(), titel: 'Vom PC', datum: '2026-11-21', zeit: '09:00' }); save(); });
  await pc.waitForTimeout(500);
  for(let i = 0; i < 2; i++){ await sync(pc); await sync(h); await sync(t); }
  const stand = p => p.evaluate(() => JSON.stringify({ o: db.objekte.map(o => o.akqTitel).sort(), k: db.kontakte.map(k => k.name).sort(), t: db.termine.map(x => x.titel).sort() }));
  const [a1, a2, a3] = [await stand(pc), await stand(h), await stand(t)];
  console.log('   ' + a1);
  ok(a1 === a2 && a2 === a3, 'Alle drei Geräte haben denselben Stand');
  ok(/ETW Lichtenberg \(Tablet\)/.test(a1) && /Vom Tablet/.test(a1) && /Vom Handy/.test(a1) && /Vom PC/.test(a1) && !/DHH Mahlsdorf/.test(a1), 'Änderungen, Neuanlagen und Löschung von jedem Gerät kommen überall an');
  // Hauptgerät wechseln
  await t.evaluate(() => { db.ab25Haupt = ab25Stand().geraet; save(); }); await t.waitForTimeout(500); await sync(t); await sync(pc);
  r = await Promise.all([pc.evaluate(() => ab25IstHaupt()), t.evaluate(() => ab25IstHaupt()), h.evaluate(() => ab25IstHaupt())]);
  ok(!r[0] && r[1] && !r[2], 'Kalender-Hauptgerät gewechselt: jetzt nur das Tablet');
  await t.evaluate(() => ab25Dialog(true)); await t.waitForTimeout(500);
  ok(await t.evaluate(() => /Dieses Gerät ist das Kalender-Hauptgerät/.test(document.querySelector('#modalBg').textContent)), 'Tablet-Dialog zeigt Kalender-Rolle');
  await pc.evaluate(() => ab25Dialog(true)); await pc.waitForTimeout(500);
  ok(await pc.evaluate(() => !!document.querySelector('#modalBg button[onclick="ab25HauptWerden()"]')), 'PC kann sich wieder zum Hauptgerät machen');
  const fe = [...pc.fe, ...h.fe, ...t.fe];
  ok(fe.length === 0, 'Keine Fehler ' + fe.join(' | '));
  await b.close(); console.log('FEHLER', f);
})();
