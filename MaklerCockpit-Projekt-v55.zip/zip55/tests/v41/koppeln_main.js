// google.js (Hauptprozess): Aktion „koppeln“ mit Kopplungscode
const Module = require('module'), fs = require('fs'), os = require('os'), path = require('path');
const orig = Module._load;
Module._load = function(r){ if(r === 'electron') return { shell: {}, safeStorage: { isEncryptionAvailable: () => false } }; return orig.apply(this, arguments); };
let f = 0; const ok = (b, t) => { console.log((b ? 'ok   ' : 'FEHL ') + t); if(!b) f++; };
const URL_ = 'https://script.google.com/macros/s/AKfycbTESTtestTESTtestTEST123/exec';
let antwort = { ok: true, version: 2, email: 'paul@example.org' }, gesendet = null;
global.fetch = async (u, o) => { gesendet = { u, body: JSON.parse(o.body) }; return { status: 200, text: async () => JSON.stringify(antwort) }; };
const handler = {}; const ipcMain = { handle: (n, fn) => { handler[n] = fn; }, on(){} };
const ORDNER = fs.mkdtempSync(path.join(os.tmpdir(), 'mc41-'));
require(process.argv[2] || '/tmp/pc/app/google.js')(ipcMain, ORDNER, () => {});
const G = (a, arg) => handler.google({}, a, arg);
const code = k => 'MC1-' + Buffer.from(JSON.stringify({ u: URL_, k, e: 'paul@example.org' })).toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
(async () => {
  let r = await G('status'); ok(!r.verbunden, 'neues Gerät: nicht verbunden');
  r = await G('koppeln', 'quatsch'); ok(!r.ok && /kein gültiger/.test(r.fehler), 'ungültiger Code abgelehnt');
  r = await G('koppeln', 'MC1-' + Buffer.from('{"u":"https://evil.example/x","k":"12345678"}').toString('base64').replace(/=+$/, '')); ok(!r.ok && /unvollständig/.test(r.fehler), 'fremde Adresse abgelehnt (nur script.google.com)');
  antwort = { ok: false, code: 'schluessel' }; r = await G('koppeln', code('geheim123')); ok(!r.ok && /Schlüssel passt nicht/.test(r.fehler), 'falscher Schlüssel → klare Meldung');
  antwort = { ok: true, version: 1 }; r = await G('koppeln', code('geheim123')); ok(!r.ok && /Version 1/.test(r.fehler), 'altes Skript → Hinweis aktualisieren');
  antwort = { ok: true, version: 2, email: 'paul@example.org' }; r = await G('koppeln', code('geheim123'));
  ok(r.ok && r.verbunden && r.modus === 'skript' && gesendet.u === URL_ && gesendet.body.key === 'geheim123' && gesendet.body.aktion === 'test', 'gültiger Code → verbunden (Test-Aufruf mit Schlüssel)');
  const k = fs.readFileSync(path.join(ORDNER, 'google-konto.json'), 'utf8');
  ok(!k.includes('geheim123') && !k.includes('AKfycb'), 'Zugang nur verschlüsselt/kodiert gespeichert, nicht im Klartext');
  r = await G('kopplung'); ok(r.ok && r.code === code('geheim123'), 'dieses Gerät kann jetzt selbst den Code für das nächste Gerät zeigen');
  console.log('FEHLER', f);
})();
