// v52: Hausverwaltungen – Bild-Anhang an der Mail, Call-Hilfe **fett**
const { chromium } = require('playwright');
let f = 0; const ok = (b, t) => { console.log((b ? 'ok   ' : 'FEHL ') + t); if(!b) f++; };
const HILFE = '**Einstieg:**\n„Guten Tag, Görner von BETTERHOMES.“\n\n**Angebot:**\n„Bei erfolgreicher Vermittlung erhalten Sie **25 % meiner Maklerprovision** – ohne Kosten.“\n\n**Abschluss:\n„An welche E-Mail-Adresse darf ich Ihnen die Informationen senden?“';
const D = JSON.stringify({ objekte: [], kontakte: [], termine: [], aufgaben: [], notizen: [], hv: { verwaltungen: [{ id: 'h1', name: 'Ralph Management GmbH', telefon: '030 42434555', ansprechpartner: 'Julius Gunnemann', status: 'offen' }], callHilfe: HILFE, callHilfeEigen: true }, meta: { v9neustart: { quittiert: true } } });
(async () => { const b = await chromium.launch();
  for(const [g, w, h] of [['pc', 1440, 900], ['handy', 412, 915]]){
    const p = await b.newPage({ viewport: { width: w, height: h }, isMobile: g === 'handy' });
    const fe = []; p.on('pageerror', e => fe.push(e.message));
    await p.addInitScript(([d, g]) => { window.__mails = []; window.__geoeffnet = []; window.pc = { geraet: g, laden: () => JSON.parse(d), speichern: () => ({ ok: true }), ordner(){}, sicherungSchreiben: () => ({ ok: true }), sicherungLesen: () => null, mailEntwurf: async a => { window.__mails.push(a); return { ok: true, weg: g === 'pc' ? 'outlook' : 'outlook' }; } }; const o = window.open; window.open = (u, ...r) => { window.__geoeffnet.push(String(u)); return null; }; }, [D, g]);
    await p.goto('file:///tmp/pc/app/index.html'); await p.waitForTimeout(2500);
    await p.evaluate(() => { try{ schliesseModal(); }catch(e){} const k = document.getElementById('an31Karte'); if(k) k.remove(); wechsleAnsicht('hausverwaltungen'); }); await p.waitForTimeout(1500);
    const fr = p.frames().find(x => x !== p.mainFrame() && /hvFrame/.test(x.name() + '') ) || p.frames().find(x => x !== p.mainFrame());
    // Call-Hilfe
    await fr.evaluate(() => oeffneHVModal('h1')); await p.waitForTimeout(300);
    const hil = await fr.evaluate(() => { renderHilfe(); const el = document.getElementById('hilfe'); return { txt: el.innerText, koepfe: Array.from(el.querySelectorAll('.h-kopf')).map(x => x.textContent), fett: Array.from(el.querySelectorAll('.text b')).map(x => x.textContent), chips: Array.from(el.querySelectorAll('.hnav .chip')).map(x => x.textContent) }; });
    ok(!/\*\*/.test(hil.txt), g + ': Call-Hilfe zeigt keine ** mehr');
    ok(hil.koepfe.join('|') === 'Einstieg|Angebot|Abschluss' && hil.fett.includes('25 % meiner Maklerprovision'), g + ': Überschriften ' + hil.koepfe.join('|') + ', fett: ' + hil.fett.join(','));
    ok(hil.chips.length === 3, g + ': Sprungmarken oben (' + hil.chips.join(', ') + ')');
    // Dialog öffnen, Mail ohne Bild → wie bisher mailto
    await fr.evaluate(() => oeffneHVModal('h1')); await p.waitForTimeout(300);
    ok(await fr.evaluate(() => /Bild anhängen/.test(document.querySelector('.hv46-mail').innerText)), g + ': Mail-Zeile zeigt „📎 Bild anhängen“');
    await fr.evaluate(() => { document.getElementById('h_mail_schnell').value = 'info@ralph-management.de'; document.getElementById('h_mail_schnell').dispatchEvent(new Event('input')); hv46Mail('h1'); }); await p.waitForTimeout(300);
    const ohne = await p.evaluate(() => ({ g: window.__geoeffnet.slice(), m: window.__mails.length }));
    ok(ohne.m === 0 && ohne.g.some(u => /^mailto:info@ralph-management\.de\?subject=/.test(u)), g + ': ohne Bild → Outlook wie bisher (mailto)');
    // Bild in der Vorlage wählen
    await fr.evaluate(() => hv46Vorlage('h1')); await p.waitForTimeout(300);
    await fr.setInputFiles('.hv52-wahl input[type=file]', '/tmp/v52/uebersicht.png'); await p.waitForTimeout(1500);
    const bild = await p.evaluate(() => db.hv && db.hv.mailBild ? { name: db.hv.mailBild.name, kb: Math.round(db.hv.mailBild.b64.length * 0.75 / 1024), jpg: db.hv.mailBild.b64.startsWith('/9j/') } : null);
    ok(bild && bild.jpg && bild.kb < 600 && bild.name === 'uebersicht.jpg', g + ': Bild gespeichert, verkleinert (' + JSON.stringify(bild) + ')');
    ok(await fr.evaluate(() => !!document.querySelector('#hv52Vorschau img')), g + ': Vorschau im Vorlage-Dialog');
    await fr.evaluate(() => { db.mailVorlage = document.getElementById('hv46Text').value; save(); oeffneHVModal('h1'); }); await p.waitForTimeout(300);
    ok(await fr.evaluate(() => /📎 uebersicht\.jpg/.test(document.querySelector('.hv46-mail').innerText)), g + ': Mail-Zeile zeigt „📎 uebersicht.jpg“');
    await fr.evaluate(() => hv46Mail('h1')); await p.waitForTimeout(500);
    const mit = await p.evaluate(() => window.__mails[0] || null);
    ok(mit && mit.an === 'info@ralph-management.de' && /Vermietung/.test(mit.betreff) && /Sehr geehrte|Guten Tag Julius Gunnemann/.test(mit.text) && mit.bild && mit.bild.b64.length > 1000 && mit.bild.name === 'uebersicht.jpg', g + ': mit Bild → Entwurf mit Empfänger, Betreff, Text und Bild (' + (mit && mit.text.split('\n')[0]) + ')');
    ok(await p.evaluate(() => window.__geoeffnet.filter(u => /^mailto:/.test(u)).length === 1), g + ': kein zusätzliches mailto');
    // Fehler im Mailprogramm → Rückfall auf mailto
    await p.evaluate(() => { window.pc.mailEntwurf = async () => ({ ok: false, fehler: 'Test' }); });
    await fr.evaluate(() => hv46Mail('h1')); await p.waitForTimeout(400);
    ok(await p.evaluate(() => window.__geoeffnet.filter(u => /^mailto:/.test(u)).length === 2), g + ': geht das Anhängen schief → Mail ohne Bild + Hinweis');
    ok(!fe.length, g + ': keine JS-Fehler ' + fe.slice(0, 3).join(' | '));
    if(g === 'pc'){ await fr.evaluate(() => hv46Vorlage('h1')); await p.waitForTimeout(300); await p.screenshot({ path: '/tmp/v52/vorlage.png' }); await fr.evaluate(() => { oeffneHVModal('h1'); }); await p.waitForTimeout(300); await p.screenshot({ path: '/tmp/v52/hilfe.png' }); }
    await p.close();
  } await b.close(); console.log(f ? 'FEHLER ' + f : 'ALLES OK'); process.exit(f ? 1 : 0); })();
