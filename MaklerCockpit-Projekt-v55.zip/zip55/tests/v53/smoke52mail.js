// v52 Smoke: Mail-Entwurf mit Bild über das echte Programm (Linux → Entwurfsdatei .eml; Windows zuerst Outlook)
const { app, BrowserWindow } = require('electron'); const fs = require('fs');
const HOME = '/tmp/claude-0/-home-claude/fcfe88c9-293d-574d-8cfa-b1821c923895/scratchpad/etest/home52mail';
fs.rmSync(HOME, { recursive: true, force: true }); app.setPath('documents', HOME + '/Dokumente');
const geoeffnet = []; require('electron').shell.openPath = async p => { geoeffnet.push(p); return ''; };
require(process.env.MC_MAIN || '/tmp/pc/app/main.js');
const warte = ms => new Promise(r => setTimeout(r, ms));
app.whenReady().then(() => setTimeout(async () => {
  let fehler = 0; const ok = (b, t) => { console.log((b ? 'ok   ' : 'FEHL ') + t); if(!b) fehler++; };
  try{
    const w = BrowserWindow.getAllWindows()[0];
    const b64 = fs.readFileSync('/tmp/v51/bild.jpg').toString('base64');
    const r = await w.webContents.executeJavaScript(`window.pc.mailEntwurf({ an: 'info@ralph-management.de', betreff: 'Vermietung – wie telefonisch besprochen', text: 'Guten Tag Herr Gunnemann,\\nvielen Dank … äöü €', bild: { name: 'Übersicht Görner.jpg', b64: ${JSON.stringify(b64)} } })`);
    ok(r && r.ok && r.weg === 'eml' && geoeffnet.length === 1 && /Anschreiben\.eml$/.test(geoeffnet[0]), 'Entwurf erzeugt und geöffnet: ' + JSON.stringify(r));
    const t = fs.readFileSync(geoeffnet[0], 'utf8');
    ok(/^To: info@ralph-management\.de\r\n/.test(t) && /\r\nX-Unsent: 1\r\n/.test(t) && /Content-Disposition: attachment; filename="=\?UTF-8\?B\?/.test(t) && t.includes(b64.slice(0, 60)), 'Entwurf: Empfänger, „ungesendet“, Bild als Anhang');
    const r2 = await w.webContents.executeJavaScript(`window.pc.mailEntwurf({ an: 'kein-mail', betreff: 'x', text: 'y' })`);
    ok(r2 && !r2.ok, 'ungültige Adresse abgelehnt');
    const r3 = await w.webContents.executeJavaScript(`window.pc.mailEntwurf({ an: 'a@b.de', betreff: 'x', text: 'y', bild: { name: 'x.jpg', b64: btoa('<html>kein Bild</html>') } })`);
    ok(r3 && !r3.ok && /JPG oder PNG/.test(r3.fehler), 'kein echtes Bild → abgelehnt');
  }catch(e){ ok(false, 'Ausnahme: ' + e.message); }
  console.log(fehler ? 'FEHLER ' + fehler : 'FEHLER 0'); app.exit(fehler ? 1 : 0);
}, 3500));
