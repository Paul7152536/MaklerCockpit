// Test google.js (Hauptprozess) mit nachgebautem Electron und Google
const Module = require('module'); const http = require('http'); const fs = require('fs'); const os = require('os'); const path = require('path');
let fehler = 0; const ok = (b, t) => { if(!b){ fehler++; console.log('FEHLER:', t); } else console.log('ok  ', t); };
const ORDNER = fs.mkdtempSync(path.join(os.tmpdir(), 'gk-'));
let browserVerhalten = 'erlauben', letzteAuthUrl = null;
const electron = {
  shell: { openExternal: async (url) => { letzteAuthUrl = new URL(url); const p = letzteAuthUrl.searchParams;
    const red = p.get('redirect_uri'); setTimeout(() => {
      const q = browserVerhalten === 'erlauben' ? `code=CODE123&state=${p.get('state')}` : browserVerhalten === 'falscherState' ? 'code=X&state=nope' : `error=access_denied&state=${p.get('state')}`;
      http.get(red + '/favicon.ico', r => r.resume());
      http.get(red + '/?' + q, r => { let b=''; r.on('data', d => b += d); r.on('end', () => { seite = b; }); });
    }, 30); } },
  safeStorage: { isEncryptionAvailable: () => true, encryptString: s => Buffer.from('§' + s), decryptString: b => b.toString().slice(1) }
};
let seite = '';
const origLoad = Module._load; Module._load = function(req, ...r){ if(req === 'electron') return electron; return origLoad.call(this, req, ...r); };
let handler; const ipcMain = { handle: (n, f) => { handler = f; } };
// Google nachbauen
let tokenAufrufe = [], apiAufrufe = [], api401 = 0, refreshFehler = null, scopeAntwort = 'openid https://www.googleapis.com/auth/userinfo.email https://www.googleapis.com/auth/calendar';
const idt = 'x.' + Buffer.from(JSON.stringify({email:'paul@example.com'})).toString('base64url') + '.y';
global.fetch = async (url, opt = {}) => {
  const u = String(url);
  const antw = (st, obj) => ({ ok: st < 300, status: st, json: async () => obj, text: async () => obj === null ? '' : JSON.stringify(obj) });
  if(u === 'https://oauth2.googleapis.com/token'){
    const b = new URLSearchParams(opt.body); tokenAufrufe.push(Object.fromEntries(b));
    if(b.get('grant_type') === 'authorization_code'){
      if(b.get('code') !== 'CODE123' || !b.get('code_verifier') || !b.get('redirect_uri').startsWith('http://127.0.0.1:')) return antw(400, {error:'invalid_grant'});
      return antw(200, { access_token: 'AT1', expires_in: 3600, refresh_token: 'RT1', scope: scopeAntwort, id_token: idt });
    }
    if(refreshFehler) return antw(400, { error: refreshFehler });
    return antw(200, { access_token: 'AT' + (tokenAufrufe.length + 1), expires_in: 3600 });
  }
  if(u.startsWith('https://oauth2.googleapis.com/revoke')) return antw(200, {});
  if(u.startsWith('https://www.googleapis.com/calendar/v3/')){
    apiAufrufe.push({ u, m: opt.method, auth: opt.headers.authorization, body: opt.body });
    if(api401 > 0){ api401--; return antw(401, { error: { code: 401 } }); }
    if(u.includes('/users/me/calendarList')) return antw(200, { items: [{ id: 'primary@x', summary: 'Paul', primary: true, accessRole: 'owner' }] });
    if(u.includes('/calendars/aus/')) return antw(403, { error: { code: 403, message: 'Google Calendar API has not been used', errors: [{ reason: 'accessNotConfigured' }] } });
    return antw(200, { items: [], echo: opt.body ? JSON.parse(opt.body) : null });
  }
  throw new Error('unerwartet ' + u);
};
require('/tmp/pc/app/google.js')(ipcMain, ORDNER, () => {});
const ruf = (a, arg) => handler({}, a, arg);
const JSON_DESKTOP = JSON.stringify({ installed: { client_id: '123-abc.apps.googleusercontent.com', project_id: 'maklercockpit-123', client_secret: 'GOCSPX-geheim12345', redirect_uris: ['http://localhost'] } });
(async () => {
  let s = await ruf('status'); ok(s.ok && !s.eingerichtet && !s.verbunden, 'Status leer');
  let r = await ruf('einrichten', { json: JSON.stringify({ web: { client_id: 'x.apps.googleusercontent.com', client_secret: 'abcdefghijkl' } }) });
  ok(!r.ok && /Desktop-App/.test(r.fehler), 'Web-Client wird abgelehnt: ' + r.fehler);
  r = await ruf('einrichten', { json: 'kaputt' }); ok(!r.ok && /keine gültige/.test(r.fehler), 'kaputte Datei');
  r = await ruf('einrichten', { clientId: 'falsch', secret: 'x' }); ok(!r.ok, 'falsche ID von Hand');
  r = await ruf('einrichten', { json: JSON_DESKTOP }); ok(r.ok && r.eingerichtet && !r.verbunden && r.projekt === 'maklercockpit-123', 'Desktop-Datei eingerichtet');
  const datei = JSON.parse(fs.readFileSync(path.join(ORDNER, 'google-konto.json'), 'utf8'));
  ok(datei.secret.startsWith('enc:') && !JSON.stringify(datei).includes('GOCSPX-geheim'), 'Schlüssel verschlüsselt gespeichert');
  // Abgelehnt im Browser
  browserVerhalten = 'ablehnen'; r = await ruf('verbinden'); ok(!r.ok && /nicht erlaubt/.test(r.fehler), 'Ablehnung erkannt: ' + r.fehler);
  await new Promise(r=>setTimeout(r,150)); ok(/nicht erlaubt/.test(seite), 'Browser zeigt Hinweisseite');
  // Erfolgreich
  browserVerhalten = 'erlauben'; r = await ruf('verbinden');
  ok(r.ok && r.verbunden && r.email === 'paul@example.com', 'Verbunden als ' + r.email);
  const p = letzteAuthUrl.searchParams;
  ok(p.get('code_challenge_method') === 'S256' && p.get('access_type') === 'offline' && p.get('scope').includes('auth/calendar') && p.get('prompt') === 'consent', 'Auth-URL korrekt (PKCE, offline, Kalender)');
  const tx = tokenAufrufe.find(t => t.grant_type === 'authorization_code');
  ok(tx && tx.code_verifier && tx.code_verifier.length > 40 && tx.client_secret === 'GOCSPX-geheim12345', 'Code-Tausch mit Verifier');
  await new Promise(r=>setTimeout(r,150)); ok(/verbunden/.test(seite), 'Browser-Erfolgsseite');
  const datei2 = fs.readFileSync(path.join(ORDNER, 'google-konto.json'), 'utf8');
  ok(!datei2.includes('RT1') && JSON.parse(datei2).refresh.startsWith('enc:'), 'Refresh-Token verschlüsselt');
  // API: erster Aufruf mit AT1, dann 401 → neues Token
  r = await ruf('api', { methode: 'GET', pfad: '/users/me/calendarList', query: { minAccessRole: 'writer' } });
  ok(r.ok && r.data.items.length === 1 && apiAufrufe[0].auth === 'Bearer AT1', 'Kalenderliste mit gespeichertem Token');
  api401 = 1; const vorher = tokenAufrufe.length;
  r = await ruf('api', { methode: 'POST', pfad: '/calendars/primary/events', body: { summary: 'Test' } });
  ok(r.ok && tokenAufrufe.length === vorher + 1 && apiAufrufe[apiAufrufe.length-1].auth !== 'Bearer AT1', '401 → Token erneuert, Wiederholung klappt');
  ok(r.data.echo && r.data.echo.summary === 'Test', 'Body durchgereicht');
  r = await ruf('api', { methode: 'GET', pfad: '/calendars/primary/events', query: { eventTypes: ['default', 'birthday'], leer: '' } });
  ok(/eventTypes=default&eventTypes=birthday/.test(apiAufrufe[apiAufrufe.length-1].u) && !/leer=/.test(apiAufrufe[apiAufrufe.length-1].u), 'Mehrfach-Parameter');
  r = await ruf('api', { methode: 'GET', pfad: '/../../oauth2' }); ok(!r.ok && /nicht erlaubt/.test(r.fehler), 'fremder Pfad gesperrt');
  r = await ruf('api', { methode: 'GET', pfad: 'https://evil' }); ok(!r.ok, 'URL gesperrt');
  r = await ruf('api', { methode: 'GET', pfad: '/calendars/aus/events' }); ok(!r.ok && r.code === 'api_aus' && /Calendar API/.test(r.fehler), 'API nicht aktiviert erkannt');
  // Neustart: Datei neu laden (neue Instanz)
  let handler2; require('/tmp/pc/app/google.js')({ handle: (n, f) => handler2 = f }, ORDNER, null);
  s = await handler2({}, 'status'); ok(s.verbunden && s.email === 'paul@example.com', 'Nach Neustart weiter verbunden');
  // Refresh widerrufen → abgelaufen
  refreshFehler = 'invalid_grant';
  r = await handler2({}, 'api', { methode: 'GET', pfad: '/users/me/calendarList' });
  ok(!r.ok && r.code === 'abgelaufen' && /Produktion/.test(r.fehler), 'Abgelaufener Zugang erkannt');
  s = await handler2({}, 'status'); ok(!s.verbunden && s.eingerichtet, 'Danach: eingerichtet, nicht verbunden');
  refreshFehler = null;
  // Fehlende Kalender-Freigabe
  scopeAntwort = 'openid email'; r = await ruf('verbinden'); ok(!r.ok && r.fehler.includes('Häkchen'), 'Kalender-Häkchen fehlt erkannt');
  scopeAntwort = 'openid https://www.googleapis.com/auth/calendar';
  r = await ruf('verbinden'); ok(r.ok && r.verbunden, 'Erneut verbunden');
  r = await ruf('trennen', {}); ok(r.ok && !r.verbunden && r.eingerichtet, 'Getrennt (Zugangsdatei bleibt)');
  r = await ruf('trennen', { allesLoeschen: true }); ok(r.ok && !r.eingerichtet, 'Alles gelöscht');
  // Abbrechen während Anmeldung
  await ruf('einrichten', { json: JSON_DESKTOP });
  electron.shell.openExternal = async () => {};
  const lauf = ruf('verbinden'); await new Promise(r => setTimeout(r, 50));
  s = await ruf('status'); ok(s.anmeldungLaeuft, 'Anmeldung läuft');
  await ruf('abbrechen'); r = await lauf; ok(!r.ok && /abgebrochen/.test(r.fehler), 'Abbrechen beendet Anmeldung');
  console.log('\nFEHLER', fehler); process.exit(fehler ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
