// Bildschirmfotos aller Hauptseiten mit realistischen Daten (Desktop + Handy) als Kontaktbögen
const { chromium } = require('playwright'); const fs = require('fs');
const BREITE = +(process.argv[2] || 1440), HOEHE = BREITE < 600 ? 844 : 900, TAG = process.argv[3] || 'pc';
const heute = new Date(); const tag = d => { const t = new Date(heute); t.setDate(t.getDate() + d); return t.toISOString().slice(0, 10); };
const strassen = ['Beuthstraße 29', 'Frankfurter Allee 112', 'Möllendorffstraße 8', 'Am Gutspark 7a', 'Dorfstraße 3', 'Weitlingstraße 41', 'Alt-Friedrichsfelde 60', 'Rhinstraße 12', 'Landsberger Allee 200', 'Seestraße 5'];
const orte = ['13156 Berlin', '10365 Berlin', '10367 Berlin', '14612 Falkensee', '15366 Neuenhagen', '10317 Berlin', '10315 Berlin', '10318 Berlin', '10369 Berlin', '15345 Altlandsberg'];
const st = ['neu', 'email_geschrieben', 'kontaktiert', 'termin', 'auftrag', 'online', 'neu', 'kontaktiert', 'abgeschlossen', 'neu'];
const namen = ['Petra Krüger', 'Hans Schulz', 'Monika Weber', 'Familie Brandt', 'Jürgen Lehmann', 'Sabine Koch', 'Thomas Richter', 'Erika Neumann', 'Klaus Wolf', 'Andrea Schröder'];
const kontakte = namen.map((n, i) => ({ id: 'k' + i, createdAt: Date.now() - i * 864e5, name: n, telefon: '0171 22' + (33400 + i), email: i % 2 ? '' : n.split(' ')[1].toLowerCase() + '@example.org', kontaktart: i < 6 ? 'eigentuemer' : 'kaeufer', status: 'lead', prioritaet: 'mittel', notizen: '' }));
const objekte = strassen.map((s, i) => ({ id: 'o' + i, createdAt: Date.now() - i * 2e8, akqTitel: ['Helle 2-Zi.-Wohnung mit Balkon', 'Altbau-ETW nahe Ostkreuz', 'Kapitalanlage vermietet', 'Einfamilienhaus mit Garten', 'Baugrundstück 650 m²', 'Dachgeschoss mit Terrasse', 'Reihenhaus ruhig', 'ETW 3 Zimmer, Aufzug', 'MFH mit 6 Einheiten', 'Bungalow am See'][i], adresse: s, ort: orte[i], objektart: ['Wohnung', 'Wohnung', 'Wohnung', 'EFH', 'Grundstück', 'Wohnung', 'Reihenhaus', 'Wohnung', 'MFH', 'EFH'][i], status: st[i], kaufpreis: [189000, 329000, 245000, 589000, 210000, 459000, 399000, 365000, 1450000, 520000][i], wohnflaeche: [43, 78, 61, 140, 0, 95, 110, 84, 420, 98][i], baujahr: [1998, 1905, 1972, 2004, 0, 1910, 1995, 2015, 1960, 1975][i], verkaeuferName: i < 6 ? namen[i] : '', verkaeuferTelefon: i < 6 ? kontakte[i].telefon : '', eigentuemerId: i < 4 ? 'k' + i : null, quelle: ['Kleinanzeigen', 'Zeitung', 'Immoscout', 'Empfehlung', 'Kleinanzeigen', 'Zeitung', 'Kleinanzeigen', 'Immowelt', 'Empfehlung', 'Kleinanzeigen'][i], link: i % 3 === 0 ? 'https://www.kleinanzeigen.de/s-anzeige/' + (1000 + i) : '', verlauf: [], prioritaet: 'mittel' }));
const termine = [0, 0, 1, 2, 3, -1, -3, 5, 8].map((d, i) => ({ id: 't' + i, createdAt: 1, titel: ['Erstgespräch Krüger', 'Besichtigung Frankfurter Allee', 'Rückruf Schulz', 'Notar Beuthstraße', 'Fotos Möllendorffstraße', 'Besichtigung', 'Call Daniel', 'Bewertung Falkensee', 'Übergabe'][i], datum: tag(d), uhrzeit: ['10:00', '14:30', '09:00', '11:00', '16:00', '13:00', '18:00', '10:30', '12:00'][i], dauer: 60, art: ['erstgespraech', 'besichtigung', 'rueckruf', 'notar', 'termin', 'besichtigung', 'termin', 'bewertung', 'termin'][i], objektId: 'o' + (i % 10), kontaktId: 'k' + (i % 10), wo: 'vorort' }));
const aufgaben = ['Exposé Beuthstraße fertigstellen', 'Grundbuchauszug anfordern', 'Energieausweis Falkensee', 'Kleinanzeigen-Leads anschreiben', 'Rückruf Familie Brandt'].map((t, i) => ({ id: 'a' + i, titel: t, faellig: tag(i - 1), prioritaet: ['hoch', 'mittel', 'mittel', 'niedrig', 'hoch'][i], objektId: 'o' + i, kontaktId: null, status: 'offen', notiz: '' }));
const gesuche = ['Familie Brandt', 'Herr Yilmaz', 'Frau Becker', 'Dr. Hoffmann'].map((n, i) => ({ id: 'g' + i, status: 'aktiv', name: n, telefon: '0152 ' + (3000000 + i), arten: [['DHH', 'EFH'], ['Wohnung'], ['Wohnung'], ['MFH']][i], orte: [['Falkensee', 'Dallgow'], ['Lichtenberg'], ['Pankow'], ['Berlin']][i], budgetMax: [550000, 300000, 250000, 1500000][i] }));
const D = { objekte, kontakte, termine, aufgaben, notizen: [{ id: 'n1', createdAt: Date.now(), text: 'Frau Krüger will erst nach Ostern verkaufen', verarbeitet: false }], gesuche, marktanalysen: [], mentorFragen: [], meta: { v9neustart: { quittiert: true } } };
(async () => {
  const b = await chromium.launch();
  const p = await b.newPage({ viewport: { width: BREITE, height: HOEHE }, deviceScaleFactor: 1 });
  const fe = []; p.on('pageerror', e => fe.push(e.message)); p.on('dialog', d => d.dismiss());
  await p.addInitScript(d => { window.pc = { geraet: 'pc', laden: () => JSON.parse(d), speichern: () => ({ ok: true }), ordner(){}, sicherungSchreiben: () => ({ ok: true }), sicherungLesen: () => null, zwischenablage: async () => '', abruf: async () => ({ ok: false }) }; }, JSON.stringify(D));
  await p.goto('file:///tmp/pc/app/index.html'); await p.waitForTimeout(2500);
  const seiten = ['heute', 'akquise', 'objekte', 'kontakte', 'termine', 'kaeufer', 'aufgaben', 'notizen', 'dashboard', 'jarvis', 'marktanalyse24', 'investments24', 'kooperationen', 'hausverwaltungen', 'immowert', 'marketing'];
  fs.mkdirSync('/tmp/v28test/bilder', { recursive: true });
  for(const s of seiten){
    await p.evaluate(s => { try{ schliesseModal(); }catch(e){} wechsleAnsicht(s); window.scrollTo(0, 0); const m = document.getElementById('main'); if(m) m.scrollTop = 0; }, s); await p.waitForTimeout(500);
    await p.screenshot({ path: `/tmp/v28test/bilder/${TAG}_${s}.png` });
  }
  await p.evaluate(() => { wechsleAnsicht('akquise'); AQ2.status = 'alle'; AQ2.sel = 'o0'; renderMain(); }); await p.waitForTimeout(400); await p.screenshot({ path: `/tmp/v28test/bilder/${TAG}_lead.png` });
  await p.evaluate(() => ob24Oeffnen('o0')); await p.waitForTimeout(400); await p.screenshot({ path: `/tmp/v28test/bilder/${TAG}_akte.png` });
  await p.evaluate(() => oeffneObjektModal('o0')); await p.waitForTimeout(400); await p.screenshot({ path: `/tmp/v28test/bilder/${TAG}_objektdialog.png` });
  console.log('Fehler', JSON.stringify(fe)); await b.close();
})();
