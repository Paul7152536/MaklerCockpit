// HTML-Einschleusung: viele Dialoge/Panels mit präparierten Daten öffnen
const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 1440, height: 900 } });
  const fe = []; p.on('pageerror', e => fe.push(e.message.slice(0, 160))); p.on('dialog', d => d.dismiss());
  const X = `"><img src=x onerror="window.__xss=(window.__xss||0)+1">'`;
  const heute = new Date(); const tag = d => { const t = new Date(heute); t.setDate(t.getDate() + d); return t.toISOString().slice(0, 10); };
  const D = { objekte: Array.from({ length: 6 }, (_, i) => ({ id: 'o' + i, createdAt: 1, akqTitel: 'T' + X, adresse: 'A' + X, ort: '10365 Berlin' + X, objektart: 'Wohnung', status: ['neu', 'termin', 'auftrag', 'kontaktiert', 'online', 'neu'][i], kaufpreis: 200000, wohnflaeche: 50, verkaeuferName: 'N' + X, verkaeuferTelefon: '0171 1' + i, verkaeuferEmail: 'm' + i + '@x.de', eigentuemerId: i < 3 ? 'k' + i : null, quelle: ['Kleinanzeigen', 'Zeitung'][i % 2], link: 'https://www.kleinanzeigen.de/s-anzeige/' + i + X, verlauf: [{ t: Date.now(), typ: 'info', text: 'V' + X }], notizen: '', anschreibenText: 'S' + X })),
    kontakte: Array.from({ length: 4 }, (_, i) => ({ id: 'k' + i, createdAt: 1, name: 'K' + X, telefon: '0171 1' + i, email: 'm' + i + '@x.de', kontaktart: 'eigentuemer', status: 'lead', prioritaet: 'hoch', notizen: 'KN' + X })),
    termine: [-2, 0, 0, 1, 1, 2, 5].map((d, i) => ({ id: 't' + i, createdAt: 1, titel: 'Termin' + X, datum: tag(d), uhrzeit: '1' + i + ':00', dauer: 30, art: 'erstgespraech', objektId: 'o' + (i % 6), kontaktId: 'k' + (i % 4), wo: 'vorort', ort: 'Ort' + X, notiz: '' })),
    aufgaben: [-3, 0, 1].map((d, i) => ({ id: 'a' + i, titel: 'Aufgabe' + X, faellig: tag(d), prioritaet: 'hoch', objektId: 'o' + i, kontaktId: 'k' + i, status: 'offen', notiz: 'AN' + X })),
    notizen: [{ id: 'n1', createdAt: Date.now(), text: 'Notiz' + X, verarbeitet: false }],
    gesuche: [{ id: 'g1', status: 'aktiv', name: 'G' + X, telefon: '0152 1', arten: ['Wohnung'], orte: ['Lichtenberg' + X], budgetMax: 300000, notiz: X }],
    mentorFragen: [{ id: 'm1', text: 'Frage' + X, erledigt: false, createdAt: 1 }], marktanalysen: [], meta: { v9neustart: { quittiert: true } } };
  await p.addInitScript(d => { window.pc = { geraet: 'pc', laden: () => JSON.parse(d), speichern: () => ({ ok: true }), ordner(){}, sicherungSchreiben: () => ({ ok: true }), sicherungLesen: () => null, zwischenablage: async () => '', abruf: async () => ({ ok: false }) }; }, JSON.stringify(D));
  await p.goto('file:///tmp/pc/app/index.html'); await p.waitForTimeout(2500);
  await p.evaluate(() => { window.__xss = 0; });
  const schritte = [
    ['Start (Heute)', ''], ['Tagescheck', 'oeffneTagescheck()'], ['Unterwegs-Modus', 'oeffneUnterwegsModus()'], ['Tag-Dialog', `oeffneTagModal(new Date().toISOString().slice(0,10))`],
    ['Aufgabe-Dialog', "oeffneAufgabeModal('a0')"], ['Notiz-Dialog', "oeffneNotizModal('n1')"], ['Suchkunde', "skBearbeiten('g1')"], ['Termin-Dialog', "oeffneTerminModal('t1')"],
    ['Briefing', "ak24Briefing({ objektId: 'o1' })"], ['Gespräch abschließen', "ak24Abschluss({ objektId: 'o1' })"], ['Regeln', 'ak24RegelnDialog()'], ['Auswertung', 'aqAuswertung()'],
    ['Menü', 'tbMenue()'], ['Kontakt-Dialog', "oeffneKontaktModal('k0')"], ['Objekt-Dialog o3', "oeffneObjektModal('o3')"], ['Akte o0', "ob24Oeffnen('o0')"], ['Akte o2', "ob24Oeffnen('o2')"],
    ['Käufer & Markt', "wechsleAnsicht('kaeufer')"], ['Suchkunden', "wechsleAnsicht('kaeufer'); typeof kgOeffnen==='function' && kgOeffnen('g1')"], ['Dashboard', "wechsleAnsicht('dashboard')"],
    ['Akquise Lead o5', "wechsleAnsicht('akquise'); AQ2.status='alle'; AQ2.sel='o5'; renderMain()"], ['Lead senden', "aq2Senden()"], ['Lead Termin', "typeof aq2TerminNeu==='function' && aq2TerminNeu()"],
    ['Glocke', "(document.querySelector('.tb-glocke, #tbGlocke, [onclick*=\"Hinweis\"]')||{click(){}}).click()"], ['Termine-Seite', "wechsleAnsicht('termine')"], ['Aufgaben-Seite', "wechsleAnsicht('aufgaben')"],
    ['Mietvergleich', "ob24Oeffnen('o3')"], ['Kooperationen', "wechsleAnsicht('kooperationen')"],
  ];
  for(const [name, js] of schritte){
    const r = await p.evaluate(js => { try{ if(js) eval(js); return ''; }catch(e){ return 'Fehler: ' + e.message; } }, js);
    await p.waitForTimeout(350);
    const x = await p.evaluate(() => { const v = window.__xss || 0; window.__xss = 0; return v; });
    console.log((x ? 'XSS! ' : '     ') + name + (r ? '  (' + r + ')' : ''));
    if(!/Lead senden|Lead Termin/.test(name)) await p.evaluate(() => { try{ schliesseModal(); }catch(e){} });
  }
  // globale Suche
  const s = await p.evaluate(() => { const i = document.querySelector('input[placeholder*="Suche nach Objekten"]'); if(!i) return 'kein Suchfeld'; i.focus(); i.value = 'T'; i.dispatchEvent(new Event('input', { bubbles: true })); return 'ok'; });
  await p.waitForTimeout(500); const xs = await p.evaluate(() => window.__xss || 0); console.log((xs ? 'XSS! ' : '     ') + 'Globale Suche ' + s);
  console.log('Seitenfehler', JSON.stringify(fe)); await b.close();
})();
