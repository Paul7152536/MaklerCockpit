// v28: Durchsicht – Sicherheit, Handy, Texte, Speichern
const { chromium } = require('playwright');
let f = 0; const ok = (b, t) => { console.log((b ? 'ok   ' : 'FEHL ') + t); if(!b) f++; };
(async () => {
  const b = await chromium.launch();
  const p = await b.newPage({ viewport: { width: 1440, height: 900 } });
  const fe = []; p.on('pageerror', e => fe.push(e.message)); p.on('dialog', d => d.dismiss());
  const netz = []; p.on('request', r => { if(/^https?:/.test(r.url())) netz.push(r.url()); });
  const heute = new Date(); const tag = d => { const t = new Date(heute); t.setDate(t.getDate() + d); return t.toISOString().slice(0, 10); };
  const X = `<img src=x onerror="window.__xss=(window.__xss||0)+1">`;
  await p.addInitScript(([d]) => { window.pc = { geraet: 'pc', laden: () => JSON.parse(d), speichern: t => { window.__gespeichert = t; return { ok: true }; }, ordner(){}, sicherungSchreiben: () => ({ ok: true }), sicherungLesen: () => null, zwischenablage: async () => '', abruf: async () => ({ ok: false }) }; }, [JSON.stringify({
    objekte: [
      { id: 'o1', createdAt: 1, adresse: 'Beuthstraße 29', ort: '13156 Berlin', objektart: 'Wohnung', status: 'neu', quelle: 'Kleinanzeigen', link: 'https://www.kleinanzeigen.de/s-anzeige/1', verlauf: [], notizen: `<b>Fett</b><br><div>Zeile <i>kursiv</i></div><a href="https://example.org" onclick="window.__xss=9">Link</a><a href="javascript:window.__xss=7">böse</a><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==" onerror="window.__xss=5"><script>window.__xss=3<\/script>${X}<svg onload="window.__xss=4"></svg>Ende`, verkaeuferName: 'Petra Krüger', verkaeuferTelefon: '0171 2223334', verkaeuferEmail: 'a@b.de" onmouseover="window.__xss=2' },
      { id: 'o2', createdAt: 1, adresse: 'Frankfurter Allee 1', ort: '10365 Berlin', objektart: 'Wohnung', status: 'neu', quelle: 'Zeitung', verlauf: [] },
      { id: 'o3', createdAt: 1, adresse: 'Seestraße 5', ort: '15345 Altlandsberg', objektart: 'EFH', status: 'neu', quelle: 'Immoscout', link: 'https://www.immobilienscout24.de/expose/1', verlauf: [] },
      { id: 'o4', createdAt: 1, adresse: 'Rhinstraße 12', ort: '10315 Berlin', objektart: 'Wohnung', status: 'auftrag', quelle: 'Empfehlung', verlauf: [] },
      { id: 'o5', createdAt: 1, adresse: 'Am See 1', ort: '10315 Berlin', objektart: 'Wohnung', status: 'neu', quelle: '', auftragsart: 'vermietung', verlauf: [] }],
    kontakte: [{ id: 'k1', createdAt: 1, name: 'Hans Schulz', telefon: '0171 9" onmouseover="x', email: 'h@s.de', kontaktart: 'eigentuemer', status: 'lead', prioritaet: 'mittel' }],
    termine: [{ id: 't1', createdAt: 1, titel: 'Google-Einladung ' + X, datum: tag(1), uhrzeit: '10:00', dauer: 30, art: 'termin', objektId: 'o1', wo: 'vorort', notiz: '' }],
    aufgaben: [{ id: 'a1', titel: 'Überfällig ' + X, faellig: tag(-3), prioritaet: 'hoch', objektId: 'o1', status: 'offen', notiz: '' }, { id: 'a2', titel: 'Heute ' + X, faellig: tag(0), prioritaet: 'hoch', status: 'offen' }],
    notizen: [], gesuche: [], marktanalysen: [], mentorFragen: [], meta: { v9neustart: { quittiert: true } } })]);
  await p.goto('file:///tmp/pc/app/index.html'); await p.waitForTimeout(2500);
  ok(/v(2[89]|[3-9][0-9])/.test(await p.evaluate(() => document.querySelector('.sb-logo') ? document.querySelector('.sb-logo').textContent : '')), 'Version ab v28 im Logo');
  ok(netz.length === 0 && await p.evaluate(() => typeof window.Sortable === 'function'), 'Start ohne Internet-Abruf, Sortierhilfe lokal geladen ' + JSON.stringify(netz));
  // Notizen säubern
  await p.evaluate(() => { window.__xss = 0; oeffneObjektModal('o1'); }); await p.waitForTimeout(500);
  let r = await p.evaluate(() => { const n = document.getElementById('m_notizen'); return { html: n.innerHTML, xss: window.__xss || 0 }; });
  ok(r.xss === 0 && !/onerror|onclick|onload|<script|<svg|javascript:/i.test(r.html), 'Notiz: Skripte/Ereignisse entfernt');
  ok(/<b>Fett<\/b>/.test(r.html) && /<i>kursiv<\/i>/.test(r.html) && /href="https:\/\/example.org"/.test(r.html) && /<img src="data:image\/png/.test(r.html) && /Ende/.test(r.html), 'Notiz: Formatierung, Link und eingefügtes Bild bleiben');
  r = await p.evaluate(() => { zeigeEigentuemerKontakt(); const a = Array.from(document.querySelectorAll('#eigentuemerKontaktBox a')); return { attr: a.some(x => Array.from(x.attributes).some(at => /^on/i.test(at.name))), href: a.map(x => x.getAttribute('href')).join(' ') }; });
  ok(!r.attr && /mailto:a@b.de/.test(r.href), 'Verkäufer-E-Mail sicher im Link (' + r.href + ')');
  r = await p.evaluate(() => document.querySelector('#gespraechBody p').innerText);
  ok(/Anzeige bei Kleinanzeigen/.test(r) && !/Zeitung/.test(r), 'Leitfaden Kleinanzeigen-Lead: „' + r.slice(0, 90) + '…“');
  const lf = async id => { await p.evaluate(id => { schliesseModal(); oeffneObjektModal(id); }, id); await p.waitForTimeout(200); return p.evaluate(() => ({ t: document.querySelector('#gespraechBody p').innerText, zu: document.getElementById('gespraechBody').style.display === 'none' })); };
  r = await lf('o2'); ok(/in der Zeitung/.test(r.t) && !r.zu, 'Leitfaden Zeitungs-Lead');
  r = await lf('o3'); ok(/ImmoScout24/.test(r.t), 'Leitfaden ImmoScout-Lead');
  r = await lf('o4'); ok(/Empfehlung/.test(r.t) && r.zu, 'Betreutes Objekt: Leitfaden eingeklappt');
  r = await lf('o5'); ok(/noch zu vermieten ist/.test(r.t) && /aufmerksam geworden/.test(r.t), 'Vermietung: „noch zu vermieten“');
  await p.evaluate(() => schliesseModal());
  // Kontakt im Objekt
  await p.evaluate(() => { findObjekt('o2').eigentuemerId = 'k1'; window.__xss = 0; oeffneObjektModal('o2'); }); await p.waitForTimeout(300);
  r = await p.evaluate(() => { const a = Array.from(document.querySelectorAll('#eigentuemerKontaktBox a')); return { attr: a.some(x => Array.from(x.attributes).some(at => /^on/i.test(at.name))), href: a.map(x => x.getAttribute('href')).join(' ') }; });
  ok(!r.attr && /tel:01719/.test(r.href), 'Kontakt-Telefon sicher im Link (' + r.href + ')');
  await p.evaluate(() => schliesseModal());
  // Tagescheck
  await p.evaluate(() => { window.__xss = 0; oeffneTagescheck(); }); await p.waitForTimeout(500);
  r = await p.evaluate(() => ({ t: document.getElementById('modalInner').innerText, x: window.__xss || 0 }));
  const d3 = (() => { const t = new Date(); t.setDate(t.getDate() - 3); return String(t.getDate()).padStart(2, '0') + '.' + String(t.getMonth() + 1).padStart(2, '0') + '.' + t.getFullYear(); })();
  ok(r.x === 0 && /Google-Einladung <img/.test(r.t) && r.t.includes('fällig war ' + d3), 'Tagescheck: Titel als Text, Datum deutsch (' + d3 + ')');
  await p.evaluate(() => schliesseModal());
  // Aufgaben-Liste
  await p.evaluate(() => wechsleAnsicht('aufgaben')); await p.waitForTimeout(300);
  r = await p.evaluate(() => document.getElementById('main').innerText);
  ok(r.includes(d3) && !/\d{4}-\d{2}-\d{2}/.test(r), 'Aufgaben: Fälligkeit als ' + d3);
  // Speichern: ein JSON, gleiche Daten
  r = await p.evaluate(() => { findObjekt('o3').kaufpreis = 123456; _schreibe(); const g = JSON.parse(window.__gespeichert); return { k: g.objekte.find(o => o.id === 'o3').kaufpreis, gleich: JSON.stringify(db) === window.__gespeichert }; });
  ok(r.k === 123456 && r.gleich, 'Speichern: gespeicherter Stand = Stand im Programm');
  // Akte-Quelle
  r = await p.evaluate(() => { ob24Oeffnen('o1'); return document.getElementById('main').innerText; });
  ok(!/Bestand vor v24/.test(r), 'Objektakte ohne „Bestand vor v24“');
  // Marketing an der Seitenleiste
  await p.evaluate(() => wechsleAnsicht('marketing')); await p.waitForTimeout(800);
  r = await p.evaluate(() => ({ l: Math.round(document.getElementById('marketingOverlay').getBoundingClientRect().left), n: Math.round(document.getElementById('nav').getBoundingClientRect().width) }));
  ok(r.l === r.n && r.l > 100, `Marketing beginnt rechts neben der Seitenleiste (${r.l} px)`);
  await p.setViewportSize({ width: 390, height: 844 }); await p.waitForTimeout(400);
  r = await p.evaluate(() => Math.round(document.getElementById('marketingOverlay').getBoundingClientRect().left));
  ok(r === 0, 'Handy: Marketing über die ganze Breite');
  // Handy: Akquise-Knöpfe erreichbar
  await p.evaluate(() => wechsleAnsicht('akquise')); await p.waitForTimeout(400);
  r = await p.evaluate(() => Array.from(document.querySelectorAll('.aq-kopf .knoepfe button')).map(x => { const b = x.getBoundingClientRect(); return [x.innerText.trim(), Math.round(b.left), Math.round(b.right)]; }));
  ok(r.length >= 4 && r.every(([, l, re]) => l >= 0 && re <= 390), 'Handy: alle Akquise-Knöpfe sichtbar ' + JSON.stringify(r.map(x => x[0])));
  await p.screenshot({ path: '/tmp/v28test/handy_akquise_v28.png' });
  r = await p.evaluate(() => { wechsleAnsicht('termine'); return document.querySelector('.aq-kopf .sub').innerText; });
  ok(/an diesem PC|Ein Kalender/.test(r), 'Termine-Untertitel am PC');
  ok(fe.length === 0, 'Keine Fehler ' + JSON.stringify(fe));
  console.log('FEHLER', f); await b.close();
})();
