// v24 Smoke im echten Electron: Start, Daten-Import (v23-Stand), Marktanalyse mit 20 Vergleichen, PDF über den Hauptprozess,
// Briefing-PDF, Sicherung inkl. neuer Daten, Wiederherstellung per Import
const { app, BrowserWindow } = require('electron'); const fs = require('fs'); const path = require('path');
const BASIS = '/tmp/claude-0/-home-claude/fcfe88c9-293d-574d-8cfa-b1821c923895/scratchpad/etest';
const HOME = BASIS + '/home28', AUS = BASIS + '/aus28', CLOUD = BASIS + '/cloud28';
for(const d of [HOME, AUS, CLOUD]) fs.rmSync(d, { recursive: true, force: true });
fs.mkdirSync(AUS, { recursive: true }); fs.mkdirSync(CLOUD, { recursive: true });
app.setPath('documents', HOME + '/Dokumente');
const fehlerLog = [];
app.on('web-contents-created', (e, wc) => wc.on('console-message', (...a) => { const ev = a[0]; const lvl = ev && ev.level !== undefined ? ev.level : a[1]; const msg = ev && ev.message !== undefined ? ev.message : a[2]; if((lvl === 3 || lvl === 'error') && !/ERR_|Failed to load resource/.test(msg)) fehlerLog.push(msg); }));
require(process.env.MC_MAIN || '/tmp/pc/app/main.js');
const warte = ms => new Promise(r => setTimeout(r, ms));
const HEUTE = new Date().toISOString().slice(0, 10);
const FIX = { objekte: [{ id: 'o1', createdAt: Date.now() - 5e8, akqTitel: 'Helle 3-Zimmer-Wohnung', objektart: 'Wohnung', adresse: 'Musterstraße 12', ort: '10365 Berlin-Lichtenberg', status: 'termin', kaufpreis: 349000, wohnflaeche: 75, baujahr: '1995', zimmer: '3', verkaeuferName: 'Frau Krüger', verkaeuferTelefon: '0171 2223334', eigentuemerId: 'k1', verlauf: [] }],
  kontakte: [{ id: 'k1', createdAt: 1, name: 'Frau Krüger', telefon: '0171 2223334', email: '', kontaktart: 'eigentuemer', status: 'lead', prioritaet: 'mittel', notizen: '' }],
  termine: [{ id: 't1', createdAt: 1, titel: 'Erstgespräch', datum: HEUTE, uhrzeit: '14:00', dauer: 60, art: 'erstgespraech', objektId: 'o1', wo: 'vorort' }], aufgaben: [], notizen: [], marktanalysen: [], mentorFragen: [], meta: { v9neustart: { quittiert: true } } };
function vergleich(i){ return { id: 'c' + i, title: 'ETW Lichtenberg ' + i, source_url: `https://www.beispielportal.de/expose/${1000 + i}`, additional_source_urls: [], source_name: 'Beispielportal', accessed_at: HEUTE + 'T09:00:00+01:00', published_at: HEUTE, verification_status: 'verified', price_type: 'sale_asking', currency: 'EUR', price_eur: 300000 + i * 7000, monthly_net_rent_eur: null, warm_rent_eur: null, parking_eur: null, area_sqm: 68 + i, area_type: 'living', plot_sqm: null, rooms: 3, year_built: 1990 + i, location: { text: 'Teststraße ' + i + ', 10365 Berlin', district: 'Lichtenberg', postal_code: '10365', resolution: 'street' }, condition: 'well_kept', occupancy: 'vacant', energy: null, features: ['Balkon'], evidence: [{ fields: ['price_eur', 'area_sqm'], excerpt: 'Kaufpreis ' + (300000 + i * 7000) + ' € · ' + (68 + i) + ' m²', url: `https://www.beispielportal.de/expose/${1000 + i}` }], missing_fields: [], comparability: i % 4 ? 'good' : 'limited', comparability_reasons: [{ criterion: 'micro_location', assessment: 'good', reason: 'gleicher Ortsteil' }], duplicate_group: null, included: true, exclusion_reason: null }; }
const ANTWORT = { schema_version: 'mc-marktanalyse-1.0', subject_id: 'o1', analysis_type: 'sale', valuation_date: HEUTE, research_timestamp: HEUTE + 'T10:00:00+01:00', research_status: 'completed', search_strategy: { areas: ['Lichtenberg'], criteria: ['ETW 60–90 m²'], expansions: [], restrictions: [], sources_searched: ['Beispielportal'] }, comparables: Array.from({ length: 20 }, (_, i) => vergleich(i + 1)), unverified_candidates: [], subject_conflicts: [], data_quality: { level: 'medium', reasons: ['Test'] }, assumptions: [], limitations: [], summary: 'Test', strategy_notes: [] };

app.whenReady().then(() => setTimeout(async () => {
  let f = 0; const ok = (b, t) => { console.log((b ? 'ok   ' : 'FEHL ') + t); if(!b) f++; };
  try{
    let w = BrowserWindow.getAllWindows()[0]; const js = s => w.webContents.executeJavaScript(s);
    ok(/v28/.test(await js(`document.querySelector('.sb-logo').textContent`)), 'v28 startet');
    const lz = await js('performance.timing.loadEventEnd - performance.timing.navigationStart'); ok(lz > 0 && lz < 2500, 'Start ohne Warten aufs Internet: ' + lz + ' ms');
    ok(await js("typeof window.Sortable === 'function'"), 'Sortierhilfe (Bilder zu PDF) lokal geladen');
    const imp = await js(`window.pc.importieren(${JSON.stringify(JSON.stringify(FIX))})`);
    ok(imp && imp.ok, 'v23-Datenstand importiert');
    await js('window.__mcNichtSpeichern = true; location.reload()'); await warte(3500);
    w = BrowserWindow.getAllWindows()[0];
    ok(await js(`aktuelleAnsicht === 'heute' && !!findObjekt('o1').angaben && db.analysen24.length === 0`), 'Migration nach dem Laden, Startseite „Heute“');
    // Marktanalyse komplett
    await js(`(() => { const a = ma24Anlegen('o1', 'sale', true); MA24.sel = a.id; MA24.schritt = 'import'; wechsleAnsicht('marktanalyse24'); MA24.roh = ${JSON.stringify(JSON.stringify(ANTWORT))}; ma24ImportPruefenKlick(true); ma24Uebernehmen(); ma24AlleBestaetigen(); ma24Strat('angebotspreis', 379000); ma24Liste('staerken', 'Balkon'); ma24Abschliessen(); })()`);
    await warte(300);
    const st = JSON.parse(await js(`JSON.stringify((() => { const r = ma24AnalyseAuswerten(ma24A()); return { n: r.anzahl.verwendet, von: r.spanne && r.spanne.von, q: r.qualitaet.stufe, status: ma24A().status }; })())`));
    ok(st.n === 20 && st.von > 0 && st.status === 'abgeschlossen', `Analyse: 20 Vergleiche verwendet, Spanne ab ${Math.round(st.von)} €, Qualität ${st.q}`);
    // PDF über den echten Hauptprozess
    const pdf = JSON.parse(await js(`window.pc.htmlZuPdf(ma24BerichtHtmlFuer(ma24A())).then(r => JSON.stringify({ ok: r.ok, b64: r.base64, fehler: r.fehler }))`));
    ok(pdf.ok && pdf.b64, 'Eigentümerbericht als PDF erzeugt ' + (pdf.fehler || ''));
    const buf = Buffer.from(pdf.b64 || '', 'base64');
    fs.writeFileSync(AUS + '/bericht.pdf', buf);
    ok(buf.slice(0, 4).toString() === '%PDF' && buf.length > 20000, 'Gültiges PDF (' + Math.round(buf.length / 1024) + ' KB)');
    const br = JSON.parse(await js(`(async () => { ak24Briefing({ objektId: 'o1' }); const r = await window.pc.htmlZuPdf(ak24BriefingDruck()); schliesseModal(); return JSON.stringify({ ok: r.ok, b64: r.base64 }); })()`));
    fs.writeFileSync(AUS + '/briefing.pdf', Buffer.from(br.b64 || '', 'base64'));
    ok(br.ok, 'Gesprächsbriefing als PDF erzeugt');
    const leer = JSON.parse(await js(`window.pc.htmlZuPdf('').then(r => JSON.stringify(r))`));
    ok(!leer.ok && /Ungültig/.test(leer.fehler), 'Leerer Inhalt wird abgelehnt');
    // Daten für Sicherung: Gespräch + Investment
    await js(`(() => { AK24_AB = { objektId: 'o1' }; ak24AbschlussSpeichern({ kontaktId: 'k1', ergebnis: 'interesse', ergebnisText: 'Test', schritt: 'unterlagen', schrittText: 'Exposé', wann: '${HEUTE}', zeit: '', notiz: 'Notiz', einwand: 'preis', einwandWort: 'zu teuer', motiv: null }); iv24Anlegen('o1', true); save(); })()`);
    await warte(800);
    // Sicherung in „Cloud-Ordner“
    const si = await js(`window.pc.sicherung('jetzt', { ziel: ${JSON.stringify(CLOUD)} })`);
    ok(si && si.ok, 'Sicherung ausgeführt');
    const ges = JSON.parse(fs.readFileSync(CLOUD + '/MaklerCockpit-Sicherung/daten-aktuell.json', 'utf8'));
    ok(ges.analysen24.length === 1 && ges.analysen24[0].vergleiche.length === 20 && ges.invest24.pruefungen.length === 1 && ges.notizen.some(n => n.typ === 'gespraech') && ges.kontakte[0].einwaende.length === 1 && ges.module.akquise24 === true, 'Sicherung enthält Analysen (20 Vergleiche), Investment, Gespräch, Einwand, Modul-Einstellung');
    // Wiederherstellung: alles weg, dann Sicherung importieren
    await js(`window.pc.importieren(${JSON.stringify(JSON.stringify(FIX))})`);
    await js('window.__mcNichtSpeichern = true; location.reload()'); await warte(3000); w = BrowserWindow.getAllWindows()[0];
    ok(await js('db.analysen24.length === 0'), 'Zwischenstand ohne Analysen');
    const r2 = await js(`window.pc.importieren(${JSON.stringify(fs.readFileSync(CLOUD + '/MaklerCockpit-Sicherung/daten-aktuell.json', 'utf8'))})`);
    await js('window.__mcNichtSpeichern = true; location.reload()'); await warte(3000); w = BrowserWindow.getAllWindows()[0];
    ok(r2.ok && await js(`db.analysen24.length === 1 && db.invest24.pruefungen.length === 1 && findKontakt('k1').einwaende.length === 1 && db.termine.some(t => t.wo === 'vorort')`), 'Wiederhergestellt: Analysen, Investments, Einwände, Termine');
    // v25: Abgleich-Stand gerätebezogen, Google-Brücke ohne Skript → verständliche Meldung
    const ws = await js(`JSON.stringify(window.pc.abgleichStand('schreiben', JSON.stringify({ geraet: 'pc-test', basis: { 'x|1': { r: 1 } } })))`);
    const ls = JSON.parse(await js(`window.pc.abgleichStand('lesen')`) || 'null');
    ok(JSON.parse(ws).ok && ls && ls.geraet === 'pc-test' && fs.existsSync(HOME + '/Dokumente/MaklerCockpit/abgleich-stand.json'), 'Abgleich-Stand liegt gerätebezogen in abgleich-stand.json');
    const ga = JSON.parse(await js(`window.pc.google('abgleich', { aktion: 'abgleich' }).then(r => JSON.stringify(r))`));
    const gk = JSON.parse(await js(`window.pc.google('kopplung').then(r => JSON.stringify(r))`));
    ok(!ga.ok && ga.code === 'kein_skript' && !gk.ok, 'Ohne Google-Skript: Abgleich und Kopplungscode verweigert, mit Erklärung');
    const sich = fs.readdirSync(CLOUD + '/MaklerCockpit-Sicherung');
    ok(!sich.some(n => /abgleich|google-konto/.test(n)), 'Cloud-Sicherung enthält weder Abgleich-Stand noch Google-Zugang');
    // v25: Telefon im Objekt ändern → Kontakt (im echten Programm)
    await js(`(() => { oeffneObjektModal('o1'); document.getElementById('m_verkaeufer_telefon').value = '0176 5554443'; speichereObjekt('o1'); })()`); await warte(600);
    ok(await js(`findKontakt('k1').telefon === '0176 5554443' && aqTel(findObjekt('o1')) === '0176 5554443'`), 'Nummer im Objekt geändert → Kontakt und Akquise im echten Programm');
    await js(`(() => { const o = findObjekt('o1'); o.angaben = o.angaben || {}; o.angaben.miete_ist = { werte: [{ id: 'm1', wert: 700, herkunft: 'eigentuemer', pruef: 'ungeprueft' }], aktiv: 'm1' }; o.angaben.vermietung = { werte: [{ id: 'v1', wert: 'vermietet', herkunft: 'eigentuemer', pruef: 'ungeprueft' }], aktiv: 'v1' }; save(); })()`);
    // v27: Beispiel-Exposé im echten Programm einlesen (Titel, Vorteile, Objektinformationen, Titelbild), gespeichert und gesichert
    const b64 = fs.readFileSync('/tmp/v27test/ex/beispiel.pdf').toString('base64');
    await js(`(async () => { const bin = atob('${b64}'); const u = new Uint8Array(bin.length); for(let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i); wechsleAnsicht('objekte'); ob26Wechseln('betreut'); await exposesImportieren([new File([u], 'ruhig-wohnen.pdf', { type: 'application/pdf' })]); schliesseModal(); })()`);
    await warte(1500);
    const ex = JSON.parse(await js(`JSON.stringify((() => { const o = db.objekte.find(x => x.referenz === '046a7aa779'); return o ? { t: o.akqTitel, v: o.vorteile.length, f: o.expose.felder.length, b: (o.titelbild || '').length, k: o.kaufpreis, a: o.adresse } : null; })())`));
    ok(ex && ex.t === 'RUHIG WOHNEN MIT TERRASSE INS GRÜNE' && ex.v === 9 && ex.f === 17 && ex.b > 100000 && ex.k === 190000 && ex.a === 'Beuthstraße 29', 'Exposé im echten Programm: Titel, 9 Vorteile, 17 Objektinformationen, Titelbild ' + (ex ? Math.round(ex.b / 1024) + ' KB' : ''));
    await warte(1500);
    const gespeichert = JSON.parse(fs.readFileSync(HOME + '/Dokumente/MaklerCockpit/daten.json', 'utf8'));
    const og = gespeichert.objekte.find(x => x.referenz === '046a7aa779');
    ok(og && /^data:image\/jpeg;base64,/.test(og.titelbild) && og.expose.vorteile.length === 9, 'daten.json enthält Exposé-Daten und Titelbild (' + Math.round(fs.statSync(HOME + '/Dokumente/MaklerCockpit/daten.json').size / 1024) + ' KB)');
    const si2 = await js(`window.pc.sicherung('jetzt', { ziel: ${JSON.stringify(CLOUD)} })`);
    const ges2 = JSON.parse(fs.readFileSync(CLOUD + '/MaklerCockpit-Sicherung/daten-aktuell.json', 'utf8'));
    ok(si2 && si2.ok && ges2.objekte.some(x => x.referenz === '046a7aa779' && x.titelbild), 'Sicherung enthält das Exposé-Objekt mit Titelbild');
    await js(`ob24Oeffnen(db.objekte.find(x => x.referenz === '046a7aa779').id)`); await warte(600);
    const img27 = await w.webContents.capturePage(); fs.writeFileSync(AUS + '/expose_electron.png', img27.toPNG());
    // v28: Notizen-Schutz und Leitfaden im echten Programm
    await js(`(() => { const o = findObjekt('o1'); o.notizen = '<b>ok</b><img src=x onerror="window.__x28=1">'; oeffneObjektModal('o1'); })()`); await warte(600);
    ok(await js("!window.__x28 && document.getElementById('m_notizen').innerHTML.includes('<b>ok</b>') && !document.getElementById('m_notizen').innerHTML.includes('onerror')"), 'Notiz mit eingeschleustem Bild: entschärft, Formatierung bleibt');
    await js('schliesseModal()');
    // Seiten im echten Fenster + Screenshot
    for(const v of ['heute', 'marktanalyse24', 'investments24', 'kooperationen']){ await js(`wechsleAnsicht('${v}')`); await warte(250); }
    await js(`ob24Oeffnen('o1')`); await warte(400);
    const img = await w.webContents.capturePage(); fs.writeFileSync(AUS + '/akte_electron.png', img.toPNG());
  }catch(e){ console.log('FEHLER', e && e.stack || e); f++; }
  ok(fehlerLog.length === 0, 'Keine Konsolenfehler ' + JSON.stringify(fehlerLog.slice(0, 3)));
  console.log('FEHLER', f); app.exit(0);
}, 3500));
