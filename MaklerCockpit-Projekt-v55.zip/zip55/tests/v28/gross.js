// Großer Datenbestand + Rundgang über alle Seiten: Zeiten, Fehler, Überlauf, HTML-Einschleusung
const { chromium } = require('playwright'); const fs = require('fs');
const MODUS = process.argv[2] || 'gross'; // gross | xss | bilder
const BILD = MODUS === 'bilder' ? 'data:image/jpeg;base64,' + require('fs').readFileSync('/tmp/v27test/titelbild.jpg').toString('base64') : '';
const BREITE = +(process.argv[3] || 1500);
function daten(){
  const X = MODUS === 'xss' ? `"><img src=x onerror="window.__xss=(window.__xss||0)+1"><b>X</b>'` : '';
  const heute = new Date(); const tag = d => { const t = new Date(heute); t.setDate(t.getDate() + d); return t.toISOString().slice(0, 10); };
  const bez = ['10365 Berlin', '13156 Berlin', '12683 Berlin', '14612 Falkensee', '15366 Neuenhagen', '10247 Berlin', '12557 Berlin'];
  const st = ['neu', 'email_geschrieben', 'kontaktiert', 'termin', 'auftrag', 'online', 'abgeschlossen', 'kein_interesse'];
  const n = MODUS === 'xss' ? 25 : 400, nk = MODUS === 'xss' ? 25 : 800;
  const kontakte = Array.from({ length: nk }, (_, i) => ({ id: 'k' + i, createdAt: Date.now() - i * 3e6, name: `Kontakt ${i} Müller${X}`, telefon: '0171 ' + String(1000000 + i), email: `k${i}@example.org`, kontaktart: ['eigentuemer', 'interessent', 'kaeufer', 'sonstige'][i % 4], status: 'lead', prioritaet: 'mittel', notizen: 'Notiz ' + X }));
  const objekte = Array.from({ length: n }, (_, i) => ({ id: 'o' + i, createdAt: Date.now() - i * 5e6, akqTitel: `Objekt ${i} schöne Wohnung${X}`, adresse: `Teststraße ${i}${X}`, ort: bez[i % bez.length], objektart: ['Wohnung', 'EFH', 'DHH', 'MFH', 'Grundstück'][i % 5], status: st[i % st.length], kaufpreis: 150000 + i * 1000, wohnflaeche: 40 + i % 120, baujahr: 1900 + i % 120, verkaeuferName: i % 3 ? `Eigentümer ${i}${X}` : '', verkaeuferTelefon: i % 3 ? '0176 ' + String(2000000 + i) : '', eigentuemerId: i % 5 === 0 ? 'k' + i : null, quelle: ['Kleinanzeigen', 'Zeitung', 'Immoscout', 'Empfehlung'][i % 4], link: i % 4 === 0 ? 'https://www.kleinanzeigen.de/s-anzeige/' + i : '', titelbild: BILD && i < 60 ? BILD : undefined, notizen: 'Bemerkung ' + X, verlauf: [{ t: Date.now() - 1e7, typ: 'info', text: 'angelegt ' + X }], prioritaet: 'mittel' }));
  const termine = Array.from({ length: MODUS === 'xss' ? 20 : 1500 }, (_, i) => ({ id: 't' + i, createdAt: 1, titel: `Termin ${i}${X}`, datum: tag((i % 120) - 60), uhrzeit: String(8 + i % 10).padStart(2, '0') + ':00', dauer: 30, art: ['erstgespraech', 'besichtigung', 'rueckruf', 'notar'][i % 4], objektId: 'o' + (i % n), kontaktId: 'k' + (i % nk), wo: 'vorort', ort: 'Ort ' + X, notiz: X }));
  const aufgaben = Array.from({ length: MODUS === 'xss' ? 20 : 300 }, (_, i) => ({ id: 'a' + i, titel: `Aufgabe ${i}${X}`, faellig: tag((i % 30) - 10), prioritaet: 'mittel', objektId: 'o' + (i % n), kontaktId: null, status: i % 4 ? 'offen' : 'erledigt', notiz: X }));
  const gesuche = Array.from({ length: MODUS === 'xss' ? 10 : 200 }, (_, i) => ({ id: 'g' + i, status: 'aktiv', name: `Suchkunde ${i}${X}`, telefon: '0152 ' + (3000000 + i), arten: ['Wohnung'], orte: ['Lichtenberg'], budgetMax: 300000 + i * 1000, notiz: X }));
  const notizen = Array.from({ length: MODUS === 'xss' ? 10 : 200 }, (_, i) => ({ id: 'n' + i, createdAt: Date.now() - i * 1e6, text: `Notiz ${i}${X}`, verarbeitet: i % 2 === 0 }));
  return { objekte, kontakte, termine, aufgaben, notizen, gesuche, marktanalysen: [], mentorFragen: [], meta: { v9neustart: { quittiert: true } } };
}
(async () => {
  const b = await chromium.launch();
  const p = await b.newPage({ viewport: { width: BREITE, height: 900 } });
  const fe = [], ce = []; p.on('pageerror', e => fe.push(e.message.slice(0, 200))); p.on('console', m => { if(m.type() === 'error' && !/ERR_|Failed to load|net::/.test(m.text())) ce.push(m.text().slice(0, 200)); }); p.on('dialog', d => d.dismiss());
  const D = JSON.stringify(daten());
  await p.addInitScript(d => { let gespeichert = 0, zeit = 0; window.__spInfo = () => ({ gespeichert, zeit });
    window.pc = { geraet: 'pc', laden: () => JSON.parse(d), speichern: t => { gespeichert++; window.__letzteGroesse = t.length; return { ok: true }; }, ordner(){}, sicherungSchreiben: () => ({ ok: true }), sicherungLesen: () => null, zwischenablage: async () => '', abruf: async () => ({ ok: false }) }; }, D);
  const t0 = Date.now();
  await p.goto('file:///tmp/pc/app/index.html', { waitUntil: 'load' });
  const tLoad = Date.now() - t0;
  await p.waitForTimeout(2500);
  console.log('Daten', Math.round(D.length / 1024) + ' KB', '· Laden bis load:', tLoad, 'ms');
  // Speichern messen (Wrapper-Kette)
  const sp = await p.evaluate(() => { const t = performance.now(); _schreibe(); const d1 = performance.now() - t; const t2 = performance.now(); for(let i = 0; i < 5; i++) _schreibe(); return { einmal: Math.round(d1), mittel5: Math.round((performance.now() - t2) / 5), groesse: Math.round((window.__letzteGroesse || 0) / 1024) }; });
  console.log('Speichern (_schreibe):', JSON.stringify(sp));
  // alle Seiten
  const ziele = await p.evaluate(() => Array.from(new Set(Array.from(document.querySelectorAll('[onclick^="wechsleAnsicht("]')).map(e => (e.getAttribute('onclick').match(/wechsleAnsicht\('([^']+)'\)/) || [])[1]).filter(Boolean))));
  for(const z of ['heute', 'dashboard', 'akquise', 'objekte', 'kontakte', 'termine', 'aufgaben', 'notizen', 'kaeufer', 'marktanalyse24', 'investments24', 'kooperationen', 'hausverwaltungen', 'immowert', 'marketing', 'jarvis']) if(!ziele.includes(z)) ziele.push(z);
  const zeilen = [];
  for(const z of ziele){
    const vor = fe.length + ce.length;
    const r = await p.evaluate(z => { const t = performance.now(); try{ wechsleAnsicht(z); }catch(e){ return { fehler: e.message }; } const d = performance.now() - t; const sw = document.documentElement.scrollWidth, cw = document.documentElement.clientWidth; const m = document.getElementById('main'); return { ms: Math.round(d), ueberlauf: sw - cw, mainUeber: m ? m.scrollWidth - m.clientWidth : 0, text: (m ? m.innerText : '').length }; }, z);
    await p.waitForTimeout(250);
    if(MODUS === 'xss'){ const x = await p.evaluate(() => window.__xss || 0); if(x) { zeilen.push('>>> XSS nach ' + z + ': ' + x); await p.evaluate(() => { window.__xss = 0; }); } }
    zeilen.push(`${z.padEnd(18)} ${String(r.ms).padStart(5)} ms  Überlauf ${r.ueberlauf}/${r.mainUeber}  ${r.fehler ? 'FEHLER ' + r.fehler : ''}${fe.length + ce.length > vor ? ' neue Fehler: ' + [...fe, ...ce].slice(vor).join(' | ') : ''}`);
  }
  console.log(zeilen.join('\n'));
  // Dialoge
  const dl = {};
  for(const [k, f] of [['objektModal', "oeffneObjektModal('o1')"], ['neuesObjekt', 'oeffneObjektModal()'], ['kontaktModal', "oeffneKontaktModal('k1')"], ['terminModal', "oeffneTerminModal('t1')"], ['akte', "ob24Oeffnen('o5')"], ['akteMitEigentuemer', "ob24Oeffnen('o0')"], ['kontaktAkte', "typeof oeffneKontakt === 'function' ? oeffneKontakt('k1') : 0"], ['gesuch', "typeof skBearbeiten === 'function' ? skBearbeiten('g1') : 0"], ['lead', "(wechsleAnsicht('akquise'), AQ2.sel = 'o2', renderMain())"]]){
    dl[k] = await p.evaluate(f => { const t = performance.now(); try{ eval(f); }catch(e){ return 'FEHLER ' + e.message; } return Math.round(performance.now() - t); }, f);
    await p.waitForTimeout(300);
    if(MODUS === 'xss'){ const x = await p.evaluate(() => { const v = window.__xss || 0; window.__xss = 0; return v; }); if(x) dl[k] += ' XSS!'; }
    await p.evaluate(() => { try{ schliesseModal(); }catch(e){} });
  }
  console.log('Dialoge:', JSON.stringify(dl));
  await p.waitForTimeout(500);
  if(MODUS === 'xss') console.log('HTML-Einschleusung ausgeführt:', await p.evaluate(() => window.__xss || 0));
  console.log('Seitenfehler:', fe.length, JSON.stringify(fe.slice(0, 8)));
  console.log('Konsolenfehler:', ce.length, JSON.stringify(ce.slice(0, 8)));
  console.log('Speichervorgänge:', JSON.stringify(await p.evaluate(() => window.__spInfo())));
  await b.close();
})();
