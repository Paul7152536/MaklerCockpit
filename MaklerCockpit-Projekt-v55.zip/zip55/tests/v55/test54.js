// v54: echter Titel aus dem Inserat, Schnell durchsehen statt Browser-Tabs, KI-Prompt mit Titel-Zeile
const { chromium } = require('playwright');
let f = 0; const ok = (b, t) => { console.log((b ? 'ok   ' : 'FEHL ') + t); if(!b) f++; };
const T = 864e5, jetzt = Date.now();
const KA = n => `https://www.kleinanzeigen.de/s-anzeige/wohnung-${n}/32000000${n}0-196-3401`;
const seite = (titel, preis, text, extra) => `<!doctype html><html><head><meta property="og:title" content="${titel} | Kleinanzeigen"><meta property="og:image" content="https://img.kleinanzeigen.de/api/v1/prod-ads/images/ab/x.JPG"></head><body>
<h1 id="viewad-title">${extra || ''}${titel}</h1><h2 id="viewad-price">${preis}</h2><span id="viewad-locality">12555 Berlin - Köpenick</span>
<div id="viewad-extra-info"><span>20.11.2026</span></div><div id="viewad-description-text">${text}</div><div id="viewad-contact">Privater Nutzer · Aktiv seit 2015</div></body></html>`;
const SEITEN = {
  [KA(1)]: seite('Helle 3-Zimmer-Wohnung mit Balkon in Köpenick', '329.000 € VB', 'Schöne Wohnung.<br>Ruhige Lage.'),
  [KA(2)]: seite('Dachgeschoss zum Ausbau Berlin', '139.000 €', 'Bitte keine Makleranfragen!'),
  [KA(3)]: seite('Reihenhaus Mahlsdorf', '450.000 €', 'Toll.', 'Reserviert • '),
  [KA(4)]: '<!doctype html><html><body><h2>Die Anzeige ist nicht mehr verfügbar.</h2></body></html>'
};
const lead = (id, x) => Object.assign({ id, objektart: 'Wohnung', ort: '12555 Berlin', status: 'neu', quelle: 'Kleinanzeigen', privat: 'ja', createdAt: jetzt - T, verlauf: [] }, x);
const D = JSON.stringify({ objekte: [
  lead('a', { akqTitel: '3-Zimmer-Eigentumswohnung', link: KA(1), kaufpreis: 330000 }),
  lead('b', { akqTitel: 'Dachgeschoss zum Ausbau Berlin', link: KA(2), kaufpreis: 139000 }),
  lead('c', { akqTitel: 'Einfamilienhaus Hellersdorf', link: KA(3) }),
  lead('d', { akqTitel: 'Wohnung Treptow', link: KA(4) })], kontakte: [], termine: [], aufgaben: [], notizen: [], meta: { v9neustart: { quittiert: true } } });
(async () => { const b = await chromium.launch();
  for(const [g, w, h] of [['pc', 1440, 900], ['handy', 412, 915]]){
    const p = await b.newPage({ viewport: { width: w, height: h }, isMobile: g === 'handy' });
    const fe = []; p.on('pageerror', e => fe.push(e.message));
    await p.route('https://img.kleinanzeigen.de/**', r => r.fulfill({ status: 200, contentType: 'image/png', body: Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==', 'base64') }));
    await p.addInitScript(([d, g, S]) => { window.__abrufe = []; window.__tabs = [];
      const holen = async (url) => { window.__abrufe.push(url); return S[url] ? { ok: true, status: 200, url, text: S[url] } : { ok: false, status: 404 }; };
      window.pc = { geraet: g, laden: () => JSON.parse(d), speichern: () => ({ ok: true }), ordner(){}, sicherungSchreiben: () => ({ ok: true }), sicherungLesen: () => null,
        seite: holen, webfenster: async (a, arg) => a === 'vorwaermen' ? { ok: true } : a === 'lesen' ? holen(arg.url) : (window.__tabs.push('fenster:' + arg.url), { ok: true }) };
      const o = window.open; window.open = (u) => { window.__tabs.push(String(u)); return null; }; }, [D, g, SEITEN]);
    await p.goto('file:///tmp/pc/app/index.html'); await p.waitForTimeout(2500);
    await p.evaluate(() => { try{ schliesseModal(); }catch(e){} const k = document.getElementById('an31Karte'); if(k) k.remove(); wechsleAnsicht('akquise'); AQ2.status = 'offen'; renderMain(); }); await p.waitForTimeout(400);
    // Prompt
    const pr = await p.evaluate(() => AKQ_PROMPTS.find(x => x.key === 'kleinanzeigen').prompt(akqDb().einst));
    ok(/\nTitel: \[Überschrift der Anzeige Wort für Wort/.test(pr) && /TITEL-REGEL/.test(pr) && /Kopierblock|Codeblock|```/i.test(pr) || /\nTitel: \[/.test(pr), g + ': KI-Prompt verlangt den Titel Wort für Wort aus dem Inserat');
    // Import mit Titel-Zeile
    const imp = await p.evaluate(() => { akqUebernehmen(akqParsen ? [] : [], 'x'); return true; }).catch(() => true);
    const par = await p.evaluate(() => { const t = '1.\nTitel: Sonnige 2-Zimmer-Wohnung am Müggelsee – provisionsfrei\nName: Nicht angegeben\nObjekt: 2-Zimmer-Eigentumswohnung\nLage: 12559 Berlin-Köpenick\nPreis: 289.000 €\nLink: https://www.kleinanzeigen.de/s-anzeige/sonnig/3299900001-196-3401\n'; const r = akqImport ? null : null; const l = (typeof akqAusText === 'function' ? akqAusText(t) : akqParsen(t)); return l; }).catch(e => 'ERR ' + e.message);
    // Leads durchsehen
    await p.evaluate(() => ak54Starten(0)); await p.waitForTimeout(800);
    const k1 = await p.evaluate(() => ({ t: document.querySelector('.ak54-titel').textContent, alt: (document.querySelector('.ak54-alt') || {}).textContent, info: document.querySelector('.ak54-info').textContent, text: document.querySelector('.ak54-text') && document.querySelector('.ak54-text').textContent, bild: !!document.querySelector('.ak54-bild'), o: findObjekt('a') }));
    ok(k1.t === 'Helle 3-Zimmer-Wohnung mit Balkon in Köpenick' && /3-Zimmer-Eigentumswohnung/.test(k1.alt || ''), g + ': Karte zeigt echten Titel, KI-Titel durchgestrichen');
    ok(k1.o.akqTitel === 'Helle 3-Zimmer-Wohnung mit Balkon in Köpenick' && k1.o.akqTitelKI === '3-Zimmer-Eigentumswohnung' && k1.o.kaufpreis === 329000 && k1.o.verlauf.some(v => /Titel aus dem Inserat/.test(v.text)), g + ': Lead korrigiert (Titel, Preis 329.000), Verlauf-Eintrag');
    ok(/329\.000/.test(k1.info) && /Köpenick/.test(k1.info) && /privat/.test(k1.info) && /Schöne Wohnung\.\nRuhige Lage\./.test(k1.text || '') && k1.bild, g + ': Preis, Ort, privat, Beschreibung mit Absätzen, Bild');
    ok(await p.evaluate(() => window.__tabs.length === 0), g + ': kein Browser-Tab geöffnet');
    await p.keyboard.press('ArrowRight'); await p.waitForTimeout(800);
    const k2 = await p.evaluate(() => ({ w: document.querySelector('.ak54-warn') && document.querySelector('.ak54-warn').textContent, o: findObjekt('b') }));
    ok(/keine Makler/.test(k2.w || '') && k2.o.keinMakler && !k2.o.akqTitelKI, g + ': „keine Makler“ erkannt, gleicher Titel bleibt');
    await p.evaluate(() => ak54Schritt(1)); await p.waitForTimeout(800);
    const k3 = await p.evaluate(() => ({ t: document.querySelector('.ak54-titel').textContent, w: (document.querySelector('.ak54-warn') || {}).textContent || '' }));
    ok(k3.t === 'Reihenhaus Mahlsdorf' && /Reserviert/.test(k3.w), g + ': „Reserviert •“ erkannt, Titel ohne Zusatz');
    await p.evaluate(() => ak54Schritt(1)); await p.waitForTimeout(800);
    const k4 = await p.evaluate(() => ({ w: (document.querySelector('.ak54-warn') || {}).textContent || '', off: !!findObjekt('d').inseratOffline }));
    ok(/nicht mehr online/.test(k4.w) && k4.off, g + ': gelöschtes Inserat → „nicht mehr online“');
    await p.keyboard.press('Delete'); await p.waitForTimeout(300);
    ok(await p.evaluate(() => !findObjekt('d')), g + ': Entf verwirft den Lead');
    await p.evaluate(() => { AK54.pos = 0; ak54Karte(); }); await p.waitForTimeout(300);
    await p.evaluate(() => ak54Inserat()); await p.waitForTimeout(200);
    const tabs = await p.evaluate(() => window.__tabs.slice());
    ok(g === 'pc' ? /^fenster:https:\/\/www\.kleinanzeigen\.de/.test(tabs[0] || '') : /^https:\/\/www\.kleinanzeigen\.de/.test(tabs[0] || ''), g + ': „Inserat ansehen“ → ' + (g === 'pc' ? 'ein Kleinanzeigen-Fenster' : 'Browser') + ' (' + tabs[0] + ')');
    await p.evaluate(() => schliesseModal());
    // Balken
    const balken = await p.evaluate(() => { aq2Liste(); return document.getElementById('ex29Balken').innerText; });
    ok(/Schnell durchsehen/.test(balken) && /(Im Browser öffnen|Nacheinander öffnen)/.test(balken), g + ': Balken: „⚡ Schnell durchsehen“ + Browser als Zusatz');
    const chips = await p.evaluate(() => Array.from(document.querySelectorAll('#aqListe .ak54-chip')).map(x => x.textContent));
    ok(chips.some(c => /Titel geprüft/.test(c)), g + ': Liste zeigt „✏️ Titel geprüft“ (' + chips.join(', ') + ')');
    // Anschreiben vor Prüfung → erst prüfen, dann mit richtigem Titel
    await p.evaluate(() => { const o = findObjekt('c'); delete o.inseratCheck; o.akqTitel = 'Falscher KI-Titel'; delete o.akqTitelKI; AQ2.sel = 'c'; renderMain(); });
    await p.evaluate(() => { window.__senden = null; const _a = aqAnschreiben; aqAnschreiben = function(o, art){ const r = _a.apply(this, arguments); window.__senden = aqTitel(o) + ' | ' + r.text; return r; }; aq2Senden(); }); await p.waitForTimeout(1200);
    const txt = await p.evaluate(() => window.__senden || '');
    ok(/^Reihenhaus Mahlsdorf \|/.test(txt), g + ': Anschreiben erst nach dem Abgleich (Titel beim Schreiben: ' + txt.split(' |')[0] + ')');
    if(g === 'pc'){ await p.evaluate(() => { ak54Starten(0); }); await p.waitForTimeout(600); await p.screenshot({ path: '/tmp/v54/karte_pc.png' }); }
    else { await p.evaluate(() => { ak54Starten(0); }); await p.waitForTimeout(600); await p.screenshot({ path: '/tmp/v54/karte_handy.png' }); }
    ok(!fe.length, g + ': keine JS-Fehler ' + fe.slice(0, 3).join(' | '));
    await p.close();
  } await b.close(); console.log(f ? 'FEHLER ' + f : 'ALLES OK'); process.exit(f ? 1 : 0); })();
