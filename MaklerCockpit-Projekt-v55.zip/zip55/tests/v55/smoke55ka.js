// v55 Smoke: Inserat öffnet sofort, Werbung blockiert, Fenster bleibt warm, Programm beendet sauber
const { app, BrowserWindow, session } = require('electron'); const http = require('http'); const fs = require('fs');
const HOME = '/tmp/claude-0/-home-claude/fcfe88c9-293d-574d-8cfa-b1821c923895/scratchpad/etest/home55';
fs.rmSync(HOME, { recursive: true, force: true }); app.setPath('documents', HOME + '/Dokumente'); process.env.MC_WEB_TEST = '1';
const srv = http.createServer((req, res) => { setTimeout(() => { res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' }); res.end('<!doctype html><html><head><script src="https://securepubads.g.doubleclick.net/tag/js/gpt.js"></script><script src="https://www.googletagmanager.com/gtm.js"></script></head><body><h1 id="viewad-title">Inserat</h1><img src="http://127.0.0.1:' + srv.address().port + '/bild.png"></body></html>'); }, 1500); });
srv.listen(0, '127.0.0.1');
require(process.env.MC_MAIN || '/tmp/pc/app/main.js');
const warte = ms => new Promise(r => setTimeout(r, ms));
let fehler = 0; const ok = (b, t) => { console.log((b ? 'ok   ' : 'FEHL ') + t); if(!b) fehler++; };
app.whenReady().then(() => setTimeout(async () => {
  try{
    const w = (BrowserWindow.getAllWindows().find(x => /index\.html/.test(x.webContents.getURL())) || BrowserWindow.getAllWindows()[0]), port = srv.address().port;
    const fehlerNetz = []; session.fromPartition('persist:kleinanzeigen').webRequest.onErrorOccurred(d => fehlerNetz.push([new URL(d.url).hostname, d.error]));
    const t0 = Date.now();
    const r = await w.webContents.executeJavaScript(`window.pc.webfenster('oeffnen', { url: 'http://127.0.0.1:${port}/s-anzeige/x/1' })`);
    const dauer = Date.now() - t0;
    const kw = BrowserWindow.getAllWindows().find(x => x !== w);
    ok(r && r.ok && dauer < 1200 && kw && kw.isVisible(), `Fenster sofort sichtbar (${dauer} ms, Seite braucht 1500 ms)`);
    await warte(3000);
    const dc = fehlerNetz.find(x => /doubleclick/.test(x[0])), gtm = fehlerNetz.find(x => /googletagmanager/.test(x[0]));
    ok(dc && /BLOCKED_BY_CLIENT/.test(dc[1]) && gtm && /BLOCKED_BY_CLIENT/.test(gtm[1]), 'Werbung/Tracker blockiert: ' + JSON.stringify([dc, gtm]));
    ok(await kw.webContents.executeJavaScript(`document.getElementById('viewad-title').textContent`) === 'Inserat', 'Inserat selbst geladen');
    kw.close(); await warte(500);
    ok(!kw.isDestroyed() && !kw.isVisible(), 'Schließen blendet nur aus (bleibt bereit)');
    const t1 = Date.now();
    await w.webContents.executeJavaScript(`window.pc.webfenster('oeffnen', { url: 'http://127.0.0.1:${port}/s-anzeige/x/2' })`);
    ok(kw.isVisible() && Date.now() - t1 < 800 && BrowserWindow.getAllWindows().length === 2, 'Nächstes Inserat im selben Fenster, sofort sichtbar');
    app.on('will-quit', () => { ok(kw.isDestroyed(), 'Programm schließen beendet auch das Kleinanzeigen-Fenster'); console.log(fehler ? 'FEHLER ' + fehler : 'FEHLER 0'); });
    w.close();
    setTimeout(() => { ok(false, 'Programm hat sich nicht beendet'); console.log('FEHLER ' + fehler); app.exit(1); }, 6000);
  }catch(e){ ok(false, 'Ausnahme: ' + e.message); console.log('FEHLER ' + fehler); app.exit(1); }
}, 3500));
