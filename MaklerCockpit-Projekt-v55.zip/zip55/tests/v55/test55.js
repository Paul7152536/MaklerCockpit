// v55: Kleinanzeigen-Inserate am PC im eigenen Fenster (statt Browser), andere Portale im Browser, Handy unverändert
const { chromium } = require('playwright');
let f = 0; const ok = (b, t) => { console.log((b ? 'ok   ' : 'FEHL ') + t); if(!b) f++; };
const D = JSON.stringify({ objekte: [
  { id: 'k', akqTitel: 'KA-Wohnung', objektart: 'Wohnung', ort: '12555 Berlin', status: 'neu', quelle: 'Kleinanzeigen', link: 'https://www.kleinanzeigen.de/s-anzeige/x/3200000001-196-3401', verlauf: [], inseratCheck: { am: 1, status: 'online' } },
  { id: 'i', akqTitel: 'IS-Wohnung', objektart: 'Wohnung', ort: '12555 Berlin', status: 'neu', quelle: 'ImmoScout', link: 'https://www.immobilienscout24.de/expose/150000001', verlauf: [] }],
  kontakte: [], termine: [], aufgaben: [], notizen: [], meta: { v9neustart: { quittiert: true } } });
(async () => { const b = await chromium.launch();
  for(const g of ['pc', 'handy']){
    const p = await b.newPage({ viewport: g === 'pc' ? { width: 1440, height: 900 } : { width: 412, height: 915 }, isMobile: g === 'handy' });
    const fe = []; p.on('pageerror', e => fe.push(e.message));
    await p.addInitScript(([d, g]) => { window.__wf = []; window.__tabs = [];
      window.pc = { geraet: g, laden: () => JSON.parse(d), speichern: () => ({ ok: true }), ordner(){}, sicherungSchreiben: () => ({ ok: true }), sicherungLesen: () => null, seite: async () => ({ ok: false }),
        webfenster: async (a, arg) => { window.__wf.push([a, arg && arg.url]); return { ok: true }; } };
      window.open = u => { window.__tabs.push(String(u)); return null; }; }, [D, g]);
    await p.goto('file:///tmp/pc/app/index.html'); await p.waitForTimeout(2500);
    await p.evaluate(() => { try{ schliesseModal(); }catch(e){} wechsleAnsicht('akquise'); }); await p.waitForTimeout(3800);
    const warm = await p.evaluate(() => window.__wf.filter(x => x[0] === 'vorwaermen').length);
    ok(g === 'pc' ? warm === 1 : warm === 0, g + ': Kleinanzeigen-Fenster ' + (g === 'pc' ? 'wird beim Öffnen der Akquise einmal vorbereitet' : 'wird am Handy nicht vorbereitet'));
    await p.evaluate(() => { window.__wf = []; aqLinkOeffnen('k'); aqLinkOeffnen('i'); ak45Inserat('k'); }); await p.waitForTimeout(300);
    const r = await p.evaluate(() => ({ wf: window.__wf.map(x => x[0] + ' ' + x[1]), tabs: window.__tabs.slice() }));
    if(g === 'pc') ok(r.wf.filter(x => /^oeffnen https:\/\/www\.kleinanzeigen/.test(x)).length === 2 && r.tabs.length === 1 && /immobilienscout24/.test(r.tabs[0]), 'pc: Kleinanzeigen → eigenes Fenster (2×), ImmoScout → Browser (' + JSON.stringify(r) + ')');
    else ok(r.wf.filter(x => /^oeffnen/.test(x)).length === 0 && r.tabs.length === 3, 'handy: alles wie bisher über Browser/App');
    ok(!fe.length, g + ': keine JS-Fehler ' + fe.slice(0, 3).join(' | '));
    await p.close();
  } await b.close(); console.log(f ? 'FEHLER ' + f : 'ALLES OK'); process.exit(f ? 1 : 0); })();
