// ═══ MaklerCockpit v46 – Große Analyse: Übernahme aus der Shooting-Analyse oben gesondert anzeigen ═══
// Pauls Wunsch (18.11.2026): Was aus der Shooting-Analyse (Reiter „Schnellbewertung“) übernommen wurde, soll oben
// gut sichtbar für sich stehen: Ergebnisse, übernommene Eckdaten (als Annahme) und Vergleichsfälle.
// Übernommene Felder tragen zusätzlich ein Abzeichen „⚡ Shooting“ – auch wenn „Quellen zeigen“ aus ist.

function ga46IstShootingFeld(x){ return !!x && (x.von === 'shooting' || (x.s === 'assumed' && !x.q && !x.p && !x.n)); }
function ga46IstShootingFall(c){ return !!c && (c.von === 'shooting' || /Schnellbewertung/.test(String(c.quelle || ''))); }
(function(){
  const _u = ga40Uebernehmen;
  ga40Uebernehmen = function(){
    const e = ga35Entwurf(GA35.obj), vorFaelle = e.vergleich.length, vorWerte = Object.assign({}, e.werte), vorSchnell = e.schnell;
    _u.apply(this, arguments);
    try{
      const am = Date.now(), felder = [];
      e.vergleich.slice(vorFaelle).forEach(c => { c.von = 'shooting'; c.vonAm = am; });
      Object.keys(e.werte).forEach(k => { const x = e.werte[k]; if(x && x !== vorWerte[k] && x.s === 'assumed'){ x.von = 'shooting'; x.vonAm = am; felder.push(k); } });
      const u = e.shooting46 || { };
      e.shooting46 = { am, faelle: (u.faelle || 0) + (e.vergleich.length - vorFaelle), felder: Array.from(new Set((u.felder || []).concat(felder))), ergebnis: e.schnell !== vorSchnell || !!u.ergebnis, auf: true };
      save(); ga35Neuzeichnen();
    }catch(err){ console.error('shooting46', err); }
  };
})();
function ga46Daten(e){
  const s = e.schnell || null, faelle = (e.vergleich || []).filter(ga46IstShootingFall);
  const felder = Object.keys(e.werte || {}).filter(k => ga46IstShootingFeld(e.werte[k]) && !ga43Leer(e.werte[k]));
  return { s, faelle, felder, leer: !s && !faelle.length && !felder.length };
}
function ga46FeldName(k){ const f = (GA43_F[k] && GA43_F[k].f) || GA35_FELDER.find(x => x.k === k); return f ? f.l : k; }
function ga46KarteHtml(e){
  const d = ga46Daten(e); if(d.leer) return '';
  const E = ga35E, info = e.shooting46 || {}, auf = info.auf !== false;
  const kach = [];
  if(d.s && d.s.vergleich) kach.push(`<div class="ga46-k"><small>Vergleichswert</small><b>${ga35Euro(d.s.vergleich.wert)}</b><span>Ø ${ga35Euro(d.s.vergleich.mittelpreis)}/m² · ${d.s.vergleich.anzahl || 0} Werte</span></div>`);
  if(d.s && d.s.ertrag) kach.push(`<div class="ga46-k"><small>Ertragswert</small><b>${ga35Euro(d.s.ertrag.ertragswert)}</b><span>Rohertrag ${ga35Euro(d.s.ertrag.rohertrag)}/Jahr</span></div>`);
  const felder = d.felder.map(k => { const x = e.werte[k], f = (GA43_F[k] && GA43_F[k].f) || null; return `<span class="ga46-chip">${E(ga46FeldName(k))}: <b>${E(ga43Text(f, x))}${f && f.e && /^\d/.test(String(x.v)) ? ' ' + E(f.e) : (k === 'wfl' || k === 'grund' ? ' m²' : k === 'brw' ? ' €/m²' : '')}</b></span>`; }).join('');
  const faelle = d.faelle.map(c => `<tr><td>${E(ga43Hausnr(c.lage || '–'))}</td><td>${E(c.preis ? (c.preisbasis && /m²/.test(c.preisbasis) ? ga35Euro(mc24N(c.preis)) + '/m²' : ga35Euro(mc24N(c.preis))) : '–')}</td><td>${E(c.flaeche ? c.flaeche + ' m²' : '–')}</td><td class="mc24-muted">${E(String(c.quelle || '').replace(/^(\w+:\/\/)?(www\.)?/, '').slice(0, 40))}</td></tr>`).join('');
  return `<div class="ga35-karte ga46">
    <div class="ga46-kopf" onclick="ga46Auf()"><h3>⚡ Aus der Shooting-Analyse übernommen</h3><span class="mc24-muted">${info.am ? 'am ' + E(mc24Datum(info.am)) : d.s && d.s.stand ? 'Stand ' + E(mc24Datum(d.s.stand)) : ''}</span><span class="ga46-pfeil">${auf ? '▾' : '▸'}</span></div>
    ${auf ? `${kach.length ? `<div class="ga46-kacheln">${kach.join('')}</div>` : ''}
    ${felder ? `<div class="ga46-ab"><b>Eckdaten</b> <span class="mc24-muted">(als Annahme übernommen – mit Unterlagen bestätigen)</span><div class="ga46-chips">${felder}</div></div>` : ''}
    ${faelle ? `<div class="ga46-ab"><b>${d.faelle.length} ${d.faelle.length === 1 ? 'Vergleichsfall' : 'Vergleichsfälle'}</b> <span class="mc24-muted">(Angebots- und Portalwerte)</span><div class="ga46-tab"><table><thead><tr><th>Lage</th><th>Preis</th><th>Fläche</th><th>Quelle</th></tr></thead><tbody>${faelle}</tbody></table></div></div>` : ''}
    <div class="ga46-fuss"><span class="mc24-muted">Nur zur Plausibilität – Portalwerte sind Angebotsniveaus.</span><button class="tiny secondary" onclick="event.stopPropagation();GA35.tab='schnell';ga35Neuzeichnen()">⚡ Zur Schnellbewertung</button></div>` : ''}
  </div>`;
}
function ga46Auf(){ const e = ga35Entwurf(GA35.obj); e.shooting46 = Object.assign({}, e.shooting46 || {}, { auf: !(e.shooting46 && e.shooting46.auf === false) ? false : true }); save(); ga35Neuzeichnen(); }
(function(){
  const _r = ga35Render;
  ga35Render = function(main){
    _r.apply(this, arguments);
    if(GA35.tab === 'schnell') return;
    try{
      const e = ga35Entwurf(GA35.obj), html = ga46KarteHtml(e); if(!html) return;
      const ziel = main.querySelector('.ga35-gitter') || main.querySelector('.ga44-bogen');
      if(ziel) ziel.insertAdjacentHTML('beforebegin', html);
    }catch(err){ console.error('shooting46 render', err); }
  };
  const _fh = ga43FeldHtml;
  ga43FeldHtml = function(e, f, x){
    const h = _fh.apply(this, arguments);
    if(!ga46IstShootingFeld(x) || ga43Leer(x)) return h;
    return h.replace('</label>', ' <span class="ga46-badge" title="Aus der Shooting-Analyse übernommen – Annahme">⚡ Shooting</span></label>');
  };
  const st = document.createElement('style');
  st.textContent = `.ga46{border:1px solid var(--orange);background:linear-gradient(180deg,rgba(255,138,61,.10),rgba(255,138,61,.03))}
.ga46-kopf{display:flex;gap:10px;align-items:center;cursor:pointer;flex-wrap:wrap}.ga46-kopf h3{margin:0}.ga46-pfeil{margin-left:auto;color:var(--orange);font-size:18px}
.ga46-kacheln{display:flex;flex-wrap:wrap;gap:10px;margin:10px 0}.ga46-k{flex:1;min-width:160px;border:1px solid var(--border);border-radius:10px;padding:8px 12px;background:var(--card)}
.ga46-k small{display:block;color:var(--muted);font-size:11px;text-transform:uppercase;letter-spacing:.04em}.ga46-k b{display:block;font-size:20px;color:var(--orange)}.ga46-k span{font-size:12px;color:var(--muted)}
.ga46-ab{margin:10px 0}.ga46-chips{display:flex;flex-wrap:wrap;gap:6px;margin-top:6px}.ga46-chip{border:1px dashed var(--orange);border-radius:999px;padding:3px 10px;font-size:12.5px}
.ga46-tab{overflow:auto;margin-top:6px}.ga46-tab table{width:100%;border-collapse:collapse;font-size:12.5px}.ga46-tab th,.ga46-tab td{text-align:left;padding:4px 6px;border-bottom:1px solid var(--border)}
.ga46-fuss{display:flex;gap:10px;align-items:center;justify-content:space-between;flex-wrap:wrap;font-size:12px}
.ga46-badge{display:inline-block;margin-left:4px;padding:0 6px;border-radius:999px;background:rgba(255,138,61,.18);color:var(--orange);font-size:10.5px;font-weight:700;text-transform:none;letter-spacing:0;white-space:nowrap}`;
  document.head.appendChild(st);
})();
