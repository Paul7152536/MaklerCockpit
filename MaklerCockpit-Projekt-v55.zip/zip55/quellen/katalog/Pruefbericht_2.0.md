# Prüfbericht Auswahlkatalog Version 2.0
Stand 17.11.2026

## Ergebnis
Die erste Fassung war für einen vollständigen Kundentermin zu grob. Korrigiert wurden die neutrale Fenstererfassung, fehlende konkrete Bauteilmerkmale und mehrere Logikfehler. Die geprüfte Fassung umfasst **205 aktive Felder, 824 aktive Fachoptionen und 26 Gruppen**. Die früheren Glas-/Rahmenfelder bleiben als zwei Legacy-Felder erhalten. Alle ursprünglichen 100 Feld-IDs sind damit weiterhin vorhanden.

**74 konkrete Merkmalszuordnungen** aus dem Gutachten wurden gegen tatsächlich vorhandene Feld- und Options-IDs geprüft. Zusätzlich wurden **690 Konfigurationsprüfungen** ausgeführt. Das prüft den Katalog und seine Zuordnungen; die spätere App-Implementierung braucht eigene Bedien- und Exportprüfungen.

## Wesentliche Befunde und Korrekturen
| Befund Version 1 | Korrektur Version 2 |
|---|---|
| Zweifach-Isolierglas und Wärmeschutzglas vorhanden, neutrale Kundenangabe „zweifach“ fehlte | Scheibenzahl unabhängig von Glasqualität auswählbar |
| Kastenfenster mit Scheibenzahl vermischt | Konstruktionsart separat |
| Unterschiedliche Fenster nicht sauber je Bereich erfassbar | Wiederholbare Fenstergruppen |
| Rollladenbauart und Antrieb fehlten | Vorsatz-/Aufsatz-/Einbaurollladen, elektrischer/manueller Antrieb und Abdeckung |
| Dachform vorhanden, Dachmaterial und Dämmlage fehlten | Tonziegel/Betondachsteine usw.; Auf-/Zwischen-/Untersparrendämmung |
| Decken, Fundament, Innenwände, Treppen und Türdetails fehlten | Eigene Bauteilgruppen |
| Parkett nur allgemein | Fertig-/Mehrschichtparkett, Massivparkett und Dielen separat |
| Kellerfeuchte vorhanden, Abdichtungsvorbehalt fehlte | Sichtbarer Befund getrennt von vermuteter Ursache |
| Heizungsaustausch mit Betriebszustand vermischt | Separate Planungsauswahl |
| Baujahr-Zeitraum und Prozentgrenzen nicht vollständig konsistent | Abhängigkeit und Grenzwerte korrigiert |
| Nebenanlagenfläche ohne Bezugsart | BGF/Nutzfläche/Grundfläche separat |
| Einfriedung konnte fälschlich zu Zaun werden | Neutrale Option „Einfriedung, Art unbekannt“ |
| Rechtslöschung konnte in einem Sammeltext untergehen | Je Recht dokumentierter Löschungsstand |

## Gutachtenabgleich
Quelle: Gutachten Wuhletal 15-1(1).pdf. Die folgenden Angaben werden als historische Dokumentaussagen erfasst. Seite 19 wurde zusätzlich bildlich überprüft.

| Seite | Merkmal im Gutachten | Vorheriger Stand | Abbildung im aktuellen Katalog |
|---|---|---|

| 17 | Massivbauweise | vorhanden | Tragende Bauweise: Massivbau |
| 19 | Mauerwerk und Beton | fehlte als Materialdetail | Außenwandmaterial: Mauerwerk, Steinart unbekannt, Beton |
| 17 | Teilkeller rund 21 Prozent | vorhanden | Unterkellerung: Teilunterkellert; Unterkellerter Anteil: 21 |
| 19 | Kellerabdichtung augenscheinlich fehlend oder verbraucht | fehlte | Kellerabdichtung: Kenntnisstand: Augenscheinlich fehlend oder verbraucht |
| 19 | Ein Vollgeschoss | vorhanden | Vollgeschosse: 1 |
| 17 | Ausgebautes Dachgeschoss | vorhanden | Dachausbau: Vollständig ausgebaut |
| 17 | Nicht ausgebauter Spitzboden | fehlte separat | Spitzboden: Nicht ausgebaut |
| 17 | Bodeneinschubtreppe zum Spitzboden | fehlte | Zugang Spitzboden: Bodeneinschub-/Bodentreppe |
| 19 | Satteldach | vorhanden | Dachform: Satteldach |
| 19 | Dachneigung rund 40 bis 42 Grad | fehlte | Dachneigung von / Einzelwert: 40; Dachneigung bis (optional): 42 |
| 19 | Tonziegel | fehlte | Dacheindeckung: Tonziegel |
| 19 | Zinkblech-Rinnen und Fallrohre | fehlte | Rinnen / Fallrohre: Material: Zinkblech / Titanzink |
| 19 | Zwischensparrendämmung | fehlte als konkrete Auswahl | Lage der Dachdämmung: Zwischensparrendämmung |
| 19 | Wärmedämmverbundsystem | vorhanden | Wanddämmung: Wärmedämmverbundsystem |
| 19 | Putz und Anstrich der Fassade | Putz vorhanden, Anstrich ergänzt | Fassade / Außenwandbekleidung: Putz, Anstrich / Beschichtung |
| 19 | Haustür aus Kunststoff mit Glasausschnitt | fehlte | Bauteil: Haustür; Material: Kunststoff; Ausführung / Merkmale: Mit Glasausschnitt |
| 19 | Massive Innenwände | fehlte | Innenwandkonstruktion: Massive Innenwände |
| 19 | Streifenfundamente aus Stahlbeton | fehlte | Gründungsart: Streifenfundamente; Fundamentmaterial: Stahlbeton |
| 19 | Massivdecken | fehlte | Deckenkonstruktion: Massivdecke, Material nicht näher bekannt |
| 19 | Holzbalkendecke über Dachgeschoss | fehlte | Decke über: Dachgeschoss; Deckenkonstruktion: Holzbalkendecke |
| 19 | Massivholztreppe mit Holzgeländer | fehlte | Bauteil: Geschosstreppe; Material: Massivholz; Ausführung / Merkmale: Holzgeländer |
| 19 | Kellertreppe aus Beton | fehlte | Bauteil: Kellertreppe; Material: Beton |
| 19 | Kunststofffenster | vorhanden, jetzt je Fenstergruppe | Rahmenmaterial: Kunststoff |
| 19 | 2-fach Isolierverglasung ohne Nachweis einer bestimmten Beschichtung | spezifische Option vorhanden; neutrale Detailtrennung fehlte | Verglasung: Scheibenanzahl: Zweifach verglast (2-fach); Glasart / thermische Ausführung: Isolierglas, Beschichtung nicht bekannt |
| 19 | Elektrische Vorsatzrollläden überwiegend | fehlte | Sonnenschutzart: Vorsatzrollladen; Bedienung / Antrieb: Elektrisch; Abdeckung: Überwiegend |
| 19 | Holzwerkstoffzargen innen | fehlte | Bauteil: Innentür; Türzarge / Rahmen: Holzwerkstoff |
| 19 | Leichte furnierte Türblätter ohne konkrete Kernangabe | fehlte | Ausführung / Merkmale: Leichtes Türblatt laut Beschreibung, Furniert |
| 19 | Mittlere Sanitärausstattung | fehlte separat | Sanitärausstattung: Qualität: Mittel / zweckmäßig |
| 17 | Bad im EG mit Dusche, Waschtisch und WC | nur unspezifische Freitexterfassung | Sanitärobjekte: Dusche, Waschtisch, WC; Bad / Geschoss: EG |
| 17 | Bad im DG mit Wanne, Waschtisch und WC | nur unspezifische Freitexterfassung | Sanitärobjekte: Badewanne, Waschtisch, WC; Bad / Geschoss: DG |
| 19 | Raufasertapeten | fehlte | Wandoberflächen: Raufasertapete |
| 19 | Strukturtapeten | fehlte | Wandoberflächen: Strukturtapete |
| 19 | Gemusterte Tapeten | fehlte | Wandoberflächen: Mustertapete |
| 19 | Anstrich der Wände | fehlte | Wandoberflächen: Anstrich |
| 19 | Deckenhoch geflieste Bäder | fehlte | Wandbelag / Fliesenhöhe: Deckenhoch gefliest |
| 19 | Fliesenspiegel der Küche | fehlte | Wandfliesen: Umfang: Fliesenspiegel |
| 19 | Decken mit Anstrich | fehlte | Deckenoberflächen: Anstrich |
| 19 | Profilholzbretter an der Decke | fehlte | Deckenoberflächen: Profilholzbretter |
| 19 | Raufasertapete an der Decke | fehlte | Deckenoberflächen: Raufasertapete |
| 19 | Fertigparkett | fehlte als konkrete Parkettart | Bodenbelag: Fertig-/Mehrschichtparkett |
| 19 | Fliesen in Küche und Bad | vorhanden, jetzt raumbezogen | Bodenbelag: Fliesen |
| 19 | Teppichboden | vorhanden, jetzt raumbezogen | Bodenbelag: Teppichboden |
| 19 | Zentralheizung | vorhanden | Versorgungsart: Zentralheizung |
| 19 | Plattenheizkörper | nur allgemeine Heizkörper vorhanden | Bauart der Heizkörper: Plattenheizkörper |
| 19 | Heizmedium Erdöl | vorhanden | Energieträger: Heizöl |
| 30 | Heizung aus 1992 | vorhanden | Baujahr Heizungsanlage: 1992 |
| 19 | Warmwasser über Heizungsanlage | vorhanden | Warmwasserbereitung: Über Heizungsanlage |
| 19 | Freie Fensterlüftung | vorhanden | Lüftung: Fensterlüftung |
| 19 | Elektroinstallation qualitativ mittel | fehlte | Elektroausstattung laut Beschreibung: Mittel / üblich |
| 19 | Befestigte Wege und Freiflächen | fehlte | Außenanlagen: Befestigte Wege / Freiflächen |
| 19 | Terrasse | vorhanden | Art der Fläche: Terrasse |
| 19 | Einfriedung ohne bezeichnetes Material | fehlte als neutrale Oberkategorie | Außenanlagen: Einfriedung, Art nicht näher bekannt |
| 19 | Rasen und Pflanzflächen | fehlte | Außenanlagen: Rasenflächen, Pflanzflächen |
| 19 | Ein Garagenstellplatz | vorhanden | Art der Anlage: Einzelgarage; Stellplatzkapazität insgesamt: 1 |
| 17 | Kelleraußentreppe | fehlte | Kellerzugang: Kelleraußentreppe |
| 17 | Fünf Heizöltanks je 800 Liter | fehlte | Brennstofflager: Heizöltanks; Anzahl Behälter: 5; Fassungsvermögen je Behälter: 800 |
| 17 | Rechteckiger Grundstückszuschnitt | fehlte | Grundstückszuschnitt: Annähernd rechteckig |
| 17 | Straßenfront rund 19 Meter, Tiefe rund 27 Meter | fehlte | Straßenfront: 19; Grundstückstiefe: 27 |
| 17 | Weitgehend eben | fehlte | Topografie: Weitgehend eben |
| 17 | Zugang von öffentlicher Straße und zweiter Zugang | fehlte | Zugang / Zufahrt: Direkt von öffentlicher Straße, Zusätzlicher Zugang |
| 17 | Unbefestigte Verkehrsfläche | fehlte | Straßenbefestigung: Unbefestigt; Nutzungsqualität: Verkehrs-/Straßenfläche |
| 18 | Innenwohnfläche 111,53 m² | vorhanden | Wohnfläche innen: 111.53 |
| 18 | Terrasse 20 m² mit Viertelanrechnung | vorhanden | Tatsächliche Grundfläche: 20; Wohnflächenanrechnung: 25 % |
| 18 | wGF 165 m² und BGF Haus 209 m² | vorhanden | Wertrelevante Geschossfläche (wGF): 165; Brutto-Grundfläche (BGF): 209 |
| 18 | BGF Garagenanbau 30 m² | vorhanden, Flächenbegriff muss ergänzt werden | Fläche Anlage: 30; Flächenbegriff der Anlage: Brutto-Grundfläche (BGF) |
| 19 | Energieverbrauchskennwert 186,2, Klasse F | Wert und Klasse vorhanden, Kennwertart ergänzt | Endenergiekennwert: 186.2; Art des eingetragenen Kennwerts: Endenergieverbrauch; Energieeffizienzklasse laut Ausweis: F |
| 20 | Feuchtigkeitserscheinungen im Keller | vorhanden, Befund und Ursachenverdacht jetzt getrennt | Befund / Verdacht: Feuchtigkeit; Betroffene Bereiche: Keller; Kellerbefund: Feuchtigkeitserscheinungen |
| 29 | Garage Baujahr ca. 1997 | vorhanden | Baujahr Anlage: 1997 |
| 17 | Garagenanbau in Massivbauweise | fehlte als konkretes Anlagenmerkmal | Bauweise der Anlage: Massivbau; Anordnung der Anlage: Angebaut |
| 30 | Elektrische Markise | fehlte | Sonnenschutzart: Markise; Bedienung / Antrieb: Elektrisch |
| 30 | Einbauküche vorhanden | fehlte | Einbauküche: Vorhanden |
| 11 | Nießbrauch soll beim Verkauf gelöscht werden | Recht vorhanden, Löschungsstand fehlte | Art des Rechts: Nießbrauch; Stand im Verkauf: Löschung beabsichtigt |
| 11 | Baulastenauszug liegt nicht vor | fehlte als Unterlagenzustand | Baulastenauskunft: Keine Auskunft vorhanden |
| 12 | Keine Altlastenauskunft vorhanden, keine Altlasten bekannt | fehlte als Kenntnisstand | Altlasten: Auskunftsstand: Keine Altlasten bekannt |

## Grenzen der Übernahme
- Im Gutachten steht „2-fach Isolierverglasung“. Das beweist allein keine bestimmte Beschichtung; diese bleibt unbekannt.
- „Augenscheinlich nicht vorhanden oder verbraucht“ wird nicht in eine gesicherte Abdichtungsdiagnose umgewandelt.
- „Einfriedung“ benennt kein Material. Deshalb keine automatische Auswahl Zaun, Mauer oder Hecke.
- „Überwiegend elektrisch“ bedeutet nicht alle Fenster. Anteil und Bezugsbereich bleiben kenntlich.
- Die prognostizierte Heizungsersparnis und ein dort geschätzter Austauschpreis werden nicht als allgemeiner Pflichtabzug hinterlegt.
- Der Wertansatz für Markise, Küche oder Garage ist keine allgemeingültige Preisliste.
- Eine Löschungsabsicht beim Nießbrauch ist keine nachgewiesene Löschung. Das Gutachten trifft dazu Annahmen, die bei einem neuen Auftrag erneut zu prüfen sind.
- Alter und Ausstattungsstandard erzeugen keine automatisch gesicherte Energieklasse.

## Akzeptanzfälle für die spätere App
1. Kunde sagt nur „zweifach verglast“: Speichern ohne Auswahl Isolierglas/Low-E und ohne U-Wert möglich.
2. Kunde sagt „unten zweifach, oben dreifach“: zwei Fenstergruppen mit Bereich; keine globale Verfälschung.
3. Kunde sagt „Gasheizung“: Gasart und Kesseltechnik bleiben offen. Keine automatische Erdgas-/Brennwertannahme.
4. Kunde sagt „Dach gedämmt“: Speichern ohne Material oder Dämmdicke möglich.
5. Kunde sagt „Keller teilweise feucht“: Befund erfassen, Ursache offenlassen.
6. Kunde sagt „Heizung läuft, soll aber getauscht werden“: beides gleichzeitig speicherbar.
7. Kunde sagt „Baujahr irgendwann 1930 bis 1940“: kein erfundenes Einzeljahr.
8. Kunde sagt „alle Bäder deckenhoch gefliest, Küche nur Fliesenspiegel“: raumbezogene Angaben möglich.
9. Kunde nennt „30 m² BGF Garage“: diese Fläche bleibt BGF und wird nicht Wohn-/Nutzfläche.
10. Ein wichtiger Begriff fehlt: Sonstiges und Originalnotiz bleiben ohne Datenverlust nutzbar.

Die Konfigurationsprüfungen dieses Durchlaufs wurden lokal erfolgreich ausgeführt. Ein UI-Test dieser zehn Akzeptanzfälle ist nach Umsetzung durch Claude noch erforderlich.
