# MaklerCockpit: geprüfte Auswahlfelder für Claude
Version 2.0 | Stand 17.11.2026 | Abgleich mit dem Wertgutachten Wuhletal 15

## Was korrigiert wurde
Die erste Fassung erfasste wichtige Obergruppen, hatte aber Lücken bei allgemeinen Kundenformulierungen und Bauteildetails. Insbesondere fehlte eine neutrale Auswahl „zweifach verglast, weitere Details unbekannt“. Sie enthielt bereits Zweifach-Isolierglas und Zweifach-Wärmeschutzglas, zwang damit aber zu unnötiger Spezifizierung. Kastenfenster stand außerdem fälschlich in derselben Kategorie wie die Scheibenzahl.

Die neue Fassung trennt Scheibenzahl, thermische Ausführung, Fensterkonstruktion und Rahmen. Zusätzlich sind die konkreten Bau- und Ausstattungsmerkmale aus dem Gutachten als eigene Optionen erfasst. Gleichartige, aber unterschiedlich ausgestattete Bereiche werden als mehrere Einträge gespeichert.

## Auftrag an Claude
Überarbeite die Eingabemaske „Große Analyse“ anhand der beigefügten JSON-Datei Version 2.0. Die Anwendung selbst wurde hier noch nicht geändert. Übernimm diese Auswahlfelder, Schnellauswahlen, Abhängigkeiten und Prüfregeln in die bestehende Anwendung. Bewahre alle ursprünglichen Angaben und Quellen. Der Prüfbericht erklärt die Änderungen und den Abgleich mit dem Gutachten.

Zeige standardmäßig nur Kerndaten; die zusätzlichen Detailfelder stehen in aufklappbaren Bauteilgruppen. Verwende durchsuchbare Dropdowns, Mehrfachauswahl und wiederholbare Einträge. Baujahre, Flächen und Geldbeträge bleiben Zahlenfelder. Die ausführliche Erfassung muss möglich sein, ohne alle Felder beim Kundentermin zwingend abzufragen.

## Grundregeln für die Erfassung
- Jede Angabe lässt sich mit unbekannten Details speichern. „2-fach verglast“ darf allein ausgewählt werden; Glasqualität, Baujahr und U-Wert können offenbleiben.
- Keine Vorauswahl Eigentümer, nein, null Quadratmeter oder mangelfrei. Fachlicher Wert null mit Datenstatus unbeantwortet/unbekannt/nicht zutreffend unterscheiden.
- Zusätzlich „Unbekannt“; bei offenen Kategorien „Sonstiges“ mit eigener Beschreibung. Geschlossene Klassifikationen wie Energieklasse nicht beliebig erweitern.
- Suchbegriffe und Umgangssprache dienen als Vorschläge. Originalwortlaut erhalten; keine automatische technische Diagnose aus Sprache.
- Quelle und Prüfstatus getrennt speichern. Unterlage belegt einen Inhalt, eine Besichtigung nur den sichtbaren Zustand. Geprüft verlangt Prüfer, Datum und Beleg.
- Merkmale aus einem Gutachten sind dokumentierte Aussagen mit Stichtag. Vermutungen, Vorbehalte und ungefähre Angaben nicht in gesicherte Tatsachen verwandeln.

## Fenster: schnelle Auswahl beim Kunden
| Kundenangabe | Was gespeichert wird | Was offenbleibt |
|---|---|---|
| „2-fach verglast“ | Scheibenzahl zweifach | Beschichtung, U-Wert, Rahmen, Baujahr |
| „2-fach Isolierglas“ | Zweifach + Isolierglas, Beschichtung unbekannt | Kein Nachweis für unbeschichtet oder Low-E |
| „2-fach Wärmeschutzglas“ | Zweifach + Wärmeschutzangabe mit Quelle | Nachweisstatus, exakter U-Wert |
| „3-fach verglast“ | Dreifach | Keine automatische Energieklasse oder U-Wert |
| „Kastenfenster“ | Konstruktionsart Kastenfenster | Einzelne Verglasungen separat klären |
| „Unten neue, oben alte Fenster“ | Zwei Fenstergruppen mit Bereich und jeweiliger Angabe | Keine pauschale Gleichsetzung des ganzen Hauses |

„Isolierglas“ ist ein Oberbegriff. Daraus ergibt sich allein nicht, ob eine Wärmeschutzbeschichtung vorhanden ist. Uw beschreibt das gesamte Fenster, Ug die Verglasung. Diese Werte getrennt speichern und nicht aus Baujahr oder Scheibenzahl schätzen. Quellen: S03 und S04 im JSON.

## Herkunft und Prüfstatus
Quellen: Eigentümerangabe; Mieterangabe; Verwaltungsangabe; Eigene Besichtigung; Eigenes Aufmaß; Exposé / Inserat; Grundriss / Bauplan; Flächenberechnung; Bauakte / Genehmigung; Energieausweis; Rechnung / Modernisierungsbeleg; Gutachten / Fachbericht; Grundbuch / Kataster; Amtliche Auskunft; Mietvertrag; Sonstige Quelle.

Prüfstatus: Ungeprüfte Angabe; Durch Unterlage belegt; Vor Ort beobachtet; Fachlich geprüft; Annahme / Schätzung; Widersprüchlich.

Pro Feld optionale Datei/Seite, Datum, Bereich und Originalnotiz speichern. Bei mehreren Quellen widersprechende Angaben nebeneinander erhalten. Eine Rohangabe kann ungeprüft sein, obwohl ein Dokument als Quelle vorhanden ist.

## Vollständiger aktueller Feldkatalog
Die Tabellen enthalten aktive Fachoptionen. Unbekannt und zulässige Sonstiges-Angaben kommen hinzu. Wiederholbare Gruppen erlauben unterschiedliche Merkmale im selben Gebäude.

### Objekt und Gebäude

| Feld | Auswahl / Eingabe |
|---|---|
| Objektart | **Auswahl**: Einfamilienhaus; Doppelhaushälfte; Reihenmittelhaus; Reihenendhaus; Zweifamilienhaus; Mehrfamilienhaus; Eigentumswohnung; Wohn- und Geschäftshaus; Unbebautes Grundstück; Gewerbeobjekt<br/>Objektart steuert die sichtbaren Formularbereiche; ein Auswahlwert aktiviert kein noch nicht vorhandenes Bewertungsmodell. |
| Gebäudestellung | **Auswahl**: Freistehend; Einseitig angebaut; Beidseitig angebaut; Eckbebauung<br/>Objektart und Gebäudestellung getrennt speichern; Doppelhaushälfte und Reihenendhaus sind Objektarten. |
| Baujahr | **Jahr**<br/>Zahleneingabe. Bei ungefähren Angaben zusätzlich Genauigkeit wählen. Kein Standardbaujahr einsetzen.<br/>Bedingt anzeigen; Regel im JSON. |
| Genauigkeit Baujahr | **Auswahl**: Jahr bekannt; Circa-Angabe; Nur Zeitraum bekannt |
| Baujahr-Zeitraum | **Zeitraum**<br/>Bedingt anzeigen; Regel im JSON. |
| Tragende Bauweise | **Auswahl**: Massivbau; Holzrahmen-/Holzständerbau; Holztafelbau; Massivholzbau; Blockhaus; Fachwerk; Stahlbetonskelettbau; Stahlskelettbau; Misch-/Hybridbauweise<br/>Fertighaus zusätzlich über Herstellungsart erfassen. Ein Fertighaus kann aus Holz oder aus massiven Bauteilen bestehen. |
| Herstellungsart | **Auswahl**: Überwiegend vor Ort errichtet; Fertig-/Elementbau; Modulbau; Kombinierte Herstellungsart |
| Vollgeschosse | **Ganzzahl**<br/>Ganzzahl; tatsächliche und baurechtliche Einordnung bei Unklarheit offenlassen. Dachgeschoss und Keller nicht automatisch als Vollgeschoss zählen. |
| Baulich vorhandene Ebenen insgesamt | **Ganzzahl**<br/>Optional als zusätzliche Angabe, keine automatische Gleichsetzung mit Vollgeschossen. |
| Zimmer | **Zahl**<br/>Zahleneingabe mit Dezimalwerten; Raumzählung bei Bedarf erläutern. Nicht nur ganze Zahlen zulassen. |
| Wohneinheiten | **Ganzzahl** |
| Unterkellerung | **Auswahl**: Nicht unterkellert; Teilunterkellert; Vollunterkellert |
| Unterkellerter Anteil | **Zahl** in %<br/>Optionaler Anteil 0 bis 100, nicht aus Teilunterkellerung pauschal ableiten.<br/>Bedingt anzeigen; Regel im JSON. |
| Kellernutzung | **Mehrfachauswahl**: Abstell-/Lagerkeller; Heizungs-/Technikkeller; Waschküche; Hobbyraum; Kellergarage; Als Wohnraum genutzt<br/>Wohnraumnutzung im Keller belegt keine Genehmigung oder anrechenbare Wohnfläche.<br/>Bedingt anzeigen; Regel im JSON. |
| Dachform | **Auswahl**: Satteldach; Walmdach; Krüppelwalmdach; Flachdach; Pultdach; Mansarddach; Zeltdach; Schmetterlingsdach; Kombinierte Dachformen |
| Dachausbau | **Auswahl**: Kein nutzbares Dachgeschoss; Nicht ausgebaut; Teilweise ausgebaut; Vollständig ausgebaut<br/>Ausgebaut bedeutet nicht automatisch baurechtlich genehmigte Wohnfläche. |
| Weiteres Dachausbaupotenzial | **Auswahl**: Nicht geprüft; Technisch möglich laut Angabe; Genehmigung beantragt; Genehmigung für weiteren Ausbau liegt vor; Nach vorliegender Prüfung nicht möglich<br/>Baureserve nur mit konkreter Unterlage und gesonderter Prüfung in die Bewertung übernehmen.<br/>Bedingt anzeigen; Regel im JSON. |

### Flächen

| Feld | Auswahl / Eingabe |
|---|---|
| Wohnfläche innen | **Zahl** in m²<br/>Nur Innenwohnfläche. Ist nur eine Gesamtwohnfläche bekannt, nicht vollständig in dieses Feld kopieren. |
| Angegebene Wohnfläche aus Unterlagen/Exposé | **Zahl** in m² |
| Außenflächen in angegebener Wohnfläche | **Auswahl**: Bereits enthalten; Nicht enthalten; Nicht erkennbar<br/>Bei bereits enthaltener Außenfläche den Anteil nicht nochmals addieren. |
| Wohnfläche berechnet nach | **Auswahl**: Wohnflächenverordnung (WoFlV); II. Berechnungsverordnung (II. BV); Als Wohnfläche bezeichnete DIN-277-Angabe; Andere dokumentierte Berechnung; Eigentümerangabe ohne Berechnung<br/>DIN 277 behandelt andere Flächenbegriffe. Eine so bezeichnete Angabe zunächst als ungeklärte Flächenbasis speichern, nicht automatisch als Wohnfläche übernehmen. |
| Nutzfläche | **Zahl** in m²<br/>Keller, Dachboden oder Garage getrennt nach Flächenart erfassen. Keine Addition zur Wohnfläche ohne passenden Nachweis. |
| Wertrelevante Geschossfläche (wGF) | **Zahl** in m² |
| wGF-Berechnungsgrundlage | **Text**<br/>Modell/Unterlage, Definition, Datum und Seite erfassen; nicht aus Wohnfläche schätzen. |
| Brutto-Grundfläche (BGF) | **Zahl** in m² |
| BGF-Berechnungsgrundlage | **Text** |
| Grundstücksfläche | **Zahl** in m²<br/>Bei mehreren Flurstücken getrennte Teilflächen und Nutzungsqualitäten verwenden. |

### Terrassen, Balkone und weitere Außenflächen (mehrere Einträge möglich)

| Feld | Auswahl / Eingabe |
|---|---|
| Art der Fläche | **Auswahl**: Terrasse; Balkon; Loggia; Dachterrasse; Dachgarten; Beheizter Wintergarten; Unbeheizter Wintergarten |
| Tatsächliche Grundfläche | **Zahl** in m² |
| Wohnflächenanrechnung | **Auswahl**: 0 % / nicht angerechnet; 25 %; 50 %; 100 %; Anderer dokumentierter Anteil<br/>Auswahl nach Berechnungsgrundlage filtern. Bei Balkon/Loggia/Terrasse/Dachgarten nach WoFlV regelmäßig 25 %, höchstens 50 %. 0 % nur als dokumentierter Ausschluss; 100 % und mehr als 50 % für diese Typen im WoFlV-Modus sperren. Bei Wintergärten separat prüfen; keine pauschale Anrechnung aus der Bezeichnung ableiten. |
| Dokumentierter Anrechnungsanteil | **Zahl** in %<br/>0 bis 100; gleiche typ- und regelwerkabhängige Prüfung wie bei Schnellauswahl.<br/>Bedingt anzeigen; Regel im JSON. |
| Überdachung | **Auswahl**: Nicht überdacht; Teilweise überdacht; Überdacht |

### Garagen, Stellplätze und Nebengebäude (mehrere Einträge möglich)

| Feld | Auswahl / Eingabe |
|---|---|
| Art der Anlage | **Auswahl**: Außenstellplatz; Carport; Einzelgarage; Doppelgarage; Tiefgaragenstellplatz; Duplexstellplatz; Garagengebäude; Gartenhaus; Geräteschuppen; Werkstatt; Scheune; Stall; Sonstiges Nebengebäude |
| Anzahl | **Ganzzahl**<br/>Bei Doppelgarage Anzahl der Garagen und tatsächliche Stellplatzkapazität nicht verwechseln. |
| Stellplatzkapazität insgesamt | **Ganzzahl** |
| Baujahr Anlage | **Jahr** |
| Fläche Anlage | **Zahl** in m²<br/>Fläche nur zusammen mit Flächenbegriff auswerten; 30 m² BGF nicht als Nutzfläche bezeichnen. |
| Zustand Anlage | **Auswahl**: Neuwertig; Gut; Übliche Gebrauchsspuren; Reparaturbedarf; Erheblicher Sanierungsbedarf; Nicht nutzbar |
| Bauweise der Anlage | **Auswahl**: Massivbau; Holzbau; Metall-/Leichtbau; Mischbau |
| Anordnung der Anlage | **Auswahl**: Angebaut; Freistehend; Im Gebäude integriert |
| Flächenbegriff der Anlage | **Auswahl**: Brutto-Grundfläche (BGF); Nutzfläche laut Unterlage; Überbaute Grundfläche; Flächenbegriff nicht bekannt |

### Ausstattung und Erhaltung

| Feld | Auswahl / Eingabe |
|---|---|
| Tatsächlicher Ausstattungsstandard | **Auswahl**: Sehr einfach; Einfach; Mittel / normal; Gehoben; Sehr gehoben / luxuriös<br/>Beschreibung für die Erfassung; keine automatische NHK-Standardstufe oder pauschaler Preisaufschlag. Alter, energetischer Zustand und Schäden gesondert erfassen. |
| Erhaltungszustand | **Auswahl**: Neuwertig; Sehr gut; Gut; Normal / gepflegt; Renovierungsbedürftig; Sanierungsbedürftig; Umfassend sanierungsbedürftig; Aktuell nicht nutzbar<br/>Zusätzlich konkrete Befunde erfassen. Kernsanierungsbedarf erst nach passender Prüfung als Befund verwenden. |
| Bodenbeläge | **Mehrfachauswahl**: Parkett; Dielen; Laminat; Vinyl / Designboden; Fliesen; Naturstein; Teppich; Linoleum; Sichtbeton / Estrich; Fertig-/Mehrschichtparkett; Massivparkett; Kork; PVC-Belag |
| Fassade / Außenwandbekleidung | **Mehrfachauswahl**: Putz; Klinker / Verblendmauerwerk; Holzbekleidung; Fassadenplatten; Sichtmauerwerk; Vorgehängte Fassade; Anstrich / Beschichtung<br/>Die sichtbare Fassade belegt nicht den dahinterliegenden Wandaufbau oder die Dämmung. |
| Wanddämmung | **Mehrfachauswahl**: Keine Dämmung laut vorliegender Angabe; Wärmedämmverbundsystem; Kerndämmung; Innendämmung; Gedämmte vorgehängte Fassade; Gedämmt, genaue Ausführung unbekannt |
| Zugänglichkeit / Barrieren | **Mehrfachauswahl**: Stufenloser Zugang; Wohnbereich ohne Stufen; Aufzug; Treppenlift; Bodengleiche Dusche; Breite Türen laut Aufmaß; Bekannte Barrieren vorhanden<br/>Keine automatische Kennzeichnung als normgerecht barrierefrei oder rollstuhlgerecht. |

### Modernisierungen (mehrere Einträge möglich)

| Feld | Auswahl / Eingabe |
|---|---|
| Bauteil / Maßnahme | **Mehrfachauswahl**: Dacheindeckung; Dachdämmung; Dämmung oberste Geschossdecke; Fassade; Außenwanddämmung; Fenster; Außentüren; Elektrik; Wasserleitungen; Abwasserleitungen; Gasleitungen; Heizung; Warmwasser; Lüftung; Bäder; Fußböden; Innenausbau; Grundrissänderung; Kellerabdichtung; Photovoltaik; Solarthermie; Batteriespeicher; Wallbox; Garage / Nebengebäude; Kernsanierung laut Angabe, Umfang prüfen; Geschossdecken; Treppen; Innentüren; Rinnen / Fallrohre; Drainage; Außenanlagen<br/>Maßnahmen mit gleichem Jahr/Umfang dürfen zusammen erfasst werden. Unterschiedliche Ausführungsjahre als getrennte Zeilen. |
| Jahr der Maßnahme | **Jahr** |
| Umfang der Maßnahme | **Auswahl**: Einzelne Teile erneuert; Teilweise erneuert; Überwiegend erneuert; Vollständig erneuert<br/>Umfang bezieht sich auf das ausgewählte Bauteil, nicht auf den Modernisierungsgrad des ganzen Hauses. |
| Dokumentierter Anteil | **Zahl** in %<br/>Optional; keine automatischen Werte 25/50/75/100 aus sprachlichen Kategorien erzeugen. |
| Nachweis vorhanden | **Auswahl**: Rechnung; Abnahme-/Prüfprotokoll; Bauunterlage; Fotodokumentation; Kein Nachweis vorhanden; Nachweis angefordert<br/>Die eigentliche Quellenangabe samt Datei/Seite zusätzlich speichern. |
| Was wurde konkret gemacht? | **Freitext** |

### Schäden, Mängel und Feuchtigkeit (mehrere Einträge möglich)

| Feld | Auswahl / Eingabe |
|---|---|
| Befund / Verdacht | **Auswahl**: Keine Schäden bekannt; Feuchtigkeit; Wasserschaden; Undichtigkeit; Schimmelverdacht; Schimmelbefund dokumentiert; Rissbildung; Setzungserscheinungen; Dachschaden; Fassadenschaden; Fenster-/Türschaden; Mangel an Elektrik; Heizungsstörung; Mangel an Leitungen; Holzschaden; Wärmebrückenverdacht; Schadstoffverdacht; Brandschaden<br/>Keine Schäden bekannt bedeutet Kenntnisstand, keine nachgewiesene Mangelfreiheit. Quelle immer mit erfassen. Bei nicht geprüft Unbekannt wählen. |
| Betroffene Bereiche | **Mehrfachauswahl**: Keller; Erdgeschoss; Obergeschoss; Dachgeschoss; Dach; Fassade; Balkon / Terrasse; Bad; Küche; Technikraum; Nebengebäude; Grundstück |
| Stand des Befunds | **Auswahl**: Verdacht / Hinweis; Sichtbar festgestellt; Fachlich untersucht; Behoben; Unter Beobachtung<br/>Sichtbare Beobachtung und gesicherte Ursache unterscheiden. |
| Handlungsbedarf | **Auswahl**: Noch nicht beurteilt; Beobachten; Bei Instandhaltung bearbeiten; Zeitnah prüfen / bearbeiten; Sofortige Fachprüfung empfohlen<br/>Keine automatische technische Diagnose oder Kostenschätzung aus dieser Auswahl. |
| Beschreibung und Umfang | **Freitext** |

### Heizungsanlagen (mehrere Einträge möglich)

| Feld | Auswahl / Eingabe |
|---|---|
| Rolle der Anlage | **Auswahl**: Hauptheizung; Zusatzheizung; Reserve / Spitzenlast |
| Versorgungsart | **Auswahl**: Zentralheizung; Etagenheizung; Einzelraumheizung; Wärmeversorgung über Netz |
| Technik der Wärmeerzeugung | **Auswahl**: Brennwertkessel; Niedertemperaturkessel; Konstanttemperatur-/Standardkessel; Wärmepumpe; Biomassekessel; Fernwärme-Übergabestation; Nahwärme-Übergabestation; Elektrische Direktheizung; Nachtspeicherheizung; Einzelofen / Kamin; Blockheizkraftwerk; Solarthermische Anlage; Heizkessel, Kesseltechnik nicht bekannt; Gastherme, Kesseltechnik nicht bekannt; Heizungsanlage, Technik nicht näher bekannt<br/>Hybridanlagen durch mehrere Anlagenzeilen abbilden. Gas ist ein Energieträger, Zentralheizung eine Versorgungsart, Fußbodenheizung eine Wärmeverteilung. |
| Energieträger | **Mehrfachauswahl**: Erdgas; Flüssiggas; Heizöl; Strom; Holzpellets; Scheitholz; Hackschnitzel; Kohle; Fernwärme; Nahwärme; Solarwärme; Gas, genaue Gasart unbekannt |
| Wärmepumpenart | **Auswahl**: Luft-Wasser; Sole-Wasser / Erdwärme; Wasser-Wasser; Luft-Luft; Abluft-Wärmepumpe<br/>Bedingt anzeigen; Regel im JSON. |
| Baujahr Heizungsanlage | **Jahr** |
| Wärmeverteilung | **Mehrfachauswahl**: Heizkörper; Fußbodenheizung; Wandheizung; Deckenheizung; Konvektoren; Warmluft; Direkte Raumheizung |
| Betriebszustand laut Kenntnisstand | **Auswahl**: In Betrieb; Eingeschränkt funktionsfähig; Außer Betrieb; Funktion nicht geprüft<br/>Betrieb belegt keine technische oder rechtliche Prüfung. Altoption Austausch geplant nur als Migration erhalten; im neuen Formular über replacement_plan erfassen. |
| Geplanter Austausch | **Auswahl**: Kein Austausch geplant; Wird erwogen; Geplant; Beauftragt<br/>Getrennt vom tatsächlichen Betriebszustand führen. |

### Energie und Haustechnik

| Feld | Auswahl / Eingabe |
|---|---|
| Warmwasserbereitung | **Mehrfachauswahl**: Über Heizungsanlage; Separate Warmwasser-Wärmepumpe; Elektrischer Durchlauferhitzer; Elektrischer Boiler; Gas-Durchlauferhitzer; Solarthermische Unterstützung |
| Lüftung | **Mehrfachauswahl**: Fensterlüftung; Abluftanlage; Zentrale Lüftung mit Wärmerückgewinnung; Dezentrale Lüftung mit Wärmerückgewinnung; Zu-/Abluftanlage ohne bekannte Wärmerückgewinnung; Lüftungsanlage, Ausführung nicht bekannt; Lüftung mit Wärmerückgewinnung, zentral/dezentral offen |
| Energieausweis: Unterlagenstand | **Auswahl**: Liegt vor; Angefordert; In Erstellung; Liegt nicht vor; Ausnahme wird geltend gemacht<br/>Eine behauptete Ausnahme gesondert prüfen; daraus keine automatische Befreiung ableiten. |
| Energieausweisart | **Auswahl**: Bedarfsausweis; Verbrauchsausweis<br/>Ausweisart darf laut Eigentümerangabe bekannt sein, auch wenn das Dokument noch angefordert ist. Quelle/Prüfstatus erhalten; nicht als vorliegenden Ausweis ausgeben. |
| Endenergiekennwert | **Zahl** in kWh/(m²·a)<br/>Wert aus dem Ausweis übernehmen. Gebäudenutzfläche im Energieausweis nicht mit Wohnfläche gleichsetzen; keinen Primärenergiewert hier eintragen. Feld Kennwertart ergänzen, wenn der Ausweis nicht eindeutig ist. |
| Energieeffizienzklasse laut Ausweis | **Auswahl**: A+; A; B; C; D; E; F; G; H; Im vorliegenden Ausweis nicht angegeben<br/>Originalklasse speichern; eine Rechenklasse ist nur eine getrennte Plausibilitätsprüfung. Ohne passende Ausweisgrundlage keine Energieklasse behaupten. |
| Gültig bis | **Datum** |
| Photovoltaik | **Auswahl**: Nicht vorhanden; Vorhanden; Geplant |
| PV-Leistung | **Zahl** in kWp<br/>Bedingt anzeigen; Regel im JSON. |
| PV-Eigentum / Vertragsbindung | **Auswahl**: Eigentum; Gemietet / geleast; Anlage gehört Dritten<br/>Bedingt anzeigen; Regel im JSON. |
| Batteriespeicher | **Auswahl**: Nicht vorhanden; Vorhanden; Geplant |
| Speicherkapazität | **Zahl** in kWh<br/>Bedingt anzeigen; Regel im JSON. |
| Wallbox / Ladepunkt | **Auswahl**: Nicht vorhanden; Anschluss vorbereitet; Vorhanden; Geplant |
| Ladeleistung | **Zahl** in kW<br/>Bedingt anzeigen; Regel im JSON. |
| Solarthermie | **Auswahl**: Nicht vorhanden; Für Warmwasser; Für Warmwasser und Heizungsunterstützung |
| Art des eingetragenen Kennwerts | **Auswahl**: Endenergiebedarf; Endenergieverbrauch; Primärenergiekennwert, hier nur als Hinweis<br/>Primärenergie nicht zur Bestimmung der Endenergieklasse verwenden; ursprünglichen Wert im eigenen Primärenergiefeld speichern. |
| Primärenergiekennwert (optional) | **Zahl** in kWh/(m²·a) |

### Nutzung und Recht

| Feld | Auswahl / Eingabe |
|---|---|
| Aktuelle Nutzung | **Auswahl**: Eigengenutzt; Vollständig vermietet; Teilweise vermietet; Leerstehend; Ferien-/Kurzzeitvermietung; Gemischte Wohn-/Gewerbenutzung<br/>Nutzung je Einheit präzisieren. Tatsächliche Nutzung und genehmigte Nutzung getrennt erfassen. |
| Verfügbarkeit | **Auswahl**: Sofort frei; Frei ab Datum; Nach Vereinbarung; Vermietet zu übernehmen; Teilweise frei |
| Verfügbar ab | **Datum**<br/>Bedingt anzeigen; Regel im JSON. |
| Ist-Nettokaltmiete insgesamt pro Monat | **Zahl** in EUR/Monat<br/>Wohnung, Stellplatz und andere Bestandteile aufschlüsseln; leer ist nicht 0. Keine Warmmiete in dieses Feld. |
| Rechtsform | **Auswahl**: Alleineigentum; Bruchteilseigentum / Miteigentum; Wohnungs-/Teileigentum; Erbbaurecht |
| Bekannte Rechte / Beschränkungen | **Mehrfachauswahl**: Keine bekannt; Wohnrecht; Nießbrauch; Wegerecht; Leitungsrecht; Baulast; Denkmalschutz; Erhaltungs-/Gestaltungsbindung; Erbbaurecht<br/>Keine bekannt ist kein bestätigter lastenfreier Rechtszustand. Rechte und Gebühren nicht automatisch wertmäßig pauschal abziehen. |
| Denkmalschutz | **Auswahl**: Kein Denkmalschutz bekannt; Einzeldenkmal; Ensemble-/Bereichsschutz; Teilbereiche geschützt<br/>Status aus geeigneter Quelle belegen; kein Standardwert nein. |
| Genehmigungs-/Prüfstand aktueller Nutzung | **Auswahl**: Nicht geprüft; Unterlagen fehlen; Unterlagen liegen vor, noch nicht geprüft; Abgleich mit Unterlagen erfolgt, keine Abweichung festgestellt; Abweichung zwischen Unterlagen und Bestand festgestellt; Nachgenehmigung beantragt; Nicht genehmigte Änderung dokumentiert<br/>Aus fehlenden Unterlagen folgt nicht automatisch ein ungenehmigter Ausbau. Prüfung und Dokumentbezug nennen. |
| Betroffene Bauteile / Nutzungen | **Mehrfachauswahl**: Dachgeschossausbau; Kellernutzung; Anbau; Wintergarten; Garage / Carport; Nutzungsänderung; Aufteilung in Einheiten; Grundriss-/Wandänderung<br/>Bedingt anzeigen; Regel im JSON. |
| Genehmigungen: Beschreibung / Dokument | **Freitext** |

### Mietverträge (mehrere Einträge möglich)

| Feld | Auswahl / Eingabe |
|---|---|
| Vermietete Einheit | **Text** |
| Vertragslaufzeit | **Auswahl**: Unbefristet; Befristet |
| Mietbeginn | **Datum** |
| Vertragsende laut Vertrag | **Datum**<br/>Ein eingetragenes Datum bestätigt nicht die rechtliche Wirksamkeit einer Befristung.<br/>Bedingt anzeigen; Regel im JSON. |
| Mietstruktur / vereinbarte Anpassung | **Auswahl**: Keine Staffel-/Indexvereinbarung erfasst; Indexmiete; Staffelmiete; Besondere Vereinbarung; Widersprüchliche Vertragsangaben<br/>Vertragstext und Wirksamkeit gesondert prüfen. Keine gleichzeitige Standardauswahl Index plus Staffel. |
| Nettokaltmiete Einheit | **Zahl** in EUR/Monat |
| Stellplatz-/Garagenmiete | **Zahl** in EUR/Monat |
| Bekannte Besonderheiten | **Mehrfachauswahl**: Mietrückstände; Laufender Streit; Kündigung erklärt; Mietminderung angegeben; Untervermietung; Förder-/Belegungsbindung; Möblierte Vermietung<br/>Tatsachenbeleg nötig; bei keinen bekannten Besonderheiten kenntnisbezogene Negativangabe speichern, nicht pauschal rechtlich unproblematisch. |

### Unterlagen, Quellen und Zusatzangaben

| Feld | Auswahl / Eingabe |
|---|---|
| Vorliegende Unterlagen | **Mehrfachauswahl**: Grundbuchauszug; Flurkarte; Bauakte / Baugenehmigung; Grundrisse; Wohnflächenberechnung; BGF-/wGF-Berechnung; Energieausweis; Modernisierungsrechnungen; Besichtigungsprotokoll; Gutachten; Mietverträge; WEG-Unterlagen; Baulastenauskunft; Denkmalauskunft; Weitere amtliche Auskünfte |
| Weitere Angaben | **Freitext**<br/>Bleibt als Ergänzung bestehen. Freitext darf strukturierte Felder nicht heimlich überschreiben. |

### Fenstergruppen (mehrere Einträge möglich)

| Feld | Auswahl / Eingabe |
|---|---|
| Bereich / Fenstergruppe | **Text**<br/>Zum Beispiel EG, DG, Keller oder Anbau. Unterschiedliche Verglasungen/Baujahre als eigene Gruppen erfassen. |
| Verglasung: Scheibenanzahl | **Auswahl**: Einfach verglast (1-fach); Zweifach verglast (2-fach); Dreifach verglast (3-fach); Mehr als drei Scheiben laut Unterlage<br/>Die Angabe 2-fach ist vollständig erfassbar, auch wenn Beschichtung, U-Wert und Glasart unbekannt sind. VSG-Folien oder Glasschichten nicht als zusätzliche Isolierglasscheiben zählen. |
| Glasart / thermische Ausführung | **Auswahl**: Isolierglas, Beschichtung nicht bekannt; Wärmeschutzverglasung / Low-E nachgewiesen; Unbeschichtetes Isolierglas nachgewiesen; Vakuumisolierglas; Einfachglas<br/>Isolierglas ist der übergeordnete Begriff und kann Wärmeschutzbeschichtung haben. Ein bloßes 2-fach oder Isolierglas nie automatisch als alt/unbeschichtet einstufen. |
| Fensterkonstruktion | **Auswahl**: Einfachfenster / ein Rahmen; Kastenfenster; Verbundfenster; Fenster mit separatem Vorsatzfenster<br/>Kasten- und Verbundfenster sind Konstruktionsarten, keine eigene energetische Scheibenzahl-Klasse. |
| Rahmenmaterial | **Auswahl**: Kunststoff; Holz; Aluminium; Holz-Aluminium; Kunststoff-Aluminium; Stahl |
| Fenster-/Öffnungsart | **Mehrfachauswahl**: Dreh-Kipp; Drehflügel; Kippfenster; Festverglasung; Schiebefenster; Dachflächenfenster; Lichtkuppel; Balkon-/Terrassentür; Hebeschiebetür; Faltanlage |
| Baujahr / Erneuerungsjahr des Fensters | **Jahr**<br/>Nicht mit dem späteren Glastausch verwechseln. |
| Jahr eines separaten Glastauschs | **Jahr** |
| Anteil am Fensterbestand | **Zahl** in %<br/>Optional, Bezugsbasis Fensteranzahl oder Fläche ergänzen. Kein unbekannter Anteil wird als 100 % behandelt. |
| Bezugsbasis des Anteils | **Auswahl**: Fensteranzahl; Fensterfläche<br/>Bedingt anzeigen; Regel im JSON. |
| Belegte Zusatzfunktionen | **Mehrfachauswahl**: Schallschutzverglasung; Sonnenschutzverglasung; Sicherheitsverglasung allgemein; Einscheibensicherheitsglas (ESG); Verbundsicherheitsglas (VSG); Einbruchhemmung nachgewiesen; Ornament-/Milchglas<br/>Mehrfachauswahl möglich. Funktion und Widerstandsklasse nicht aus Scheibenzahl ableiten. |
| Uw-Wert: gesamtes Fenster | **Zahl** in W/(m²·K)<br/>Nur dokumentierte Werte; nicht aus Baujahr oder Scheibenzahl schätzen. |
| Ug-Wert: Verglasung | **Zahl** in W/(m²·K)<br/>Nicht mit Uw austauschen. |
| Zustand / Befund | **Mehrfachauswahl**: Keine sichtbaren Auffälligkeiten; Undicht; Beschlag zwischen den Scheiben; Rahmenschaden; Dichtungen schadhaft; Beschläge beeinträchtigt; Glas beschädigt<br/>Keine sichtbaren Auffälligkeiten ersetzt keine Fachprüfung. |
| Wörtliche Angabe / Kennzeichnung | **Text**<br/>Beispiel: 2 fach verglaste Gläser. Original erhalten, normalisierte Vorschläge bestätigen lassen. |

### Rollläden, Verschattung und Markisen (mehrere Einträge möglich)

| Feld | Auswahl / Eingabe |
|---|---|
| Bereich / Zuordnung | **Text** |
| Sonnenschutzart | **Auswahl**: Kein Sonnenschutz; Rollladen, Bauart unbekannt; Vorsatzrollladen; Aufsatzrollladen; Einbaurollladen; Außenjalousie / Raffstore; Fensterladen; Markise; Außenliegender Screen; Innenjalousie / Rollo |
| Bedienung / Antrieb | **Auswahl**: Gurtzug; Kurbel; Manuell, genaue Art unbekannt; Elektrisch; Solarbetrieben<br/>Elektrische Bedienung bedeutet nicht automatisch Smart-Home-Anbindung.<br/>Bedingt anzeigen; Regel im JSON. |
| Steuerung | **Mehrfachauswahl**: Schalter; Funkfernbedienung; Zeitschaltung; Sonnen-/Windsensor; Smart-Home-Anbindung<br/>Bedingt anzeigen; Regel im JSON. |
| Abdeckung | **Auswahl**: Einzelne Fenster / Bereiche; Teilweise; Überwiegend; Vollständig<br/>Überwiegend elektrische Vorsatzrollläden ist direkt erfassbar, ohne alle Fenster gleichzusetzen.<br/>Bedingt anzeigen; Regel im JSON. |

### Tragwerk, Gründung und Keller

| Feld | Auswahl / Eingabe |
|---|---|
| Außenwandmaterial | **Mehrfachauswahl**: Mauerwerk, Steinart unbekannt; Ziegelmauerwerk; Kalksandstein; Porenbeton; Leichtbeton / Bims; Beton; Stahlbeton; Holzkonstruktion; Historisches Mischmauerwerk<br/>Konstruktionsmaterial nicht aus Putz oder Klinkeroberfläche ableiten. |
| Außenwanddicke laut Unterlage / Aufmaß | **Zahl** in cm |
| Innenwandkonstruktion | **Mehrfachauswahl**: Massive Innenwände; Mauerwerkswände; Beton-/Stahlbetonwände; Trockenbauwände; Holz-/Fachwerkwände<br/>Nicht automatisch tragend/nicht tragend zuordnen. |
| Gründungsart | **Auswahl**: Streifenfundamente; Bodenplatte / Plattengründung; Einzelfundamente; Pfahlgründung; Kombinierte Gründung |
| Fundamentmaterial | **Mehrfachauswahl**: Stahlbeton; Beton ohne näheren Nachweis; Mauerwerk; Naturstein |
| Kellerabdichtung: Kenntnisstand | **Auswahl**: Keine Abdichtung nachgewiesen; Abdichtung vorhanden laut Beleg; Abdichtung schadhaft / verbraucht laut Befund; Augenscheinlich fehlend oder verbraucht; Abdichtung erneuert; Nicht untersucht<br/>Das Gutachten nennt eine augenscheinliche Einschätzung. Diese nicht als gesicherte technische Diagnose exportieren. |
| Art der Kellerabdichtung | **Mehrfachauswahl**: Außenabdichtung / schwarze Wanne; WU-Betonkonstruktion / weiße Wanne; Innenabdichtung; Horizontalsperre; Drainage angegeben<br/>Drainage ist keine alleinige Abdichtung. Keine Funktionsfähigkeit aus dem Begriff ableiten. |
| Kellerzugang | **Mehrfachauswahl**: Innentreppe; Kelleraußentreppe; Ebenerdiger Außenzugang; Luke / Leiter |
| Kellerbefund | **Mehrfachauswahl**: Zum Termin keine sichtbare Feuchtigkeit; Feuchtigkeitserscheinungen; Salzausblühungen; Wasserzutritt; Muffiger Geruch; Nicht zugänglich<br/>Trocken beim Termin ist keine dauerhafte Feuchtigkeitsfreiheit. |
| Spitzboden | **Auswahl**: Kein Spitzboden; Nicht ausgebaut; Teilweise ausgebaut; Ausgebaut<br/>Spitzboden separat vom darunterliegenden ausgebauten Dachgeschoss erfassen. |
| Zugang Spitzboden | **Auswahl**: Feste Treppe; Bodeneinschub-/Bodentreppe; Leiter; Luke ohne feste Aufstiegshilfe; Nicht zugänglich |
| Einliegerwohnung | **Auswahl**: Nicht vorhanden; Vorhanden laut Angabe; Geplant<br/>Eigenständige Einheit und genehmigte Nutzung separat prüfen; ein ausgebauter Keller ist nicht automatisch eine Einliegerwohnung. |

### Geschossdecken (mehrere Einträge möglich)

| Feld | Auswahl / Eingabe |
|---|---|
| Decke über | **Auswahl**: Kellergeschoss; Erdgeschoss; Obergeschoss; Dachgeschoss; Anbau |
| Deckenkonstruktion | **Auswahl**: Massivdecke, Material nicht näher bekannt; Stahlbetondecke; Betonfertigteildecke; Holzbalkendecke; Massivholzdecke; Stahlträgerdecke; Ziegel-/Gewölbedecke; Hohlsteindecke |

### Dachdeckung und Dämmung

| Feld | Auswahl / Eingabe |
|---|---|
| Dacheindeckung | **Mehrfachauswahl**: Dachpfannen / Ziegel, Material unbekannt; Tonziegel; Betondachsteine; Schiefer; Metall; Faserzement; Bitumenbahnen / Schindeln; Dachfolie; Reet; Dachbegrünung<br/>Faserzement nicht automatisch mit Asbest gleichsetzen; Dachbegrünung beschreibt nicht alle darunterliegenden Schichten. |
| Dachneigung von / Einzelwert | **Zahl** in Grad |
| Dachneigung bis (optional) | **Zahl** in Grad |
| Rinnen / Fallrohre: Material | **Mehrfachauswahl**: Zinkblech / Titanzink; Kupfer; Aluminium; Stahl; Kunststoff |
| Dachdämmung: Kenntnisstand | **Auswahl**: Gedämmt, genaue Ausführung offen; Keine Dämmung laut Beleg; Teilweise gedämmt; Nicht untersucht |
| Lage der Dachdämmung | **Mehrfachauswahl**: Zwischensparrendämmung; Aufsparrendämmung; Untersparrendämmung; Flachdachdämmung<br/>Mehrere Dämmlagen können kombiniert sein. Dach- und Geschossdeckendämmung getrennt führen. |
| Dämmung oberste Geschossdecke | **Auswahl**: Vorhanden; Nicht vorhanden laut Beleg; Teilweise vorhanden; Nicht untersucht |
| Dämmstoff laut Beleg | **Mehrfachauswahl**: Mineralwolle, genaue Art unbekannt; Glaswolle; Steinwolle; Holzfaser; Zellulose; EPS; XPS; PUR / PIR; Sonstiger Naturdämmstoff |
| Dokumentierte Dämmdicke Dach | **Zahl** in cm |

### Treppen und Türen (mehrere Einträge möglich)

| Feld | Auswahl / Eingabe |
|---|---|
| Bauteil | **Auswahl**: Geschosstreppe; Kellertreppe; Haustür; Innentür; Wohnungseingangstür |
| Einbauort / Gruppe | **Text** |
| Material | **Mehrfachauswahl**: Massivholz; Holz, Ausführung unbekannt; Holzwerkstoff; Beton; Stahlbeton; Stahl; Kunststoff; Aluminium; Glas |
| Ausführung / Merkmale | **Mehrfachauswahl**: Mit Glasausschnitt; Furniert; Lackiert / gestrichen; Leichtes Türblatt laut Beschreibung; Hohlraum-Türblatt nachgewiesen; Massives Türblatt nachgewiesen; Schwellenarm / schwellenlos; Wendeltreppe; Gerade Treppe; Holzgeländer; Metallgeländer<br/>Leichtes Türblatt nicht automatisch als Waben-/Röhrenspantür klassifizieren. |
| Türzarge / Rahmen | **Auswahl**: Holzwerkstoff; Massivholz; Stahl; Aluminium; Kunststoff<br/>Nur für Türgruppen anzeigen, bei Treppen nicht zutreffend.<br/>Bedingt anzeigen; Regel im JSON. |

### Raumoberflächen und Ausstattung (mehrere Einträge möglich)

| Feld | Auswahl / Eingabe |
|---|---|
| Raum / Bereich | **Text** |
| Bodenbelag | **Mehrfachauswahl**: Parkett, genaue Art unbekannt; Fertig-/Mehrschichtparkett; Massivparkett; Dielen; Laminat; Vinyl / Designboden; PVC-Belag; Fliesen; Naturstein; Teppichboden; Linoleum; Beton / Estrich; Kork<br/>Fertigparkett ist nicht Laminat. Teppich und Teppichboden dürfen als Suchbegriffe auf denselben Belag führen. |
| Wandoberflächen | **Mehrfachauswahl**: Raufasertapete; Strukturtapete; Mustertapete; Glattputz / Spachtelung; Anstrich; Holzverkleidung; Fliesen; Steinverkleidung; Tapete, Art unbekannt |
| Deckenoberflächen | **Mehrfachauswahl**: Anstrich; Tapete; Raufasertapete; Holzverkleidung; Profilholzbretter; Putz; Abgehängte Gipskartondecke; Sichtbeton; Sichtbare Balken |
| Wandfliesen: Umfang | **Auswahl**: Fliesenspiegel; Teilflächen; Etwa halbhoch; Deckenhoch |

### Bäder und Küche

| Feld | Auswahl / Eingabe |
|---|---|
| Anzahl Badezimmer | **Ganzzahl** |
| Anzahl separate WCs | **Ganzzahl** |
| Vorhandene Sanitärausstattung | **Mehrfachauswahl**: Dusche; Bodengleiche Dusche; Badewanne; Waschtisch; Doppelwaschtisch; WC; Bidet; Fenster; Mechanische Lüftung; Waschmaschinenanschluss |
| Sanitärausstattung: Qualität | **Auswahl**: Sehr einfach; Einfach; Mittel / zweckmäßig; Gehoben; Sehr gehoben<br/>Separat vom Gesamtstandard. Für unterschiedliche Bäder Detailzeilen/Freitext verwenden. |
| Einbauküche | **Auswahl**: Nicht vorhanden; Vorhanden; Teilausstattung vorhanden; Vorhanden, nicht im Verkauf enthalten; Übernahme verhandelbar |
| Baujahr / Einbaujahr Küche | **Jahr** |
| Küchenausführung | **Auswahl**: Separate Küche; Offene Küche; Wohnküche; Pantryküche |

### Badezimmer einzeln (mehrere Einträge möglich)

| Feld | Auswahl / Eingabe |
|---|---|
| Bad / Geschoss | **Text** |
| Sanitärobjekte | **Mehrfachauswahl**: Dusche; Bodengleiche Dusche; Badewanne; Waschtisch; Doppelwaschtisch; WC; Bidet |
| Wandbelag / Fliesenhöhe | **Auswahl**: Deckenhoch gefliest; Teilweise / halbhoch gefliest; Nur Spritzwasserbereiche gefliest; Ungefliest laut Angabe |
| Jahr der letzten wesentlichen Erneuerung | **Jahr** |
| Zustand | **Auswahl**: Neuwertig; Gut; Normal / nutzbar; Renovierungsbedarf; Umfassender Erneuerungsbedarf |

### Flurstücke / Teilflächen (mehrere Einträge möglich)

| Feld | Auswahl / Eingabe |
|---|---|
| Bezeichnung / Flurstück | **Text**<br/>Bei einer anonymisierten Auskunft keine Identifizierung erzwingen. |
| Fläche der Teilfläche | **Zahl** in m² |
| Nutzungsqualität | **Auswahl**: Baugrundstück; Verkehrs-/Straßenfläche; Garten-/Hinterland; Landwirtschaft; Wald |
| Richtwert / Wertansatz laut Beleg | **Zahl** in EUR/m²<br/>Keine automatische Bewertung; BRW-Modell, Stichtag und Quelle erforderlich. |
| Stichtag des Wertansatzes | **Datum** |

### Rechte und Löschungsvorbehalte einzeln (mehrere Einträge möglich)

| Feld | Auswahl / Eingabe |
|---|---|
| Art des Rechts | **Auswahl**: Nießbrauch; Wohnrecht; Wegerecht; Leitungsrecht; Sonstige Verfügungsbeschränkung |
| Eintrag / Belegstelle | **Text**<br/>Keine Berechtigtennamen oder Geburtsdaten für den allgemeinen Auswahlkatalog erforderlich. |
| Stand im Verkauf | **Auswahl**: Bleibt bestehen; Löschung beabsichtigt; Löschung nachgewiesen; Klärung erforderlich |
| Bedingung / Nachweis | **Freitext** |

### Elektroinstallation und weitere Technik

| Feld | Auswahl / Eingabe |
|---|---|
| Elektroausstattung laut Beschreibung | **Auswahl**: Einfach; Mittel / üblich; Gehoben<br/>Die Bewertung mittel aus dem Gutachten belegt weder den Sicherheitszustand noch das Vorhandensein von FI/RCD. |
| Erneuerungsstand | **Auswahl**: Überwiegend ursprünglicher Bestand; Teilweise erneuert; Überwiegend erneuert; Vollständig erneuert laut Beleg |
| Leitungsmaterial laut Nachweis | **Mehrfachauswahl**: Kupfer; Aluminium |
| FI-/RCD-Schutz laut Kenntnisstand | **Auswahl**: Vorhanden, Umfang nicht bekannt; Teilbereiche geschützt; Für angegebene Stromkreise vollständig dokumentiert; Nicht vorhanden laut Prüfung; Nicht geprüft |
| Elektrische Prüfung | **Auswahl**: Keine Prüfung bekannt; Prüfbericht liegt vor; Mängel im Prüfbericht genannt; Mängelbeseitigung dokumentiert |
| Weitere Technik | **Mehrfachauswahl**: Alarmanlage; Smart Home; Wasserenthärtung; Klimaanlage; Kamin / Ofen; Sauna; Zentralstaubsauger<br/>Hersteller/Modell und tatsächliche Funktion gesondert ergänzen. |

### Heizungsdetails und Brennstofflager

| Feld | Auswahl / Eingabe |
|---|---|
| Bauart der Heizkörper | **Mehrfachauswahl**: Plattenheizkörper; Gliederheizkörper; Röhrenheizkörper; Bad-/Handtuchheizkörper; Konvektoren; Heizkörper, Typ nicht bekannt |
| Brennstofflager | **Auswahl**: Kein Brennstofflager; Heizöltanks; Flüssiggastank; Pelletlager; Holzlager |
| Anzahl Behälter | **Ganzzahl** |
| Fassungsvermögen je Behälter | **Zahl** in Liter |
| Standort Lager | **Auswahl**: Keller; Technik-/Nebenraum; Oberirdisch im Außenbereich; Unterirdisch |
| Tank-/Anlagenprüfung: Belegstand | **Auswahl**: Keine Prüfung bekannt; Prüfbericht liegt vor; Mangel dokumentiert |
| Schornsteinfegerunterlagen | **Auswahl**: Bericht liegt vor; Angefordert; Liegt nicht vor<br/>Ein vorliegender Bericht ist keine pauschale Bestätigung aller gesetzlichen Anforderungen. |

### Grundstück, Erschließung und Außenanlagen

| Feld | Auswahl / Eingabe |
|---|---|
| Grundstückszuschnitt | **Auswahl**: Regelmäßig; Annähernd rechteckig; Annähernd quadratisch; Unregelmäßig; Hammer-/Hinterliegergrundstück; Lang und schmal; Eckgrundstück |
| Topografie | **Auswahl**: Weitgehend eben; Leichte Hanglage; Starke Hanglage; Terrassiert |
| Straßenfront | **Zahl** in m |
| Grundstückstiefe | **Zahl** in m |
| Zugang / Zufahrt | **Mehrfachauswahl**: Direkt von öffentlicher Straße; Über Privatstraße; Über Wegerecht; Zusätzlicher Zugang; Rechtliche Sicherung nicht bestätigt |
| Straßenbefestigung | **Auswahl**: Asphalt; Pflaster; Schotter / wassergebundene Decke; Unbefestigt |
| Vorhandene Anschlüsse laut Kenntnisstand | **Mehrfachauswahl**: Strom; Gas; Trinkwasser; Öffentliche Abwasserentsorgung; Fern-/Nahwärme; Telefon; Kabel; Glasfaser; Brunnen; Kleinkläranlage / Sammelgrube<br/>Vorhandener Gasanschluss bedeutet nicht Gasheizung. Anschlüsse nach Quelle und Prüfstatus erfassen. |
| Erschließungs-/Beitragsstand | **Auswahl**: Beitragsfrei laut geeigneter Auskunft; Bezahlt laut Eigentümerangabe; Offene Beiträge bekannt; Nicht geprüft |
| Außenanlagen | **Mehrfachauswahl**: Befestigte Wege / Freiflächen; Rasenflächen; Pflanzflächen; Zaun; Einfriedungsmauer; Hecke; Tor; Brunnen; Bewässerungsanlage; Zisterne; Pool; Teich; Einfriedung, Art nicht näher bekannt |
| Ausrichtung Wohnbereich / Hauptaußenfläche | **Mehrfachauswahl**: Nord; Nordost; Ost; Südost; Süd; Südwest; West; Nordwest<br/>Bezug nennen; Wohnbereich und Terrasse können verschiedene Ausrichtungen haben. |
| Art der Teilfläche | **Auswahl**: Baugrundstück; Verkehrs-/Straßenfläche; Garten-/Hinterland; Landwirtschaft; Wald<br/>Bei mehreren Flurstücken als wiederholbare Teilflächen mit eigener Fläche, Quelle und Wertbasis umsetzen; nicht alle Flächen zum Baulandrichtwert rechnen. |
| Umgang mit eingetragenem Recht im Verkauf | **Auswahl**: Bleibt bestehen; Löschung beabsichtigt; Löschung nachgewiesen; Klärung erforderlich<br/>Für jedes Recht gesondert verknüpfen; beabsichtigte Löschung nicht als bereits lastenfrei exportieren. |
| Altlasten: Auskunftsstand | **Auswahl**: Nicht geprüft; Keine Altlasten bekannt; Auskunft ohne Eintrag liegt vor; Verdacht / Hinweis; Belastung fachlich dokumentiert<br/>Keine Altlasten bekannt oder fehlender Registereintrag ist nicht mit uneingeschränkter Schadstofffreiheit gleichzusetzen. |
| Baulastenauskunft | **Auswahl**: Keine Auskunft vorhanden; Angefordert; Auskunft ohne Eintrag liegt vor; Einträge vorhanden<br/>Annahme von Baulastenfreiheit im Gutachten ist kein amtlicher Nachweis. |

## Umsetzung, Konflikte und Migration
1. Alle ursprünglichen 100 Feld-IDs bleiben erhalten: aktive Felder oder separat gespeicherte Altfelder mit Migrationsregel. Alte Glas- und Rahmenwerte nicht löschen. Bei mehrdeutiger Zuordnung neue Fenstergruppen erst nach Bestätigung bilden.
2. Ursprüngliches double_insulating wird zu zwei Scheiben und Isolierglas mit unbekannter Beschichtung. Nicht automatisch „alte unbeschichtete Isolierverglasung“ wählen. Ein altes Wärmeschutzetikett mitsamt ursprünglichem Prüfstatus erhalten; keinen neuen Nachweis erfinden.
3. Kastenfenster ist eine Bauart. Es darf nicht automatisch in eine pauschale Scheibenzahl oder Energiequalität übersetzt werden.
4. Beim Baujahr-Zeitraum muss die Genauigkeit ohne vorherige Einzeljahreseingabe auswählbar sein. Einzeljahr bei aktivem Zeitraum aus der Bewertung ausschließen, Rohwert erhalten.
5. Kelleranteil für Teilkeller liegt strikt zwischen 0 und 100. „Keine Dämmung“ darf nicht zusammen mit vorhandenen Dämmsystemen als widerspruchsfreie Angabe exportiert werden.
6. Nebenanlagenflächen brauchen einen Flächenbegriff. BGF, Nutzfläche, Grundstücksfläche und Wohnfläche nicht miteinander ersetzen. Bei fehlender Definition Flächenbasis unbekannt speichern.
7. Bei Dachneigungsspanne und Jahreszeiträumen Untergrenze <= Obergrenze prüfen. Ungewöhnliche Werte markieren, nicht automatisch korrigieren.
8. Wohnfläche innen, bekannte Gesamtwohnfläche und Terrassenanteil getrennt führen. Außenflächen nicht zweimal addieren. Regelwerkabhängige Anrechnung aus Version 1 beibehalten; WoFlV für Balkon/Loggia/Terrasse/Dachgarten regelmäßig 25 Prozent, höchstens 50 Prozent, Ausnahme-/Ausschlussangaben gesondert dokumentieren.
9. Kein genereller Wertaufschlag pro Fenster, Keller oder Ausstattungsmerkmal. Abbildung auf Modellkomponenten erfolgt erst im passenden Bewertungsmodell.
10. „Keine bekannten Schäden“ bleibt kenntnisbezogen. Feuchtigkeit als sichtbaren Befund und vermutete Abdichtungsursache getrennt erfassen.
11. Betriebszustand Heizung und geplanter Austausch getrennt speichern. In Betrieb und Austausch geplant ist zulässig. Eine Ölheizung ist nicht automatisch ein Brennwertkessel. Ein Gasanschluss bedeutet nicht Gasheizung.
12. Ein Löschungsvorbehalt bedeutet nicht, dass ein Recht schon gelöscht ist. Fehlende Baulastenauskunft bedeutet nicht Baulastenfreiheit. Vorbehalte im Prompt sichtbar erhalten.
13. Der erzeugte Prompt enthält aktive Feldwerte, Originalangaben, Quellen, Prüfstatus, Datum und Bereich. Ausgeblendete widersprechende Altwerte separat im Konfliktprotokoll erhalten.
14. Detailangaben und Summenfelder aufeinander prüfen. Detailgruppen wie „EG zweifach / DG einfach“ dürfen nicht zu „alle Fenster zweifach“ verdichtet werden. Überwiegend bedeutet nicht 100 Prozent.

## Quellen und geprüfter Umfang
R01: Gutachten Wuhletal 15-1(1).pdf, Stichtag 23.03.2026; geprüft insbesondere Seiten 10–20 und 29–30, Baubeschreibung Seite 19 visuell abgeglichen. Das Gutachten belegt die hier aufgeführten historischen Objektangaben und dient als Vollständigkeitsprüfung der Erfassung. Seine rechtlichen Annahmen, Kostenschätzungen und Wertansätze werden nicht als allgemeine Regeln übernommen.

S01: https://www.gesetze-im-internet.de/woflv/__4.html
S02: https://www.gesetze-im-internet.de/geg/anlage_10.html
S03: https://www.verbraucherzentrale.de/wissen/energie/energetische-sanierung/fenster-modernisieren-wann-ist-eine-sanierung-sinnvoll-13878
S04: https://missione.bundesimmobilien.de/informationen-ueber-fenster-0ead57e66f07c3b9 (hier nur Begriffserklärungen verwendet).
S05: https://zukunftskompass-waerme.bayern.de/dachdaemmung (hier nur Bezeichnungen der Dämmlagen verwendet).

Stand 17.11.2026. Geprüft sind der Auswahlkatalog und konkrete Zuordnungen, nicht der Quellcode oder die Bedienung der noch anzupassenden App. Seltene Sonderkonstruktionen können weiterhin über Sonstiges, Originalnotiz und unbekannte Details erfasst werden.
