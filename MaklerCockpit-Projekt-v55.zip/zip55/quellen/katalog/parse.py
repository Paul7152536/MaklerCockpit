import re, json
t = open('/tmp/v43/katalog.md', encoding='utf-8').read()
teil = t.split('## Vollständiger aktueller Feldkatalog')[1].split('## Umsetzung, Konflikte')[0]
gruppen = []
for blk in re.split(r'\n### ', teil)[1:]:
    kopf, *zeilen = blk.strip().split('\n')
    rep = '(mehrere Einträge möglich)' in kopf
    titel = kopf.replace('(mehrere Einträge möglich)', '').strip()
    felder = []
    for z in zeilen:
        if not z.startswith('| ') or z.startswith('| Feld') or z.startswith('|---'): continue
        m = re.match(r'\| (.+?) \| (.+) \|$', z)
        label, rest = m.group(1).strip(), m.group(2)
        teile = rest.split('<br/>')
        tm = re.match(r'\*\*(.+?)\*\*(?::\s*(.*)|\s+in\s+(.*))?$', teile[0].strip())
        if not tm: print('??', z); continue
        typ, opt, einheit = tm.group(1), tm.group(2), tm.group(3)
        hint = [x.strip() for x in teile[1:]]
        bedingt = any('Bedingt anzeigen' in x for x in hint)
        hint = [x for x in hint if 'Bedingt anzeigen' not in x]
        felder.append({'l': label, 't': typ, 'o': [o.strip() for o in opt.split(';')] if opt else None, 'e': einheit, 'h': ' '.join(hint) or None, 'bed': bedingt})
    gruppen.append({'t': titel, 'rep': rep, 'f': felder})
json.dump(gruppen, open('/tmp/v43/roh.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
n = sum(len(g['f']) for g in gruppen); o = sum(len(f['o'] or []) for g in gruppen for f in g['f'])
print(len(gruppen), 'Gruppen', n, 'Felder', o, 'Optionen')
print(sorted(set(f['t'] for g in gruppen for f in g['f'])))
for g in gruppen: print(('R ' if g['rep'] else '  ') + g['t'], len(g['f']))
