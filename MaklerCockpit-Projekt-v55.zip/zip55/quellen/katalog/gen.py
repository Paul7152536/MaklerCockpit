import json, re, unicodedata
G = json.load(open('/tmp/v43/roh.json', encoding='utf-8'))
def slug(s):
    s = s.lower().replace('ä','ae').replace('ö','oe').replace('ü','ue').replace('ß','ss')
    s = re.sub(r'\(.*?\)', '', s); s = re.sub(r'[^a-z0-9]+', '_', s).strip('_')
    return s[:40].rstrip('_')
GID = {'Objekt und Gebäude':'gebaeude','Flächen':'flaechen','Terrassen, Balkone und weitere Außenflächen':'aussenflaechen','Garagen, Stellplätze und Nebengebäude':'nebenanlagen','Ausstattung und Erhaltung':'ausstattung','Modernisierungen':'modernisierungen','Schäden, Mängel und Feuchtigkeit':'schaeden','Heizungsanlagen':'heizungen','Energie und Haustechnik':'energie','Nutzung und Recht':'nutzung','Mietverträge':'mietvertraege','Unterlagen, Quellen und Zusatzangaben':'unterlagen','Fenstergruppen':'fenster','Rollläden, Verschattung und Markisen':'sonnenschutz','Tragwerk, Gründung und Keller':'tragwerk','Geschossdecken':'decken','Dachdeckung und Dämmung':'dach','Treppen und Türen':'treppen_tueren','Raumoberflächen und Ausstattung':'raeume','Bäder und Küche':'baeder_kueche','Badezimmer einzeln':'baeder','Flurstücke / Teilflächen':'flurstuecke','Rechte und Löschungsvorbehalte einzeln':'rechte','Elektroinstallation und weitere Technik':'elektro','Heizungsdetails und Brennstofflager':'heizdetails','Grundstück, Erschließung und Außenanlagen':'grundstueck'}
OFFEN = {'gebaeude','flaechen','ausstattung','heizungen','energie','nutzung'}
NUR_GRUNDSTUECK_SICHTBAR = {'flaechen','nutzung','flurstuecke','rechte','grundstueck','unterlagen'}
ALT = {('gebaeude','Objektart'):'@art',('gebaeude','Gebäudestellung'):'stellung',('gebaeude','Baujahr'):'baujahr',('gebaeude','Vollgeschosse'):'geschosse',('gebaeude','Zimmer'):'zimmer',('gebaeude','Unterkellerung'):'keller',
 ('flaechen','Wohnfläche innen'):'wfl',('flaechen','Wohnfläche berechnet nach'):'wfl_regel',('flaechen','Nutzfläche'):'nfl',('flaechen','Wertrelevante Geschossfläche (wGF)'):'wgf',('flaechen','Brutto-Grundfläche (BGF)'):'bgf',('flaechen','Grundstücksfläche'):'grund',
 ('ausstattung','Tatsächlicher Ausstattungsstandard'):'standard',('ausstattung','Erhaltungszustand'):'zustand',
 ('energie','Energieausweisart'):'ea_art',('energie','Endenergiekennwert'):'ea_kw',('energie','Energieeffizienzklasse laut Ausweis'):'ea_klasse',
 ('nutzung','Aktuelle Nutzung'):'nutzung',('nutzung','Ist-Nettokaltmiete insgesamt pro Monat'):'miete_ist',('nutzung','Denkmalschutz'):'denkmal',
 ('grundstueck','Erschließungs-/Beitragsstand'):'beitrag',
 ('unterlagen','Vorliegende Unterlagen'):'@unterlagen',('unterlagen','Weitere Angaben'):'@notiz',
 ('grundstueck','Art der Teilfläche'):'@verweis:flurstuecke',('grundstueck','Umgang mit eingetragenem Recht im Verkauf'):'@verweis:rechte'}
KERN = {'gebaeude':['Gebäudestellung','Baujahr','Genauigkeit Baujahr','Baujahr-Zeitraum','Tragende Bauweise','Vollgeschosse','Zimmer','Wohneinheiten','Unterkellerung','Unterkellerter Anteil','Dachform','Dachausbau'],
 'flaechen':['Wohnfläche innen','Wohnfläche berechnet nach','Nutzfläche','Grundstücksfläche'],
 'ausstattung':['Tatsächlicher Ausstattungsstandard','Erhaltungszustand'],
 'energie':['Energieausweis: Unterlagenstand','Energieausweisart','Endenergiekennwert','Art des eingetragenen Kennwerts','Energieeffizienzklasse laut Ausweis','Photovoltaik','PV-Leistung','PV-Eigentum / Vertragsbindung'],
 'nutzung':['Aktuelle Nutzung','Verfügbarkeit','Verfügbar ab','Ist-Nettokaltmiete insgesamt pro Monat','Rechtsform','Bekannte Rechte / Beschränkungen','Denkmalschutz']}
GEWICHT = {('gebaeude','Baujahr'):'hoch',('gebaeude','Tragende Bauweise'):'hoch',('flaechen','Wohnfläche innen'):'stop',('flaechen','Grundstücksfläche'):'stop',('flaechen','Wohnfläche berechnet nach'):'hoch',('ausstattung','Tatsächlicher Ausstattungsstandard'):'hoch',('ausstattung','Erhaltungszustand'):'hoch',('nutzung','Aktuelle Nutzung'):'stop'}
# Bedingungen: (gruppe, label) -> {f: label im selben Bereich, in/nicht/gesetzt}
BED = {('gebaeude','Baujahr'):{'f':'Genauigkeit Baujahr','nicht':['Nur Zeitraum bekannt']},
 ('gebaeude','Baujahr-Zeitraum'):{'f':'Genauigkeit Baujahr','in':['Nur Zeitraum bekannt']},
 ('gebaeude','Unterkellerter Anteil'):{'f':'Unterkellerung','in':['Teilunterkellert']},
 ('gebaeude','Kellernutzung'):{'f':'Unterkellerung','in':['Teilunterkellert','Vollunterkellert']},
 ('gebaeude','Weiteres Dachausbaupotenzial'):{'f':'Dachausbau','in':['Nicht ausgebaut','Teilweise ausgebaut']},
 ('aussenflaechen','Dokumentierter Anrechnungsanteil'):{'f':'Wohnflächenanrechnung','in':['Anderer dokumentierter Anteil']},
 ('heizungen','Wärmepumpenart'):{'f':'Technik der Wärmeerzeugung','in':['Wärmepumpe']},
 ('energie','PV-Leistung'):{'f':'Photovoltaik','in':['Vorhanden','Geplant']},
 ('energie','PV-Eigentum / Vertragsbindung'):{'f':'Photovoltaik','in':['Vorhanden']},
 ('energie','Speicherkapazität'):{'f':'Batteriespeicher','in':['Vorhanden','Geplant']},
 ('energie','Ladeleistung'):{'f':'Wallbox / Ladepunkt','in':['Vorhanden','Geplant']},
 ('nutzung','Verfügbar ab'):{'f':'Verfügbarkeit','in':['Frei ab Datum']},
 ('nutzung','Betroffene Bauteile / Nutzungen'):{'f':'Genehmigungs-/Prüfstand aktueller Nutzung','in':['Abweichung zwischen Unterlagen und Bestand festgestellt','Nachgenehmigung beantragt','Nicht genehmigte Änderung dokumentiert']},
 ('mietvertraege','Vertragsende laut Vertrag'):{'f':'Vertragslaufzeit','in':['Befristet']},
 ('fenster','Bezugsbasis des Anteils'):{'f':'Anteil am Fensterbestand','gesetzt':True},
 ('sonnenschutz','Bedienung / Antrieb'):{'f':'Sonnenschutzart','gesetzt':True,'nicht':['Kein Sonnenschutz','Unbekannt']},
 ('sonnenschutz','Steuerung'):{'f':'Bedienung / Antrieb','in':['Elektrisch','Solarbetrieben']},
 ('sonnenschutz','Abdeckung'):{'f':'Sonnenschutzart','gesetzt':True,'nicht':['Kein Sonnenschutz']},
 ('treppen_tueren','Türzarge / Rahmen'):{'f':'Bauteil','in':['Haustür','Innentür','Wohnungseingangstür']}}
GESCHLOSSEN = set('''Genauigkeit Baujahr|Unterkellerung|Dachausbau|Weiteres Dachausbaupotenzial|Außenflächen in angegebener Wohnfläche|Wohnflächenanrechnung|Überdachung|Zustand Anlage|Anordnung der Anlage|Flächenbegriff der Anlage|Tatsächlicher Ausstattungsstandard|Erhaltungszustand|Umfang der Maßnahme|Nachweis vorhanden|Stand des Befunds|Handlungsbedarf|Rolle der Anlage|Betriebszustand laut Kenntnisstand|Geplanter Austausch|Energieausweis: Unterlagenstand|Energieausweisart|Energieeffizienzklasse laut Ausweis|Photovoltaik|PV-Eigentum / Vertragsbindung|Batteriespeicher|Wallbox / Ladepunkt|Solarthermie|Art des eingetragenen Kennwerts|Verfügbarkeit|Rechtsform|Denkmalschutz|Genehmigungs-/Prüfstand aktueller Nutzung|Vertragslaufzeit|Mietstruktur / vereinbarte Anpassung|Verglasung: Scheibenanzahl|Bezugsbasis des Anteils|Abdeckung|Kellerabdichtung: Kenntnisstand|Spitzboden|Einliegerwohnung|Decke über|Dachdämmung: Kenntnisstand|Dämmung oberste Geschossdecke|Wandfliesen: Umfang|Sanitärausstattung: Qualität|Einbauküche|Wandbelag / Fliesenhöhe|Zustand|Stand im Verkauf|Elektroausstattung laut Beschreibung|Erneuerungsstand|FI-/RCD-Schutz laut Kenntnisstand|Elektrische Prüfung|Tank-/Anlagenprüfung: Belegstand|Schornsteinfegerunterlagen|Topografie|Erschließungs-/Beitragsstand|Ausrichtung Wohnbereich / Hauptaußenfläche|Altlasten: Auskunftsstand|Baulastenauskunft|Leitungsmaterial laut Nachweis|Bedienung / Antrieb|Küchenausführung|Glasart / thermische Ausführung'''.split('|'))
TYP = {'Auswahl':'sel','Mehrfachauswahl':'multi','Zahl':'zahl','Ganzzahl':'int','Jahr':'jahr','Datum':'datum','Text':'text','Freitext':'lang','Zeitraum':'zeitraum'}
aus, alle_ids = [], set()
for g in G:
    gid = GID[g['t']]; felder = []; ids = {}
    for f in g['f']:
        k = ALT.get((gid, f['l']))
        if not k:
            k = slug(f['l']) if g['rep'] else 'k_' + slug(f['l'])
        assert k not in ids.values(), (gid, k)
        if not g['rep'] and not k.startswith('@'):
            assert k not in alle_ids, k; alle_ids.add(k)
        ids[f['l']] = k
    for f in g['f']:
        d = {'k': ids[f['l']], 'l': f['l'], 't': TYP[f['t']]}
        if f['o']: d['o'] = f['o']
        if f['e']: d['e'] = f['e']
        if f['h']: d['h'] = f['h']
        if f['t'] in ('Auswahl','Mehrfachauswahl') and f['l'] not in GESCHLOSSEN: d['sonst'] = 1
        b = BED.get((gid, f['l']))
        if f['bed'] and not b: raise SystemExit('Bedingung fehlt: %s / %s' % (gid, f['l']))
        if b:
            b = dict(b); b['f'] = ids[b['f']]; d['wenn'] = b
        if not g['rep'] and gid in KERN and f['l'] not in KERN[gid]: d['detail'] = 1
        if (gid, f['l']) in GEWICHT: d['w'] = GEWICHT[(gid, f['l'])]
        if gid == 'flaechen' and f['l'] != 'Grundstücksfläche': d['bau'] = 1
        felder.append(d)
    aus.append({'id': gid, 't': g['t'], 'rep': 1 if g['rep'] else 0, 'offen': 1 if gid in OFFEN else 0, 'haus': 0 if gid in NUR_GRUNDSTUECK_SICHTBAR else 1, 'f': felder})
REIHE = ['gebaeude','flaechen','aussenflaechen','nebenanlagen','ausstattung','modernisierungen','schaeden','heizungen','energie','nutzung','mietvertraege','fenster','sonnenschutz','tragwerk','decken','dach','treppen_tueren','raeume','baeder_kueche','baeder','elektro','heizdetails','grundstueck','flurstuecke','rechte','unterlagen']
aus.sort(key=lambda g: REIHE.index(g['id']))
js = '// MaklerCockpit v43 – Auswahlkatalog 2.0 (Stand 17.11.2026, abgeglichen mit Gutachten Wuhletal 15). Automatisch aus der Katalogdatei erzeugt.\nconst GA43_KAT = ' + json.dumps(aus, ensure_ascii=False, separators=(',', ':')) + ';\n'
open('/tmp/jvb/katalog43.js', 'w', encoding='utf-8').write(js)
print(len(aus), sum(len(g['f']) for g in aus), sum(len(f.get('o', [])) for g in aus for f in g['f']), len(js))
