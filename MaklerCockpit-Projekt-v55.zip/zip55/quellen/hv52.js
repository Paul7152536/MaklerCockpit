// ═══ MaklerCockpit v52 – Anschreiben an Hausverwaltungen mit Bild-Anhang ═══
// Wird aus dem Hausverwaltungs-Modul aufgerufen, wenn in der Vorlage ein Bild hinterlegt ist.
// PC: Outlook-Entwurf mit Anhang (klassisches Outlook) bzw. Entwurfsdatei fürs Standard-Mailprogramm.
// Handy: Outlook-App (sonst Auswahl) mit Empfänger, Betreff, Text und Bild. Gesendet wird nie automatisch.
async function hv52Senden(m){
  const toast = (t, ms) => { try{ akqToast(t, ms || 4500); }catch(e){} };
  const mailto = () => { try{ window.open(m.mailto, '_blank'); }catch(e){} };
  try{
    if(window.pc && typeof window.pc.mailEntwurf === 'function'){
      toast('✉️ Mail wird vorbereitet …', 2500);
      const r = await window.pc.mailEntwurf({ an: m.an, betreff: m.betreff, text: m.text, bild: m.bild && m.bild.b64 ? { name: m.bild.name, b64: m.bild.b64 } : null });
      if(r && r.ok){
        toast(r.weg === 'outlook' ? '✉️ Outlook-Entwurf mit Bild ist offen – nur noch prüfen und Senden.'
          : r.weg === 'eml' ? '✉️ Entwurf mit Bild im Mailprogramm geöffnet – prüfen und Senden.'
          : '✉️ Mail-App mit Bild geöffnet – prüfen und Senden.', 6000);
        return r;
      }
      toast('Bild-Anhang ging nicht (' + ((r && r.fehler) || 'unbekannt') + ') – Mail ohne Bild geöffnet, Bild bitte von Hand anhängen.', 7000);
    }
  }catch(e){ console.error('hv52', e); }
  mailto();
  return { ok: true, weg: 'mailto' };
}
