// ═══ MaklerCockpit v33 – PDF-Werkzeuge (Pauls „Alles-in-einem-Tool“) statt „Bilder zu PDF“ ═══
// Läuft in einem eigenen Rahmen über dem Hauptbereich und bleibt geladen, wenn du zwischendurch andere Seiten öffnest.
// Außerdem: pdf.js im ganzen Cockpit ohne eval (Schutz vor präparierten PDFs, CVE-2024-4367).
(function(){
  try{
    if(!window.pdfjsLib || window.pdfjsLib.__mc33) return;
    const alt = window.pdfjsLib, neu = { __mc33: true };
    for(const k of Object.keys(alt)) neu[k] = alt[k];
    neu.getDocument = function(src){
      let s = src;
      if(typeof s === 'string') s = { url: s };
      else if(s instanceof ArrayBuffer || ArrayBuffer.isView(s)) s = { data: s };
      else s = Object.assign({}, s);
      s.isEvalSupported = false;
      return alt.getDocument(s);
    };
    window.pdfjsLib = neu;
  }catch(e){ console.error('pdf33 pdf.js', e); }
})();
(function(){ try{ const e = NAV.find(x => x.key === 'pdfs'); if(e){ e.label = 'PDF-Werkzeuge'; e.icon = '📄'; } }catch(e){} })();
const PDF33 = { el: null };
function pdf33Lage(){
  const d = PDF33.el, m = document.getElementById('main'); if(!d || !m || d.style.display === 'none') return;
  const r = m.getBoundingClientRect();
  const tabs = document.getElementById('h25Tabs'); const tr = tabs && getComputedStyle(tabs).display !== 'none' ? tabs.getBoundingClientRect() : null; const unten = tr && tr.height > 0 && tr.top > r.top ? tr.top : innerHeight;
  d.style.left = Math.round(r.left) + 'px'; d.style.top = Math.round(r.top) + 'px'; d.style.width = Math.round(r.width) + 'px';
  d.style.height = Math.max(200, Math.round(unten - r.top)) + 'px';
}
function pdf33Zeigen(){
  if(!PDF33.el){
    const d = document.createElement('div'); d.id = 'pdf33'; d.className = 'pdf33';
    const f = document.createElement('iframe'); f.id = 'pdf33Frame'; f.title = 'PDF-Werkzeuge';
    f.setAttribute('allow', 'clipboard-write');
    f.srcdoc = window.PDF33_HTML || '<p style="color:#fff;font-family:sans-serif">PDF-Werkzeuge fehlen.</p>';
    d.appendChild(f); document.body.appendChild(d); PDF33.el = d;
  }
  PDF33.el.style.display = 'block'; pdf33Lage();
}
function pdf33Verstecken(){ if(PDF33.el) PDF33.el.style.display = 'none'; }
const _pdf33Render = renderMain;
renderMain = function(){
  if(aktuelleAnsicht === 'pdfs'){
    const main = document.getElementById('main');
    if(main) main.innerHTML = '<div id="pdf33Platz" style="min-height:calc(100vh - 120px)"></div>';
    pdf33Zeigen(); return;
  }
  pdf33Verstecken();
  return _pdf33Render.apply(this, arguments);
};
window.addEventListener('resize', () => { try{ pdf33Lage(); }catch(e){} });
