// ═══ MaklerCockpit v25 – Brücke für die Handy-App (Android) ═══
// Läuft nur in der App: dort stellt Android das Objekt „MCAndroid“ bereit; daraus wird window.pc wie am PC.
(function(){
  if(!window.MCAndroid || window.pc) return;
  const A = window.MCAndroid;
  const offen = {}; let nr = 0;
  window.__mcAntwort = function(id, json){ const f = offen[id]; if(!f) return; delete offen[id]; let d = null; try{ d = JSON.parse(json); }catch(e){ d = { ok: false, fehler: 'Ungültige Antwort' }; } f(d); };
  const asyncRuf = (name, ...args) => new Promise(res => { const id = 'r' + (++nr); offen[id] = res; try{ A[name](id, ...args.map(a => typeof a === 'string' ? a : JSON.stringify(a == null ? null : a))); }catch(e){ delete offen[id]; res({ ok: false, fehler: String(e.message || e) }); } });
  const sync = (name, ...args) => { try{ return JSON.parse(A[name](...args)); }catch(e){ return null; } };
  const nurPC = text => async () => ({ ok: false, fehler: text });
  window.pc = {
    geraet: 'handy',
    laden: () => sync('laden'),
    speichern: t => sync('speichern', t),
    importieren: t => sync('importieren', t),
    sicherungSchreiben: (n, t) => sync('sicherungSchreiben', n, t),
    sicherungLesen: n => { try{ return A.sicherungLesen(n); }catch(e){ return null; } },
    sicherungExtern: (t, art) => { try{ return typeof A.sicherungExtern === 'function' ? JSON.parse(A.sicherungExtern(t, art || 'manuell')) : { ok: false, fehler: 'Erst ab App-Version 18' }; }catch(e){ return { ok: false, fehler: String(e.message || e) }; } },
    abgleichStand: (a, t) => { try{ if(a === 'lesen') return A.standLesen(); if(a === 'schreiben') return JSON.parse(A.standSchreiben(t)); if(a === 'loeschen') return JSON.parse(A.standLoeschen()); }catch(e){} return null; },
    google: (aktion, arg) => asyncRuf('google', aktion, arg || {}),
    koppeln: code => asyncRuf('koppeln', code),
    gekoppelt: () => { try{ return A.gekoppelt() === 'true'; }catch(e){ return false; } },
    entkoppeln: () => { try{ A.entkoppeln(); }catch(e){} },
    abruf: url => asyncRuf('abruf', url),
    seite: url => asyncRuf('seite', url),
    feed: url => asyncRuf('seite', url),
    zwischenablage: async () => { try{ return A.zwischenablage(); }catch(e){ return ''; } },
    dateiSpeichern: (name, base64) => asyncRuf('dateiSpeichern', name, base64),
    dateiOeffnen: (pfad) => { try{ A.dateiOeffnen(pfad); }catch(e){} },
    htmlZuPdf: async () => ({ ok: false, druck: true, fehler: 'Am Handy über „Drucken → Als PDF speichern“' }),
    drucken: (html, titel) => { try{ A.drucken(String(html || ''), String(titel || 'MaklerCockpit')); return { ok: true }; }catch(e){ return { ok: false, fehler: String(e.message || e) }; } },
    teilen: (text, titel) => { try{ A.teilen(String(text || ''), String(titel || '')); }catch(e){} },
    mailEntwurf: arg => typeof A.mailMitBild === 'function' ? asyncRuf('mailMitBild', arg || {}) : Promise.resolve({ ok: false, fehler: 'Bild-Anhang erst ab Handy-App v28' }),
    oeffnen: url => { try{ A.oeffnen(String(url || '')); }catch(e){} },
    sperre: an => { try{ return A.sperre(an == null ? '' : (an ? '1' : '0')) === 'true'; }catch(e){ return false; } },
    claude: nurPC('Die KI-Schnittstelle gibt es nur am PC.'),
    dok: async () => ({ ok: false, fehler: 'Unterlagen-Dateien (PDFs, Fotos) liegen auf dem PC.' }),
    webfenster: async () => ({ ok: false, fehler: 'Das Kleinanzeigen-Fenster gibt es nur am PC – am Handy die Kleinanzeigen-App nutzen.' }),
    onWebfenster: () => {},
    ordner: () => {}, fokus: () => {}, autostart: async () => false
  };
  // Links zu Telefon, WhatsApp, E-Mail und Webseiten an Android übergeben
  const _open = window.open;
  window.open = function(url){ if(url && /^(https?:|tel:|mailto:|sms:|whatsapp:|geo:|intent:)/i.test(String(url))){ window.pc.oeffnen(String(url)); return null; } return _open ? _open.apply(window, arguments) : null; };
  document.addEventListener('click', e => {
    const a = e.target.closest && e.target.closest('a[href]'); if(!a) return;
    const h = a.getAttribute('href') || '';
    if(/^(tel:|mailto:|sms:|whatsapp:|geo:)/i.test(h) || (/^https?:/i.test(h) && (a.target === '_blank' || !h.startsWith(location.origin)))){ e.preventDefault(); window.pc.oeffnen(a.href); }
  }, true);
})();
