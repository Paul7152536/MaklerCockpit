// ═══ MaklerCockpit v25 – Handy-Ansicht (auch für schmale PC-Fenster) ═══
// Unten eine Leiste mit den wichtigsten Seiten, die Seitenleiste als Schublade, Lead-Details bildschirmfüllend, Zurück-Taste.
function h25Mobil(){ try{ return window.matchMedia('(max-width: 760px)').matches; }catch(e){ return false; } }
function h25Tabs(){
  const heute = typeof ak24An === 'function' && ak24An();
  return [heute ? ['heute', 'Heute'] : ['dashboard', 'Start'], ['akquise', 'Akquise'], ['termine', 'Termine'], ['kontakte', 'Kontakte'], ['mehr', 'Mehr']];
}
function h25TabsRendern(){
  let el = document.getElementById('h25Tabs');
  if(!el){ el = document.createElement('div'); el.id = 'h25Tabs'; document.body.appendChild(el); }
  const ic = k => (typeof IC !== 'undefined' && (IC[k] || (k === 'mehr' ? IC.menue || IC.mehr : null))) || '';
  el.innerHTML = h25Tabs().map(([k, l]) => `<button class="${aktuelleAnsicht === k || (k === 'mehr' && document.body.classList.contains('h25-nav-offen')) ? 'aktiv' : ''}" onclick="${k === 'mehr' ? 'h25Schublade()' : `h25Gehe('${k}')`}">${ic(k) || '☰'}<span>${l}</span></button>`).join('');
}
function h25Gehe(k){ document.body.classList.remove('h25-nav-offen', 'h25-detail'); wechsleAnsicht(k); }
function h25Schublade(an){
  const offen = an == null ? !document.body.classList.contains('h25-nav-offen') : !!an;
  document.body.classList.toggle('h25-nav-offen', offen); h25TabsRendern();
}
function h25Aufbauen(){
  document.body.classList.toggle('h25-app', !!(window.pc && window.pc.geraet === 'handy'));
  const tb = document.getElementById('topbar');
  if(tb && !document.getElementById('h25Menue')){
    const b = document.createElement('button'); b.id = 'h25Menue'; b.className = 'tb-icon h25-nur'; b.title = 'Menü'; b.textContent = '☰'; b.onclick = (e) => { e.stopPropagation(); h25Schublade(); };
    tb.insertBefore(b, tb.firstChild);
  }
  if(!document.getElementById('h25Abdeckung')){
    const d = document.createElement('div'); d.id = 'h25Abdeckung'; d.onclick = () => h25Schublade(false); document.body.appendChild(d);
  }
  h25TabsRendern();
}
const _h25RenderNav = renderNav;
renderNav = function(){ const r = _h25RenderNav.apply(this, arguments); try{ h25TabsRendern(); }catch(e){} return r; };
const _h25Wechsle = wechsleAnsicht;
wechsleAnsicht = function(){ document.body.classList.remove('h25-nav-offen', 'h25-detail'); const r = _h25Wechsle.apply(this, arguments); try{ h25TabsRendern(); window.scrollTo(0, 0); const m = document.getElementById('main'); if(m) m.scrollTop = 0; }catch(e){} return r; };
// Lead-Details auf dem Handy bildschirmfüllend, mit „Zurück“
if(typeof aq2Detail === 'function'){
  const _h25Detail = aq2Detail;
  aq2Detail = function(){
    const r = _h25Detail.apply(this, arguments);
    try{
      const kopf = document.querySelector('#aqDetail .dp-kopf');
      if(kopf && !kopf.querySelector('.h25-zurueck')) kopf.insertAdjacentHTML('afterbegin', `<button class="tb-icon h25-nur h25-zurueck" title="Zurück zur Liste" onclick="h25DetailZu()">←</button>`);
      if(h25Mobil() && typeof AQ2 !== 'undefined' && AQ2.sel && findObjekt(AQ2.sel) && AQ2.h25Offen) document.body.classList.add('h25-detail');
    }catch(e){}
    return r;
  };
}
function h25DetailZu(){ document.body.classList.remove('h25-detail'); if(typeof AQ2 !== 'undefined') AQ2.h25Offen = false; }
// Tippen auf einen Lead in der Liste öffnet die Details
document.addEventListener('click', e => {
  try{
    if(!h25Mobil()) return;
    const zeile = e.target.closest('#aqListe [onclick]');
    if(zeile && !e.target.closest('button, a, input, select') && typeof AQ2 !== 'undefined'){ AQ2.h25Offen = true; setTimeout(() => { if(AQ2.sel) document.body.classList.add('h25-detail'); }, 30); }
  }catch(err){}
}, true);
// Zurück-Taste (Android ruft h25Zurueck auf): erst Dialoge, dann Schublade/Details, dann Startseite
window.h25Zurueck = function(){
  try{
    const m = document.getElementById('modalBg'); if(m && m.classList.contains('show')){ schliesseModal(); return true; }
    if(document.getElementById('tbMenue')){ tbMenueZu(); return true; }
    if(document.body.classList.contains('h25-nav-offen')){ h25Schublade(false); return true; }
    if(document.body.classList.contains('h25-detail')){ h25DetailZu(); return true; }
    if(aktuelleAnsicht === 'akte'){ wechsleAnsicht(MC24.zurueck || 'objekte'); return true; }
    const start = h25Tabs()[0][0];
    if(aktuelleAnsicht !== start){ wechsleAnsicht(start); return true; }
  }catch(e){}
  return false;
};
window.addEventListener('load', () => { try{ h25Aufbauen(); }catch(e){ console.error('h25', e); } });
window.addEventListener('resize', () => { if(!h25Mobil()) document.body.classList.remove('h25-nav-offen', 'h25-detail'); });
// In der Handy-App: PDFs (Eigentümerbericht, Briefing) über den Android-Druckdialog („Als PDF speichern“ oder Drucker)
if(window.pc && window.pc.geraet === 'handy' && typeof window.pc.drucken === 'function'){
  mc24Pdf = async function(html, name){ akqToast('📄 Druckansicht – dort „Als PDF speichern“ wählen'); return window.pc.drucken(html, name || 'MaklerCockpit'); };
  mc24Drucken = function(html){ window.pc.drucken(html, 'MaklerCockpit'); };
}
