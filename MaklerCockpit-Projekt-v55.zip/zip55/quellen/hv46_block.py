# v46: Hausverwaltungen – E-Mail-Adresse + Knopf „Anschreiben in Outlook öffnen“ (mailto: Empfänger, Betreff, fertiger Text)
# wird von akq_patch.py per exec() ausgeführt; bearbeitet HV_HTML in s
import json as _j46
_a = s.index('const HV_HTML = '); _b = s.index('\n', _a)
_hv = _j46.loads(s[_a + len('const HV_HTML = '):_b].rstrip(';'))
def hv46(a, b):
    global _hv
    assert _hv.count(a) == 1, ('hv46', a[:80], _hv.count(a)); _hv = _hv.replace(a, b)

# 1) E-Mail-Feld in den Stammdaten + leseForm
hv46("""        <div><label>Telefonnummer</label><input id="h_tel" value="${esc(v.telefon)}" placeholder="z.B. 030 123456 (Zentrale)"></div>
      </div>""", """        <div><label>Telefonnummer</label><input id="h_tel" value="${esc(v.telefon)}" placeholder="z.B. 030 123456 (Zentrale)"></div>
      </div>
      <label>E-Mail</label><input id="h_mail" type="email" value="${esc(v.email||'')}" placeholder="z. B. vermietung@verwaltung.de">""")
hv46("""    begruendung:val('h_begr').trim(), quelle:val('h_quelle').trim(), bezirk:val('h_bez'), status:val('h_status'),""",
     """    begruendung:val('h_begr').trim(), quelle:val('h_quelle').trim(), bezirk:val('h_bez'), status:val('h_status'), email:(val('h_mail')||val('h_mail_schnell')).trim(),""")

# 2) Mail-Zeile oben im Dialog (nach Ansprechpartner)
hv46("""'<div style="font-size:12px;color:var(--muted);margin:6px 0;">👤 Kein Ansprechpartner öffentlich angegeben</div>'}`:''}""",
     """'<div style="font-size:12px;color:var(--muted);margin:6px 0;">👤 Kein Ansprechpartner öffentlich angegeben</div>'}
    <div class="hv46-mail">${v.email ? `<span class="hv46-an">✉️ ${esc(v.email)}</span>` : `<input id="h_mail_schnell" type="email" placeholder="E-Mail-Adresse eintragen" oninput="const m=document.getElementById('h_mail');if(m)m.value=this.value">`}
      <button onclick="hv46Mail('${id}')">✉️ Anschreiben in Outlook öffnen</button>
      <a href="#" onclick="hv46Vorlage('${id}');return false;">Vorlage bearbeiten</a>${v.mailAm ? `<span class="hv46-zuletzt">zuletzt geöffnet ${fmtDatum(v.mailAm)}</span>` : ''}</div>`:''}""")

# 3) Funktionen + Stil
hv46("""function setzeStatusChip(s){""", r"""const HV46_STANDARD = "Betreff: Vermietung – wie telefonisch besprochen\n\n{anrede}\n\nvielen Dank für das freundliche Telefonat{wann}. Wie besprochen schicke ich Ihnen meine Unterlagen zur Vermietung:\n- Komplette Vermietung: Fotos und Exposé, Inserate auf allen Portalen, Besichtigungen, Bonitätsprüfung, Vorbereitung des Mietvertrags\n- Sie entscheiden über die Mieter\n- Kosten: 1,79 Nettokaltmieten inkl. MwSt., nur bei erfolgreicher Vermietung\n\nGern übernehme ich zum Kennenlernen eine Ihrer freien Wohnungen. Ich melde mich wie besprochen – oder Sie rufen mich einfach an.\n\nViele Grüße\nPaul Görner\nBETTERHOMES · Görner Immobilien";
function hv46Mailtext(v){
  const roh = String(db.mailVorlage || HV46_STANDARD);
  const anr = hatAnsprech(v) ? 'Guten Tag ' + v.ansprechpartner.trim() + ',' : 'Sehr geehrte Damen und Herren,';
  let wann = '';
  if(v.letzterAnruf){ const d = new Date(v.letzterAnruf), h = new Date(); const tage = Math.round((new Date(h.toDateString()) - new Date(d.toDateString())) / 864e5); wann = tage === 0 ? ' heute' : tage === 1 ? ' gestern' : ' am ' + d.toLocaleDateString('de-DE', { day: '2-digit', month: '2-digit' }).replace(/\.$/, ''); }
  const t = roh.replace(/\{anrede\}/g, anr).replace(/\{ansprechpartner\}/g, hatAnsprech(v) ? v.ansprechpartner.trim() : '').replace(/\{firma\}/g, v.name || '').replace(/\{wann\}/g, wann).replace(/\{datum\}/g, new Date().toLocaleDateString('de-DE')).replace(/[ \t]+([,.])/g, '$1');
  const m = t.match(/^\s*Betreff:\s*(.+)\n+/i);
  return { betreff: m ? m[1].trim() : 'Vermietung', text: m ? t.slice(m[0].length) : t };
}
function hv46Mail(id){
  const v = db.verwaltungen.find(x => x.id === id); if(!v) return;
  const daten = leseForm(); if(!daten.name) daten.name = v.name;
  const mail = String(daten.email || v.email || '').trim();
  if(!/^[^\s@<>"',;]+@[^\s@<>"',;]+\.[a-z]{2,}$/i.test(mail)){ const f = document.getElementById('h_mail_schnell') || document.getElementById('h_mail'); if(f){ f.focus(); f.style.borderColor = 'var(--red)'; } alert('Bitte zuerst eine gültige E-Mail-Adresse eintragen.'); return; }
  daten.email = mail; schreibeHV(id, daten);
  const m = hv46Mailtext(v);
  v.mailAm = Date.now();
  const zeile = '✉️ Anschreiben per Mail geöffnet (' + new Date().toLocaleDateString('de-DE') + ')';
  if(!String(v.notizen || '').includes(zeile)) v.notizen = (v.notizen ? v.notizen.replace(/\s+$/, '') + '\n' : '') + zeile;
  save();
  const url = 'mailto:' + encodeURIComponent(mail).replace(/%40/g, '@') + '?subject=' + encodeURIComponent(m.betreff) + '&body=' + encodeURIComponent(m.text.replace(/\r?\n/g, '\r\n'));
  try{ (window.parent && window.parent !== window ? window.parent : window).open(url, '_blank'); }catch(e){ location.href = url; }
  oeffneHVModal(id);
}
function hv46Vorlage(id){
  if(id){ try{ schreibeHV(id, Object.assign(leseForm(), { name: val('h_name').trim() || (db.verwaltungen.find(x => x.id === id) || {}).name })); save(); }catch(e){} }
  zeigeModal(`<h3>✉️ Anschreiben-Vorlage für Hausverwaltungen</h3>
    <div style="font-size:12px;color:var(--muted);margin-bottom:8px;">Erste Zeile „Betreff: …“ wird der Betreff. Platzhalter: <b>{anrede}</b> (Guten Tag Frau … / Sehr geehrte Damen und Herren), <b>{wann}</b> (heute / gestern / am 18.11.), <b>{firma}</b>, <b>{ansprechpartner}</b>, <b>{datum}</b>.</div>
    <textarea id="hv46Text" style="min-height:300px;width:100%;">${esc(db.mailVorlage || HV46_STANDARD)}</textarea>
    <div class="modal-actions"><button class="secondary" onclick="document.getElementById('hv46Text').value=HV46_STANDARD">Standard wiederherstellen</button>
      <div class="right"><button class="secondary" onclick="${id ? `oeffneHVModal('${id}')` : 'schliesseModal()'}">Abbrechen</button><button onclick="db.mailVorlage=document.getElementById('hv46Text').value;save();${id ? `oeffneHVModal('${id}')` : 'schliesseModal()'}">Speichern</button></div></div>`);
}
function setzeStatusChip(s){""")
_k = _hv.index('</head>')
_hv = _hv[:_k] + """<style>.hv46-mail{display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin:8px 0 10px;padding:8px 10px;border:1px solid var(--border);border-radius:10px;background:var(--bg2)}
.hv46-mail input{flex:1;min-width:200px;margin:0}.hv46-mail button{white-space:nowrap}.hv46-an{font-size:13px;font-weight:600}
.hv46-mail a{font-size:12px;color:var(--muted)}.hv46-zuletzt{font-size:11px;color:var(--green)}</style>""" + _hv[_k:]
s = s[:_a] + 'const HV_HTML = ' + _j46.dumps(_hv, ensure_ascii=False).replace('</', '<\\/') + ';' + s[_b:]
