# ── v39: Jarvis liest „typ=kaufvergleiche“ (Vergleichsfälle für die Große Analyse) ein ──
_JV39 = r"""
try{ TYP_ALIAS.kaufvergleiche="kaufvergleiche"; TYP_ALIAS.vergleichsfaelle="kaufvergleiche"; TITEL.kaufvergleiche="Vergleichsfälle (Große Analyse)"; ICON.kaufvergleiche="🔬"; }catch(e){ console.error("v39 jarvis", e); }
if(typeof einlesen==="function"){ var ei39=einlesen; einlesen=function(text){
  var z; try{ z=zerlegen(text); }catch(e){ return ei39.apply(this,arguments); }
  if(z[0]!=="kaufvergleiche") return ei39.apply(this,arguments);
  var P=null; try{ P=(window.parent!==window && window.parent.ga39ImportListe) ? window.parent : null; }catch(e){}
  if(!P) return "⚠️ Vergleichsfälle lassen sich nur im MaklerCockpit einlesen.";
  if(!z[1].length) return "📥 Kein lesbarer Eintrag gefunden. Bitte den ganzen Block von JARVIS-IMPORT bis JARVIS-ENDE kopieren.";
  var b; try{ b=P.ga39ImportListe(z[1]); }catch(e){ return "⚠️ Beim Einlesen ist etwas schiefgegangen: "+e.message; }
  b+=" (in der zuletzt gewählten Großen Analyse)";
  S.letzteImporte=[{zeit:new Date().toISOString(),typ:"kaufvergleiche",bericht:b}].concat(S.letzteImporte||[]).slice(0,15); speichern();
  return b;
}; }
"""
a = s.index('const JV_HTML = '); b = s.index('\n', a)
html = json.loads(s[a+len('const JV_HTML = '):b].rstrip(';'))
k = html.rindex('</body>')
html = html[:k] + '<script>/* v39 Kaufvergleiche */\n' + _JV39 + '\n</script>\n' + html[k:]
s = s[:a] + 'const JV_HTML = ' + json.dumps(html, ensure_ascii=False).replace('</', '<\\/') + ';' + s[b:]
