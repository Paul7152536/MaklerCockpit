// ═══ MaklerCockpit v45 – Objektakte: Inserat-Link im Kopf, eigene Notizen im Verlauf farbig ═══
// Pauls Wunsch (17.11.2026): Im Kopf der Objektakte direkt der Link zum Inserat; ohne Link „📰 Aus Zeitung“.
// In „Kerndaten und Herkunft“ wird „aus den Objektdaten“ entsprechend zu „aus dem Inserat ↗“ bzw. „aus der Zeitung“.
// Verlauf: Was Paul selbst geschrieben hat (Notizen, Gesprächsnotizen) ist farbig markiert; automatische Einträge bleiben neutral.
// In der Objektakte kann man jetzt direkt eine Notiz in den Verlauf schreiben.

const AK45 = { alle: {} };
const AK45_SYSTEM = /^(📄|📥|💶|🔬|📊|🤖|👥|🔁|Angabe geklärt|Investmentprüfung:|Marktanalyse V\d|Große Analyse)/u;
function ak45Eigen(x){
  if(!x) return false;
  if(x.eigen === true || x.eigen === false) return x.eigen;
  if(x.typ === 'gespraech') return true;
  return x.typ === 'notiz' && !AK45_SYSTEM.test(String(x.text || '').trim());
}
function ak45Link(o){ const u = String((o && o.link) || '').trim(); return /^https?:\/\/[^\s"'<>]+$/i.test(u) ? u : ''; }
function ak45Inserat(id){ const o = findObjekt(id), u = ak45Link(o); if(u) window.open(u, '_blank'); }
function ak45HerkunftHtml(o){
  const u = ak45Link(o);
  if(u) return `<a href="#" class="ak45-inserat" onclick="ak45Inserat('${o.id}');return false;" title="${mc24E(u)}">🔗 Inserat öffnen <small>${mc24E(typeof aqLinkDomain === 'function' ? aqLinkDomain(u) : '')}</small></a>`;
  const q = String(o.quelle || '').trim(), name = q && !/direktakquise|kleinanzeigen|immoscout|immowelt|immonet|ebay|akquise/i.test(q) ? ' (' + q + ')' : '';
  return `<span class="ak45-zeitung">📰 Aus Zeitung${mc24E(name)}</span>`;
}
function ak45Zeit(ts){ if(!ts) return { d: '', u: '' }; const d = new Date(ts); return { d: d.toLocaleDateString('de-DE', { day: '2-digit', month: '2-digit', year: '2-digit' }), u: d.toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' }) }; }
function ak45VerlaufHtml(o){
  const l = (o.verlauf || []).slice().sort((a, b) => (b.ts || b.zeit || 0) - (a.ts || a.zeit || 0)), alle = AK45.alle[o.id], zeigen = alle ? l : l.slice(0, 10);
  const ic = typeof AQ_VL_IC === 'object' ? AQ_VL_IC : {};
  const eintraege = zeigen.map(v => {
    const z = ak45Zeit(v.ts || v.zeit), eigen = ak45Eigen(v);
    return `<div class="ak45-v${eigen ? ' eigen' : ''}"><span class="ak45-zeit">${z.d}<br><b>${z.u}</b></span><span class="ak45-ic">${eigen ? '✍️' : (ic[v.typ] || (v.typ === 'gespraech' ? '💬' : '•'))}</span>
      <div class="ak45-text">${eigen ? `<span class="ak45-ich">${v.typ === 'gespraech' ? 'Deine Gesprächsnotiz' : 'Deine Notiz'}</span>` : ''}${mc24E(v.text || v.t || '')}</div></div>`;
  }).join('');
  return `<div class="ak45-neu"><textarea id="ak45Notiz" rows="2" placeholder="Notiz zum Objekt schreiben …" onkeydown="if((event.ctrlKey||event.metaKey)&&event.key==='Enter'){event.preventDefault();ak45NotizSpeichern('${o.id}');}"></textarea><button onclick="ak45NotizSpeichern('${o.id}')">📝 Notiz speichern</button></div>
    ${eintraege || '<div class="vl-leer">Noch kein Verlauf.</div>'}
    ${l.length > 10 ? `<button class="secondary tiny" style="margin-top:6px" onclick="AK45.alle['${o.id}']=!AK45.alle['${o.id}'];ob24Render(document.getElementById('main'))">${alle ? 'Weniger anzeigen' : 'Alle ' + l.length + ' Einträge'}</button>` : ''}`;
}
function ak45NotizSpeichern(id){
  const o = findObjekt(id), t = document.getElementById('ak45Notiz'); if(!o || !t) return;
  const text = t.value.trim(); if(!text){ t.focus(); return; }
  aqLog(o, 'notiz', text); const v = o.verlauf[o.verlauf.length - 1]; if(v) v.eigen = true;
  save(); ob24Render(document.getElementById('main')); akqToast('📝 Notiz gespeichert');
}
(function(){
  const _r = ob24Render;
  ob24Render = function(main){
    _r.apply(this, arguments);
    try{
      const o = findObjekt(MC24.akteId); if(!o || !main) return;
      const sub = main.querySelector('.aq-kopf .sub');
      if(sub && !sub.querySelector('.ak45-inserat, .ak45-zeitung')) sub.insertAdjacentHTML('beforeend', ' · ' + ak45HerkunftHtml(o));
      const u = ak45Link(o);
      main.querySelectorAll('.mc24-akte td.mc24-muted').forEach(td => {
        if(td.innerHTML.includes('aus den Objektdaten')) td.innerHTML = td.innerHTML.replace('aus den Objektdaten', u ? `<a href="#" onclick="ak45Inserat('${o.id}');return false;" title="${mc24E(u)}">aus dem Inserat ↗</a>` : 'aus der Zeitung');
      });
      const vk = [...main.querySelectorAll('.mc24-akte .mc24-karte')].find(k => (k.querySelector('h3') || {}).textContent === 'Verlauf');
      if(vk){ vk.classList.add('breit'); vk.innerHTML = `<h3>Verlauf <span class="sp"></span><small class="mc24-muted ak45-leg"><span class="ak45-punkt"></span> = von dir geschrieben</small></h3>` + ak45VerlaufHtml(o); }
    }catch(err){ console.error('akte45', err); }
  };
  // Notizen aus der Akquise-Ansicht als eigene markieren
  if(typeof aq2NotizHinzu === 'function'){
    const _n = aq2NotizHinzu;
    aq2NotizHinzu = function(){
      const o = findObjekt(AQ2.sel), vorher = o && o.verlauf ? o.verlauf.length : 0;
      _n.apply(this, arguments);
      if(o && o.verlauf && o.verlauf.length > vorher){ o.verlauf[o.verlauf.length - 1].eigen = true; save(); try{ aq2Detail(); }catch(e){} }
    };
  }
  if(typeof aqVerlaufHtml === 'function'){
    const _v = aqVerlaufHtml;
    aqVerlaufHtml = function(o){
      let h = _v.apply(this, arguments);
      try{
        const v = (typeof aqVerlaufHolen === 'function' ? aqVerlaufHolen(o) : (o.verlauf || [])).slice().sort((a, b) => b.ts - a.ts);
        let i = 0;
        h = h.replace(/<div class="vl-i vl-([a-z_]+)">/g, (m, typ) => { const x = v[i++]; return ak45Eigen(x) ? `<div class="vl-i vl-${typ} vl-eigen">` : m; });
      }catch(err){}
      return h;
    };
  }
  const st = document.createElement('style');
  st.textContent = `.ak45-inserat{display:inline-flex;gap:5px;align-items:center;padding:2px 10px;border-radius:999px;background:var(--orange);color:#fff !important;font-weight:600;text-decoration:none;white-space:nowrap}
.ak45-inserat small{opacity:.85;font-weight:400}
.ak45-zeitung{display:inline-block;padding:2px 10px;border-radius:999px;border:1px solid var(--border);white-space:nowrap}
.ak45-neu{display:flex;gap:8px;align-items:flex-end;margin-bottom:10px}.ak45-neu textarea{flex:1;min-height:42px}
.ak45-v{display:grid;grid-template-columns:62px 22px 1fr;gap:6px;align-items:start;padding:7px 4px;border-bottom:1px solid rgba(29,43,68,.6);font-size:13px}
.ak45-zeit{color:var(--muted);font-size:11px;line-height:1.35}.ak45-text{line-height:1.45;word-break:break-word;color:#b9c5d8}
.ak45-v.eigen{background:rgba(255,138,61,.16);border-left:4px solid #ff8a3d;border-radius:0 8px 8px 0;padding-left:8px;margin:3px 0}
.ak45-v.eigen .ak45-text{color:var(--text);font-weight:500}
.ak45-ich{display:block;font-size:11px;font-weight:700;color:#ff8a3d;text-transform:uppercase;letter-spacing:.04em;margin-bottom:1px}
.ak45-leg{font-weight:400;font-size:11px;display:inline-flex;gap:5px;align-items:center}.ak45-punkt{display:inline-block;width:10px;height:10px;border-radius:2px;background:#ff8a3d}
.vl-i.vl-eigen{background:rgba(255,138,61,.16);border-left:4px solid #ff8a3d;border-radius:0 8px 8px 0;padding-left:6px}
.vl-i.vl-eigen .vl-x{background:none;border-left:0;padding:0;color:var(--text);font-weight:500}
@media (max-width:760px){.ak45-neu{flex-direction:column;align-items:stretch}.ak45-v{grid-template-columns:50px 20px 1fr}}`;
  document.head.appendChild(st);
})();
