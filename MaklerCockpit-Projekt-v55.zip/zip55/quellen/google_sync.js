/* MaklerCockpit v14/v15 – Google Kalender: Zwei-Wege-Abgleich, Termine-Seite, Termin-Dialog, Einrichtung */
const GS = { st:null, laeuft:false, nochmal:false, timer:null, fehler:'', code:'', letzterVersuch:0, signatur:null, kalender:null, anmeldeFehler:'' };
const GS_ZURUECK = 30, GS_VOR = 400;               // Abgleich-Zeitraum: 30 Tage zurück bis ca. 13 Monate voraus
const GS_MARKE = '— aus dem MaklerCockpit —';       // ab hier steht in Google die Lead-Info (wird beim Zurücklesen abgeschnitten)
const GS_FARBE_STD = '7';                          // v20: Standardfarbe Blau („Pfau“) für alle Termine aus dem Cockpit
const GS_FARBE_ALT = { besichtigung:'6', akquise:'6', erstgespraech:'2', rueckruf:'5', shooting:'3' };  // bis v19 vergeben – wird einmalig auf Blau umgestellt
const GS_WT = ['So','Mo','Di','Mi','Do','Fr','Sa'];

// Terminarten: allgemeiner Termin (aus Google) + Makler-Arten
try{ TERMIN_ARTEN.splice(0, TERMIN_ARTEN.length,
  ["termin","📅 Termin"],["besichtigung","👀 Besichtigung"],["erstgespraech","🤝 Erstgespräch / Bewertung"],["akquise","🎯 Akquise-Termin"],
  ["rueckruf","🔁 Rückruf"],["shooting","📸 Shooting"],["eigene","✏️ Eigene Bezeichnung…"]); }catch(e){}

// ── Kleine Helfer ──
function gsVerfuegbar(){ return !!(window.pc && window.pc.google); }
async function gsRuf(aktion, arg){
  if(!gsVerfuegbar()) return { ok:false, fehler:'Nur in der PC-Version verfügbar' };
  try{ return (await window.pc.google(aktion, arg)) || { ok:false, fehler:'keine Antwort' }; }catch(e){ return { ok:false, fehler:String(e.message||e) }; }
}
function gsApi(methode, pfad, query, body){ return gsRuf('api', { methode, pfad, query, body }); }
function gsCfg(){ if(!db.googleSync || typeof db.googleSync !== 'object') db.googleSync = {}; const c = db.googleSync; if(!c.bekannt || typeof c.bekannt !== 'object') c.bekannt = {}; return c; }
function gsAktiv(){ const c = gsCfg(); return !!(gsVerfuegbar() && GS.st && GS.st.verbunden && c.kalenderId && !c.pausiert); }
function gsFehler(code, text){ const e = new Error(text || 'Fehler'); e.code = code; return e; }
async function gsStatusLaden(){ const s = await gsRuf('status'); GS.st = s && s.ok ? s : { verbunden:false, eingerichtet:false }; return GS.st; }
function gsT(id){ return (db.termine||[]).find(x=>x.id===id); }
function gsTagPlus(key, n){ const [y,m,d] = String(key).split('-').map(Number); return toDateKey(new Date(y, m-1, d+n)); }
function gsPlusMin(datum, zeit, min){ const [y,m,d] = datum.split('-').map(Number); const [h,mi] = String(zeit||'00:00').split(':').map(Number); return new Date(Date.UTC(y, m-1, d, h, mi + min)).toISOString().slice(0,19); }
function gsEnde(t){ return t.uhrzeit ? gsPlusMin(t.datum, t.uhrzeit, Number(t.dauer)||60).slice(11,16) : ''; }
function gsImFenster(datum){ if(!datum) return false; const h = toDateKey(new Date()); return datum > gsTagPlus(h, -GS_ZURUECK+1) && datum < gsTagPlus(h, GS_VOR-1); }
function gsDatumLang(key){
  if(!key) return '';
  const [y,m,d] = key.split('-').map(Number); const x = new Date(y, m-1, d); const h = toDateKey(new Date());
  if(key===h) return 'Heute'; if(key===gsTagPlus(h,1)) return 'Morgen'; if(key===gsTagPlus(h,-1)) return 'Gestern';
  return GS_WT[x.getDay()] + ' ' + String(d).padStart(2,'0') + '.' + String(m).padStart(2,'0') + '.' + (y!==new Date().getFullYear() ? String(y).slice(2) : '');
}
function gsKurz(t){ return gsDatumLang(t.datum) + (t.uhrzeit ? ' ' + t.uhrzeit + ' Uhr' : ' (ganztägig)'); }
// Für den Verlauf: festes Datum statt „Morgen“ (bleibt auch später richtig)
function gsDatumFest(key){ if(!key) return ''; const [y,m,d] = key.split('-').map(Number); return GS_WT[new Date(y, m-1, d).getDay()] + ' ' + String(d).padStart(2,'0') + '.' + String(m).padStart(2,'0') + '.' + (y!==new Date().getFullYear() ? y : ''); }
function gsKurzFest(t){ return gsDatumFest(t.datum) + (t.uhrzeit ? ' ' + t.uhrzeit + ' Uhr' : ' (ganztägig)'); }
function gsArtLabel(t){ if(t.art==='eigene') return t.artEigene || 'Termin'; const a = TERMIN_ARTEN.find(x=>x[0]===t.art); return a ? a[1].replace(/^\S+\s/,'').replace(/…$/,'') : 'Termin'; }
function gsArtIcon(t){ if(t.art==='eigene') return /rückruf/i.test(t.artEigene||'') ? '🔁' : /akquise/i.test(t.artEigene||'') ? '🎯' : '📅'; const a = TERMIN_ARTEN.find(x=>x[0]===t.art); return a ? a[1].split(' ')[0] : '📅'; }
function gsVor(ts){
  if(!ts) return ''; const s = (Date.now()-ts)/1000;
  if(s < 50) return 'gerade eben'; if(s < 3600) return 'vor ' + Math.max(1, Math.round(s/60)) + ' Min.';
  const d = new Date(ts); const zeit = d.toLocaleTimeString('de-DE',{hour:'2-digit',minute:'2-digit'});
  return toDateKey(d)===toDateKey(new Date()) ? 'um ' + zeit + ' Uhr' : 'am ' + d.toLocaleDateString('de-DE',{day:'2-digit',month:'2-digit'}) + ' ' + zeit;
}
function gsLogText(t){ return gsArtLabel(t) + ' am ' + gsKurzFest(t); }
function gsObjLog(t, text){ try{ const o = t && t.objektId && findObjekt(t.objektId); if(o && typeof aqLog==='function') aqLog(o, 'termin', text); }catch(e){} }

// ── Termin ↔ Google-Termin ──
function gsHash(t){ return JSON.stringify([t.titel||'', t.datum||'', t.uhrzeit||'', t.uhrzeit ? (Number(t.dauer)||60) : 0, t.uhrzeit ? '' : (t.bisDatum||''), t.ort||'', String(t.notiz||'').trim()]); }
function gsSignatur(){ return (db.termine||[]).map(t=>t.id+'|'+(t.googleEventId||'')+'|'+(t.nurLokal?1:0)+'|'+gsHash(t)).join('\n'); }
function gsFuss(t){
  const z = [];
  const o = t.objektId ? findObjekt(t.objektId) : null;
  const k = t.kontaktId ? findKontakt(t.kontaktId) : (o && o.eigentuemerId ? findKontakt(o.eigentuemerId) : null);
  const name = (o && typeof aqName==='function' ? aqName(o) : '') || (k && !/^Privat – /.test(k.name||'') ? k.name : '') || '';
  const tel = (o && typeof aqTel==='function' ? aqTel(o) : '') || (k && k.telefon) || '';
  const mail = (o && typeof aqMail==='function' ? aqMail(o) : '') || (k && k.email) || '';
  if(o){ const titel = typeof aqTitel==='function' ? aqTitel(o) : (o.adresse||''); const lage = [o.adresse, o.ort].filter(Boolean).join(', '); z.push('Objekt: ' + [titel, lage && lage!==titel ? lage : ''].filter(Boolean).join(' – ')); }
  if(name) z.push('Kontakt: ' + name);
  if(tel) z.push('Telefon: ' + tel);
  if(mail) z.push('E-Mail: ' + mail);
  if(o && o.kaufpreis) z.push('Preis: ' + Number(o.kaufpreis).toLocaleString('de-DE') + ' €');
  if(o && o.link) z.push('Anzeige: ' + o.link);
  return z.length ? (String(t.notiz||'').trim() ? '\n\n' : '') + GS_MARKE + '\n' + z.join('\n') : '';
}
function gsText(roh){
  let s = String(roh||''); const i = s.indexOf(GS_MARKE); if(i >= 0) s = s.slice(0, i);
  if(/<[a-z][^>]*>/i.test(s)) s = s.replace(/<br\s*\/?>/gi,'\n').replace(/<\/(p|div|li|h\d)>/gi,'\n').replace(/<[^>]+>/g,'')
    .replace(/&nbsp;/g,' ').replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&quot;/g,'"').replace(/&#39;/g,"'").replace(/&amp;/g,'&');
  return s.replace(/\r/g,'').replace(/\n{3,}/g,'\n\n').trim();
}
function gsEventKoerper(t){
  const b = { summary: t.titel || '(ohne Titel)', description: String(t.notiz||'').trim() + gsFuss(t), location: t.ort || '', extendedProperties: { private: { mcId: t.id } } };
  if(t.uhrzeit){ b.start = { dateTime: t.datum + 'T' + t.uhrzeit + ':00', timeZone: 'Europe/Berlin' }; b.end = { dateTime: gsPlusMin(t.datum, t.uhrzeit, Number(t.dauer)||60), timeZone: 'Europe/Berlin' }; }
  else { b.start = { date: t.datum }; b.end = { date: gsTagPlus(t.bisDatum && t.bisDatum > t.datum ? t.bisDatum : t.datum, 1) }; }
  return b;
}
function gsAusEvent(ev){
  const s = ev.start || {}, e = ev.end || {};
  const r = { titel: ev.summary || '(ohne Titel)', ort: ev.location || '', notiz: gsText(ev.description), gLink: ev.htmlLink || '',
    farbe: (typeof GOOGLE_EVENT_FARBEN!=='undefined' && ev.colorId && GOOGLE_EVENT_FARBEN[ev.colorId]) || null };
  if(s.date){ r.datum = s.date; r.uhrzeit = ''; r.dauer = null; const bis = e.date ? gsTagPlus(e.date, -1) : s.date; r.bisDatum = bis > s.date ? bis : ''; }
  else { const st = String(s.dateTime||''); r.datum = st.slice(0,10); r.uhrzeit = st.slice(11,16); const min = Math.round((Date.parse(e.dateTime) - Date.parse(s.dateTime)) / 60000); r.dauer = min > 0 ? min : 60; r.bisDatum = ''; }
  return r;
}
function gsNormTitel(s){ return String(s||'').toLowerCase().replace(/[^a-z0-9äöüß]+/g,' ').trim(); }
function gsGleich(ev, t){ const g = gsAusEvent(ev); return g.datum===t.datum && (g.uhrzeit||'')===(t.uhrzeit||'') && gsNormTitel(g.titel)===gsNormTitel(t.titel); }
function gsTrenneTermin(t){ delete t.googleEventId; delete t.gUpdated; delete t.gHash; delete t.gLink; }
function gsMcId(ev){ return ((ev.extendedProperties||{}).private||{}).mcId || ''; }

// ── Abgleich ──
async function gsHochladen(pfad, id, ev){
  const t = gsT(id); const h = gsHash(t); const body = gsEventKoerper(t);
  const artJetzt = t.uhrzeit ? 'zeit' : 'tag', artGoogle = ev && ev.start ? (ev.start.date ? 'tag' : 'zeit') : artJetzt;
  let r;
  if(artJetzt !== artGoogle){
    // ganztägig ↔ mit Uhrzeit: komplettes Ersetzen, sonst lehnt Google die Mischung ab
    const voll = Object.assign({}, ev, body);
    voll.extendedProperties = { shared: (ev.extendedProperties||{}).shared, private: Object.assign({}, (ev.extendedProperties||{}).private||{}, body.extendedProperties.private) };
    if(!voll.extendedProperties.shared) delete voll.extendedProperties.shared;
    r = await gsApi('PUT', pfad, {}, voll);
  } else r = await gsApi('PATCH', pfad, {}, body);
  return { r, h };
}
async function gsSync(grund){
  if(!gsVerfuegbar()) return null;
  if(GS.laeuft){ GS.nochmal = true; return null; }
  let c = gsCfg();
  if(!c.kalenderId || c.pausiert) return null;
  clearTimeout(GS.timer); GS.timer = null;
  GS.laeuft = true; GS.letzterVersuch = Date.now(); gsAnzeigen(false);
  const b = { neuG:0, neuL:0, aendG:0, aendL:0, loeschG:0, loeschL:0, fehler:[] };
  const vorher = JSON.stringify([db.termine, c.bekannt]);
  try{
    if(!GS.st || !GS.st.verbunden){ await gsStatusLaden(); if(!GS.st.verbunden) throw gsFehler('nicht_verbunden', 'Google ist nicht verbunden.'); }
    const kal = '/calendars/' + encodeURIComponent(c.kalenderId) + '/events';
    const pf = eid => kal + '/' + encodeURIComponent(eid);
    const heute = new Date(), h0 = toDateKey(heute);
    const tMin = new Date(heute.getFullYear(), heute.getMonth(), heute.getDate() - GS_ZURUECK).toISOString();
    const tMax = new Date(heute.getFullYear(), heute.getMonth(), heute.getDate() + GS_VOR).toISOString();
    const items = []; let seite = '';
    do{
      const r = await gsApi('GET', kal, { timeMin:tMin, timeMax:tMax, singleEvents:'true', showDeleted:'true', maxResults:'2500', timeZone:'Europe/Berlin', pageToken: seite || undefined });
      if(!r.ok) throw gsFehler(r.code, r.status === 404 ? 'Der gewählte Google-Kalender existiert nicht mehr – bitte über ⚙ einen anderen wählen.' : (r.fehler || ('Google antwortet mit Fehler ' + r.status)));
      items.push(...(((r.data||{}).items)||[]).filter(e => e && e.id && e.eventType !== 'workingLocation'));
      seite = (r.data||{}).nextPageToken || '';
    } while(seite);
    const evMap = new Map(items.map(e=>[e.id, e]));
    const erledigt = new Set();

    // 1) Am PC gelöschte Termine → auch in Google löschen
    c = gsCfg();
    const lokal = new Set((db.termine||[]).filter(t=>t.googleEventId).map(t=>t.googleEventId));
    let weg = Object.keys(c.bekannt).filter(eid => !lokal.has(eid));
    const zf = c.zusammen || {}, pruef = weg.filter(eid => !zf[eid]);   // v48: zu einer Anrufliste zusammengefügte Telefontermine nicht nachfragen
    if(pruef.length > 5 && pruef.length > Object.keys(c.bekannt).length * 0.3){
      const ja = confirm(`Seit dem letzten Abgleich fehlen am PC ${weg.length} Termine, die auch in deinem Google Kalender stehen.\n\nSollen sie auch im Google Kalender gelöscht werden?\n\nOK = ja, in Google löschen\nAbbrechen = nein, die Termine wieder aus Google holen`);
      if(!ja){ pruef.forEach(eid => delete gsCfg().bekannt[eid]); weg = weg.filter(eid => zf[eid]); }
    }
    for(const eid of weg){
      erledigt.add(eid);
      const ev = evMap.get(eid);
      if(ev && ev.status === 'cancelled'){ delete gsCfg().bekannt[eid]; continue; }
      const r = await gsApi('DELETE', pf(eid));
      if(r.ok || r.status === 404 || r.status === 410 || r.code === 'kein_recht'){ delete gsCfg().bekannt[eid]; if(c.zusammen) delete c.zusammen[eid]; if(r.ok) b.loeschG++; else if(r.code === 'kein_recht') b.fehler.push(r.fehler); }
      else b.fehler.push('Löschen in Google: ' + (r.fehler || r.status));
    }

    // 2) Verknüpfte Termine: wer zuletzt geändert hat, gewinnt
    for(const id of (db.termine||[]).filter(t=>t.googleEventId).map(t=>t.id)){
      let t = gsT(id); if(!t || !t.googleEventId) continue;
      const eid = t.googleEventId; erledigt.add(eid); gsCfg().bekannt[eid] = id;
      if(t.nurLokal){   // „nur am PC“ angehakt → aus Google entfernen
        const r = await gsApi('DELETE', pf(eid)); t = gsT(id); if(!t) continue;
        if(r.ok || r.status === 404 || r.status === 410 || r.code === 'kein_recht'){ gsTrenneTermin(t); delete gsCfg().bekannt[eid]; if(r.ok) b.loeschG++; }
        else b.fehler.push(r.fehler || 'Entfernen aus Google fehlgeschlagen');
        continue;
      }
      let ev = evMap.get(eid);
      if(!ev){
        if(!gsImFenster(t.datum)) continue;          // älter als 30 Tage: bleibt als Archiv am PC
        const r = await gsApi('GET', pf(eid), { timeZone:'Europe/Berlin' }); t = gsT(id); if(!t) continue;
        if(r.status === 404 || r.status === 410) ev = { id:eid, status:'cancelled' };
        else if(!r.ok){ b.fehler.push(r.fehler || 'Abruf fehlgeschlagen'); continue; }
        else ev = r.data;
      }
      if(ev.status === 'cancelled'){
        db.termine = db.termine.filter(x=>x.id!==id); delete gsCfg().bekannt[eid]; b.loeschL++;
        gsObjLog(t, 'Termin im Google Kalender gelöscht: ' + gsKurzFest(t)); continue;
      }
      let lokalNeu = gsHash(t) !== t.gHash, googleNeu = ev.updated !== t.gUpdated;
      // v20: früher vom Cockpit vergebene Farben (orange/grün/gelb/lila) einmalig auf Blau umstellen
      if(!t.farbe20 && !lokalNeu && !googleNeu){
        if(ev.colorId && GS_FARBE_ALT[t.art] === ev.colorId){
          const r = await gsApi('PATCH', pf(eid), {}, { colorId: GS_FARBE_STD }); t = gsT(id); if(!t) continue;
          if(r.ok && r.data){ t.gUpdated = r.data.updated; t.farbe = GOOGLE_EVENT_FARBEN[GS_FARBE_STD] || null; t.farbe20 = true; }
        } else t.farbe20 = true;
        lokalNeu = gsHash(t) !== t.gHash; googleNeu = false;
      }
      if(googleNeu && (!lokalNeu || Date.parse(ev.updated) >= (t.geaendertAm||0))){
        const alt = gsKurz(t);
        Object.assign(t, gsAusEvent(ev)); t.gUpdated = ev.updated; t.gHash = gsHash(t); b.aendL++;
        if(gsKurz(t) !== alt) gsObjLog(t, 'Im Google Kalender verschoben auf ' + gsKurzFest(t));
      } else if(lokalNeu){
        const { r, h } = await gsHochladen(pf(eid), id, ev); t = gsT(id); if(!t) continue;
        if(r.ok){ t.gUpdated = r.data.updated; t.gHash = h; t.gLink = r.data.htmlLink || t.gLink || ''; b.aendG++; }
        else if(r.status === 404 || r.status === 410){ gsTrenneTermin(t); delete gsCfg().bekannt[eid]; }      // wird unten neu angelegt
        else if(r.code === 'kein_recht'){ Object.assign(t, gsAusEvent(ev)); t.gUpdated = ev.updated; t.gHash = gsHash(t); b.fehler.push('„' + t.titel + '“: ' + r.fehler + ' Die Änderung am PC wurde zurückgenommen.'); }
        else b.fehler.push('„' + t.titel + '“: ' + (r.fehler || r.status));
      } else if(!t.gLink && ev.htmlLink) t.gLink = ev.htmlLink;
    }

    // 3) Neue Termine vom PC → Google (doppelte werden erkannt und verknüpft)
    const ab = gsTagPlus(h0, -GS_ZURUECK), bis = gsTagPlus(h0, GS_VOR);
    const verknuepft = () => new Set((db.termine||[]).filter(t=>t.googleEventId).map(t=>t.googleEventId));
    for(const id of (db.termine||[]).filter(t=>!t.googleEventId && !t.nurLokal && t.datum && t.datum >= ab && t.datum < bis).map(t=>t.id)){
      let t = gsT(id); if(!t || t.googleEventId) continue;
      const vk = verknuepft();
      const frei = e => e.status !== 'cancelled' && !erledigt.has(e.id) && !vk.has(e.id);
      let ev = items.find(e => frei(e) && gsMcId(e) === id), zusammen = false;
      if(!ev){ ev = items.find(e => frei(e) && gsGleich(e, t)); zusammen = !!ev; }
      if(ev){
        erledigt.add(ev.id);
        const g = gsAusEvent(ev);
        if(zusammen){ g.notiz = g.notiz || t.notiz || ''; g.ort = g.ort || t.ort || ''; Object.assign(t, g); }
        t.googleEventId = ev.id; t.gUpdated = ev.updated; t.gLink = ev.htmlLink || '';
        t.gHash = gsHash(Object.assign({}, t, gsAusEvent(ev)));
        gsCfg().bekannt[ev.id] = id;
        if(gsHash(t) !== t.gHash){ const { r, h } = await gsHochladen(pf(ev.id), id, ev); t = gsT(id); if(t && r.ok){ t.gUpdated = r.data.updated; t.gHash = h; b.aendG++; } }
        continue;
      }
      // Gleicher Termin ist schon mit einem anderen PC-Eintrag verknüpft → zusammenführen statt doppelt eintragen
      const zwilling = items.find(e => e.status !== 'cancelled' && vk.has(e.id) && gsGleich(e, t));
      const tw = zwilling && (db.termine||[]).find(x => x.googleEventId === zwilling.id && x.id !== id);
      if(tw){
        ['notiz','ort','objektId','kontaktId'].forEach(f => { if(!tw[f] && t[f]) tw[f] = t[f]; });
        if(tw.art === 'termin' && t.art && t.art !== 'termin'){ tw.art = t.art; tw.artEigene = t.artEigene || ''; }
        tw.geaendertAm = Date.now();
        db.termine = db.termine.filter(x => x.id !== id);
        continue;
      }
      const h = gsHash(t), body = gsEventKoerper(t); body.colorId = GS_FARBE_STD;
      const r = await gsApi('POST', kal, {}, body);
      t = gsT(id);
      if(!r.ok){ b.fehler.push('„' + ((t && t.titel) || 'Termin') + '“ konnte nicht eingetragen werden: ' + (r.fehler || r.status)); if(r.code === 'kein_recht' || r.code === 'api_aus') break; continue; }
      erledigt.add(r.data.id);
      if(!t || t.googleEventId){ await gsApi('DELETE', pf(r.data.id)); continue; }   // inzwischen am PC gelöscht
      t.googleEventId = r.data.id; t.gUpdated = r.data.updated; t.gHash = h; t.gLink = r.data.htmlLink || '';
      gsCfg().bekannt[r.data.id] = id; b.neuG++;
    }

    // 4) Neue Termine aus Google → PC
    const vk = verknuepft();
    for(const ev of items){
      if(ev.status === 'cancelled' || erledigt.has(ev.id) || vk.has(ev.id) || gsCfg().bekannt[ev.id]) continue;
      const mc = gsMcId(ev);
      const gleich = (db.termine||[]).find(x => !x.googleEventId && !x.nurLokal && (x.id === mc || gsGleich(ev, x)));
      if(gleich){ Object.assign(gleich, gsAusEvent(ev), { googleEventId: ev.id, gUpdated: ev.updated }); gleich.gHash = gsHash(gleich); gsCfg().bekannt[ev.id] = gleich.id; vk.add(ev.id); b.aendL++; continue; }
      const t = Object.assign({ id: (mc && !gsT(mc)) ? mc : uid(), createdAt: Date.now(), art:'termin', artEigene:'', objektId:null, kontaktId:null, quelle:'google' }, gsAusEvent(ev), { googleEventId: ev.id, gUpdated: ev.updated });
      t.gHash = gsHash(t); db.termine.push(t); gsCfg().bekannt[ev.id] = t.id; b.neuL++;
    }

    c = gsCfg();
    (db.termine||[]).forEach(t => { if(t.googleEventId) c.bekannt[t.googleEventId] = t.id; });
    c.letzterSync = Date.now(); c.letzteZahlen = { neuG:b.neuG, neuL:b.neuL, aendG:b.aendG, aendL:b.aendL, loeschG:b.loeschG, loeschL:b.loeschL };
    GS.fehler = b.fehler.length ? (b.fehler.length > 1 ? b.fehler.length + ' Probleme, u. a.: ' : '') + b.fehler[0] : ''; GS.code = b.fehler.length ? 'teil' : '';
  }catch(e){
    GS.fehler = String(e.message || e); GS.code = e.code || 'fehler';
    if(GS.code === 'abgelaufen' || GS.code === 'nicht_verbunden') await gsStatusLaden();
    b.fehler.push(GS.fehler);
  }finally{
    const geaendert = JSON.stringify([db.termine, gsCfg().bekannt]) !== vorher;
    GS.signatur = gsSignatur();
    if(geaendert) _gsSaveOrig();
    GS.laeuft = false;
    gsAnzeigen(geaendert);
    const zahl = b.neuL + b.aendL + b.loeschL;
    if(grund === 'manuell') akqToast(GS.fehler ? '⚠️ ' + GS.fehler : `✓ Abgeglichen${zahl||b.neuG||b.aendG||b.loeschG ? ' – ' + gsZahlenText(b) : ' – alles aktuell'}`, 4200);
    else if(zahl && grund !== 'leise') akqToast('📅 Google Kalender: ' + gsZahlenText(b), 3600);
    if(GS.nochmal){ GS.nochmal = false; gsPlanen(1500); }
  }
  return b;
}
function gsZahlenText(b){
  const t = [];
  if(b.neuL) t.push(b.neuL + ' neu aus Google'); if(b.aendL) t.push(b.aendL + ' in Google geändert'); if(b.loeschL) t.push(b.loeschL + ' in Google gelöscht');
  if(b.neuG) t.push(b.neuG + ' nach Google eingetragen'); if(b.aendG) t.push(b.aendG + ' nach Google übertragen'); if(b.loeschG) t.push(b.loeschG + ' in Google gelöscht');
  return t.join(' · ');
}
function gsPlanen(ms){ if(!gsAktiv()) return; clearTimeout(GS.timer); GS.timer = setTimeout(()=>gsSync('aenderung'), ms==null ? 2000 : ms); }

// Jede lokale Speicherung prüft, ob sich Termine geändert haben → kurz danach abgleichen
const _gsSaveOrig = save;
save = function(){
  const r = _gsSaveOrig.apply(this, arguments);
  try{ if(gsAktiv()){ if(GS.laeuft) GS.nochmal = true; else if(gsSignatur() !== GS.signatur) gsPlanen(2500); } }catch(e){}
  return r;
};
// Alte Google-Funktionen der Browser-Version umleiten
syncTerminMitGoogleCalendar = function(){ gsPlanen(800); };
loescheTerminAusGoogleCalendar = function(){ gsPlanen(800); };
ladeGoogleKalenderTermine = function(){ gsSync('manuell'); };
googleKalenderVerbinden = function(){ gsAssistent(); };
googleKalenderTermine = [];

// Oberfläche nach Abgleich auffrischen (ohne laufende Eingaben zu stören)
function gsAnzeigen(aenderung){
  const l = document.getElementById('gsLeiste'); if(l) l.innerHTML = gsLeisteHtml();
  if(aenderung){
    if(document.getElementById('kalGrid')) try{ renderKalenderGrid(); }catch(e){}
    const n = document.getElementById('tmNaechste'); if(n) n.innerHTML = gsNaechsteHtml();
    try{ if(typeof aq2TermineAktualisieren==='function') aq2TermineAktualisieren(); }catch(e){}
    try{ renderNav(); }catch(e){}
  }
  try{ tbGlockeAktualisieren(); }catch(e){}
}

// ── Termine-Seite ──
function gsTermineAm(key){ return (db.termine||[]).filter(t=>t.datum===key || (t.bisDatum && t.datum < key && t.bisDatum >= key)).sort((a,b)=>(a.uhrzeit||'').localeCompare(b.uhrzeit||'')); }
function gsSyncIcon(t){
  if(!gsVerfuegbar() || !gsCfg().kalenderId) return '';
  if(t.nurLokal) return '<span class="gs-si lokal" title="Nur am PC">PC</span>';
  if(t.googleEventId) return gsHash(t) !== t.gHash ? '<span class="gs-si wartet" title="Änderung wird übertragen">⟳</span>' : '<span class="gs-si ok" title="Im Google Kalender">✓</span>';
  return gsImFenster(t.datum) || t.datum >= toDateKey(new Date()) ? '<span class="gs-si wartet" title="Wird in Google eingetragen">⟳</span>' : '';
}
function gsNaechste(n){
  const jetzt = new Date(), h = toDateKey(jetzt), uhr = jetzt.toTimeString().slice(0,5);
  return (db.termine||[]).filter(t => t.datum > h || (t.datum === h && (!t.uhrzeit || gsEnde(t) >= uhr)) || (t.bisDatum && t.datum < h && t.bisDatum >= h))
    .sort((a,b)=> (a.datum+(a.uhrzeit||'00:00')).localeCompare(b.datum+(b.uhrzeit||'00:00'))).slice(0, n||12);
}
function gsTerminZeile(t, mitDatum){
  const o = t.objektId ? findObjekt(t.objektId) : null;
  const unter = [t.uhrzeit ? '' : 'ganztägig', o && typeof aqTitel==='function' ? aqTitel(o) : '', t.ort].filter(Boolean).join(' · ');
  return `<div class="tm-z" onclick="oeffneTerminModal('${t.id}')">
    <div class="tm-zeit">${mitDatum ? `<small>${gsDatumLang(t.datum)}</small>` : ''}<b>${t.uhrzeit || '–'}</b>${t.uhrzeit ? `<small>${gsEnde(t)}</small>` : ''}</div>
    <div class="tm-was"><div class="tm-titel">${gsArtIcon(t)} ${akqEsc(t.titel)}</div>${unter ? `<div class="tm-unter">${akqEsc(unter)}</div>` : ''}</div>${gsSyncIcon(t)}</div>`;
}
function gsNaechsteHtml(){
  const l = gsNaechste(14);
  if(!l.length) return '<div class="vl-leer">Keine anstehenden Termine.</div>';
  let tag = '', html = '';
  for(const t of l){ if(t.datum !== tag){ tag = t.datum; html += `<div class="tm-tag">${gsDatumLang(t.datum)}</div>`; } html += gsTerminZeile(t, false); }
  return html;
}
function gsLeisteHtml(){
  if(!gsVerfuegbar()) return '';
  const st = GS.st, c = gsCfg();
  if(!st) return `<div class="gs-leiste"><span class="gs-punkt grau"></span><div class="gs-txt"><b>Google Kalender wird geprüft …</b></div></div>`;
  if(!st.verbunden || !c.kalenderId){
    const weg = !!c.kalenderId && !st.verbunden;
    return `<div class="gs-leiste ${weg ? 'warn' : 'einladung'}"><div class="gs-ic">${IC.termine}</div>
      <div class="gs-txt"><b>${weg ? 'Google-Verbindung abgelaufen' : 'Mit deinem Google Kalender verbinden'}</b>
      <small>${weg ? akqEsc(GS.fehler || 'Bitte neu anmelden – deine Termine bleiben erhalten.') : 'Termine am PC eintragen und sofort am Handy sehen – und umgekehrt. Einmal einrichten, kostenlos.'}</small></div>
      <button onclick="gsAssistent()">${weg ? 'Neu verbinden' : st.verbunden ? 'Kalender wählen' : 'Jetzt einrichten'}</button></div>`;
  }
  const leicht = GS.code==='teil' || GS.code==='netz';
  const punkt = GS.laeuft ? 'laeuft' : (GS.fehler ? (leicht ? 'gelb' : 'rot') : c.pausiert ? 'grau' : 'gruen');
  const titel = GS.laeuft ? 'Gleiche mit Google ab …' : c.pausiert ? 'Abgleich pausiert' : GS.fehler ? (GS.code==='teil' ? 'Abgeglichen – mit Hinweis' : GS.code==='netz' ? 'Gerade offline – nächster Versuch automatisch' : 'Abgleich hat nicht geklappt') : 'Synchron mit Google Kalender';
  const unter = GS.fehler && !GS.laeuft ? akqEsc(GS.fehler) : [akqEsc(st.email||''), akqEsc(c.kalenderName||'Hauptkalender'), c.letzterSync ? 'abgeglichen ' + gsVor(c.letzterSync) : 'noch nicht abgeglichen'].filter(Boolean).join(' · ');
  return `<div class="gs-leiste ${GS.fehler && !GS.laeuft && !leicht ? 'warn' : ''}"><span class="gs-punkt ${punkt}"></span>
    <div class="gs-txt"><b>${titel}</b><small>${unter}</small></div>
    <button class="secondary" ${GS.laeuft ? 'disabled' : ''} onclick="gsSync('manuell')">⟳ Jetzt abgleichen</button>
    <button class="secondary gs-zahn" title="Einstellungen" onclick="gsAssistent()">⚙</button></div>`;
}
renderTermine = function(main){
  main.innerHTML = `
    <div class="aq-kopf"><div class="ic">${IC.termine}</div><div><h1>Termine</h1><div class="sub">${gsAktiv() ? 'Ein Kalender für PC und Handy – Änderungen gehen automatisch hin und her.' : 'Deine Termine an diesem PC.'}</div></div>
      <div class="knoepfe"><button onclick="oeffneTerminModal()">${IC.plus} Neuer Termin</button></div></div>
    <div id="gsLeiste">${gsLeisteHtml()}</div>
    <div class="tm-layout">
      <div class="tm-kal">
        <div class="kal-kopf" style="margin-top:0;">
          <div class="nav"><button class="secondary tiny" onclick="kalenderMonatWechseln(-1)">← Zurück</button></div>
          <h2 id="kalMonatTitel"></h2>
          <div class="nav"><button class="secondary tiny" onclick="kalenderMonatWechseln(0)">Heute</button><button class="secondary tiny" onclick="kalenderMonatWechseln(1)">Weiter →</button></div>
        </div>
        <div class="kal-grid" id="kalGrid"></div>
      </div>
      <div class="tm-seite"><div class="tm-kopf">Als Nächstes</div><div id="tmNaechste">${gsNaechsteHtml()}</div></div>
    </div>`;
  renderKalenderGrid();
};
alleTermineKombiniert = function(){ return (db.termine||[]).map(t => Object.assign({}, t, { quelle: t.quelle === 'google' ? 'google' : 'cockpit' })); };
alleTermineFuerTag = function(key){ return gsTermineAm(key); };
oeffneTagModal = function(key){
  const l = gsTermineAm(key);
  const [y,m,d] = key.split('-').map(Number);
  document.getElementById('modalInner').innerHTML = `
    <h3>📅 ${new Date(y, m-1, d).toLocaleDateString('de-DE',{weekday:'long', day:'2-digit', month:'long', year:'numeric'})}</h3>
    <div class="tm-liste">${l.map(t => gsTerminZeile(t, false)).join('') || '<div class="vl-leer">Noch keine Termine an diesem Tag.</div>'}</div>
    <div class="modal-actions"><div></div><div class="right">
      <button class="secondary" onclick="schliesseModal()">Schließen</button>
      <button onclick="oeffneTerminModal(null,null,'${key}')">+ Neuer Termin an diesem Tag</button></div></div>`;
  document.getElementById('modalBg').classList.add('show');
};

// ── Termin-Dialog (mit Dauer, Ort, Google-Status) ──
const GS_DAUERN = [15,30,45,60,90,120,180,240];
function gsDauerText(m){ return m < 60 ? m + ' Min.' : (m % 60 ? (m/60).toLocaleString('de-DE') + ' Std.' : (m/60) + ' Std.'); }
function gsObjektLabel(o){ return (typeof aqTitel==='function' ? aqTitel(o) : (o.adresse || 'Objekt')) + (o.ort ? ' · ' + (typeof aqOrtKurz==='function' ? aqOrtKurz(o) : o.ort) : ''); }
oeffneTerminModal = function(id, googleEventId, presetDatum, vorgabe){
  let t = id ? gsT(id) : null;
  if(!t && googleEventId) t = (db.termine||[]).find(x => x.id===googleEventId || x.googleEventId===googleEventId) || null;
  const v = t || Object.assign({ datum: presetDatum || toDateKey(new Date()), uhrzeit:'', dauer:60, art:'termin' }, vorgabe || {});
  const objekte = (db.objekte||[]).slice().sort((a,b)=>(b.createdAt||0)-(a.createdAt||0));
  const kontakte = (db.kontakte||[]).slice().sort((a,b)=>String(a.name||'').localeCompare(String(b.name||''),'de'));
  const dauer = Number(v.dauer) || 60;
  const dauern = GS_DAUERN.includes(dauer) ? GS_DAUERN : GS_DAUERN.concat(dauer).sort((a,b)=>a-b);
  const c = gsCfg(), verbunden = gsVerfuegbar() && GS.st && GS.st.verbunden && c.kalenderId;
  let gInfo;
  if(!gsVerfuegbar()) gInfo = '';
  else if(!verbunden) gInfo = `Nur an diesem PC gespeichert · <a href="#" onclick="schliesseModal();gsAssistent();return false;">Google Kalender verbinden</a>`;
  else if(t && t.googleEventId) gInfo = `<span style="color:var(--green);">✓ Im Google Kalender</span>${c.kalenderName ? ' („' + akqEsc(c.kalenderName) + '“)' : ''}${t.gLink ? ` · <a href="#" onclick="window.open('${akqEsc(t.gLink)}','_blank');return false;">in Google öffnen ↗</a>` : ''}`;
  else gInfo = 'Wird beim Speichern in deinen Google Kalender eingetragen.';
  document.getElementById('modalInner').innerHTML = `
    <h3>${t ? 'Termin bearbeiten' : 'Neuer Termin'}</h3>
    <label>Titel</label><input id="m_t_titel" value="${akqEsc(v.titel||'')}" placeholder="z. B. Besichtigung Musterstraße 5">
    <div class="field-row">
      <div><label>Datum</label><input id="m_t_datum" type="date" value="${akqEsc(v.datum||'')}" oninput="if(typeof tsMT==='function')tsMT()"></div>
      <div style="min-width:110px;"><label>Uhrzeit</label><input id="m_t_zeit" type="time" step="300" value="${akqEsc(v.uhrzeit||'')}" oninput="document.getElementById('m_t_dauer').disabled=!this.value;if(typeof tsMT==='function')tsMT()"></div>
      <div style="min-width:110px;"><label>Dauer</label><select id="m_t_dauer" onchange="if(typeof tsMT==='function')tsMT()" ${v.uhrzeit ? '' : 'disabled'}>${dauern.map(m=>`<option value="${m}" ${m===dauer?'selected':''}>${gsDauerText(m)}</option>`).join('')}</select></div>
    </div>
    <div style="font-size:11px;color:var(--muted);margin-top:3px;">Ohne Uhrzeit = ganztägig.</div>
    <div id="m_t_slots" class="ts" data-ohne="${t ? akqEsc(t.id) : ''}"></div>
    <div class="field-row">
      <div><label>Art</label><select id="m_t_art" onchange="toggleEigeneArt()">${TERMIN_ARTEN.map(a=>`<option value="${a[0]}" ${(v.art||'termin')===a[0]?'selected':''}>${a[1]}</option>`).join('')}</select></div>
      <div><label>Ort</label><input id="m_t_ort" value="${akqEsc(v.ort||'')}" placeholder="Adresse oder „Telefon“"></div>
    </div>
    <div id="eigeneArtWrap" style="display:${v.art==='eigene'?'block':'none'};"><label>Eigene Bezeichnung</label><input id="m_t_art_eigene" value="${akqEsc(v.artEigene||'')}"></div>
    <div class="field-row">
      <div><label>Objekt / Lead (optional)</label><select id="m_t_objekt"><option value="">–</option>${objekte.map(o=>`<option value="${o.id}" ${v.objektId===o.id?'selected':''}>${akqEsc(gsObjektLabel(o))}</option>`).join('')}</select></div>
      <div><label>Kontakt (optional)</label><select id="m_t_kontakt"><option value="">–</option>${kontakte.map(k=>`<option value="${k.id}" ${v.kontaktId===k.id?'selected':''}>${akqEsc(k.name||'(ohne Name)')}</option>`).join('')}</select></div>
    </div>
    <label>Notiz</label><textarea id="m_t_notiz" rows="3">${akqEsc(v.notiz||'')}</textarea>
    ${verbunden ? `<label class="gs-chk"><input type="checkbox" id="m_t_lokal" ${v.nurLokal?'checked':''}> Nur am PC – nicht in den Google Kalender eintragen</label>` : ''}
    ${gInfo ? `<div class="gs-hinweis">${gInfo}</div>` : ''}
    <div class="modal-actions">
      ${t ? `<button class="secondary" onclick="loescheTermin('${t.id}')">Löschen</button>` : '<div></div>'}
      <div class="right"><button class="secondary" onclick="schliesseModal()">Abbrechen</button>
        <button onclick="speichereTermin('${t ? t.id : ''}')">Speichern</button></div>
    </div>`;
  document.getElementById('modalBg').classList.add('show');
  if(typeof tsMT==='function') tsMT();
  setTimeout(()=>{ const f = document.getElementById('m_t_titel'); if(f && !t) f.focus(); }, 30);
};
speichereTermin = function(id){
  const g = x => document.getElementById(x);
  const zeit = g('m_t_zeit').value;
  const daten = { titel: g('m_t_titel').value.trim(), datum: g('m_t_datum').value, uhrzeit: zeit, dauer: zeit ? (Number(g('m_t_dauer').value) || 60) : null,
    art: g('m_t_art').value, artEigene: g('m_t_art_eigene') ? g('m_t_art_eigene').value.trim() : '', ort: g('m_t_ort').value.trim(),
    objektId: g('m_t_objekt').value || null, kontaktId: g('m_t_kontakt').value || null, notiz: g('m_t_notiz').value.trim(),
    nurLokal: g('m_t_lokal') ? g('m_t_lokal').checked : !!(id && gsT(id) && gsT(id).nurLokal) };
  if(!daten.titel){ g('m_t_titel').focus(); akqToast('Bitte einen Titel eingeben.'); return; }
  if(!daten.datum){ g('m_t_datum').focus(); akqToast('Bitte ein Datum wählen.'); return; }
  let t = id ? gsT(id) : null;
  if(t){
    const alt = gsKurz(t);
    Object.assign(t, daten); t.geaendertAm = Date.now();
    if(gsKurz(t) !== alt) gsObjLog(t, gsArtLabel(t) + ' verlegt auf ' + gsKurzFest(t));
  } else {
    t = Object.assign({ id: uid(), createdAt: Date.now(), geaendertAm: Date.now() }, daten);
    db.termine.push(t); gsObjLog(t, gsLogText(t));
  }
  save(); schliesseModal(); gsNachAenderung(); gsPlanen(500);
  akqToast(gsAktiv() && !t.nurLokal ? '📅 Gespeichert – geht in deinen Google Kalender' : '📅 Termin gespeichert');
};
loescheTermin = function(id, googleEventId){
  const t = (db.termine||[]).find(x => x.id===id || (googleEventId && x.googleEventId===googleEventId)); if(!t) return;
  bestaetigeUnten(t.googleEventId && gsAktiv() ? 'Termin löschen? Er wird auch aus deinem Google Kalender gelöscht.' : 'Termin wirklich löschen?', ()=>{
    db.termine = db.termine.filter(x => x.id !== t.id);
    gsObjLog(t, 'Termin gelöscht: ' + gsLogText(t));
    save(); schliesseModal(); gsNachAenderung(); gsPlanen(500);
  });
};
function gsNachAenderung(){
  if(aktuelleAnsicht === 'akquise' && typeof aq2Liste === 'function'){ aq2Liste(); try{ renderNav(); }catch(e){} }
  else renderMain();
}

// ── Einrichtung & Einstellungen ──
function gsModal(html, breit){
  const inner = document.getElementById('modalInner'); inner.innerHTML = html;
  if(breit){ inner.style.width = breit + 'px'; inner.style.maxWidth = '94vw'; }
  document.getElementById('modalBg').classList.add('show');
}
function gsLink(url, text){ return `<a href="#" onclick="window.open('${url}','_blank');return false;">${text} ↗</a>`; }
async function gsAssistent(){
  if(!gsVerfuegbar()){ alert('Die Google-Kalender-Anbindung gibt es nur in der PC-Version.'); return; }
  await gsStatusLaden();
  const c = gsCfg();
  if(GS.st.verbunden && c.kalenderId) return gsEinstellungen();
  if(GS.st.verbunden) return gsKalenderWahl();
  return gsAnleitung();
}
// v15: Verbindung über ein eigenes Google-Skript (Apps Script) im Kalender-Konto – bleibt dauerhaft verbunden
const GS_SKRIPT_VORLAGE = "/**\n * MaklerCockpit – Kalender-Brücke\n * Verbindet dein MaklerCockpit (PC-Programm) dauerhaft mit deinem Google Kalender.\n * Das Skript läuft nur in DEINEM Google-Konto. Den Schlüssel unten nicht weitergeben.\n */\nconst SCHLUESSEL = '%%SCHLUESSEL%%';\nconst API = 'https://www.googleapis.com/calendar/v3';\n\nfunction doPost(e) {\n  let a;\n  try { a = JSON.parse(e.postData.contents); } catch (x) { return antwort_({ ok: false, status: 400, fehler: 'Ungültige Anfrage' }); }\n  if (!a || a.key !== SCHLUESSEL) return antwort_({ ok: false, status: 403, code: 'schluessel', fehler: 'Falscher Schlüssel' });\n  try {\n    if (a.aktion === 'test') {\n      const r = abruf_('GET', '/users/me/calendarList', { maxResults: 1 }, null);\n      return antwort_({ ok: r.ok, status: r.status, data: r.data, email: CalendarApp.getDefaultCalendar().getId(), version: 1 });\n    }\n    const pfad = String(a.pfad || '');\n    if (!/^\\/(users\\/me\\/calendarList|calendars\\/[^?#\\s]+)$/.test(pfad)) return antwort_({ ok: false, status: 400, fehler: 'Pfad nicht erlaubt' });\n    return antwort_(abruf_(String(a.methode || 'GET'), pfad, a.query || {}, a.body || null));\n  } catch (x) {\n    return antwort_({ ok: false, status: 0, fehler: String((x && x.message) || x) });\n  }\n}\n\nfunction abruf_(methode, pfad, query, body) {\n  const q = Object.keys(query)\n    .filter(function (k) { return query[k] !== undefined && query[k] !== null && query[k] !== ''; })\n    .map(function (k) { return [].concat(query[k]).map(function (v) { return encodeURIComponent(k) + '=' + encodeURIComponent(v); }).join('&'); })\n    .join('&');\n  const opt = { method: methode.toLowerCase(), headers: { Authorization: 'Bearer ' + ScriptApp.getOAuthToken() }, muteHttpExceptions: true };\n  if (body) { opt.contentType = 'application/json'; opt.payload = JSON.stringify(body); }\n  const r = UrlFetchApp.fetch(API + pfad + (q ? '?' + q : ''), opt);\n  const st = r.getResponseCode();\n  const txt = r.getContentText();\n  let data = null;\n  try { data = txt ? JSON.parse(txt) : null; } catch (x) {}\n  return { ok: st >= 200 && st < 300, status: st, data: data };\n}\n\nfunction antwort_(o) {\n  return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON);\n}\n\nfunction doGet() {\n  return ContentService.createTextOutput('MaklerCockpit Kalender-Brücke läuft.');\n}\n";
async function gsAnleitung(){
  const sk = await gsRuf('skriptSchluessel');
  GS.skriptCode = sk && sk.schluessel ? GS_SKRIPT_VORLAGE.replace('%%SCHLUESSEL%%', sk.schluessel) : '';
  const vorschau = GS.skriptCode.split('\n').slice(0, 9).join('\n');
  gsModal(`
    <h3>📅 Google Kalender verbinden</h3>
    <div class="gs-intro">Danach sind deine Termine am PC und am Handy immer gleich – <b>dauerhaft verbunden</b>, ohne erneutes Anmelden. Dafür legst du einmal ein kleines Google-Skript in deinem Kalender-Konto an: ca. 5 Minuten, kostenlos, keine Website und keine Cloud-App nötig. Das Skript gehört nur dir und ist mit einem geheimen Schlüssel geschützt.</div>
    ${GS.anmeldeFehler ? `<div class="gs-fehler">⚠️ ${akqEsc(GS.anmeldeFehler)}</div>` : ''}
    <ol class="gs-schritte">
      <li><b>Neues Skript öffnen</b> – ${gsLink('https://script.google.com/home/projects/create', 'script.google.com')}<br>
        Oben rechts prüfen, dass du mit dem Konto angemeldet bist, in dem dein <b>Kalender</b> ist (sonst dort wechseln). Oben links auf <i>Unbenanntes Projekt</i> klicken → <i>MaklerCockpit Kalender</i> nennen.</li>
      <li><b>Code einfügen</b> – im Editor den vorhandenen Code komplett löschen, diesen einfügen und speichern (<b>Strg + S</b>):
        <div class="gs-code"><pre>${akqEsc(vorschau)}\n…</pre><button class="secondary tiny" onclick="gsCodeKopieren()">📋 Code kopieren</button></div></li>
      <li><b>Kalender-Dienst hinzufügen</b> – links bei <i>Dienste</i> auf <b>＋</b> → <i>Google Calendar API</i> auswählen → <b>Hinzufügen</b>.</li>
      <li><b>Bereitstellen</b> – oben rechts <b>Bereitstellen</b> → <i>Neue Bereitstellung</i> → beim Zahnrad ⚙ <b>Web-App</b> wählen → Ausführen als: <b>Ich</b> → Wer hat Zugriff: <b>Jeder</b> → <b>Bereitstellen</b>.</li>
      <li><b>Erlauben</b> – <i>Zugriff autorisieren</i> → dein Kalender-Konto → bei „Google hat diese App nicht überprüft“: <b>Erweitert</b> → <b>Zu MaklerCockpit Kalender wechseln (unsicher)</b> → <b>Zulassen</b>. Die Warnung kommt, weil es dein eigenes Skript ist.</li>
      <li><b>Web-App-URL hier einfügen</b> – die angezeigte Adresse (endet auf <i>/exec</i>) kopieren:
        <div class="gs-url"><input id="gsUrl" value="${akqEsc(GS.urlEntwurf||'')}" placeholder="https://script.google.com/macros/s/…/exec" onkeydown="if(event.key==='Enter')gsSkriptVerbinden()"><button id="gsUrlKnopf" onclick="gsSkriptVerbinden()">Verbinden</button></div>
        <div id="gsUrlStatus" class="gs-url-status"></div></li>
    </ol>
    <details class="gs-details"><summary>Andere Methode: eigene App in der Google Cloud</summary>
      <div class="gs-intro" style="margin-top:8px;">Nur sinnvoll, wenn du eine eigene Website mit Datenschutzerklärung hast – sonst läuft die Verbindung dort alle 7 Tage ab. <a href="#" onclick="gsAnleitungCloud();return false;">Zur Cloud-Anleitung</a></div></details>
    <div class="modal-actions"><div></div><div class="right"><button class="secondary" onclick="schliesseModal()">Schließen</button></div></div>`, 680);
}
function gsCodeKopieren(){
  const code = GS.skriptCode || '';
  const fertig = () => akqToast('📋 Code kopiert – jetzt im Skript-Editor einfügen (Strg + V)', 3200);
  const ersatz = () => { const t = document.createElement('textarea'); t.value = code; t.style.position = 'fixed'; t.style.opacity = '0'; document.body.appendChild(t); t.select(); try{ document.execCommand('copy'); fertig(); }catch(e){ akqToast('Kopieren hat nicht geklappt'); } t.remove(); };
  try{ if(navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(code).then(fertig, ersatz); else ersatz(); }catch(e){ ersatz(); }
}
async function gsSkriptVerbinden(){
  const f = document.getElementById('gsUrl'), url = f ? f.value.trim() : '';
  if(!url){ if(f) f.focus(); akqToast('Bitte die Web-App-URL einfügen'); return; }
  GS.urlEntwurf = url;
  const k = document.getElementById('gsUrlKnopf'), st = document.getElementById('gsUrlStatus');
  if(k) k.disabled = true;
  if(st) st.innerHTML = '<span class="gs-dreh klein"></span> Prüfe die Verbindung zu deinem Skript …';
  const r = await gsRuf('skriptVerbinden', { url });
  if(!r.ok){ GS.anmeldeFehler = r.fehler || 'Verbindung fehlgeschlagen'; gsAnleitung(); return; }
  GS.anmeldeFehler = ''; GS.urlEntwurf = ''; GS.st = r; GS.fehler = ''; GS.code = '';
  gsKalenderWahl();
}
function gsAnleitungCloud(){
  const st = GS.st || {};
  const schritte = `
    <ol class="gs-schritte">
      <li><b>Projekt anlegen</b> – ${gsLink('https://console.cloud.google.com/projectcreate', 'Google Cloud öffnen')}<br>
        Mit deinem Google-Konto anmelden (das mit deinem Kalender). Projektname z. B. <i>MaklerCockpit</i> → <i>Erstellen</i>. Danach oben links prüfen, dass das neue Projekt ausgewählt ist. Kein Abrechnungskonto nötig.</li>
      <li><b>Kalender-Schnittstelle einschalten</b> – ${gsLink('https://console.cloud.google.com/apis/library/calendar-json.googleapis.com', 'Google Calendar API')}<br>
        Auf <i>Aktivieren</i> klicken.</li>
      <li><b>App anlegen</b> – ${gsLink('https://console.cloud.google.com/auth/overview', 'Google Auth Platform')}<br>
        <i>Jetzt starten</i> (Get started): App-Name <i>MaklerCockpit</i>, deine E-Mail → Zielgruppe <i>Extern</i> → Kontakt-E-Mail → zustimmen → <i>Erstellen</i>.</li>
      <li><b>App veröffentlichen</b> – ${gsLink('https://console.cloud.google.com/auth/audience', 'Zielgruppe (Audience)')}<br>
        Bei „Veröffentlichungsstatus: Test“ auf <i>App veröffentlichen</i>. Dafür verlangt Google eine eigene Website mit Datenschutzerklärung. Ohne: unter <i>Testnutzer</i> dein Kalender-Konto eintragen – dann läuft die Verbindung aber alle 7 Tage ab.</li>
      <li><b>Zugangsdatei erstellen</b> – ${gsLink('https://console.cloud.google.com/auth/clients', 'Clients')}<br>
        <i>Client erstellen</i> → Anwendungstyp <b>Desktop-App</b> → Name <i>MaklerCockpit PC</i> → <i>Erstellen</i> → im Fenster <b>JSON herunterladen</b>. <span class="gs-wichtig">Das geht nur in diesem Moment</span> – sonst einfach einen neuen Client anlegen.</li>
      <li><b>Datei hier auswählen</b> – danach öffnet sich der Browser zur Anmeldung.</li>
    </ol>`;
  gsModal(`
    <h3>📅 Google Kalender – über eigene Cloud-App</h3>
    <div class="gs-intro">Danach sind deine Termine am PC und am Handy immer gleich: Was du hier einträgst, steht sofort in Google – und was du am Handy einträgst oder verschiebst, kommt automatisch hierher. Einmalig ca. 10 Minuten, kostenlos. Deine Daten gehen nur zwischen diesem PC und deinem eigenen Google-Konto hin und her.</div>
    ${GS.anmeldeFehler ? `<div class="gs-fehler">⚠️ ${akqEsc(GS.anmeldeFehler)}</div>` : ''}
    ${st.eingerichtet ? `<div class="gs-ok">✓ Zugangsdatei ist hinterlegt${st.projekt ? ' (Projekt „' + akqEsc(st.projekt) + '“)' : ''}. <a href="#" onclick="document.getElementById('gsDatei').click();return false;">Andere Datei wählen</a></div>
      <details class="gs-details"><summary>Anleitung anzeigen</summary>${schritte}</details>` : schritte}
    <input type="file" id="gsDatei" accept=".json,application/json" style="display:none" onchange="gsDateiGewaehlt(this.files)">
    ${st.eingerichtet ? '' : `<div class="gs-drop" id="gsDrop" onclick="document.getElementById('gsDatei').click()" ondragover="event.preventDefault();this.classList.add('an')" ondragleave="this.classList.remove('an')" ondrop="event.preventDefault();this.classList.remove('an');gsDateiGewaehlt(event.dataTransfer.files)">
        📄 <b>Zugangsdatei auswählen</b><small>client_secret_….json – oder hierher ziehen</small></div>
      <details class="gs-details"><summary>Client-ID und Schlüssel lieber von Hand eingeben</summary>
        <label>Client-ID</label><input id="gsId" placeholder="….apps.googleusercontent.com">
        <label>Clientschlüssel (Client-Secret)</label><input id="gsSec" placeholder="GOCSPX-…">
        <button class="secondary" style="margin-top:8px;" onclick="gsVonHand()">Übernehmen & anmelden</button></details>`}
    <div class="gs-tipp">Beim Anmelden zeigt Google „<i>Google hat diese App nicht überprüft</i>“ – das ist bei deiner eigenen App normal: <b>Erweitert</b> → <b>Zu MaklerCockpit wechseln</b> → beim Kalender das Häkchen setzen → <b>Weiter</b>.</div>
    <div class="modal-actions"><div></div><div class="right">
      <button class="secondary" onclick="gsAnleitung()">← Zurück</button>
      ${st.eingerichtet ? `<button onclick="gsAnmelden()">Mit Google anmelden</button>` : ''}</div></div>`, 660);
}
function gsDateiGewaehlt(files){
  const f = files && files[0]; if(!f) return;
  const rd = new FileReader();
  rd.onload = async () => {
    const r = await gsRuf('einrichten', { json: String(rd.result||'') });
    if(!r.ok){ GS.anmeldeFehler = r.fehler; gsAnleitungCloud(); return; }
    GS.anmeldeFehler = ''; GS.st = r; gsAnmelden();
  };
  rd.readAsText(f);
}
async function gsVonHand(){
  const r = await gsRuf('einrichten', { clientId: (document.getElementById('gsId')||{}).value, secret: (document.getElementById('gsSec')||{}).value });
  if(!r.ok){ GS.anmeldeFehler = r.fehler; gsAnleitungCloud(); return; }
  GS.anmeldeFehler = ''; GS.st = r; gsAnmelden();
}
async function gsAnmelden(){
  gsModal(`<h3>🌐 Anmeldung im Browser</h3>
    <div class="gs-warte"><span class="gs-dreh"></span><div>Dein Browser ist geöffnet. Melde dich dort mit dem Google-Konto an, in dem dein Kalender ist.</div></div>
    <ol class="gs-schritte kurz">
      <li>Konto auswählen</li>
      <li>„Google hat diese App nicht überprüft“ → <b>Erweitert</b> → <b>Zu MaklerCockpit wechseln</b></li>
      <li>Beim Kalender-Zugriff das <b>Häkchen setzen</b> → <b>Weiter</b></li>
      <li>Fertig – das Browserfenster kannst du schließen.</li>
    </ol>
    <div class="gs-tipp">Zeigt Google „<i>Zugriff blockiert</i>“ / „<i>access_denied</i>“ oder „nur für Testnutzer“? Dann fehlt Schritt 4 (<i>App veröffentlichen</i>) – nachholen, hier abbrechen und neu anmelden.</div>
    <div class="modal-actions"><div></div><div class="right"><button class="secondary" onclick="gsRuf('abbrechen')">Abbrechen</button></div></div>`, 560);
  const r = await gsRuf('verbinden');
  if(!r.ok){ GS.anmeldeFehler = r.fehler || 'Anmeldung fehlgeschlagen'; await gsStatusLaden(); if(document.getElementById('modalBg').classList.contains('show')) gsAnleitungCloud(); return; }
  GS.anmeldeFehler = ''; GS.st = r; GS.fehler = ''; GS.code = '';
  gsKalenderWahl();
}
async function gsKalenderWahl(){
  gsModal(`<h3>📅 Welcher Kalender?</h3><div class="gs-warte"><span class="gs-dreh"></span><div>Lade deine Kalender …</div></div>`, 600);
  const r = await gsApi('GET', '/users/me/calendarList', { minAccessRole:'writer', maxResults:'250' });
  if(!r.ok){
    gsModal(`<h3>📅 Kalender laden</h3><div class="gs-fehler">⚠️ ${akqEsc(r.fehler || 'Fehler beim Laden der Kalender')}</div>
      <div class="modal-actions"><div></div><div class="right"><button class="secondary" onclick="schliesseModal()">Schließen</button><button onclick="gsKalenderWahl()">Erneut versuchen</button></div></div>`, 600);
    return;
  }
  const c = gsCfg();
  const liste = ((r.data||{}).items||[]).sort((a,b)=> (b.primary?1:0)-(a.primary?1:0) || String(a.summary).localeCompare(String(b.summary),'de'));
  GS.kalender = liste;
  const ab = gsTagPlus(toDateKey(new Date()), -GS_ZURUECK);
  const nurPc = (db.termine||[]).filter(t => !t.googleEventId && !t.nurLokal && t.datum && t.datum >= ab).length;
  const aktuell = c.kalenderId || (liste.find(k=>k.primary)||liste[0]||{}).id;
  gsModal(`<h3>📅 Welcher Kalender?</h3>
    <div class="gs-intro">Verbunden als <b>${akqEsc(GS.st.email||'')}</b>. In diesen Kalender trägt das MaklerCockpit ein – und holt von dort deine Termine.</div>
    <div class="gs-kal">${liste.map(k=>`<label class="gs-kal-z"><input type="radio" name="gsKal" value="${akqEsc(k.id)}" ${k.id===aktuell?'checked':''}>
      <span class="gs-farbe" style="background:${akqEsc(k.backgroundColor||'#60a5fa')}"></span><span>${akqEsc(k.summaryOverride||k.summary||k.id)}${k.primary?' <small>Hauptkalender</small>':''}</span></label>`).join('') || '<div class="vl-leer">Keine beschreibbaren Kalender gefunden.</div>'}</div>
    ${nurPc ? `<div class="gs-frage"><b>${nurPc} Termin${nurPc===1?'':'e'}</b> ${nurPc===1?'steht':'stehen'} bisher nur am PC (ab ${typeof aqDatum==='function' ? aqDatum(ab) : ab}):
      <label class="gs-chk"><input type="radio" name="gsErst" value="hoch" checked><span>in den Google Kalender eintragen<small>Gleiche Termine (gleicher Tag, Uhrzeit und Titel) werden erkannt und nicht doppelt angelegt.</small></span></label>
      <label class="gs-chk"><input type="radio" name="gsErst" value="pc"><span>nur am PC lassen</span></label></div>` : ''}
    <div class="gs-intro" style="margin-top:10px;">Abgeglichen werden Termine von 30 Tagen zurück bis 13 Monate voraus – automatisch beim Start, alle 5 Minuten und gleich nach jeder Änderung.</div>
    <div class="modal-actions"><div></div><div class="right"><button class="secondary" onclick="schliesseModal()">Später</button>
      <button onclick="gsKalenderUebernehmen()" ${liste.length?'':'disabled'}>Abgleich starten</button></div></div>`, 600);
}
function gsVerknuepfungLoesen(googleTermineEntfernen){
  db.termine = (db.termine||[]).filter(t => !(googleTermineEntfernen && t.quelle === 'google' && t.googleEventId));
  (db.termine||[]).forEach(t => { if(t.googleEventId) gsTrenneTermin(t); });
  gsCfg().bekannt = {};
}
async function gsKalenderUebernehmen(){
  const w = document.querySelector('input[name="gsKal"]:checked'); if(!w) return;
  const k = (GS.kalender||[]).find(x=>x.id===w.value) || { id:w.value };
  const c = gsCfg();
  const wechsel = (c.kalenderId && c.kalenderId !== k.id) || (c.konto && GS.st && GS.st.email && c.konto !== GS.st.email);
  if(wechsel) gsVerknuepfungLoesen(true);
  const erst = document.querySelector('input[name="gsErst"]:checked');
  if(erst && erst.value === 'pc'){ const ab = gsTagPlus(toDateKey(new Date()), -GS_ZURUECK); (db.termine||[]).forEach(t => { if(!t.googleEventId && t.datum && t.datum >= ab) t.nurLokal = true; }); }
  Object.assign(c, { kalenderId: k.id, kalenderName: k.primary ? 'Hauptkalender' : (k.summaryOverride || k.summary || 'Kalender'), konto: (GS.st && GS.st.email) || c.konto || '', pausiert: false, seit: c.seit || Date.now() });
  GS.signatur = null; _gsSaveOrig();
  schliesseModal();
  if(aktuelleAnsicht === 'termine') renderMain();
  gsAnzeigen(false);
  akqToast('⟳ Erster Abgleich mit Google läuft …', 2500);
  await gsSync('manuell');
}
async function gsEinstellungen(){
  const c = gsCfg(), st = GS.st || {};
  const verkn = (db.termine||[]).filter(t=>t.googleEventId).length, lokal = (db.termine||[]).filter(t=>t.nurLokal).length;
  const z = c.letzteZahlen;
  gsModal(`<h3>📅 Google Kalender</h3>
    <div class="gs-leiste" style="margin:0 0 12px;"><span class="gs-punkt ${c.pausiert?'grau':GS.fehler&&GS.code!=='teil'?'rot':'gruen'}"></span><div class="gs-txt"><b>${c.pausiert?'Abgleich pausiert':'Verbunden'}</b><small>${akqEsc(st.email||'')} · Kalender „${akqEsc(c.kalenderName||'')}“</small></div></div>
    ${GS.fehler ? `<div class="gs-fehler">⚠️ ${akqEsc(GS.fehler)}</div>` : ''}
    <div class="gs-werte">
      <div><span>Letzter Abgleich</span><b>${c.letzterSync ? gsVor(c.letzterSync) : '–'}</b></div>
      <div><span>Verknüpfte Termine</span><b>${verkn}</b></div>
      <div><span>Nur am PC</span><b>${lokal}</b></div>
      <div><span>Zeitraum</span><b>−30 Tage bis +13 Monate</b></div>
    </div>
    ${z ? `<div class="gs-intro">Zuletzt: ${gsZahlenText(z) || 'keine Änderungen'}.</div>` : ''}
    <div class="gs-knoepfe">
      <button onclick="schliesseModal();gsSync('manuell')">⟳ Jetzt abgleichen</button>
      <button class="secondary" onclick="gsKalenderWahl()">Anderen Kalender wählen</button>
      <button class="secondary" onclick="gsPause()">${c.pausiert ? '▶ Abgleich fortsetzen' : '⏸ Abgleich pausieren'}</button>
      <button class="secondary" onclick="gsTrennen(false)">Verbindung trennen</button>
    </div>
    <div class="gs-intro" style="margin-top:12px;">${st.modus === 'skript' ? `Verbunden über dein Google-Skript „MaklerCockpit Kalender“ – bleibt dauerhaft verbunden. Adresse und Schlüssel liegen verschlüsselt in <i>Dokumente\\MaklerCockpit\\google-konto.json</i>, nicht in deinen Daten-Sicherungen. Abschalten geht jederzeit auch bei ${gsLink('https://script.google.com/home', 'script.google.com')} (Skript löschen).` : `Der Zugang liegt verschlüsselt (nur mit deinem Windows-Konto lesbar) in <i>Dokumente\\MaklerCockpit\\google-konto.json</i> – nicht in deinen Daten-Sicherungen. Widerrufen kannst du ihn jederzeit auch bei Google unter ${gsLink('https://myaccount.google.com/connections', 'Drittanbieter-Apps')}.`}
      <a href="#" onclick="gsTrennen(true);return false;" style="color:var(--muted);">Zugangsdaten ganz löschen</a></div>
    <div class="modal-actions"><div></div><div class="right"><button class="secondary" onclick="schliesseModal()">Schließen</button></div></div>`, 620);
}
function gsPause(){ const c = gsCfg(); c.pausiert = !c.pausiert; _gsSaveOrig(); gsAnzeigen(false); gsEinstellungen(); if(!c.pausiert) gsSync('manuell'); }
async function gsTrennen(alles){
  if(!confirm(alles ? 'Verbindung trennen und die Zugangsdatei vom PC löschen?\n\nDeine Termine bleiben am PC und in Google erhalten.' : 'Verbindung zum Google Kalender trennen?\n\nDeine Termine bleiben am PC und in Google erhalten. Später neu verbinden geht jederzeit – gleiche Termine werden dann wiedererkannt.')) return;
  await gsRuf('trennen', { allesLoeschen: !!alles });
  gsVerknuepfungLoesen(false);
  const c = gsCfg(); c.kalenderId = ''; c.kalenderName = ''; c.pausiert = false;
  GS.fehler = ''; GS.code = ''; GS.signatur = null; _gsSaveOrig();
  await gsStatusLaden(); schliesseModal(); gsAnzeigen(true);
  if(aktuelleAnsicht === 'termine') renderMain();
  akqToast('Google Kalender getrennt');
}

// Hinweis oben rechts (Glocke), wenn die Verbindung abgelaufen ist
const _gsHinweise = tbHinweise;
tbHinweise = function(){
  const l = _gsHinweise();
  try{
    const c = gsCfg();
    if(gsVerfuegbar() && c.kalenderId && GS.st && !GS.st.verbunden) l.unshift({ic:'⚠️', t:'Google-Kalender-Verbindung abgelaufen', s:'Neu verbinden – deine Termine bleiben erhalten', f:'gsAssistent()'});
    else if(c.kalenderId && GS.fehler && GS.code !== 'teil' && GS.code !== 'netz') l.unshift({ic:'⚠️', t:'Abgleich mit Google hat nicht geklappt', s:GS.fehler.slice(0,90), f:`wechsleAnsicht('termine')`});
  }catch(e){}
  return l;
};

// Start: Status holen, dann regelmäßig abgleichen
window.addEventListener('load', ()=>{
  if(!gsVerfuegbar()) return;
  gsStatusLaden().then(()=>{ gsAnzeigen(false); setTimeout(()=>{ if(gsAktiv()) gsSync('start'); }, 1200); });
  setInterval(()=>{ if(gsAktiv()) gsSync('intervall'); }, 5*60*1000);
  window.addEventListener('focus', ()=>{ if(gsAktiv() && Date.now() - GS.letzterVersuch > 2*60*1000) gsSync('fokus'); });
  window.addEventListener('online', ()=>{ if(gsAktiv()) gsSync('fokus'); });
});
