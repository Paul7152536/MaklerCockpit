// ═══ MaklerCockpit v28 – Durchsicht: Sicherheit, Handy-Ansicht, kleine Verbesserungen ═══
// 1) Notizen (formatierter Text) nur mit harmlosen Elementen anzeigen – kein Skript, keine Ereignis-Attribute
const MC28_ELEMENTE = new Set(['B', 'STRONG', 'I', 'EM', 'U', 'S', 'STRIKE', 'SUB', 'SUP', 'MARK', 'SMALL', 'BIG', 'FONT', 'BR', 'HR', 'DIV', 'P', 'SPAN', 'BLOCKQUOTE', 'PRE', 'CODE',
  'UL', 'OL', 'LI', 'H1', 'H2', 'H3', 'H4', 'H5', 'H6', 'A', 'IMG', 'TABLE', 'THEAD', 'TBODY', 'TFOOT', 'TR', 'TD', 'TH', 'CAPTION', 'COLGROUP', 'COL']);
const MC28_WEG = /^(SCRIPT|STYLE|IFRAME|FRAME|FRAMESET|OBJECT|EMBED|APPLET|SVG|MATH|TEMPLATE|NOSCRIPT|LINK|META|BASE|FORM|INPUT|BUTTON|SELECT|TEXTAREA|VIDEO|AUDIO|SOURCE|TRACK|CANVAS|PORTAL)$/i;
function mc28SicherHtml(html){
  const s = String(html == null ? '' : html);
  if(!/[<&]/.test(s)) return s;
  const t = document.createElement('template'); t.innerHTML = s;   // Vorlage = inaktiv: nichts wird geladen oder ausgeführt
  const geh = knoten => {
    for(const k of Array.from(knoten.childNodes)){
      if(k.nodeType === 3) continue;
      if(k.nodeType !== 1){ k.remove(); continue; }
      const tag = k.tagName.toUpperCase();
      if(MC28_WEG.test(tag)){ k.remove(); continue; }
      geh(k);
      if(!MC28_ELEMENTE.has(tag)){ k.replaceWith(...Array.from(k.childNodes)); continue; }
      for(const a of Array.from(k.attributes)){
        const n = a.name.toLowerCase(), v = String(a.value || '').trim();
        const ok = (n === 'href' && tag === 'A' && /^(https?:|mailto:|tel:)/i.test(v)) ||
          (n === 'src' && tag === 'IMG' && /^(data:image\/(png|jpe?g|gif|webp);base64,|https:)/i.test(v)) ||
          (n === 'style' && !/url\s*\(|expression|javascript:|@import|behavior/i.test(v)) ||
          (['color', 'size', 'face'].includes(n) && tag === 'FONT') || (['colspan', 'rowspan'].includes(n) && /^T[DH]$/.test(tag)) || (n === 'alt' && tag === 'IMG');
        if(!ok) k.removeAttribute(a.name);
      }
      if(tag === 'A'){ k.setAttribute('target', '_blank'); k.setAttribute('rel', 'noopener noreferrer'); }
    }
  };
  geh(t.content);
  const d = document.createElement('div'); d.appendChild(t.content); return d.innerHTML;
}
// 2) Telefon/E-Mail sicher in Links
function mc28Tel(t){ return esc(String(t || '').replace(/[^\d+]/g, '')); }
function mc28Mail(m){ return esc(encodeURI(String(m || '').trim())); }
// 3) Datum deutsch (2026-11-11 → 11.11.2026)
function mc28Datum(iso){ const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(String(iso || '')); return m ? `${m[3]}.${m[2]}.${m[1]}` : esc(iso || ''); }
// 4) Gesprächsleitfaden: Einstieg passend zur Herkunft des Leads
function mc28LeitfadenStart(o){
  o = o || {};
  const q = String(o.quelle || '') + ' ' + String(o.link || '') + ' ' + String(o.quelleText || '');
  let wo = 'Ich bin auf Ihre Immobilie aufmerksam geworden.';
  if(typeof vl26IstZeitung === 'function' ? vl26IstZeitung(o) : /zeitung/i.test(q)) wo = 'Ich bin auf Ihre Immobilienanzeige in der Zeitung aufmerksam geworden.';
  else if(/kleinanzeigen/i.test(q)) wo = 'Ich bin auf Ihre Anzeige bei Kleinanzeigen aufmerksam geworden.';
  else if(/immobilienscout|immoscout|is24/i.test(q)) wo = 'Ich bin auf Ihr Inserat bei ImmoScout24 aufmerksam geworden.';
  else if(/immowelt/i.test(q)) wo = 'Ich bin auf Ihr Inserat bei Immowelt aufmerksam geworden.';
  else if(/immonet/i.test(q)) wo = 'Ich bin auf Ihr Inserat bei Immonet aufmerksam geworden.';
  else if(/markt\.de|quoka|portal|inserat|https?:/i.test(q)) wo = 'Ich bin auf Ihr Inserat im Internet aufmerksam geworden.';
  else if(/empfehlung|tipp/i.test(q)) wo = 'Ich habe Ihre Nummer über eine Empfehlung bekommen.';
  const frage = o.auftragsart === 'vermietung' ? 'ob die Wohnung noch zu vermieten ist' : 'ob das Objekt noch zum Verkauf steht';
  return `„Guten Tag, mein Name ist Paul Görner. ${wo} Ich wollte kurz fragen, ${frage}?“`;
}
function mc28LeitfadenZu(o){
  try{ return !!(o && o.id && typeof ob26Bereich === 'function' && ob26Bereich(o) === 'betreut'); }catch(e){ return false; }
}
// 5) Marketing-Bereich an der Seitenleiste ausrichten (PC) bzw. ganzer Bildschirm (Handy)
function mc28MarketingLage(){
  const div = document.getElementById('marketingOverlay'); if(!div) return;
  const nav = document.getElementById('nav');
  const handy = window.matchMedia && window.matchMedia('(max-width: 760px)').matches;
  const b = !handy && nav ? Math.round(nav.getBoundingClientRect().width) : 0;
  div.style.left = (b > 40 ? b : 0) + 'px';
  if(handy){ div.style.zIndex = '400'; } else div.style.zIndex = '50';
}
const _mc28Overlay = aktualisiereMarketingOverlay;
aktualisiereMarketingOverlay = function(){ const r = _mc28Overlay.apply(this, arguments); try{ mc28MarketingLage(); }catch(e){} return r; };
window.addEventListener('resize', () => { try{ if(aktuelleAnsicht === 'marketing') mc28MarketingLage(); }catch(e){} });
// 6) Angaben aus der Zeit vor v24: verständliche Quelle statt Versionsnummer
function mc28Quellen(){
  let n = 0;
  for(const o of db.objekte || []) for(const k of Object.keys(o.angaben || {})) for(const w of (o.angaben[k].werte || [])) if(w.quelle === 'Bestand vor v24'){ w.quelle = 'aus den Objektdaten'; n++; }
  return n;
}
window.addEventListener('load', () => { try{ if(mc28Quellen()) save(); }catch(e){ console.error('mc28', e); } });
