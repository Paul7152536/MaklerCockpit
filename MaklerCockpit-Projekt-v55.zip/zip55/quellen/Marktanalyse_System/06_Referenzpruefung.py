"""Historische Rechenprüfungen, kein produktives Bewertungsmodell.
Aufruf: python3 06_Referenzpruefung.py
Nur Python-Standardbibliothek erforderlich.
"""
from decimal import Decimal as D
import json
from pathlib import Path
p = Path(__file__).parent
seed = json.loads((p / '05_Referenzdaten_Wuhletal.json').read_text())
f = {x['field']: D(str(x['value'])) for x in seed['facts']}
checks = {
    'Grundstückssumme': f['plot_buildable'] + f['plot_road'] == D('551'),
    'Wohnfläche mit Terrasse': f['living_internal'] + f['terrace_gross'] * f['terrace_share'] == f['living_with_terrace'],
    'Vorläufiger Sachwert': f['building_residual_document'] + f['land_buildable'] == f['preliminary_asset'],
    'Sieben getrennte Referenzen': len({x['id'] for x in seed['comparables']}) == 7,
    'Einheit wGF erhalten': all('price_eur_per_m2_wgf_reported' in x for x in seed['comparables']),
}
extras = sum(f[x] for x in ['garage_adjustment', 'awning_adjustment', 'kitchen_adjustment', 'heating_adjustment'])
market = f['preliminary_asset'] * f['factor_override']
result = market + extras + f['land_road']
low_factor_scenario = f['preliminary_asset'] * f['factor_model_rounded'] + extras + f['land_road']
checks['Besondere Merkmale'] = extras == D('8000')
checks['Dokumentergebnis ungerundet'] = abs(result - D('418068.90')) < D('0.01')
report = {
    'role': 'historische Reproduktion; keine aktuelle Neubewertung',
    'checks': checks,
    'market_adjusted_exact_eur': str(market),
    'historical_result_exact_eur': str(result),
    'factor_074_scenario_eur': str(low_factor_scenario),
    'override_effect_eur': str(result - low_factor_scenario),
    'printed_input_reconstruction_eur': str(f['bgf_rounded'] * f['nhk_house'] * f['building_index']),
    'document_manufacturing_cost_eur': '387953.11',
    'warnings': ['Seite 28: Textwert 409828.90 weicht um ca. 100 EUR von Rechnung ab.', 'Herstellungskosten stimmen bis auf Cent-Rundung; zentrale Rundungsregel erforderlich.', 'Historische Anpassungen und 0.90-Override sind nicht für neue Fälle freigegeben.'],
}
print(json.dumps(report, indent=2, ensure_ascii=False))
if not all(checks.values()):
    raise SystemExit('Referenzprüfung fehlgeschlagen')
