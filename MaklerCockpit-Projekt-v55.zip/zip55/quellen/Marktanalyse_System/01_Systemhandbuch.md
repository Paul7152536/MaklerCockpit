# GÖRNER IMMOBILIEN | Marktanalyse-System
## Umsetzbare Spezifikation für ein separates KI-System
Version 1.0 | 13.11.2026 | Schwerpunkt Berlin und Berliner Umland

## 1. Ziel und Lieferumfang
Das System erstellt eine nachvollziehbare Immobilienmarktanalyse mit Preisband, begründeter Preisstrategie und PDF-Bericht. Zuerst werden Einfamilienhäuser, Doppelhaushälften und Reihenhäuser unterstützt. ETW, vermietete Mehrfamilienhäuser und Grundstücke erhalten eigene Verfahrensprofile. Gewerbe, Erbbaurecht und komplexe Entwicklungsfälle werden ohne passendes Fachmodell nicht automatisch bewertet.

Dieses Paket ist ein Implementierungsauftrag mit Datenvertrag, erweiterter Objektmatrix, Referenzdaten, Master-Prompt und Qualitätssicherung. Es ist keine bereits betriebene Anwendung und keine vollständig gefüllte Transaktionsdatenbank. Eingepflegt sind die aus dem übergebenen Gutachten nachvollziehbaren Referenzdaten und sieben darin dokumentierte Vergleichskauffälle. Diese wurden nicht unabhängig in der Kaufpreissammlung verifiziert. Die Originalunterlagen bleiben maßgebend.

Eine perfekte Punktprognose ist nicht seriös garantierbar. Genauigkeit entsteht durch passende echte Kaufpreise, belastbare Objektinformationen und nachgemessene Prognosefehler. Viele Inserate allein erzeugen keine hohe Genauigkeit. Ein Wunschpreis ist kein Zielwert des Modells.

## 2. Technische Architektur
Pipeline: Dokumente und strukturierte Daten importieren; Fakten mit Quellen extrahieren; Konflikte auflösen; Stichtag und Teilmarkt auswählen; Vergleichsfälle filtern; zugelassene Verfahren deterministisch berechnen; Sensitivität prüfen; KI-Bericht schreiben; PDF rendern; fachlich freigeben.

Die Anwendung benötigt fünf getrennte Speicher: unveränderte Quelldateien, strukturierte Fakten, historische Marktdaten, versionierte Bewertungsmodelle sowie unveränderliche Analyse-Läufe. Ein relationaler Speicher mit räumlichen Abfragen ist zweckmäßig. Ein zusätzlicher Suchindex erschließt Texte. Tabellen und Formeln gehören nicht ausschließlich in einen Vektorindex.

Die KI extrahiert, erklärt, recherchiert und formuliert. Ein Rechenmodul führt Formeln aus. Ein Regelmodul entscheidet über zulässige Modelle und Daten. Ein PDF-Modul gestaltet. Jede Zahl im Bericht ist auf ein Faktum oder einen Rechenknoten zurückführbar. Die KI darf Endwerte des Rechenmoduls nicht verändern.

Empfohlene interne Schnittstellen: POST /documents/import; POST /facts/validate; POST /comparables/select; POST /valuations/calculate; POST /reports/render. Jede Anfrage erhält eine run_id. Die konkrete technische Plattform bleibt frei wählbar.

## 3. Datentypen und Quellenbelege
Jeder fachliche Wert besitzt einen Belegumschlag: value, unit, source_id, page_or_locator, observed_at, valid_at, extraction_method, verification_status, confidence_note und conflict_id. Fehlend ist null; null ist niemals 0, nein oder mangelfrei. verification_status ist eines aus documented, owner_statement, visually_inferred, assumed, conflicted oder verified. verified erfordert benannte Prüfung mit Zeitstempel.

Für jede Quelle speichern: ID, Herausgeber, Titel, URL oder Datei, Dokumentdatum, Veröffentlichungsdatum, Abrufdatum, Bezugszeitraum, räumlichen Geltungsbereich, Objektsegment, Lizenz/Zugangsstatus, Version, Prüfsumme und erlaubte Nutzung. Belege müssen konkreten Seiten oder Datensätzen zugeordnet sein. Eine Homepage als einzige Quelle für einen Zuschlag reicht nicht.

Widersprechende Angaben werden parallel erhalten. Beispielsweise werden 112 m² aus einer Übersicht und 116,53 m² einschließlich Terrasse nicht überschrieben oder gemittelt. Das System ermittelt, ob unterschiedliche Definitionen vorliegen, und protokolliert die für den jeweiligen Rechenweg gewählte Bezugsgröße.

Faktenpriorität gilt feldbezogen: Grundstücksfläche aus geeignetem Kataster-/Grundbuchbeleg; Wohnfläche aus nachvollziehbarer Berechnung mit Regelwerk; Zustand aus aktueller Besichtigung und Fachunterlagen; Baurecht aus zuständiger Dokumentation. Ein neueres Exposé verdrängt nicht automatisch eine geprüfte Flächenberechnung.

## 4. Erweiterung deiner Objektmatrix
Die vorhandene Matrix liefert einen guten Gesprächs- und Besichtigungsbogen: Lage, Zielgruppen, Stärken, Einwände, Gebäudeart, Geschosse, Dach, Keller, Flächen, Standard, Modernisierungen, Bauweise, Nebengebäude und Nutzung. Marketingargumente bleiben jedoch von wertrelevanten, belegten Fakten getrennt.

Die beigefügte Datenmatrix enthält atomare Felder für Import und Formularbau. Wiederholbare Gruppen sind Flurstücke, Räume, Bauteile, Modernisierungen, Schäden, Mietverträge, Vergleichsfälle und Quellen. Ein Jahr und ein Prozentkreuz genügen bei einer Modernisierung nicht: zusätzlich Umfang, betroffene Bauteile, Nachweis, Ausführungsqualität, verbleibende Defizite und Bewertungswirkung erfassen.

Besonders wichtige Ergänzungen: Wohnflächenregelwerk; Terrasse brutto und angerechnet; getrennte Wfl./wGF/BGF; genehmigte Nutzung; vermietete versus freie Nutzung; Baulasten und Rechte; Beitragszustand; Energieausweisart und Kennwert; Feuchtigkeit und Schadensumfang; Modernisierungskosten versus marktlicher Wertbeitrag; Flurstücke mit unterschiedlichen Nutzungsqualitäten; Datenalter und Belegqualität.

Standardstufe und Erhaltungszustand sind getrennt. Ein ehemals hochwertiges Haus kann heute sanierungsbedürftig sein. Modellbedingte Standardstufe 4 bedeutet nicht automatisch gehobene tatsächliche Ausstattung. Fotos belegen sichtbare Oberflächen, nicht verdeckte Dämmung, Tragfähigkeit, Schadstofffreiheit oder rechtliche Genehmigung.

Erfassungsablauf: Eigentümerformular; Dokumentenimport; KI-Vorbefüllung; Besichtigungscheck; Konfliktliste; fachliche Bestätigung. Pro fehlendem Feld zeigt das System den Einfluss auf das Ergebnis und das benötigte Dokument. Pflichtfelder sind vom gewählten Verfahren abhängig.

## 5. Datenbeschaffung: viele Daten mit klarer Funktion
### Ebene A: echte Kaufpreise
Priorität haben geeignete Kaufpreissammlungs-Auszüge, lizenzierte Transaktionsdaten und eigene dokumentierte Abschlüsse. Jeder Kaufpreis benötigt Kaufdatum, Preisumfang, Objektsegment, Flächenbezug, Zustand, Nutzungsstatus und Bereinigung von Zubehör/Nebenanlagen. Käufer- und Verkäuferidentitäten sind für den Modellkern grundsätzlich entbehrlich.

Die Berliner AKS Online ist kein frei zugängliches Massenportal. Zugang erfolgt auf Antrag und nach Prüfung. Ohne Zugang werden passende Auskünfte oder lizenzierte Daten beschafft, soweit zulässig. Es darf kein erfolgreicher AKS-Abruf simuliert werden. Zugriffskosten oder ein Datenvertrag sind hier noch nicht ausgelöst.

### Ebene B: amtliche Modelle
Quellenregister anlegen für GAA Berlin, regionale Gutachterausschüsse Brandenburg, BORIS Berlin/Brandenburg, Baupreisindizes und jeweilige Modellbeschreibungen. Ein Sachwertfaktor wird nur zusammen mit seinem gesamten Modellpaket eingelesen: NHK-System, Gebäudetyp, Flächendefinition, Standardansatz, GND/RND-Regeln, Indexbasis und -stichtag, Bodenwertbasis, Nebenanlagenbehandlung, Lagekategorien und Gültigkeitsgrenzen.

Am 13.11.2026 listet GAA Berlin Sachwertfaktoren 2026 mit Stand 30.10.2026. Das verlinkte Dokument konnte in dieser Recherche wegen HTTP 429 nicht inhaltlich geladen werden. Die konkreten 2026er Koeffizienten sind daher nicht in diesem Paket freigegeben. Die Werte aus dem Gutachten bleiben ein historisches Referenzmodell für März 2026; sie sind kein aktuelles Standardmodell.

### Ebene C: Angebotsmarkt
Aktuelle Inserate zeigen Konkurrenz und Preisvorstellungen. Import nur aus erlaubten Exporten, freigegebenen Schnittstellen, nutzerseitigen Unterlagen oder zulässig zugänglichen Seiten. Mindestens erfassen: Portal-ID, URL, erstmalig/zuletzt gesehen, Angebotsstatus, Preisänderungen, Flächen, Lagegenauigkeit, Ausstattung, Zustand, vermietet/frei, Anbieter und Dublettengruppe. Deaktiviert bedeutet nicht verkauft. Angebotspreise und tatsächliche Abschlüsse bleiben getrennte Tabellen und Auswertungen.

Ein pauschaler Verhandlungsabschlag von etwa 5 oder 10 Prozent ist verboten. Ein Angebots-Abschluss-Modell darf nur anhand zugeordneter, überprüfter Abschlüsse und zeitlich passender Segmente eingesetzt werden. Ohne diese Daten lautet die Ausgabe Angebotsmarktindikation, nicht nachgewiesener Verkaufspreis.

### Ebene D: Objekt und Mikrolage
Grundrisse, Flächenberechnung, Energieausweis, Baubeschreibung, Rechnungen, Besichtigungsprotokoll, Grundbuch-/Baulastinformationen und Mietunterlagen. Ergänzend überprüfbare Geodaten zu Lärm, Hochwasser, ÖPNV, tatsächlichen Wegen, Infrastruktur, Planungsrecht und Bodenverhältnissen. Aus einer Gefahrenkarte wird kein bautechnischer Befund abgeleitet. Straßenseite, Immissionen und unmittelbare Nachbarschaft können wichtiger sein als ein Bezirksdurchschnitt.

### Beschaffungs- und Aktualisierungsplan
Startziel pro Analyse: 30 bis 100 Kandidaten recherchieren, soweit verfügbar; daraus etwa 8 bis 20 tatsächlich geeignete Vergleichsfälle dokumentieren. Diese Zahlen sind Arbeitsziele, keine statistische Qualitätsgarantie. Mehr als 20 Fälle dürfen im Rechenmodell verwendet werden; die PDF-Kerntabelle zeigt bis zu 20 und verweist auf den vollständigen Anhang.

Für den langfristigen Datenbestand: getrennte Segmente nach Region, Gebäudeart, Zeitraum und Nutzung aufbauen. Nicht tausende unpassende Inserate in einen Prompt kopieren. Der Rechenlauf verarbeitet den relevanten Bestand; die KI erhält Tabellen, Kennzahlen, Modellregeln und zitierbare Auszüge.

Angebote bei aktiven Mandaten wöchentlich auf Änderungen prüfen; Transaktionen nach verfügbarer Veröffentlichung bzw. eigenem Abschluss ergänzen; amtliche Quellen monatlich auf neue Fassungen prüfen; Objektzustand vor jeder finalen Bewertung bestätigen. Das sind vorgeschlagene Betriebsregeln, keine hier eingerichteten Automationen.

## 6. Stichtag, Versionierung und Wiederholbarkeit
Jeder Lauf speichert valuation_date, quality_date, data_cutoff, information_as_of, model_version, calculation_version, prompt_version und report_version. Ein historischer Lauf darf keine damals unbekannten Kaufpreise oder später veröffentlichten Modelle verwenden. Eine rückblickende Neubewertung mit späterem Wissen ist eine andere Analyse und wird so benannt.

Modellkonformität geht vor isolierter Aktualität: Ein neuer Bodenrichtwert oder Baupreisindex darf nicht beliebig mit einem alten Sachwertfaktor kombiniert werden. Aktuelle Lageinformationen werden getrennt vom modellgebundenen Bodenwertansatz gezeigt. Jede zusätzliche Zeitkorrektur braucht eine Begründung und darf nicht schon im Faktor stecken. Grundlage: ImmoWertV § 10, Quellenregister S01.

## 7. Auswahl von Vergleichsfällen
Zunächst harte Ausschlüsse: falsche Preisart, unklarer Flächenbezug, nicht vergleichbare Nutzung/Rechtsform, nicht nachvollziehbarer Preis, Dublette oder unzulässiges Beobachtungsdatum. Sonderfälle wie Erbbaurecht, Zwangsverkauf oder vermietetes Objekt werden nicht ungeprüft mit normalen freien Eigenheimverkäufen vermischt.

Suche zunächst gleiche Gebäudeart und zusammenhängende Mikromärkte. Startfenster als konfigurierbare Arbeitshilfe: 12 Monate, Wohnfläche plus/minus 25 Prozent, Grundstück plus/minus 35 Prozent. Erst danach Zeitraum, angrenzende Mikrolagen oder Größenfenster erweitern. Jede Erweiterung mit Grund und Qualitätsfolge dokumentieren. Das ist kein amtlicher Grenzwert.

Ähnlichkeit ordnet Fälle nach Lage, Bauart, Größe, Zustand, Energie, Baualter und Nutzungsstatus. Anfangsgewichte müssen als heuristisch markiert und später gegen Verkäufe validiert werden. Schlechte Angaben dürfen nicht durch hohe Ähnlichkeit aufgewertet werden. Ausreißer zuerst auf Fehler oder besondere Merkmale prüfen; nie nur entfernen, weil sie dem Wunschpreis widersprechen.

Pro Vergleichsfall ausgeben: Rohpreis; Preisart; Quelle; Datum; Bezugsfläche; bereinigter Basispreis; jede Anpassung einzeln; angepasster Wert; Auswahlgrund; Gewicht; Unsicherheit. Abgelehnte Fälle mit Ablehnungsgrund im Prüfprotokoll erhalten.

## 8. Bewertungslogik und Rechenregeln
### Vergleichspreise
Einheit strikt binden: EUR/m² Wohnfläche ist nicht EUR/m² wGF und nicht EUR/m² BGF. Normalisierung nur bei belegten Bezugsgrößen. Für Häuser darf der Bodenanteil nicht nochmals hinzuaddiert werden, wenn er im Vergleichskaufpreis enthalten ist.

Bei belegten multiplikativen Anpassungen: p_adj_i = p_base_i × Produkt(F_i,k). Bei einem ausdrücklich additiven Prozentmodell: p_adj_i = p_base_i × (1 + Summe(a_i,k)). Beide Verfahren sind nicht austauschbar. Art und Reihenfolge stehen im Modell. Anpassungsrichtung ist immer vom Vergleichsobjekt zum Zielobjekt. Ohne belastbaren Koeffizienten wird ein Unterschied beschrieben oder als Szenario behandelt.

Ein robuster Mittelwert oder gewichteter Median kann die bereinigten Werte zusammenfassen. Bei Gewichten w: Mittelwert = Summe(w_i × p_i)/Summe(w_i); effektive Fallzahl n_eff = (Summe w_i)²/Summe(w_i²). Zusätzlich Median, Minimum/Maximum, Quartile, Streuung, ungewichtete Fallzahl und größte Einzelgewichtung zeigen. Gleiche Daten in mehreren Verfahren zählen nicht als unabhängige Bestätigung.

### Bodenwert
Teilflächen getrennt: BW = Summe(Fläche_j × passender Richtwert_j × zulässiger Anpassungsfaktor_j). Bauland, Straßenland, Garten-/Hinterland und ungesicherte Entwicklungsflächen nicht gleich bewerten. Baurecht und Teilbarkeit benötigen Nachweise. Ein Bodenrichtwert ist kein garantierter Verkaufspreis des konkreten Grundstücks.

### Sachwert
Vereinfachte Grundstruktur: Herstellungskosten = BGF × NHK × Indexquotient × Regionalfaktor × modellzulässige Korrekturen. Gebäuderestwert bei linearer Altersminderung = Herstellungskosten × RND/GND. Danach modellkonformer vorläufiger Sachwert, Sachwertfaktor, gegebenenfalls zusätzliche belegte Marktanpassung, schließlich noch nicht enthaltene besondere Merkmale. Nebenanlagen und Nebenflächen genau an der vom lokalen Modell vorgesehenen Stelle berücksichtigen.

Verlangt das lokale Modell feste Standard- oder RND-Ansätze, dürfen diese nicht durch eine frei erfundene Punktelogik ersetzt werden. Eine abweichende sachverständige Entscheidung erhält Originalwert, Ersatzwert, Begründung, Quelle, Auswirkung in EUR und Freigabe. Fehlende vollständige Modellbeschreibung blockiert die entsprechende endgültige Rechnung.

### Ertragswert und Vermietung
Für ein geeignetes Ertragsobjekt im allgemeinen Verfahren: Reinertrag = nachhaltiger Rohertrag minus modellkonforme Bewirtschaftungskosten. Gebäudeertragsanteil = Reinertrag minus Bodenwertverzinsung. Vervielfältiger bei i > 0: (1 - (1+i)^(-n))/i. Ertragswert = Gebäudeertragsanteil × Vervielfältiger + Bodenwert, anschließend erforderliche noch nicht enthaltene Korrekturen. Modellgrenzen, Restnutzungsdauer und besondere Ertragsverhältnisse beachten; i ist keine Hypothekenrate.

Ist-Miete, erzielbare Miete und rechtlich zulässige Miete getrennt speichern. Keine automatische Annahme einer sofortigen Marktmieterhöhung. ETW zusätzlich WEG-Unterlagen, Rücklagenanteil, nicht umlagefähige Kosten, Beschlüsse, Sonderumlagen und Gemeinschaftseigentum prüfen. Keine pauschale Übertragung eines Wohnungsmietspiegels auf Einfamilienhäuser. Ohne passende Rechts- und Marktdaten wird keine rechtlich belastbare Mietempfehlung behauptet.

### Zusammenführung
Verfahrenswahl nach Daten und Marktgepflogenheiten begründen. Keine starre Regel 50 Prozent Sachwert plus 50 Prozent Vergleichswert. Ein führendes geeignetes Verfahren bestimmen, andere als Plausibilisierung verwenden. Bei erheblicher Abweichung Ursachen analysieren. Eine konfigurierbare Differenz von mehr als 15 Prozent löst eine Prüfung aus; sie ist kein gesetzlicher Zulässigkeitswert.

## 9. Schutz vor Doppelzählung
Ein Wirkungsregister enthält je Merkmal: effect_id, Beschreibung, Verfahren, betroffene Modellkomponente, enthalten_ja_nein, zusätzlicher Betrag, Beleg und Begründung. Beispiele: schlechter Zustand schon in RND oder Vergleichskorrektur; Garage bereits im Kaufpreis; Terrasse bereits in Wohnfläche; normale Außenanlagen bereits im Bodenwertmodell. Ein zusätzlicher Abzug oder Zuschlag wird bei Überschneidung blockiert, bis eine Abgrenzung vorliegt.

Investitionskosten sind nicht gleich Marktwertänderung. Eine 20.000-EUR-Küche erhöht den Kaufpreis nicht automatisch um 20.000 EUR. Bei Sanierung getrennt zeigen: technische Maßnahme, belastbare Kostenspanne, marktlich belegter Effekt und Szenario ohne gesicherten Markteffekt. Energetische Einsparungen nicht ohne Verbrauchsbasis und Berechnung behaupten.

## 10. Unsicherheit und Genauigkeitsmessung
Ausgabe mindestens: zentraler Orientierungswert, nachvollziehbares Preisband, Datenlage und drei größte Werttreiber. Ein Szenarioband ist kein statistisches 90-Prozent-Prognoseintervall. Mittelwert plus/minus eine Standardabweichung beschreibt Streuung der Stichprobe und nicht automatisch die Unsicherheit des Zielobjekts oder des Mittelwerts.

Bei fehlender Kalibrierung: plausible Parameter-Szenarien rechnen, Unterschiede in EUR zeigen, Band ausdrücklich nicht statistisch kalibriert nennen. Bei ausreichenden überprüften Abschlüssen: zeitlich vorwärts gerichtete Testdaten, objektweise getrennte Dubletten-Gruppen und ausschließlich damals bekannte Daten verwenden. Kalibrierungsdaten strikt vom abschließenden Test trennen.

Kennzahlen je Segment: Median des absoluten Prozentfehlers, mittlerer absoluter Fehler in EUR, systematische Über-/Unterbewertung und tatsächliche Abdeckung des ausgegebenen Intervalls. Beispiel eines Produktziels: Medianfehler unter 10 Prozent. Das ist ein zu prüfendes Ziel, keine zugesagte Leistung. Ein 80-Prozent-Intervall sollte auf unabhängigen Fällen ungefähr 80 Prozent der Verkaufspreise erfassen; breite Intervalle separat bewerten.

Eigene Abschlüsse sind wertvoll, aber selektiv. Nicht verkaufte Mandate und abgebrochene Vermarktungen separat erfassen. Verweildauer ist bei aktiven Angeboten rechtszensiert; daraus keine abgeschlossene Verkaufsdauer ableiten. Kleine Teilmärkte nicht mit unzuverlässigen Genauigkeitsversprechen versehen.

Qualitätsstufen als Betriebsregel: A = dokumentierte Kerndaten, passende Transaktionen, passendes Modell und empirisch geprüfte Unsicherheit; B = belastbare Orientierung mit begrenzter Stichprobe oder offenen Nebenpunkten; C = überwiegend Angebote/Annahmen, nur vorläufige Indikation; STOP = entscheidende Einheit, Rechtsform, Preisbasis oder Objektidentität ungeklärt. Eine bloße Anzahl von Fällen erzeugt kein A.

## 11. Was das Gutachten konkret für das System zeigt
Quelle R01: übergebenes Gutachten Wuhletal 15, erstellt 31.03.2026, Bewertungsstichtag 23.03.2026. Die folgenden Angaben sind historische Dokumentwerte und keine Neubewertung zum 13.11.2026.

Flächen: Seite 18 nennt innen 111,53 m², Terrasse 20 m² mit 25 Prozent = 5 m², zusammen 116,53 m². Die Übersicht verwendet rund 112 m². wGF rund 165 m²; BGF Haus rund 209 m²; Garage rund 30 m². Diese Werte gehören in separate Felder mit Verwendungszweck.

Boden: 523 m² Baugrundstück × 500 EUR/m² = 261.500 EUR. Dazu 28 m² Verkehrsfläche × 5 EUR/m² = 140 EUR. Gesamt 261.640 EUR. Der Ansatz 500 EUR/m² ist im Gutachten an das historische Sachwertmodell gebunden; der dort zusätzlich genannte Richtwert 2026 von 460 EUR/m² ist nicht einfach austauschbar.

Sachwert: dokumentierter Gebäuderestwert 193.976,56 EUR plus 261.500 EUR = 455.476,56 EUR. Faktor 0,90 ergibt 409.928,90 EUR. Garage +18.500, Markise +2.000, Küche +1.500, Heizung -14.000 ergeben +8.000 EUR; Straßenland +140 EUR. Ergebnis 418.068,90 EUR, gerundet 418.000 EUR.

Prüfpunkt 1: Die gedruckten Eingaben 209 × 1.005 × 1,847 ergeben 387.953,115 EUR Herstellungskosten und reproduzieren damit den auf Seite 35 angegebenen Wert bis auf die Cent-Rundung. Rohpräzision und Anzeigepräzision müssen getrennt werden; eine zentrale Rundungsregel verhindert Folgedifferenzen.

Prüfpunkt 2: Seite 28 nennt beim Faktor 0,90 im Fließtext 409.828,90 EUR; rechnerisch ergeben sich 409.928,90 EUR, wie später verwendet. Die Differenz von 100 EUR wird als Dokumentwiderspruch protokolliert; sie ändert hier den gerundeten Endwert nicht.

Prüfpunkt 3: Der tabellarisch abgeleitete Faktor 0,740 wird auf Grundlage von sieben Vergleichsfällen auf 0,90 ersetzt. Differenz: 455.476,56 × (0,90 - 0,74) = 72.876,25 EUR. Bei sonst gleichen Ansätzen ergäbe 0,74 etwa 345.192,65 EUR inklusive besonderer Merkmale und Verkehrsfläche. Das ist eine Sensitivität, kein hier neu festgestellter Marktwert. Eine solche Entscheidung darf die KI nicht stillschweigend treffen.

Prüfpunkt 4: Der Vergleichsweg nutzt 165 m² wGF × 2.600 EUR/m² = 429.000 EUR; Garage +18.500, Heizung -14.000 ergeben 433.500 EUR, im Dokument 434.000 EUR gerundet. 2.600 EUR/m² wGF darf nicht mit 112 m² Wohnfläche multipliziert werden.

Prüfpunkt 5: Das Gutachten verwendet geschätzte Baujahreskorrekturen von 1 Prozent je Jahr und eine Lagekorrektur, die auf Sachwertfaktor-Korrekturen Bezug nimmt. Das sind zu prüfende fallbezogene Ansätze, keine universellen Koeffizienten. Eine additive Änderung eines Sachwertfaktors ist nicht automatisch ein identischer prozentualer Kaufpreiseffekt.

Prüfpunkt 6: Für den Kauffall 03/2024 ist die ausgewiesene Zeitkorrektur von -0,72 Prozent anhand des erklärten Zeitbezugs gesondert nachzurechnen. Die sieben bereinigten Vergleichswerte und ihre Anpassungen werden als Dokumentangaben gespeichert, nicht als unabhängig bestätigte Trainingswahrheit.

Prüfpunkt 7: Sachwert und Vergleichswert nutzen teilweise dieselben Kauffälle zur Plausibilisierung bzw. Faktorauswahl. Ihre Nähe ist daher keine unabhängige doppelte Bestätigung. Die kleinen Streuungen nach Anpassung belegen allein keine hohe Prognosegenauigkeit.

## 12. PDF-Ausgabe für Eigentümer
Titel: Immobilienmarktanalyse, Objektkennung, Ort, Stichtag und Version. Keine Behauptung eines zertifizierten Gutachtens. Zielumfang etwa 10 bis 16 Seiten plus benötigte Anhänge; keine leeren Pflichtseiten erzeugen.

Empfohlene Reihenfolge: 1 Ergebnis mit Preisband und Datenqualität; 2 Objektprofil und Flächen; 3 Mikro-/Makrolage; 4 Quellenlage und Markt; 5 bis 7 Vergleichsfälle und Anpassungen; 8 bis 9 Verfahrensrechnungen; 10 Sensitivität und offene Punkte; 11 Preisstrategie; 12 Quellen und Methodik. Umfang an Datenlage anpassen.

Preisstrategie trennt erzielbare Orientierung vom Angebotspreis. Konservativ, marktgerecht und ambitioniert nur mit jeweiliger Herleitung und Annahmen zeigen. Ohne nachgewiesenes Nachfrage-/Verkaufsdauermodell keine Verkaufswahrscheinlichkeit oder konkrete Verkaufsfrist erfinden. Eigentümerwunschpreis nur als Vergleichslinie darstellen.

Gestaltung: A4, dunkles Blau, dezente Magenta-Akzente, gut lesbare Tabellen und kurze Aussagen. Kein fremdes Logo ohne bereitgestellte Nutzungsgrundlage nachbauen. Zahlen aus Rechen-JSON übernehmen. Jede wertrelevante Tabelle erhält Quellen-ID, Bezugsdatum und Einheit. Karten/Bilder nur mit geeigneten Nutzungsrechten; Karten aus dem Gutachten nicht ungeprüft weiterverwenden.

PDF enthält echten durchsuchbaren Text, Seitenzahlen, Fußnoten/Quellen, keine abgeschnittenen Tabellen. Beträge in der Ergebnisübersicht sinnvoll gerundet, interne Rechnung ungerundet. Berechnung und PDF müssen dieselbe run_id und Version tragen. Interner Prüfanhang getrennt von der Eigentümerversion; keine unnötigen Personendaten veröffentlichen.

## 13. Umsetzung in sechs Arbeitspaketen
AP1: Datenvertrag, Dateiablage, Quellenregister und dynamische Objektmatrix. Abnahme: Jeder Wert hat Einheit, Status und Quelle; widersprechende Flächen bleiben sichtbar.

AP2: Import von PDF, Bildern, CSV/JSON und erlaubten Datenexporten. OCR-Konfidenz markieren; Zahlenspalten visuell prüfen. Abnahme: Referenzfall ist einschließlich sieben Vergleichsfällen korrekt extrahiert, ohne Eigentümerdaten in Modelltabellen.

AP3: Vergleichsauswahl und Dublettenerkennung. Regelbasierte Kandidatengruppierung nach Portal-ID, Adresse, Flächen, Bildern und Zeit; unsichere Gruppen manuell bestätigen. Abnahme: mehrfach inseriertes Objekt zählt einmal; deaktivierte Inserate gelten nicht als Verkauf.

AP4: Rechenmodul und versionierte Modellprofile. Historischen Referenzfall reproduzieren, Abweichungen offenlegen, fehlende Faktoren blockieren. Neue 2026er Profile erst nach vollständig eingelesener Originalmodellbeschreibung aktivieren.

AP5: Berichtserstellung mit Master-Prompt und PDF-Renderer. Abnahme: keine erfundene Zahl/Quelle, alle Tabellen rechnerisch konsistent, saubere Seitenumbrüche und sichtbare Unsicherheit. Prompt allein erzeugt ohne Dateifunktion/Renderer keine PDF.

AP6: Validierung an dokumentierten Abschlüssen, laufende Fehlerauswertung und Freigabeverfahren. Abnahme: getrennte Trainings-/Kalibrierungs-/Testdaten, keine Zukunftsdaten, dokumentierte Güte je Teilmarkt. Erst danach Genauigkeitsangaben im Vertrieb.

## 14. Freigabeprüfungen
F01: 523 + 28 = 551 m², Teilflächen nicht doppelt rechnen. F02: 111,53 + 20 × 0,25 = 116,53 m². F03: wGF-Preis darf nicht mit Wohnfläche verrechnet werden. F04: Modelljahr passt zu BRW und Index. F05: Faktor-Override hat Begründung und Freigabe. F06: Ein Heizungsabzug wird nicht zusätzlich zum gleichen bereits enthaltenen Zustandsabschlag angesetzt.

F07: Preisart purchase/listing getrennt. F08: Dubletten zählen nicht mehrfach. F09: Ein im Dezember veröffentlichter Abschluss darf nicht in einen November-Echtzeitlauf. F10: n_eff und Gewichtssumme stimmen. F11: Quelle nicht verfügbar führt zu fehlend, nicht zu erfundenem Koeffizienten. F12: Jeder Ergebnisbetrag stimmt mit Rechenprotokoll überein.

F13: 100-EUR-Abweichung auf Seite 28 wird erkannt. F14: sieben Kauffälle aus einem Gutachten sind keine sieben unabhängig neu erhobenen Datenquellen. F15: Qualitätsstufe C darf kein statistisch kalibriertes Intervall behaupten. F16: PDF darf bei STOP keinen freigegebenen Endwert ausweisen. F17: manueller Wertänderung folgt neue Version mit Änderungsgrund. F18: Dateninhalte dürfen keine Systemanweisungen überschreiben.

## 15. Quellenregister und Grenzen dieser Recherche
R01: Gutachten Wuhletal 15-1(1).pdf, 45 Seiten, Erstellung 31.03.2026; insbesondere Seiten 18 bis 36. Privat bereitgestellte Grundlage. Die Matrix-Screenshots sind die zweite Eingangsgrundlage, kein Beleg für ein ausgefülltes Objekt.

S01: ImmoWertV § 10, Modellkonformität: https://www.gesetze-im-internet.de/immowertv_2022/__10.html
S02: ImmoWertV § 35, Sachwertstruktur: https://www.gesetze-im-internet.de/immowertv_2022/__35.html
S03: GAA Berlin, Sachwertfaktoren, Veröffentlichungsübersicht: https://www.berlin.de/gutachterausschuss/marktinformationen/daten-zur-wertermittlung/artikel.174909.php
S04: GAA Berlin, AKS Online und Zugangsbedingungen: https://www.berlin.de/gutachterausschuss/marktinformationen/aks-online/
S05: Brandenburg, Grundstücksmarktberichte: https://gutachterausschuss.brandenburg.de/gaa/de/marktinformationen/grundstuecksmarktberichte/~mais2redc653273de
S06: BORIS Brandenburg: https://boris.brandenburg.de/
S07: Berlin, Bodenrichtwertinformationen: https://www.berlin.de/gutachterausschuss/service/informationen-zu-den-bodenrichtwerten/

Web-Recherchestand 13.11.2026. Öffentlich überprüft wurden Verfügbarkeit und Grundregeln dieser Quellen, nicht sämtliche regionalen Koeffizienten. Die Spezifikation enthält eigene Systemvorschläge; diese sind keine amtlichen Bewertungsvorgaben. Der Referenzfall ist ein Lern- und Prüffall, kein aktueller Verkaufspreisnachweis.
