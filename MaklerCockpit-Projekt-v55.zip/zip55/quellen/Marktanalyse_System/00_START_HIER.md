# Marktanalyse-System für Görner Immobilien
Stand 13.11.2026. Implementierungspaket für ein separates System, keine bereits installierte Software.

## Reihenfolge
1. `01_Systemhandbuch.md` als fachliche Spezifikation und Arbeitsauftrag einlesen.
2. `03_Datenmatrix.csv` als Feldkatalog für Datenbank und Erfassungsformular verwenden: 329 Felddefinitionen, Semikolon-getrennt, UTF-8 mit BOM. Gruppen mit [] sind wiederholbar. Nicht jedes Feld gilt für jeden Objekttyp; Einheiten und Datentypen vor Produktion fachlich vervollständigen.
3. `04_Eingabevorlage.json` ist der minimale strukturelle Eingabevertrag mit leeren Werten, kein formales JSON Schema und kein fertiger Datensatz. Das separate System muss diesen Vertrag erweitern und validieren.
4. `05_Referenzdaten_Wuhletal.json` enthält 26 belegte Referenzangaben und sieben im Gutachten aufgeführte Vergleichskauffälle. Keine unabhängig verifizierten aktuellen Verkäufe.
5. `06_Referenzpruefung.py` ausführen, um zentrale historische Rechnungen nachzuvollziehen. Diese Datei ist kein allgemeiner Wertermittlungsrechner.
6. `02_Masterprompt.md` als feste KI-Systemanweisung hinterlegen. Pro Objekt das befüllte Analysepaket zusätzlich übergeben.
7. Rechenmodul und PDF-Renderer nach Handbuch implementieren. Den endgültigen Bericht vor Versand fachlich freigeben.

## Bereits vorhanden / noch erforderlich
Vorhanden: Systemkonzept, 329 Datenfelder, historischer Referenzdatensatz, ausführbarer Rechentest, Master-Prompt und lesbare PDF-Fassung des Systemhandbuchs.
Noch erforderlich: Einbindung in deine Zielsoftware, tatsächlicher Import großer Marktbestände, Zugang zu geeigneten Kaufpreisdaten, vollständige aktuelle regionale Modellpakete, Kalibrierung und produktiver PDF-Workflow.

Das Systemhandbuch ist die PDF-Erklärung dieses Pakets. Es ist keine aktuelle Immobilienbewertung des Referenzobjekts.
