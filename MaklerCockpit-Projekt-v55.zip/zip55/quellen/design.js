/* MaklerCockpit v11 – Oberfläche: Seitenleiste mit Symbolen, Kopfleiste mit Suche (Strg+K), Hinweisen und Menü */
const IC = (()=>{
  const s = (p, extra) => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"${extra||''}>${p}</svg>`;
  return {
    logo: s('<path d="M3 11 12 3.5l9 7.5"/><path d="M5 9.5V20a1 1 0 0 0 1 1h4v-6h4v6h4a1 1 0 0 0 1-1V9.5"/>'),
    akquise: s('<circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="4.5"/><circle cx="12" cy="12" r="1"/><path d="M15.5 8.5 20 4M17 4h3v3"/>'),
    objekte: s('<path d="M3 11 12 3.5l9 7.5"/><path d="M5 9.5V20h14V9.5"/><path d="M10 20v-5h4v5"/>'),
    kaeufer: s('<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c.8-3.6 3.3-5.6 6.5-5.6 1.6 0 3 .5 4.1 1.4"/><path d="m15 17.5 2.2 2.2 4.3-4.4"/>'),
    kontakte: s('<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c.8-3.6 3.3-5.6 6.5-5.6s5.7 2 6.5 5.6"/><circle cx="17" cy="9" r="2.6"/><path d="M16.2 14.5c2.6.2 4.5 2 5.3 4.9"/>'),
    hausverwaltungen: s('<rect x="4" y="3" width="16" height="18" rx="1.5"/><path d="M8.5 7h2M13.5 7h2M8.5 11h2M13.5 11h2M8.5 15h2M13.5 15h2M11 21v-2h2v2"/>'),
    termine: s('<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4M8 14h2M12 14h2"/>'),
    jarvis: s('<path d="M11 3.5 12.8 8.2 17.5 10l-4.7 1.8L11 16.5l-1.8-4.7L4.5 10l4.7-1.8z"/><path d="M18.5 14.5l.8 2.2 2.2.8-2.2.8-.8 2.2-.8-2.2-2.2-.8 2.2-.8z"/>'),
    'jv-rechner': s('<rect x="5" y="2.5" width="14" height="19" rx="2"/><path d="M8 6.5h8v3.5H8zM8.5 14h.01M12 14h.01M15.5 14h.01M8.5 17.5h.01M12 17.5h.01M15.5 17.5h.01"/>'),
    'jv-miete': s('<circle cx="8" cy="15" r="4"/><path d="m10.9 12.1 9.1-9.1M16 7l3 3M13.5 9.5l2 2"/>'),
    immowert: s('<path d="M4 20V11M10 20V5M16 20v-7M21 20H3"/>'),
    shooting: s('<path d="M4 8h3l2-3h6l2 3h3a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V9a1 1 0 0 1 1-1z"/><circle cx="12" cy="13.5" r="3.5"/>'),
    pdfs: s('<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-5-5L5 21"/>'),
    marketing: s('<path d="M3 11v2a1 1 0 0 0 1 1h2l6 4V6l-6 4H4a1 1 0 0 0-1 1z"/><path d="M16 9a4 4 0 0 1 0 6M19 6.5a8 8 0 0 1 0 11"/>'),
    'jv-warenkorb': s('<path d="M3 4h2l2.4 11.2a1 1 0 0 0 1 .8h8.8a1 1 0 0 0 1-.8L20 8H6.2"/><circle cx="9" cy="20" r="1.3"/><circle cx="17" cy="20" r="1.3"/>'),
    'jv-suchen': s('<circle cx="11" cy="11" r="7"/><path d="m20 20-3.6-3.6M8 11h6M11 8v6"/>'),
    'jv-news': s('<rect x="3" y="4" width="14" height="16" rx="1.5"/><path d="M17 8h3v11a1 1 0 0 1-1 1h-2M6.5 8h7M6.5 12h7M6.5 16h4.5"/>'),
    'jv-steuer': s('<path d="M6 2.5h12v19l-3-2-3 2-3-2-3 2z"/><path d="M9 7h6M9 11h6M9 15h4"/>'),
    'call-daniel': s('<path d="M5 4h3l2 5-2.5 1.5a11 11 0 0 0 6 6L15 14l5 2v3a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2z"/>'),
    dashboard: s('<rect x="3" y="3" width="7" height="9" rx="1.5"/><rect x="14" y="3" width="7" height="5" rx="1.5"/><rect x="14" y="12" width="7" height="9" rx="1.5"/><rect x="3" y="16" width="7" height="5" rx="1.5"/>'),
    such: s('<circle cx="11" cy="11" r="7"/><path d="m20 20-3.6-3.6"/>'),
    glocke: s('<path d="M6 8.5a6 6 0 0 1 12 0c0 6.5 3 8.5 3 8.5H3s3-2 3-8.5"/><path d="M10.3 21a1.9 1.9 0 0 0 3.4 0"/>'),
    zahnrad: s('<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/>'),
    pin: s('<path d="M12 21s-7-6.1-7-11.5a7 7 0 0 1 14 0C19 14.9 12 21 12 21z"/><circle cx="12" cy="9.5" r="2.5"/>'),
    flaeche: s('<rect x="3.5" y="3.5" width="17" height="17" rx="1.5"/><path d="M3.5 12h8.5V3.5M12 16v4.5"/>'),
    zimmer: s('<path d="M6 21V4a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v17M3.5 21h17M14.5 12h.01"/>'),
    grund: s('<path d="M3 6.5 9 3.5l6 3 6-3v14l-6 3-6-3-6 3z"/><path d="M9 3.5v14M15 6.5v14"/>'),
    tel: s('<path d="M5 4h3l2 5-2.5 1.5a11 11 0 0 0 6 6L15 14l5 2v3a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2z"/>'),
    mail: s('<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/>'),
    notiz: s('<path d="M5 3h10l4 4v14H5z"/><path d="M15 3v4h4M8.5 12h7M8.5 16h4.5"/>'),
    person: s('<circle cx="12" cy="8" r="4"/><path d="M4 21c1-4.2 4-6.5 8-6.5s7 2.3 8 6.5"/>'),
    kal: s('<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/>'),
    info: s('<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.01"/>'),
    doku: s('<path d="M6 3h9l4 4v14H6z"/><path d="M15 3v4h4M9 13h6M9 17h6"/>'),
    stern: s('<path d="m12 3 2.8 5.7 6.2.9-4.5 4.4 1.1 6.2L12 17.3 6.4 20.2l1.1-6.2L3 9.6l6.2-.9z"/>'),
    sternVoll: s('<path d="m12 3 2.8 5.7 6.2.9-4.5 4.4 1.1 6.2L12 17.3 6.4 20.2l1.1-6.2L3 9.6l6.2-.9z" fill="currentColor"/>'),
    stift: s('<path d="M4 20h4L19 9l-4-4L4 16z"/><path d="m13.5 6.5 4 4"/>'),
    mehr: s('<circle cx="5" cy="12" r="1.2"/><circle cx="12" cy="12" r="1.2"/><circle cx="19" cy="12" r="1.2"/>'),
    liste: s('<path d="M9 6h11M9 12h11M9 18h11M4 6h.01M4 12h.01M4 18h.01"/>'),
    karte: s('<path d="M12 21s-6.5-5.7-6.5-11a6.5 6.5 0 0 1 13 0c0 5.3-6.5 11-6.5 11z"/><circle cx="12" cy="10" r="2.3"/>'),
    plus: s('<path d="M12 5v14M5 12h14"/>'),
    einfuegen: s('<rect x="8" y="3" width="8" height="4" rx="1"/><path d="M16 5h2a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2h2"/><path d="M12 11v6M9 14l3 3 3-3"/>'),
    lupe: s('<circle cx="11" cy="11" r="7"/><path d="m20 20-3.6-3.6"/>'),
    links: s('<path d="m15 18-6-6 6-6"/>'),
    rechts: s('<path d="m9 18 6-6-6-6"/>'),
    kamera: s('<path d="M4 8h3l2-3h6l2 3h3a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V9a1 1 0 0 1 1-1z"/><circle cx="12" cy="13.5" r="3.5"/>'),
    link: s('<path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1"/><path d="M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1"/>'),
    haus: s('<path d="M3 11 12 3.5l9 7.5"/><path d="M5 9.5V20h14V9.5"/><path d="M10 20v-5h4v5"/>'),
    mfh: s('<rect x="4" y="3" width="16" height="18" rx="1"/><path d="M8 7h2M14 7h2M8 11h2M14 11h2M8 15h2M14 15h2M11 21v-3h2v3"/>'),
    wohnung: s('<rect x="5" y="3" width="14" height="18" rx="1"/><path d="M9 7h2M13 7h2M9 11h2M13 11h2M9 15h6"/>'),
    land: s('<path d="M3 20h18"/><path d="M7 20v-4M7 16a3 3 0 1 1 0-6 3 3 0 0 1 0 6z"/><path d="M16 20v-6M16 14a4 4 0 1 1 0-8 4 4 0 0 1 0 8z"/>'),
    gewerbe: s('<path d="M3 21V9l6-4v4l6-4v4l6-4v16z"/><path d="M7 17h2M12 17h2M17 17h1"/>'),
  };
})();

function anzahlHeuteTermine(){ const h = toDateKey(new Date()); return (db.termine||[]).filter(t=>{ const d = String(t.datum||'').slice(0,10); return d===h || (t.bisDatum && d < h && t.bisDatum >= h); }).length; }
function renderNav(){
  const neu = (db.objekte||[]).filter(o=>o.status==='neu').length, heute = anzahlHeuteTermine();
  const faellig = (typeof jvFaellig!=='undefined' && jvFaellig.length) ? jvFaellig.length : 0;
  const badge = k => k==='akquise'&&neu ? `<span class="sb-badge">${neu}</span>` : k==='termine'&&heute ? `<span class="sb-badge">${heute}</span>` : k==='jarvis'&&faellig ? `<span class="sb-badge warn" title="Suchen fällig">⏰ ${faellig}</span>` : '';
  document.getElementById('nav').innerHTML = `
    <div class="sb-logo">${IC.logo}<b>MaklerCockpit</b><span>${(window.pc && window.pc.geraet === "handy") ? "Handy v29" : "v55"}</span></div>
    <div class="sb-liste">
      ${NAV.map(n=>n.header ? `<div class="sb-kopf">${n.header}</div>` : `<div class="sb-item ${aktuelleAnsicht===n.key?'aktiv':''}" onclick="wechsleAnsicht('${n.key}')">${IC[n.key]||IC.dashboard}<span>${n.label}</span>${badge(n.key)}</div>`).join('')}
    </div>
    <div class="sb-fuss"><div class="av">PG</div><div style="flex:1;min-width:0;"><b>Paul Görner</b><small>Görner Immobilien</small></div>
      <button class="tb-icon" title="Einstellungen & Daten" onclick="tbMenue(event,'nutzer')">${IC.zahnrad}</button></div>
    <input type="file" id="importDatei" accept=".json,application/json" style="display:none" onchange="datenImportieren(this)">`;
}

// ── Kopfleiste ──
function tbAufbauen(){
  if(document.getElementById('topbar')) return;
  const main = document.getElementById('main'); if(!main) return;
  const wrap = document.createElement('div'); wrap.id = 'mainWrap';
  main.parentNode.insertBefore(wrap, main);
  const tb = document.createElement('div'); tb.id = 'topbar';
  tb.innerHTML = `<div class="tb-suche">${IC.such}<input id="gSuche" placeholder="Suche nach Objekten, Eigentümern, Orten …" autocomplete="off" oninput="gSuche()" onfocus="gSuche()" onkeydown="gSucheTaste(event)"><kbd>Strg + K</kbd><div id="gSucheErg" class="tb-drop"></div></div>
    <div class="tb-rechts"><button class="tb-icon" id="tbGlocke" title="Hinweise" onclick="tbMenue(event,'hinweise')">${IC.glocke}</button><div class="tb-av" title="Paul Görner" onclick="tbMenue(event,'nutzer')">PG</div></div>`;
  wrap.appendChild(tb); wrap.appendChild(main);
  document.addEventListener('keydown', e=>{
    if((e.ctrlKey||e.metaKey) && e.key.toLowerCase()==='k'){ e.preventDefault(); const i = document.getElementById('gSuche'); i.focus(); i.select(); }
    if(e.key==='Escape'){ gSucheZu(); tbMenueZu(); }
  });
  document.addEventListener('click', e=>{
    if(!e.target.closest('.tb-suche')) gSucheZu();
    if(!e.target.closest('.tb-menue') && !e.target.closest('.tb-icon') && !e.target.closest('.tb-av')) tbMenueZu();
  });
  tbGlockeAktualisieren();
  setInterval(tbGlockeAktualisieren, 60000);
}
// Globale Suche
let gSel = 0, gTreffer = [];
function gSuche(){
  const q = akqNorm(document.getElementById('gSuche').value);
  const box = document.getElementById('gSucheErg');
  if(q.length<2){ box.classList.remove('offen'); gTreffer = []; return; }
  const passt = t => akqNorm(t).includes(q);
  const objs = (db.objekte||[]).filter(o=>passt([o.akqTitel,o.adresse,o.ort,o.objektart,o.verkaeuferName,o.verkaeuferTelefon,o.verkaeuferEmail,o.quelle,(findKontakt(o.eigentuemerId)||{}).name].join(' '))).slice(0,8);
  const ks = (db.kontakte||[]).filter(k=>passt([k.name,k.telefon,k.email,k.notizen].join(' '))).slice(0,6);
  const hvs = ((db.hv||{}).verwaltungen||[]).filter(v=>passt([v.name,v.ansprechpartner,v.telefon,v.bezirk].join(' '))).slice(0,5);
  gTreffer = [].concat(objs.map(o=>({art:'o',id:o.id,t:o.akqTitel||o.adresse||o.objektart,s:[o.ort,o.kaufpreis?Number(o.kaufpreis).toLocaleString('de-DE')+' €':''].filter(Boolean).join(' · ')})),
    ks.map(k=>({art:'k',id:k.id,t:k.name,s:k.telefon||k.email||''})), hvs.map(v=>({art:'h',id:v.id,t:v.name,s:v.bezirk||''})));
  gSel = 0;
  const kopf = {o:'Objekte & Leads', k:'Kontakte', h:'Hausverwaltungen'}; let letzte = '';
  box.innerHTML = gTreffer.length ? gTreffer.map((x,i)=>{ const k = x.art!==letzte ? `<div class="gk">${kopf[x.art]}</div>` : ''; letzte = x.art;
      return k+`<div class="gi ${i===gSel?'sel':''}" onmousedown="gSucheOeffnen(${i})">${{o:IC.objekte,k:IC.person,h:IC.hausverwaltungen}[x.art].replace('<svg','<svg style="width:16px;height:16px;color:var(--muted)"')}<span>${akqEsc(x.t)}</span><small>${akqEsc(x.s)}</small></div>`; }).join('')
    : '<div class="gi" style="color:var(--muted);">Nichts gefunden</div>';
  box.classList.add('offen');
}
function gSucheTaste(e){
  if(!gTreffer.length) return;
  if(e.key==='ArrowDown'){ e.preventDefault(); gSel = Math.min(gSel+1, gTreffer.length-1); }
  else if(e.key==='ArrowUp'){ e.preventDefault(); gSel = Math.max(gSel-1, 0); }
  else if(e.key==='Enter'){ e.preventDefault(); gSucheOeffnen(gSel); return; }
  else return;
  document.querySelectorAll('#gSucheErg .gi').forEach((el,i)=>el.classList.toggle('sel', i===gSel));
}
function gSucheZu(){ const b = document.getElementById('gSucheErg'); if(b) b.classList.remove('offen'); }
function gSucheOeffnen(i){
  const x = gTreffer[i]; if(!x) return; gSucheZu(); document.getElementById('gSuche').blur();
  if(x.art==='o'){ AQ2.sel = x.id; AQ2.status = 'alle'; AQ2.kpi = ''; AQ2.q = ''; wechsleAnsicht('akquise'); setTimeout(()=>{ const el = document.getElementById('lc-'+x.id); if(el) el.scrollIntoView({block:'center'}); }, 30); }
  else if(x.art==='k'){ oeffneKontaktModal(x.id); }
  else { wechsleAnsicht('hausverwaltungen'); }
}
// Hinweise & Menü
// ── Hinweise (Glocke): jeder Hinweis lässt sich abhaken; Suchen-Erinnerungen einstellbar (v19) ──
function tbEinst(){ if(!db.hinweisEinst || typeof db.hinweisEinst !== 'object') db.hinweisEinst = {}; const e = db.hinweisEinst; if(!e.suche || typeof e.suche !== 'object') e.suche = {}; if(!e.aus || typeof e.aus !== 'object') e.aus = {}; return e; }
function tbHeute(){ return toDateKey(new Date()); }
function akqIntervall(p){ const s = ((db.hinweisEinst||{}).suche||{})[p.key]; return (s && Number(s.tage)) || p.tage; }
function akqErinnern(p){ const s = ((db.hinweisEinst||{}).suche||{})[p.key]; return !(s && s.aus); }
function tbHinweise(){
  const l = [], e = db.hinweisEinst || {};
  try{ const a = akqDb(); AKQ_PROMPTS.forEach(p=>{ if(!akqErinnern(p)) return; const t = akqVorTagen(a.zuletzt[p.key]), iv = akqIntervall(p); if(t===null || t>=iv) l.push({k:'suche:'+p.key, suche:p.key, iv, ic:p.icon, t:`Suche fällig: ${p.titel}`, s:t===null?'noch nie gemacht':t===1?'zuletzt gestern':'zuletzt vor '+t+' Tagen', f:`aq2Suchen()`}); }); }catch(err){}
  if(e.neu !== false){ const neu = (db.objekte||[]).filter(o=>o.status==='neu').length; if(neu) l.push({k:'neu', n:neu, ic:'🆕', t:`${neu} neue Leads noch nicht kontaktiert`, s:'Akquise öffnen', f:`AQ2.status='neu';wechsleAnsicht('akquise')`}); }
  if(e.termine !== false){ const h = anzahlHeuteTermine(); if(h) l.push({k:'termine', n:h, ic:'📅', t:`${h} Termin${h===1?'':'e'} heute`, s:'Termine öffnen', f:`wechsleAnsicht('termine')`}); }
  if(e.rueckruf !== false){ const rueck = (db.objekte||[]).filter(o=>o.status==='nochmal_anrufen').length; if(rueck) l.push({k:'rueckruf', n:rueck, ic:'🔁', t:`${rueck} Rückruf${rueck===1?'':'e'} offen`, s:'Status „Nochmal anrufen“', f:`AQ2.status='nochmal_anrufen';wechsleAnsicht('akquise')`}); }
  if(e.nachfassen !== false){
    const mails = (db.objekte||[]).filter(o=>o.status==='email_geschrieben' && o.emailAm && Date.now()-o.emailAm>5*864e5).length; if(mails) l.push({k:'mails', n:mails, ic:'✉️', t:`${mails} E-Mail${mails===1?'':'s'} seit über 5 Tagen ohne Antwort`, s:'nachfassen?', f:`AQ2.status='email_geschrieben';wechsleAnsicht('akquise')`});
    const kan = (db.objekte||[]).filter(o=>o.status==='kleinanzeigen_geschrieben' && o.kleinanzeigenAm && Date.now()-o.kleinanzeigenAm>5*864e5).length; if(kan) l.push({k:'ka', n:kan, ic:'💬', t:`${kan} Kleinanzeigen-Nachricht${kan===1?'':'en'} seit über 5 Tagen ohne Antwort`, s:'nachfassen?', f:`AQ2.status='kleinanzeigen_geschrieben';wechsleAnsicht('akquise')`});
  }
  return l;
}
function tbSchluessel(h){ return h.k || ('x:' + h.t); }
function tbGelesen(h){
  const aus = ((db.hinweisEinst||{}).aus||{})[tbSchluessel(h)];
  if(!aus) return false;
  if(h.n != null) return aus.tag === tbHeute() && h.n <= aus.n;       // kommt wieder, wenn es mehr wird oder am nächsten Tag
  return aus.sig === (h.t + '|' + (h.s||''));
}
function tbHinweiseOffen(){ return tbHinweise().filter(h => !tbGelesen(h)); }
function tbAbhaken(h){
  if(h.suche){ akqDb().zuletzt[h.suche] = new Date().toISOString(); return; }
  tbEinst().aus[tbSchluessel(h)] = h.n != null ? { n:h.n, tag:tbHeute() } : { sig: h.t + '|' + (h.s||'') };
}
function tbErledigt(i){ const h = tbHinweiseOffen()[i]; if(!h) return; tbAbhaken(h); save(); tbGlockeAktualisieren(); tbMenueNeu(); }
function tbAlleErledigt(){ tbHinweiseOffen().forEach(tbAbhaken); save(); tbGlockeAktualisieren(); tbMenueNeu(); }
function tbHinweiseHtml(){
  const l = tbHinweiseOffen();
  const fuss = `<div class="hw-fuss">${l.length ? '<button class="secondary tiny" onclick="event.stopPropagation();tbAlleErledigt()">✓ Alle abhaken</button>' : ''}<button class="secondary tiny" onclick="tbMenueZu();tbErinnerungenEinstellen()">⚙ Erinnerungen</button></div>`;
  if(!l.length) return '<div class="mi" style="color:var(--muted);cursor:default;">✅ Alles erledigt – keine Hinweise.</div>' + fuss;
  return l.map((x,i)=>`<div class="mi hw"><span class="hw-ic" onclick="tbMenueZu();${x.f}">${x.ic}</span><div class="hw-txt" onclick="tbMenueZu();${x.f}">${akqEsc(x.t)}<small>${akqEsc(x.s)}</small></div><button class="hw-ok" title="${x.suche ? 'Erledigt – nächste Erinnerung in ' + x.iv + ' Tag' + (x.iv===1?'':'en') : 'Abhaken – kommt wieder, wenn es mehr wird'}" onclick="event.stopPropagation();tbErledigt(${i})">✓</button></div>`).join('') + fuss;
}
function tbMenueNeu(){ const m = document.getElementById('tbMenue'); if(m && m.dataset.art === 'hinweise') m.innerHTML = tbHinweiseHtml(); }
function tbGlockeAktualisieren(){
  const b = document.getElementById('tbGlocke'); if(!b) return;
  const n = tbHinweiseOffen().length; let p = b.querySelector('.punkt');
  if(n){ if(!p){ b.insertAdjacentHTML('beforeend', '<span class="punkt"></span>'); p = b.querySelector('.punkt'); } p.textContent = n > 9 ? '9+' : String(n); b.title = n + ' offene Hinweise'; }
  else { if(p) p.remove(); b.title = 'Keine offenen Hinweise'; }
}
function tbErinnerungenEinstellen(){
  const e = tbEinst(), a = akqDb();
  const tageWahl = [1,2,3,5,7,14,30];
  const zeile = p => { const s = e.suche[p.key] || {}, iv = akqIntervall(p), t = akqVorTagen(a.zuletzt[p.key]);
    return `<div class="hw-zeile"><label class="gs-chk" style="margin:0 !important;"><input type="checkbox" ${s.aus?'':'checked'} onchange="tbEinstSuche('${p.key}','aus',!this.checked)"><span>${p.icon} ${akqEsc(p.titel)}<small>${t===null?'noch nie gemacht':t===0?'zuletzt heute':t===1?'zuletzt gestern':'zuletzt vor '+t+' Tagen'}</small></span></label>
      <select onchange="tbEinstSuche('${p.key}','tage',+this.value)">${tageWahl.concat(tageWahl.includes(iv)?[]:[iv]).sort((x,y)=>x-y).map(d=>`<option value="${d}" ${d===iv?'selected':''}>${d===1?'täglich':'alle '+d+' Tage'}</option>`).join('')}</select></div>`; };
  const schalter = (k, text) => `<label class="gs-chk"><input type="checkbox" ${e[k]===false?'':'checked'} onchange="tbEinstSetzen('${k}',this.checked)"><span>${text}</span></label>`;
  document.getElementById('modalInner').innerHTML = `<h3>🔔 Erinnerungen</h3>
    <div class="gs-intro">Erinnern an Suchen – mit ✓ in der Glocke abgehakt, kommt die Erinnerung erst nach dem eingestellten Abstand wieder.</div>
    ${AKQ_PROMPTS.map(zeile).join('')}
    <div class="gs-intro" style="margin-top:14px;margin-bottom:2px;">Weitere Hinweise – abgehakt kommen sie erst wieder, wenn es mehr werden oder am nächsten Tag:</div>
    ${schalter('neu','🆕 Neue Leads noch nicht kontaktiert')}${schalter('termine','📅 Termine heute')}${schalter('rueckruf','🔁 Offene Rückrufe')}${schalter('nachfassen','✉️ Nachfassen nach 5 Tagen ohne Antwort (E-Mail / Kleinanzeigen)')}${schalter('preis','📉 Preis gesenkt bei einem Lead')}${schalter('suchkunden','👥 Neue Suchkunden passen zu deinen Aufträgen')}${typeof siVerfuegbar==='function' && siVerfuegbar() ? schalter('sicherung','☁️ Sicherung (nicht eingerichtet, fehlgeschlagen oder zu alt)') : ''}
    <div class="modal-actions"><button class="secondary" onclick="tbEinst().aus={};save();tbGlockeAktualisieren();akqToast('Abgehakte Hinweise werden wieder angezeigt')">Abgehakte wieder zeigen</button><div class="right"><button onclick="schliesseModal()">Fertig</button></div></div>`;
  document.getElementById('modalBg').classList.add('show');
}
function tbEinstSuche(key, feld, wert){ const e = tbEinst(); e.suche[key] = Object.assign({}, e.suche[key], { [feld]: wert }); save(); tbGlockeAktualisieren(); }
function tbEinstSetzen(k, an){ tbEinst()[k] = !!an; save(); tbGlockeAktualisieren(); }
function tbMenueZu(){ const m = document.getElementById('tbMenue'); if(m) m.remove(); }
function tbMenue(ev, art){
  ev.stopPropagation();
  const offen = document.getElementById('tbMenue'); if(offen && offen.dataset.art===art){ offen.remove(); return; } tbMenueZu();
  const m = document.createElement('div'); m.id = 'tbMenue'; m.className = 'tb-menue'; m.dataset.art = art;
  if(art==='hinweise'){
    m.innerHTML = tbHinweiseHtml();
  } else {
    m.innerHTML = `<div class="mi" onclick="tbMenueZu();datenOrdnerOeffnen()">📁<div>Datenordner öffnen<small>Dokumente\\MaklerCockpit (mit Sicherungen)</small></div></div>
      ${typeof siVerfuegbar==='function' && siVerfuegbar() ? `<div class="mi" onclick="tbMenueZu();siAssistent()">☁️<div>Automatische Sicherung<small>${siAktiv() ? 'aktiv – zuletzt ' + x20Wann(db.sicherung.letzte) : (db.sicherung && db.sicherung.aus) ? 'ausgeschaltet' : 'einrichten: Kopie in OneDrive / Google Drive'}</small></div></div>` : ''}
      <div class="mi" onclick="tbMenueZu();document.getElementById('importDatei').click()">📥<div>Daten importieren (JSON)<small>ersetzt alle Daten – vorher wird gesichert</small></div></div>
      <div class="mi" onclick="tbMenueZu();gsAssistent()">📅<div>Google Kalender<small>${typeof gsAktiv==='function' && gsAktiv() ? 'verbunden – Einstellungen' : 'verbinden: Termine auf PC und Handy gleich'}</small></div></div>
      <div class="mi" onclick="tbMenueZu();zlDialog()">📄<div>Zeitung einlesen<small>PDF oder Fotos → Leads und Suchkunden</small></div></div>
      <div class="mi" onclick="tbMenueZu();akqVorlageBearbeiten()">✏️<div>Anschreiben-Vorlagen<small>E-Mail, Kleinanzeigen-Nachricht, Nachfassen</small></div></div>
      <div class="mi" onclick="tbMenueZu();wechsleAnsicht('jv-profil')">🤖<div>Jarvis: Profil & KI<small>Steuerdaten, Suchplan, optionaler API-Schlüssel</small></div></div>
      <div class="mi" onclick="tbMenueZu();wechsleAnsicht('dashboard')">📋<div>Alte Übersicht<small>Pipeline, Aufgaben, Mentor-Fragen</small></div></div>
      <div class="mi" style="cursor:default;color:var(--muted);">ℹ️<div>MaklerCockpit ${(window.pc && window.pc.geraet === "handy") ? "Handy-Version 29" : "PC-Version v55"}<small>Daten lokal auf diesem PC · Termine optional mit Google</small></div></div>`;
  }
  if(art==='nutzer' && ev.currentTarget && ev.currentTarget.closest('nav')){ m.style.left = '20px'; m.style.right = 'auto'; m.style.top = 'auto'; m.style.bottom = '70px'; m.style.position = 'fixed'; }
  document.body.appendChild(m);
}
window.addEventListener('load', ()=>{ try{ tbAufbauen(); }catch(e){ console.error(e); } });

// ── v17: PDF speichern mit „Speichern unter“ (für alle Module) ──
async function mcPdfSpeichern(name, base64){
  if(!(window.pc && window.pc.dateiSpeichern)) return;
  const r = await window.pc.dateiSpeichern(name, base64);
  if(!r || r.abgebrochen) return;
  if(!r.ok){ akqToast('⚠️ PDF konnte nicht gespeichert werden: ' + (r.fehler || 'unbekannter Fehler'), 5000); return; }
  let el = document.getElementById('mcPdfHinweis');
  if(!el){ el = document.createElement('div'); el.id = 'mcPdfHinweis'; el.className = 'mc-pdf-hinweis'; document.body.appendChild(el); }
  el.innerHTML = `<span>📄 <b>PDF gespeichert:</b> ${akqEsc(r.name)}</span><button onclick="window.pc.dateiOeffnen(this.parentNode._pfad,'oeffnen');this.parentNode.remove()">Öffnen</button><button class="secondary" onclick="window.pc.dateiOeffnen(this.parentNode._pfad,'ordner');this.parentNode.remove()">Im Ordner zeigen</button><button class="secondary" onclick="this.parentNode.remove()">✕</button>`;
  el._pfad = r.pfad;
  clearTimeout(el._t); el._t = setTimeout(() => { if(el.parentNode) el.remove(); }, 15000);
}
