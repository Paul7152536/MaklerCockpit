/**
 * MaklerCockpit – Google-Brücke (Version 2)
 * 1) Kalender: verbindet dein MaklerCockpit dauerhaft mit deinem Google Kalender.
 * 2) Abgleich: hält PC und Handy auf demselben Stand. Die Daten liegen in deinem Google Drive
 *    im Ordner „MaklerCockpit-Abgleich“ – nur in DEINEM Konto.
 * Den Schlüssel unten nicht weitergeben: wer ihn und die Web-App-Adresse kennt, kann deine Cockpit-Daten lesen.
 */
const SCHLUESSEL = '%%SCHLUESSEL%%';
const API = 'https://www.googleapis.com/calendar/v3';
const ORDNER = 'MaklerCockpit-Abgleich';
const TEILE = 8;                 // Daten auf 8 Dateien verteilt (schneller, unter den Google-Grenzen)
const ANTWORT_MAX = 1500000;     // höchstens ~1,5 MB Daten je Antwort, Rest beim nächsten Abruf

function doPost(e) {
  let a;
  try { a = JSON.parse(e.postData.contents); } catch (x) { return antwort_({ ok: false, status: 400, fehler: 'Ungültige Anfrage' }); }
  if (!a || a.key !== SCHLUESSEL) return antwort_({ ok: false, status: 403, code: 'schluessel', fehler: 'Falscher Schlüssel' });
  try {
    if (a.aktion === 'test') {
      const r = abruf_('GET', '/users/me/calendarList', { maxResults: 1 }, null);
      return antwort_({ ok: r.ok, status: r.status, data: r.data, email: CalendarApp.getDefaultCalendar().getId(), version: 2, abgleich: true });
    }
    if (a.aktion === 'abgleich') return antwort_(abgleich_(a));
    if (a.aktion === 'abgleichStatus') return antwort_(abgleichStatus_());
    if (a.aktion === 'abgleichLeeren') return antwort_(abgleichLeeren_(a));
    const pfad = String(a.pfad || '');
    if (!/^\/(users\/me\/calendarList|calendars\/[^?#\s]+)$/.test(pfad)) return antwort_({ ok: false, status: 400, fehler: 'Pfad nicht erlaubt' });
    return antwort_(abruf_(String(a.methode || 'GET'), pfad, a.query || {}, a.body || null));
  } catch (x) {
    return antwort_({ ok: false, status: 0, fehler: String((x && x.message) || x) });
  }
}

function abruf_(methode, pfad, query, body) {
  const q = Object.keys(query)
    .filter(function (k) { return query[k] !== undefined && query[k] !== null && query[k] !== ''; })
    .map(function (k) { return [].concat(query[k]).map(function (v) { return encodeURIComponent(k) + '=' + encodeURIComponent(v); }).join('&'); })
    .join('&');
  const opt = { method: methode.toLowerCase(), headers: { Authorization: 'Bearer ' + ScriptApp.getOAuthToken() }, muteHttpExceptions: true };
  if (body) { opt.contentType = 'application/json'; opt.payload = JSON.stringify(body); }
  const r = UrlFetchApp.fetch(API + pfad + (q ? '?' + q : ''), opt);
  const st = r.getResponseCode();
  const txt = r.getContentText();
  let data = null;
  try { data = txt ? JSON.parse(txt) : null; } catch (x) {}
  return { ok: st >= 200 && st < 300, status: st, data: data };
}

// ── Abgleich ──
function meta_() {
  const p = PropertiesService.getScriptProperties();
  let m = null; try { m = JSON.parse(p.getProperty('mc_abgleich') || 'null'); } catch (x) {}
  if (!m || !m.dateien) m = { rev: 0, max: [], dateien: [], ordner: '' };
  return m;
}
function metaSpeichern_(m) { PropertiesService.getScriptProperties().setProperty('mc_abgleich', JSON.stringify(m)); }
function ordner_(m) {
  if (m.ordner) { try { return DriveApp.getFolderById(m.ordner); } catch (x) {} }
  const it = DriveApp.getFoldersByName(ORDNER);
  const o = it.hasNext() ? it.next() : DriveApp.createFolder(ORDNER);
  m.ordner = o.getId();
  return o;
}
function teilDatei_(m, i) {
  if (m.dateien[i]) { try { return DriveApp.getFileById(m.dateien[i]); } catch (x) {} }
  const o = ordner_(m), name = 'mc-abgleich-' + i + '.json';
  const it = o.getFilesByName(name);
  const f = it.hasNext() ? it.next() : o.createFile(name, '{}', 'application/json');
  m.dateien[i] = f.getId();
  return f;
}
function teilLesen_(m, i) { try { return JSON.parse(teilDatei_(m, i).getBlob().getDataAsString() || '{}') || {}; } catch (x) { return {}; } }
function teilNr_(k) { let h = 0; for (let i = 0; i < k.length; i++) h = (h * 31 + k.charCodeAt(i)) | 0; return Math.abs(h) % TEILE; }

function abgleich_(a) {
  const lock = LockService.getScriptLock();
  if (!lock.tryLock(25000)) return { ok: false, code: 'belegt', fehler: 'Ein anderes Gerät gleicht gerade ab – gleich nochmal.' };
  try {
    const m = meta_();
    const geraet = String(a.geraet || '').slice(0, 60);
    const teile = {}, geaendert = {};
    const lies = function (i) { if (!teile[i]) teile[i] = teilLesen_(m, i); return teile[i]; };
    const angenommen = [], abgelehnt = [];
    (a.aenderungen || []).forEach(function (c) {
      if (!c || typeof c.s !== 'string' || typeof c.id !== 'string') return;
      const k = c.s + '|' + c.id, i = teilNr_(k), t = lies(i), cur = t[k];
      if (cur && cur.r > (Number(c.b) || 0)) { abgelehnt.push({ s: c.s, id: c.id, r: cur.r, d: cur.d, t: cur.t, g: cur.g }); return; }
      m.rev++;
      t[k] = { r: m.rev, d: c.d === undefined ? null : c.d, g: geraet, t: Date.now() };
      m.max[i] = m.rev; geaendert[i] = true;
      angenommen.push({ s: c.s, id: c.id, r: m.rev });
    });
    Object.keys(geaendert).forEach(function (i) { teilDatei_(m, Number(i)).setContent(JSON.stringify(teile[i])); });
    // Abruf: alles, was seit „seit“ dazukam (in Reihenfolge, auf mehrere Antworten verteilt)
    const seit = Number(a.seit) || 0, liste = [];
    for (let i = 0; i < TEILE; i++) {
      if (!((m.max[i] || 0) > seit)) continue;
      const t = lies(i);
      Object.keys(t).forEach(function (k) { if (t[k].r > seit && !(a.ohneEigene && t[k].g === geraet)) liste.push([k, t[k]]); });
    }
    liste.sort(function (x, y) { return x[1].r - y[1].r; });
    const raus = []; let groesse = 0, bis = m.rev, mehr = false;
    for (let j = 0; j < liste.length; j++) {
      const k = liste[j][0], v = liste[j][1], n = JSON.stringify(v.d).length;
      if (raus.length && groesse + n > ANTWORT_MAX) { mehr = true; bis = liste[j - 1][1].r; break; }
      groesse += n; const p = k.indexOf('|');
      raus.push({ s: k.slice(0, p), id: k.slice(p + 1), r: v.r, d: v.d, t: v.t, g: v.g });
    }
    metaSpeichern_(m);
    return { ok: true, rev: m.rev, epoche: m.neuStart || 0, bis: bis, mehr: mehr, aenderungen: raus, angenommen: angenommen, abgelehnt: abgelehnt, zeit: Date.now() };
  } finally { lock.releaseLock(); }
}
function abgleichStatus_() {
  const m = meta_(); let n = 0, geloescht = 0, bytes = 0;
  for (let i = 0; i < TEILE; i++) {
    if (!m.dateien[i]) continue;
    const t = teilLesen_(m, i);
    Object.keys(t).forEach(function (k) { if (t[k].d === null) geloescht++; else n++; });
    try { bytes += teilDatei_(m, i).getSize(); } catch (x) {}
  }
  return { ok: true, rev: m.rev, eintraege: n, geloescht: geloescht, bytes: bytes, zeit: Date.now() };
}
function abgleichLeeren_(a) {
  if (a.bestaetigung !== 'LEEREN') return { ok: false, fehler: 'Bestätigung fehlt' };
  const lock = LockService.getScriptLock(); if (!lock.tryLock(25000)) return { ok: false, code: 'belegt', fehler: 'Gerade belegt' };
  try {
    const m = meta_();
    for (let i = 0; i < TEILE; i++) { if (m.dateien[i]) { try { teilDatei_(m, i).setContent('{}'); } catch (x) {} } m.max[i] = 0; }
    m.rev = 0; m.neuStart = Date.now(); metaSpeichern_(m);
    return { ok: true, rev: 0 };
  } finally { lock.releaseLock(); }
}

function antwort_(o) {
  return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON);
}

function doGet() {
  return ContentService.createTextOutput('MaklerCockpit Google-Brücke (Version 2) läuft.');
}
