/* MaklerCockpit v9 – Akquise-Zentrale
   Suchen (Prompts für Claude/ChatGPT) → Ergebnis einfügen → automatisch Objekte + Kontakte anlegen (mit Dublettenprüfung und Rückgängig).
   Liest Pauls Zeitungsformat (Name:/Objekt:/Lage:/Preis:/Telefon:/E-Mail:/Eingestellt am:/Privat eindeutig:/Details:/Seite:/Status:),
   ähnliche Klartext-Listen, Markdown-Tabellen und JARVIS-IMPORT-Blöcke (Akquise, Hausverwaltungen; Rest geht an Jarvis). */

// ── Grundlagen ──
function akqDb(){
  db.akquise = db.akquise || {};
  const a = db.akquise;
  a.zuletzt = a.zuletzt || {};
  a.importe = Array.isArray(a.importe) ? a.importe : [];
  a.einst = Object.assign({gebiet:"Berlin und Berliner Umland (Speckgürtel, ca. 30 km)", arten:"Häuser, Wohnungen, Grundstücke, Mehrfamilienhäuser", nurPrivat:true, anzahl:20, tage:7}, a.einst||{});
  if(!a.vorlage) a.vorlage = AKQ_VORLAGE_STD;
  return a;
}
const AKQ_VORLAGE_STD = `Guten Tag{anrede},

ich habe Ihre Anzeige „{objekt}“ in {ort} gesehen{quelle_satz}. Mein Name ist Paul Görner, ich bin Immobilienmakler bei BETTERHOMES in Berlin.

Falls Sie beim Verkauf Unterstützung möchten – etwa bei der Preisfindung, den Unterlagen oder der Auswahl geprüfter Käufer –, melde ich mich gern kurz telefonisch. Wenn nicht, ist das völlig in Ordnung; dann wünsche ich Ihnen viel Erfolg beim Verkauf.

Viele Grüße
Paul Görner
BETTERHOMES · Görner Immobilien`;
function akqToast(t, ms){
  let el = document.getElementById('akqToast');
  if(!el){ el = document.createElement('div'); el.id = 'akqToast'; el.style.cssText = 'position:fixed;bottom:22px;left:50%;transform:translateX(-50%);background:#2e3138;border:1px solid var(--orange);color:var(--text);border-radius:10px;padding:10px 16px;font-size:13px;z-index:9999;box-shadow:0 10px 30px rgba(0,0,0,.45);max-width:90vw;transition:opacity .2s;'; document.body.appendChild(el); }
  el.textContent = t; el.style.opacity = '1'; clearTimeout(el._t); el._t = setTimeout(()=>{ el.style.opacity = '0'; }, ms||2800);
}
async function akqKopieren(text, meldung){
  let ok = false;
  try{ await navigator.clipboard.writeText(text); ok = true; }catch(e){
    const ta = document.createElement('textarea'); ta.value = text; document.body.appendChild(ta); ta.select();
    try{ ok = document.execCommand('copy'); }catch(e2){} ta.remove();
  }
  akqToast(ok ? (meldung||'Kopiert ✓') : 'Kopieren ging nicht – bitte von Hand markieren');
  return ok;
}
const akqEsc = s => (s===null||s===undefined) ? '' : String(s).replace(/[&<>"']/g, m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
const akqNorm = s => String(s||'').toLowerCase().replace(/ä/g,'ae').replace(/ö/g,'oe').replace(/ü/g,'ue').replace(/ß/g,'ss').replace(/[^a-z0-9]+/g,' ').trim();
function akqTelNorm(t){ let d = String(t||'').replace(/[^\d+]/g,''); if(d.startsWith('+49')) d = '0'+d.slice(3); else if(d.startsWith('0049')) d = '0'+d.slice(4); return d.replace(/\+/g,''); }
function akqZahl(s){ s = String(s||'').trim(); if(!s) return 0; if(/^\d{1,3}(\.\d{3})+(,\d+)?$/.test(s)) s = s.replace(/\./g,'').replace(',','.'); else s = s.replace(/\.(?=\d{3}\b)/g,'').replace(',','.'); const n = parseFloat(s); return isFinite(n) ? n : 0; }

// ── Erkennen: Schlüssel, Werte ──
const AKQ_KEYS = [
  ["anzeigentyp", /^(anzeigentyp|anzeigenart|typ der anzeige|angebot oder gesuch|art der anzeige)$/],
  ["sucht", /^(sucht|gesucht|gesucht wird|sucht nach|wunschobjekt|suchprofil|sucht folgendes)$/],
  ["budget", /^(budget|kaufbudget|preis bis|max preis|maximaler preis|preisrahmen|preisvorstellung des k[aä]ufers)$/],
  ["preiseinschaetzung", /^(preis einsch[aä]tzung|preiseinsch[aä]tzung|preis check|preischeck|marktpreis|marktgerecht|preisbewertung)$/],
  ["kaeufer", /^(passende k[aä]ufer|k[aä]ufergruppen?|k[aä]ufer|zielgruppen?|wer passt|passende k[aä]ufergruppen?)$/],
  ["ansprache", /^(ansprache|k[aä]uferansprache|vermarktung|kan[aä]le)$/],
  ["name", /^(name|anbieter(in)?|verk[aä]ufer(in)?|ansprechpartner(in)?|kontaktperson|inserent(in)?|eigent[uü]mer(in)?|kontaktname)$/],
  ["inserattitel", /^(titel|inserat\s*titel|anzeigen\s*titel|titel der anzeige|[uü]berschrift)$/],   // v54: echter Titel aus dem Inserat
  ["objekt", /^(objekt|objektart|art|angebot|immobilie|immobilientyp|typ|was)$/],
  ["lage", /^(lage|ort|adresse|standort|region|gebiet|stadt|ortsteil|plz\s*\/?\s*ort|ort\s*\/\s*lage)$/],
  ["preis", /^(preis|kaufpreis|vb|preisvorstellung|miete|kaltmiete|warmmiete|preis\s*\/\s*miete|preisangabe)$/],
  ["telefon", /^(telefon|tel|handy|mobil|mobilnummer|rufnummer|telefonnummer|tel\s*nr|telefon\s*\/\s*handy)$/],
  ["email", /^(e\s*mail|email|mail|e\s*mail\s*adresse)$/],
  ["kontakt", /^(kontakt|kontaktdaten|erreichbar|kontaktweg|chiffre)$/],
  ["datum", /^(eingestellt\s*am|eingestellt|datum|erschienen(\s*am)?|inseriert(\s*seit|\s*am)?|online\s*seit|ver[oö]ffentlicht(\s*am)?|anzeigendatum|zeitungsdatum|ausgabe\s*vom)$/],
  ["privat", /^(privat(\s*eindeutig)?|privatangebot|anbieterart|anbietertyp|von\s*privat|privat\s*\?)$/],
  ["details", /^(details|beschreibung|hinweise?|infos?|merkmale|sonstiges|bemerkung(en)?|text|anzeigentext|eckdaten|ausstattung)$/],
  ["seite", /^(seite|rubrik|seite\s*\/\s*rubrik|fundstelle)$/],
  ["status", /^(status|einsch[aä]tzung|bewertung|fazit|empfehlung)$/],
  ["quelle", /^(quelle|zeitung|medium|plattform|portal|ausgabe|anzeigenblatt)$/],
  ["link", /^(link|url|inserat|anzeigenlink|anzeigen link|anzeige|webseite|website|direktlink|inseratslink|inserat link|expos[eé]|expos[eé] link|expos[eé]link|link zum (expos[eé]|inserat|angebot|anzeige))$/],
  ["wohnflaeche", /^(wohnfl[aä]che|wfl|fl[aä]che|wohnfl)$/],
  ["grundstueck", /^(grundst[uü]ck(sfl[aä]che|sgr[oö][sß]e)?|grundst)$/],
  ["zimmer", /^(zimmer|zi|r[aä]ume|zimmeranzahl)$/],
  ["baujahr", /^(baujahr|bj)$/],
];
function akqKey(k){
  k = String(k||'').toLowerCase().replace(/[*_`#>\[\]]/g,'').replace(/[\u{1F000}-\u{1FAFF}☀-➿️]/gu,'').replace(/^[\s\-•·–]+/,'').replace(/[.:]+$/,'').replace(/-/g,' ').replace(/\s+/g,' ').trim();
  for(const [n,re] of AKQ_KEYS) if(re.test(k)) return n;
  return null;
}
function akqKV(zeile){
  const m = /^\s*(?:[-*•·]\s*)?\**\s*([A-Za-zÄÖÜäöüßÉé][A-Za-zÄÖÜäöüßÉé .\/\-?]{0,38}?)\s*\**\s*:\s*\**\s*(.*?)\s*\**\s*$/u.exec(zeile);
  if(!m) return null;
  const k = akqKey(m[1]); if(!k) return null;
  return [k, m[2]];
}
function akqWert(v){
  v = String(v||'').replace(/\*\*/g,'').replace(/^["„“]+|["“”]+$/g,'').trim();
  if(/^(nicht\s+angegeben|k\.?\s*a\.?|keine\s+angabe|unbekannt|n\/a|ohne\s+angabe|nicht\s+genannt|nicht\s+vorhanden|fehlt|—|–|-)(\b|$)/i.test(v)) return '';
  return v;
}

// ── Zerlegen in Einträge ──
function akqBloecke(text){
  const zeilen = String(text||'').replace(/\r/g,'').split('\n');
  const bloecke = []; let akt = null, letzter = null, letzteNr = 0;
  const neu = ()=>{ if(akt && Object.keys(akt.f).length) bloecke.push(akt); akt = {f:{}, titel:''}; letzter = null; };
  neu();
  for(const z of zeilen){
    const s = z.trim();
    if(!s) continue;
    if(/^(-{3,}|_{3,}|\*{3,}|={3,}|```.*)$/.test(s)) { if(!/^```/.test(s)) neu(); continue; }
    if(/^(JARVIS-IMPORT|JARVIS-ENDE|gesamt\s*:)/i.test(s)) { neu(); continue; }
    const nr = /^\**\s*(?:#{1,4}\s*)?(?:anzeige\s*|nr\.?\s*)?(\d{1,3})\s*[.):]\s*\**\s*(.*)$/i.exec(s);
    if(nr){
      const n = +nr[1], rest = nr[2].replace(/\*\*/g,'').trim();
      const kv = rest ? akqKV(rest) : null;
      if(!rest || kv || n===1 || n===letzteNr+1){
        neu(); letzteNr = n;
        if(kv){ akt.f[kv[0]] = kv[1]; letzter = kv[0]; }
        else if(rest) akt.titel = rest.replace(/^[–\-:\s]+/,'');
        continue;
      }
    }
    const kv = akqKV(s);
    if(kv){
      const [k,v] = kv;
      if(akt.f[k]!==undefined && !['details','status'].includes(k)) neu();
      akt.f[k] = (akt.f[k]!==undefined) ? akt.f[k]+' '+v : v; letzter = k; continue;
    }
    // Überschrift wie "### Einfamilienhaus in Teltow" oder Fortsetzungszeile
    const h = /^#{1,4}\s*(.+)$/.exec(s);
    if(h){ neu(); akt.titel = h[1].replace(/\*\*/g,'').trim(); continue; }
    if(letzter) akt.f[letzter] += ' ' + s.replace(/^[-•·*]\s*/,'');
    else if(!akt.titel && s.length<120) akt.titel = s.replace(/\*\*/g,'');
  }
  neu();
  return bloecke.filter(b=>{ const f = b.f; return (f.objekt||b.titel||f.lage||f.preis||f.sucht) && (f.lage||f.preis||f.budget||f.telefon||f.email||f.kontakt||f.details||f.link||f.name); });
}
function akqTabelle(text){
  const zeilen = String(text||'').split('\n').map(z=>z.trim()).filter(z=>/^\|.*\|$/.test(z));
  if(zeilen.length<3) return [];
  const zellen = z=>z.slice(1,-1).split('|').map(c=>c.trim());
  const kopf = zellen(zeilen[0]).map(akqKey);
  if(kopf.filter(Boolean).length<2) return [];
  return zeilen.slice(1).filter(z=>!/^\|\s*:?-{2,}/.test(z)).map(z=>{ const c = zellen(z), f = {}; kopf.forEach((k,i)=>{ if(k && c[i]) f[k] = c[i]; }); return {f, titel:''}; })
    .filter(b=>b.f.objekt||b.f.lage||b.f.preis);
}
// JARVIS-IMPORT-Blöcke (JSON je Zeile)
function akqJsonEnde(s,start){ let t=0,str=false,es=false; for(let i=start;i<s.length;i++){ const c=s[i]; if(str){ if(es) es=false; else if(c==='\\') es=true; else if(c==='"') str=false; continue; } if(c==='"') str=true; else if(c==='{') t++; else if(c==='}'){ t--; if(t===0) return i; } } return -1; }
function akqJarvis(text){
  const m = /JARVIS-IMPORT\s*(?:typ\s*[=:]\s*([A-Za-zäöü_]+))?/i.exec(text||'');
  if(!m) return null;
  let rest = text.slice(m.index+m[0].length); const e = rest.search(/JARVIS-ENDE/i); if(e>=0) rest = rest.slice(0,e);
  if((rest.match(/"/g)||[]).length<4) rest = rest.replace(/[“”„]/g,'"');
  const liste = []; let pos = 0;
  while(true){ const i = rest.indexOf('{',pos); if(i<0) break; const j = akqJsonEnde(rest,i); if(j<0) break;
    try{ const o = JSON.parse(rest.slice(i,j+1).replace(/[\u0000-\u001f]+/g,' ')); if(o && typeof o==='object' && !Array.isArray(o)) liste.push(o); }catch(err){}
    pos = j+1; }
  let typ = (m[1]||'').toLowerCase();
  const alias = {akquise:'akquise',leads:'akquise',lead:'akquise',hv:'hausverwaltungen',hausverwaltungen:'hausverwaltungen',hausverwaltung:'hausverwaltungen'};
  typ = alias[typ] || typ;
  if(!typ && liste.length){ const k = new Set(Object.keys(liste[0])); typ = k.has('nachricht')||k.has('plattform') ? 'akquise' : (k.has('name')&&!k.has('kaufpreis')) ? 'hausverwaltungen' : 'andere'; }
  return {typ, liste};
}
function akqAusJson(it){
  const t = x => (x===null||x===undefined) ? '' : String(x).trim();
  return {f:{ name:t(it.anbieter||it.name||it.verkaeufer), objekt:t(it.titel||it.objektart), lage:t(it.adresse||it.ort), preis:t(it.preis||it.kaufpreis), telefon:t(it.telefon), email:t(it.email),
    datum:t(it.inseriert_seit||it.datum), privat:t(it.privat), details:[t(it.details),t(it.warum)].filter(Boolean).join(' – '), quelle:t(it.plattform||it.quelle), link:t(it.url||it.link),
    wohnflaeche:t(it.flaeche||it.wohnflaeche), grundstueck:t(it.grundstueck), zimmer:t(it.zimmer), baujahr:t(it.baujahr), status:t(it.prio?('Priorität '+it.prio):''), nachricht:t(it.nachricht)}, titel:'' };
}

// ── Aufbereiten ──
function akqObjektart(t){
  t = String(t||'').toLowerCase();
  if(/mehrfamilien|\bmfh\b|zinshaus|wohn-?\s*und\s*gesch[aä]ftshaus|mehrparteien|renditeobjekt/.test(t)) return 'MFH';
  if(/doppelhaush|\bdhh\b|doppelhaus/.test(t)) return 'DHH';
  if(/reihen(end|mittel|eck)?haus|\brh\b|\brmh\b|\breh\b/.test(t)) return 'Reihenhaus';
  if(/einfamilien|\befh\b|bungalow|villa|landhaus|siedlungshaus|stadthaus|zweifamilien|\bzfh\b|\bhaus\b|h[aä]uschen|resthof|bauernhaus|fachwerkhaus/.test(t)) return 'EFH';
  if(/wohnung|\betw\b|apartment|appartement|penthouse|maisonette|\bloft\b|dachgeschoss|\d\s*[,.]?\s*\d?\s*-?\s*zi(\.|\b|mmer)|zimmer/.test(t)) return 'Wohnung';
  if(/grundst[uü]ck|bauland|baugrund|bauplatz|baul[uü]cke|acker|wiese|waldst|gartenland|erholungsgrundst|freizeitgrundst|parzelle/.test(t)) return 'Grundstück';
  if(/gewerbe|laden|b[uü]ro|halle|praxis|gastronomie|lager|werkstatt|hotel|pension/.test(t)) return 'Gewerbe';
  return 'Sonstiges';
}
function akqPreis(t){
  t = String(t||'').toLowerCase().replace(/\s+/g,' '); if(!t) return 0;
  let m = /(\d+(?:[.,]\d+)?)\s*(mio|millionen)/.exec(t); if(m) return Math.round(akqZahl(m[1])*1e6);
  m = /(\d+(?:[.,]\d+)?)\s*(t€|t ?eur|tsd|tausend|k€|k\b)/.exec(t); if(m) return Math.round(akqZahl(m[1])*1000);
  m = /(\d{1,3}(?:[.\s]\d{3})+|\d{3,})(?:,\d{1,2})?/.exec(t); if(m) return Number(m[1].replace(/[.\s]/g,''))||0;
  m = /(\d+(?:,\d{1,2})?)/.exec(t); return m ? akqZahl(m[1]) : 0;
}
function akqFlaechen(text, art){
  const t = String(text||''); const r = {wohnflaeche:0, grundstueck:0, zimmer:'', baujahr:''};
  const qm = '(?:m²|m2|qm|quadratmeter)';
  let m = new RegExp('(\\d[\\d.,]*)\\s*'+qm+'\\s*(?:gro(?:ß|ss)es\\s*|gr\\.\\s*)?(?:grundst|gst|grdst|grst|grd\\b|grund\\b|gartengrundst|land)','i').exec(t) || new RegExp('(?:grundst\\w*|grdst\\.?|grst\\.?)\\s*(?:fl[aä]che|gr[oö](?:ß|ss)e)?\\s*(?:von|ca\\.?|:|mit)?\\s*(?:ca\\.?\\s*)?(\\d[\\d.,]*)\\s*'+qm,'i').exec(t);
  if(m) r.grundstueck = Math.round(akqZahl(m[1]));
  m = new RegExp('(\\d[\\d.,]*)\\s*'+qm+'\\s*(?:wfl|wohnfl|wohnfl[aä]che|wf\\b|wohnraum)','i').exec(t) || new RegExp('wohnfl\\w*\\s*(?:von|ca\\.?|:)?\\s*(?:ca\\.?\\s*)?(\\d[\\d.,]*)','i').exec(t);
  if(m) r.wohnflaeche = Math.round(akqZahl(m[1]));
  if(art==='Grundstück' && !r.grundstueck){ m = new RegExp('(\\d[\\d.,]*)\\s*'+qm,'i').exec(t); if(m) r.grundstueck = Math.round(akqZahl(m[1])); }
  if(art!=='Grundstück' && !r.wohnflaeche){ const alle = [...t.matchAll(new RegExp('(\\d[\\d.,]*)\\s*'+qm+'(?!\\s*(?:gro(?:ß|ss)es\\s*)?(?:grundst|gst|grdst|grst|grd\\b|grund\\b|land))','gi'))]; if(alle.length) r.wohnflaeche = Math.round(akqZahl(alle[0][1])); }
  m = /(\d+(?:[,.]5)?)\s*-?\s*(?:zi\b|zi\.|zimmer|zkb|raum\b|r[aä]ume)/i.exec(t); if(m) r.zimmer = m[1].replace('.',',');
  m = /(?:bj\.?|baujahr|erbaut|errichtet)\s*(?:ca\.?|um)?\s*:?\s*((?:18|19|20)\d\d)/i.exec(t); if(m) r.baujahr = m[1];
  return r;
}
function akqPrivat(t, rest){
  t = String(t||'').toLowerCase().replace(/\*\*/g,'').trim();
  if(t){
    if(/🟢/.test(t)) return 'ja';
    if(/🟡/.test(t)) return 'unklar';
    if(/🔴/.test(t)) return 'nein';
    if(/^(ja|yes|eindeutig)\b/.test(t)) return 'ja';
    if(/^(nein|no)\b/.test(t)) return 'nein';
    if(/^(unklar|wahrscheinlich|vermutlich|unsicher|evtl|vielleicht|eher)/.test(t)) return 'unklar';
    if(/gewerblich|bautr[aä]ger|maklerangebot|^makler/.test(t)) return 'nein';
    if(/von privat|privat/.test(t)) return 'ja';
  }
  rest = String(rest||'').toLowerCase();
  if(/von privat|privatverkauf|privat zu verkaufen|privatanbieter|ohne makler|provisionsfrei|keine makler/.test(rest)) return 'ja';
  if(/provision|courtage|maklerprovision|k[aä]uferprovision|bautr[aä]ger/.test(rest)) return 'nein';
  return 'unklar';
}
function akqDatum(t){
  t = String(t||''); let m;
  if((m = /(\d{1,2})\.(\d{1,2})\.(\d{2,4})/.exec(t))){ const j = +m[3]<100 ? 2000 + +m[3] : +m[3]; return `${j}-${String(m[2]).padStart(2,'0')}-${String(m[1]).padStart(2,'0')}`; }
  if((m = /(\d{4})-(\d{2})-(\d{2})/.exec(t))) return m[0];
  if(/heute/i.test(t)) return new Date().toISOString().slice(0,10);
  if(/gestern/i.test(t)) return new Date(Date.now()-864e5).toISOString().slice(0,10);
  return '';
}
function akqQuelle(f){
  const q = [f.quelle, f.link, f.seite].join(' ').toLowerCase();
  if(/kleinanzeigen|ebay/.test(q)) return 'Kleinanzeigen';
  if(/immobilienscout|immoscout|is24|immowelt|immonet|ohne-makler|immobilien\.de/.test(q)) return 'ImmoScout';
  if(f.seite || /zeitung|morgenpost|tagesspiegel|\bmaz\b|m[aä]rkische|\bmoz\b|\bb\.?z\b|wochenblatt|anzeiger|kurier|berliner woche|abendblatt|lausitzer|rundschau|nachrichten|anzeigenblatt|ausgabe/.test(q)) return 'Zeitung';
  return 'Direktakquise';
}
const AKQ_STRASSE = /(?:stra(?:ß|ss)e|str\.|weg|allee|platz|damm|ring|chaussee|ufer|gasse|steig|pfad|promenade|zeile|anger|markt|siedlung|stieg)\s*\d+\s*[a-z]?(?:\s*-\s*\d+)?\b/i;
function akqAdresse(lage){
  lage = String(lage||'').trim();
  const teile = lage.split(/\s*[,;]\s*/).filter(Boolean);
  const i = teile.findIndex(t=>AKQ_STRASSE.test(t) && t.length<60);
  if(i>=0 && teile.length>1){ const adresse = teile[i]; const ort = teile.filter((t,j)=>j!==i).join(', '); return {adresse, ort}; }
  if(i>=0){ const m = new RegExp('^(.*?'+AKQ_STRASSE.source+')\\s*(.*)$','i').exec(lage); if(m) return {adresse:m[1].trim(), ort:(m[2]||'').trim()}; }
  return {adresse:'', ort:lage};
}
function akqLinkAus(...texte){
  const urls = [];
  texte.forEach(t => { String(t||'').replace(/https?:\/\/[^\s<>()\[\]"'„“]+/gi, u => { urls.push(u.replace(/[.,;:!?…]+$/,'')); return u; }); });
  const gut = u => /expose|expos%c3%a9|s-anzeige|\/anzeige|inserat|objekt|immobilie|angebot/i.test(u) && !/\/(suche|search|liste)\b|[?&](sorting|pagenumber|geocodes)=/i.test(u);
  return urls.find(gut) || urls[0] || '';
}
function akqAufbereiten(b){
  const f = {}; Object.entries(b.f).forEach(([k,v])=>{ f[k] = akqWert(v); });
  const roh = b.f;
  const titel = f.inserattitel || f.objekt || akqWert(b.titel) || '';
  const alles = [titel, f.objekt, f.details, f.preis, roh.objekt, b.titel].join(' ');
  const art = akqObjektart([f.objekt, titel, b.titel].join(' ')) !== 'Sonstiges' ? akqObjektart([f.objekt, titel, b.titel].join(' ')) : akqObjektart(alles);
  const preisZahl = akqPreis(f.preis);
  const vermietung = /(zu vermieten|\bmiete\b|mietwohnung|kaltmiete|warmmiete|nachmieter|untermiete|\/\s*monat|\bmtl\b|monatlich|€\s*(kalt|warm)|nettokalt)/i.test([titel, f.preis].join(' ')) && !/kaufpreis|zu verkaufen|verkauf|eigentum/i.test([titel, f.preis].join(' ')) && !(preisZahl >= 20000);
  const kontaktText = [f.kontakt, f.telefon, f.email, roh.telefon, roh.email].join(' ');
  const ohneChiffre = x => /chiffre/i.test(x||'') ? '' : String(x||'').replace(/https?:\/\/\S+/gi, ' ');
  const tel = (f.telefon && /\d{4,}/.test(f.telefon) && !/chiffre/i.test(f.telefon)) ? f.telefon.replace(/\s{2,}/g,' ').trim() : ((/(\+?\d[\d\s\/()\-]{5,}\d)/.exec(ohneChiffre(f.kontakt)+' '+ohneChiffre(f.details))||[])[1]||'').trim();
  const mail = ((/[\w.+-]+@[\w-]+(?:\.[\w-]+)+/.exec(kontaktText)||/[\w.+-]+@[\w-]+(?:\.[\w-]+)+/.exec(f.details||'')||[])[0]||'').toLowerCase();
  let chiffre = ''; for(const x of [roh.telefon, roh.email, roh.kontakt, f.details]){ const m = /chiffre\s*(?:nr\.?|nummer)?\s*[:\-]?\s*([A-ZÄÖÜ]{1,4}\s?\d[\w\-\/]{0,12}|[A-Za-z0-9][\w\-\/]{0,15})/i.exec(String(x||'')); if(m){ chiffre = m[1]; break; } }
  const fl = akqFlaechen([titel, f.details, f.wohnflaeche ? f.wohnflaeche+' m² Wohnfläche' : '', f.grundstueck ? f.grundstueck+' m² Grundstück' : '', f.zimmer ? f.zimmer+' Zimmer' : '', f.baujahr ? 'Baujahr '+f.baujahr : ''].join(' · '), art);
  const ad = akqAdresse(f.lage);
  const name = f.name && !/^privat(verk[aä]ufer|anbieter)?$/i.test(f.name) ? f.name : '';
  return {titel: titel || [art, ad.ort].filter(Boolean).join(' in '), objektart:art, auftragsart: vermietung ? 'vermietung' : 'verkauf', adresse:ad.adresse, ort:ad.ort, lageRoh:f.lage||'',
    preis: akqPreis(f.preis), preisText:f.preis||'', telefon:tel, email:mail, chiffre, name, datum:akqDatum(f.datum), datumText:f.datum||'', privat:akqPrivat(roh.privat, alles),
    privatText:roh.privat ? String(roh.privat).replace(/\*\*/g,'').trim() : '', details:f.details||'', seite:f.seite||'', statusText:f.status||'', quelleText:f.quelle||'', link: akqLinkAus(roh.link) || akqLinkAus(...Object.values(roh), b.titel),
    quelle: akqQuelle(f), nachricht:f.nachricht||'', ...fl,
    typ: /gesuch|such/i.test(f.anzeigentyp||'') ? 'gesuch' : 'angebot', sucht:f.sucht||'', budget:f.budget||'', kiPreis:f.preiseinschaetzung||'', kiKaeufer:f.kaeufer||'', kiAnsprache:f.ansprache||''};
}
function akqLesen(text){
  const j = akqJarvis(text);
  if(j) return {art: j.typ==='akquise' ? 'akquise' : j.typ==='hausverwaltungen' ? 'hv' : 'jarvis', jarvis:j, eintraege: j.typ==='akquise' ? j.liste.map(akqAusJson).map(akqAufbereiten) : []};
  let bl = akqBloecke(text);
  if(!bl.length) bl = akqTabelle(text);
  return {art:'akquise', eintraege: bl.map(akqAufbereiten)};
}

// ── Übernehmen ──
function akqVorlageFuellen(e){
  const a = akqDb();
  const anrede = e.name ? ' '+e.name : '';
  const qs = e.quelle==='Zeitung' ? ` (${e.quelleText||'Zeitung'}${e.datum?' vom '+new Date(e.datum).toLocaleDateString('de-DE'):''})` : e.quelle==='Kleinanzeigen' ? ' (Kleinanzeigen)' : e.quelle==='ImmoScout' ? ' (Immobilienportal)' : '';
  return a.vorlage.replace(/\{anrede\}/g, anrede).replace(/\{objekt\}/g, e.titel||e.objektart).replace(/\{ort\}/g, e.ort||e.lageRoh||'Ihrer Region').replace(/\{quelle_satz\}/g, qs ? ' '+qs.trim() : '');
}
// v20: Preisänderung mit Verlauf (Startpreis bleibt gemerkt → „Preis gesenkt“)
function akqPreisAendern(o, neu, wie){
  neu = Math.round(Number(neu)||0); const alt = Math.round(Number(o.kaufpreis)||0);
  if(!(neu > 0) || neu === alt) return 0;
  if(alt > 0){
    if(!(Number(o.preisStart) > 0)) o.preisStart = alt;
    o.preisHistorie = Array.isArray(o.preisHistorie) ? o.preisHistorie : [];
    o.preisHistorie.push({ts:Date.now(), alt, neu, wie:wie||''});
    if(o.preisHistorie.length > 20) o.preisHistorie = o.preisHistorie.slice(-20);
    if(neu < alt) o.preisGesenktAm = Date.now();
    if(neu >= o.preisStart) delete o.preisGesenktAm;
  }
  o.kaufpreis = neu;
  if(alt > 0){
    const t = (neu < alt ? '📉 Preis gesenkt: ' : '📈 Preis erhöht: ') + alt.toLocaleString('de-DE') + ' € → ' + neu.toLocaleString('de-DE') + ' €' + (wie==='Anzeige' ? ' (laut Anzeige)' : '');
    if(typeof aqLog === 'function') aqLog(o, 'info', t); else if(Array.isArray(o.verlauf)) o.verlauf.push({ts:Date.now(), typ:'info', text:t});
  }
  return neu - alt;
}
function akqNotizen(e){
  const z = [];
  const q = [e.quelleText, e.seite ? 'Seite '+e.seite : ''].filter(Boolean).join(', ');
  z.push(`<b>📥 Akquise · ${akqEsc(e.quelle)}</b>${q?' – '+akqEsc(q):''}${e.datumText?' · eingestellt '+akqEsc(e.datumText):''}`);
  if(e.titel) z.push('Objekt: '+akqEsc(e.titel));
  if(e.lageRoh) z.push('Lage: '+akqEsc(e.lageRoh));
  if(e.preisText) z.push('Preis: '+akqEsc(e.preisText));
  if(e.details) z.push('Details: '+akqEsc(e.details));
  if(e.privatText) z.push('Privat: '+akqEsc(e.privatText));
  if(e.statusText) z.push('Einschätzung: '+akqEsc(e.statusText));
  if(e.chiffre) z.push('Chiffre: '+akqEsc(e.chiffre));
  if(e.link) z.push(`Link: <a href="${akqEsc(e.link)}" target="_blank">${akqEsc(e.link)}</a>`);
  return z.join('<br>');
}
function akqUebernehmen(eintraege, quelleHinweis){
  const a = akqDb(), importId = 'imp'+Date.now(), heute = new Date().toLocaleDateString('de-DE');
  const ber = {id:importId, zeit:new Date().toISOString(), neuObjekte:0, neuKontakte:0, doppelt:0, leer:0, liste:[], quelle:quelleHinweis||''};
  const basisZeit = Date.now(); let nr = 0;
  for(const e of eintraege){
    if(!e.titel && !e.ort && !e.preis){ ber.leer++; continue; }
    nr++;
    const tel = akqTelNorm(e.telefon), mail = e.email;
    let k = db.kontakte.find(x=> (mail && String(x.email||'').toLowerCase()===mail) || (tel.length>=7 && akqTelNorm(x.telefon)===tel));
    let kNeu = false;
    if(!k && (e.name || tel || mail)){
      k = {id:uid(), createdAt:Date.now(), name: e.name || ('Privat – '+(e.ort||e.lageRoh||e.objektart)+(mail?' ('+mail+')':tel?' ('+e.telefon+')':'')), telefon:e.telefon||'', email:mail||'', adresse:'',
        kontaktart:'eigentuemer', quelle:e.quelle, status:'lead', prioritaet: e.privat==='ja' ? 'hoch' : 'mittel', notizen:`Akquise ${heute}: ${e.titel||e.objektart}${e.ort?' in '+e.ort:''}${e.quelleText?' ('+e.quelleText+')':''}`, importId};
      db.kontakte.push(k); kNeu = true; ber.neuKontakte++;
    }
    const ortN = akqNorm(e.ort||e.lageRoh);
    const titelN = akqNorm(e.titel||'');
    const gleicherTitel = o => titelN.length >= 12 && o.importId !== importId && akqNorm(o.akqTitel||'')===titelN && o.objektart===e.objektart && akqNorm(o.ort||'')===ortN &&
      ((e.wohnflaeche && o.wohnflaeche) ? Math.abs(Number(o.wohnflaeche)-Number(e.wohnflaeche)) <= 1 : !(e.link && o.link)) &&
      !(e.preis && Number(o.kaufpreis) > 0 && (e.preis/Number(o.kaufpreis) < 0.7 || e.preis/Number(o.kaufpreis) > 1.3)) &&
      !(k && o.eigentuemerId && o.eigentuemerId !== k.id) && !(tel.length >= 7 && o.verkaeuferTelefon && akqTelNorm(o.verkaeuferTelefon) !== tel);
    const dupe = (e.link && (typeof dl50LinkKey !== 'function' || dl50LinkKey(e.link)) && db.objekte.find(o=>o.link===e.link)) || db.objekte.find(o=>   // v50: Such-/Listenseiten sind kein Erkennungsmerkmal
      (k && o.eigentuemerId===k.id && o.objektart===e.objektart && akqNorm(o.ort||'')===ortN && !(e.link && o.link)) ||   // v50: zwei Inserate desselben Verkäufers bleiben zwei Leads
      (!k && e.preis && Number(o.kaufpreis)===e.preis && o.objektart===e.objektart && akqNorm(o.ort||'')===ortN && !(e.link && o.link)) ||
      gleicherTitel(o));
    if(dupe){
      // v20: Preisänderung erkennen (Preis gesenkt / erhöht) statt nur zu notieren
      const preisAlt = Number(dupe.kaufpreis)||0;
      let preisInfo = '';
      if(e.preis && preisAlt > 0 && e.preis !== preisAlt){
        const q = e.preis / preisAlt;
        if(q > 0.5 && q < 1.5 && !(dupe.auftragsart==='vermietung' && preisAlt < 20000)) akqPreisAendern(dupe, e.preis, 'Anzeige');
        else preisInfo = ' – Preis in der Anzeige: '+e.preis.toLocaleString('de-DE')+' € (nicht übernommen, bitte prüfen)';
      }
      ['kaufpreis','wohnflaeche','grundstueck','baujahr'].forEach(f=>{ const v = f==='kaufpreis' ? e.preis : e[f]; if(!dupe[f] && v) dupe[f] = v; });
      if(!dupe.verkaeuferTelefon && e.telefon) dupe.verkaeuferTelefon = e.telefon;
      if(!dupe.verkaeuferEmail && mail) dupe.verkaeuferEmail = mail;
      if(!dupe.eigentuemerId && k) dupe.eigentuemerId = k.id;
      if(e.kiPreis){ dupe.kiPreis = e.kiPreis; dupe.kiAm = Date.now(); } if(e.kiKaeufer) dupe.kiKaeufer = e.kiKaeufer; if(e.kiAnsprache) dupe.kiAnsprache = e.kiAnsprache;
      if(e.link && dupe.link !== e.link){ const neuerLink = !!dupe.link; dupe.link = e.link; preisInfo += neuerLink ? ' – Anzeige neu eingestellt (neuer Link)' : ' – Link zur Anzeige ergänzt'; }
      if(Array.isArray(dupe.verlauf)) dupe.verlauf.push({ts:Date.now(), typ:'info', text:'Erneut gefunden'+(e.quelleText?' ('+e.quelleText+')':'')+preisInfo});
      dupe.notizen = (dupe.notizen||'') + `<br>🔁 Erneut gefunden am ${heute}${e.quelleText?' ('+akqEsc(e.quelleText)+')':''}${akqEsc(preisInfo)}`;
      ber.doppelt++; ber.liste.push({id:dupe.id, titel:e.titel, ort:e.ort||e.lageRoh, doppelt:true});
      continue;
    }
    const o = {id:uid(), createdAt:basisZeit-nr, adresse:e.adresse||'', ort:e.ort||e.lageRoh||'', objektart:e.objektart, auftragsart:e.auftragsart, quelle:e.quelle,
      verkaeuferName:e.name||'', verkaeuferTelefon:e.telefon||'', verkaeuferEmail:mail||'', eigentuemerId:k?k.id:null, status:'neu',
      prioritaet: e.privat==='ja' ? 'hoch' : e.privat==='nein' ? 'niedrig' : 'mittel', kaufpreis:e.preis||0, einschaetzung:0, farbe:'',
      wohnflaeche:e.wohnflaeche||0, grundstueck:e.grundstueck||0, baujahr:e.baujahr||'', anschreibenText: e.nachricht || '', anschreibenEigen: !!e.nachricht, followupText:'',
      followupTermin:false, followupKontakt:false, followupEmailVersendet:false, notizen:akqNotizen(e),
      akqTitel:e.titel||'', privat:e.privat, link:e.link||'', inseratDatum:e.datum||'', zimmer:e.zimmer||'', chiffre:e.chiffre||'', importId,
      kiPreis:e.kiPreis||'', kiKaeufer:e.kiKaeufer||'', kiAnsprache:e.kiAnsprache||'', kiAm:(e.kiPreis||e.kiKaeufer)?Date.now():0,
      details:e.details||'', seite:e.seite||'', quelleText:e.quelleText||'', statusText:e.statusText||'', privatText:e.privatText||'',
      verlauf:[{ts:Date.now(), typ:'import', text:`Aus ${e.quelle==='Direktakquise'&&quelleHinweis==='manuell'?'Eingabe':e.quelle} übernommen${e.seite?' · Seite '+e.seite:''}`}]};
    db.objekte.push(o); ber.neuObjekte++; ber.liste.push({id:o.id, titel:o.akqTitel, ort:o.ort, neu:true, kontaktNeu:kNeu});
  }
  a.importe.unshift({id:importId, zeit:ber.zeit, neuObjekte:ber.neuObjekte, neuKontakte:ber.neuKontakte, doppelt:ber.doppelt, quelle:ber.quelle, rueckgaengig:false});
  a.importe = a.importe.slice(0,40);
  save();
  return ber;
}
function akqRueckgaengig(importId){
  const objIds = new Set(db.objekte.filter(o=>o.importId===importId).map(o=>o.id));
  objIds.forEach(id=>{ try{ objektVerknuepfungenAufraeumen(id); }catch(e){} });
  db.objekte = db.objekte.filter(o=>o.importId!==importId);
  const kWeg = db.kontakte.filter(k=>k.importId===importId && !db.objekte.some(o=>o.eigentuemerId===k.id));
  kWeg.forEach(k=>{ db.aufgaben.forEach(x=>{ if(x.kontaktId===k.id) x.kontaktId=null; }); });
  const kIds = new Set(kWeg.map(k=>k.id));
  db.kontakte = db.kontakte.filter(k=>!kIds.has(k.id));
  const imp = akqDb().importe.find(i=>i.id===importId); if(imp) imp.rueckgaengig = true;
  save();
  akqToast(`↩️ Rückgängig: ${objIds.size} Objekt(e) und ${kIds.size} Kontakt(e) entfernt`);
  if(aktuelleAnsicht==='akquise') renderAkquise(document.getElementById('main'));
}

// Zentraler Einstieg für alles, was eingefügt wird
let akqLetzterBericht = null;
function akqImportText(text, quelleHinweis){
  text = String(text||'');
  if(!text.trim()){ akqToast('Bitte erst das Ergebnis einfügen'); return null; }
  const r = akqLesen(text);
  if(r.art==='hv'){
    const liste = []; r.jarvis.liste.slice(0,60).forEach(it=>{ try{ const v = hvMappen(it,''); if(v) liste.push(v); }catch(e){} });
    const x = window.__JV_HOST && window.__JV_HOST.hvAdd ? window.__JV_HOST.hvAdd(liste) : {neu:0,doppelt:0};
    akqLetzterBericht = {hv:true, neu:x.neu, doppelt:x.doppelt};
    akqToast(`🏢 ${x.neu} Hausverwaltung(en) übernommen${x.doppelt?', '+x.doppelt+' schon vorhanden':''}`, 4000);
    return akqLetzterBericht;
  }
  if(r.art==='jarvis'){
    window.__JV_HOST.pendingImport = text; akqLetzterBericht = {jarvis:true};
    akqToast('📥 Das sind Jarvis-Daten (Investment/Markt/Recht) – werden in Jarvis eingelesen', 4000);
    wechsleAnsicht('jv-suchen'); return akqLetzterBericht;
  }
  if(!r.eintraege.length){ akqLetzterBericht = {fehler:'Keine Anzeige erkannt. Jede Anzeige braucht Zeilen wie „Objekt: …“, „Lage: …“, „Preis: …“ – nummeriert (1., 2., …) oder mit „---“ getrennt.'}; return akqLetzterBericht; }
  // v21: Kaufgesuche werden Suchkunden, Angebote werden Leads
  const gesuche = r.eintraege.filter(e=>e.typ==='gesuch'), angebote = r.eintraege.filter(e=>e.typ!=='gesuch');
  const ber = angebote.length ? akqUebernehmen(angebote, quelleHinweis) : {id:'imp'+Date.now(), zeit:new Date().toISOString(), neuObjekte:0, neuKontakte:0, doppelt:0, leer:0, liste:[], quelle:quelleHinweis||''};
  if(gesuche.length && typeof skUebernehmen==='function'){
    const sk = skUebernehmen(gesuche.map(skAusKi), ber.id);
    ber.suchkunden = sk.neu; ber.suchkundenDoppelt = sk.doppelt; ber.suchkundenTreffer = sk.treffer; ber.suchkundenKeinMakler = sk.keinMakler || 0;
    if(!angebote.length){ const a = akqDb(); a.importe.unshift({id:ber.id, zeit:ber.zeit, neuObjekte:0, neuKontakte:sk.kontakteNeu, doppelt:0, quelle:ber.quelle, rueckgaengig:false}); a.importe = a.importe.slice(0,40); save(); }
  }
  akqLetzterBericht = ber;
  akqToast(`✅ ${angebote.length ? ber.neuObjekte+' neue Objekte, '+ber.neuKontakte+' neue Kontakte' : ''}${ber.doppelt?' · '+ber.doppelt+' schon bekannt':''}${gesuche.length ? (angebote.length?' · ':'')+'👥 '+(ber.suchkunden||0)+' neue Suchkunden'+(ber.suchkundenTreffer?' (passen zu '+ber.suchkundenTreffer+' Objekten)':'')+(ber.suchkundenKeinMakler?' · '+ber.suchkundenKeinMakler+' wollen keinen Makler (aussortiert)':'') : ''}`, 4500);
  return ber;
}
// Für Jarvis: Akquise-Treffer landen direkt in Objekte/Kontakte
window.__AKQ = { eintraege: (liste)=> akqUebernehmen(liste.map(akqAusJson).map(akqAufbereiten), 'Jarvis') };

// ── Prompts ──
const AKQ_FORMAT = `ANTWORTFORMAT (genau so – Paul fügt deine Antwort in sein Programm ein, das liest sie automatisch):
Nummeriere die Anzeigen (1., 2., 3., …). Jede Anzeige bekommt genau diese Zeilen in dieser Reihenfolge:

1.
Titel: [Überschrift der Anzeige Wort für Wort, genau so wie sie im Inserat hinter dem Link steht – nicht umformulieren, nicht kürzen, nichts ergänzen; bei Zeitungsanzeigen die erste fett gedruckte Zeile]
Name: [Name des Anbieters oder „Nicht angegeben“]
Objekt: [kurze Bezeichnung, z. B. „Einfamilienhaus mit Garten“, „3-Zimmer-Eigentumswohnung“, „Baugrundstück“]
Lage: [Ort/Ortsteil, Straße falls genannt]
Preis: [Betrag in € wie in der Anzeige, z. B. „300.000 €“, „VB 249.000 €“, sonst „Nicht angegeben“]
Telefon: [Nummer oder „Nicht angegeben“]
E-Mail: [Adresse oder „Nicht angegeben“]
Eingestellt am: [TT.MM.JJJJ]
Privat eindeutig: [🟢 Ja – Begründung / 🟡 Unklar – Begründung / 🔴 Nein – Makler/Bauträger]
Details: [Fläche, Zimmer, Grundstück, Baujahr, Zustand – nur was in der Anzeige steht]
Quelle: [Zeitung bzw. Portal, Ausgabe]
Seite: [Seite/Rubrik oder „Nicht angegeben“]
Link: [vollständiger direkter Link zum Exposé, z. B. https://www.immobilienscout24.de/expose/123456789 – bei Online-Anzeigen PFLICHT; nur bei Zeitungsanzeigen ohne Webadresse „Nicht angegeben“]
Status: [ein kurzer Satz: Privatangebot mit E-Mail-Kontakt / nur Chiffre / Makler …]
Preis-Einschätzung: [marktgerecht / eher hoch / zu hoch / günstig – kurze Begründung, z. B. €/m² im Vergleich zu ähnlichen Angeboten im Ort]
Passende Käufer: [1–3 Käufergruppen, die zu genau diesem Objekt passen, mit Grund – z. B. „Familie mit Kindern (5 Zimmer, Garten)“, „Kapitalanleger (vermietet)“, „Paar 55+ (ebenerdig)“]

TITEL-REGEL: Titel, Preis, Lage und Link einer Nummer müssen zu GENAU DERSELBEN Anzeige gehören. Öffne den Link und übernimm die Überschrift von dort. Vermische nie Angaben aus verschiedenen Anzeigen. Passt etwas nicht zusammen, lass die Anzeige weg.

LINK-REGEL: Bei jeder Online-Anzeige gehört der Link zum Exposé dazu – als reine Adresse (https://…) in einer Zeile, ohne Klammern, ohne Markdown, nicht gekürzt. Er muss genau dieses eine Inserat öffnen, keine Suchergebnis- oder Übersichtsseite. Gerade wenn Telefon und E-Mail fehlen, ist der Link der einzige Weg zum Eigentümer. Findest du keinen direkten Link, lass die Anzeige weg.

Keine Tabellen, kein Fettdruck, keine Erklärungen zwischen den Anzeigen. Am Ende eine Zeile: „Gesamt: X Anzeigen“.`;
const AKQ_FORMAT_GESUCH_ZEILEN = `Anzeigentyp: Gesuch
Name: [wer sucht, z. B. „Junge Familie“ oder Name, sonst „Nicht angegeben“]
Sucht: [Objektart(en), z. B. „Einfamilienhaus oder Doppelhaushälfte“]
Lage: [Wunschorte, mit Komma getrennt]
Budget: [z. B. „bis 500.000 €“ oder „Nicht angegeben“]
Details: [Zimmer, Wohnfläche, Grundstück, Wünsche, Kauf oder Miete]
Telefon: [Nummer oder „Nicht angegeben“]
E-Mail: [Adresse oder „Nicht angegeben“]
Link: [direkter Link zum Gesuch, falls online – sonst „Nicht angegeben“]
Eingestellt am: [TT.MM.JJJJ]
Quelle: [Zeitung bzw. Portal, Ausgabe]`;
const AKQ_FORMAT_GESUCH = `KAUFGESUCHE (Leute, die eine Immobilie SUCHEN) bekommen dieselbe Nummerierung, aber diese Zeilen statt der Angebots-Zeilen:
${AKQ_FORMAT_GESUCH_ZEILEN}
Bei Chiffre-Gesuchen „Chiffre …“ bei Telefon eintragen. Gesuche von Maklern („für vorgemerkte Kunden“, „suchen für unsere Kunden“) lässt du weg – ebenso Gesuche mit „keine Makler“, „von privat“ oder „provisionsfrei“ (die wollen keinen Makler).`;
const AKQ_PROMPTS = [
  {key:'zeitung', icon:'📰', titel:'Zeitung auswerten', text:'Fotos oder PDF der Anzeigenseiten anhängen – die KI liest alle Immobilienanzeigen aus.', tage:3,
   prompt:(e)=>`Du hilfst Paul Görner (Immobilienmakler, BETTERHOMES Berlin) bei der Eigenakquise. Im Anhang sind Seiten aus Zeitungen/Anzeigenblättern (Fotos oder PDF). Heute ist der ${new Date().toLocaleDateString('de-DE')}.

AUFGABE: Lies ALLE Immobilienanzeigen auf diesen Seiten – Verkaufsangebote (${e.arten}) UND alle Kaufgesuche von Privatleuten (wer ein Haus, eine Wohnung oder ein Grundstück sucht – das sind Pauls künftige Käufer). Gebiet: ${e.gebiet} – Anzeigen außerhalb trotzdem aufnehmen, aber im Status vermerken.
${e.nurPrivat?'Nimm nur Anzeigen von PRIVAT oder unklarer Herkunft auf. Anzeigen von Maklern, Bauträgern und Banken lässt du weg.':'Nimm alle Anzeigen auf und kennzeichne Makler/Bauträger mit 🔴.'}
- Übernimm Namen, Telefonnummern und E-Mail-Adressen exakt wie gedruckt (Ziffer für Ziffer prüfen). Bei Chiffre-Anzeigen: „Chiffre …“ bei Telefon eintragen.
- Erfinde nichts. Unleserliches mit [?] markieren. Was fehlt: „Nicht angegeben“.
- „Eingestellt am“ = Erscheinungsdatum der Zeitung (steht meist oben auf der Seite).
- Link: Steht in der Anzeige eine Webadresse oder ein Online-Code, trag sie ein – sonst „Nicht angegeben“.
- Doppelte Anzeigen (gleiche Nummer/gleiches Objekt) nur einmal.

${AKQ_FORMAT}

${AKQ_FORMAT_GESUCH}`},
  {key:'kleinanzeigen', icon:'🛒', titel:'Kleinanzeigen (privat)', text:'Websuche auf kleinanzeigen.de nach privaten Verkäufern.', tage:1,
   prompt:(e)=>`Du hilfst Paul Görner (Immobilienmakler, BETTERHOMES Berlin) bei der Eigenakquise. Heute ist der ${new Date().toLocaleDateString('de-DE')}. Nutze die Websuche gründlich und öffne jede Anzeige einzeln.

AUFGABE: Finde bis zu ${e.anzahl} aktuelle Immobilien-Verkaufsanzeigen von PRIVAT auf kleinanzeigen.de (Rubrik Immobilien: Häuser zum Kauf, Eigentumswohnungen, Grundstücke) im Gebiet ${e.gebiet}. Objektarten: ${e.arten}. Nur Anzeigen der letzten ${e.tage} Tage.
- Nur Anbieter „Privat“ (nicht „Gewerblich“). Anzeigen mit „keine Makler“, „Makleranfragen zwecklos“ o. ä. weglassen.
- Link = PFLICHT: direkter Link zur einzelnen Anzeige (https://www.kleinanzeigen.de/s-anzeige/…), keine Suchseiten. Ohne Link keine Aufnahme.
- Telefon/E-Mail nur, wenn sie in der Anzeige stehen – sonst „Nicht angegeben“ (Kontakt dann über die Nachrichtenfunktion).
- Erfinde nichts; prüfe jeden Eintrag gegen die geöffnete Anzeige.

${AKQ_FORMAT}`},
  {key:'portale', icon:'🏘️', titel:'Portale „von privat“', text:'ImmoScout24, Immowelt, Immonet & Co. – nur Privatanbieter.', tage:3,
   prompt:(e)=>`Du hilfst Paul Görner (Immobilienmakler, BETTERHOMES Berlin) bei der Eigenakquise. Heute ist der ${new Date().toLocaleDateString('de-DE')}. Nutze die Websuche gründlich.

AUFGABE: Finde bis zu ${e.anzahl} aktuelle Verkaufsangebote von PRIVATEN Eigentümern (ohne Makler) im Gebiet ${e.gebiet}. Objektarten: ${e.arten}. Suche auf ImmoScout24 („Privatanbieter“), Immowelt, Immonet, ohne-makler.net, immobilien.de und regionalen Portalen. Nur Inserate der letzten ${e.tage*2} Tage, wenn erkennbar.
- Nur Privatanbieter; „Provision“, „Courtage“ oder Firmenname = Makler → weglassen.
- Link = PFLICHT: direkter Link zum Exposé (z. B. https://www.immobilienscout24.de/expose/…, https://www.immowelt.de/expose/…). Ohne Link keine Aufnahme.
- Kontakt nur, wenn öffentlich angegeben – sonst „Nicht angegeben“ (Kontakt dann über das Exposé).
- Erfinde nichts; prüfe jeden Eintrag gegen das geöffnete Inserat.

${AKQ_FORMAT}`},
  {key:'hv', icon:'🏢', titel:'Hausverwaltungen', text:'Verwaltungen für die Vermietungs-Kooperation (landen im Hausverwaltungen-Modul).', tage:7,
   prompt:(e)=> (typeof hvRecherchePrompt==='function' ? hvRecherchePrompt({menge:15, gebiet:e.gebiet}) : '')},
];
function akqEinstSetzen(k,v){ const a = akqDb(); a.einst[k] = (k==='nurPrivat') ? !!v : (k==='anzahl'||k==='tage') ? (parseInt(v)||a.einst[k]) : v; save(); }
function akqPromptKopieren(key){
  const p = AKQ_PROMPTS.find(x=>x.key===key); if(!p) return;
  const text = p.prompt(akqDb().einst); if(!text) return;
  akqDb().zuletzt[key] = new Date().toISOString(); save();
  akqKopieren(text, `📋 Prompt „${p.titel}“ kopiert – in Claude oder ChatGPT einfügen${key==='zeitung'?' und die Zeitungsseiten anhängen':''}`);
  renderAkquiseKarten();
}
function akqVorTagen(iso){ if(!iso) return null; return Math.floor((Date.now()-new Date(iso).getTime())/864e5); }

// ── Ansicht ──
let akqListe = 'neu';   // 'neu' oder 'email_geschrieben'
function renderAkquise(main){
  akqDb();
  const neu = db.objekte.filter(o=>o.status==='neu').length, mail = db.objekte.filter(o=>o.status==='email_geschrieben').length;
  main.innerHTML = `
    <h1>🎯 Akquise <span>· Eigenakquise</span></h1>
    <div class="sub">① Prompt kopieren → ② in Claude/ChatGPT suchen lassen → ③ Antwort hier einfügen. Objekte und Kontakte werden automatisch angelegt, Doppelte erkannt.</div>
    <div id="akqNeustart">${akqNeustartBannerHtml()}</div>
    <div class="dash-grid" style="align-items:start;">
      <div class="dash-box">
        <h3>① Suchen lassen</h3>
        <div class="akq-einst" style="display:grid;grid-template-columns:1fr 1fr;gap:4px 10px;">
          <div style="grid-column:1/-1;"><label>Gebiet</label><input value="${akqEsc(db.akquise.einst.gebiet)}" onchange="akqEinstSetzen('gebiet',this.value)"></div>
          <div style="grid-column:1/-1;"><label>Objektarten</label><input value="${akqEsc(db.akquise.einst.arten)}" onchange="akqEinstSetzen('arten',this.value)"></div>
          <div><label>Anzahl (online)</label><input value="${akqEsc(db.akquise.einst.anzahl)}" onchange="akqEinstSetzen('anzahl',this.value)"></div>
          <div><label>Zeitraum (Tage)</label><input value="${akqEsc(db.akquise.einst.tage)}" onchange="akqEinstSetzen('tage',this.value)"></div>
          <div style="grid-column:1/-1;"><label style="display:flex;align-items:center;gap:6px;text-transform:none;font-size:12px;color:var(--text);"><input type="checkbox" style="width:auto;" ${db.akquise.einst.nurPrivat?'checked':''} onchange="akqEinstSetzen('nurPrivat',this.checked)"> nur private Anbieter</label></div>
        </div>
        <div id="akqKarten" style="margin-top:10px;"></div>
        <div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:10px;">
          <button class="secondary tiny" onclick="window.open('https://claude.ai/new','_blank')">Claude öffnen ↗</button>
          <button class="secondary tiny" onclick="window.open('https://chatgpt.com/','_blank')">ChatGPT öffnen ↗</button>
          <button class="secondary tiny" onclick="wechsleAnsicht('jv-suchen')" title="Kaufobjekte für dich, Marktbericht, Recht">🔎 KI-Suche</button>
        </div>
      </div>
      <div class="dash-box">
        <h3>② Ergebnis einfügen</h3>
        <textarea id="akqText" style="min-height:230px;font-family:Consolas,monospace;font-size:11px;" placeholder="Antwort der KI hier einfügen (Strg+V) – wird sofort übernommen.

1.
Name: Nicht angegeben
Objekt: Voll erschlossenes Baugrundstück
Lage: Ludwigsfelde
Preis: 300.000 €
…" onpaste="setTimeout(()=>akqEinfuegen(true),60)"></textarea>
        <div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:8px;">
          <button onclick="akqEinfuegen()">✅ Einfügen</button>
          ${window.pc&&window.pc.zwischenablage?'<button class="secondary" onclick="akqAusZwischenablage()">📋 Aus Zwischenablage</button>':''}
          <button class="secondary" onclick="document.getElementById('akqText').value='';">Leeren</button>
        </div>
        <div id="akqErgebnis" style="margin-top:10px;">${akqErgebnisHtml()}</div>
      </div>
    </div>
    <div class="dash-box" style="margin-top:16px;">
      <h3 style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;">③ Eingang
        <button class="${akqListe==='neu'?'':'secondary'} tiny" onclick="akqListe='neu';renderAkquise(document.getElementById('main'))">⚪ Neu (${neu})</button>
        <button class="${akqListe==='email_geschrieben'?'':'secondary'} tiny" onclick="akqListe='email_geschrieben';renderAkquise(document.getElementById('main'))">✉️ E-Mail geschrieben (${mail})</button>
        <span style="flex:1;"></span><button class="secondary tiny" onclick="akqVorlageBearbeiten()">✏️ Anschreiben-Vorlage</button><button class="secondary tiny" onclick="wechsleAnsicht('objekte')">Alle Objekte →</button></h3>
      <div id="akqNeuListe">${akqNeuListeHtml()}</div>
    </div>
    <div class="leer-hinweis" style="margin-top:12px;font-style:normal;">⚖️ Hinweis: Private Verkäufer ohne vorherige Einwilligung anzurufen oder per E-Mail/Nachricht zu bewerben, ist abmahnriskant (§ 7 UWG). Auf Anzeigen mit „keine Makler“ nicht reagieren.</div>`;
  renderAkquiseKarten();
}
function renderAkquiseKarten(){
  const el = document.getElementById('akqKarten'); if(!el) return;
  const a = akqDb();
  el.innerHTML = AKQ_PROMPTS.map(p=>{
    const t = akqVorTagen(a.zuletzt[p.key]); const faellig = t===null || t>=(typeof akqIntervall==='function' ? akqIntervall(p) : p.tage);
    return `<div style="display:flex;align-items:center;gap:10px;padding:9px 0;border-bottom:1px solid var(--border);">
      <span style="font-size:20px;">${p.icon}</span>
      <div style="flex:1;min-width:0;"><b style="font-size:13px;">${p.titel}</b> ${faellig?'<span class="badge b-orange">fällig</span>':''}<div style="font-size:11px;color:var(--muted);">${p.text}${t!==null?` · zuletzt ${t===0?'heute':t===1?'gestern':'vor '+t+' Tagen'}`:''}</div></div>
      <button class="tiny" onclick="akqPromptKopieren('${p.key}')">📋 Prompt</button>
    </div>`;
  }).join('');
}
function akqEinfuegen(vonPaste){
  const ta = document.getElementById('akqText'); if(!ta) return;
  const t = ta.value; if(!t.trim()) return;
  if(vonPaste && t.trim().length<25) return;
  const r = akqImportText(t);
  if(r && !r.fehler && !r.jarvis) ta.value = '';
  if(aktuelleAnsicht==='akquise'){ const rest = (r && (r.fehler||r.jarvis)) ? t : ''; renderAkquise(document.getElementById('main')); const ta2 = document.getElementById('akqText'); if(ta2) ta2.value = rest; }
}
async function akqAusZwischenablage(){
  let t = ''; try{ t = await window.pc.zwischenablage(); }catch(e){}
  if(!t.trim()){ akqToast('Zwischenablage ist leer'); return; }
  document.getElementById('akqText').value = t; akqEinfuegen();
}
function akqErgebnisHtml(){
  const r = akqLetzterBericht;
  const verlauf = akqDb().importe.slice(0,5);
  let h = '';
  if(r && r.fehler) h += `<div style="color:var(--yellow);font-size:12px;">⚠️ ${akqEsc(r.fehler)}</div>`;
  else if(r && r.hv) h += `<div style="font-size:12px;">🏢 ${r.neu} Hausverwaltung(en) übernommen${r.doppelt?', '+r.doppelt+' schon vorhanden':''} – <a href="#" onclick="wechsleAnsicht('hausverwaltungen');return false;" style="color:var(--orange);">ansehen</a></div>`;
  else if(r && r.liste){
    h += `<div style="font-size:12px;margin-bottom:6px;"><b style="color:var(--green);">✅ ${r.neuObjekte} neue Objekte · ${r.neuKontakte} neue Kontakte</b>${r.doppelt?` · ${r.doppelt} schon bekannt (ergänzt)`:''}${r.leer?` · ${r.leer} leer`:''}
      ${r.neuObjekte||r.neuKontakte?` <button class="secondary tiny" onclick="akqRueckgaengig('${r.id}')">↩️ Rückgängig</button>`:''}</div>
      <div style="max-height:150px;overflow:auto;font-size:11px;color:var(--muted);">${r.liste.map(x=>`<div>${x.doppelt?'🔁':'🆕'} ${akqEsc(x.titel||'')}${x.ort?' · '+akqEsc(x.ort):''}</div>`).join('')}</div>`;
  }
  if(verlauf.length) h += `<div style="margin-top:8px;font-size:11px;color:var(--muted);">Letzte Importe: ${verlauf.map(v=>`${new Date(v.zeit).toLocaleDateString('de-DE',{day:'2-digit',month:'2-digit'})} ${v.rueckgaengig?'<s>':''}+${v.neuObjekte}${v.rueckgaengig?'</s>':''}`).join(' · ')}</div>`;
  return h;
}
const AKQ_PRIVAT_BADGE = {ja:'<span class="badge b-gruen" title="eindeutig privat">🟢 privat</span>', unklar:'<span class="badge b-gelb" title="unklar">🟡 unklar</span>', nein:'<span class="badge b-rot" title="Makler/gewerblich">🔴 gewerbl.</span>'};
function akqNeuListeHtml(){
  const liste = db.objekte.filter(o=>o.status===akqListe).sort((a,b)=>(akqListe==='neu'?(b.createdAt||0)-(a.createdAt||0):(b.emailAm||0)-(a.emailAm||0)));
  if(!liste.length) return akqListe==='neu' ? '<div class="leer-hinweis">Noch nichts Neues – kopiere einen Prompt, lass suchen und füge das Ergebnis oben ein.</div>' : '<div class="leer-hinweis">Noch keine Objekte mit „E-Mail geschrieben“.</div>';
  return `<table><tr><th>Objekt</th><th>Preis</th><th>Kontakt</th><th>${akqListe==='neu'?'Eingestellt':'E-Mail am'}</th><th></th></tr>${liste.slice(0,80).map(o=>{
    const k = o.eigentuemerId ? findKontakt(o.eigentuemerId) : null;
    const tel = o.verkaeuferTelefon || (k&&k.telefon) || '', mail = o.verkaeuferEmail || (k&&k.email) || '';
    return `<tr class="row">
      <td onclick="oeffneObjektModal('${o.id}')" style="cursor:pointer;"><b>${akqEsc(o.akqTitel||o.adresse||o.objektart)}</b> ${AKQ_PRIVAT_BADGE[o.privat]||''}<br><span style="color:var(--muted);">${akqEsc([o.objektart,o.adresse,o.ort].filter(Boolean).join(' · '))}${o.grundstueck?' · '+o.grundstueck+' m² Grund':''}${o.wohnflaeche?' · '+o.wohnflaeche+' m²':''} · ${akqEsc(o.quelle||'')}</span></td>
      <td>${o.kaufpreis?Number(o.kaufpreis).toLocaleString('de-DE')+' €':'–'}</td>
      <td style="font-size:11px;">${k?akqEsc(k.name)+'<br>':''}${tel?`<a href="tel:${akqEsc(akqTelNorm(tel))}" style="color:var(--orange);">📞 ${akqEsc(tel)}</a><br>`:''}${mail?`<a href="mailto:${akqEsc(mail)}" style="color:var(--orange);">✉️ ${akqEsc(mail)}</a>`:''}${!tel&&!mail?(o.chiffre?'Chiffre '+akqEsc(o.chiffre):o.link?`<a href="#" onclick="window.open('${akqEsc(o.link)}','_blank');return false;" style="color:var(--orange);">🔗 Anzeige</a>`:'<span style="color:var(--muted);">–</span>'):''}</td>
      <td style="font-size:11px;">${akqListe==='neu' ? (o.inseratDatum?new Date(o.inseratDatum).toLocaleDateString('de-DE'):'–') : (o.emailAm?new Date(o.emailAm).toLocaleDateString('de-DE'):'–')}</td>
      <td style="white-space:nowrap;">
        <button class="secondary tiny" title="Anschreiben kopieren" onclick="akqText('${o.id}')">✉️</button>
        ${akqListe==='neu'?`<button class="secondary tiny" title="E-Mail geschrieben" onclick="akqStatus('${o.id}','email_geschrieben')">📧✅</button>`:''}
        <button class="secondary tiny" title="Erreicht → Erstkontakt" onclick="akqStatus('${o.id}','erstkontakt')">📞✅</button>
        <button class="secondary tiny" title="Nicht erreicht" onclick="akqStatus('${o.id}','nicht_erreicht')">📞❌</button>
        <button class="secondary tiny" title="Unbrauchbar – löschen" onclick="akqWeg('${o.id}')">🗑️</button>
      </td></tr>`;
  }).join('')}</table>${liste.length>80?`<div class="leer-hinweis">… und ${liste.length-80} weitere unter Objekte (Filter „Neu“).</div>`:''}`;
}
function akqText(id){ const o = findObjekt(id); if(!o) return; akqKopieren(typeof aqAnschreiben==='function' ? aqAnschreiben(o,'email').text : (o.anschreibenText||''), 'Anschreiben kopiert ✓'); }
function akqStatus(id, st){
  const o = findObjekt(id); if(!o) return;
  o.status = st; try{ objektStatusAktionAusfuehren(id, st); }catch(e){}
  if(st==='email_geschrieben'){ o.emailAm = Date.now(); o.followupEmailVersendet = true; o.notizen = (o.notizen||'') + '<br>✉️ E-Mail geschrieben am ' + new Date().toLocaleDateString('de-DE'); }
  save(); akqToast({erstkontakt:'Status: Erstkontakt', nicht_erreicht:'Status: Nicht erreicht', email_geschrieben:'Status: E-Mail geschrieben', kleinanzeigen_geschrieben:'Status: Per Kleinanzeigen angeschrieben'}[st]||'Status geändert');
  if(aktuelleAnsicht==='akquise') renderAkquise(document.getElementById('main'));
}
function akqWeg(id){
  bestaetigeUnten('Objekt als unbrauchbar löschen?', ()=>{
    const o = findObjekt(id); const eig = o ? o.eigentuemerId : null;
    try{ akqVerworfenMerken(o); }catch(e){}
    try{ objektVerknuepfungenAufraeumen(id); }catch(e){}
    db.objekte = db.objekte.filter(x=>x.id!==id);
    try{ eigentuemerMitloeschenFallsVerwaist(eig); }catch(e){}
    save(); if(aktuelleAnsicht==='akquise') renderAkquise(document.getElementById('main'));
  });
}
function akqVorlageBearbeiten(){
  document.getElementById('modalInner').innerHTML = `<h3>✏️ Anschreiben-Vorlage</h3>
    <div style="color:var(--muted);font-size:11px;margin-bottom:8px;">Platzhalter: {anrede} (Name, falls bekannt), {objekt}, {ort}, {quelle_satz}. Gilt für neu eingefügte Anzeigen.</div>
    <textarea id="akqVorlage" style="min-height:260px;">${akqEsc(akqDb().vorlage)}</textarea>
    <div class="modal-actions"><div><button class="secondary" onclick="document.getElementById('akqVorlage').value=AKQ_VORLAGE_STD">Standard</button></div><div class="right"><button class="secondary" onclick="schliesseModal()">Abbrechen</button><button onclick="akqDb().vorlage=document.getElementById('akqVorlage').value;save();schliesseModal();akqToast('Vorlage gespeichert')">Speichern</button></div></div>`;
  document.getElementById('modalBg').classList.add('show');
}

// ── Neustart v9: Kontakte und Objekte einmalig leeren (mit Sicherung) ──
function akqNeustart(){
  db.meta = db.meta || {};
  if(db.meta.v9neustart) return;
  const nO = (db.objekte||[]).length, nK = (db.kontakte||[]).length, nL = ((db.jarvis||{}).leads||[]).length;
  let datei = '';
  if(nO || nK || nL){
    datei = 'vor-v9-neustart-' + new Date().toISOString().slice(0,19).replace(/[:T]/g,'-') + '.json';
    let ok = false;
    try{ const r = window.pc && window.pc.sicherungSchreiben ? window.pc.sicherungSchreiben(datei, JSON.stringify(db)) : null; ok = !!(r && r.ok); }catch(e){}
    if(!ok){ console.warn('Neustart: Sicherung fehlgeschlagen – nichts geleert'); return; }   // ohne Sicherung nichts löschen
    (db.objekte||[]).forEach(o=>{ try{ objektVerknuepfungenAufraeumen(o.id); }catch(e){} });
    db.aufgaben.forEach(a=>{ a.kontaktId = null; }); db.termine.forEach(t=>{ t.kontaktId = null; });
    (db.marktanalysen||[]).forEach(m=>{ if(m.kontaktId) m.kontaktId = null; });
    db.objekte = []; db.kontakte = [];
    if(db.jarvis && Array.isArray(db.jarvis.leads)) db.jarvis.leads = [];
  }
  db.meta.v9neustart = {zeit:new Date().toISOString(), datei, objekte:nO, kontakte:nK, leads:nL, quittiert: !(nO||nK||nL)};
  save();
  aktuelleAnsicht = 'akquise';
}
function akqNeustartBannerHtml(){
  const n = (db.meta||{}).v9neustart; if(!n || n.quittiert || n.fehler) return '';
  return `<div style="background:rgba(232,149,95,.12);border:1px solid var(--orange);border-radius:8px;padding:10px 14px;margin-bottom:14px;display:flex;gap:10px;align-items:center;flex-wrap:wrap;font-size:12px;">
    <span>🧹 <b>Neustart:</b> ${n.objekte} ${n.objekte===1?'Objekt':'Objekte'} und ${n.kontakte} ${n.kontakte===1?'Kontakt':'Kontakte'}${n.leads?' (dazu '+n.leads+' alte Jarvis-'+(n.leads===1?'Lead':'Leads')+')':''} wurden geleert. Gesichert in <code>backups\\${akqEsc(n.datei)}</code>.</span>
    <span style="flex:1;"></span><button class="secondary tiny" onclick="akqNeustartWiederherstellen()">↩️ Wiederherstellen</button><button class="tiny" onclick="db.meta.v9neustart.quittiert=true;save();document.getElementById('akqNeustart').innerHTML='';">OK</button></div>`;
}
function akqNeustartWiederherstellen(){
  const n = (db.meta||{}).v9neustart; if(!n || !n.datei) return;
  bestaetigeUnten('Die gesicherten Objekte und Kontakte zurückholen? (Neu Eingefügtes bleibt erhalten.)', ()=>{
    let alt = null; try{ const t = window.pc.sicherungLesen(n.datei); alt = t ? JSON.parse(t) : null; }catch(e){}
    if(!alt){ alert('Sicherung nicht gefunden: '+n.datei); return; }
    const ids = new Set(db.objekte.map(o=>o.id)), kids = new Set(db.kontakte.map(k=>k.id));
    (alt.objekte||[]).forEach(o=>{ if(!ids.has(o.id)) db.objekte.push(o); });
    (alt.kontakte||[]).forEach(k=>{ if(!kids.has(k.id)) db.kontakte.push(k); });
    if(alt.jarvis && Array.isArray(alt.jarvis.leads) && db.jarvis) db.jarvis.leads = alt.jarvis.leads.concat(db.jarvis.leads||[]);
    n.quittiert = true; n.wiederhergestellt = new Date().toISOString(); save(); renderMain(); akqToast('↩️ Objekte und Kontakte wiederhergestellt');
  });
}

// ── Zwischenablage: Akquise-Ergebnisse überall erkennen ──
function akqSiehtAusWieAnzeigen(t){
  const keys = ['objekt','lage','preis','telefon','email','privat','eingestellt'].filter(k=>new RegExp('(^|\\n)\\s*(?:\\d+\\.\\s*)?\\**'+({email:'e-?mail',eingestellt:'eingestellt am',privat:'privat'}[k]||k)+'\\**\\s*:','i').test(t));
  return keys.length>=3;
}
async function jvZwischenablagePruefen(){
  return;   // v16: kein automatisches Banner mehr – Paul fügt über „Ergebnis einfügen“ oder Strg+V ein
  if(!(window.pc && window.pc.zwischenablage)) return;
  let t = ''; try{ t = await window.pc.zwischenablage(); }catch(e){ return; }
  if(!t) return;
  const istJarvis = /JARVIS-IMPORT/i.test(t) && t.includes('{');
  const istAnz = !istJarvis && akqSiehtAusWieAnzeigen(t);
  if(!istJarvis && !istAnz) return;
  const key = t.length + '|' + t.slice(0,300);
  if(key === jvLetzteZwischenablage) return;
  jvLetzteZwischenablage = key;
  let was = 'Anzeigen';
  if(istJarvis){ const typ = ((t.match(/JARVIS-IMPORT\s*typ\s*[=:]\s*([A-Za-zäöü_]+)/i)||[])[1]||'').toLowerCase(); was = {akquise:'Akquise-Treffer', leads:'Akquise-Treffer', hausverwaltungen:'Hausverwaltungen', hv:'Hausverwaltungen', objekte:'Kaufobjekte', rendite:'Kaufobjekte', markt:'Marktbericht', recht:'Rechts-Update', gebiete:'Bezirkspreise'}[typ] || 'Jarvis-Daten'; }
  else { const n = akqBloecke(t).length; was = n+' Anzeige'+(n===1?'':'n'); }
  let el = document.getElementById('jvClipBanner');
  if(!el){ el = document.createElement('div'); el.id = 'jvClipBanner'; el.style.cssText = 'position:fixed;top:14px;left:50%;transform:translateX(-50%);z-index:9999;background:#2e3138;border:1px solid var(--orange);border-radius:12px;padding:12px 16px;box-shadow:0 10px 40px rgba(0,0,0,.5);display:flex;gap:12px;align-items:center;font-size:13px;max-width:92vw;'; document.body.appendChild(el); }
  el.innerHTML = `<span>📥 <b>KI-Ergebnis erkannt</b> (${akqEsc(was)}) – jetzt einfügen?</span><button onclick="jvClipEinlesen()">Einfügen</button><button class="secondary" onclick="document.getElementById('jvClipBanner').remove()">Nein</button>`;
  el._text = t;
}
function jvClipEinlesen(){
  const el = document.getElementById('jvClipBanner'); if(!el) return;
  const t = el._text; el.remove();
  const r = akqImportText(t);
  if(r && r.jarvis) return;
  if(r && r.hv){ wechsleAnsicht('hausverwaltungen'); return; }
  wechsleAnsicht('akquise');
}
// „📋 Text einfügen“ bei Objekte führt jetzt in die Akquise
function oeffneTextImportModal(){ wechsleAnsicht('akquise'); setTimeout(()=>{ const t = document.getElementById('akqText'); if(t) t.focus(); }, 50); }
