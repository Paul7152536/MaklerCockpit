/* MaklerCockpit v23 – Telefon-Termin oder Vor-Ort-Termin
   Jeder Termin bekommt t.wo = 'telefon' | 'vorort'. Alte Termine ohne Angabe werden aus Art/Titel/Ort abgeleitet
   (Rückruf/Anruf → Telefon, Besichtigung/Akquise/Shooting/Adresse → Vor Ort), sonst bleibt es offen.
   Sichtbar: Kalender, „Als Nächstes“, Tagesansicht, Lead-Details, Lead-Liste, Objekte-Liste, Glocke, Google Kalender (📞/📍 vor dem Titel). */

const TW = { tel: '📞', ort: '📍' };
const TW_TEXT = { telefon: '📞 Telefon', vorort: '📍 Vor Ort' };
// Wortgrenzen auch für Umlaute (JS-\b kennt kein ä/ö/ü)
const TW_TEL_RE = /(^|[^a-zäöüß])(telefon\w*|tel\.|anruf\w*|anrufen|rückruf\w*|ruckruf\w*|zurückrufen|telefonat\w*|telko|call)(?=$|[^a-zäöüß])/i;
const TW_ORT_RE = /(^|[^a-zäöüß])(vor ort|besichtigung\w*|übergabe\w*|shooting|fototermin|notar\w*|ortstermin|begehung)(?=$|[^a-zäöüß])/i;
const TW_NUR_NUMMER = /^\s*(tel\.?|telefon)?\s*:?\s*\+?[\d\s\/().-]{6,}\s*$/i;

function twWo(t){
  if(!t) return '';
  if(t.wo === 'telefon' || t.wo === 'vorort') return t.wo;
  const ort = String(t.ort || '').trim();
  const txt = [t.titel, ort, t.art === 'eigene' ? t.artEigene : ''].join(' ');
  if(t.art === 'rueckruf' || TW_TEL_RE.test(txt) || (ort && TW_NUR_NUMMER.test(ort))) return 'telefon';
  if(['besichtigung', 'shooting', 'akquise'].includes(t.art) || TW_ORT_RE.test(txt)) return 'vorort';
  if(ort && /\d/.test(ort) && /[a-zäöüß]{3,}/i.test(ort)) return 'vorort';   // sieht nach Adresse aus
  return '';
}
function twIcon(t){ const w = twWo(t); return w === 'telefon' ? TW.tel : w === 'vorort' ? TW.ort : ''; }
function twPre(t){ const i = twIcon(t); return i ? i + ' ' : ''; }
function twChip(t, kurz){
  const w = twWo(t); if(!w) return '';
  return `<span class="tw tw-${w}" title="${w === 'telefon' ? 'Telefon-Termin' : 'Termin vor Ort'}">${kurz ? (w === 'telefon' ? TW.tel : TW.ort) : TW_TEXT[w]}</span>`;
}
// Vorschlag je Terminart (nur wenn eindeutig)
function twVorschlag(art){ return art === 'rueckruf' ? 'telefon' : ['besichtigung', 'akquise', 'shooting'].includes(art) ? 'vorort' : ''; }

function twObjektVon(objektId){ try{ return objektId ? findObjekt(objektId) : null; }catch(e){ return null; } }
function twTel(objektId, kontaktId){
  const o = twObjektVon(objektId);
  let k = null; try{ k = kontaktId ? findKontakt(kontaktId) : (o && o.eigentuemerId ? findKontakt(o.eigentuemerId) : null); }catch(e){}
  return (o && typeof aqTel === 'function' ? aqTel(o) : '') || (o && o.verkaeuferTelefon) || (k && k.telefon) || '';
}
function twAdresse(objektId){ const o = twObjektVon(objektId); return o ? [o.adresse, o.ort].filter(Boolean).join(', ') : ''; }
// Was unter dem Termin steht: bei Telefon die Nummer, vor Ort die Adresse
function twOrtText(t){
  const w = twWo(t), ort = String(t.ort || '').trim();
  if(w === 'telefon'){ if(ort && !/^telefon$/i.test(ort)) return ort.replace(/^telefon\s*:?\s*/i, 'Tel. '); const n = twTel(t.objektId, t.kontaktId); return n ? 'Tel. ' + n : ''; }
  return ort || (w === 'vorort' ? twAdresse(t.objektId) : '');
}

// ── Auswahl im Dialog ──
function twWahlHtml(id, wo){
  return `<label>Telefon oder vor Ort?</label>
    <div class="tw-wahl" id="${id}" data-wo="${wo || ''}">
      <button type="button" class="tw-b tw-telefon ${wo === 'telefon' ? 'an' : ''}" data-wo="telefon" onclick="twKlick('${id}','telefon')">📞 Telefon-Termin</button>
      <button type="button" class="tw-b tw-vorort ${wo === 'vorort' ? 'an' : ''}" data-wo="vorort" onclick="twKlick('${id}','vorort')">📍 Vor-Ort-Termin</button>
    </div>`;
}
function twGewaehlt(id){ const el = document.getElementById(id); return el ? (el.dataset.wo || '') : null; }
function twSetzen(id, wo, manuell){
  const el = document.getElementById(id); if(!el) return;
  el.dataset.wo = wo || '';
  if(manuell) el.dataset.manuell = '1';
  el.classList.remove('fehlt');
  el.querySelectorAll('.tw-b').forEach(b => b.classList.toggle('an', b.dataset.wo === wo));
  twOrtAnpassen(id);
}
function twKlick(id, wo){ twSetzen(id, wo, true); }
function twFehlt(id){
  const el = document.getElementById(id); if(!el) return;
  el.classList.remove('fehlt'); void el.offsetWidth; el.classList.add('fehlt');
  el.scrollIntoView({ block: 'center', behavior: 'smooth' });
  akqToast('Bitte wählen: 📞 Telefon-Termin oder 📍 Vor-Ort-Termin');
}
// Dialog-Felder: allgemeiner Dialog (m_t_…) oder Lead-Dialog (tq_…)
function twFelder(id){
  if(id === 'tq_wo') return { ort: document.getElementById('tq_ort'), objektId: AQ_TQ && AQ_TQ.objektId, kontaktId: null };
  const ob = document.getElementById('m_t_objekt'), ko = document.getElementById('m_t_kontakt');
  return { ort: document.getElementById('m_t_ort'), objektId: ob && ob.value, kontaktId: ko && ko.value };
}
// Ort-Feld passend vorbelegen – nur solange es automatisch gefüllt / leer ist
function twOrtAnpassen(id){
  const wo = twGewaehlt(id), f = twFelder(id), ortF = f.ort; if(!ortF) return;
  const adr = twAdresse(f.objektId), tel = twTel(f.objektId, f.kontaktId), telText = tel ? 'Telefon ' + tel : 'Telefon';
  const v = ortF.value.trim(), auto = ortF.dataset.auto === '1' || !v;
  ortF.placeholder = wo === 'telefon' ? 'Telefonnummer (optional)' : wo === 'vorort' ? 'Adresse' : 'Adresse oder Telefon';
  if(!wo) return;
  if(wo === 'telefon' && (auto || v === adr)){ ortF.value = tel ? telText : (id === 'tq_wo' ? 'Telefon' : ''); ortF.dataset.auto = '1'; }
  else if(wo === 'vorort' && (auto || /^telefon/i.test(v) || TW_NUR_NUMMER.test(v))){ ortF.value = adr; ortF.dataset.auto = '1'; }
}
function twOrtBeobachten(ortF, schonAuto){
  if(!ortF) return;
  ortF.dataset.auto = schonAuto ? '1' : '0';
  ortF.addEventListener('input', () => { ortF.dataset.auto = ortF.value.trim() ? '0' : '1'; });
}

// ── Allgemeiner Termin-Dialog ──
const _twTerminModal = oeffneTerminModal;
oeffneTerminModal = function(id, googleEventId, presetDatum, vorgabe){
  const r = _twTerminModal.apply(this, arguments);
  try{
    let t = id ? gsT(id) : null;
    if(!t && googleEventId) t = (db.termine || []).find(x => x.id === googleEventId || x.googleEventId === googleEventId) || null;
    const v = t || Object.assign({ art: 'termin' }, vorgabe || {});
    const start = t ? twWo(t) : (v.wo || twVorschlag(v.art));
    const titel = document.getElementById('m_t_titel');
    if(titel && !document.getElementById('m_t_wo')){
      const box = document.createElement('div'); box.className = 'tw-box'; box.innerHTML = twWahlHtml('m_t_wo', start);
      titel.insertAdjacentElement('afterend', box);
      if(t && t.wo) document.getElementById('m_t_wo').dataset.manuell = '1';
      const ortF = document.getElementById('m_t_ort');
      twOrtBeobachten(ortF, !t && !(ortF && ortF.value.trim()));
      if(ortF && start) ortF.placeholder = start === 'telefon' ? 'Telefonnummer (optional)' : 'Adresse';
      const art = document.getElementById('m_t_art');
      if(art) art.addEventListener('change', () => { const w = document.getElementById('m_t_wo'); if(w && w.dataset.manuell !== '1'){ const vs = twVorschlag(art.value); if(vs) twSetzen('m_t_wo', vs); } });
      ['m_t_objekt', 'm_t_kontakt'].forEach(x => { const el = document.getElementById(x); if(el) el.addEventListener('change', () => twOrtAnpassen('m_t_wo')); });
      if(!t && start) twOrtAnpassen('m_t_wo');
    }
  }catch(e){ console.error('Telefon/Vor Ort', e); }
  return r;
};
speichereTermin = function(id){
  const g = x => document.getElementById(x);
  const wo = twGewaehlt('m_t_wo');
  const zeit = g('m_t_zeit').value;
  const daten = { titel: g('m_t_titel').value.trim(), datum: g('m_t_datum').value, uhrzeit: zeit, dauer: zeit ? (Number(g('m_t_dauer').value) || 60) : null,
    art: g('m_t_art').value, artEigene: g('m_t_art_eigene') ? g('m_t_art_eigene').value.trim() : '', ort: g('m_t_ort').value.trim(),
    objektId: g('m_t_objekt').value || null, kontaktId: g('m_t_kontakt').value || null, notiz: g('m_t_notiz').value.trim(),
    nurLokal: g('m_t_lokal') ? g('m_t_lokal').checked : !!(id && gsT(id) && gsT(id).nurLokal) };
  if(!daten.titel){ g('m_t_titel').focus(); akqToast('Bitte einen Titel eingeben.'); return; }
  if(!daten.datum){ g('m_t_datum').focus(); akqToast('Bitte ein Datum wählen.'); return; }
  if(wo === ''){ twFehlt('m_t_wo'); return; }
  if(wo) daten.wo = wo;
  let t = id ? gsT(id) : null;
  if(t){
    const alt = gsKurz(t), woAlt = twWo(t);
    Object.assign(t, daten); t.geaendertAm = Date.now();
    if(gsKurz(t) !== alt) gsObjLog(t, gsArtLabel(t) + ' verlegt auf ' + gsKurzFest(t));
    else if(wo && woAlt && wo !== woAlt) gsObjLog(t, gsArtLabel(t) + ' am ' + gsKurzFest(t) + ' jetzt ' + (wo === 'telefon' ? 'per Telefon' : 'vor Ort'));
  } else {
    t = Object.assign({ id: uid(), createdAt: Date.now(), geaendertAm: Date.now() }, daten);
    db.termine.push(t); gsObjLog(t, gsLogText(t));
  }
  save(); schliesseModal(); gsNachAenderung(); gsPlanen(500);
  akqToast((wo === 'telefon' ? '📞 ' : wo === 'vorort' ? '📍 ' : '📅 ') + (gsAktiv() && !t.nurLokal ? 'Gespeichert – geht in deinen Google Kalender' : 'Termin gespeichert'));
};
gsLogText = function(t){ const w = twWo(t); return gsArtLabel(t) + (w === 'telefon' ? ' (Telefon)' : w === 'vorort' ? ' (vor Ort)' : '') + ' am ' + gsKurzFest(t); };

// ── Termin direkt am Lead (Akquise) ──
const _twTqNeu = aq2TerminNeu;
aq2TerminNeu = function(art){
  const r = _twTqNeu.apply(this, arguments);
  try{
    const arten = document.querySelector('#modalInner .tq-arten');
    if(arten && !document.getElementById('tq_wo')){
      const box = document.createElement('div'); box.className = 'tw-box'; box.innerHTML = twWahlHtml('tq_wo', '');
      arten.insertAdjacentElement('afterend', box);
      twOrtBeobachten(document.getElementById('tq_ort'), true);
      const vs = twVorschlag(AQ_TQ && AQ_TQ.art); if(vs) twSetzen('tq_wo', vs);
    }
  }catch(e){ console.error('Telefon/Vor Ort', e); }
  return r;
};
const _twTqArt = aq2TqArt;
aq2TqArt = function(k, init){
  const r = _twTqArt.apply(this, arguments);
  try{
    const w = document.getElementById('tq_wo');
    if(w){
      if(w.dataset.manuell !== '1'){ const vs = twVorschlag(k); twSetzen('tq_wo', vs); }
      else twOrtAnpassen('tq_wo');
    }
  }catch(e){}
  return r;
};
aq2TerminAnlegen = function(){
  const o = findObjekt(AQ_TQ && AQ_TQ.objektId); if(!o) return;
  const g = x => document.getElementById(x);
  const a = AQ_TA.find(x => x.k === AQ_TQ.art) || AQ_TA[0];
  const datum = g('tq_datum').value, uhrzeit = g('tq_zeit').value, wo = twGewaehlt('tq_wo');
  if(!datum){ g('tq_datum').focus(); akqToast('Bitte ein Datum wählen'); return; }
  if(wo === ''){ twFehlt('tq_wo'); return; }
  const t = { id: uid(), createdAt: Date.now(), geaendertAm: Date.now(), titel: g('tq_titel').value.trim() || aq2TqTitel(a, o), datum, uhrzeit,
    dauer: uhrzeit ? (Number(g('tq_dauer').value) || 60) : null, art: a.k, artEigene: '', ort: g('tq_ort').value.trim(), notiz: g('tq_notiz').value.trim(),
    objektId: o.id, kontaktId: o.eigentuemerId || null };
  if(wo) t.wo = wo;
  db.termine.push(t);
  aqLog(o, 'termin', (a.k === 'termin' ? 'Termin' : a.l) + (wo === 'telefon' ? ' (Telefon)' : wo === 'vorort' ? ' (vor Ort)' : '') + ' am ' + (typeof gsKurzFest === 'function' ? gsKurzFest(t) : datum + ' ' + uhrzeit));
  if(a.st && g('tq_status').checked && o.status !== a.st && g('tq_st_wrap').style.display !== 'none'){ o.status = a.st; o.statusAm = Date.now(); }
  if(a.st === 'termin') o.hatTermin = true;
  save(); schliesseModal(); aq2Neu(); if(typeof gsPlanen === 'function') gsPlanen(400);
  akqToast((wo === 'telefon' ? '📞 Telefon-Termin' : wo === 'vorort' ? '📍 Vor-Ort-Termin' : '📅 Termin') + (typeof gsAktiv === 'function' && gsAktiv() ? ' gespeichert – geht jetzt in deinen Google Kalender' : ' gespeichert'));
};

// ── Anzeige ──
gsTerminZeile = function(t, mitDatum){
  const o = t.objektId ? findObjekt(t.objektId) : null, w = twWo(t);
  const unter = [t.uhrzeit ? '' : 'ganztägig', o && typeof aqTitel === 'function' ? aqTitel(o) : '', twOrtText(t)].filter(Boolean).join(' · ');
  return `<div class="tm-z ${w ? 'tw-z tw-z-' + w : ''}" onclick="oeffneTerminModal('${t.id}')">
    <div class="tm-zeit">${mitDatum ? `<small>${gsDatumLang(t.datum)}</small>` : ''}<b>${t.uhrzeit || '–'}</b>${t.uhrzeit ? `<small>${gsEnde(t)}</small>` : ''}</div>
    <div class="tm-was"><div class="tm-titel">${twChip(t)}${gsArtIcon(t)} ${akqEsc(t.titel)}</div>${unter ? `<div class="tm-unter">${akqEsc(unter)}</div>` : ''}</div>${gsSyncIcon(t)}</div>`;
};
aqTerminChip = function(t){ return t ? (twIcon(t) || '📅') + ' ' + aqTD(t.datum) + (t.uhrzeit ? ' ' + t.uhrzeit : '') : ''; };
aq2TermineHtml = function(o){
  const l = aqTermineVon(o), h = toDateKey(new Date());
  const kommend = l.filter(t => t.datum >= h), vorbei = l.filter(t => t.datum < h).reverse().slice(0, 2);
  const zeile = (t, alt) => { const ot = twOrtText(t); return `<div class="dp-termin ${alt ? 'vorbei' : ''}" onclick="oeffneTerminModal('${t.id}')" title="Termin öffnen / ändern">
      <span class="dt-d"><b>${aqTD(t.datum)}</b><small>${t.uhrzeit ? t.uhrzeit + (typeof gsEnde === 'function' ? '–' + gsEnde(t) : '') : 'ganztägig'}</small></span>
      <span class="dt-x"><span class="dt-t">${twChip(t)}${typeof gsArtIcon === 'function' ? gsArtIcon(t) : '📅'} ${akqEsc(typeof gsArtLabel === 'function' ? gsArtLabel(t) : t.titel)}</span>${ot ? `<small>${akqEsc(ot)}</small>` : ''}</span>${typeof gsSyncIcon === 'function' ? gsSyncIcon(t) : ''}</div>`; };
  const leer = `<div class="vl-leer">Noch kein Termin.${typeof gsAktiv === 'function' && gsAktiv() ? ' Neue Termine gehen automatisch in deinen Google Kalender.' : ''}</div>`;
  return `<h4>${IC.kal} Termine<span class="sp"></span><button class="tiny" onclick="aq2TerminNeu()">+ Termin</button></h4>`
    + ((kommend.length || vorbei.length) ? kommend.map(t => zeile(t, false)).join('') + vorbei.map(t => zeile(t, true)).join('') : leer);
};
// Kalender-Monat: Symbol vor jedem Eintrag
renderKalenderGrid = function(){
  const wtage = ['Mo','Di','Mi','Do','Fr','Sa','So'];
  document.getElementById('kalMonatTitel').textContent = kalenderMonat.toLocaleDateString('de-DE', { month: 'long', year: 'numeric' });
  const jahr = kalenderMonat.getFullYear(), monat = kalenderMonat.getMonth();
  const ersterTag = new Date(jahr, monat, 1), letzterTag = new Date(jahr, monat + 1, 0);
  let startOffset = ersterTag.getDay() - 1; if(startOffset < 0) startOffset = 6;
  const alle = alleTermineKombiniert(), heuteKey = toDateKey(new Date());
  const zellen = [];
  for(let i = 0; i < startOffset; i++) zellen.push({ datum: new Date(jahr, monat, i - startOffset + 1), ausserhalb: true });
  for(let i = 1; i <= letzterTag.getDate(); i++) zellen.push({ datum: new Date(jahr, monat, i), ausserhalb: false });
  while(zellen.length % 7 !== 0){ const d = new Date(zellen[zellen.length - 1].datum); d.setDate(d.getDate() + 1); zellen.push({ datum: d, ausserhalb: true }); }
  document.getElementById('kalGrid').innerHTML =
    wtage.map((w, i) => `<div class="kal-wtag wt-${i}">${w}</div>`).join('') +
    zellen.map(z => {
      const key = toDateKey(z.datum);
      const tt = alle.filter(t => t.datum === key).sort((a, b) => (a.uhrzeit || '').localeCompare(b.uhrzeit || ''));
      const max = 2;
      return `<div class="kal-tag wt-${(z.datum.getDay() + 6) % 7} ${z.ausserhalb ? 'ausserhalb' : ''} ${key === heuteKey ? 'heute' : ''}" onclick="oeffneTagModal('${key}')">
          <div class="tagnr">${z.datum.getDate()}</div>
          ${tt.slice(0, max).map(t => { const w = twWo(t); return `<div class="eintrag ${t.quelle === 'google' ? 'google' : ''} ${w ? 'tw-e-' + w : ''}" ${t.farbe ? `style="background:${t.farbe}22;color:${t.farbe};border-left:3px solid ${t.farbe};"` : ''} title="${akqEsc((w === 'telefon' ? 'Telefon-Termin: ' : w === 'vorort' ? 'Vor Ort: ' : '') + (t.titel || ''))}">${twPre(t)}${t.uhrzeit ? t.uhrzeit + ' ' : ''}${esc(t.titel)}</div>`; }).join('')}
          ${tt.length > max ? `<div class="mehr">+${tt.length - max} weitere</div>` : ''}
        </div>`;
    }).join('');
};
// Objekte-Liste: nächster Termin mit Symbol
function twObjektChip(o){
  if(!o) return '';
  const h = toDateKey(new Date());
  const n = (db.termine || []).filter(t => t.objektId === o.id && t.datum && t.datum >= h).sort((a, b) => (a.datum + (a.uhrzeit || '')).localeCompare(b.datum + (b.uhrzeit || '')))[0];
  if(!n) return '';
  const w = twWo(n);
  return ` <span class="tw-obj ${w ? 'tw-' + w : ''}" title="${akqEsc(n.titel || 'Termin')}${w ? ' – ' + (w === 'telefon' ? 'Telefon-Termin' : 'vor Ort') : ''}" onclick="event.stopPropagation();oeffneTerminModal('${n.id}')">${twIcon(n) || '📅'} ${akqEsc(aqTD(n.datum))}${n.uhrzeit ? ' ' + n.uhrzeit : ''}</span>`;
}
// Glocke: „3 Termine heute (📞 1 · 📍 2)“
const _twHinweise = tbHinweise;
tbHinweise = function(){
  const l = _twHinweise.apply(this, arguments);
  try{
    const e = l.find(x => x.k === 'termine');
    if(e){
      const h = toDateKey(new Date());
      const heute = (db.termine || []).filter(t => { const d = String(t.datum || '').slice(0, 10); return d === h || (t.bisDatum && d < h && t.bisDatum >= h); });
      const tel = heute.filter(t => twWo(t) === 'telefon').length, ort = heute.filter(t => twWo(t) === 'vorort').length;
      const teile = [tel ? '📞 ' + tel + ' Telefon' : '', ort ? '📍 ' + ort + ' vor Ort' : ''].filter(Boolean);
      if(teile.length) e.t += ' (' + teile.join(' · ') + ')';
    }
  }catch(err){}
  return l;
};

// ── Google Kalender: 📞/📍 vor dem Titel, Merkmal mcWo, Zeile in der Beschreibung ──
const _twHash = gsHash;
gsHash = function(t){ const h = _twHash(t), w = twWo(t); return w ? h.slice(0, -1) + ',' + JSON.stringify(w) + ']' : h; };
const _twKoerper = gsEventKoerper;
gsEventKoerper = function(t){
  const b = _twKoerper(t), w = twWo(t);
  if(w) b.summary = (w === 'telefon' ? TW.tel : TW.ort) + ' ' + b.summary;
  b.extendedProperties = b.extendedProperties || { private: {} };
  b.extendedProperties.private = Object.assign({}, b.extendedProperties.private, { mcWo: w || '' });
  return b;
};
const _twAus = gsAusEvent;
gsAusEvent = function(ev){
  const r = _twAus(ev);
  const m = /^\s*(📞|📍|☎️?)️?\s*/u.exec(r.titel || '');
  const mc = (((ev || {}).extendedProperties || {}).private || {}).mcWo;
  if(m){ r.titel = r.titel.slice(m[0].length).trim() || '(ohne Titel)'; r.wo = m[1] === '📍' ? 'vorort' : 'telefon'; }
  else if(mc === 'telefon' || mc === 'vorort') r.wo = mc;
  return r;
};
const _twFuss = gsFuss;
gsFuss = function(t){
  const f = _twFuss(t), w = twWo(t);
  if(!w) return f;
  const zeile = w === 'telefon' ? '📞 Telefon-Termin' : '📍 Termin vor Ort';
  if(!f) return (String(t.notiz || '').trim() ? '\n\n' : '') + GS_MARKE + '\n' + zeile;
  return f.replace(GS_MARKE + '\n', GS_MARKE + '\n' + zeile + '\n');
};
