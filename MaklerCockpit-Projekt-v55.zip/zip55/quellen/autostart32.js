// ═══ MaklerCockpit v32 – Mit Windows starten (Zahnrad-Menü) ═══
// Standard: an, minimiert in der Taskleiste. Wahl gilt nur für diesen PC (pc-einstellungen.json), nicht für das Handy.
function as32Da(){ return !!(window.pc && typeof window.pc.autostart2 === 'function'); }
async function as32Stand(w){ try{ return await window.pc.autostart2(w); }catch(e){ return null; } }
const _as32Menue = tbMenue;
tbMenue = function(ev, art){
  const r = _as32Menue.apply(this, arguments);
  try{
    const m = document.getElementById('tbMenue');
    if(m && art !== 'hinweise' && as32Da() && !m.querySelector('.as32-mi')){
      m.insertAdjacentHTML('beforeend', `<div class="mi as32-mi" onclick="tbMenueZu();as32Dialog()">🚀<div>Mit Windows starten<small id="as32Info">…</small></div></div>`);
      as32Stand().then(s => { const i = document.getElementById('as32Info'); if(i && s) i.textContent = s.an ? (s.minimiert ? 'an – startet minimiert in der Taskleiste' : 'an – Fenster öffnet sich') : 'aus'; });
    }
  }catch(e){}
  return r;
};
async function as32Dialog(){
  const s = await as32Stand(); if(!s) return;
  const wahl = !s.gewaehlt ? 'aus' : s.minimiert ? 'mini' : 'offen';
  const opt = (k, t, u) => `<label class="as32-opt"><input type="radio" name="as32" value="${k}" ${wahl === k ? 'checked' : ''} onchange="as32Setzen(this.value)"><div><b>${t}</b><small>${u}</small></div></label>`;
  mc24Modal(`<h3>🚀 Mit Windows starten</h3>
    <p>Das Cockpit startet von selbst, sobald du dich an diesem PC anmeldest – Erinnerungen, Glocke und der Abgleich mit dem Handy laufen dann ohne dass du daran denken musst.</p>
    <div class="as32-liste">${opt('mini', 'An – minimiert (empfohlen)', 'Startet unten in der Taskleiste, ein Klick holt es nach vorn.')}${opt('offen', 'An – Fenster gleich öffnen', 'Das Cockpit erscheint direkt nach dem Anmelden.')}${opt('aus', 'Aus', 'Du startest das Cockpit selbst.')}</div>
    <p class="mc24-muted" style="font-size:12px;">Gilt für die Datei <b>${mc24E(s.datei || '')}</b>. Startest du später eine neue Version, stellt sie den Autostart automatisch auf sich um. Ein zweites Fenster gibt es nicht – läuft das Cockpit schon, wird es nur nach vorn geholt.</p>
    <div class="modal-actions"><span></span><div class="right"><button onclick="schliesseModal()">Fertig</button></div></div>`, 520);
}
async function as32Setzen(w){
  const s = await as32Stand({ an: w !== 'aus', minimiert: w !== 'offen' });
  akqToast(!s ? 'Ging nicht' : w === 'aus' ? 'Autostart aus' : s.an ? (w === 'mini' ? '🚀 Startet mit Windows – minimiert' : '🚀 Startet mit Windows – Fenster öffnet sich') : 'Autostart ist hier nicht möglich');
}
window.addEventListener('load', () => {
  if(!as32Da()) return;
  setTimeout(async () => {
    const s = await as32Stand();
    if(s && s.neu){ await as32Stand({ gesehen: true }); if(s.an) akqToast('🚀 Das Cockpit startet ab jetzt automatisch mit Windows (minimiert) – ändern: Zahnrad → „Mit Windows starten“', 7000); }
  }, 2500);
});
