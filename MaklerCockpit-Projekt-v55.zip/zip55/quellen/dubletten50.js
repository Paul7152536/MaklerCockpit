// ═══ MaklerCockpit v50 – keine doppelten Inserate mehr ═══
// Ursachen für Doppel:
//  a) Dasselbe Inserat kommt mit leicht anderem Link (www/ohne, ?Parameter, anderer Titel-Teil) – bisher zählte nur der exakt gleiche Link.
//  b) Beim Geräte-Abgleich: gleiche id mit unterschiedlichem Inhalt wurde als „id_2“ aufgehoben → zwei Leads zum selben Inserat.
//  c) Dasselbe KI-Ergebnis am PC und am Handy eingefügt → zwei Leads mit eigener id.
// Jetzt: Inserate werden an ihrer Anzeigen-Nummer erkannt (Kleinanzeigen, ImmoScout, Immowelt, Immonet), sonst am bereinigten Link.
// Vorhandene Doppel werden automatisch zu EINEM Lead zusammengeführt (Verlauf, Termine, Analysen, Dokumente bleiben erhalten).

function dl50LinkKey(u){
  u = String(u || '').trim(); if(!/^https?:\/\//i.test(u)) return '';
  let m;
  if((m = u.match(/kleinanzeigen\.de\/s-anzeige\/(?:[^\/?#]*\/)?(\d{6,})(?:-\d+-\d+)?/i))) return 'ka:' + m[1];
  if((m = u.match(/kleinanzeigen\.de\/.*[?&]adId=(\d{6,})/i))) return 'ka:' + m[1];
  if((m = u.match(/immobilienscout24\.de\/(?:expose|Suche\/.*?\/expose)\/(\d+)/i))) return 'is:' + m[1];
  if((m = u.match(/immowelt\.de\/(?:projekte\/)?expose\/([a-z0-9]+)/i))) return 'iw:' + m[1].toLowerCase();
  if((m = u.match(/immonet\.de\/angebot\/(\d+)/i))) return 'in:' + m[1];
  // sonstige Seiten: nur wenn der Link nach EINEM Inserat aussieht (Nummer im Pfad), nie Such- oder Listenseiten
  try{
    const x = new URL(u), pfad = decodeURIComponent(x.pathname).replace(/\/+$/, '').toLowerCase();
    if(/kleinanzeigen\.de$/i.test(x.hostname) || !/\d{6,}/.test(pfad) || /\/(s-|suche|search|liste|ergebnis)/.test(pfad)) return '';
    return 'u:' + x.hostname.replace(/^(www|m)\./i, '').toLowerCase() + pfad;
  }catch(e){ return ''; }
}
function dl50SigKey(o){
  // Leads ohne Link (z. B. Zeitung): gleicher Titel, Ort, Objektart und gleiche Nummer bzw. gleicher Preis
  if(o.link) return '';
  const t = akqNorm(o.akqTitel || ''), tel = String(o.verkaeuferTelefon || '').replace(/\D/g, ''), preis = Number(o.kaufpreis) || 0;
  if(t.length < 12 || !(tel.length >= 7 || preis > 0)) return '';
  if(typeof ob26Bereich === 'function' && ob26Bereich(o) !== 'akquise') return '';
  return 'sig:' + [t, akqNorm(o.ort || ''), o.objektart || '', tel || '-', preis || '-'].join('|');
}
function dl50Key(o){ return dl50LinkKey(o && o.link) || (o ? dl50SigKey(o) : ''); }

const DL50_RANG = { abgeschlossen: 9, online: 8, auftrag: 7, termin: 6, telefontermin: 5, erstkontakt: 4, nochmal_anrufen: 3, nicht_erreicht: 2, kleinanzeigen_geschrieben: 1, email_geschrieben: 1, neu: 0 };
function dl50Besser(a, b){   // true, wenn a behalten werden soll (auf allen Geräten gleich)
  const ra = DL50_RANG[a.status] || 0, rb = DL50_RANG[b.status] || 0; if(ra !== rb) return ra > rb;
  const va = (a.verlauf || []).length, vb = (b.verlauf || []).length; if(va !== vb) return va > vb;
  const ca = Number(a.createdAt) || 0, cb = Number(b.createdAt) || 0; if(ca !== cb) return ca < cb;
  return String(a.id) < String(b.id);
}
function dl50Leer(v){ return v == null || v === '' || v === 0 || (Array.isArray(v) && !v.length) || (typeof v === 'object' && !Array.isArray(v) && !Object.keys(v).length); }
const DL50_REF = new Set(['objektId', 'oid', 'objId', 'leadId']);
const DL50_NICHT = new Set(['objekte', 'googleSync', 'sicherung', 'ab25Lokal', 'meta']);
function dl50Umhaengen(alt, neu){
  let n = 0;
  const geh = (x, tiefe) => {
    if(!x || typeof x !== 'object' || tiefe > 9) return;
    if(Array.isArray(x)){ for(let i = 0; i < x.length; i++){ if(x[i] && typeof x[i] === 'object') geh(x[i], tiefe + 1); } return; }
    for(const k of Object.keys(x)){
      const v = x[k];
      if(DL50_REF.has(k) && v === alt){ x[k] = neu; n++; continue; }
      if(k === alt && x[neu] === undefined){ x[neu] = v; delete x[k]; n++; geh(x[neu], tiefe + 1); continue; }
      if(v && typeof v === 'object') geh(v, tiefe + 1);
    }
  };
  for(const k of Object.keys(db)){ if(!DL50_NICHT.has(k)) geh(db[k], 0); }
  return n;
}
function dl50Zusammenfuehren(keep, weg){
  for(const f of Object.keys(weg)){
    if(['id', 'createdAt', 'importId', 'verlauf', 'notizen', 'status', 'statusAm', 'vb25'].includes(f)) continue;
    const a = keep[f], b = weg[f];
    if(Array.isArray(a) && Array.isArray(b)){ const s = new Set(a.map(x => JSON.stringify(x))); b.forEach(x => { if(!s.has(JSON.stringify(x))){ a.push(x); s.add(JSON.stringify(x)); } }); continue; }
    if(dl50Leer(a) && !dl50Leer(b)) keep[f] = b;
    else if(b === true && a === false) keep[f] = true;      // Favorit, hatTermin, keinMakler …
  }
  if(weg.anrufTag && (!keep.anrufTag || weg.anrufTag < keep.anrufTag) && weg.anrufTag >= toDateKey(new Date())) keep.anrufTag = weg.anrufTag;
  const vk = keep.verlauf = Array.isArray(keep.verlauf) ? keep.verlauf : [];
  const s = new Set(vk.map(v => (v.ts || '') + '|' + (v.text || '')));
  (weg.verlauf || []).forEach(v => { const k = (v.ts || '') + '|' + (v.text || ''); if(!s.has(k)){ vk.push(v); s.add(k); } });
  vk.sort((x, y) => (x.ts || 0) - (y.ts || 0));
  const nw = String(weg.notizen || '').trim();
  if(nw && !String(keep.notizen || '').includes(nw)) keep.notizen = [keep.notizen, nw].filter(Boolean).join('<br>');
  dl50Umhaengen(weg.id, keep.id);
  db.objekte = db.objekte.filter(o => o !== weg);
  vk.push({ ts: Date.now(), typ: 'info', text: '🔁 Doppeltes Inserat zusammengeführt (es war zweimal angelegt)' });
  try{ if(typeof AQ2 !== 'undefined' && AQ2.sel === weg.id) AQ2.sel = keep.id; }catch(e){}
  try{ if(typeof GA35 !== 'undefined' && GA35.obj === weg.id) GA35.obj = keep.id; }catch(e){}
}
function dl50Aufraeumen(){
  if(!db || !Array.isArray(db.objekte) || db.objekte.length < 2) return 0;
  const mb = document.getElementById('modalBg'); if(mb && mb.classList.contains('show')) return 0;   // nicht mitten in einem Dialog
  let n = 0;
  for(let runde = 0; runde < 3; runde++){
    const map = new Map(), paare = [];
    for(const o of db.objekte){
      const k = dl50Key(o); if(!k) continue;
      const a = map.get(k);
      if(!a){ map.set(k, o); continue; }
      const [keep, weg] = dl50Besser(a, o) ? [a, o] : [o, a];
      paare.push([keep, weg]); map.set(k, keep);
    }
    if(!paare.length) break;
    for(const [keep, weg] of paare){ if(db.objekte.includes(keep) && db.objekte.includes(weg)){ dl50Zusammenfuehren(keep, weg); n++; } }
  }
  if(n){ try{ if(typeof ek48AlleListenAktualisieren === 'function') ek48AlleListenAktualisieren(); }catch(e){} }
  return n;
}
// Import: Doppel im selben Einfügen zusammenfassen und an der Anzeigen-Nummer wiedererkennen
(function(){
  if(typeof akqUebernehmen !== 'function') return;
  const _u = akqUebernehmen;
  akqUebernehmen = function(eintraege, quelle){
    const liste = [], gesehen = new Map(); let doppelImText = 0;
    for(const e of (eintraege || [])){
      const k = dl50LinkKey(e && e.link);
      if(k){
        if(gesehen.has(k)){ const a = gesehen.get(k); Object.keys(e).forEach(f => { if(dl50Leer(a[f]) && !dl50Leer(e[f])) a[f] = e[f]; }); doppelImText++; continue; }
        gesehen.set(k, e);
        const o = (db.objekte || []).find(x => dl50LinkKey(x.link) === k);
        if(o && o.link !== e.link) e.link = o.link;          // gleicher Link-Text → wird als „schon bekannt“ erkannt
      }
      liste.push(e);
    }
    const r = _u.call(this, liste, quelle);
    if(r && doppelImText){ r.doppelt = (r.doppelt || 0) + doppelImText; }
    return r;
  };
})();
(function(){
  if(typeof _schreibe === 'function'){
    const _s = _schreibe;
    _schreibe = function(){
      try{ const n = dl50Aufraeumen(); if(n){ setTimeout(() => { try{ renderMain(); akqToast(`🔁 ${n} doppelte${n === 1 ? 's' : ''} Inserat${n === 1 ? '' : 'e'} zusammengeführt`, 4000); }catch(e){} }, 60); } }catch(e){ console.error('dl50', e); }
      return _s.apply(this, arguments);
    };
  }
  window.addEventListener('load', () => { setTimeout(() => { try{ const n = dl50Aufraeumen(); if(n){ save(); renderMain(); akqToast(`🔁 ${n} doppelte${n === 1 ? 's' : ''} Inserat${n === 1 ? '' : 'e'} zusammengeführt`, 5000); } }catch(e){ console.error('dl50 start', e); } }, 200); });
})();
