// ═══ MaklerCockpit v36 – Handy-Feinschliff ═══
// 1) Hinweis-Meldung (Toast) blockierte nach dem Ausblenden die Reiter Akquise/Termine/Kontakte (unsichtbar, aber noch „anfassbar“).
// 2) Größere Tippflächen am Handy (Symbole oben, z. B. Bearbeiten/Favorit bei „Aktiver Lead“).
// 3) Termine: Telefon-Termin → 15 Minuten, Vor-Ort-Termin → 1 Stunde voreingestellt.

// ── 1) Toast nie anklickbar, am Handy über den Reitern ──
(function(){
  const _akqToast = akqToast;
  akqToast = function(){
    const r = _akqToast.apply(this, arguments);
    try{
      const el = document.getElementById('akqToast');
      if(el){
        el.style.pointerEvents = 'none';
        if(window.matchMedia && window.matchMedia('(max-width: 760px)').matches) el.style.bottom = 'calc(84px + env(safe-area-inset-bottom, 0px))';
        clearTimeout(el._t36);
        el.style.visibility = 'visible';
        el._t36 = setTimeout(() => { if(el.style.opacity === '0') el.style.visibility = 'hidden'; }, (arguments[1] || 2800) + 400);
      }
    }catch(e){}
    return r;
  };
})();

// ── 3) Dauer passend zur Termin-Art ──
const H36_DAUER = { telefon: 15, vorort: 60 };
function h36DauerSetzen(id, wo){
  const sel = document.getElementById(id === 'tq_wo' ? 'tq_dauer' : 'm_t_dauer');
  const min = H36_DAUER[wo]; if(!sel || !min) return;
  if(![...sel.options].some(o => +o.value === min)){ const o = document.createElement('option'); o.value = min; o.textContent = typeof gsDauerText === 'function' ? gsDauerText(min) : min + ' Min.'; sel.appendChild(o); }
  if(+sel.value === min) return;
  sel.value = String(min);
  sel.dispatchEvent(new Event('change', { bubbles: true }));   // Zeitraster/Belegung aktualisieren
}
const _h36Klick = twKlick;
twKlick = function(id, wo){ const r = _h36Klick.apply(this, arguments); try{ h36DauerSetzen(id, wo); }catch(e){} return r; };
// Neuer Termin am Lead: automatisch gewählte Art (z. B. Rückruf → Telefon) setzt die Dauer gleich mit
const _h36TqNeu = aq2TerminNeu;
aq2TerminNeu = function(){ const r = _h36TqNeu.apply(this, arguments); try{ const w = twGewaehlt('tq_wo'); if(w) h36DauerSetzen('tq_wo', w); }catch(e){} return r; };
const _h36TqArt = aq2TqArt;
aq2TqArt = function(k, init){
  const r = _h36TqArt.apply(this, arguments);
  try{ const w = twGewaehlt('tq_wo'); if(w) h36DauerSetzen('tq_wo', w); }catch(e){}   // Dauer folgt immer Telefon/Vor Ort
  return r;
};
// Neuer Termin im allgemeinen Dialog (nicht beim Bearbeiten eines bestehenden)
const _h36TerminModal = oeffneTerminModal;
oeffneTerminModal = function(id){
  const r = _h36TerminModal.apply(this, arguments);
  try{ if(!id){ const w = twGewaehlt('m_t_wo'); if(w) h36DauerSetzen('m_t_wo', w); } }catch(e){}
  return r;
};

// ── 2) Tippflächen am Handy ──
(function(){
  const st = document.createElement('style');
  st.textContent = `@media (max-width:760px){
  .tb-icon:not(.mini){min-width:44px;min-height:44px;width:44px;height:44px}
  .tb-icon:not(.mini) svg{width:20px;height:20px}
  .h25-zurueck{font-size:20px}
  .aq-kopf .knoepfe,.dp-kopf .knoepfe{gap:6px}
  #akqToast{pointer-events:none}
}`;
  document.head.appendChild(st);
})();
