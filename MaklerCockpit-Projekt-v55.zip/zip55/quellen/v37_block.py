# ── v37: Jarvis bekommt „Mieten & Mietrecht auffrischen“ (alle 2 Wochen), Import typ=mieten → Cockpit (mp37Import) ──
_JV37 = r"""
try{
TITEL.mieten="Mieten & Mietrecht auffrischen"; ICON.mieten="🏷️"; MIT_IMPORT.add("mieten");
PROMPT_INFO.mieten="Niedrigste, mittlere und höchste Angebotsmiete je Bezirk und Umland-Gemeinde plus aktuelle Rechtslage (Mietpreisbremse, Mietspiegel, Mietrecht II …). Ergebnis → Mietpotenzial in der Marktanalyse und im Objekt.";
PLAN_STANDARD.mieten={aktiv:true, modus:"woche", tage:[1], zeit:"09:30", alle:2};
TYP_ALIAS.mieten="mieten"; TYP_ALIAS.mietdaten="mieten"; TYP_ALIAS.miete="mieten"; TYP_ALIAS.mietpotenzial="mieten";
}catch(e){ console.error("v37 jarvis", e); }
function p37(){ try{ return (window.parent!==window && window.parent.mp37Prompt) ? window.parent : null; }catch(e){ return null; } }
if(typeof promptErzeugen==="function"){ var pe37=promptErzeugen; promptErzeugen=function(typ,auftrag){ if(typ==="mieten"){ var P=p37(); if(!P){ toast("Nur im MaklerCockpit verfügbar.",3500); return ""; } return P.mp37Prompt(auftrag||""); } return pe37.apply(this,arguments); }; }
if(typeof einlesen==="function"){ var ei37=einlesen; einlesen=function(text){
  var z; try{ z=zerlegen(text); }catch(e){ return ei37.apply(this,arguments); }
  if(z[0]!=="mieten") return ei37.apply(this,arguments);
  var P=p37(); if(!P) return "⚠️ Mietdaten lassen sich nur im MaklerCockpit einlesen.";
  if(!z[1].length) return "📥 Kein lesbarer Eintrag gefunden. Bitte den ganzen Block von JARVIS-IMPORT bis JARVIS-ENDE kopieren.";
  var b; try{ b=P.mp37Import(z[1]); }catch(e){ return "⚠️ Beim Einlesen ist etwas schiefgegangen: "+e.message; }
  if(z[2]) b+=" ⚠️ "+z[2]+" Stelle(n) waren nicht lesbar und fehlen.";
  if(!/^⚠️/.test(b)) planErledigt("mieten");
  S.letzteImporte=[{zeit:new Date().toISOString(),typ:"mieten",bericht:b}].concat(S.letzteImporte||[]).slice(0,15); speichern();
  return b;
}; }
"""
a = s.index('const JV_HTML = '); b = s.index('\n', a)
html = json.loads(s[a+len('const JV_HTML = '):b].rstrip(';'))
for alt, neu in [('["akquise","rendite","hv","gebiete","markt","recht","steuer","bank"].map(t=>', '["akquise","rendite","hv","gebiete","mieten","markt","recht","steuer","bank"].map(t=>'),
                 ('const viel = ["akquise","rendite","hv","gebiete"].includes(typ);', 'const viel = ["akquise","rendite","hv","gebiete","mieten"].includes(typ);'),
                 ('t==="gebiete"?"leer = 12 Berliner Bezirke · „Umland“ · oder Namen"', 't==="gebiete"?"leer = 12 Berliner Bezirke · „Umland“ · oder Namen":t==="mieten"?"optional: weitere Orte, z. B. Bernau, Erkner"')]:
    assert html.count(alt) == 1, ('v37', alt, html.count(alt))
    html = html.replace(alt, neu)
k = html.rindex('</body>')
html = html[:k] + '<script>/* v37 Mietdaten */\n' + _JV37 + '\n</script>\n' + html[k:]
s = s[:a] + 'const JV_HTML = ' + json.dumps(html, ensure_ascii=False).replace('</', '<\\/') + ';' + s[b:]
