/* MaklerCockpit v22 – Suchkunden
   - Wer „keine Makler“ / „von privat“ / „provisionsfrei“ schreibt, kommt gar nicht erst rein
   - Suchkunden-Tabelle: auf einen Blick, was jemand sucht
   - Passende Suchkunden gut sichtbar an jedem Objekt (Objekte-Liste, Objekt-Fenster, Akquise, Käufer & Markt)
   - Suchkunden finden: Zeitung · Kleinanzeigen im eigenen Fenster („Gesuche übernehmen“) · KI-Websuche */

// ═════════ „Keine Makler“ aussortieren ═════════
const _sk21Uebernehmen = skUebernehmen;
skUebernehmen = function(liste, importId){
  let keinMakler = 0;
  const gut = (liste || []).filter(e => { const t = [e.text, e.sucht, e.details].filter(Boolean).join(' '); if(t.trim() && zlKeinMakler(t)){ keinMakler++; return false; } return true; });
  const r = _sk21Uebernehmen(gut, importId);
  r.keinMakler = keinMakler;
  return r;
};
function skKeinMaklerAussortieren(){
  let n = 0;
  skListe().forEach(g => { if((!g.status || g.status === 'aktiv') && zlKeinMakler([g.text, g.notiz].join(' '))){ g.status = 'keinMakler'; (g.verlauf = g.verlauf || []).push({ ts:Date.now(), text:'Aussortiert: will keinen Makler' }); n++; } });
  if(n) save();
  return n;
}

// ═════════ Was sucht jemand – als Chips (am Objekt grün/gelb/rot) ═════════
const SK_ART_IC = { EFH:'🏡', DHH:'🏘️', Reihenhaus:'🏘️', Wohnung:'🏢', 'Grundstück':'🌳', MFH:'🏬', Gewerbe:'🏪' };
const SK_HAUS = ['EFH', 'DHH', 'Reihenhaus'];
function skFit(o, g){
  const r = {};
  r.art = (g.arten || []).length ? g.arten.includes(o.objektart) : null;
  const oi = skOrtInfo([o.ort, o.adresse].filter(Boolean).join(' '));
  if((g.orte || []).length || g.berlinAlle || g.umland){
    let v = false;
    for(const go of g.orte || []){ const x = skOrtVergleich(go, oi); if(x === 'genau'){ v = true; break; } if(x === 'bezirk') v = 'bezirk'; }
    if(!v && g.berlinAlle && oi.land === 'BE') v = true;
    if(!v && g.umland && oi.land === 'BB') v = true;
    r.ort = v;
  } else r.ort = null;
  const kp = Number(o.kaufpreis) || 0;
  r.preis = !g.preisMax ? null : !kp ? 'warn' : kp <= g.preisMax ? true : kp <= g.preisMax * 1.12 ? 'warn' : false;
  const zi = parseFloat(String(o.zimmer || '').replace(',', '.')) || 0;
  r.zimmer = !g.zimmerMin ? null : !zi ? 'warn' : zi >= g.zimmerMin ? true : zi >= g.zimmerMin - 1 ? 'warn' : false;
  const fl = Number(o.wohnflaeche) || 0;
  r.flaeche = !g.flaecheMin ? null : !fl ? 'warn' : fl >= g.flaecheMin ? true : fl >= g.flaecheMin * 0.9 ? 'warn' : false;
  const gs = Number(o.grundstueck) || 0;
  r.grund = !g.grundstueckMin ? null : !gs ? 'warn' : gs >= g.grundstueckMin ? true : 'warn';
  return r;
}
function skChip(t, f, titel){ const k = f === true || f === 'bezirk' ? 'ok' : f === 'warn' ? 'warn' : f === false ? 'nein' : ''; return `<span class="skc ${k}"${titel ? ` title="${akqEsc(titel)}"` : ''}>${t}</span>`; }
function skArtText(g){
  const a = g.arten || [];
  if(!a.length) return '🏠 Art offen';
  const haus = SK_HAUS.every(x => a.includes(x));
  const teile = (haus ? ['🏡 Haus (EFH, DHH, RH)'] : a.filter(x => SK_HAUS.includes(x)).map(x => SK_ART_IC[x] + ' ' + SK_ART_LANG[x])).concat(a.filter(x => !SK_HAUS.includes(x)).map(x => SK_ART_IC[x] + ' ' + (SK_ART_LANG[x] || x)));
  return teile.join(' · ');
}
function skOrteText(g){ const l = (g.orte || []).slice(); if(g.berlinAlle) l.push('ganz Berlin'); if(g.umland) l.push('Umland'); return l.length ? l.join(', ') : ''; }
function skGroesseText(g){ return [g.zimmerMin ? 'ab ' + String(g.zimmerMin).replace('.', ',') + ' Zi.' : '', g.flaecheMin ? 'ab ' + g.flaecheMin + ' m²' : '', g.grundstueckMin ? 'Grundstück ab ' + Number(g.grundstueckMin).toLocaleString('de-DE') + ' m²' : ''].filter(Boolean).join(' · '); }
function skKriterienChips(g, o){
  const f = o ? skFit(o, g) : {};
  const c = [];
  c.push(skChip(akqEsc(skArtText(g)), o ? f.art : undefined, 'Objektart'));
  if(g.nutzung === 'miete') c.push(skChip('🔑 zur Miete', undefined));
  const orte = skOrteText(g);
  c.push(skChip('📍 ' + (orte ? akqEsc(orte) : 'Ort offen'), o ? f.ort : undefined, f.ort === 'bezirk' ? 'gleicher Bezirk' : 'Wunschorte'));
  c.push(skChip('💶 ' + (g.preisMax ? 'bis ' + aqEur(g.preisMax) + (g.nutzung === 'miete' ? ' im Monat' : '') : 'Budget offen'), o ? f.preis : undefined, o && Number(o.kaufpreis) ? 'Objekt: ' + aqEur(o.kaufpreis) : 'Budget'));
  if(g.zimmerMin) c.push(skChip('🛏 ab ' + String(g.zimmerMin).replace('.', ',') + ' Zi.', o ? f.zimmer : undefined, o && o.zimmer ? 'Objekt: ' + o.zimmer + ' Zi.' : ''));
  if(g.flaecheMin) c.push(skChip('📐 ab ' + g.flaecheMin + ' m²', o ? f.flaeche : undefined, o && o.wohnflaeche ? 'Objekt: ' + o.wohnflaeche + ' m²' : ''));
  if(g.grundstueckMin) c.push(skChip('🌳 Grundstück ab ' + Number(g.grundstueckMin).toLocaleString('de-DE') + ' m²', o ? f.grund : undefined, o && o.grundstueck ? 'Objekt: ' + o.grundstueck + ' m²' : ''));
  (g.wuensche || []).filter(w => !/^(see|neubau|altbau)$/.test(w)).slice(0, 4).forEach(w => c.push(`<span class="skc wunsch">${akqEsc(w.replace(/bed$/, 'bedürftig').replace(/^./, x => x.toUpperCase()))}</span>`));
  return `<span class="skc-reihe">${c.join('')}</span>`;
}
function skKontaktHtml(g, kurz){
  const tel = skTel(g), mail = skMailAdr(g), l = [];
  if(tel) l.push(`<a href="tel:${akqEsc(akqTelNorm(tel))}" title="Anrufen" onclick="event.stopPropagation()">📞 ${akqEsc(tel)}</a>`);
  if(mail) l.push(`<a href="mailto:${akqEsc(mail)}" title="E-Mail" onclick="event.stopPropagation()">✉️ ${kurz ? 'E-Mail' : akqEsc(mail)}</a>`);
  if(g.link) l.push(`<a href="#" onclick="event.stopPropagation();kgOeffnen('${akqEsc(g.link)}');return false;" title="${akqEsc(g.link)}">💬 ${/kleinanzeigen/.test(g.link) ? 'Kleinanzeigen' : 'Gesuch öffnen'}</a>`);
  if(g.chiffre) l.push(`<span title="Antwort über die Zeitung">✉️ Chiffre ${akqEsc(g.chiffre)}</span>`);
  return l.length ? l.join('') : '<span class="zl-warn">keine Kontaktdaten</span>';
}

// ═════════ An jedem Objekt gut sichtbar ═════════
function aqKaeuferBadge(o){
  const n = skTrefferFuer(o).length; if(!n) return '';
  return ` <span class="obj-sk" title="${n} Suchkunde${n === 1 ? '' : 'n'} sucht so ein Objekt – klicken für Details" onclick="event.stopPropagation();kmOeffnen('${o.id}')">👥 ${n} Suchkunde${n === 1 ? '' : 'n'}</span>`;
}
function skTrefferListeHtml(o, tr, max){
  return tr.slice(0, max || 5).map(x => `<div class="sk-r">
      <span class="sk-score-mini s${x.m.score >= 85 ? 3 : x.m.score >= 70 ? 2 : 1}" title="Trefferquote">${x.m.score} %</span>
      <div class="sk-r-mitte"><div class="sk-r-kopf"><b>${akqEsc(skName(x.g))}</b><span class="sk-r-kontakt">${skKontaktHtml(x.g, true)}</span></div>${skKriterienChips(x.g, o)}</div></div>`).join('')
    + (tr.length > (max || 5) ? `<div class="mv-sub">+ ${tr.length - (max || 5)} weitere</div>` : '');
}
aqSuchkundenHtml = function(o){
  const tr = skTrefferFuer(o); if(!tr.length) return '';
  return `<div class="sk-box"><div class="mv-kopf"><span>👥 ${tr.length} Suchkunde${tr.length === 1 ? '' : 'n'} sucht so etwas</span><button class="secondary tiny" onclick="kmOeffnen('${o.id}')">Alle anzeigen</button></div>
    ${skTrefferListeHtml(o, tr, 4)}
    ${AQ_OFFEN.includes(o.status) ? `<div class="mv-sub">Argument beim Verkäufer: „Ich habe bereits vorgemerkte Käufer, die genau so etwas in ${akqEsc(aqOrtText(o) || 'Ihrer Gegend')} suchen.“</div>` : ''}</div>`;
};
kmTrefferHtml = function(o, x){
  const g = x.g, info = (g.informiert || {})[o.id], mail = skMailAdr(g);
  const s = x.m.score >= 85 ? 3 : x.m.score >= 70 ? 2 : 1;
  return `<div class="sk-treffer"><div class="sk-score s${s}">${x.m.score}<small>%</small></div>
    <div class="sk-mitte"><div><b>${akqEsc(skName(g))}</b> <small>${akqEsc([g.quelleText || g.quelle, g.datum ? new Date(g.datum).toLocaleDateString('de-DE') : ''].filter(Boolean).join(' · '))}</small></div>
      ${skKriterienChips(g, o)}
      <div class="sk-r-kontakt" style="margin-top:4px;">${skKontaktHtml(g)}</div>
      ${info ? `<div class="sk-info">✓ informiert am ${new Date(info).toLocaleDateString('de-DE')}</div>` : ''}</div>
    <div class="sk-aktion">${mail ? `<button class="sk-btn" title="Passendes Angebot per E-Mail" onclick="skMail('${g.id}','${o.id}')">✉️</button>` : ''}
      <button class="sk-btn" title="${info ? 'Nicht mehr als informiert markieren' : 'Als informiert markieren'}" onclick="skInformiert('${g.id}','${o.id}')">${info ? '↩' : '✓'}</button></div></div>`;
};
// Objekt-Fenster: oben ein Kasten mit den passenden Suchkunden
const _skObjektModal = oeffneObjektModal;
oeffneObjektModal = function(id){
  const r = _skObjektModal.apply(this, arguments);
  try{
    const o = id ? findObjekt(id) : null;
    const tr = o ? skTrefferFuer(o) : [];
    const h = document.querySelector('#modalInner h3');
    if(h && tr.length) h.insertAdjacentHTML('afterend', `<div class="sk-box sk-im-modal"><div class="mv-kopf"><span>👥 ${tr.length} Suchkunde${tr.length === 1 ? '' : 'n'} sucht so ein Objekt</span><button class="secondary tiny" onclick="schliesseModal();kmOeffnen('${o.id}')">In „Käufer & Markt“ öffnen</button></div>${skTrefferListeHtml(o, tr, 3)}</div>`);
  }catch(e){ console.error('Suchkunden im Objekt', e); }
  return r;
};

// ═════════ Suchkunden-Tabelle ═════════
KM.skArt = KM.skArt || ''; KM.skSort = KM.skSort || 'neu'; KM.skOffen = KM.skOffen || {};
function skAktiv(g){ return !g.status || g.status === 'aktiv'; }
kmSuchkunden = function(){
  const el = document.getElementById('kmInhalt'); if(!el) return;
  const alle = skListe();
  let l = alle.slice();
  if(KM.skFilter === 'aktiv') l = l.filter(skAktiv);
  else if(KM.skFilter === 'erledigt') l = l.filter(g => g.status === 'erledigt');
  else if(KM.skFilter === 'keinMakler') l = l.filter(g => g.status === 'keinMakler');
  const art = KM.skArt;
  if(art === 'haus') l = l.filter(g => (g.arten || []).some(a => SK_HAUS.includes(a)) && g.nutzung !== 'miete');
  else if(art === 'miete') l = l.filter(g => g.nutzung === 'miete');
  else if(art) l = l.filter(g => (g.arten || []).includes(art) && g.nutzung !== 'miete');
  const q = KM.skQ.trim().toLowerCase();
  if(q) l = l.filter(g => [skName(g), g.text, skOrteText(g), skTel(g), skMailAdr(g), g.quelleText, g.chiffre].join(' ').toLowerCase().includes(q));
  const tr = new Map(l.map(g => [g.id, skObjekteFuer(g)]));
  if(KM.skSort === 'treffer') l.sort((a, b) => tr.get(b.id).length - tr.get(a.id).length || (b.createdAt || 0) - (a.createdAt || 0));
  else if(KM.skSort === 'budget') l.sort((a, b) => (b.preisMax || 0) - (a.preisMax || 0));
  else l.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
  const aktiv = alle.filter(skAktiv), mitTreffer = aktiv.filter(g => skObjekteFuer(g).length).length, aussortiert = alle.filter(g => g.status === 'keinMakler').length;
  const zeile = g => {
    const t = tr.get(g.id), offen = !!KM.skOffen[g.id];
    return `<tr class="sk-zeile ${offen ? 'offen' : ''} ${skAktiv(g) ? '' : 'inaktiv'}" onclick="KM.skOffen['${g.id}']=!KM.skOffen['${g.id}'];kmSuchkunden()">
      <td class="sk-wer"><b>${akqEsc(skName(g))}</b><small>${akqEsc(g.quelleText || g.quelle || '')}${g.datum || g.createdAt ? ' · ' + new Date(g.datum || g.createdAt).toLocaleDateString('de-DE') : ''}${g.status === 'erledigt' ? ' · erledigt' : g.status === 'keinMakler' ? ' · will keinen Makler' : ''}</small></td>
      <td><span class="sk-art">${akqEsc(skArtText(g))}</span>${g.nutzung === 'miete' ? '<span class="skc">🔑 Miete</span>' : ''}</td>
      <td>${skOrteText(g) ? akqEsc(skOrteText(g)) : '<span class="sk-offen">offen</span>'}</td>
      <td class="sk-budget">${g.preisMax ? aqEur(g.preisMax) + (g.nutzung === 'miete' ? '<small>im Monat</small>' : '') : '<span class="sk-offen">offen</span>'}</td>
      <td>${skGroesseText(g) ? akqEsc(skGroesseText(g)) : '<span class="sk-offen">–</span>'}</td>
      <td class="sk-kont"><div class="sk-kont-in">${skKontaktHtml(g, true)}</div></td>
      <td class="sk-passt-zelle"><div class="sk-passt-in">${t.length ? `<span class="sk-anz">${t.length}</span>${t.slice(0, 2).map(x => `<button class="sk-obj ${['auftrag', 'online'].includes(x.o.status) ? 'auftrag' : ''}" onclick="event.stopPropagation();kmOeffnen('${x.o.id}')" title="${akqEsc(aqTitel(x.o))}">${akqEsc(aqTitel(x.o).slice(0, 26))} · <b>${x.m.score} %</b></button>`).join('')}` : '<span class="sk-offen">–</span>'}</div></td>
      <td class="sk-akt" onclick="event.stopPropagation()"><button class="tb-icon" title="Bearbeiten" onclick="skBearbeiten('${g.id}')">${IC.stift}</button><button class="tb-icon" title="${g.status === 'erledigt' ? 'Wieder aktiv' : 'Erledigt'}" onclick="skStatus('${g.id}')">${g.status === 'erledigt' ? '↩' : '✓'}</button><button class="tb-icon" title="Löschen" onclick="skLoeschen('${g.id}')">🗑</button></td></tr>
      ${offen ? `<tr class="sk-detail"><td colspan="8"><div class="sk-detail-in">
        <div>${skKriterienChips(g)}</div>
        ${g.text ? `<div class="sk-orig"><b>Anzeige:</b> ${akqEsc(g.text)}</div>` : ''}${g.notiz ? `<div class="sk-orig"><b>Notiz:</b> ${akqEsc(g.notiz)}</div>` : ''}
        ${t.length ? `<div class="sk-detail-tr"><b>Passt zu ${t.length} Objekt${t.length === 1 ? '' : 'en'}:</b>${t.map(x => `<div class="sk-dt"><span class="sk-score-mini s${x.m.score >= 85 ? 3 : x.m.score >= 70 ? 2 : 1}">${x.m.score} %</span><a href="#" onclick="kmOeffnen('${x.o.id}');return false;">${akqEsc(aqTitel(x.o))}</a> <small>${akqEsc([x.o.ort, x.o.kaufpreis ? aqEur(x.o.kaufpreis) : '', AQ_ST_KURZ[x.o.status] || x.o.status].filter(Boolean).join(' · '))}</small> ${skKriterienChips(g, x.o)}</div>`).join('')}</div>` : '<div class="km-leer">Noch kein passendes Objekt.</div>'}
      </div></td></tr>` : ''}`;
  };
  el.innerHTML = `<div class="sk-sum"><b>${aktiv.length}</b> aktive Suchkunden · <b>${mitTreffer}</b> passen zu deinen Objekten${aussortiert ? ` · <a href="#" onclick="KM.skFilter='keinMakler';kmSuchkunden();return false;">${aussortiert} aussortiert (wollen keinen Makler)</a>` : ''}</div>
    <div class="aq-filter">
      <select onchange="KM.skFilter=this.value;kmSuchkunden()">${[['aktiv', 'Aktive Suchkunden'], ['erledigt', 'Erledigt'], ['keinMakler', 'Aussortiert: keine Makler'], ['alle', 'Alle']].map(([k, t]) => `<option value="${k}" ${KM.skFilter === k ? 'selected' : ''}>${t}</option>`).join('')}</select>
      <select onchange="KM.skArt=this.value;kmSuchkunden()">${[['', 'Alle Objektarten'], ['haus', '🏡 Haus'], ['Wohnung', '🏢 Wohnung'], ['Grundstück', '🌳 Grundstück'], ['MFH', '🏬 Mehrfamilienhaus'], ['miete', '🔑 zur Miete']].map(([k, t]) => `<option value="${k}" ${KM.skArt === k ? 'selected' : ''}>${t}</option>`).join('')}</select>
      <select onchange="KM.skSort=this.value;kmSuchkunden()">${[['neu', 'Neueste zuerst'], ['treffer', 'Meiste Treffer'], ['budget', 'Höchstes Budget']].map(([k, t]) => `<option value="${k}" ${KM.skSort === k ? 'selected' : ''}>${t}</option>`).join('')}</select>
      <div class="such">${IC.lupe}<input placeholder="Name, Ort, Telefon …" value="${akqEsc(KM.skQ)}" oninput="KM.skQ=this.value;kmSuchkunden();const i=document.querySelector('#kmInhalt .such input');if(i){i.focus();i.setSelectionRange(i.value.length,i.value.length);}"></div>
    </div>
    ${l.length ? `<div class="sk-tab-wrap"><table class="sk-tab"><thead><tr><th>Wer</th><th>Sucht</th><th>Wo</th><th>Budget</th><th>Größe</th><th>Kontakt</th><th>Passt zu</th><th></th></tr></thead><tbody>${l.map(zeile).join('')}</tbody></table></div>`
      : `<div class="aq-leer"><b>${alle.length ? 'Keine Suchkunden für diesen Filter' : 'Noch keine Suchkunden'}</b>Oben auf „🔎 Suchkunden finden“: Zeitung einlesen, Kleinanzeigen-Gesuche übernehmen oder die KI suchen lassen.</div>`}`;
};

// ═════════ Suchkunden finden ═════════
const KG_KAT = [['haus', '🏡 Häuser', 's-haus-kaufen', 208], ['wohnung', '🏢 Wohnungen', 's-wohnung-kaufen', 196], ['grund', '🌳 Grundstücke', 's-grundstuecke-garten', 207], ['miete', '🔑 Mietwohnungen', 's-wohnung-mieten', 203]];
function kgUrl(k, ort){
  const x = KG_KAT.find(a => a[0] === k) || KG_KAT[0];
  ort = String(ort || '').trim();
  if(ort) return `https://www.kleinanzeigen.de/${x[2]}/anzeige:gesuche/${encodeURIComponent(ort.toLowerCase().replace(/\s+/g, '-'))}/k0c${x[3]}`;
  return `https://www.kleinanzeigen.de/${x[2]}/berlin/anzeige:gesuche/c${x[3]}l3331r30`;
}
function kgVerfuegbar(){ return !!(window.pc && typeof window.pc.webfenster === 'function'); }
async function kgOeffnen(url){
  if(!kgVerfuegbar()){ window.open(url, '_blank'); return; }
  const r = await window.pc.webfenster('oeffnen', { url });
  if(!r || !r.ok) akqToast('⚠️ ' + ((r && r.fehler) || 'Fenster ließ sich nicht öffnen'));
}
// AKQ: Prompt „Käufer-Gesuche“ für die ganze Region
if(!AKQ_PROMPTS.some(p => p.key === 'gesuche')) AKQ_PROMPTS.splice(Math.max(0, AKQ_PROMPTS.findIndex(p => p.key === 'hv')), 0, { key:'gesuche', icon:'👥', titel:'Käufer-Gesuche (Suchkunden)', text:'Websuche nach Kaufgesuchen von Privatleuten – landen als Suchkunden und werden mit deinen Objekten abgeglichen.', tage:7,
  prompt:(e) => `Du hilfst Paul Görner (Immobilienmakler, BETTERHOMES Berlin), Käufer zu finden. Heute ist der ${new Date().toLocaleDateString('de-DE')}. Nutze die Websuche gründlich und öffne jedes Gesuch einzeln.

AUFGABE: Finde bis zu ${e.anzahl} aktuelle KAUFGESUCHE von Privatleuten – Menschen, die ein Haus, eine Wohnung oder ein Grundstück kaufen wollen – im Gebiet ${e.gebiet}. Nur Gesuche der letzten ${Math.max(14, Number(e.tage) || 0)} Tage.
Wo suchen: kleinanzeigen.de (Häuser zum Kauf, Eigentumswohnungen, Grundstücke – jeweils Anzeigentyp „Gesuche“), markt.de und andere Kleinanzeigen-Portale mit Gesuche-Rubrik, Online-Ausgaben regionaler Anzeigenblätter.
- NICHT aufnehmen: Gesuche von Maklern, Bauträgern oder Aufkäufern („für vorgemerkte Kunden“, „kaufe alle Immobilien“) und Gesuche mit „keine Makler“, „von privat“, „provisionsfrei“ o. ä. – diese Leute wollen keinen Makler. Gesuche mit „Makler willkommen“ oder „gerne auch über Makler“ sind dagegen besonders gut.
- Link = PFLICHT: direkter Link zum einzelnen Gesuch. Ohne Link keine Aufnahme.
- Kontaktdaten nur, wenn sie im Gesuch stehen – sonst „Nicht angegeben“ (Kontakt dann über die Nachrichtenfunktion).
- Erfinde nichts; prüfe jeden Eintrag gegen das geöffnete Gesuch.

ANTWORTFORMAT (genau so – Paul fügt deine Antwort in sein Programm ein, das liest sie automatisch):
Nummeriere die Gesuche (1., 2., 3., …). Jedes Gesuch bekommt genau diese Zeilen:
${AKQ_FORMAT_GESUCH_ZEILEN}

Keine Tabellen, kein Fettdruck, keine Erklärungen zwischen den Einträgen. Am Ende eine Zeile: „Gesamt: X Gesuche“.` });
function kgFinden(){
  const e = akqDb().einst;
  x20Modal(`<div id="kgModal"><h3>🔎 Suchkunden finden</h3>
    <div class="gs-intro" style="margin-bottom:10px;">Alles, was hier gefunden wird, landet automatisch bei den Suchkunden und wird sofort mit deinen Objekten abgeglichen. Wer „keine Makler“, „von privat“ oder „provisionsfrei“ schreibt, wird aussortiert.</div>
    <div class="sf-karten">
      <div class="sf-karte"><b>💬 Kleinanzeigen</b><span>Öffnet die Gesuche in einem eigenen Fenster. Unten im Fenster auf <b>„Gesuche dieser Seite übernehmen“</b> klicken – fertig. Du kannst dort ganz normal blättern und filtern.</span>
        <div class="sf-knoepfe">${KG_KAT.map(([k, t]) => `<button class="secondary tiny" onclick="kgOeffnen(kgUrl('${k}'))">${t}</button>`).join('')}</div>
        <div class="sf-ort"><input id="kgOrt" placeholder="oder Ort, z. B. Falkensee"><select id="kgArt">${KG_KAT.map(([k, t]) => `<option value="${k}">${t}</option>`).join('')}</select><button class="tiny" onclick="kgOeffnen(kgUrl(document.getElementById('kgArt').value, document.getElementById('kgOrt').value))">Öffnen</button></div>
        <small>Ohne Ort: Berlin + 30 km.</small></div>
      <div class="sf-karte"><b>🤖 KI-Websuche</b><span>Claude sucht im ganzen Netz nach Kaufgesuchen im Gebiet <b>${akqEsc(e.gebiet)}</b>. Prompt kopieren → in Claude einfügen → Antwort hier einfügen.</span>
        <div class="sf-knoepfe"><button class="secondary tiny" onclick="akqPromptKopieren('gesuche')">📋 Prompt kopieren</button><button class="secondary tiny" onclick="window.open('https://claude.ai/new','_blank')">Claude ↗</button><button class="tiny" onclick="kgKiEinfuegen()">Antwort einfügen</button></div></div>
      <div class="sf-karte"><b>📄 Zeitung</b><span>PDF oder Fotos der Anzeigenseiten – Kaufgesuche werden automatisch erkannt.</span>
        <div class="sf-knoepfe"><button class="secondary tiny" onclick="schliesseModal();zlDialog()">Zeitung einlesen</button></div></div>
    </div>
    <div class="modal-actions"><span></span><div class="right"><button class="secondary" onclick="schliesseModal()">Schließen</button></div></div></div>`, 720);
}
function kgKiEinfuegen(){
  x20Modal(`<div id="kgKiModal"><h3>📋 KI-Ergebnis einfügen</h3><div class="gs-intro" style="margin-bottom:8px;">Antwort von Claude/ChatGPT (Gesuche im Format „Anzeigentyp: Gesuch …“) hier einfügen.</div>
    <textarea id="kgKiText" style="min-height:240px;"></textarea>
    <div class="modal-actions"><span></span><div class="right"><button class="secondary" onclick="schliesseModal()">Abbrechen</button><button onclick="kgKiUebernehmen()">Übernehmen</button></div></div></div>`, 680);
  setTimeout(() => { const t = document.getElementById('kgKiText'); if(t) t.focus(); }, 30);
}
function kgKiUebernehmen(){
  const t = String((document.getElementById('kgKiText') || {}).value || '');
  if(!t.trim()) return;
  const ber = akqImportText(t, 'KI-Suche');
  schliesseModal();
  if(ber && ber.fehler) akqToast('⚠️ ' + ber.fehler, 5000);
  KM.tab = 'suchkunden'; if(aktuelleAnsicht === 'kaeufer') renderMain(); else wechsleAnsicht('kaeufer');
}
// Kleinanzeigen-Fenster: Gesuche der angezeigten Seite übernehmen
function kgDaten(d){
  const status = t => { try{ if(kgVerfuegbar()) window.pc.webfenster('status', t); }catch(e){} };
  if(!d || d.fehler){ status('⚠️ ' + ((d && d.fehler) || 'Nichts gelesen')); return null; }
  const roh = Array.isArray(d.eintraege) ? d.eintraege : [];
  const url = String(d.url || '');
  const z = { keinGesuch:0, keinMakler:0, makler:0, keineImmo:0, aussen:0 };
  const liste = [];
  const heute = new Date().toISOString().slice(0, 10);
  roh.forEach(x => {
    const titel = zlNorm(x.titel), text = zlNorm([x.titel, x.text, x.art].filter(Boolean).join('. '));
    const istGesuch = d.gesuchSeite || /anzeige:gesuche/.test(url) || x.gesuchMarke || ZL_GESUCH.test(titel) || /gesuch/i.test(x.art || '');
    if(!istGesuch){ z.keinGesuch++; return; }
    if(!ZL_IMMO.test(text) && !/haus|wohnung|grundst/i.test(url)){ z.keineImmo++; return; }
    if(zlIstMakler(text)){ z.makler++; return; }
    if(zlKeinMakler(text)){ z.keinMakler++; return; }
    const k = zlGesuchKriterien(text);
    if(!k.arten.length){ if(/s-haus/.test(url)) k.arten = SK_HAUS.slice(); else if(/s-wohnung/.test(url)) k.arten = ['Wohnung']; else if(/grundst/.test(url)) k.arten = ['Grundstück']; }
    if(/-mieten\//.test(url)) k.nutzung = 'miete';
    if(!k.preisMax && x.preis){ const b = akqPreis(x.preis); if(b >= (k.nutzung === 'miete' ? 100 : 10000)) k.preisMax = b; }
    const ortAnz = String(x.ort || '').replace(/\b\d{5}\b/g, '').replace(/\s+/g, ' ').trim();
    if(!k.orte.length && ortAnz) k.orte = [ortAnz.split(/\s+-\s+|,/).pop().trim()];
    const land = skOrtInfo([x.ort, (k.orte || []).join(' ')].join(' ')).land;
    if(!land && !k.berlinAlle && !k.umland){ z.aussen++; return; }
    const dat = /heute/i.test(x.datum || '') ? heute : /gestern/i.test(x.datum || '') ? new Date(Date.now() - 864e5).toISOString().slice(0, 10) : akqDatum(x.datum);
    liste.push(Object.assign(k, { text, wer:'', name:zlNorm(x.name || ''), link:/^https?:/i.test(x.link || '') ? x.link : '', quelle:'Kleinanzeigen', quelleText:'Kleinanzeigen-Gesuch', datum:dat || '' }));
  });
  const r = liste.length ? skUebernehmen(liste) : { neu:0, doppelt:0, treffer:0, keinMakler:0 };
  z.keinMakler += r.keinMakler || 0;
  const t = `✅ ${r.neu} neu übernommen${r.doppelt ? ', ' + r.doppelt + ' schon da' : ''}${z.keinMakler ? ' · ' + z.keinMakler + ' wollen keinen Makler (aussortiert)' : ''}${z.makler ? ' · ' + z.makler + ' Makler-Gesuche ignoriert' : ''}${z.keinGesuch ? ' · ' + z.keinGesuch + ' Angebote ignoriert' : ''}${z.aussen ? ' · ' + z.aussen + ' außerhalb Berlin/Brandenburg' : ''}${r.treffer ? ' · passen zu ' + r.treffer + ' Objekt' + (r.treffer === 1 ? '' : 'en') : ''}`;
  status(t);
  akqToast('👥 Kleinanzeigen: ' + t.replace('✅ ', ''), 5000);
  if(aktuelleAnsicht === 'kaeufer') renderMain();
  try{ tbGlockeAktualisieren(); }catch(e){}
  return Object.assign({ r }, z);
}
if(window.pc && typeof window.pc.onWebfenster === 'function') window.pc.onWebfenster(d => { try{ kgDaten(d); }catch(e){ console.error('Kleinanzeigen', e); } });

window.addEventListener('load', () => { try{ const n = skKeinMaklerAussortieren(); if(n) console.log('v22: ' + n + ' Suchkunden ohne Makler-Wunsch aussortiert'); }catch(e){ console.error(e); } });
