/* MaklerCockpit v18 – Unterlagen zu Objekten und Akquise-Leads
   Dateien liegen in Dokumente\MaklerCockpit\Unterlagen\<Objekt-Ordner>\, in den Daten stehen nur Name, Kategorie und Pfad. */
const DOK = { basis: '' };
const DOK_KAT = [
  ['expose','Exposé','📰'], ['grundbuch','Grundbuchauszug','📜'], ['energie','Energieausweis','⚡'], ['grundriss','Grundriss','📐'],
  ['flurkarte','Flurkarte / Lageplan','🗺️'], ['wohnflaeche','Wohnflächenberechnung','📏'], ['teilung','Teilungserklärung','📑'],
  ['weg','WEG-Protokolle','🗂️'], ['hausgeld','Wirtschaftsplan / Hausgeld','💶'], ['mietvertrag','Mietverträge','🔑'],
  ['baulast','Baulastenauskunft','🏛️'], ['auftrag','Maklerauftrag','✍️'], ['foto','Fotos','📷'], ['sonstiges','Sonstiges','📄'],
];
// Was für einen Verkauf typischerweise gebraucht wird – je Objektart
const DOK_CHECK = {
  Wohnung: ['expose','grundbuch','energie','grundriss','teilung','weg','hausgeld'],
  MFH: ['expose','grundbuch','energie','grundriss','flurkarte','wohnflaeche','mietvertrag','baulast'],
  Haus: ['expose','grundbuch','energie','grundriss','flurkarte','wohnflaeche','baulast'],
  'Grundstück': ['expose','grundbuch','flurkarte','baulast'],
  Gewerbe: ['expose','grundbuch','energie','grundriss','mietvertrag'],
};
const DOK_REGELN = [
  ['flurkarte', /flurkarte|lageplan|liegenschaftskarte|katasterkarte|kataster/],
  ['energie', /energie|epass|\beav\b|ausweis_e|verbrauchsausweis|bedarfsausweis/],
  ['grundbuch', /grundbuch|gb ?auszug|gbauszug/],
  ['teilung', /teilungserkl|aufteilungsplan|teilungs/],
  ['weg', /protokoll|eigentuemerversammlung|etv\b|beschlusssammlung/],
  ['hausgeld', /wirtschaftsplan|hausgeld|jahresabrechnung|weg abrechnung/],
  ['mietvertrag', /mietvertrag|mieterliste|mietaufstellung|mietermatrix/],
  ['baulast', /baulast/],
  ['wohnflaeche', /wohnflaeche|flaechenberechnung|\bwfl\b|flaechenaufstellung/],
  ['auftrag', /maklervertrag|alleinauftrag|vermittlungsauftrag|maklerauftrag|auftrag/],
  ['grundriss', /grundriss|plan eg|plan og|plan dg|floorplan|\bplan\b/],
  ['expose', /expose|exposé|inserat|anzeige/],
];
function dokVerfuegbar(){ return !!(window.pc && window.pc.dok); }
async function dokRuf(a, x){ try{ return (await window.pc.dok(a, x)) || { ok:false }; }catch(e){ return { ok:false, fehler:String(e.message||e) }; } }
function dokL(o){ return Array.isArray(o && o.dokumente) ? o.dokumente : []; }
function dokKat(k){ return DOK_KAT.find(x => x[0] === k) || DOK_KAT[DOK_KAT.length-1]; }
function dokNorm(s){ return String(s||'').toLowerCase().replace(/ä/g,'ae').replace(/ö/g,'oe').replace(/ü/g,'ue').replace(/ß/g,'ss').replace(/[_\-.]+/g,' '); }
function dokKatRaten(name){
  const n = dokNorm(name);
  if(/\.(jpe?g|png|webp|heic|gif)$/i.test(name) && !/grundriss|energie|grundbuch|flurkarte|lageplan|expose/.test(n)) return 'foto';
  for(const [k, re] of DOK_REGELN) if(re.test(n)) return k;
  return 'sonstiges';
}
function dokArtGruppe(o){
  const a = String(o.objektart||'');
  if(a === 'Wohnung') return 'Wohnung';
  if(a === 'MFH') return 'MFH';
  if(a === 'Grundstück') return 'Grundstück';
  if(a === 'Gewerbe') return 'Gewerbe';
  if(/EFH|DHH|Reihenhaus|haus/i.test(a)) return 'Haus';
  return null;
}
function dokCheck(o){ const g = dokArtGruppe(o); return g ? DOK_CHECK[g] : ['expose','grundbuch','energie','grundriss']; }
function dokGroesse(b){ b = Number(b)||0; return b >= 1048576 ? (b/1048576).toLocaleString('de-DE',{maximumFractionDigits:1}) + ' MB' : Math.max(1, Math.round(b/1024)) + ' KB'; }
function dokOrdnerVon(o){
  if(!o.dokOrdner){
    const titel = [o.adresse || (typeof aqTitel==='function' ? aqTitel(o) : o.akqTitel) || 'Objekt', o.ort ? String(o.ort).replace(/^\d{5}\s*/,'') : ''].filter(Boolean).join(', ');
    o.dokOrdner = (titel.replace(/[\\/:*?"<>|\u0000-\u001f]+/g,' ').replace(/\s+/g,' ').trim().slice(0,60) || 'Objekt') + ' (' + String(o.id).slice(-6) + ')';
  }
  return o.dokOrdner;
}
function dokUrl(d){
  if(!DOK.basis) return '';
  const p = (DOK.basis.replace(/\\/g,'/') + '/' + String(d.datei).replace(/\\/g,'/'));
  const teile = p.split('/').map((s, i) => (i === 0 && /^[A-Za-z]:$/.test(s)) ? s : encodeURIComponent(s));
  return (p.startsWith('/') ? 'file://' : 'file:///') + teile.join('/');
}
function dokIcon(d){
  if(/\.(jpe?g|png|webp|gif)$/i.test(d.datei||'') && DOK.basis) return `<img src="${akqEsc(dokUrl(d))}" loading="lazy" alt="" onerror="this.outerHTML='<span class=&quot;dok-ext&quot;>BILD</span>'">`;
  const ext = (String(d.datei||'').split('.').pop()||'').toUpperCase().slice(0,4);
  return `<span class="dok-ext ${ext==='PDF'?'pdf':''}">${akqEsc(ext||'DATEI')}</span>`;
}

// ── Anzeige ──
function dokSektionHtml(o){
  if(!dokVerfuegbar() || !o || !o.id) return '';
  const ordnung = k => DOK_KAT.findIndex(x => x[0] === k);
  const l = dokL(o).slice().sort((a,b) => ordnung(a.kat) - ordnung(b.kat) || (b.am||0) - (a.am||0));
  const check = dokCheck(o), da = new Set(l.map(d => d.kat));
  const fehlt = check.filter(k => !da.has(k));
  const zeilen = l.map(d => { const k = dokKat(d.kat); return `<div class="dok-z" onclick="dokOeffnen('${o.id}','${d.id}')" title="Öffnen: ${akqEsc(d.name)}">
      <span class="dok-ic">${dokIcon(d)}</span>
      <span class="dok-n"><b>${akqEsc(d.name)}</b><small>${k[2]} ${akqEsc(k[1])} · ${dokGroesse(d.groesse)} · ${new Date(d.am||Date.now()).toLocaleDateString('de-DE')}</small></span>
      <button class="tb-icon mini" title="Mehr" onclick="event.stopPropagation();dokMenue(event,'${o.id}','${d.id}')">${typeof IC!=='undefined' && IC.mehr ? IC.mehr : '⋯'}</button></div>`; }).join('');
  const chips = check.map(k => { const kk = dokKat(k); return da.has(k)
      ? `<span class="dok-chk ok" title="vorhanden">✓ ${akqEsc(kk[1])}</span>`
      : `<span class="dok-chk fehlt" title="Datei als „${akqEsc(kk[1])}“ hinzufügen" onclick="dokHinzu('${o.id}','${k}')">+ ${akqEsc(kk[1])}</span>`; }).join('');
  return `<div class="dok-sek" data-dok="${o.id}" ondragover="event.preventDefault();this.classList.add('drop')" ondragleave="if(!this.contains(event.relatedTarget))this.classList.remove('drop')" ondrop="event.preventDefault();event.stopPropagation();this.classList.remove('drop');dokDrop(event,'${o.id}')">
    <h4>📎 Unterlagen${l.length ? ` <span class="dok-anz">${l.length}</span>` : ''}<span class="sp"></span>
      <button class="secondary tiny" title="Ordner im Explorer öffnen" onclick="dokOrdnerOeffnen('${o.id}')">📁 Ordner</button>
      <button class="tiny" onclick="dokHinzu('${o.id}')">+ Datei</button></h4>
    ${l.length ? `<div class="dok-liste">${zeilen}</div>` : `<div class="dok-leer">Dateien hierher ziehen oder „+ Datei“ – z. B. Exposé, Grundbuchauszug, Energieausweis, Fotos.</div>`}
    <div class="dok-check"><div class="dok-check-k">${fehlt.length ? `Unterlagen-Check: ${check.length - fehlt.length} von ${check.length} da` : '✓ Alle wichtigen Unterlagen da'}</div>${chips}</div>
  </div>`;
}
function dokAktualisieren(oid){
  const o = findObjekt(oid);
  document.querySelectorAll(`.dok-sek[data-dok="${oid}"]`).forEach(el => { el.outerHTML = dokSektionHtml(o); });
  document.querySelectorAll(`[data-dokz="${oid}"]`).forEach(el => { const n = dokL(o).length; el.textContent = n ? '📎 ' + n : ''; });
}

// ── Aktionen ──
function dokEintrag(o, f, kat){
  const d = { id: uid(), name: f.name, datei: f.datei, groesse: f.groesse || 0, kat: kat || dokKatRaten(f.name), am: Date.now() };
  if(!Array.isArray(o.dokumente)) o.dokumente = [];
  o.dokumente.push(d);
  return d;
}
function dokFertig(o, neu){
  if(!neu.length) return;
  if(typeof aqLog === 'function') aqLog(o, 'info', neu.length === 1 ? 'Unterlage hinzugefügt: ' + neu[0].name + ' (' + dokKat(neu[0].kat)[1] + ')' : neu.length + ' Unterlagen hinzugefügt');
  save(); dokAktualisieren(o.id);
  akqToast(neu.length === 1 ? '📎 ' + neu[0].name + ' gespeichert' : '📎 ' + neu.length + ' Dateien gespeichert', 2600);
}
async function dokHinzu(oid, kat){
  const o = findObjekt(oid); if(!o || !dokVerfuegbar()) return;
  const ordner = dokOrdnerVon(o);
  const r = await dokRuf('auswaehlen', { ordner });
  if(!r.ok){ if(!r.abgebrochen) akqToast('⚠️ ' + (r.fehler || 'Hinzufügen fehlgeschlagen')); return; }
  const o2 = findObjekt(oid); if(!o2) return;
  o2.dokOrdner = ordner;
  dokFertig(o2, r.dateien.map(f => dokEintrag(o2, f, kat)));
}
async function dokDrop(ev, oid){
  const dateien = [...((ev.dataTransfer && ev.dataTransfer.files) || [])];
  if(!dateien.length) return;
  const o = findObjekt(oid); if(!o) return;
  const ordner = dokOrdnerVon(o), neu = [];
  akqToast('📎 Speichere ' + dateien.length + ' Datei' + (dateien.length === 1 ? '' : 'en') + ' …', 1500);
  for(const f of dateien){
    if(f.size > 300 * 1048576){ akqToast('⚠️ ' + f.name + ' ist zu groß (über 300 MB)'); continue; }
    let daten; try{ daten = new Uint8Array(await f.arrayBuffer()); }catch(e){ continue; }   // Ordner o. Ä. lassen sich nicht lesen
    const r = await dokRuf('speichern', { ordner, name: f.name, daten });
    const o2 = findObjekt(oid);
    if(r.ok && o2){ o2.dokOrdner = ordner; neu.push(dokEintrag(o2, r.datei)); }
    else if(!r.ok) akqToast('⚠️ ' + f.name + ': ' + (r.fehler || 'konnte nicht gespeichert werden'));
  }
  const o3 = findObjekt(oid); if(o3) dokFertig(o3, neu);
}
async function dokOeffnen(oid, did, zeigen){
  const o = findObjekt(oid), d = dokL(o).find(x => x.id === did); if(!d) return;
  const r = await dokRuf(zeigen ? 'zeigen' : 'oeffnen', { datei: d.datei });
  if(!r.ok) akqToast('⚠️ ' + (r.fehler || 'Öffnen fehlgeschlagen') + (r.code === 'weg' ? ' – über ⋯ kannst du den Eintrag entfernen.' : ''), 4500);
}
async function dokOrdnerOeffnen(oid){
  const o = findObjekt(oid); if(!o) return;
  const neu = !o.dokOrdner, ordner = dokOrdnerVon(o);
  const r = await dokRuf('ordner', { ordner });
  if(neu) save();
  if(!r.ok) akqToast('⚠️ ' + (r.fehler || 'Ordner konnte nicht geöffnet werden'));
}
function dokKatSetzen(oid, did, kat){
  const o = findObjekt(oid), d = dokL(o).find(x => x.id === did); if(!d) return;
  d.kat = kat; save(); dokAktualisieren(oid);
}
function dokEntfernen(oid, did){
  const o = findObjekt(oid), d = dokL(o).find(x => x.id === did); if(!d) return;
  bestaetigeUnten(`„${d.name}“ entfernen? Die Datei kommt in den Windows-Papierkorb.`, async () => {
    const r = await dokRuf('loeschen', { datei: d.datei });
    if(!r.ok){ akqToast('⚠️ ' + (r.fehler || 'Entfernen fehlgeschlagen')); return; }
    const o2 = findObjekt(oid); if(!o2) return;
    o2.dokumente = dokL(o2).filter(x => x.id !== did);
    if(typeof aqLog === 'function') aqLog(o2, 'info', 'Unterlage entfernt: ' + d.name);
    save(); dokAktualisieren(oid);
    akqToast(r.papierkorb === false ? '🗑️ Entfernt (liegt in Unterlagen\\_Papierkorb)' : '🗑️ Entfernt – liegt im Papierkorb');
  });
}
function dokMenue(ev, oid, did){
  if(typeof tbMenueZu === 'function') tbMenueZu();
  const o = findObjekt(oid), d = dokL(o).find(x => x.id === did); if(!d) return;
  const m = document.createElement('div'); m.id = 'tbMenue'; m.className = 'tb-menue dok-menue';
  const r = ev.currentTarget.getBoundingClientRect();
  m.style.position = 'fixed'; m.style.top = Math.min(r.bottom + 6, window.innerHeight - 260) + 'px'; m.style.right = Math.max(8, window.innerWidth - r.right) + 'px'; m.style.zIndex = 10050;
  m.innerHTML = `<div class="mi" onclick="tbMenueZu();dokOeffnen('${oid}','${did}')">📂<div>Öffnen</div></div>
    <div class="mi" onclick="tbMenueZu();dokOeffnen('${oid}','${did}',true)">🗂️<div>Im Ordner zeigen</div></div>
    <div class="mi dok-kat-mi" onclick="event.stopPropagation()">🏷️<div>Art<select onchange="dokKatSetzen('${oid}','${did}',this.value);tbMenueZu()">${DOK_KAT.map(k => `<option value="${k[0]}" ${d.kat===k[0]?'selected':''}>${k[2]} ${k[1]}</option>`).join('')}</select></div></div>
    <div class="mi" onclick="tbMenueZu();dokEntfernen('${oid}','${did}')" style="color:#fca5a5;">🗑️<div>Entfernen</div></div>`;
  document.body.appendChild(m);
  ev.stopPropagation();
}

// ── Objekt-Fenster: Unterlagen unter dem Formular ──
const _dokObjektModal = oeffneObjektModal;
oeffneObjektModal = function(id){
  const r = _dokObjektModal.apply(this, arguments);
  try{
    const act = document.querySelector('#modalInner .modal-actions');
    if(act && dokVerfuegbar()){
      const o = id ? findObjekt(id) : null;
      act.insertAdjacentHTML('beforebegin', `<div class="dok-im-modal">${o ? dokSektionHtml(o) : '<div class="dok-leer">📎 Unterlagen kannst du hinzufügen, sobald das Objekt gespeichert ist.</div>'}</div>`);
    }
  }catch(e){ console.error('Unterlagen', e); }
  return r;
};

window.addEventListener('load', async () => {
  if(!dokVerfuegbar()) return;
  const r = await dokRuf('basis');
  if(r.ok){ DOK.basis = r.basis; document.querySelectorAll('.dok-sek').forEach(el => dokAktualisieren(el.dataset.dok)); }
});
