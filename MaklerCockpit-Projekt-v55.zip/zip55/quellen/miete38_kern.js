// ═══ MaklerCockpit v38 – Mietvergleichsangebote: Rechenkern (ohne Oberfläche, in Node testbar) ═══
// Grundlage: Pauls „Mietmodul-Handbuch“ (15.11.2026), Kap. 4: Einzelpreis = Nettokaltmiete / Wohnfläche, Mittel, Median,
// Minimum/Maximum aus derselben Stichprobe, P25/P75 mit linearer Interpolation h = (n − 1) × q. Eignung geht vor Anzahl.
(function(root){
  function zahl(v){ if(v === null || v === undefined || v === '') return null; if(typeof v === 'number') return isFinite(v) ? v : null; const s = String(v).replace(/[^\d,.\-]/g, ''); if(!s) return null; const n = s.includes(',') ? Number(s.replace(/\./g, '').replace(',', '.')) : Number(s); return isFinite(n) ? n : null; }
  function txt(v, max){ return v == null ? '' : String(v).replace(/[<>]/g, '').replace(/\s+/g, ' ').slice(0, max || 160).trim(); }
  function ja(v){ return v === true || v === 'true' || v === 'ja' || v === 1; }
  function quantil(sortiert, q){ const n = sortiert.length; if(!n) return null; const h = (n - 1) * q, lo = Math.floor(h), hi = Math.ceil(h); return sortiert[lo] + (sortiert[hi] - sortiert[lo]) * (h - lo); }
  function istHaus(art){ const t = String(art || '').toLowerCase(); return /haus|efh|zfh|dhh|bungalow|villa/.test(t) && !/mehrfamil|mfh|wohnung|etw|hochhaus/.test(t); }
  function link(u){ try{ const x = new URL(String(u || '')); return /^https?:$/.test(x.protocol) ? x.href : ''; }catch(e){ return ''; } }
  function host(u){ try{ return new URL(u).hostname.replace(/^www\./, ''); }catch(e){ return ''; } }

  // Ein Angebot aus der KI-Antwort oder von Hand prüfen und in feste Form bringen. ziel: { haus: bool }
  function fall(x, ziel){
    x = x || {}; ziel = ziel || {};
    const f = {
      url: link(x.url), portal: txt(x.portal, 40) || host(link(x.url)), pid: txt(x.portal_id != null ? x.portal_id : x.pid, 40), titel: txt(x.titel, 120),
      plz: (String(x.plz || '').match(/\b\d{5}\b/) || [''])[0], ortsteil: txt(x.ortsteil, 60), lage: txt(x.lage_genau, 20),
      objektart: txt(x.objektart, 30).toLowerCase(), flaeche: zahl(x.flaeche), zimmer: zahl(x.zimmer), kalt: zahl(x.nettokalt != null ? x.nettokalt : x.kalt), warm: zahl(x.warm),
      baujahr: zahl(x.baujahr), zustand: txt(x.zustand, 80), ausstattung: txt(x.ausstattung, 160),
      moebliert: ja(x.moebliert), befristet: ja(x.befristet), gefoerdert: ja(x.gefoerdert), tausch: ja(x.tausch), wg: ja(x.wg), erstbezug: ja(x.neubau_erstbezug),
      online: txt(x.online_seit, 10), abruf: txt(x.abruf, 10), notiz: txt(x.grund || x.notiz, 200), von: txt(x.von, 10) || 'ki'
    };
    const gruende = [];
    if(f.kalt == null) gruende.push(f.warm != null ? 'Nur Warmmiete – Nettokaltmiete nicht belegt (wird nicht geschätzt)' : 'Nettokaltmiete fehlt');
    if(f.flaeche == null) gruende.push('Wohnfläche fehlt');
    f.qm = f.kalt != null && f.flaeche ? f.kalt / f.flaeche : null;
    if(f.qm != null && (f.qm < 3 || f.qm > 80 || f.flaeche < 10 || f.flaeche > 600)) gruende.push('Wert unplausibel (' + (Math.round(f.qm * 100) / 100) + ' €/m²)');
    if(f.moebliert) gruende.push('möbliert (eigenes Segment)');
    if(f.befristet) gruende.push('Kurzzeit/befristet (eigenes Segment)');
    if(f.gefoerdert) gruende.push('gefördert/WBS (preisgebunden)');
    if(f.tausch) gruende.push('Tauschangebot');
    if(f.wg) gruende.push('WG-Zimmer');
    if(f.objektart && ziel.haus !== undefined && istHaus(f.objektart) !== !!ziel.haus) gruende.push(ziel.haus ? 'Wohnung statt Haus' : 'Haus statt Wohnung');
    if(x.geeignet === false || x.geeignet === 'false') gruende.push(f.notiz || 'von der KI als ungeeignet markiert');
    f.geeignet = !gruende.length; f.grund = gruende.join('; ');
    f.rechenbar = f.qm != null && f.qm >= 3 && f.qm <= 80;
    return f;
  }

  // Dubletten: gleiche Portal-ID – oder gleiche PLZ, Fläche (±0,5 m²), Nettokaltmiete (±1 €) und Zimmerzahl. Ein Objekt zählt einmal.
  function gleich(a, b){
    if(a.pid && b.pid && a.portal && a.portal === b.portal) return a.pid === b.pid;
    if(a.url && a.url === b.url) return true;
    if(a.flaeche == null || b.flaeche == null || a.kalt == null || b.kalt == null) return false;
    if(a.plz && b.plz && a.plz !== b.plz) return false;
    if(a.zimmer != null && b.zimmer != null && a.zimmer !== b.zimmer) return false;
    return Math.abs(a.flaeche - b.flaeche) <= 0.5 && Math.abs(a.kalt - b.kalt) <= 1;
  }
  function gleichesObjekt(a, b){   // gleiche Anzeige mit geändertem Preis
    return !!(a.pid && b.pid && a.portal && a.portal === b.portal && a.pid === b.pid) || !!(a.url && a.url === b.url);
  }
  function zusammenfuehren(liste){
    const out = [];
    for(const f of liste){
      const i = out.findIndex(o => gleich(o, f));
      if(i < 0){ out.push(Object.assign({ quellen: f.url ? [{ url: f.url, portal: f.portal }] : [], preise: [] }, f)); continue; }
      const o = out[i];
      if(f.url && !o.quellen.some(q => q.url === f.url)) o.quellen.push({ url: f.url, portal: f.portal });
      const preisGleich = f.kalt == null || o.kalt == null || Math.abs(f.kalt - o.kalt) <= 1;
      if(preisGleich && (f.abruf || '') > (o.abruf || '')) o.abruf = f.abruf;   // zuletzt gesehen
      if(gleichesObjekt(o, f) && f.kalt != null && o.kalt != null && Math.abs(f.kalt - o.kalt) > 1){   // Preisänderung → Historie, kein neuer Fall
        const neuer = (f.abruf || '') >= (o.abruf || '');
        o.preise.push({ kalt: neuer ? o.kalt : f.kalt, abruf: neuer ? o.abruf : f.abruf });
        if(neuer){ o.kalt = f.kalt; o.abruf = f.abruf; o.qm = o.flaeche ? o.kalt / o.flaeche : null; }
      }
    }
    return out;
  }

  // Kennzahlen aus den geeigneten Fällen
  function statistik(faelle){
    const p = (faelle || []).filter(x => x && x.geeignet && x.rechenbar).slice().sort((a, b) => a.qm - b.qm), v = p.map(x => x.qm), n = v.length;
    const stufe = !n ? 'keine' : n < 5 ? 'einzelwerte' : n < 8 ? 'vorlaeufig' : 'voll';
    if(!n) return { n: 0, stufe };
    const sum = v.reduce((s, x) => s + x, 0), kalt = p.reduce((s, x) => s + x.kalt, 0), fl = p.reduce((s, x) => s + x.flaeche, 0);
    const tage = p.map(x => x.abruf || x.online).filter(Boolean).sort();
    return { n, stufe, min: v[0], max: v[n - 1], minFall: p[0], maxFall: p[n - 1], mittel: sum / n, median: quantil(v, 0.5), p25: quantil(v, 0.25), p75: quantil(v, 0.75),
      gewichtet: fl ? kalt / fl : null, von: tage[0] || '', bis: tage[tage.length - 1] || '' };
  }
  const STUFEN = { keine: 'Keine Vergleichsangebote – nur regionale Jahresdaten', einzelwerte: 'Nur Einzelwerte, sehr begrenzte Aussagekraft (unter 5 geeignete Angebote)', vorlaeufig: 'Vorläufige Statistik (5–7 geeignete Angebote)', voll: 'Vollständige Auswertung (ab 8 geeigneten Angeboten) – keine Garantie für Repräsentativität' };

  root.MP38K = { zahl, txt, quantil, fall, gleich, zusammenfuehren, statistik, istHaus, link, host, STUFEN };
})(typeof window !== 'undefined' ? window : globalThis);
