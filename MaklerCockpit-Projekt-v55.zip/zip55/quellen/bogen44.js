// ═══ MaklerCockpit v44 – Große Analyse im Fragebogen-Aufbau + Eigentümer-Fragebogen als PDF (erstellen & einlesen) ═══
// Pauls Wunsch (17.11.2026): Die Erfassung im Tool sieht aus wie der Eigentümer-Fragebogen – 9 Abschnitte, einfache Fragen,
// feste Plätze (Fenstergruppen, Bäder …). Die übrigen Katalogfelder (Gutachten-Niveau) bleiben zugeklappt darunter erreichbar.
// Quelle/Prüfstatus je Angabe sind ausgeblendet und lassen sich einschalten.
// Fragebogen-PDF: ausfüllbar (Dropdowns, Kästchen, Textfelder). Einlesen: Werte als „Eigentümerangabe, ungeprüft“;
// vorhandene abweichende Angaben werden NICHT überschrieben, sondern zum Vergleich angezeigt.
// Name des Ausfüllenden wird nur am Entwurf gemerkt (e.fragebogen), nie in Notizen oder Prompts.

Object.assign(GA44, { quellen: false, alleAuf: false, slot: {}, konflikte: null });
try{ GA44.quellen = localStorage.getItem('mc44Quellen') === '1'; }catch(e){}

// ── virtuelle Plätze: „Fenstergruppe 2“ existiert erst, wenn dort etwas eingetragen wird ──
(function(){
  const _z = ga43Ziel;
  ga43Ziel = function(e, pfad, anlegen){
    const t = String(pfad).split(':');
    if(t[0] === 'g' && t[2] && t[2][0] === '~'){
      const key = (GA35.obj || 'frei') + '|' + t[1] + '|' + t[2];
      let id = GA44.slot[key];
      const l = (e.gruppen43 || {})[t[1]] || [];
      if(!id || !l.some(x => x.id === id)){
        if(!anlegen) return null;
        if(!e.gruppen43) e.gruppen43 = {};
        if(!e.gruppen43[t[1]]) e.gruppen43[t[1]] = [];
        id = uid(); e.gruppen43[t[1]].push({ id, w: {} }); GA44.slot[key] = id;
      }
      t[2] = id; pfad = t.join(':');
    }
    return _z.call(this, e, pfad, anlegen);
  };
  const _ein = ga43Eingabe;
  ga43Eingabe = function(ev){
    const t = ev.target;
    if(t && t.dataset && t.dataset.m === 'v1' && t.dataset.g43){   // Einzelauswahl für ein Mehrfachfeld (Tabellenzeilen)
      const e = ga35Entwurf(GA35.obj), x = ga43Ziel(e, t.dataset.g43, true); if(!x) return;
      x.v = t.value ? [t.value] : []; ga35Merken(ev.type === 'change'); return;
    }
    return _ein.apply(this, arguments);
  };
})();

function ga44Label(l, f){ return f && f.e ? l.replace(/\s*\((m²|€|%|kWp|kWh\/m²·a|qm)\)\s*$/, '') : l; }
function ga44FeldTool(e, k, l, w, pfad, gruppe){
  const f = gruppe ? gruppe.f.find(x => x.k === k) : (GA43_F[k] && GA43_F[k].f); if(!f) return '';
  if(!ga43FeldSichtbar(e, f, w)) return '';
  return ga43FeldHtml(e, Object.assign({}, f, { l: ga44Label(l || f.l, f) }), w[k], pfad, w);
}
function ga44BogenHtml(e){
  const E = ga35E, teile = [];
  GA44_BOGEN.forEach((a, ai) => {
    if(/^Unterlagen, Preis/.test(a.t)) return;
    if(e.art === 'Grundstueck' && !/Flächen|Nutzung/.test(a.t)) return;
    let h = '';
    a.f.forEach(it => {
      if(Array.isArray(it)){
        const [k, l] = it; if(k[0] === '@') return;
        h += ga44FeldTool(e, k, l, e.werte, 'w:' + k);
        return;
      }
      const g = GA43_G[it.g]; if(!g) return;
      const l = (e.gruppen43 || {})[g.id] || [], anz = Math.max(it.n, l.length);
      let gh = '';
      for(let p = 1; p <= anz; p++){
        const en = l[p - 1], id = en ? en.id : '~' + p, w = (en && en.w) || {};
        const kopf = it.tabelle ? `<span class="ga44-nr">${p}</span>` : `<div class="ga44-ekopf"><b>${E(it.titel || GA43_EINTRAG[g.id] || 'Eintrag')}${anz > 1 || it.n > 1 ? ' ' + p : ''}</b>${en ? `<button type="button" class="tiny secondary" title="Eintrag leeren/entfernen" onclick="ga43Weg('${g.id}','${E(en.id)}')">✕</button>` : ''}</div>`;
        const felder = it.f.map(k => {
          const f = g.f.find(x => x.k === k); if(!f || !ga43Bed(w, f)) return '';
          let def = Object.assign({}, f, { l: ga44Label(f.l.replace(' / Maßnahme', '').replace(' laut Kenntnisstand', ''), f) });
          if(it.tabelle && f.t === 'multi'){ def.t = 'sel'; def.sonst = 0; return ga43FeldHtml(e, def, w[k], `g:${g.id}:${id}:${k}`, w).replace(/data-m="v"/g, 'data-m="v1"'); }
          return ga43FeldHtml(e, def, w[k], `g:${g.id}:${id}:${k}`, w);
        }).join('');
        gh += it.tabelle ? `<div class="ga44-zeile">${kopf}<div class="ga44-zfelder">${felder}</div>${en ? `<button type="button" class="tiny secondary ga44-zweg" title="Zeile leeren" onclick="ga43Weg('${g.id}','${E(en.id)}')">✕</button>` : ''}</div>` : `<div class="ga44-eintrag">${kopf}<div class="ga43-felder">${felder}</div></div>`;
      }
      gh += `<button type="button" class="secondary tiny ga44-mehr" onclick="ga43Neu('${g.id}')">＋ ${E(it.tabelle ? 'weitere Zeile' : 'weitere ' + (it.titel || 'Eintrag'))}</button>`;
      h += `<div class="ga44-gruppe breit">${gh}</div>`;
    });
    teile.push(`<div class="ga44-sek"><h4><span class="ga44-strich"></span>${ai + 1}. ${E(a.t)}</h4>${a.hinweis ? `<div class="mc24-muted ga44-hin">${E(a.hinweis)}</div>` : ''}<div class="ga43-felder">${h}</div></div>`);
  });
  const fb = e.fragebogen ? `<div class="mc24-muted ga44-fbinfo">📥 Eigentümer-Fragebogen eingelesen am ${E(mc24Datum(e.fragebogen.am))}${e.fragebogen.datum ? ' (ausgefüllt ' + E(e.fragebogen.datum) + ')' : ''}.</div>` : '';
  return `<div class="ga35-karte ga44-bogen${GA44.quellen ? '' : ' ohneq'}">
    <div class="ga44-titel"><h3>📋 Objektdaten</h3><div class="ga44-knoepfe">
      <button type="button" class="secondary" onclick="ga44PdfErstellen()" title="Leeren Fragebogen als ausfüllbares PDF für den Eigentümer speichern">📄 Fragebogen als PDF</button>
      <button type="button" class="secondary" onclick="ga44Einlesen()" title="Vom Eigentümer ausgefülltes PDF einlesen">📥 Ausgefüllten Fragebogen einlesen</button>
      <label class="ga44-q"><input type="checkbox" ${GA44.quellen ? 'checked' : ''} onchange="ga44Quellen(this.checked)"> Quellen zeigen</label></div></div>
    <div class="mc24-muted ga44-intro">Gleicher Aufbau wie der Eigentümer-Fragebogen. Nur ausfüllen, was bekannt ist – leer oder „Unbekannt“ ist in Ordnung.</div>
    ${fb}${teile.join('')}</div>`;
}
function ga44Quellen(an){ GA44.quellen = !!an; try{ localStorage.setItem('mc44Quellen', an ? '1' : '0'); }catch(e){} ga35Neuzeichnen(); }
function ga44AlleAuf(d){ GA44.alleAuf = d.open; }
(function(){
  const _k = ga43KatalogHtml;
  ga43KatalogHtml = function(e){
    const alt = ga43AltHtml(e), voll = _k.apply(this, arguments), kat = alt && voll.endsWith(alt) ? voll.slice(0, voll.length - alt.length) : voll;
    const n = GA43_KAT.reduce((s, g) => s + ga43Zaehl(e, g), 0);
    return ga44BogenHtml(e) + alt + `<details class="ga44-alle"${GA44.alleAuf ? ' open' : ''} ontoggle="ga44AlleAuf(this)"><summary>🔧 Alle Detailfelder (Gutachten-Niveau, 205 Felder${n ? ` · ${n} ausgefüllt` : ''})</summary>${kat}</details>`;
  };
})();

// ── PDF erstellen ──
function ga44PdfLib(){
  if(window.PDFLib) return Promise.resolve(window.PDFLib);
  return new Promise((ok, nein) => { const s = document.createElement('script'); s.src = 'vendor/pdf-lib.min.js'; s.onload = () => window.PDFLib ? ok(window.PDFLib) : nein(new Error('PDF-Bibliothek fehlt')); s.onerror = () => nein(new Error('PDF-Bibliothek nicht gefunden')); document.head.appendChild(s); });
}
function ga44B64(bytes){ let s = ''; for(let i = 0; i < bytes.length; i += 0x8000) s += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000)); return btoa(s); }
function ga44Bytes(b64){ const s = atob(b64), u = new Uint8Array(s.length); for(let i = 0; i < s.length; i++) u[i] = s.charCodeAt(i); return u; }
async function ga44PdfBytes(id, e){
  const P = await ga44PdfLib(), o = id ? findObjekt(id) : null;
  const titel = String((o && aqTitel(o)) || '').slice(0, 60);
  const adr = String((e.werte.adresse || {}).v || (o && o.adresse) || '').trim(), plz = String((e.werte.plz || {}).v || ''), ort = String((e.werte.ort || {}).v || '');
  const adresse = adr + (adr && plz && !adr.includes(plz) ? ', ' + plz + ' ' + ort : '');
  const abs = (typeof db === 'object' && db.profil && (db.profil.firma || db.profil.name)) || 'Görner Immobilien';
  return ga44FragebogenErstellen({ PDFLib: P, kat: GA43_KAT, arten: GA35_ARTEN, unterlagen: GA35_UNTERLAGEN, art: e.art, objektId: id || 'frei', titel, adresse, absender: 'Görner Immobilien', dachBild: ga44Bytes(GA44_DACH_PDF) });
}
async function ga44PdfErstellen(){
  const id = GA35.obj, e = ga35Entwurf(id);
  try{
    akqToast('📄 Fragebogen wird erstellt …', 2000);
    const bytes = await ga44PdfBytes(id, e), o = id ? findObjekt(id) : null;
    const name = ('Objekt-Fragebogen ' + String((o && aqTitel(o)) || '').replace(/[\\/:*?"<>|]+/g, ' ').trim()).trim().slice(0, 70) + '.pdf';
    const b64 = ga44B64(bytes);
    if(window.pc && window.pc.dateiSpeichern){
      const r = await window.pc.dateiSpeichern(name, b64);
      if(r && r.ok){ akqToast('✅ Fragebogen gespeichert' + (r.name ? ': ' + r.name : '') + ' – jetzt per E-Mail an den Eigentümer schicken', 6000); if(o) try{ aqLog(o, 'notiz', '📄 Eigentümer-Fragebogen (PDF) erstellt'); save(); }catch(err){} }
      else if(!(r && r.abgebrochen)) akqToast('⚠️ Speichern fehlgeschlagen: ' + ((r && r.fehler) || ''), 6000);
      return;
    }
    const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([bytes], { type: 'application/pdf' })); a.download = name; document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 4000);
  }catch(err){ console.error(err); akqToast('⚠️ Fragebogen konnte nicht erstellt werden: ' + (err.message || err), 6000); }
}

// ── Ausgefüllten Fragebogen einlesen ──
function ga44Einlesen(){
  const inp = document.createElement('input'); inp.type = 'file'; inp.accept = 'application/pdf,.pdf'; inp.style.display = 'none';
  inp.onchange = async () => {
    const f = inp.files && inp.files[0]; inp.remove(); if(!f) return;
    if(f.size > 40e6){ akqToast('⚠️ Datei zu groß'); return; }
    try{ await ga44EinlesenBytes(new Uint8Array(await f.arrayBuffer())); }catch(err){ console.error(err); akqToast('⚠️ ' + (err.message || err), 7000); }
  };
  document.body.appendChild(inp); inp.click();
}
function ga44Sauber(v, max){ return String(v == null ? '' : v).replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, '').trim().slice(0, max || 300); }
async function ga44Lesen(bytes){
  const P = await ga44PdfLib();
  let doc; try{ doc = await P.PDFDocument.load(bytes, { ignoreEncryption: true }); }catch(err){ throw new Error('Die PDF-Datei lässt sich nicht öffnen.'); }
  const kw = String(doc.getKeywords() || '');
  if(!/MaklerCockpit-Fragebogen/.test(kw)) throw new Error('Das ist kein MaklerCockpit-Fragebogen.');
  const objId = (kw.match(/obj:(\S+)/) || [])[1] || '';
  const werte = {};
  doc.getForm().getFields().forEach(fd => {
    const n = fd.getName();
    try{
      if(fd instanceof P.PDFDropdown){ const s = fd.getSelected(); if(s && s[0]) werte[n] = s[0]; }
      else if(fd instanceof P.PDFTextField){ const t = fd.getText(); if(t && t.trim()) werte[n] = t; }
      else if(fd instanceof P.PDFCheckBox){ if(fd.isChecked()) werte[n] = true; }
    }catch(err){}
  });
  return { objId, werte };
}
function ga44Zuordnen(e, werte){   // → Liste von Änderungen { pfad, f, label, neu (Wert), alt (Text), konflikt }
  const aend = [], heute = ga35Heute(), datum = ga44Sauber(werte['@datum'], 40);
  const optWert = (f, s) => ga44Opts(f).find(o => ga44San(o) === s);
  const fertig = (f, v) => ({ v, q: 'Eigentümerangabe', p: 'Ungeprüfte Angabe', d: heute, n: 'Eigentümer-Fragebogen' + (datum ? ' vom ' + datum : '') });
  const merke = (pfad, f, label, v, w) => {
    if(v == null || v === '' || (Array.isArray(v) && !v.length)) return;
    const x = w, altText = x && !ga43Leer(x) ? ga43Text(f, x) : '';
    const neuText = ga43Text(f, { v });
    aend.push({ pfad, f, label, wert: v, neuText, altText, konflikt: !!altText && altText !== neuText, gleich: !!altText && altText === neuText });
  };
  const einzel = {}, mehr = {}, gr = {};
  Object.entries(werte).forEach(([n, v]) => {
    const t = n.split('|');
    if(t[0] === 'w'){ if(t.length === 2) einzel[t[1]] = v; else if(t[2] === 'von' || t[2] === 'bis'){ (einzel[t[1]] = einzel[t[1]] && typeof einzel[t[1]] === 'object' ? einzel[t[1]] : {})[t[2]] = v; } else (mehr[t[1]] = mehr[t[1]] || []).push(+t[2]); }
    else if(t[0] === 'g'){ const k = t[1] + '|' + t[2]; gr[k] = gr[k] || { gid: t[1], pos: +t[2], w: {}, m: {} }; if(t.length === 4) gr[k].w[t[3]] = v; else (gr[k].m[t[3]] = gr[k].m[t[3]] || []).push(+t[4]); }
  });
  Object.entries(einzel).forEach(([k, v]) => {
    const f = GA43_F[k] && GA43_F[k].f; if(!f) return;
    let wert;
    if(f.t === 'zeitraum'){ const von = ga44Sauber(v.von, 12), bis = ga44Sauber(v.bis, 12); if(!von && !bis) return; wert = { von, bis }; }
    else if(f.t === 'sel'){ wert = optWert(f, v); if(!wert) return; }
    else wert = ga44Sauber(v, f.t === 'lang' ? 2000 : 200);
    merke('w:' + k, f, f.l, wert, e.werte[k]);
  });
  Object.entries(mehr).forEach(([k, idx]) => { const f = GA43_F[k] && GA43_F[k].f; if(!f) return; const o = ga44Opts(f); merke('w:' + k, f, f.l, idx.sort((a, b) => a - b).map(i => o[i]).filter(Boolean), e.werte[k]); });
  Object.values(gr).sort((a, b) => a.gid < b.gid ? -1 : a.gid > b.gid ? 1 : a.pos - b.pos).forEach(s => {
    const g = GA43_G[s.gid]; if(!g) return;
    const l = (e.gruppen43 || {})[g.id] || [], en = l[s.pos - 1], w = (en && en.w) || {}, id = en ? en.id : '~' + s.pos;
    const name = (GA43_EINTRAG[g.id] || g.t) + ' ' + s.pos + ': ';
    Object.entries(s.w).forEach(([k, v]) => {
      const f = g.f.find(x => x.k === k); if(!f) return;
      let wert;
      if(f.t === 'sel'){ wert = optWert(f, v); if(!wert) return; }
      else if(f.t === 'multi'){ const o = optWert(f, v); if(!o) return; wert = [o]; }
      else wert = ga44Sauber(v, f.t === 'lang' ? 2000 : 200);
      merke(`g:${g.id}:${id}:${k}`, f, name + f.l, wert, w[k]);
    });
    Object.entries(s.m).forEach(([k, idx]) => { const f = g.f.find(x => x.k === k); if(!f) return; const o = ga44Opts(f); merke(`g:${g.id}:${id}:${k}`, f, name + f.l, idx.sort((a, b) => a - b).map(i => o[i]).filter(Boolean), w[k]); });
  });
  return { aend, fertig };
}
async function ga44EinlesenBytes(bytes){
  const id = GA35.obj, e = ga35Entwurf(id), r = await ga44Lesen(bytes);
  const weiter = () => ga44Uebernehmen(id, e, r.werte);
  if(r.objId && r.objId !== 'frei' && id && r.objId !== id){
    const o = findObjekt(r.objId);
    bestaetigeUnten(`Dieser Fragebogen wurde für ${o ? '„' + aqTitel(o) + '“' : 'ein anderes Objekt'} erstellt. Trotzdem hier einlesen?`, weiter, 'Hier einlesen');
    return;
  }
  weiter();
}
function ga44Uebernehmen(id, e, werte){
  const { aend, fertig } = ga44Zuordnen(e, werte);
  let neu = 0;
  const konf = aend.filter(a => a.konflikt);
  aend.filter(a => !a.konflikt && !a.gleich).forEach(a => { const x = ga43Ziel(e, a.pfad, true); if(!x) return; Object.assign(x, fertig(a.f, a.wert)); ga43S(x); neu++; });
  aend.filter(a => a.gleich).forEach(a => { const x = ga43Ziel(e, a.pfad, false); if(x && !x.q){ x.q = 'Eigentümerangabe'; ga43S(x); } });
  // Objektart
  const artL = ga44Sauber(werte['@art'], 80), art = (GA35_ARTEN.find(a => ga44San(a[1]) === artL) || [])[0];
  if(art && !e.art){ e.art = art; neu++; }
  const artKonf = art && e.art && art !== e.art ? (GA35_ARTEN.find(a => a[0] === art) || [])[1] : '';
  // Preisvorstellung, Notiz, Unterlagen (ohne Namen – der bleibt nur am Entwurf)
  const wunsch = ga44Sauber(werte['@wunsch'], 30);
  let wunschKonf = '';
  if(wunsch){ const x = e.werte.wunsch; if(!x || ga43Leer(x)){ e.werte.wunsch = { v: wunsch, s: 'owner_statement', q: 'Eigentümerangabe', p: 'Ungeprüfte Angabe', d: ga35Heute() }; neu++; } else if(String(x.v).replace(/\D/g, '') !== wunsch.replace(/\D/g, '')) wunschKonf = wunsch; }
  const datum = ga44Sauber(werte['@datum'], 40), zus = [];
  const unt = Object.keys(werte).filter(k => /^@unterlagen\|\d+$/.test(k)).map(k => (GA35_UNTERLAGEN[+k.split('|')[1]] || [])[1]).filter(Boolean);
  if(unt.length) zus.push('Eigentümer kann bereitstellen: ' + unt.join(', '));
  const notiz = ga44Sauber(werte['@notiz'], 2000); if(notiz) zus.push('Hinweis des Eigentümers: ' + notiz);
  if(zus.length){ const kopf = `[Eigentümer-Fragebogen${datum ? ' vom ' + datum : ''}]`; if(!String(e.notiz || '').includes(zus.join('\n'))) e.notiz = (e.notiz ? e.notiz.trim() + '\n\n' : '') + kopf + '\n' + zus.join('\n'); }
  e.fragebogen = { am: Date.now(), datum: datum || null, name: ga44Sauber(werte['@name'], 80) || null, felder: aend.length };
  save();
  const o = id ? findObjekt(id) : null;
  if(o) try{ aqLog(o, 'notiz', `📥 Eigentümer-Fragebogen eingelesen (${neu} Angaben übernommen${konf.length ? ', ' + konf.length + ' abweichend' : ''})`); save(); }catch(err){}
  GA44.konflikte = { id, liste: konf, fertig, artKonf, art, wunschKonf };
  ga35Neuzeichnen();
  ga44ErgebnisDialog(neu, aend.filter(a => a.gleich).length);
}
function ga44ErgebnisDialog(neu, gleich){
  const K = GA44.konflikte, E = ga35E;
  const zeilen = K.liste.map((a, i) => `<tr><td>${E(a.label)}</td><td>${E(a.altText)}</td><td><b>${E(a.neuText)}</b></td><td><input type="checkbox" class="ga44-kw" data-i="${i}"></td></tr>`).join('')
    + (K.artKonf ? `<tr><td>Objektart</td><td>${E((GA35_ARTEN.find(a => a[0] === ga35Entwurf(K.id).art) || [])[1] || '')}</td><td><b>${E(K.artKonf)}</b></td><td><input type="checkbox" class="ga44-kw" data-i="art"></td></tr>` : '')
    + (K.wunschKonf ? `<tr><td>Preisvorstellung</td><td>${E(ga43Text(null, ga35Entwurf(K.id).werte.wunsch))}</td><td><b>${E(K.wunschKonf)}</b></td><td><input type="checkbox" class="ga44-kw" data-i="wunsch"></td></tr>` : '');
  const n = K.liste.length + (K.artKonf ? 1 : 0) + (K.wunschKonf ? 1 : 0);
  mc24Modal(`<h3>📥 Fragebogen eingelesen</h3>
    <p><b>${neu}</b> Angaben übernommen (als „Eigentümerangabe, ungeprüft“)${gleich ? `, ${gleich} stimmten schon überein` : ''}.</p>
    ${n ? `<p class="mc24-muted">${n} Angaben weichen von deiner bisherigen Erfassung ab und wurden <b>nicht</b> überschrieben. Haken setzen, um die Eigentümerangabe zu übernehmen:</p>
    <div style="max-height:46vh;overflow:auto"><table class="ga44-ktab"><thead><tr><th>Feld</th><th>Bisher</th><th>Eigentümer</th><th>Übernehmen</th></tr></thead><tbody>${zeilen}</tbody></table></div>` : '<p class="mc24-muted">Keine Abweichungen zu bisherigen Angaben.</p>'}
    <p class="mc24-muted">Preisvorstellung, Hinweise und bereitstellbare Unterlagen stehen in den Notizen. Der Name des Ausfüllenden wird nicht in Prompts übernommen.</p>
    <div class="modal-actions"><button class="secondary" onclick="schliesseModal()">Fertig</button><div class="right">${n ? `<button class="secondary" onclick="document.querySelectorAll('.ga44-kw').forEach(c => c.checked = true)">Alle markieren</button><button onclick="ga44KonflikteUebernehmen()">Markierte übernehmen</button>` : ''}</div></div>`, 760);
}
function ga44KonflikteUebernehmen(){
  const K = GA44.konflikte; if(!K) return schliesseModal();
  const e = ga35Entwurf(K.id); let n = 0;
  document.querySelectorAll('.ga44-kw').forEach(c => {
    if(!c.checked) return;
    const i = c.dataset.i;
    if(i === 'art'){ e.art = K.art; n++; return; }
    if(i === 'wunsch'){ e.werte.wunsch = Object.assign(e.werte.wunsch || {}, { v: K.wunschKonf, s: 'owner_statement', q: 'Eigentümerangabe', p: 'Ungeprüfte Angabe', d: ga35Heute() }); n++; return; }
    const a = K.liste[+i]; if(!a) return;
    const x = ga43Ziel(e, a.pfad, true); if(!x) return;
    const alt = a.altText; Object.assign(x, K.fertig(a.f, a.wert)); x.alt = alt; ga43S(x); n++;
  });
  GA44.konflikte = null; save(); schliesseModal(); ga35Neuzeichnen();
  akqToast(`✅ ${n} Eigentümerangaben übernommen (vorheriger Wert ist gemerkt)`, 4500);
}

(function(){
  const st = document.createElement('style');
  st.textContent = `.ga44-titel{display:flex;flex-wrap:wrap;gap:8px 14px;align-items:center;justify-content:space-between}.ga44-titel h3{margin:0}
.ga44-knoepfe{display:flex;flex-wrap:wrap;gap:6px;align-items:center}.ga44-q{display:flex;gap:5px;white-space:nowrap;align-items:center;font-size:12px;color:var(--muted);text-transform:none;letter-spacing:0;margin:0}
.ga44-intro{font-size:12px;margin:6px 0 4px}.ga44-fbinfo{font-size:12px;margin:2px 0 6px;color:var(--green)}
.ga44-sek{margin-top:16px}.ga44-sek h4{display:flex;align-items:center;gap:8px;margin:0 0 8px;font-size:15px}
.ga44-strich{display:inline-block;width:4px;height:16px;background:var(--orange);border-radius:2px}
.ga44-hin{font-size:12px;margin:-4px 0 8px}
.ga44-bogen.ohneq .ga43-her{display:none}.ga44-bogen.ohneq .ga43-panel{display:none}
.ga44-gruppe{display:flex;flex-direction:column;gap:8px}
.ga44-eintrag{border-left:3px solid var(--orange);padding:2px 0 4px 10px}
.ga44-ekopf{display:flex;gap:8px;align-items:center;margin-bottom:4px;color:var(--orange)}.ga44-ekopf button{margin-left:auto}
.ga44-zeile{display:flex;gap:8px;align-items:flex-start;border-bottom:1px solid var(--border);padding-bottom:6px}
.ga44-nr{min-width:18px;font-weight:600;color:var(--muted);padding-top:22px}
.ga44-zfelder{flex:1;display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:6px 10px}
.ga44-zfelder .ga43-feld.breit{grid-column:auto}
.ga44-zweg{margin-top:20px}
.ga44-mehr{align-self:flex-start}
.ga44-alle{margin:10px 0}.ga44-alle>summary{cursor:pointer;color:var(--muted);font-size:13px;padding:6px 2px}
.ga44-ktab{width:100%;border-collapse:collapse;font-size:13px}.ga44-ktab th,.ga44-ktab td{border-bottom:1px solid var(--border);padding:5px 6px;text-align:left;vertical-align:top}
@media (max-width:760px){.ga44-zfelder{grid-template-columns:1fr}.ga44-nr{padding-top:2px}.ga44-zeile{flex-wrap:wrap}}`;
  document.head.appendChild(st);
})();
