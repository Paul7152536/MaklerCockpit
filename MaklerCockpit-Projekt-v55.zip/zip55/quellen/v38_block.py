# ── v38: Jarvis liest „typ=mietvergleiche“ (Vergleichsangebote je Objekt) ein und nutzt aufgefrischte VPI-Werte im Mietrechner ──
_JV38 = r"""
try{ TYP_ALIAS.mietvergleiche="mietvergleiche"; TYP_ALIAS.mietvergleich="mietvergleiche"; TYP_ALIAS.vergleichsmieten="mietvergleiche"; TITEL.mietvergleiche="Vergleichsangebote (Miete)"; ICON.mietvergleiche="🔎"; }catch(e){ console.error("v38 jarvis", e); }
function p38(){ try{ return (window.parent!==window && window.parent.mp38Import) ? window.parent : null; }catch(e){ return null; } }
try{ if(typeof MR!=="undefined" && MR.setVpiExtra){ var sv38=MR.setVpiExtra; MR.setVpiExtra=function(o){ var p={}; try{ var P=p38(); if(P) p=P.mp37Db().vpi||{}; }catch(e){} return sv38(Object.assign({}, p, o||{})); }; MR.setVpiExtra((S.miete||{}).vpi||{}); } }catch(e){ console.error("v38 vpi", e); }
if(typeof einlesen==="function"){ var ei38=einlesen; einlesen=function(text){
  var z; try{ z=zerlegen(text); }catch(e){ return ei38.apply(this,arguments); }
  if(z[0]==="mieten"){ var b0=ei38.apply(this,arguments); try{ MR.setVpiExtra((S.miete||{}).vpi||{}); }catch(e){} return b0; }
  if(z[0]!=="mietvergleiche") return ei38.apply(this,arguments);
  var P=p38(); if(!P) return "⚠️ Vergleichsangebote lassen sich nur im MaklerCockpit einlesen.";
  if(!z[1].length) return "📥 Kein lesbarer Eintrag gefunden. Bitte den ganzen Block von JARVIS-IMPORT bis JARVIS-ENDE kopieren.";
  var b; try{ b=P.mp38Import(z[1]); }catch(e){ return "⚠️ Beim Einlesen ist etwas schiefgegangen: "+e.message; }
  if(z[2]) b+=" ⚠️ "+z[2]+" Stelle(n) waren nicht lesbar und fehlen.";
  S.letzteImporte=[{zeit:new Date().toISOString(),typ:"mietvergleiche",bericht:b}].concat(S.letzteImporte||[]).slice(0,15); speichern();
  return b;
}; }
"""
a = s.index('const JV_HTML = '); b = s.index('\n', a)
html = json.loads(s[a+len('const JV_HTML = '):b].rstrip(';'))
assert html.count('/* v37 Mietdaten */') == 1
k = html.rindex('</body>')
html = html[:k] + '<script>/* v38 Mietvergleiche */\n' + _JV38 + '\n</script>\n' + html[k:]
s = s[:a] + 'const JV_HTML = ' + json.dumps(html, ensure_ascii=False).replace('</', '<\\/') + ';' + s[b:]
