// ═══ MaklerCockpit v33 – Seitenleiste und Seiten springen nicht mehr nach oben ═══
// • Die Leiste links behält ihre Scroll-Position, wenn du einen Eintrag anklickst.
// • Jede Seite merkt sich, wie weit du gescrollt hast: zurück über die Leiste/Tabs → du landest wieder an derselben Stelle.
// • Klick auf die Seite, auf der du schon bist, lässt alles stehen.
const NAV33 = { pos: {}, klick: false };
function nav33Liste(){ return document.querySelector('#nav .sb-liste') || document.querySelector('.sb-liste'); }
function nav33Scroller(){ return document.getElementById('main'); }
const _nav33Nav = renderNav;
renderNav = function(){
  const l = nav33Liste(), st = l ? l.scrollTop : 0;
  const r = _nav33Nav.apply(this, arguments);
  const l2 = nav33Liste(); if(l2 && st && l2.scrollTop !== st) l2.scrollTop = st;
  return r;
};
document.addEventListener('click', ev => {
  const z = ev.target && ev.target.closest ? ev.target.closest('#nav [onclick*="wechsleAnsicht"], #h25Tabs [onclick], .sb-liste [onclick]') : null;
  if(z) NAV33.klick = true;
}, true);
const _nav33Wechsle = wechsleAnsicht;
wechsleAnsicht = function(key){
  const m = nav33Scroller(), von = aktuelleAnsicht, ausLeiste = NAV33.klick; NAV33.klick = false;
  const doc = document.scrollingElement;
  if(von){ NAV33.pos[von] = { m: m ? m.scrollTop : 0, d: doc ? doc.scrollTop : 0 }; }
  const r = _nav33Wechsle.apply(this, arguments);
  let ziel = { m: 0, d: 0 };
  if(key === von) ziel = NAV33.pos[key] || ziel;                       // gleiche Seite: stehen bleiben
  else if(ausLeiste && NAV33.pos[key]) ziel = NAV33.pos[key];          // zurück über die Leiste: alte Stelle
  const setzen = () => { const m2 = nav33Scroller(); if(m2) m2.scrollTop = ziel.m; if(doc) doc.scrollTop = ziel.d; };
  setzen(); requestAnimationFrame(setzen); setTimeout(setzen, 120);
  return r;
};
