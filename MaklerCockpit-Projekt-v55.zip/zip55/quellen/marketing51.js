// ═══ MaklerCockpit v51 – Marketing lädt wieder (Handy und PC) ═══
// Vorher: Das Marketing-Tool wurde als „blob:“-Adresse in den Rahmen geladen.
//  • Handy-App: Die App hat diese Adresse wie einen fremden Link behandelt und blockiert → weiße Fläche.
//  • PC: Der Rahmen lief ohne eigenen Speicher (Objekte/Fotos wurden nicht gespeichert) und die Reiter oben griffen nicht.
// Jetzt: Das Tool wird direkt eingebettet (wie Hausverwaltungen, Jarvis usw.) – gleicher Speicher, Reiter funktionieren.
function ma51Html(){
  if(ma51Html.c) return ma51Html.c;
  const bin = atob(MARKETING_HUB_HTML_B64), b = new Uint8Array(bin.length);
  for(let i = 0; i < bin.length; i++) b[i] = bin.charCodeAt(i);
  return (ma51Html.c = new TextDecoder('utf-8').decode(b));
}
marketingHubBlobUrl = function(){ return 'about:blank'; };
function ma51Pruefen(){
  clearTimeout(ma51Pruefen.t);
  ma51Pruefen.t = setTimeout(() => {
    try{
      if(aktuelleAnsicht !== 'marketing') return;
      const f = document.getElementById('marketingFrame'), d = f && f.contentDocument;
      const ok = d && d.body && d.body.children.length > 1 && f.contentWindow && f.contentWindow.__hub;
      const bar = document.getElementById('marketingBar'); if(!bar) return;
      const alt = document.getElementById('ma51Hinweis'); if(alt) alt.remove();
      if(!ok) bar.insertAdjacentHTML('beforeend', `<div id="ma51Hinweis" style="flex:1 0 100%;font-size:12px;color:#fbbf24;">Marketing lädt nicht richtig. <button class="secondary tiny" onclick="ma51NeuLaden()">↻ Neu laden</button></div>`);
    }catch(e){}
  }, 8000);
}
function ma51NeuLaden(){
  const f = document.getElementById('marketingFrame'); if(!f) return;
  window.__marketingHubReady = false;
  const h = document.getElementById('ma51Hinweis'); if(h) h.remove();
  f.srcdoc = ma51Html(); ma51Pruefen();
}
(function(){
  const _ms = stelleMarketingOverlaySicher;
  stelleMarketingOverlaySicher = function(){
    const neu = !document.getElementById('marketingOverlay');
    const r = _ms.apply(this, arguments);
    if(neu){
      const f = document.getElementById('marketingFrame');
      if(f){ f.removeAttribute('src'); f.srcdoc = ma51Html(); ma51Pruefen(); }
    }
    return r;
  };
})();
// Vorfüllen: Preis wie im Exposé schreiben („300.000“ statt „300000“), Zimmer aus dem Objekt
(function(){
  const _v = versucheMarketingPrefill;
  versucheMarketingPrefill = function(){
    const id = window.__marketingPrefillObjektId;
    const r = _v.apply(this, arguments);
    try{
      const f = document.getElementById('marketingFrame'), hub = f && f.contentWindow && f.contentWindow.__hub, o = id && findObjekt(id);
      if(!hub || !o || window.__marketingPrefillObjektId) return r;
      const d = hub.state.d; let neu = false;
      const p = String(d.preis || '').replace(/\s/g, '');
      if(/^\d{4,}$/.test(p)){ d.preis = Number(p).toLocaleString('de-DE'); neu = true; }
      if(!d.zimmer && o.zimmer){ d.zimmer = String(o.zimmer).replace('.', ','); neu = true; }
      if(neu){ hub.deriveData(); hub.fillForm(); if(typeof hub.fillHooks === 'function') hub.fillHooks(); }
    }catch(e){ console.error('ma51 prefill', e); }
    return r;
  };
})();
