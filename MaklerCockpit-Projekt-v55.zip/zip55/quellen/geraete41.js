// ═══ MaklerCockpit v41 – Tablet (Windows) im Hochformat und schmale Fenster: Seitenleiste nur mit Symbolen ═══
// Zwischen 761 und 1100 px Breite (z. B. Lenovo-Tablet hochkant) bekommt der Inhalt den Platz; die Namen stehen als Tooltip am Symbol.
(function(){
  const st = document.createElement('style');
  st.textContent = `@media (min-width:761px) and (max-width:1100px){
  #nav{width:68px!important;min-width:68px!important;flex:0 0 68px!important}
  #nav .sb-logo{justify-content:center;padding-left:0;padding-right:0}#nav .sb-logo b,#nav .sb-logo span{display:none}
  #nav .sb-item{justify-content:center;padding:12px 0;gap:0}#nav .sb-item>span{display:none}#nav .sb-kopf{font-size:0;height:1px;margin:8px 10px;background:var(--border);padding:0}
  #nav .sb-fuss{flex-direction:column;gap:8px;padding:10px 0;align-items:center}#nav .sb-fuss>div:not(.av){display:none}
  #nav #ab25Status{font-size:0;padding:8px 0;text-align:center}#nav #ab25Status .ab25-p{margin:0}
  .aq-kpis{grid-template-columns:repeat(2,minmax(0,1fr))!important}
}
@media (pointer:coarse) and (min-width:761px){ .sb-item{padding-top:12px;padding-bottom:12px} .tb-icon{min-width:40px;min-height:40px} }`;
  document.head.appendChild(st);
  const titel = () => { try{ document.querySelectorAll('#nav .sb-item').forEach(e => { const s = e.querySelector('span'); if(s && !e.title) e.title = s.textContent.trim(); }); }catch(e){} };
  const _r = renderNav;
  renderNav = function(){ const r = _r.apply(this, arguments); titel(); return r; };
  setTimeout(titel, 500);
})();
