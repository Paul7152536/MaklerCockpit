// ═══ MaklerCockpit v47 (Nachtrag) – Heute nur heute · Akquise-Pipeline · Name/Telefon aus Terminen überall ═══

// ── 1) „Heute“: nur Punkte von heute (und Überfälliges), morgen nur als kleine Zeile ──
function hu47Morgen(){ const m = gsTagPlus(mc24Heute(), 1); return (db.termine || []).filter(t => t.datum === m || (t.bisDatum && t.datum < m && t.bisDatum >= m)); }
(function(){
  if(typeof ak24Prioritaeten !== 'function') return;
  const _p = ak24Prioritaeten;
  ak24Prioritaeten = function(){
    const r = _p.apply(this, arguments), h = mc24Heute();
    const spaeter = r.liste.filter(x => x.datum && x.datum > h);
    r.liste = r.liste.filter(x => !(x.datum && x.datum > h));
    r.spaeter = spaeter.length;
    return r;
  };
  const _r = ak24Render;
  ak24Render = function(main){
    const r = _r.apply(this, arguments);
    try{
      const m = gsTagPlus(mc24Heute(), 1), n = hu47Morgen().length;
      const karte = Array.from(main.querySelectorAll('.mc24-karte')).find(k => /Termine heute/.test((k.querySelector('h3') || {}).textContent || ''));
      const zeile = `<div class="hu47-morgen" onclick="oeffneTagModal('${m}')" title="Termine von morgen ansehen">Morgen: ${n ? n + ' Termin' + (n === 1 ? '' : 'e') : 'keine Termine'}</div>`;
      if(karte) karte.insertAdjacentHTML('beforeend', zeile);
      else { const s = main.querySelector('.aq-kopf .sub'); if(s) s.insertAdjacentHTML('afterend', zeile); }
    }catch(e){ console.error('hu47', e); }
    return r;
  };
})();

// ── 2) Akquise-Pipeline: Neu → Angeschrieben → Termin → Nochmal anrufen ──
const PL47 = [
  { k: 'neu', l: 'Neu', ic: '🆕', st: ['neu', ''] },
  { k: 'angeschrieben', l: 'Angeschrieben', ic: '✉️', st: ['email_geschrieben', 'kleinanzeigen_geschrieben', 'erstkontakt'] },
  { k: 'termin', l: 'Termin', ic: '📅', st: ['termin', 'telefontermin'] },
  { k: 'anrufen', l: 'Nochmal anrufen', ic: '📞', st: ['nicht_erreicht', 'nochmal_anrufen'] }
];
const PL47F = { ob: '' };
function pl47Stufe(o){
  const s = (o && o.status) || '';
  for(const p of PL47) if(p.st.includes(s)) return p.k;
  return ['auftrag', 'online', 'abgeschlossen'].includes(s) ? 'auftrag' : '';
}
function pl47Leads(){ return (db.objekte || []).filter(o => typeof ob26Bereich !== 'function' || ob26Bereich(o) === 'akquise' || ['auftrag', 'online', 'abgeschlossen'].includes(o.status)); }
function pl47Zahlen(){
  const z = { neu: 0, angeschrieben: 0, termin: 0, anrufen: 0, auftrag: 0, tel: 0 };
  for(const o of pl47Leads()){ const s = pl47Stufe(o); if(s) z[s]++; if(['neu', 'angeschrieben', 'anrufen'].includes(s) && aqTel(o)) z.tel++; }
  return z;
}
function pl47Aktiv(wo){ return wo === 'ob' ? PL47F.ob : (/^p:/.test(AQ2.status || '') ? AQ2.status.slice(2) : ''); }
function pl47LeisteHtml(wo){
  const z = pl47Zahlen(), akt = pl47Aktiv(wo);
  const kachel = (p, i) => `${i ? '<div class="pl47-pfeil">›</div>' : ''}<button class="pl47-st pl47-${p.k} ${akt === p.k ? 'an' : ''}" onclick="pl47Filter('${wo}','${p.k}')"><span class="pl47-ic">${p.ic}</span><span class="pl47-n">${z[p.k]}</span><span class="pl47-l">${p.l}</span></button>`;
  const extra = wo === 'aq'
    ? `<button class="pl47-mini ${AQ2.status === 'offen' ? 'an' : ''}" onclick="AQ2.status='offen';renderAkquise(document.getElementById('main'))">Alle offenen</button><button class="pl47-mini ${AQ2.status === 'mit_tel' ? 'an' : ''}" onclick="AQ2.status='mit_tel';renderAkquise(document.getElementById('main'))">📞 Mit Telefon (${z.tel})</button><button class="pl47-mini ${AQ2.status === 'termine' ? 'an' : ''}" onclick="AQ2.status='termine';renderAkquise(document.getElementById('main'))">✔ Aufträge (${z.auftrag})</button>`
    : `${akt ? `<button class="pl47-mini" onclick="pl47Filter('ob','${akt}')">✕ Pipeline-Filter aus</button>` : ''}`;
  return `<div class="pl47"><div class="pl47-reihe">${PL47.map(kachel).join('')}</div><div class="pl47-extra">${extra}</div></div>`;
}
function pl47Filter(wo, k){
  if(wo === 'ob'){
    PL47F.ob = PL47F.ob === k ? '' : k;
    if(PL47F.ob && typeof X20 !== 'undefined'){ X20.objFilter = 'alle'; }
    renderMain(); return;
  }
  AQ2.status = AQ2.status === 'p:' + k ? 'offen' : 'p:' + k;
  renderAkquise(document.getElementById('main'));
}
function pl47Setzen(k){
  const o = findObjekt(AQ2.sel); if(!o || pl47Stufe(o) === k) return;
  if(k === 'neu') aq2StatusSetzen('neu');
  else if(k === 'angeschrieben') aq2StatusSetzen(/kleinanzeigen/i.test((o.quelle || '') + ' ' + (o.link || '')) ? 'kleinanzeigen_geschrieben' : 'email_geschrieben');
  else if(k === 'anrufen') aq2StatusSetzen('nochmal_anrufen');
  else if(k === 'termin'){
    const h = mc24Heute();
    if((db.termine || []).some(t => t.objektId === o.id && t.datum >= h)) aq2StatusSetzen('termin');
    else aq2TerminNeu('akquise');
  }
}
function pl47SchritteHtml(o){
  const akt = pl47Stufe(o);
  if(akt === 'auftrag') return `<div class="pl47-schritte"><span class="pl47-fertig">✔ Auftrag – aus der Akquise-Pipeline raus</span></div>`;
  return `<div class="pl47-schritte">${PL47.map((p, i) => `${i ? '<span class="pl47-p">›</span>' : ''}<button class="pl47-sch ${akt === p.k ? 'an' : ''}" title="In „${p.l}“ verschieben" onclick="pl47Setzen('${p.k}')">${p.ic} ${p.l}</button>`).join('')}</div>`;
}
(function(){
  if(typeof aqGefiltert === 'function'){
    const _g = aqGefiltert;
    aqGefiltert = function(){
      const st = AQ2.status;
      if(!/^p:/.test(st || '')) return _g.apply(this, arguments);
      AQ2.status = 'alle';
      try{ return _g.apply(this, arguments).filter(o => pl47Stufe(o) === st.slice(2)); } finally { AQ2.status = st; }
    };
  }
  if(typeof aq2Kpis === 'function') aq2Kpis = function(){ return pl47LeisteHtml('aq'); };
  if(typeof renderAkquise === 'function'){
    const _ra = renderAkquise;
    renderAkquise = function(main){
      const r = _ra.apply(this, arguments);
      try{
        const sel = main.querySelector('.aq-filter select');
        if(sel){
          sel.insertAdjacentHTML('afterbegin', `<optgroup label="Pipeline">${PL47.map(p => `<option value="p:${p.k}" ${AQ2.status === 'p:' + p.k ? 'selected' : ''}>${p.ic} ${p.l}</option>`).join('')}</optgroup>`);
          if(/^p:/.test(AQ2.status || '')) sel.value = AQ2.status;
        }
      }catch(e){ console.error('pl47 select', e); }
      return r;
    };
  }
  if(typeof aq2Detail === 'function'){
    const _d = aq2Detail;
    aq2Detail = function(){
      const r = _d.apply(this, arguments);
      try{ const o = findObjekt(AQ2.sel), dp = document.querySelector('#aqDetail .dp'); if(o && dp && !dp.querySelector('.pl47-schritte')) dp.insertAdjacentHTML('afterbegin', pl47SchritteHtml(o)); }catch(e){ console.error('pl47 detail', e); }
      return r;
    };
  }
  // Objekte-Seite (Akquise-Objekte): gleiche Pipeline oben, doppeltes „📅 Termin“-Abzeichen weg
  if(typeof objSichtbar === 'function'){
    const _s = objSichtbar;
    objSichtbar = function(o){
      if(PL47F.ob && typeof OB26 !== 'undefined' && OB26.aktiv === 'akquise') return ob26Bereich(o) === 'akquise' && pl47Stufe(o) === PL47F.ob;
      return _s.apply(this, arguments);
    };
  }
  if(typeof renderObjekte === 'function'){
    const _ro = renderObjekte;
    renderObjekte = function(main){
      const r = _ro.apply(this, arguments);
      try{
        if(typeof OB26 !== 'undefined' && OB26.aktiv === 'akquise'){
          const f = main.querySelector('.ob26-felder');
          if(f && !main.querySelector('.pl47')) f.insertAdjacentHTML('afterend', pl47LeisteHtml('ob'));
          if(PL47F.ob){ const ft = document.getElementById('objFilterTermin'); if(ft) ft.value = 'alle'; }
        }
      }catch(e){ console.error('pl47 objekte', e); }
      return r;
    };
  }
  if(typeof renderObjekteTabelle === 'function'){
    const _rt = renderObjekteTabelle;
    renderObjekteTabelle = function(){
      const r = _rt.apply(this, arguments);
      try{
        const el = document.getElementById('objTabelle'); if(!el) return r;
        el.querySelectorAll('.badge').forEach(b => { if(b.textContent.trim() === '📅 Termin') b.remove(); });
        if(PL47F.ob) el.querySelectorAll('.obj-filter-hinweis').forEach(x => x.remove());
      }catch(e){}
      return r;
    };
  }
})();

// ── 3) Name und Telefon aus Terminen überall übernehmen ──
const VB47_TEL = /(?:\+49|0049|\b0)\s?[1-9][\d \/\-()]{5,22}\d/g;
const VB47_NAME = /(?:^|[\n;,|·]|\s)(?:kontakt|name|eigent[üu]mer(?:in)?|ansprechpartner(?:in)?|verk[äa]ufer(?:in)?)\s*:\s*([^\n,;|·]{2,50})/i;
function vb47Tels(text){
  const out = [];
  String(text || '').replace(VB47_TEL, m => {
    const teile = m.trim().split(/\s+/);
    for(let i = teile.length; i > 0; i--){
      const c = teile.slice(0, i).join(' ').replace(/[\s\/\-(]+$/, ''), d = vb25Tel(c);
      if(d.length >= 9 && d.length <= 13){ if(!out.some(x => vb25Tel(x) === d)) out.push(c); break; }
    }
    return m;
  });
  return out;
}
function vb47Name(text){
  const m = String(text || '').match(VB47_NAME); if(!m) return '';
  let n = m[1].replace(VB47_TEL, '').replace(/\b(tel(efon)?|handy|mobil|mail|e-mail)\b.*$/i, '').replace(/[\s:.\-–]+$/, '').trim();
  if(!n || /\d|@/.test(n) || n.length > 40 || vb25Platzhalter(n)) return '';
  return n;
}
function vb47Text(t){ return [t.titel, t.ort, t.notiz].filter(Boolean).join('\n'); }
function vb47AdrNorm(s){ return akqNorm(String(s || '').replace(/stra(ss|ß)e\b/gi, 'str').replace(/str\./gi, 'str')); }
function vb47ObjektZuTermin(t, tels){
  const l = db.objekte || [];
  if(tels.length){
    const k = l.filter(x => { const xt = vb25Tel(aqTel(x)); return xt && tels.some(tt => vb25Tel(tt) === xt); });
    if(k.length === 1) return k[0];
  }
  const txt = ' ' + vb47AdrNorm(vb47Text(t)) + ' ';
  const k = l.filter(x => /\d/.test(x.adresse || '') && vb47AdrNorm(x.adresse).length >= 6 && txt.includes(' ' + vb47AdrNorm(x.adresse) + ' '));
  return k.length === 1 ? k[0] : null;
}
function vb47TelFremd(tel, o){ const d = vb25Tel(tel); return (db.objekte || []).some(x => x !== o && vb25Tel(aqTel(x)) === d); }
function vb47Abgleichen(){
  if(!db || !Array.isArray(db.termine) || !Array.isArray(db.objekte)) return 0;
  let n = 0;
  for(const t of db.termine){
    if(t.anrufliste) continue;
    const text = vb47Text(t), tels = vb47Tels(text);
    let o = t.objektId ? findObjekt(t.objektId) : null;
    const fest = !!o;   // v49: von Paul verknüpft → Nummer aus dem Termin gilt, auch wenn derselbe Verkäufer weitere Inserate hat
    if(!o && !t.objektId && !t.vb47Geprueft){
      o = vb47ObjektZuTermin(t, tels);
      t.vb47Geprueft = true;
      if(o){ t.objektId = o.id; n++; try{ aqLog(o, 'termin', '📅 Kalendertermin zugeordnet: ' + (t.titel || '') + ' (' + t.datum + ')'); }catch(e){} }
    }
    if(!o) continue;
    if(!t.kontaktId && o.eigentuemerId){ t.kontaktId = o.eigentuemerId; n++; }
    const tk = t.kontaktId ? findKontakt(t.kontaktId) : null;
    if(!aqTel(o)){
      const neu = (tk && tk.telefon) || (fest ? tels[0] : tels.find(x => !vb47TelFremd(x, o))) || '';
      if(neu){ o.verkaeuferTelefon = neu; n++; try{ aqLog(o, 'info', '📞 Telefonnummer aus dem Termin übernommen: ' + neu); }catch(e){} }
    }
    if(!aqName(o)){
      const nm = (tk && !vb25Platzhalter(tk.name) ? tk.name : '') || vb47Name(text);
      if(nm){ o.verkaeuferName = nm; n++; try{ aqLog(o, 'info', '👤 Name aus dem Termin übernommen: ' + nm); }catch(e){} }
    }
    if(tk && o.eigentuemerId !== tk.id){                         // Termin-Kontakt ohne Nummer → vom Objekt ergänzen
      if(!tk.telefon && aqTel(o) && aqName(o) && vb25S(tk.name) === aqName(o)){ tk.telefon = aqTel(o); n++; }
    }
  }
  return n;
}
function vb47Wer(t){
  const o = t && t.objektId ? findObjekt(t.objektId) : null, k = t && t.kontaktId ? findKontakt(t.kontaktId) : null;
  const name = (o ? aqName(o) : '') || (k && !vb25Platzhalter(k.name) ? k.name : '');
  const tel = (o ? aqTel(o) : '') || (k && k.telefon) || '';
  return { o, k, name, tel };
}
(function(){
  if(typeof _schreibe === 'function'){
    const _s = _schreibe;
    _schreibe = function(){ try{ vb47Abgleichen(); }catch(e){ console.error('vb47', e); } return _s.apply(this, arguments); };
  }
  window.addEventListener('load', () => { setTimeout(() => { try{ if(vb47Abgleichen()){ save(); renderMain(); } }catch(e){ console.error('vb47 start', e); } }, 300); });
  // Terminzeilen: Eigentümer und Telefon gleich mit anzeigen
  if(typeof gsTerminZeile === 'function'){
    const _z = gsTerminZeile;
    gsTerminZeile = function(t){
      const html = _z.apply(this, arguments);
      try{
        const w = vb47Wer(t); if(!w.name && !w.tel) return html;
        const roh = [t.titel, t.ort].join(' ');
        if(w.tel && vb47Tels(roh).some(x => vb25Tel(x) === vb25Tel(w.tel)) && (!w.name || roh.includes(w.name))) return html;
        const d = document.createElement('div'); d.innerHTML = html;
        const was = d.querySelector('.tm-was'); if(!was) return html;
        was.insertAdjacentHTML('beforeend', `<div class="tm-unter vb47-wer">👤 ${akqEsc(w.name || 'Eigentümer')}${w.tel ? ' · 📞 ' + akqEsc(w.tel) : ''}</div>`);
        return d.innerHTML;
      }catch(e){ return html; }
    };
  }
  // Termin-Dialog: Eigentümer-Name und Telefon direkt eintragen → landen im Objekt und Kontakt
  if(typeof oeffneTerminModal === 'function'){
    const _m = oeffneTerminModal;
    oeffneTerminModal = function(id){
      const r = _m.apply(this, arguments);
      try{
        const t = id ? (db.termine || []).find(x => x.id === id) : null;
        const sel = document.getElementById('m_t_objekt'), notiz = document.getElementById('m_t_notiz');
        if(sel && notiz && !document.getElementById('m_t_vbtel')){
          const w = vb47Wer(t || { objektId: sel.value, kontaktId: (document.getElementById('m_t_kontakt') || {}).value });
          notiz.previousElementSibling.insertAdjacentHTML('beforebegin', `<div class="field-row vb47-felder"><div><label>Eigentümer (Name)</label><input id="m_t_vbname" value="${akqEsc(w.name)}" placeholder="wird ins Objekt übernommen"></div><div><label>Telefon</label><input id="m_t_vbtel" type="tel" value="${akqEsc(w.tel)}" placeholder="z. B. 0151 …"></div></div>`);
          const neu = () => {
            const w2 = vb47Wer({ objektId: sel.value, kontaktId: (document.getElementById('m_t_kontakt') || {}).value });
            const fn = document.getElementById('m_t_vbname'), ft = document.getElementById('m_t_vbtel');
            if(fn && !fn.dataset.geaendert) fn.value = w2.name; if(ft && !ft.dataset.geaendert) ft.value = w2.tel;
          };
          sel.addEventListener('change', neu); const kk = document.getElementById('m_t_kontakt'); if(kk) kk.addEventListener('change', neu);
          ['m_t_vbname', 'm_t_vbtel'].forEach(x => document.getElementById(x).addEventListener('input', e => { e.target.dataset.geaendert = '1'; }));
        }
      }catch(e){ console.error('vb47 modal', e); }
      return r;
    };
  }
  if(typeof speichereTermin === 'function'){
    const _sp = speichereTermin;
    speichereTermin = function(id){
      const g = x => document.getElementById(x);
      const name = g('m_t_vbname') ? g('m_t_vbname').value.trim() : null, tel = g('m_t_vbtel') ? g('m_t_vbtel').value.trim() : null;
      const oid = g('m_t_objekt') ? g('m_t_objekt').value : '', kid = g('m_t_kontakt') ? g('m_t_kontakt').value : '';
      const r = _sp.apply(this, arguments);
      try{
        if(name === null && tel === null) return r;
        const o = oid ? findObjekt(oid) : null, k = kid ? findKontakt(kid) : null;
        let n = 0;
        if(o){
          if(tel && !vb25Gleich('t', tel, aqTel(o))){ o.verkaeuferTelefon = tel; const ek = aqKontakt(o); if(ek) vb25KontaktSetzen(ek, 't', tel, aqTitel(o)); aqLog(o, 'info', '📞 Telefon im Termin eingetragen: ' + tel); n++; }
          if(name && name !== aqName(o)){ o.verkaeuferName = name; const ek = aqKontakt(o); if(ek) vb25KontaktSetzen(ek, 'n', name); aqLog(o, 'info', '👤 Name im Termin eingetragen: ' + name); n++; }
        } else if(k){
          if(tel && !vb25Gleich('t', tel, k.telefon)){ vb25KontaktSetzen(k, 't', tel, 'Termin'); n++; }
          if(name && name !== k.name && vb25Platzhalter(k.name)){ vb25KontaktSetzen(k, 'n', name); n++; }
        }
        if(n){ save(); try{ renderMain(); }catch(e){} }
      }catch(e){ console.error('vb47 speichern', e); }
      return r;
    };
  }
})();

(function(){
  const css = document.createElement('style');
  css.textContent = `
.hu47-morgen{margin-top:10px;font-size:11px;color:var(--muted);cursor:pointer;opacity:.8}
.hu47-morgen:hover{opacity:1;text-decoration:underline}
#aqKpis{display:block!important;grid-template-columns:none!important}
.pl47{margin:0 0 12px;width:100%}
.pl47 button{min-height:0;width:auto;box-shadow:none}
.pl47-reihe{display:flex;align-items:stretch;gap:4px}
.pl47-pfeil{display:flex;align-items:center;color:var(--muted);font-size:20px;padding:0 2px}
.pl47 .pl47-st{flex:1;width:auto;display:flex;flex-direction:column;align-items:center;gap:2px;padding:10px 6px;border-radius:12px;border:1px solid var(--border);background:var(--bg2,rgba(255,255,255,.03));color:inherit;cursor:pointer;min-width:0}
.pl47-st:hover{border-color:var(--accent,#f97316)}
.pl47-st.an{border-color:var(--accent,#f97316);box-shadow:0 0 0 2px rgba(249,115,22,.25)}
.pl47-ic{font-size:18px}.pl47-n{font-size:22px;font-weight:700;line-height:1.1}.pl47-l{font-size:11px;color:var(--muted);text-align:center;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:100%}
.pl47-neu .pl47-n{color:#34d399}.pl47-angeschrieben .pl47-n{color:#c4b5fd}.pl47-termin .pl47-n{color:#22c55e}.pl47-anrufen .pl47-n{color:#fb923c}
.pl47-extra{display:flex;gap:6px;flex-wrap:wrap;margin-top:6px}
.pl47 .pl47-mini{font-size:11px;padding:3px 10px;line-height:1.4;border-radius:999px;border:1px solid var(--border);background:transparent;color:var(--muted);cursor:pointer}
.pl47-mini.an{color:inherit;border-color:var(--accent,#f97316)}
.pl47-schritte{display:flex;align-items:center;gap:3px;flex-wrap:wrap;margin:0 0 10px}
.pl47-schritte .pl47-sch{min-height:0;width:auto;font-size:11px;padding:4px 8px;border-radius:999px;border:1px solid var(--border);background:transparent;color:var(--muted);cursor:pointer}
.pl47-sch.an{background:var(--accent,#f97316);border-color:var(--accent,#f97316);color:#fff;font-weight:600}
.pl47-p{color:var(--muted);font-size:12px}.pl47-fertig{font-size:12px;color:#60a5fa}
.vb47-wer{color:var(--muted)}
@media (max-width:700px){.pl47-pfeil{display:none}.pl47-st{padding:8px 3px}.pl47-n{font-size:18px}.pl47-l{font-size:10px;white-space:normal}}
`;
  document.head.appendChild(css);
})();
