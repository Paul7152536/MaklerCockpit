# v52: Hausverwaltungen – Bild an das Anschreiben hängen + Call-Hilfe mit **fett** sauber darstellen
# wird von akq_patch.py per exec() nach hv46_block.py ausgeführt; bearbeitet HV_HTML in s
import json as _j52
_a = s.index('const HV_HTML = '); _b = s.index('\n', _a)
_hv = _j52.loads(s[_a + len('const HV_HTML = '):_b].rstrip(';').replace('<\\/', '</'))
def hv52(a, b):
    global _hv
    assert _hv.count(a) == 1, ('hv52', a[:80], _hv.count(a)); _hv = _hv.replace(a, b)

# 1) Call-Hilfe: **Überschrift** / **Überschrift:** / ### als Kopf, **fett** im Text
hv52("""  const kapitel = bloecke.map((b,i)=>[b,i]).filter(([b])=>/^##\\s/.test(b)||/^(Einstieg|Abschluss)$/i.test(b));""",
     """  const kapitel = bloecke.map((b,i)=>[b,i]).filter(([b])=>/^#{1,4}\\s/.test(b)||/^(Einstieg|Abschluss)$/i.test(b)||hv52Kopf(b.split('\\n')[0])).map(([b,i])=>[hv52Kopf(b.split('\\n')[0]) ? '## ' + hv52Kopf(b.split('\\n')[0]) : b, i]);""")
hv52("""function formatiereHilfe(text){""", r"""function hv52Kopf(z){
  const t = String(z || '').trim();
  let m = t.match(/^\*\*([^*]+?)\*\*\s*:?\s*$/) || t.match(/^\*\*([^*]+?):\s*$/) || t.match(/^#{1,4}\s+(.+)$/);
  return m ? m[1].replace(/\*\*/g, '').replace(/:\s*$/, '').trim() : '';
}
function hv52Fett(t){ return esc(t).replace(/\*\*([^*]+?)\*\*/g, '<b>$1</b>').replace(/\*\*/g, ''); }
function formatiereHilfe(text){
  let n = 0;
  return hilfeAbschnitte(text).map((block, i) => {
    const zeilen = block.split('\n'); let html = '', rest = [];
    const flush = () => { if(!rest.length) return; html += hv52Alt(rest.join('\n'), n++ === 0 ? i : null); rest = []; };
    zeilen.forEach(z => { const k = hv52Kopf(z); if(k){ flush(); html += `<div ${n++ === 0 ? `id="hb_${i}" ` : ''}class="h-kopf">${esc(k)}</div>`; } else rest.push(z); });
    flush(); n = 0; return html;
  }).join("");
}
function hv52Alt(b, i){
  const id = i == null ? '' : `id="hb_${i}"`;
  if(/^(Einstieg|Abschluss)$/i.test(b)) return `<div ${id} class="h-kopf">${esc(b)}</div>`;
  if(/^(→\s*)?(Wenn|Bei)\b/.test(b) && b.length<110 && !/^[„"“]/.test(b)) return `<div ${id} class="h-wenn">${hv52Fett(b.replace(/^→\s*/,''))}</div>`;
  if(/^💡/.test(b)) return `<div ${id} class="h-note">${hv52Fett(b)}</div>`;
  if(/^[„"“]/.test(b)) return `<div ${id} class="h-satz">${hv52Fett(b)}</div>`;
  return `<div ${id} class="h-satz h-fort">${hv52Fett(b)}</div>`;
}
function formatiereHilfeAlt(text){""")

# 2) Mail: mit Bild über das Programm (Outlook-Entwurf / Handy-Mail-App), sonst wie bisher mailto
hv52("""  const url = 'mailto:' + encodeURIComponent(mail).replace(/%40/g, '@') + '?subject=' + encodeURIComponent(m.betreff) + '&body=' + encodeURIComponent(m.text.replace(/\\r?\\n/g, '\\r\\n'));
  try{ (window.parent && window.parent !== window ? window.parent : window).open(url, '_blank'); }catch(e){ location.href = url; }""",
     """  const url = 'mailto:' + encodeURIComponent(mail).replace(/%40/g, '@') + '?subject=' + encodeURIComponent(m.betreff) + '&body=' + encodeURIComponent(m.text.replace(/\\r?\\n/g, '\\r\\n'));
  const P = window.parent && window.parent !== window ? window.parent : null;
  if(db.mailBild && db.mailBild.b64 && P && typeof P.hv52Senden === 'function'){ P.hv52Senden({ an: mail, betreff: m.betreff, text: m.text, bild: db.mailBild, mailto: url }); }
  else { try{ (P || window).open(url, '_blank'); }catch(e){ location.href = url; } }""")
hv52("""      <a href="#" onclick="hv46Vorlage('${id}');return false;">Vorlage bearbeiten</a>""",
     """      <a href="#" onclick="hv46Vorlage('${id}');return false;">Vorlage bearbeiten</a>${db.mailBild && db.mailBild.b64 ? `<span class="hv52-bild" title="Wird als Anhang mitgeschickt">📎 ${esc(db.mailBild.name || 'Bild')}</span>` : `<a href="#" onclick="hv46Vorlage('${id}');return false;">📎 Bild anhängen</a>`}""")

# 3) Vorlage-Dialog: Bild auswählen / entfernen
hv52("""    <textarea id="hv46Text" style="min-height:300px;width:100%;">${esc(db.mailVorlage || HV46_STANDARD)}</textarea>""",
     """    <textarea id="hv46Text" style="min-height:300px;width:100%;">${esc(db.mailVorlage || HV46_STANDARD)}</textarea>
    <div class="hv52-box"><b>📎 Bild als Anhang</b> <span style="font-size:12px;color:var(--muted);">(z. B. Übersicht oder Visitenkarte – wird bei jeder Mail mitgeschickt)</span>
      <div id="hv52Vorschau">${hv52VorschauHtml()}</div>
      <label class="hv52-wahl"><input type="file" accept="image/jpeg,image/png" onchange="hv52BildGewaehlt(this)" style="display:none">🖼 Bild auswählen</label>
      ${db.mailBild && db.mailBild.b64 ? `<button class="secondary tiny" onclick="delete db.mailBild;save();hv46Vorlage(${id ? `'${id}'` : ''})">Bild entfernen</button>` : ''}</div>""")
hv52("""function hv46Vorlage(id){""", r"""function hv52VorschauHtml(){
  const b = db.mailBild;
  return b && b.b64 ? `<img src="data:${b.typ || 'image/jpeg'};base64,${b.b64}" style="max-width:220px;max-height:160px;border-radius:8px;margin:6px 0;display:block;"><div style="font-size:12px;color:var(--muted);">${esc(b.name || 'Bild')} · ${Math.round(b.b64.length * 0.75 / 1024)} KB</div>` : '<div style="font-size:12px;color:var(--muted);margin:6px 0;">Noch kein Bild – die Mail geht ohne Anhang.</div>';
}
function hv52BildGewaehlt(inp){
  const f = inp.files && inp.files[0]; if(!f) return;
  if(!/^image\/(jpeg|png)$/.test(f.type)){ alert('Bitte ein JPG- oder PNG-Bild wählen.'); return; }
  const r = new FileReader();
  r.onload = () => {
    const img = new Image();
    img.onload = () => {
      const max = 1600, k = Math.min(1, max / Math.max(img.width, img.height));
      const c = document.createElement('canvas'); c.width = Math.round(img.width * k); c.height = Math.round(img.height * k);
      const x = c.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height); x.drawImage(img, 0, 0, c.width, c.height);
      const url = c.toDataURL('image/jpeg', 0.85);
      db.mailBild = { name: f.name.replace(/\.(jpe?g|png)$/i, '') + '.jpg', typ: 'image/jpeg', b64: url.split(',')[1], am: Date.now() };
      save(); const v = document.getElementById('hv52Vorschau'); if(v) v.innerHTML = hv52VorschauHtml();
    };
    img.onerror = () => alert('Das Bild konnte nicht gelesen werden.');
    img.src = r.result;
  };
  r.readAsDataURL(f);
}
function hv46Vorlage(id){""")

_k = _hv.index('</head>')
_hv = _hv[:_k] + """<style>.hv52-bild{font-size:12px;color:var(--green)}.hv52-box{margin-top:10px;padding:10px;border:1px dashed var(--border);border-radius:10px}
.hv52-wahl{display:inline-block;margin:6px 8px 0 0;padding:6px 12px;border:1px solid var(--border);border-radius:8px;cursor:pointer;font-size:13px}
.text b{color:var(--text,#e6edf7)}</style>""" + _hv[_k:]
s = s[:_a] + 'const HV_HTML = ' + _j52.dumps(_hv, ensure_ascii=False).replace('</', '<\\/') + ';' + s[_b:]
