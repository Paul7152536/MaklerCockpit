// ═══ MaklerCockpit v34 – Durchsicht: doppelte Kennungen, beschädigte Datendatei, Speichern ═══
// 1) Doppelte Kennungen (ids) reparieren. Früher konnten bei Importen (viele Leads/Gesuche in derselben Millisekunde)
//    zwei Einträge dieselbe id bekommen. Folge: Bearbeiten traf den falschen Eintrag, und der Abgleich mit dem Handy
//    konnte Leads verlieren. Die Reparatur ist auf PC und Handy gleich (deterministisch), Verweise bleiben beim ersten Eintrag.
function mc34IdsPruefen(){
  if(!window.AB25K || typeof AB25K.idsReparieren !== 'function' || !db) return 0;
  const log = [];
  let n = 0;
  try{ n = AB25K.idsReparieren(db, log); }catch(e){ console.error('mc34 ids', e); return 0; }
  if(n) console.warn('MaklerCockpit: doppelte Kennungen repariert', log);
  return n;
}
// 2) Hinweis, wenn die Datendatei beschädigt war und eine Sicherung geladen wurde (PC)
function mc34LadeHinweis(){
  let h = null;
  try{ h = window.pc && typeof window.pc.ladeHinweis === 'function' ? window.pc.ladeHinweis() : null; }catch(e){}
  if(!h || !(h.sicherung || h.kopie)) return;
  const tag = /(\d{4})-(\d{2})-(\d{2})/.exec(h.sicherung || '');
  const wann = tag ? `${tag[3]}.${tag[2]}.${tag[1]}` : (h.sicherung || '');
  // Abgleich: der Stand aus der Sicherung ist ÄLTER als der Abgleich-Speicher → beim nächsten Abgleich alles neu holen
  // (sonst würde die alte Sicherung neuere Änderungen auf dem Handy überschreiben)
  let abgleich = false;
  try{ if(typeof ab25Aktiv === 'function' && ab25Aktiv()){ const st = ab25Stand(); st.basis = {}; st.lokalSeit = {}; st.seit = 0; ab25StandSpeichern(); abgleich = true; } }catch(e){}
  setTimeout(() => {
    try{
      mc24Modal(`<h3>⚠️ Datendatei war beschädigt</h3>
        <p>Die Datei <b>daten.json</b> ließ sich nicht lesen. ${wann ? `Geladen wurde deshalb die <b>Sicherung vom ${mc24E(wann)}</b>.` : 'Es wurde <b>keine lesbare Sicherung</b> gefunden – bitte nichts eingeben, sondern zuerst über ⚙ die Cloud-Sicherung zurückholen oder mich (Claude) fragen.'}</p>
        <p class="mc24-muted">Änderungen nach dieser Sicherung fehlen evtl. Die beschädigte Datei wurde nicht gelöscht, sondern als <code>${mc24E(h.kopie || 'beschaedigt-….json')}</code> im Ordner „backups“ aufbewahrt.${abgleich ? ' Neuere Änderungen holt der Handy-Abgleich gleich automatisch zurück.' : ''}</p>
        <div class="modal-actions"><button class="secondary" onclick="schliesseModal(); datenOrdnerOeffnen()">Datenordner öffnen</button><div class="right"><button onclick="schliesseModal()">Verstanden</button></div></div>`, 520);
    }catch(e){ alert('Die Datendatei war beschädigt' + (wann ? ' – geladen wurde die Sicherung vom ' + wann + '.' : '.')); }
  }, 900);
}
window.addEventListener('load', () => {
  // läuft nach startLokal (dort wird db geladen)
  const n = mc34IdsPruefen();
  if(n){
    try{ _schreibe(); }catch(e){}
    try{ renderNav(); renderMain(); }catch(e){}
    setTimeout(() => { try{ akqToast(`🔧 ${n} doppelte Kennung${n === 1 ? '' : 'en'} repariert (z. B. aus einem Import) – es ging nichts verloren`, 6000); }catch(e){} }, 1500);
  }
  mc34LadeHinweis();
});
