// ═══ MaklerCockpit v36 – Alle KI-Prompts verlangen das Ergebnis als Kopierblock ═══
// An jeden Prompt, den das Cockpit für Claude/ChatGPT erzeugt, kommt ein kurzer Absatz: Ergebnis vollständig in EINEM Codeblock,
// damit Paul es mit einem Klick kopieren und ins Cockpit einfügen kann. Vorgegebene Formate (JSON, JARVIS-IMPORT …) bleiben gültig.
const MC36_KOPIER_HINWEIS = '\n\n---\nAUSGABE ZUM KOPIEREN: Ich will das Ergebnis kopieren und ins MaklerCockpit übernehmen. Gib es deshalb am Ende vollständig in einem Codeblock aus (zwischen ``` und ```). Ist oben ein bestimmtes Format verlangt (z. B. JSON, Liste oder JARVIS-IMPORT … JARVIS-ENDE), genau dieses Format im Codeblock verwenden. Erklärungen und Hinweise bitte außerhalb des Codeblocks.';
function mc36Kopierbar(t){ return (typeof t === 'string' && t.trim() && t.indexOf('AUSGABE ZUM KOPIEREN') < 0) ? t.replace(/\s+$/, '') + MC36_KOPIER_HINWEIS : t; }
(function(){
  const huelle = name => { try{ const f = window[name]; if(typeof f !== 'function') return; window[name] = function(){ return mc36Kopierbar(f.apply(this, arguments)); }; }catch(e){ console.error('kopier36', name, e); } };
  // Funktionsdeklarationen sind globale Bindungen – Ersetzen wirkt auch für onclick="…"
  ma24Prompt = (f => function(){ return mc36Kopierbar(f.apply(this, arguments)); })(ma24Prompt);
  skKiPrompt = (f => function(){ return mc36Kopierbar(f.apply(this, arguments)); })(skKiPrompt);
  baueUmgebungsPrompt = (f => function(){ return mc36Kopierbar(f.apply(this, arguments)); })(baueUmgebungsPrompt);
  ak24KiPrompt = (f => function(){ return mc36Kopierbar(f.apply(this, arguments)); })(ak24KiPrompt);
  ak24EinwandPrompt = (f => function(){ return mc36Kopierbar(f.apply(this, arguments)); })(ak24EinwandPrompt);
  hvRecherchePrompt = (f => function(){ return mc36Kopierbar(f.apply(this, arguments)); })(hvRecherchePrompt);
  // Akquise-/Gesuche-Prompts (Liste AKQ_PROMPTS)
  try{ (AKQ_PROMPTS || []).forEach(p => { if(p && typeof p.prompt === 'function' && !p.prompt.__mc36){ const f = p.prompt; p.prompt = function(){ return mc36Kopierbar(f.apply(this, arguments)); }; p.prompt.__mc36 = true; } }); }catch(e){ console.error('kopier36 akq', e); }
  void huelle;
})();
