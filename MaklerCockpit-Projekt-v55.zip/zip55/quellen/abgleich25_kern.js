// ═══ MaklerCockpit v25 – Abgleich PC ↔ Handy: Rechenkern (ohne Oberfläche, in Node testbar) ═══
// Zerlegt die Daten in Einträge (Sammlung + id), erkennt lokale Änderungen gegenüber dem letzten gemeinsamen Stand (Basis)
// und führt gleichzeitige Änderungen feldweise zusammen. Nichts wird still verworfen: Widersprüche landen im Protokoll.
(function(root){
'use strict';
// Gerätebezogen – wird nie abgeglichen
const AB25_NUR_LOKAL = new Set(['googleSync', 'sicherung', 'ab25Lokal']);
const AB25_NUR_LOKAL_UNTER = new Set(['jarvis.geo_cache', 'shooting.draft', 'immowert.draft', 'jarvis.einstellungen.apiKey']);
const AB25_MAX_EINTRAG = 1500000;   // größere Einzeleinträge (z. B. Fotos) bleiben auf dem Gerät

function istObj(x){ return x !== null && typeof x === 'object' && !Array.isArray(x); }
function hatId(x){ return istObj(x) && (typeof x.id === 'string' || typeof x.id === 'number') && x.id !== ''; }
function idListe(a){
  if(!Array.isArray(a)) return false;
  const ids = new Set();
  for(const x of a){ if(!hatId(x)) return false; const k = String(x.id); if(ids.has(k)) return false; ids.add(k); }
  return true;
}
// v34: Sammlung = Liste, deren Einträge alle eine id haben (doppelte ids erlaubt – sie werden vorher repariert).
// Früher wurde eine Liste mit doppelter id als EIN Einzelwert abgeglichen; dabei gingen auf dem anderen Gerät Einträge verloren.
function idSammlung(a){ return Array.isArray(a) && a.every(hatId); }
// v34: doppelte ids reparieren – auf allen Geräten gleich (deterministisch): echte Doppel (inhaltsgleich) fallen weg,
// sonst bekommt der spätere Eintrag die id „<id>_2“, „<id>_3“ … Verweise (objektId, kontaktId …) zeigen weiter auf den ersten.
function listeReparieren(a, pfad, log){
  if(!idSammlung(a) || a.length < 2) return 0;
  const zahl = new Map(); let doppelt = false;
  for(const x of a){ const k = String(x.id); if(zahl.has(k)){ doppelt = true; break; } zahl.set(k, 1); }
  if(!doppelt) return 0;
  const erste = new Map(), alle = new Set(a.map(x => String(x.id))), weg = new Set(); let n = 0;
  const ohneId = x => { const c = Object.assign({}, x); delete c.id; return stabil(c); };
  a.forEach((x, i) => {
    const k = String(x.id);
    if(!erste.has(k)){ erste.set(k, i); return; }
    const f = ohneId(x);
    if(ohneId(a[erste.get(k)]) === f){ weg.add(i); n++; if(log) log.push({ pfad, id: k, art: 'doppelt_entfernt' }); return; }
    let z = 2, neu = k + '_' + z;
    while(alle.has(neu)){
      const j = a.findIndex(y => String(y.id) === neu);
      if(j >= 0 && ohneId(a[j]) === f) break;   // dieselbe Reparatur gab es schon (z. B. vom anderen Gerät)
      neu = k + '_' + (++z);
    }
    if(alle.has(neu)){ weg.add(i); n++; if(log) log.push({ pfad, id: k, art: 'doppelt_entfernt' }); return; }
    x.id = neu; alle.add(neu); erste.set(neu, i); n++;
    if(log) log.push({ pfad, id: k, neu, art: 'neue_id' });
  });
  if(weg.size){ for(let i = a.length - 1; i >= 0; i--) if(weg.has(i)) a.splice(i, 1); }
  return n;
}
function idsReparieren(db, log){
  let n = 0;
  if(!istObj(db)) return 0;
  for(const K of Object.keys(db)){
    if(AB25_NUR_LOKAL.has(K)) continue;
    const v = db[K];
    if(Array.isArray(v)){ n += listeReparieren(v, K, log); continue; }
    if(istObj(v)) for(const SK of Object.keys(v)){ if(Array.isArray(v[SK])) n += listeReparieren(v[SK], K + '.' + SK, log); }
  }
  return n;
}
function stabil(x){
  if(x === undefined) return 'null';
  if(x === null || typeof x !== 'object') return JSON.stringify(x);
  if(Array.isArray(x)) return '[' + x.map(stabil).join(',') + ']';
  return '{' + Object.keys(x).filter(k => x[k] !== undefined).sort().map(k => JSON.stringify(k) + ':' + stabil(x[k])).join(',') + '}';
}
function hash(x){ const s = stabil(x); let h = 0x811c9dc5; for(let i = 0; i < s.length; i++){ h ^= s.charCodeAt(i); h = Math.imul(h, 0x01000193); } return (h >>> 0).toString(36) + '.' + s.length.toString(36); }
function gleich(a, b){ return stabil(a) === stabil(b); }
function kopie(x){ return x === undefined ? undefined : JSON.parse(JSON.stringify(x)); }
// apiKey o. Ä. aus Einzelwerten entfernen
function ohneLokales(id, d){
  if(id === 'jarvis.einstellungen' && istObj(d) && 'apiKey' in d){ d = Object.assign({}, d); delete d.apiKey; }
  return d;
}

// Daten → Einträge. Ergebnis: Map key → { s, id, d, gross }
// Sammlungen: Listen mit eindeutiger id (db.objekte …) und eine Ebene tiefer (db.hv.verwaltungen, db.invest24.pruefungen …).
// Alles andere wird als Einzelwert (s = '_einzel', id = 'schluessel' bzw. 'schluessel.unter') geführt.
function einheiten(db){
  const m = new Map();
  const add = (s, id, d) => {
    const k = s + '|' + id; let gross = false;
    try{ gross = JSON.stringify(d).length > AB25_MAX_EINTRAG; }catch(e){ gross = true; }
    m.set(k, { s, id, d, gross });
  };
  for(const K of Object.keys(db || {})){
    if(AB25_NUR_LOKAL.has(K)) continue;
    const v = db[K];
    if(v === undefined) continue;
    if(idSammlung(v)){ for(const x of v) if(!m.has(K + '|' + String(x.id))) add(K, String(x.id), x); continue; }
    if(istObj(v)){
      for(const SK of Object.keys(v)){
        const pfad = K + '.' + SK; if(AB25_NUR_LOKAL_UNTER.has(pfad)) continue;
        const w = v[SK]; if(w === undefined) continue;
        if(idSammlung(w)){ for(const x of w) if(!m.has(pfad + '|' + String(x.id))) add(pfad, String(x.id), x); continue; }
        add('_einzel', pfad, ohneLokales(pfad, w));
      }
      continue;
    }
    add('_einzel', K, v);
  }
  return m;
}
// Welche Sammlungen/Behälter sind auf diesem Gerät vorhanden? (nur dort werden Löschungen erkannt)
function behaelterDa(db, s, id){
  if(s === '_einzel'){ const t = id.split('.'); if(t.length === 1) return true; return istObj(db[t[0]]); }
  const t = s.split('.');
  if(t.length === 1) return Array.isArray(db[t[0]]);
  return istObj(db[t[0]]) && (Array.isArray(db[t[0]][t[1]]) || db[t[0]][t[1]] === undefined);
}
// Eintrag schreiben/löschen; Objekte werden an Ort und Stelle ersetzt (offene Dialoge behalten ihre Referenz)
function setzen(db, s, id, d){
  if(s === '_einzel'){
    const t = id.split('.');
    if(t.length === 1){ if(d === null) delete db[t[0]]; else db[t[0]] = d; return; }
    if(!istObj(db[t[0]])){ if(d === null) return; db[t[0]] = {}; }
    if(d === null) delete db[t[0]][t[1]];
    else if(t[0] === 'jarvis' && t[1] === 'einstellungen' && istObj(db.jarvis.einstellungen) && 'apiKey' in db.jarvis.einstellungen){ db.jarvis.einstellungen = Object.assign({}, d, { apiKey: db.jarvis.einstellungen.apiKey }); }
    else db[t[0]][t[1]] = d;
    return;
  }
  const t = s.split('.');
  let liste;
  if(t.length === 1){ if(!Array.isArray(db[t[0]])){ if(d === null) return; db[t[0]] = []; } liste = db[t[0]]; }
  else { if(!istObj(db[t[0]])){ if(d === null) return; db[t[0]] = {}; } if(!Array.isArray(db[t[0]][t[1]])){ if(d === null) return; db[t[0]][t[1]] = []; } liste = db[t[0]][t[1]]; }
  const i = liste.findIndex(x => x && String(x.id) === id);
  if(d === null){ if(i >= 0) liste.splice(i, 1); return; }
  if(i >= 0){ const alt = liste[i]; if(istObj(alt) && istObj(d)){ for(const k of Object.keys(alt)) if(!(k in d)) delete alt[k]; Object.assign(alt, d); } else liste[i] = d; }
  else liste.push(d);
}
function lesen(db, s, id){
  if(s === '_einzel'){ const t = id.split('.'); const v = t.length === 1 ? db[t[0]] : (istObj(db[t[0]]) ? db[t[0]][t[1]] : undefined); return v === undefined ? undefined : ohneLokales(id, v); }
  const t = s.split('.');
  const liste = t.length === 1 ? db[t[0]] : (istObj(db[t[0]]) ? db[t[0]][t[1]] : null);
  if(!Array.isArray(liste)) return undefined;
  return liste.find(x => x && String(x.id) === id);
}

// Dreiwege-Zusammenführung: b = gemeinsamer Stand, l = hier, r = anderes Gerät. lokalNeuer entscheidet echte Widersprüche.
function zusammen(b, l, r, pfad, protokoll, lokalNeuer){
  if(gleich(l, r)) return l;
  if(gleich(l, b)) return kopie(r);
  if(gleich(r, b)) return l;
  if(istObj(l) && istObj(r)){
    const out = {}; const bb = istObj(b) ? b : {};
    const keys = new Set(Object.keys(l).concat(Object.keys(r)));
    for(const k of keys){ const v = zusammen(bb[k], l[k], r[k], pfad + '.' + k, protokoll, lokalNeuer); if(v !== undefined) out[k] = v; }
    return out;
  }
  if(idListe(l || []) && idListe(r || []) && (l || r) && Array.isArray(l) && Array.isArray(r)){
    const bm = new Map((idListe(b || []) && Array.isArray(b) ? b : []).map(x => [String(x.id), x]));
    const lm = new Map(l.map(x => [String(x.id), x])), rm = new Map(r.map(x => [String(x.id), x]));
    const ids = l.map(x => String(x.id)).concat(r.map(x => String(x.id)).filter(id => !lm.has(id)));
    const out = [];
    for(const id of ids){
      const bi = bm.get(id), li = lm.get(id), ri = rm.get(id);
      if(li === undefined && ri === undefined) continue;
      if(li === undefined){ if(bi !== undefined && gleich(ri, bi)) continue; if(bi !== undefined) protokoll.push({ pfad: pfad + '[' + id + ']', art: 'wiederhergestellt', text: 'Hier gelöscht, auf dem anderen Gerät geändert – behalten.' }); out.push(kopie(ri)); continue; }
      if(ri === undefined){ if(bi !== undefined && gleich(li, bi)) continue; if(bi !== undefined) protokoll.push({ pfad: pfad + '[' + id + ']', art: 'wiederhergestellt', text: 'Auf dem anderen Gerät gelöscht, hier geändert – behalten.' }); out.push(li); continue; }
      out.push(zusammen(bi, li, ri, pfad + '[' + id + ']', protokoll, lokalNeuer));
    }
    return out;
  }
  // echter Widerspruch (gleicher Wert auf beiden Geräten unterschiedlich geändert)
  protokoll.push({ pfad, art: 'widerspruch', behalten: lokalNeuer ? l : r, ersetzt: lokalNeuer ? r : l, text: lokalNeuer ? 'Neuere Änderung von diesem Gerät behalten' : 'Neuere Änderung vom anderen Gerät übernommen' });
  return kopie(lokalNeuer ? l : r);
}

// Lokale Änderungen gegenüber der Basis
function aenderungen(db, basis, lokalSeit, jetzt){
  const e = einheiten(db), raus = [], zuGross = [];
  for(const [k, u] of e){
    if(u.gross){ zuGross.push(k); continue; }
    const B = basis[k], h = hash(u.d);
    if(B && B.h === h) continue;
    if(!lokalSeit[k]) lokalSeit[k] = jetzt;
    raus.push({ k, s: u.s, id: u.id, d: u.d, b: B ? B.r : 0, h });
  }
  const loeschungen = [], proSammlung = {};
  for(const k of Object.keys(basis)){
    if(e.has(k)) continue;
    const B = basis[k]; if(!B || B.h === 'x') continue;     // schon gelöscht
    const p = k.indexOf('|'), s = k.slice(0, p), id = k.slice(p + 1);
    if(!behaelterDa(db, s, id)) continue;                  // Bereich hier nicht geladen → nichts löschen
    // v34: Liste wurde früher (wegen doppelter id) als Einzelwert geführt und ist jetzt wieder eine Sammlung →
    // den alten Einzelwert NICHT löschen (ältere Geräte würden sonst die ganze Liste entfernen), nur hier abhaken
    if(s === '_einzel' && idSammlung(wert(db, id))){ basis[k] = { r: B.r, h: 'x', d: null }; delete lokalSeit[k]; continue; }
    if(!lokalSeit[k]) lokalSeit[k] = jetzt;
    loeschungen.push({ k, s, id, d: null, b: B.r, h: 'x' });
    if(s !== '_einzel') proSammlung[s] = (proSammlung[s] || 0) + 1;
  }
  // v34: Schutz, wenn eine ganze Liste (z. B. alle Leads) auf einmal leer wäre
  let ganzLeer = '';
  for(const s of Object.keys(proSammlung)){ const w = wert(db, s); if(proSammlung[s] >= 5 && Array.isArray(w) && w.length === 0) ganzLeer = s; }
  return { liste: raus.concat(loeschungen), loeschungen: loeschungen.length, zuGross, einheiten: e, ganzLeer };
}
// Wert unter „schluessel“ bzw. „schluessel.unter“
function wert(db, pfad){ const t = String(pfad).split('.'); if(t.length === 1) return db[t[0]]; return istObj(db[t[0]]) ? db[t[0]][t[1]] : undefined; }
// Eintrag vom anderen Gerät einarbeiten. Rückgabe: 'uebernommen' | 'gleich' | 'zusammengefuehrt'
function einarbeiten(db, basis, lokalSeit, rec, protokoll, ohneBasis){
  const k = rec.s + '|' + rec.id, B = basis[k];
  const L = lesen(db, rec.s, rec.id);
  const R = rec.d === undefined ? null : rec.d;
  const neueBasis = { r: rec.r, h: R === null ? 'x' : hash(R), d: R === null ? null : kopie(R) };
  // v34: Ein älteres Gerät schickt eine ganze Liste als Einzelwert (Folge einer doppelten id), hier ist sie eine Sammlung.
  // Dann nie die ganze Liste löschen oder ersetzen, sondern Eintrag für Eintrag zusammenführen (nichts geht verloren).
  if(rec.s === '_einzel' && idSammlung(L) && (R === null || idSammlung(R))){
    let geaendert = false;
    if(R !== null){
      const R2 = kopie(R); listeReparieren(R2, rec.id);
      for(const x of R2){
        const ek = rec.id + '|' + String(x.id), EL = lesen(db, rec.id, String(x.id)), EB = basis[ek];
        if(EL === undefined){ if(EB) continue; /* hier gelöscht */ setzen(db, rec.id, String(x.id), kopie(x)); geaendert = true; continue; }
        if(gleich(EL, x)) continue;
        const M = zusammen(EB ? EB.d : undefined, kopie(EL), x, ek, protokoll, (lokalSeit[ek] || 0) > (rec.t || 0));
        if(!gleich(M, EL)){ setzen(db, rec.id, String(x.id), M); geaendert = true; }
      }
    }
    basis[k] = { r: rec.r, h: 'x', d: null }; delete lokalSeit[k];
    return geaendert ? 'zusammengefuehrt' : 'gleich';
  }
  // Erstabgleich eines Geräts: ohne gemeinsamen Stand gewinnt der Server (Voreinstellungen eines neuen Geräts überschreiben nichts)
  const lokalGeaendert = B ? (L === undefined ? B.h !== 'x' : hash(L) !== B.h) : (L !== undefined && ohneBasis !== 'fern');
  if(!lokalGeaendert || (L === undefined && R === null)){
    if(R === null){ if(L !== undefined) setzen(db, rec.s, rec.id, null); }
    else if(L === undefined || !gleich(L, R)) setzen(db, rec.s, rec.id, kopie(R));
    basis[k] = neueBasis; delete lokalSeit[k];
    return L !== undefined && R !== null && gleich(L, R) ? 'gleich' : 'uebernommen';
  }
  if(L !== undefined && R !== null && gleich(L, R)){ basis[k] = neueBasis; delete lokalSeit[k]; return 'gleich'; }
  const lokalNeuer = (lokalSeit[k] || 0) > (rec.t || 0);
  let M;
  if(R === null){ M = L; protokoll.push({ pfad: k, art: 'wiederhergestellt', text: 'Auf dem anderen Gerät gelöscht, hier geändert – behalten.' }); }
  else if(L === undefined){ M = kopie(R); protokoll.push({ pfad: k, art: 'wiederhergestellt', text: 'Hier gelöscht, auf dem anderen Gerät geändert – behalten.' }); }
  else M = zusammen(B ? B.d : undefined, kopie(L), R, k, protokoll, lokalNeuer);
  setzen(db, rec.s, rec.id, M);
  basis[k] = neueBasis;                 // Ergebnis weicht von der Basis ab → wird beim nächsten Senden hochgeladen
  if(!lokalSeit[k]) lokalSeit[k] = Date.now();
  return 'zusammengefuehrt';
}
// Doppelte Termine (gleicher Google-Termin) zusammenlegen
function termineEntdoppeln(db){
  const l = Array.isArray(db.termine) ? db.termine : []; const nach = new Map(); let n = 0;
  for(const t of l.slice().sort((a, b) => (a.createdAt || 0) - (b.createdAt || 0))){
    if(!t.googleEventId) continue;
    const erster = nach.get(t.googleEventId);
    if(!erster){ nach.set(t.googleEventId, t); continue; }
    ['notiz', 'ort', 'objektId', 'kontaktId', 'wo'].forEach(f => { if(!erster[f] && t[f]) erster[f] = t[f]; });
    db.termine = db.termine.filter(x => x !== t); n++;
  }
  return n;
}
// Pakete bis ca. maxBytes
function paketieren(liste, maxBytes){
  const out = []; let akt = [], g = 0;
  for(const c of liste){ const n = (c.d === null ? 4 : JSON.stringify(c.d).length) + 80; if(akt.length && g + n > maxBytes){ out.push(akt); akt = []; g = 0; } akt.push(c); g += n; }
  if(akt.length) out.push(akt);
  return out;
}
// Eine Abgleich-Runde: senden(payload) → Antwort der Brücke. st = { geraet, seit, epoche, basis, lokalSeit }
async function runde(dbQuelle, st, senden, opt){
  opt = opt || {};
  const D = typeof dbQuelle === 'function' ? dbQuelle : () => dbQuelle;   // Daten-Objekt kann zwischen zwei Anfragen ersetzt werden
  const erg = { gesendet: 0, empfangen: 0, zusammengefuehrt: 0, protokoll: [], zuGross: [], geaendert: false, durchlaeufe: 0, erstabgleich: false, bereiche: [] };
  const bereiche = new Set();
  st.basis = st.basis || {}; st.lokalSeit = st.lokalSeit || {}; st.seit = st.seit || 0;
  const einarbeitenAlle = (liste, ohneBasis) => {
    // v34: Schickt ein älteres Gerät eine Liste als Einzelwert und „löscht“ gleichzeitig deren Einträge (Folge einer doppelten id),
    // sind diese Löschungen keine echten – die Einträge stecken ja in der Liste. Solche Löschungen werden übergangen.
    const inListe = new Map();
    for(const rec of liste || []){ if(rec && rec.s === '_einzel' && idSammlung(rec.d) && idSammlung(wert(D(), rec.id))) inListe.set(rec.id, new Set(rec.d.map(x => String(x.id)))); }
    for(const rec of liste || []){
      if(rec && rec.d == null && rec.s !== '_einzel' && inListe.has(rec.s) && inListe.get(rec.s).has(String(rec.id))){
        const kk = rec.s + '|' + rec.id; if(st.basis[kk]) st.basis[kk] = Object.assign({}, st.basis[kk], { h: 'neu' });   // beim nächsten Senden wiederherstellen
        erg.empfangen++; continue;
      }
      const r = einarbeiten(D(), st.basis, st.lokalSeit, rec, erg.protokoll, ohneBasis);
      erg.empfangen++;
      if(r !== 'gleich'){ erg.geaendert = true; bereiche.add(rec.s === '_einzel' ? String(rec.id).split('.')[0] : rec.s.split('.')[0]); }
      if(r === 'zusammengefuehrt') erg.zusammengefuehrt++;
    }
  };
  const pruefe = a => { if(!a || !a.ok) throw Object.assign(new Error((a && a.fehler) || 'Keine Antwort von der Google-Brücke'), { code: (a && a.code) || 'antwort' }); return a; };
  const abholen = async (ohneEigene, ohneBasis) => {
    let mehr = true, n = 0;
    while(mehr && n++ < 500){
      const a = pruefe(await senden({ aktion: 'abgleich', geraet: st.geraet, seit: st.seit, ohneEigene, aenderungen: [] }));
      if((a.epoche || 0) !== (st.epoche || 0)) return a;
      einarbeitenAlle(a.aenderungen, ohneBasis);
      st.seit = a.bis != null ? a.bis : a.rev; mehr = !!a.mehr;
      if(opt.zwischenstand) await opt.zwischenstand();
    }
    return null;
  };
  // Erstabgleich (noch kein gemeinsamer Stand) oder Server wurde geleert: erst alles holen
  for(let neu = 0; neu < 2; neu++){
    if(Object.keys(st.basis).length && st.seit) break;
    erg.erstabgleich = true; st.seit = 0;
    const ep = await abholen(false, opt.ohneBasis || 'fern');
    if(ep){ st.epoche = ep.epoche || 0; st.basis = {}; st.lokalSeit = {}; st.seit = 0; continue; }
    break;
  }
  for(let d = 0; d < 4; d++){
    erg.durchlaeufe++;
    erg.repariert = (erg.repariert || 0) + idsReparieren(D());
    const a = aenderungen(D(), st.basis, st.lokalSeit, Date.now());
    erg.zuGross = a.zuGross;
    const bekannt = Object.keys(st.basis).length;
    if(((a.loeschungen > 25 && a.loeschungen > bekannt * 0.3) || a.ganzLeer) && !opt.loeschenErlaubt) throw Object.assign(new Error(a.loeschungen + ' Einträge fehlen hier seit dem letzten Abgleich. Zum Schutz wurde nichts gelöscht.'), { code: 'massenloeschung', anzahl: a.loeschungen });
    const pakete = paketieren(a.liste, opt.paketBytes || 800000);
    if(!pakete.length) pakete.push([]);
    let nochmal = false;
    for(const paket of pakete){
      const ant = pruefe(await senden({ aktion: 'abgleich', geraet: st.geraet, seit: st.seit, ohneEigene: true, aenderungen: paket.map(c => ({ s: c.s, id: c.id, d: c.d, b: c.b })) }));
      if((ant.epoche || 0) !== (st.epoche || 0)){ st.epoche = ant.epoche || 0; st.basis = {}; st.lokalSeit = {}; st.seit = 0; throw Object.assign(new Error('Der Abgleich-Speicher wurde neu angelegt – bitte erneut abgleichen.'), { code: 'neustart' }); }
      const gesendet = new Map(paket.map(c => [c.s + '|' + c.id, c]));
      for(const x of ant.angenommen || []){ const k = x.s + '|' + x.id, c = gesendet.get(k); if(!c) continue; st.basis[k] = { r: x.r, h: c.h, d: c.d === null ? null : kopie(c.d) }; delete st.lokalSeit[k]; erg.gesendet++; }
      if((ant.abgelehnt || []).length) nochmal = true;
      const vorher = erg.zusammengefuehrt;
      einarbeitenAlle((ant.abgelehnt || []).concat(ant.aenderungen || []));
      if(erg.zusammengefuehrt > vorher) nochmal = true;
      st.seit = ant.bis != null ? ant.bis : ant.rev;
      if(ant.mehr) await abholen(true);
      if(opt.zwischenstand) await opt.zwischenstand();
    }
    if(!nochmal) break;
  }
  if(termineEntdoppeln(D())){ erg.geaendert = true; bereiche.add('termine'); }
  erg.bereiche = Array.from(bereiche);
  return erg;
}
const AB25 = { runde, paketieren, einheiten, aenderungen, einarbeiten, zusammen, setzen, lesen, hash, stabil, gleich, termineEntdoppeln, behaelterDa, idsReparieren, listeReparieren, idSammlung, AB25_MAX_EINTRAG };
root.AB25K = AB25;
if(typeof module !== 'undefined' && module.exports) module.exports = AB25;
})(typeof window !== 'undefined' ? window : globalThis);
