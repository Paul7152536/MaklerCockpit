/* MaklerCockpit v24 – Marktanalyse mit KI-Recherche (Prompt → JSON-Import → Prüfung → lokale Kennzahlen → Strategie → Eigentümerbericht → Überprüfung)
   Rechenkern: markt24_kern.js. Keine vorgetäuschte Websuche, kein API-Zwang. */

const MA24 = { sel: null, schritt: 'eingaben', vorschau: null, offen: {} };
const MA24_SCHRITTE = [['eingaben', '1 Objekt & Eingaben'], ['suche', '2 Suche & Prompt'], ['import', '3 KI-Ergebnis einfügen'], ['vergleiche', '4 Vergleiche prüfen'], ['ergebnis', '5 Ergebnis & Strategie'], ['bericht', '6 Eigentümerbericht'], ['pruefung', '7 Überprüfung']];
function ma24A(id){ return (db.analysen24 || []).find(a => a.id === (id || MA24.sel)) || null; }
function ma24Obj(a){ return a ? findObjekt(a.objektId) : null; }
function ma24Gesperrt(a){ if(a && a.status === 'abgeschlossen'){ akqToast('Diese Analyse ist abgeschlossen – für Änderungen bitte eine neue Version anlegen.'); return true; } return false; }

// Bewertungsobjekt aus dem Eingabestand (versioniert) oder live aus der Objektakte
function ma24Subjekt(a){
  const o = ma24Obj(a), e = a.eingabe && a.eingabe.werte;
  const w = k => e ? (e[k] ? e[k].wert : null) : (o ? an24Wert(o, k) : null);
  return { objektart: (a.eingabe && a.eingabe.objektart) || (o && o.objektart) || null, wohnflaeche: a.flaechenTyp === 'usable' ? w('nutzflaeche') : w('wohnflaeche'), grundstueck: w('grundstueck'), baujahr: w('baujahr'), zustand: w('zustand'), zimmer: w('zimmer'), flaechenTyp: a.flaechenTyp || 'living', link: o ? o.link : null };
}
function ma24AnalyseAuswerten(a){ return ma24Auswerten(a, ma24Subjekt(a)); }
function ma24EingabeErfassen(a){
  const o = ma24Obj(a); if(!o) return;
  const werte = {};
  for(const k of ['wohnflaeche', 'nutzflaeche', 'grundstueck', 'zimmer', 'baujahr', 'zustand', 'vermietung', 'kaufpreis', 'miete_ist', 'modernisierung', 'energie']){
    const akt = an24Aktiv(o, k), w = an24Wert(o, k);
    werte[k] = { wert: w, herkunft: akt ? akt.herkunft : (w == null ? 'fehlt' : 'offen'), pruef: akt ? akt.pruef : null, quelle: akt ? akt.quelle : '' };
  }
  a.eingabe = { am: new Date().toISOString(), objektart: o.objektart || null, ort: o.ort || '', werte, luecken: Object.entries(werte).filter(([k, v]) => v.wert == null && [a.flaechenTyp === 'usable' ? 'nutzflaeche' : 'wohnflaeche', 'baujahr', 'zustand'].concat(['EFH', 'DHH', 'Reihenhaus', 'Grundstück'].includes(o.objektart) ? ['grundstueck'] : []).includes(k)).map(([k]) => an24Feld(k).l), konflikte: an24Konflikte(o).map(x => x.feld.l) };
}

// ── Anlegen / Versionen ──
function ma24Neu(oid){
  const offen = (db.analysen24 || []).filter(a => a.objektId === oid && a.status !== 'abgeschlossen' && !a.objektGeloescht).sort((a, b) => (b.erstellt || 0) - (a.erstellt || 0))[0];
  if(oid && offen){ ma24Oeffnen(offen.id); akqToast('Offene Analyse (Entwurf) geöffnet'); return; }
  const obj = (db.objekte || []).slice().sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
  const vorO = oid ? findObjekt(oid) : null;
  mc24Modal(`<h3>📊 Neue Marktanalyse</h3>
    <label>Objekt</label><select id="ma_o">${obj.map(o => `<option value="${o.id}" ${o.id === oid ? 'selected' : ''}>${mc24E(mc24Titel(o))}${o.ort ? ' · ' + mc24E(mc24OrtKurz(o)) : ''}</option>`).join('')}</select>
    <label>Analyseziel</label><select id="ma_t"><option value="sale">Verkaufspreis (Kaufangebote)</option><option value="rent" ${vorO && vorO.auftragsart === 'vermietung' ? 'selected' : ''}>Marktmiete (Mietangebote, Nettokaltmiete)</option></select>
    <div class="mc24-muted">Kauf und Miete werden nie in einer Vergleichsgruppe gemischt. Jede Analyse wird mit Datum, Eingabestand und Annahmen gespeichert.</div>
    <div class="modal-actions"><div></div><div class="right"><button class="secondary" onclick="schliesseModal()">Abbrechen</button><button onclick="ma24Anlegen(document.getElementById('ma_o').value, document.getElementById('ma_t').value)">Analyse anlegen</button></div></div>`, 620);
}
function ma24Anlegen(oid, typ, ohneOeffnen){
  const o = findObjekt(oid); if(!o) return null;
  const vorher = (db.analysen24 || []).filter(a => a.objektId === oid && a.typ === typ).sort((a, b) => (b.version || 0) - (a.version || 0))[0];
  const fl = an24Wert(o, 'wohnflaeche');
  const a = { id: uid(), objektId: oid, typ, version: vorher ? (vorher.version || 1) + 1 : 1, vorgaengerId: vorher ? vorher.id : null, erstellt: Date.now(), stichtag: mc24Heute(), status: 'entwurf', flaechenTyp: 'living',
    parameter: vorher ? JSON.parse(JSON.stringify(vorher.parameter || {})) : { suchgebiet: ma24Suchgebiet(o), objektart: o.objektart || '', flaecheVon: fl ? Math.round(fl * 0.8) : '', flaecheBis: fl ? Math.round(fl * 1.2) : '', zustand: 'ähnlich', anzahl: 12, erweiterungen: 'angrenzende Ortsteile; Fläche ±30 %; Angebote der letzten 12 Monate – jede Erweiterung begründen', quellen: '', adresseImPrompt: true },
    importe: [], vergleiche: [], unbestaetigt: [], kiKonflikte: [], annahmen: vorher ? (vorher.annahmen || []).slice() : [], grenzen: [], staerken: vorher ? (vorher.staerken || []).slice() : [], schwaechen: vorher ? (vorher.schwaechen || []).slice() : [], naechste: [], offenManuell: [],
    strategie: { szenarien: null, angebotspreis: null, begruendung: '', wunsch: null }, ueberpruefungen: [], berichte: [] };
  ma24EingabeErfassen(a);
  db.analysen24.push(a); save();
  if(!ohneOeffnen){ schliesseModal(); ma24Oeffnen(a.id); }
  return a;
}
function ma24Suchgebiet(o){
  const ort = String(o.ort || ''), plz = (ort.match(/\b\d{5}\b/) || [])[0] || '';
  let gebiet = '';
  try{ const [gid] = aqGebietFinden(o.ort, o.adresse); if(gid) gebiet = MC_MARKT.gebiete[gid].name; }catch(e){}
  return [ort.replace(/\b\d{5}\b/, '').trim(), plz ? 'PLZ ' + plz : '', gebiet && !ort.includes(gebiet) ? 'Bezirk ' + gebiet : ''].filter(Boolean).join(', ');
}
function ma24NeueVersion(id){
  const alt = ma24A(id); if(!alt) return;
  const neu = ma24Anlegen(alt.objektId, alt.typ, true);
  neu.vergleiche = JSON.parse(JSON.stringify(alt.vergleiche || [])).map(v => Object.assign(v, { pruef: 'ungeprueft' }));
  neu.unbestaetigt = JSON.parse(JSON.stringify(alt.unbestaetigt || [])); neu.suche = alt.suche; neu.researchStatus = alt.researchStatus; neu.recherche = alt.recherche;
  neu.strategie = JSON.parse(JSON.stringify(alt.strategie || {})); neu.naechste = (alt.naechste || []).slice(); neu.offenManuell = (alt.offenManuell || []).slice();
  neu.hinweisVersion = `Übernommen aus Version ${alt.version} vom ${mc24Datum(alt.erstellt)} – Vergleiche bitte erneut prüfen und bestätigen.`;
  save(); ma24Oeffnen(neu.id); akqToast(`Version ${neu.version} angelegt`);
}
function ma24Oeffnen(id){ schliesseModal(); MA24.sel = id; MA24.vorschau = null; const a = ma24A(id); MA24.schritt = a && a.vergleiche.length ? (a.status === 'abgeschlossen' ? 'ergebnis' : 'vergleiche') : 'eingaben'; wechsleAnsicht('marktanalyse24'); }
function ma24Loeschen(id){ bestaetigeUnten('Diese Analyse-Version löschen?', () => { db.analysen24 = db.analysen24.filter(a => a.id !== id); MA24.sel = null; save(); renderMain(); }); }

// ── Seite ──
function ma24Render(main){
  const alle = (db.analysen24 || []).slice().sort((a, b) => (b.erstellt || 0) - (a.erstellt || 0));
  if(!ma24A() && alle.length) MA24.sel = alle[0].id;
  const a = ma24A();
  main.innerHTML = `
  <div class="aq-kopf"><div class="ic">${IC.marktanalyse24 || ''}</div><div><h1>Marktanalyse</h1><div class="sub">Vergleichsinserate per KI-Recherche (bis 20), lokal ausgewertet – mit Quellen, Datenqualität und Eigentümerbericht.</div></div>
    <div class="knoepfe"><button class="secondary" onclick="wechsleAnsicht('immowert')" title="Bisheriger Vergleichs-/Ertragswert-Rechner">Wertrechner</button><button onclick="ma24Neu()">${IC.plus || '+'} Neue Analyse</button></div></div>
  <div class="ma24-layout"><div class="ma24-liste">${alle.map(x => { const o = ma24Obj(x), r = ma24AnalyseAuswerten(x); return `<div class="ma24-lz ${x.id === MA24.sel ? 'an' : ''}" onclick="ma24Oeffnen('${x.id}')"><b>${mc24E(o ? mc24Titel(o) : (x.objektGeloescht || {}).titel || 'Objekt gelöscht')}</b><small>${x.typ === 'rent' ? 'Marktmiete' : 'Verkaufspreis'} · V${x.version} · ${mc24Datum(x.erstellt)}${x.status === 'abgeschlossen' ? ' · ✓ abgeschlossen' : ' · Entwurf'}${x.objektGeloescht ? ' · <span class="mc24-rot">Objekt gelöscht</span>' : ''}</small><small>${r.spanne && r.spanne.von != null ? mc24Eur(r.spanne.von) + ' – ' + mc24Eur(r.spanne.bis) : r.anzahl.gefunden ? r.anzahl.verwendet + ' von ' + r.anzahl.gefunden + ' Vergleichen verwendet' : 'noch keine Vergleiche'}</small></div>`; }).join('') || '<div class="vl-leer">Noch keine Analyse. Starte mit „Neue Analyse“ oder aus der Objektakte.</div>'}</div>
  <div class="ma24-haupt">${a ? ma24AnalyseHtml(a) : ''}</div></div>`;
}
function ma24AnalyseHtml(a){
  const o = ma24Obj(a), r = ma24AnalyseAuswerten(a);
  const offen = ma24OffenePunkte(a, r);
  const naechste = ma24NaechsteAktion(a, r);
  return `<div class="ma24-kopf"><div><h2>${mc24E(o ? mc24Titel(o) : 'Objekt gelöscht')} <span class="mc24-muted">· ${a.typ === 'rent' ? 'Marktmiete' : 'Verkaufspreis'} · Version ${a.version}</span></h2>
      <div class="mc24-muted">Stichtag ${mc24Datum(a.stichtag)} · angelegt ${mc24Datum(a.erstellt)}${a.eingabe ? ' · Eingabestand ' + mc24Datum(a.eingabe.am) : ''} · ${a.status === 'abgeschlossen' ? '✓ abgeschlossen ' + mc24Datum(a.abgeschlossenAm) : 'Entwurf'}</div></div>
      <div class="mc24-knoepfe">${o ? `<button class="tiny secondary" onclick="ob24Oeffnen('${o.id}')">📁 Akte</button>` : ''}<button class="tiny secondary" onclick="ma24NeueVersion('${a.id}')">⧉ Neue Version</button><button class="tiny secondary" onclick="ma24Loeschen('${a.id}')">🗑</button></div></div>
    ${a.hinweisVersion ? `<div class="mc24-hinweis">${mc24E(a.hinweisVersion)}</div>` : ''}
    <div class="mc24-fokus">
      <div class="mc24-fz"><span>📈</span><div><b>${r.spanne && r.spanne.von != null ? `${ma24Wert(a, r.spanne.von)} – ${ma24Wert(a, r.spanne.bis)} (Median ${ma24Wert(a, r.spanne.mitte)})` : r.spanne ? `${mc24Zahl(r.spanne.m2Von, 2)} – ${mc24Zahl(r.spanne.m2Bis, 2)} €/m²` : 'Keine belastbare Spanne'}</b><small>${r.anzahl.verwendet} verwendet · ${r.anzahl.bestaetigt} bestätigt · ${r.anzahl.gefunden} gefunden${r.anzahl.hinweise ? ' · ' + r.anzahl.hinweise + ' unbestätigte Hinweise' : ''} · Datenqualität ${r.qualitaet.stufe}</small></div></div>
      ${offen.length ? `<div class="mc24-fz warn"><span>⚠️</span><div><b>${offen.length} offene${offen.length === 1 ? 'r' : ''} Punkt${offen.length === 1 ? '' : 'e'}</b><small>${mc24E(offen.slice(0, 3).join(' · '))}</small></div></div>` : ''}
      <div class="mc24-fz"><span>➡️</span><div><b>Nächste Aktion</b><small>${mc24E(naechste.t)}</small></div>${naechste.s ? `<button class="tiny" onclick="MA24.schritt='${naechste.s}';renderMain()">${mc24E(naechste.k)}</button>` : ''}</div>
    </div>
    <div class="vl-tabs ma24-tabs">${MA24_SCHRITTE.map(([k, l]) => `<button class="${MA24.schritt === k ? 'an' : ''}" onclick="MA24.schritt='${k}';renderMain()">${l}</button>`).join('')}</div>
    <div class="ma24-inhalt">${({ eingaben: ma24SchrittEingaben, suche: ma24SchrittSuche, import: ma24SchrittImport, vergleiche: ma24SchrittVergleiche, ergebnis: ma24SchrittErgebnis, bericht: ma24SchrittBericht, pruefung: ma24SchrittPruefung })[MA24.schritt](a, r, o)}</div>`;
}
function ma24Wert(a, x){ return a.typ === 'rent' ? mc24Eur(x) + ' mtl.' : mc24Eur(x); }
function ma24KiKonflikteOffen(a){
  const o = ma24Obj(a);
  return (a.kiKonflikte || []).filter(k => {
    if(k.erledigt) return false;
    const f = k.feld || ma24KonfliktFeld(k.field);
    if(o && f){
      if(an24Konflikte(o).some(x => x.feld.k === f)) return false;   // wird als Widerspruch der Objektakte geführt
      const ent = o.angaben && o.angaben[f] && o.angaben[f].entscheidung;
      if(ent && (!k.am || ent.am >= k.am)) return false;               // in der Akte entschieden
    }
    return true;
  });
}
function ma24OffenePunkte(a, r){
  const o = ma24Obj(a), l = [];
  if(o) an24Konflikte(o).forEach(x => l.push(`${x.feld.l}: widersprüchliche Angaben`));
  ma24KiKonflikteOffen(a).forEach(k => l.push(`${k.field}: ${k.question || 'klären'}`));
  if(a.eingabe) a.eingabe.luecken.forEach(x => l.push(x + ' unbekannt'));
  const unge = (r || ma24AnalyseAuswerten(a)).zeilen.filter(z => z.vorlaeufig && z.v.pruef === 'ungeprueft').length; if(unge) l.push(`${unge} nutzbare(r) Vergleich(e) noch nicht geprüft`);
  (a.offenManuell || []).forEach(x => l.push(x));
  return l;
}
function ma24NaechsteAktion(a, r){
  if(!a.eingabe) return { t: 'Eingaben und Datenlücken prüfen', s: 'eingaben', k: 'Eingaben' };
  if(!a.importe.length) return { t: 'Recherche-Prompt erstellen, in einer KI mit Websuche nutzen und das JSON einfügen', s: 'suche', k: 'Prompt erstellen' };
  if(r.zeilen.some(z => z.vorlaeufig && z.v.pruef === 'ungeprueft')) return { t: 'Nutzbare Vergleiche prüfen und bestätigen oder ausschließen', s: 'vergleiche', k: 'Vergleiche prüfen' };
  if(a.status !== 'abgeschlossen') return { t: 'Ergebnis und Preisstrategie prüfen, dann Analyse abschließen', s: 'ergebnis', k: 'Ergebnis' };
  if(!(a.berichte || []).length) return { t: 'Eigentümerbericht ansehen und als PDF speichern', s: 'bericht', k: 'Bericht' };
  return { t: 'Nach Vermarktungsstart: Resonanz eintragen und mit der Analyse vergleichen', s: 'pruefung', k: 'Überprüfung' };
}

// Schritt 1: Objekt & Eingaben (Herkunft, Lücken)
function ma24SchrittEingaben(a, r, o){
  if(!o) return '<div class="vl-leer">Das Objekt wurde gelöscht. Die Analyse bleibt als Archiv erhalten.</div>';
  const felder = ['wohnflaeche', 'nutzflaeche', 'grundstueck', 'zimmer', 'baujahr', 'zustand', 'vermietung', 'kaufpreis', 'miete_ist', 'modernisierung', 'energie'];
  const konf = an24Konflikte(o);
  return `<div class="mc24-karte"><h3>Bewertungsobjekt <span class="sp"></span><button class="tiny secondary" onclick="an24Dialog('${o.id}')">+ Angabe erfassen</button></h3>
    <table class="mc24-tab"><tr><th>Angabe</th><th>Wert jetzt</th><th>Herkunft</th><th>Prüfung</th>${a.eingabe ? '<th>im Eingabestand</th>' : ''}</tr>
    ${felder.map(k => { const f = an24Feld(k), w = an24Wert(o, k), akt = an24Aktiv(o, k), e = a.eingabe && a.eingabe.werte[k]; return `<tr><td>${mc24E(f.l)}</td><td><b>${mc24E(an24Wtext(f, w))}</b></td><td>${akt ? `<span class="mc24-h h-${akt.herkunft}">${mc24E(an24L(AN24_HERKUNFT, akt.herkunft))}</span>` : w == null ? '<span class="mc24-h h-fehlt">fehlt</span>' : ''}</td><td>${akt && akt.pruef === 'geprueft' ? '✓' : ''}</td>${a.eingabe ? `<td class="mc24-muted">${e ? mc24E(an24Wtext(f, e.wert)) : ''}</td>` : ''}</tr>`; }).join('')}</table>
    ${konf.length ? `<div class="mc24-hinweis">⚠️ Widersprüchliche Angaben: ${konf.map(x => mc24E(x.feld.l)).join(', ')} – <a href="#" onclick="ob24Oeffnen('${o.id}');return false;">in der Objektakte klären</a>. Bis dahin wird der aktuell verwendete Wert genutzt und im Bericht als offen genannt.</div>` : ''}
    <div class="field-row"><div><label>Flächenart für den Vergleich</label><select ${a.status === 'abgeschlossen' ? 'disabled' : ''} onchange="ma24Setzen('flaechenTyp', this.value)"><option value="living" ${a.flaechenTyp !== 'usable' ? 'selected' : ''}>Wohnfläche</option><option value="usable" ${a.flaechenTyp === 'usable' ? 'selected' : ''}>Nutzfläche</option></select></div>
      <div><label>Stichtag</label><input type="date" value="${mc24E(a.stichtag)}" ${a.status === 'abgeschlossen' ? 'disabled' : ''} onchange="ma24Setzen('stichtag', this.value)"></div></div>
    <div class="mc24-knoepfe" style="margin-top:10px;"><button onclick="ma24EingabeUebernehmen()">${a.eingabe ? '↻ Eingabestand aktualisieren' : '✓ Eingaben übernehmen'}</button><span class="mc24-muted">${a.eingabe ? 'Gespeichert am ' + mc24Datum(a.eingabe.am) + (a.eingabe.luecken.length ? ' · Lücken: ' + mc24E(a.eingabe.luecken.join(', ')) : ' · keine Kernlücken') : 'Der Eingabestand wird mit der Analyse versioniert.'}</span></div></div>`;
}
function ma24Setzen(feld, wert){ const a = ma24A(); if(ma24Gesperrt(a)) return; a[feld] = wert; save(); renderMain(); }
function ma24EingabeUebernehmen(){ const a = ma24A(); if(ma24Gesperrt(a)) return; ma24EingabeErfassen(a); save(); MA24.schritt = 'suche'; renderMain(); akqToast('Eingabestand gespeichert'); }

// Schritt 2: Suche & Prompt
function ma24PromptDaten(a){
  const o = ma24Obj(a), p = a.parameter || {}, e = (a.eingabe || {}).werte || {};
  const obj = { objektart: (a.eingabe || {}).objektart || o.objektart || null, ort_ortsteil: o.ort || null, adresse: p.adresseImPrompt ? (o.adresse || null) : 'nicht übergeben' };
  for(const [k, v] of Object.entries(e)) obj[k] = { wert: v.wert, herkunft: v.herkunft === 'fehlt' ? 'unbekannt' : an24L(AN24_HERKUNFT, v.herkunft), geprueft: v.pruef === 'geprueft' };
  obj.flaechenart_fuer_vergleich = a.flaechenTyp === 'usable' ? 'Nutzfläche (usable)' : 'Wohnfläche (living)';
  obj.datenluecken = (a.eingabe || {}).luecken || [];
  obj.widersprueche = (a.eingabe || {}).konflikte || [];
  if(o.link) obj.eigenes_inserat_nicht_als_vergleich = o.link;
  const quellen = String(p.quellen || '').split(/\n+/).map(s => s.trim()).filter(Boolean).concat((a.vergleiche || []).map(v => v.source_url));
  return { stichtag: a.stichtag, typ: a.typ, subjectId: a.objektId, objekt: obj, suchgebiet: p.suchgebiet,
    filter: [p.objektart ? 'Objektart: ' + p.objektart : '', p.flaecheVon || p.flaecheBis ? `Fläche ${p.flaecheVon || '?'}–${p.flaecheBis || '?'} m²` : '', p.zustand ? 'Zustand: ' + p.zustand : '', p.erweiterungen ? 'Zulässige Erweiterungen: ' + p.erweiterungen : ''].filter(Boolean).join('; '),
    anzahl: p.anzahl, quellen: [...new Set(quellen)].slice(0, 25) };
}
function ma24SchrittSuche(a, r, o){
  if(!o) return '<div class="vl-leer">Objekt gelöscht.</div>';
  const p = a.parameter || {}, dis = a.status === 'abgeschlossen' ? 'disabled' : '';
  const f = (k, l, w, typ, ph) => `<div><label>${l}</label><input ${dis} ${typ ? `type="${typ}"` : ''} value="${mc24E(w == null ? '' : w)}" placeholder="${mc24E(ph || '')}" onchange="ma24Param('${k}', this.value)"></div>`;
  return `<div class="mc24-karte"><h3>Suchkriterien</h3>
    <div class="field-row">${f('suchgebiet', 'Suchgebiet / Mikrolage', p.suchgebiet)}${f('objektart', 'Objektart', p.objektart)}</div>
    <div class="field-row">${f('flaecheVon', 'Fläche von (m²)', p.flaecheVon, 'number')}${f('flaecheBis', 'Fläche bis (m²)', p.flaecheBis, 'number')}${f('zustand', 'Zustand', p.zustand)}<div><label>Anzahl Vergleiche (1–20)</label><input ${dis} type="number" min="1" max="20" value="${mc24E(p.anzahl || 12)}" onchange="ma24Param('anzahl', Math.max(1, Math.min(20, Number(this.value) || 12)))"></div></div>
    <div class="field-row">${f('erweiterungen', 'Zulässige Erweiterungen', p.erweiterungen)}</div>
    <label>Bereits bekannte Quellen (ein Link pro Zeile, optional)</label><textarea ${dis} rows="2" onchange="ma24Param('quellen', this.value)">${mc24E(p.quellen || '')}</textarea>
    <label class="gs-chk"><input type="checkbox" ${dis} ${p.adresseImPrompt !== false ? 'checked' : ''} onchange="ma24Param('adresseImPrompt', this.checked)"> Genaue Adresse für die Lagebeurteilung mitgeben (interne Recherche). Eigentümerdaten werden nie übergeben.</label>
    <div class="mc24-knoepfe" style="margin-top:10px;"><button onclick="ma24PromptKopieren()">📋 KI-Recherche-Prompt erstellen und kopieren</button><span class="mc24-muted">${a.promptAm ? 'zuletzt erstellt ' + mc24Datum(a.promptAm) : ''}</span></div>
    <div class="mc24-hinweis">So geht's: Prompt in einer KI <b>mit Websuche</b> einfügen (z. B. ChatGPT mit Suche oder Claude mit Websuche). Die Antwort ist ein JSON-Block – den im nächsten Schritt einfügen. Ohne Webzugang meldet die KI das ausdrücklich, dann werden keine Vergleiche gewertet. Kein kostenpflichtiger API-Zugang nötig.</div>
    <details class="gs-details"><summary>Technisch: Vorschau des Prompts und JSON-Schema (${MA24_VERSION})</summary><textarea readonly rows="10" style="font-family:Consolas,monospace;font-size:11px;">${mc24E(ma24Prompt(ma24PromptDaten(a)))}</textarea></details></div>`;
}
function ma24Param(k, v){ const a = ma24A(); if(ma24Gesperrt(a)) return; a.parameter = a.parameter || {}; a.parameter[k] = v; save(); }
function ma24PromptKopieren(){
  const a = ma24A(); if(!a) return;
  if(!a.eingabe){ ma24EingabeErfassen(a); }
  const text = ma24Prompt(ma24PromptDaten(a));
  a.promptAm = new Date().toISOString(); a.promptHash = ma24Hash(text); save();
  mc24Kopieren(text, '📋 Prompt kopiert – jetzt in der KI mit Websuche einfügen');
  MA24.schritt = 'import'; renderMain();
}

// Schritt 3: Import mit Vorschau
function ma24SchrittImport(a, r, o){
  if(a.status === 'abgeschlossen') return '<div class="vl-leer">Abgeschlossene Analyse – für neue Recherche eine neue Version anlegen.</div>';
  const v = MA24.vorschau;
  return `<div class="mc24-karte"><h3>KI-Ergebnis einfügen</h3>
    <textarea id="ma_json" rows="7" placeholder='Antwort der KI hier einfügen – sie beginnt mit {"schema_version": …' style="font-family:Consolas,monospace;font-size:11.5px;">${mc24E(MA24.roh || '')}</textarea>
    <div class="mc24-knoepfe"><button onclick="ma24ImportPruefenKlick()">Prüfen</button><button class="secondary" onclick="document.getElementById('ma_datei').click()">📂 JSON-Datei wählen</button><input type="file" id="ma_datei" accept=".json,application/json,.txt" style="display:none" onchange="ma24DateiLesen(this)"></div>
    ${v ? ma24VorschauHtml(a, v) : '<div class="mc24-muted" style="margin-top:8px;">Vor der Übernahme siehst du eine Vorschau mit Quellen, Unklarheiten und Ausschlüssen. Nichts wird still repariert.</div>'}</div>
    ${a.importe.length ? `<div class="mc24-karte"><h3>Bisherige Importe</h3>${a.importe.map(i => `<div class="mc24-z"><span>⇩</span><div>${mc24Datum(i.am)} · ${i.anzahl} Vergleiche · Recherche ${mc24E(ma24T(i.research_status))}<small>${i.hinzu} neu, ${i.aktualisiert} aktualisiert, ${i.gleich} unverändert</small></div></div>`).join('')}</div>` : ''}`;
}
function ma24DateiLesen(inp){ const f = inp.files && inp.files[0]; if(!f) return; const rd = new FileReader(); rd.onload = () => { MA24.roh = String(rd.result || ''); ma24ImportPruefenKlick(true); }; rd.readAsText(f); inp.value = ''; }
function ma24ImportPruefenKlick(ausDatei){
  const a = ma24A(); if(!a) return;
  if(!ausDatei) MA24.roh = document.getElementById('ma_json').value;
  const p = ma24Parsen(MA24.roh);
  if(!p.ok){ MA24.vorschau = { fehler: p.fehler, codezaun: p.codezaun }; renderMain(); return; }
  const pr = ma24ImportPruefen(p.json, { subjectId: a.objektId, analyseTyp: a.typ });
  const dopp = a.importe.find(i => i.hash === p.hash);
  MA24.vorschau = { json: p.json, hash: p.hash, fehler: pr.fehler, hinweise: pr.hinweise, schonImportiert: !!dopp };
  renderMain();
}
function ma24VorschauHtml(a, v){
  if(v.fehler && v.fehler.length) return `<div class="ma24-fehler"><b>Nicht übernommen – bitte korrigieren lassen:</b><ul>${v.fehler.map(f => `<li>${mc24E(f)}</li>`).join('')}</ul>${v.codezaun ? '<button class="tiny" onclick="MA24.roh=ma24CodezaunEntfernen(MA24.roh);ma24ImportPruefenKlick(true)">Codezaun entfernen und erneut prüfen</button>' : '<div class="mc24-muted">Tipp: die Fehlermeldungen in die KI kopieren und um eine korrigierte, vollständige JSON-Antwort bitten.</div>'}</div>`;
  const j = v.json, test = Object.assign({}, a, { vergleiche: ma24VergleicheMergen(a.vergleiche, j.comparables, 'vorschau').liste, researchStatus: j.research_status });
  const r = ma24Auswerten(test, ma24Subjekt(a));
  const neuIds = new Set(j.comparables.map(c => ma24UrlNorm(c.source_url)));
  const zeilen = r.zeilen.filter(z => neuIds.has(ma24UrlNorm(z.v.source_url)));
  return `<div class="ma24-vorschau">
    ${v.schonImportiert ? '<div class="mc24-hinweis">Genau diese Antwort wurde bereits importiert – eine erneute Übernahme ändert nichts.</div>' : ''}
    <div class="ma24-zahlen"><div><b>${j.comparables.length}</b><small>Vergleiche geliefert</small></div><div><b>${j.comparables.filter(c => c.verification_status === 'verified').length}</b><small>laut KI belegt</small></div><div><b>${zeilen.filter(z => z.vorlaeufig).length}</b><small>vorläufig nutzbar</small></div><div><b>${j.unverified_candidates.length}</b><small>unbestätigte Hinweise</small></div><div><b>${j.subject_conflicts.length}</b><small>Widersprüche</small></div></div>
    <div class="mc24-muted">Recherche: ${mc24E(ma24T(j.research_status))} · ${mc24E(j.research_timestamp)} · Quellen: ${mc24E((j.search_strategy.sources_searched || []).join(', ') || '–')} · KI-Einschätzung Datenqualität: ${mc24E(ma24T(j.data_quality.level))}</div>
    ${v.hinweise.length ? `<div class="mc24-hinweis"><b>Hinweise:</b><ul>${v.hinweise.map(h => `<li>${mc24E(h)}</li>`).join('')}</ul></div>` : ''}
    ${j.summary ? `<div class="mc24-muted"><b>Zusammenfassung der KI:</b> ${mc24E(j.summary)}</div>` : ''}
    <table class="mc24-tab"><tr><th>Vergleich</th><th>Preisart</th><th>${a.typ === 'rent' ? 'Nettokaltmiete' : 'Preis'}</th><th>Fläche</th><th>€/m²</th><th>KI-Eignung</th><th>Vorläufig</th></tr>
      ${zeilen.map(z => `<tr><td>${mc24E(z.v.title.slice(0, 60))}<br><small>${mc24E(z.v.source_name)} · ${mc24LinkHtml(z.v.source_url, 'Quelle')}</small></td><td>${mc24E(ma24T(z.v.price_type))}</td><td>${mc24Eur(ma24Kennwert(z.v, a.typ))}</td><td>${mc24Zahl(z.v.area_sqm)} m² <small>${mc24E(ma24T(z.v.area_type))}</small></td><td>${mc24Zahl(z.proM2, a.typ === 'rent' ? 2 : 0)}</td><td>${mc24E(ma24T(z.v.comparability))}</td><td>${z.vorlaeufig ? '✓ nutzbar' : `<span class="mc24-muted">${mc24E(z.grund)}</span>`}</td></tr>`).join('') || '<tr><td colspan="7" class="mc24-muted">Keine Vergleiche geliefert.</td></tr>'}</table>
    ${j.subject_conflicts.length ? `<div><b>Widersprüche beim Bewertungsobjekt (werden als Vorschlag geführt, nichts wird überschrieben):</b>${j.subject_conflicts.map(c => `<div class="mc24-muted">• ${mc24E(c.field)}: ${c.values.map(x => mc24E(String(x.value)) + ' (' + mc24E(x.source) + ')').join(' ↔ ')} – ${mc24E(c.question)}</div>`).join('')}</div>` : ''}
    <div class="mc24-knoepfe" style="margin-top:10px;"><button onclick="ma24Uebernehmen()" ${v.schonImportiert ? 'disabled' : ''}>✓ In die Analyse übernehmen</button><button class="secondary" onclick="MA24.vorschau=null;renderMain()">Verwerfen</button></div></div>`;
}
function ma24KonfliktFeld(name){
  const n = String(name || '').toLowerCase();
  return /wohnfl|living|area_sqm|^area|fläche/.test(n) && !/grund|plot|nutz/.test(n) ? 'wohnflaeche' : /nutzfl|usable/.test(n) ? 'nutzflaeche' : /grund|plot/.test(n) ? 'grundstueck' : /baujahr|year/.test(n) ? 'baujahr' : /zimmer|room/.test(n) ? 'zimmer' : /hausgeld/.test(n) ? 'hausgeld' : /miete|rent/.test(n) ? 'miete_ist' : /modern/.test(n) ? 'modernisierung' : /zustand|condition/.test(n) ? 'zustand' : null;
}
function ma24Uebernehmen(){
  const a = ma24A(), v = MA24.vorschau; if(!a || !v || !v.json || (v.fehler || []).length) return;
  if(ma24Gesperrt(a)) return;
  const j = v.json, impId = uid();
  const m = ma24VergleicheMergen(a.vergleiche, j.comparables, impId);
  if(m.liste.length > MA24_MAX){ akqToast(`Zusammen wären es ${m.liste.length} Vergleiche – höchstens ${MA24_MAX}. Bitte vorher Vergleiche entfernen oder neue Version anlegen.`); return; }
  a.vergleiche = m.liste;
  const bekannt = new Set((a.unbestaetigt || []).map(u => ma24UrlNorm(u.url) || u.title));
  a.unbestaetigt = (a.unbestaetigt || []).concat(j.unverified_candidates.filter(u => !bekannt.has(ma24UrlNorm(u.url) || u.title)));
  a.researchStatus = j.research_status; a.recherche = j.research_timestamp; a.suche = j.search_strategy;
  a.kiQualitaet = j.data_quality; a.zusammenfassung = j.summary; a.kiStrategie = j.strategy_notes; a.grenzen = j.limitations; a.kiAnnahmen = j.assumptions;
  const o = ma24Obj(a);
  j.subject_conflicts.forEach(c => {
    const key = c.field + '|' + c.values.map(x => x.value).join('|');
    if(!(a.kiKonflikte || []).some(k => k.key === key)) (a.kiKonflikte = a.kiKonflikte || []).push({ key, field: c.field, feld: ma24KonfliktFeld(c.field), values: c.values, significance: c.significance, question: c.question, erledigt: false, am: new Date().toISOString() });
    const feld = ma24KonfliktFeld(c.field);
    if(o && feld) c.values.forEach(x => {
      const f = an24Feld(feld), wert = f.typ === 'zahl' ? mc24N(x.value) : x.value;
      if(wert == null || an24Norm(f, wert) === an24Norm(f, an24Wert(o, feld))) return;
      an24Setzen(o, feld, { wert, herkunft: 'offen', quelle: String(x.source || 'KI-Recherche').slice(0, 120) + ' (KI-Recherche ' + String(j.research_timestamp).slice(0, 10) + ')', pruef: 'vorschlag', von: 'ki', analyseId: a.id }, { aktivieren: false });
    });
  });
  a.importe.push({ id: impId, am: new Date().toISOString(), hash: v.hash, research_status: j.research_status, anzahl: j.comparables.length, hinzu: m.hinzu, aktualisiert: m.aktualisiert, gleich: m.gleich });
  save(); MA24.vorschau = null; MA24.roh = ''; MA24.schritt = 'vergleiche'; renderMain();
  akqToast(`✓ Übernommen: ${m.hinzu} neu, ${m.aktualisiert} aktualisiert – jetzt prüfen und bestätigen`);
}

// Schritt 4: Vergleiche prüfen
function ma24SchrittVergleiche(a, r, o){
  const dis = a.status === 'abgeschlossen';
  const gebiet = ma24GebietText(o, a);
  return `<div class="ma24-zahlen"><div><b>${r.anzahl.gefunden}</b><small>gefunden</small></div><div><b>${r.anzahl.bestaetigt}</b><small>von dir bestätigt</small></div><div><b>${r.anzahl.verwendet}</b><small>in der Berechnung</small></div><div><b>${r.anzahl.hinweise}</b><small>unbestätigte Hinweise</small></div></div>
    ${!dis && r.zeilen.some(z => z.vorlaeufig && z.v.pruef === 'ungeprueft') ? `<div class="mc24-knoepfe"><button class="tiny" onclick="ma24AlleBestaetigen()">✓ Alle ${r.zeilen.filter(z => z.vorlaeufig && z.v.pruef === 'ungeprueft').length} nutzbaren nach Durchsicht bestätigen</button><span class="mc24-muted">Erst Quellen ansehen – das KI-Label „belegt“ macht Daten nicht automatisch wahr.</span></div>` : ''}
    <table class="mc24-tab ma24-vt"><tr><th>#</th><th>Vergleich</th><th>${a.typ === 'rent' ? 'Nettokaltmiete' : 'Preis'}</th><th>Fläche</th><th>${a.typ === 'rent' ? '€/m² mtl.' : '€/m²'}</th><th>Bj. / Zustand</th><th>Eignung</th><th>Status</th><th>In Berechnung</th></tr>
    ${r.zeilen.map((z, i) => { const v = z.v, off = MA24.offen[v.id]; return `<tr class="${z.verwendet ? 'verw' : ''}"><td>${i + 1}</td>
      <td><a href="#" onclick="MA24.offen['${v.id}']=!MA24.offen['${v.id}'];renderMain();return false;">${off ? '▾' : '▸'} ${mc24E(v.title.slice(0, 70))}</a><br><small>${mc24E(ma24OrtOeffentlich(v))} · ${mc24E(v.source_name)} · ${mc24LinkHtml(v.source_url, 'öffnen ↗')} · ${mc24E(ma24T(v.verification_status))}</small></td>
      <td>${mc24Eur(ma24Kennwert(v, a.typ))}<br><small>${mc24E(ma24T(v.price_type))}</small></td><td>${mc24Zahl(v.area_sqm)} m²<br><small>${mc24E(ma24T(v.area_type))}${v.plot_sqm ? ' · Grdst. ' + mc24Zahl(v.plot_sqm) + ' m²' : ''}</small></td><td>${mc24Zahl(z.proM2, a.typ === 'rent' ? 2 : 0)}</td>
      <td>${v.year_built || '–'}<br><small>${mc24E(ma24T(v.condition))}</small></td>
      <td><small>KI: ${mc24E(ma24T(v.comparability))}</small><br><select ${dis ? 'disabled' : ''} onchange="ma24VSetzen('${v.id}','eignungNutzer', this.value || null)"><option value="">wie KI</option>${['good', 'limited', 'unsuitable'].map(x => `<option value="${x}" ${v.eignungNutzer === x ? 'selected' : ''}>${ma24T(x)}</option>`).join('')}</select></td>
      <td><select ${dis ? 'disabled' : ''} onchange="ma24VStatus('${v.id}', this.value)">${[['ungeprueft', 'ungeprüft'], ['bestaetigt', '✓ bestätigt'], ['ausgeschlossen', '✕ ausgeschlossen']].map(x => `<option value="${x[0]}" ${v.pruef === x[0] ? 'selected' : ''}>${x[1]}</option>`).join('')}</select></td>
      <td>${z.verwendet ? '✓' : `<small class="mc24-muted">${mc24E(z.grund)}</small>`}${z.dublette && z.dublette.art === 'unsicher' && !dis ? `<br><button class="tiny secondary" onclick="ma24VSetzen('${v.id}','keineDublette',true)">keine Dublette</button>` : ''}${v.included === false && !v.einschliessen && !dis ? `<br><button class="tiny secondary" onclick="ma24VSetzen('${v.id}','einschliessen',true)">trotzdem einbeziehen</button>` : ''}</td></tr>
      ${off ? `<tr class="ma24-detail"><td></td><td colspan="8">${ma24VDetailHtml(v)}</td></tr>` : ''}`; }).join('') || '<tr><td colspan="9" class="mc24-muted">Noch keine Vergleiche – Prompt erstellen und KI-Ergebnis einfügen.</td></tr>'}</table>
    ${(a.unbestaetigt || []).length ? `<div class="mc24-karte"><h3>Unbestätigte Recherchehinweise (nicht in der Berechnung)</h3>${a.unbestaetigt.map(u => `<div class="mc24-z"><span>?</span><div>${mc24E(u.title)}<small>${mc24E(u.source_name)} · ${mc24E(u.reason)}${u.url ? ' · ' + mc24LinkHtml(u.url, 'Link') : ''}</small>${u.snippet ? `<div class="mc24-muted">„${mc24E(u.snippet)}“</div>` : ''}</div></div>`).join('')}</div>` : ''}
    ${gebiet ? `<div class="mc24-hinweis"><b>Zusätzliche Orientierung – Gebietswerte, kein Ersatz für Objektvergleiche:</b> ${mc24E(gebiet)}</div>` : ''}`;
}
function ma24VDetailHtml(v){
  const ev = (v.evidence || []).map(e => `<div class="ma24-beleg">„${mc24E(e.excerpt)}“ <small>(${mc24E((e.fields || []).join(', '))} · ${mc24LinkHtml(e.url, 'Quelle')})</small></div>`).join('') || '<div class="mc24-rot">Kein Quellenbeleg</div>';
  const gr = (v.comparability_reasons || []).map(c => `<tr><td>${mc24E(ma24T(c.criterion))}</td><td>${mc24E(ma24T(c.assessment))}</td><td>${mc24E(c.reason)}</td></tr>`).join('');
  return `<div class="ma24-vdet"><div><b>Belege aus der Quelle</b>${ev}</div>${gr ? `<div><b>Vergleichbarkeit je Merkmal</b><table class="mc24-tab">${gr}</table></div>` : ''}
    <div class="mc24-muted">${(v.missing_fields || []).length ? 'Fehlende Angaben: ' + mc24E(v.missing_fields.join(', ')) + ' · ' : ''}Zimmer ${mc24Zahl(v.rooms, 1)} · Vermietung ${mc24E(ma24T(v.occupancy))}${v.energy ? ' · Energie ' + mc24E([v.energy.certificate_type, v.energy.kwh_sqm_year ? v.energy.kwh_sqm_year + ' kWh/m²a' : '', v.energy.efficiency_class, v.energy.heating].filter(Boolean).join(', ')) : ''}${(v.features || []).length ? ' · ' + mc24E(v.features.join(', ')) : ''} · abgerufen ${mc24Datum(v.accessed_at)}${v.published_at ? ' · veröffentlicht ' + mc24Datum(v.published_at) : ''}${v.warm_rent_eur ? ' · Warmmiete ' + mc24Eur(v.warm_rent_eur) : ''}${v.parking_eur ? ' · Stellplatz ' + mc24Eur(v.parking_eur) : ''}${v.exclusion_reason ? ' · KI-Ausschluss: ' + mc24E(v.exclusion_reason) : ''}${(v.additional_source_urls || []).length ? ' · weitere Links: ' + v.additional_source_urls.map(u => mc24LinkHtml(u, 'Link')).join(', ') : ''}</div>
    <label>Deine Notiz</label><input value="${mc24E(v.notiz || '')}" onchange="ma24VSetzen('${v.id}','notiz', this.value)"></div>`;
}
function ma24VSetzen(vid, feld, wert){ const a = ma24A(); if(ma24Gesperrt(a)) return; const v = a.vergleiche.find(x => x.id === vid); if(!v) return; v[feld] = wert; save(); renderMain(); }
function ma24VStatus(vid, st){ const a = ma24A(); if(ma24Gesperrt(a)) return; const v = a.vergleiche.find(x => x.id === vid); if(!v) return; v.pruef = st; v.geprueftAm = new Date().toISOString(); save(); renderMain(); }
function ma24AlleBestaetigen(){ const a = ma24A(); if(ma24Gesperrt(a)) return; const r = ma24AnalyseAuswerten(a); r.zeilen.filter(z => z.vorlaeufig && z.v.pruef === 'ungeprueft').forEach(z => { z.v.pruef = 'bestaetigt'; z.v.geprueftAm = new Date().toISOString(); }); save(); renderMain(); }
function ma24GebietText(o, a){
  if(!o || typeof aqGebietFinden !== 'function' || typeof MC_MARKT === 'undefined' || a.typ === 'rent') return '';
  try{
    const [gid] = aqGebietFinden(o.ort, o.adresse); if(!gid) return '';
    const g = MC_MARKT.gebiete[gid], whg = o.objektart === 'Wohnung';
    const teile = [];
    if(whg && g.etw) teile.push(`Angebotspreise Wohnungen ${g.name}: ${mc24Zahl(g.etw)} €/m²`);
    if(whg && g.etwKauf) teile.push(`belegte Kaufpreise Wohnungen: ${mc24Zahl(g.etwKauf)} €/m²`);
    if(!whg && g.efh) teile.push(`Angebotspreise Häuser ${g.name}: ${mc24Zahl(g.efh)} €/m²`);
    return teile.length ? teile.join(' · ') + ` (Quelle ${g.quelle || 'Marktdaten'}, Stand ${g.stand || MC_MARKT.stand})` : '';
  }catch(e){ return ''; }
}

// Schritt 5: Ergebnis, Datenqualität, Preisstrategie, Widersprüche
function ma24SchrittErgebnis(a, r, o){
  const dis = a.status === 'abgeschlossen' ? 'disabled' : '';
  const st = r.angebot, ein = a.typ === 'rent' ? 2 : 0;
  const wunsch = a.strategie && a.strategie.wunsch != null ? a.strategie.wunsch : (o ? an24Wert(o, a.typ === 'rent' ? 'miete_ist' : 'kaufpreis') : null);
  const vorschlag = ma24SzenarienVorschlag(r, a.typ);
  const szen = (a.strategie && a.strategie.szenarien) || vorschlag || [];
  const konf = (o ? an24Konflikte(o) : []).map(x => ({ quelle: 'Objektakte', feld: x.feld.l, werte: x.werte.map(w => an24Wtext(x.feld, w.wert) + ' (' + an24L(AN24_HERKUNFT, w.herkunft) + (w.quelle ? ', ' + w.quelle : '') + ')').join(' ↔ '), bedeutung: an24Bedeutung(x.feld), k: x.feld.k }))
    .concat(ma24KiKonflikteOffen(a).map(k => ({ quelle: 'KI-Recherche', feld: k.field, werte: k.values.map(x => String(x.value) + ' (' + x.source + ')').join(' ↔ '), bedeutung: k.significance + (k.question ? ' Rückfrage: ' + k.question : ''), key: k.key })));
  const listeFeld = (feld, titel, ph) => `<div><label>${titel}</label><textarea ${dis} rows="3" placeholder="${mc24E(ph)}" onchange="ma24Liste('${feld}', this.value)">${mc24E((a[feld] || []).join('\n'))}</textarea></div>`;
  return `<div class="mc24-karte"><h3>Ergebnis</h3>
    ${r.spanne && r.spanne.von != null ? `<div class="ma24-band"><div><small>unteres Quartil</small><b>${ma24Wert(a, r.spanne.von)}</b></div><div class="mitte"><small>Median</small><b>${ma24Wert(a, r.spanne.mitte)}</b></div><div><small>oberes Quartil</small><b>${ma24Wert(a, r.spanne.bis)}</b></div></div>` : `<div class="mc24-hinweis"><b>${mc24E(r.spanneGrund || 'Keine belastbare Spanne ableitbar.')}</b>${r.orientierung ? ` Orientierung: Median ${mc24Zahl(r.orientierung.m2Median, ein)} €/m² aus ${r.orientierung.n} Angeboten – keine Spanne.` : ''}</div>`}
    ${st.n ? `<table class="mc24-tab"><tr><th>${mc24E(r.methode.kennwert || 'Kennwert')}</th><th>n</th><th>Min</th><th>unteres Quartil</th><th>Median</th><th>oberes Quartil</th><th>Max</th><th>Streuung</th></tr><tr><td>Angebote</td><td>${st.n}</td><td>${mc24Zahl(st.min, ein)}</td><td>${mc24Zahl(st.q1, ein)}</td><td><b>${mc24Zahl(st.median, ein)}</b></td><td>${mc24Zahl(st.q3, ein)}</td><td>${mc24Zahl(st.max, ein)}</td><td>${st.streuungRel != null ? Math.round(st.streuungRel * 100) + ' %' : '–'}</td></tr>${r.transaktion.n ? `<tr><td>belegte ${a.typ === 'rent' ? 'Bestandsmieten' : 'Verkäufe'} (getrennt)</td><td>${r.transaktion.n}</td><td>${mc24Zahl(r.transaktion.min, ein)}</td><td>${mc24Zahl(r.transaktion.q1, ein)}</td><td>${mc24Zahl(r.transaktion.median, ein)}</td><td>${mc24Zahl(r.transaktion.q3, ein)}</td><td>${mc24Zahl(r.transaktion.max, ein)}</td><td></td></tr>` : ''}</table>` : ''}
    <div><b>Datenqualität: ${mc24E(r.qualitaet.stufe)}</b> – ${mc24E(r.qualitaet.gruende.join('; '))}</div>
    ${a.kiQualitaet ? `<div class="mc24-muted">Einschätzung der recherchierenden KI: ${mc24E(ma24T(a.kiQualitaet.level))} – ${mc24E((a.kiQualitaet.reasons || []).join('; '))}</div>` : ''}
    <details class="gs-details"><summary>Methode</summary><div class="mc24-muted">${mc24E(r.methode.text)} Ausgewertet werden nur geprüfte Vergleiche mit belegtem Preis und belegter Fläche. Median und Quartile (25./75. Perzentil, lineare Interpolation). Spanne erst ab ${MA24_MIN_SPANNE} verwendeten Angeboten. Keine pauschalen Zu- oder Abschläge.</div></details></div>
  <div class="mc24-karte"><h3>Preisstrategie</h3>
    <div class="field-row"><div><label>${a.typ === 'rent' ? 'Mietwunsch Eigentümer (mtl.)' : 'Preisvorstellung Eigentümer'}</label><input ${dis} inputmode="decimal" value="${mc24E(mc24Fmt(wunsch))}" placeholder="unbekannt" onchange="ma24Strat('wunsch', mc24N(this.value))"></div>
      <div><label>Datenbasierte Einschätzung</label><div class="ma24-fix">${r.spanne && r.spanne.von != null ? ma24Wert(a, r.spanne.von) + ' – ' + ma24Wert(a, r.spanne.bis) : 'keine belastbare Spanne'}</div></div>
      <div><label>Vorgeschlagener Angebotspreis</label><input ${dis} inputmode="decimal" value="${mc24E(mc24Fmt(a.strategie && a.strategie.angebotspreis))}" placeholder="noch festlegen" onchange="ma24Strat('angebotspreis', mc24N(this.value))"></div></div>
    ${wunsch != null && r.spanne && r.spanne.mitte != null ? `<div class="mc24-muted">${mc24E(ma24WunschEinordnung(wunsch, r))}</div>` : ''}
    <label>Begründung des Angebotspreises</label><input ${dis} value="${mc24E((a.strategie || {}).begruendung || '')}" onchange="ma24Strat('begruendung', this.value)">
    ${szen.length ? `<table class="mc24-tab"><tr><th>Szenario</th><th>Preis (Annahme, änderbar)</th><th>Resonanz / Verhandlung (qualitativ)</th></tr>${szen.map((s, i) => `<tr><td><b>${mc24E(s.l)}</b><br><small>${mc24E(s.manuell ? 'von dir angepasst' : s.herkunft || '')}</small></td><td><input ${dis} inputmode="decimal" value="${mc24Fmt(s.wert)}" onchange="ma24Szenario(${i}, this.value)" style="max-width:150px;"></td><td class="mc24-muted">${mc24E(s.text)}</td></tr>`).join('')}</table>${vorschlag && !dis ? `<button class="tiny secondary" onclick="ma24Strat('szenarien', null)">Szenarien aus den Daten neu vorschlagen</button>` : ''}` : '<div class="mc24-muted">Ohne belastbare Spanne werden keine Szenarien vorgeschlagen.</div>'}
    <div class="mc24-muted">Keine garantierten Verkaufszeiten oder Abschlusswahrscheinlichkeiten.</div>
    ${(a.kiStrategie || []).length ? `<div class="mc24-muted"><b>Hinweise der recherchierenden KI:</b> ${mc24E(a.kiStrategie.join(' · '))}</div>` : ''}</div>
  ${a.typ === 'rent' ? `<div class="mc24-karte"><h3>Rechtlich zulässige Miete (getrennt vom Marktangebot)</h3>
    <div class="mc24-hinweis">Eine beobachtete Angebotsmiete begründet keine rechtliche Zulässigkeit. Mietpreisbremse, Mietspiegel und Ausnahmen bitte im Mietrechner prüfen – Rechtsstand dort mit Quelle und Datum.</div>
    <div class="field-row"><div><label>Ergebnis Mietrechner (Nettokaltmiete mtl.)</label><input ${dis} inputmode="decimal" value="${mc24Fmt(a.mietrecht && a.mietrecht.wert)}" onchange="ma24Mietrecht('wert', mc24N(this.value))"></div><div><label>Quelle / Grundlage</label><input ${dis} value="${mc24E((a.mietrecht || {}).quelle || '')}" placeholder="z. B. Mietspiegel 2026, Feld …" onchange="ma24Mietrecht('quelle', this.value)"></div><div><label>geprüft am</label><input ${dis} type="date" value="${mc24E((a.mietrecht || {}).am || '')}" onchange="ma24Mietrecht('am', this.value)"></div></div>
    <button class="tiny secondary" onclick="wechsleAnsicht('jv-miete')">🔑 Mietrechner öffnen</button></div>` : ''}
  <div class="mc24-karte"><h3>Widersprüche und Klärung</h3>${konf.length ? konf.map(k => `<div class="mc24-konflikt"><b>${mc24E(k.feld)}</b> <small class="mc24-muted">(${k.quelle})</small>: ${mc24E(k.werte)}<div class="mc24-muted">${mc24E(k.bedeutung)}</div><div class="mc24-knoepfe">${k.k ? `<button class="tiny" onclick="ob24Oeffnen('${a.objektId}')">in der Akte entscheiden</button><button class="tiny secondary" onclick="an24KlaerAufgabe('${a.objektId}','${k.k}')">Rückfrage als Aufgabe</button>` : `<button class="tiny secondary" onclick="ma24KiKonfliktAufgabe(${mc24E(JSON.stringify(k.key))})">Rückfrage als Aufgabe</button><button class="tiny secondary" onclick="ma24KiKonfliktErledigt(${mc24E(JSON.stringify(k.key))})">geklärt</button>`}</div></div>`).join('') : '<div class="vl-leer">Keine offenen Widersprüche.</div>'}</div>
  <div class="mc24-karte"><h3>Stärken, Schwächen, Annahmen, nächste Schritte</h3>
    <div class="field-row">${listeFeld('staerken', 'Stärken (eine pro Zeile)', 'z. B. ruhige Lage, Balkon nach Süden')}${listeFeld('schwaechen', 'Schwächen', 'z. B. kein Aufzug')}</div>
    <div class="field-row">${listeFeld('annahmen', 'Annahmen (werden im Bericht offengelegt)', 'z. B. Wohnfläche laut Eigentümer, nicht aufgemessen')}${listeFeld('naechste', 'Nächste Schritte', 'z. B. Wohnflächenberechnung anfordern')}</div>
    ${(a.kiAnnahmen || []).length ? `<div class="mc24-muted">Von der KI genannte Annahmen (nur übernehmen, wenn sie zutreffen): ${mc24E(a.kiAnnahmen.join(' · '))}</div>` : ''}
    ${listeFeld('offenManuell', 'Weitere offene Punkte (erscheinen im Bericht)', '')}</div>
  <div class="mc24-knoepfe">${a.status === 'abgeschlossen' ? `<span class="mc24-ok">✓ Abgeschlossen am ${mc24Datum(a.abgeschlossenAm)}</span><button class="secondary" onclick="ma24NeueVersion('${a.id}')">⧉ Neue Version für Änderungen</button>` : `<button onclick="ma24Abschliessen()">✓ Analyse abschließen</button><span class="mc24-muted">Speichert den Stand (Eingaben, Vergleiche, Annahmen) unveränderbar als Version ${a.version}.</span>`}</div>`;
}
function ma24Liste(feld, text){ const a = ma24A(); if(ma24Gesperrt(a)) return; a[feld] = String(text || '').split(/\n+/).map(s => s.trim()).filter(Boolean); save(); }
function ma24Strat(k, v){ const a = ma24A(); if(ma24Gesperrt(a)) return; a.strategie = a.strategie || {}; a.strategie[k] = v; save(); renderMain(); }
function ma24Szenario(i, wert){ const a = ma24A(); if(ma24Gesperrt(a)) return; const r = ma24AnalyseAuswerten(a); a.strategie = a.strategie || {}; if(!a.strategie.szenarien) a.strategie.szenarien = ma24SzenarienVorschlag(r, a.typ) || []; const s = a.strategie.szenarien[i]; if(!s) return; s.wert = mc24N(wert); s.manuell = true; save(); renderMain(); }
function ma24Mietrecht(k, v){ const a = ma24A(); if(ma24Gesperrt(a)) return; a.mietrecht = a.mietrecht || {}; a.mietrecht[k] = v; save(); }
function ma24KiKonfliktAufgabe(key){ const a = ma24A(), k = (a.kiKonflikte || []).find(x => x.key === key); if(!k) return; const o = ma24Obj(a); mc24AufgabeAnlegen({ titel: `Klären: ${k.field} (${o ? mc24Titel(o).slice(0, 40) : ''})`, faellig: gsTagPlus(mc24Heute(), 3), objektId: a.objektId, kontaktId: o ? o.eigentuemerId : null, typ: 'klaerung', notiz: (k.question || '') + ' – Werte: ' + k.values.map(x => x.value + ' (' + x.source + ')').join(' / ') }); save(); akqToast('✅ Rückfrage als Aufgabe angelegt'); }
function ma24KiKonfliktErledigt(key){
  const a = ma24A(), k = (a.kiKonflikte || []).find(x => x.key === key); if(!k) return;
  mc24Modal(`<h3>Geklärt: ${mc24E(k.field)}</h3><div class="mc24-muted">${mc24E(k.values.map(x => x.value + ' (' + x.source + ')').join(' ↔ '))}</div><label>Wie wurde es geklärt? (wird mit Datum dokumentiert, die Quellen bleiben erhalten)</label><input id="kk_t">
    <div class="modal-actions"><div></div><div class="right"><button class="secondary" onclick="schliesseModal()">Abbrechen</button><button onclick="ma24KiKonfliktErledigtSpeichern(${mc24E(JSON.stringify(key))})">Speichern</button></div></div>`, 560);
}
function ma24KiKonfliktErledigtSpeichern(key){ const a = ma24A(), k = (a.kiKonflikte || []).find(x => x.key === key), t = document.getElementById('kk_t').value.trim(); if(!k) return; if(!t){ akqToast('Bitte kurz festhalten, wie es geklärt wurde.'); return; } k.erledigt = true; k.entscheidung = { text: t, am: new Date().toISOString() }; save(); schliesseModal(); renderMain(); }
function ma24Abschliessen(){
  const a = ma24A(); if(!a || a.status === 'abgeschlossen') return;
  const r = ma24AnalyseAuswerten(a);
  if(!a.eingabe) ma24EingabeErfassen(a);
  if(!a.strategie.szenarien) a.strategie.szenarien = ma24SzenarienVorschlag(r, a.typ);
  a.status = 'abgeschlossen'; a.abgeschlossenAm = Date.now();
  a.ergebnisStand = { spanne: r.spanne, n: r.anzahl.verwendet, qualitaet: r.qualitaet.stufe };
  const o = ma24Obj(a); if(o && typeof aqLog === 'function') aqLog(o, 'notiz', `Marktanalyse V${a.version} abgeschlossen: ${r.spanne && r.spanne.von != null ? mc24Eur(r.spanne.von) + ' – ' + mc24Eur(r.spanne.bis) : 'keine belastbare Spanne'} (${r.anzahl.verwendet} Vergleiche, Qualität ${r.qualitaet.stufe})`);
  save(); MA24.schritt = 'bericht'; renderMain(); akqToast('✓ Analyse abgeschlossen');
}

// Schritt 6: Eigentümerbericht (öffentlich: ohne genaue Adresse, ohne interne Notizen)
function ma24BerichtBauen(a){
  const o = ma24Obj(a), r = ma24AnalyseAuswerten(a);
  const e = (a.eingabe || {}).werte || {};
  const wertAus = k => { const v = e[k] || (o ? { wert: an24Wert(o, k), herkunft: (an24Aktiv(o, k) || {}).herkunft } : null); return v && v.wert != null ? v : null; };
  const profil = [{ l: 'Objektart', wert: (a.eingabe || {}).objektart || (o && o.objektart) || 'unbekannt' }, { l: 'Lage', wert: ma24OhneAdresse(o ? o.ort : (a.objektGeloescht || {}).ort) || 'unbekannt' }];
  ['wohnflaeche', 'nutzflaeche', 'grundstueck', 'zimmer', 'baujahr', 'zustand', 'vermietung', 'modernisierung', 'energie'].forEach(k => { const v = wertAus(k); if(v) profil.push({ l: an24Feld(k).l, wert: an24Wtext(an24Feld(k), v.wert), herkunft: v.herkunft && v.herkunft !== 'offen' ? an24L(AN24_HERKUNFT, v.herkunft) + (v.pruef === 'geprueft' ? ', geprüft' : '') : (v.pruef === 'geprueft' ? 'geprüft' : 'ohne Nachweis') }); });
  const offen = (o ? an24Konflikte(o).map(x => `${x.feld.l}: abweichende Angaben – wird geklärt`) : [])
    .concat(ma24KiKonflikteOffen(a).map(k => `${k.field}: ${k.question || 'zu klären'}`))
    .concat(((a.eingabe || {}).luecken || []).map(x => x + ': noch unbekannt'))
    .concat(a.offenManuell || []);
  const s = a.strategie || {};
  const wunsch = s.wunsch != null ? s.wunsch : (o ? an24Wert(o, a.typ === 'rent' ? 'miete_ist' : 'kaufpreis') : null);
  const annahmen = (a.annahmen || []).concat(a.flaechenTyp === 'usable' ? ['Vergleich auf Basis Nutzfläche'] : [])
    .concat(['Angaben der Vergleichsobjekte wie im Inserat veröffentlicht (ohne Besichtigung und ohne Prüfung vor Ort).', 'Angebotspreise und Angebotsmieten sind keine belegten Abschlusswerte.'])
    .concat(profil.filter(x => x.herkunft === 'ohne Nachweis' || /^Eigentümerangabe$/.test(x.herkunft || '')).map(x => `${x.l} des Objekts: ${x.herkunft === 'ohne Nachweis' ? 'ohne Nachweis' : 'laut Eigentümer'} übernommen (${x.wert}).`));
  return { titel: `${(a.eingabe || {}).objektart || (o && o.objektart) || 'Immobilie'} in ${ma24OhneAdresse(o ? o.ort : '') || 'Berlin/Brandenburg'}`, datum: mc24Heute(), ersteller: 'Paul Görner · Görner Immobilien',
    analyse: a, auswertung: r, profil, staerken: a.staerken || [], schwaechen: a.schwaechen || [], annahmen, offen, naechste: a.naechste || [], gebiet: ma24GebietText(o, a),
    strategie: { wunsch, wunschText: ma24WunschEinordnung(wunsch, r), szenarien: s.szenarien || ma24SzenarienVorschlag(r, a.typ) || [], angebotspreis: s.angebotspreis, begruendung: s.begruendung } };
}
function ma24BerichtHtmlFuer(a){ let h = ma24BerichtHtml(ma24BerichtBauen(a)); if(a.status !== 'abgeschlossen') h = h.replace('<body>', '<body><div style="color:#b45309;font-weight:700;border:1px solid #f59e0b;padding:4pt 8pt;margin-bottom:8pt;">ENTWURF – Analyse noch nicht abgeschlossen</div>'); return h; }
function ma24SchrittBericht(a, r, o){
  const html = ma24BerichtHtmlFuer(a);
  const pruef = [['Keine genaue Adresse', !(o && o.adresse && html.includes(o.adresse))], ['Keine Kontaktdaten des Eigentümers', !(o && [o.verkaeuferTelefon, o.verkaeuferEmail, o.verkaeuferName].filter(x => x && String(x).length > 3).some(x => html.includes(x)))], ['Keine internen Notizen/Motivation/Einwände', true], ['Quellen als Links', r.anzahl.verwendet === 0 || /href="https?:/.test(html)]];
  return `<div class="mc24-karte"><h3>Vorschau Eigentümerbericht <span class="sp"></span><button class="tiny secondary" onclick="mc24Kopieren(ma24BerichtText(ma24BerichtBauen(ma24A())), '📋 Bericht als Text kopiert')">📋 Text kopieren</button><button class="tiny" onclick="ma24BerichtPdf()">📄 Als PDF speichern</button></h3>
    <div class="ma24-pruef">${pruef.map(([l, ok]) => `<span class="${ok ? 'ok' : 'nein'}">${ok ? '✓' : '✕'} ${l}</span>`).join('')}</div>
    ${a.status !== 'abgeschlossen' ? '<div class="mc24-hinweis">Entwurf: Der Bericht ist als „ENTWURF“ gekennzeichnet, bis die Analyse abgeschlossen ist.</div>' : ''}
    <iframe class="ma24-bericht" sandbox="allow-same-origin" srcdoc="${mc24E(html)}"></iframe>
    ${(a.berichte || []).length ? `<div class="mc24-muted">Bisher erstellt: ${a.berichte.map(b => mc24Datum(b.am) + ' (' + b.art + ')').join(', ')}</div>` : ''}</div>`;
}
async function ma24BerichtPdf(){
  const a = ma24A(); if(!a) return;
  const o = ma24Obj(a);
  const name = `Marktanalyse ${a.typ === 'rent' ? 'Miete' : 'Verkauf'} ${(ma24OhneAdresse(o ? o.ort : '') || 'Objekt').replace(/[^\wäöüÄÖÜß -]/g, '')} ${mc24Heute()}.pdf`;
  const r = await mc24Pdf(ma24BerichtHtmlFuer(a), name);
  if(r && r.ok){ (a.berichte = a.berichte || []).push({ am: new Date().toISOString(), art: 'PDF', name: r.name }); save(); if(aktuelleAnsicht === 'marktanalyse24') renderMain(); }
}

// Schritt 7: Überprüfung nach Vermarktungsstart
function ma24SchrittPruefung(a, r, o){
  const letzte = (a.ueberpruefungen || [])[a.ueberpruefungen.length - 1];
  const start = (letzte && letzte.start) || (o && o.statusAm && ['online'].includes(o.status) ? toDateKey(new Date(o.statusAm)) : '');
  const besKal = o ? (db.termine || []).filter(t => t.objektId === o.id && t.art === 'besichtigung' && (!start || t.datum >= start) && t.datum <= mc24Heute()).length : 0;
  return `<div class="mc24-karte"><h3>Resonanz seit Vermarktungsstart</h3>
    <div class="mc24-muted">Vergleicht die tatsächliche Resonanz mit der damaligen Analyse und schlägt begründete Maßnahmen vor. Es wird nichts automatisch geändert. Keine Kanal-Auswertung, kein Inseratsmonitoring.</div>
    <div class="field-row"><div><label>Vermarktungsstart</label><input type="date" id="up_start" value="${mc24E(start)}"></div><div><label>Stand</label><input type="date" id="up_bis" value="${mc24Heute()}"></div><div><label>Anfragen</label><input type="number" min="0" id="up_anf" value="${letzte && letzte.anfragen != null ? letzte.anfragen : ''}" placeholder="z. B. aus dem Portal"></div><div><label>Besichtigungen</label><input type="number" min="0" id="up_bes" value="${letzte && letzte.besichtigungen != null ? letzte.besichtigungen : besKal || ''}"><small class="mc24-muted">${besKal ? besKal + ' laut Kalender' : ''}</small></div></div>
    <label>Qualifiziertes Feedback (eine Rückmeldung pro Zeile)</label><textarea id="up_fb" rows="3">${mc24E(((letzte || {}).feedback || []).join('\n'))}</textarea>
    <label>Vorliegende Angebote (Beträge, eines pro Zeile)</label><textarea id="up_ang" rows="2">${mc24E(((letzte || {}).angebote || []).join('\n'))}</textarea>
    <div class="mc24-knoepfe"><button onclick="ma24PruefungAuswerten()">Auswerten</button><span class="mc24-muted">Angebotspreis laut Analyse: ${a.strategie && a.strategie.angebotspreis != null ? ma24Wert(a, a.strategie.angebotspreis) : 'nicht festgelegt'}</span></div></div>
    ${(a.ueberpruefungen || []).slice().reverse().map(u => `<div class="mc24-karte"><h3>Überprüfung vom ${mc24Datum(u.am)}</h3><div class="mc24-muted">${mc24E(u.ergebnis.fakten.join(' · '))}</div>
      ${u.ergebnis.vorschlaege.map((v, i) => `<div class="mc24-konflikt"><b>${mc24E(v.l)}</b><div class="mc24-muted">${mc24E(v.grund)}</div>${v.k !== 'ok' ? `<div class="mc24-knoepfe">${v.k === 'preis' ? `<button class="tiny" onclick="ma24PreisAnpassen('${u.id}')">Angebotspreis anpassen …</button>` : ''}<button class="tiny secondary" onclick="ma24MassnahmeAufgabe('${u.id}', ${i})">als Aufgabe</button></div>` : ''}</div>`).join('')}
      ${u.entscheidung ? `<div class="mc24-ok">Entscheidung ${mc24Datum(u.entscheidung.am)}: ${mc24E(u.entscheidung.text)}</div>` : ''}</div>`).join('')}`;
}
function ma24PruefungAuswerten(){
  const a = ma24A(), g = x => document.getElementById(x).value;
  const v = { start: g('up_start'), bis: g('up_bis'), anfragen: g('up_anf') === '' ? null : Number(g('up_anf')), besichtigungen: g('up_bes') === '' ? null : Number(g('up_bes')), feedback: g('up_fb').split(/\n+/).map(s => s.trim()).filter(Boolean), angebote: g('up_ang').split(/\n+/).map(s => mc24N(s.replace(/[^\d.,]/g, ''))).filter(x => x) };
  const r = ma24AnalyseAuswerten(a);
  const erg = ma24Ueberpruefung(v, { angebotspreis: a.strategie ? a.strategie.angebotspreis : null, spanne: r.spanne, typ: a.typ });
  (a.ueberpruefungen = a.ueberpruefungen || []).push(Object.assign({ id: uid(), am: new Date().toISOString(), ergebnis: erg }, v));
  save(); renderMain();
}
function ma24PreisAnpassen(uid_){
  const a = ma24A(), u = (a.ueberpruefungen || []).find(x => x.id === uid_), o = ma24Obj(a);
  const alt = a.strategie ? (a.strategie.angebotspreisAktuell != null ? a.strategie.angebotspreisAktuell : a.strategie.angebotspreis) : null;
  mc24Modal(`<h3>Angebotspreis anpassen</h3><div class="mc24-muted">Wird erst mit „Bestätigen“ übernommen und mit Begründung dokumentiert. Bisher: ${alt != null ? ma24Wert(a, alt) : 'nicht festgelegt'}.</div>
    <div class="field-row"><div><label>Neuer Angebotspreis</label><input id="pa_n" inputmode="decimal"></div></div>
    <label>Begründung</label><input id="pa_b" value="${mc24E(u ? u.ergebnis.vorschlaege.filter(v => v.k === 'preis').map(v => v.grund).join(' ') : '')}">
    ${o && a.typ === 'sale' ? '<label class="gs-chk"><input type="checkbox" id="pa_obj"> Auch im Objekt als aktuellen Preis übernehmen (alter Wert bleibt mit Herkunft gespeichert)</label>' : ''}
    <div class="modal-actions"><div></div><div class="right"><button class="secondary" onclick="schliesseModal()">Abbrechen</button><button onclick="ma24PreisAnpassenSpeichern('${uid_}')">Bestätigen</button></div></div>`, 600);
}
function ma24PreisAnpassenSpeichern(uid_){
  const a = ma24A(), u = (a.ueberpruefungen || []).find(x => x.id === uid_), o = ma24Obj(a);
  const n = mc24N(String(document.getElementById('pa_n').value).replace(/[^\d.,]/g, '')), begr = document.getElementById('pa_b').value.trim();
  if(!n){ akqToast('Bitte einen Betrag eingeben'); return; }
  const alt = a.strategie ? (a.strategie.angebotspreisAktuell != null ? a.strategie.angebotspreisAktuell : a.strategie.angebotspreis) : null;
  (a.preisHistorie = a.preisHistorie || []).push({ am: new Date().toISOString(), von: alt, auf: n, begruendung: begr, ueberpruefungId: uid_ });
  a.strategie = a.strategie || {}; a.strategie.angebotspreisAktuell = n;
  if(u) u.entscheidung = { text: `Angebotspreis ${alt != null ? mc24Eur(alt) : '–'} → ${mc24Eur(n)}${begr ? ': ' + begr : ''}`, am: new Date().toISOString() };
  const chk = document.getElementById('pa_obj');
  if(o && chk && chk.checked) an24Setzen(o, 'kaufpreis', { wert: n, herkunft: 'eigentuemer', quelle: 'Preisanpassung nach Überprüfung ' + mc24Datum(mc24Heute()), von: 'manuell', pruef: 'geprueft' }, { aktivieren: true, entscheidung: begr || 'Preisanpassung bestätigt' });
  save(); schliesseModal(); renderMain();
}
function ma24MassnahmeAufgabe(uid_, i){ const a = ma24A(), u = (a.ueberpruefungen || []).find(x => x.id === uid_); if(!u) return; const v = u.ergebnis.vorschlaege[i]; const o = ma24Obj(a); mc24AufgabeAnlegen({ titel: `${v.l} (${o ? mc24Titel(o).slice(0, 40) : 'Objekt'})`, faellig: gsTagPlus(mc24Heute(), 2), objektId: a.objektId, typ: 'massnahme', notiz: v.grund }); save(); akqToast('✅ Aufgabe angelegt'); }

// ── Einbindung ──
const _ma24RenderMain = renderMain;
renderMain = function(){ if(aktuelleAnsicht === 'marktanalyse24') return ma24Render(document.getElementById('main')); return _ma24RenderMain.apply(this, arguments); };
window.addEventListener('load', () => {
  try{
    const altMA = NAV.find(n => n.key === 'immowert'); if(altMA) altMA.label = 'Wertrechner';
    const i = NAV.findIndex(n => n.key === 'kaeufer');
    if(!NAV.some(n => n.key === 'marktanalyse24')) NAV.splice(i >= 0 ? i + 1 : 2, 0, { key: 'marktanalyse24', label: 'Marktanalyse', icon: '📊' });
    if(typeof IC === 'object'){ IC.marktanalyse24 = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M3 20h18"/><path d="M6 16l4-5 3 3 5-7"/><circle cx="18" cy="7" r="1.6"/></svg>'; }
    renderNav();
  }catch(e){ console.error('Marktanalyse v24', e); }
});
