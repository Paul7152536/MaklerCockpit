# v26: + Zwei Felder betreut/Akquise, Exposé-Import ins Feld (objekte26), Kaufgesuche bis 100 (gesuche26)
# v25: + Name/Telefon überall verbunden (verbund25), Mietvergleich Bezirk/Mietspiegel (mietvergleich25), Abgleich PC ↔ Handy (abgleich25), Handy-Ansicht (handy25)
# v24: + Objektakte/Herkunft (akte24), Marktanalyse mit KI-Import (markt24), Investments (invest24), Akquise-Erweiterung abschaltbar (akquise24)
# v23: + Telefon-Termin / Vor-Ort-Termin überall sichtbar (termin23.js)
# v22: + Suchkunden ohne „keine Makler“, Suchkunden-Tabelle, Suchkunden an jedem Objekt, Kleinanzeigen-Fenster, KI-Gesuche-Suche (kaeufer22.js)
# v21: + Zeitung lesen (PDF/Fotos, lokal), Suchkunden, Seite „Käufer & Markt“ (zeitung21.js, kaeufer21.js), pdf.js + Texterkennung lokal
# v20: + Cloud-Sicherung, Anschreiben-Vorlagen, Preis gesenkt, Preis-Check, Auswertung (extras20.js, markt_kompakt.js)
# v19: + Glocke: Hinweise abhaken, Erinnerungen einstellen
# v18: + Unterlagen zu Objekten (unterlagen.js)
# v17: + PDF-Speichern über das Programm, PDF-Bausteine lokal
# v16: + Exposé-Link Pflicht im Prompt, Exposé-Knopf am Lead
# v15: + dauerhafte Google-Verbindung über eigenes Apps-Skript
# v14: + Google-Kalender-Abgleich (google_sync.js)
# v9: Akquise-Zentrale, eine gemeinsame Navigation (Cockpit + Jarvis), Neustart mit leeren Objekten/Kontakten
p = '/tmp/pc/app/index.html'
s = open(p, encoding='utf8').read()

def rep(a, b, n=1):
    global s
    c = s.count(a)
    assert c == n, (a[:90], c)
    s = s.replace(a, b)

# 1) Navigation: ein System
alt_nav = s[s.index('const NAV = ['):]
alt_nav = alt_nav[:alt_nav.index('];')+2]
neu_nav = '''const NAV = [
  {key:"akquise", label:"Akquise", icon:"🎯"},
  {key:"objekte", label:"Objekte", icon:"🏠"},
  {key:"kontakte", label:"Kontakte", icon:"👤"},
  {key:"hausverwaltungen", label:"Hausverwaltungen", icon:"🏢"},
  {key:"termine", label:"Termine", icon:"📅"},
  {header:"Werkzeuge"},
  {key:"jarvis", label:"Jarvis", icon:"🤖"},
  {key:"jv-suchen", label:"KI-Suche", icon:"🔎"},
  {key:"jv-rechner", label:"Deal-Rechner", icon:"🧮"},
  {key:"jv-miete", label:"Miete & Mietrecht", icon:"🔑"},
  {key:"immowert", label:"Marktanalyse", icon:"📊"},
  {key:"shooting", label:"Shooting-Analyse", icon:"📸"},
  {key:"pdfs", label:"Bilder zu PDF", icon:"📄"},
  {key:"marketing", label:"Marketing", icon:"📣"},
  {key:"jv-warenkorb", label:"Warenkorb", icon:"🛒"},
  {key:"jv-news", label:"News & Recht", icon:"📰"},
  {key:"jv-steuer", label:"Steuer", icon:"🧾"},
  {key:"call-daniel", label:"Call Daniel", icon:"📞"},
];'''
s = s.replace(alt_nav, neu_nav, 1)

# 2) Ansicht Akquise, Start auf Akquise
rep('''  if(aktuelleAnsicht==="dashboard") return renderDashboard(main);
  if(aktuelleAnsicht==="jarvis")''', '''  if(aktuelleAnsicht==="dashboard") return renderDashboard(main);
  if(aktuelleAnsicht==="akquise") return renderAkquise(main);
  if(aktuelleAnsicht==="jarvis")''')
rep('let aktuelleAnsicht = "dashboard";', 'let aktuelleAnsicht = "akquise";')

# 3) Status „Neu“ für frisch eingefügte Anzeigen
rep('''const OBJEKT_STATUS = [
  ["nicht_erreicht","🔴 Nicht erreicht"],''', '''const OBJEKT_STATUS = [
  ["neu","⚪ Neu – noch nicht kontaktiert"],
  ["email_geschrieben","✉️ E-Mail geschrieben"],
  ["kleinanzeigen_geschrieben","💬 Per Kleinanzeigen angeschrieben"],
  ["nicht_erreicht","🔴 Nicht erreicht"],''')
rep('''    {key:"nicht_erreicht", label:"Nicht erreicht", farbe:"b-rot"},''', '''    {key:"neu", label:"Neu", farbe:"b-grau"},
    {key:"email_geschrieben", label:"E-Mail geschrieben", farbe:"b-tuerkis"},
    {key:"kleinanzeigen_geschrieben", label:"Per Kleinanzeigen angeschrieben", farbe:"b-lila"},
    {key:"nicht_erreicht", label:"Nicht erreicht", farbe:"b-rot"},''')

# 4) Neustart beim Programmstart (einmalig, mit Sicherung)
rep('''  aufgabenAufraeumen();
  renderNav();
  renderMain();
}
window.addEventListener('load', startLokal);''', '''  aufgabenAufraeumen();
  try{ akqNeustart(); }catch(e){ console.error('Neustart', e); }
  renderNav();
  renderMain();
}
window.addEventListener('load', startLokal);''')

# 5) Objekte-Liste: Anzeigentitel, Privat-Ampel, Suche über Telefon/E-Mail
rep('''const hay = (o.adresse+" "+o.ort+" "+(eig?eig.name:"")).toLowerCase();''',
    '''const hay = (o.adresse+" "+o.ort+" "+(o.akqTitel||"")+" "+(o.verkaeuferTelefon||"")+" "+(o.verkaeuferEmail||"")+" "+(o.quelle||"")+" "+(eig?eig.name+" "+(eig.telefon||"")+" "+(eig.email||""):"")).toLowerCase();''', 2)
rep('''<b>${esc(o.adresse||o.name||'(ohne Adresse)')}</b><br><span style="color:var(--muted);">${esc(o.ort||'')}</span></td>''',
    '''<b>${esc(o.adresse||o.akqTitel||o.name||'(ohne Adresse)')}</b>${o.privat&&typeof AKQ_PRIVAT_BADGE!=='undefined'?' '+(AKQ_PRIVAT_BADGE[o.privat]||''):''}${(o.dokumente||[]).length?' <span class="dok-zahl" title="Unterlagen">📎 '+o.dokumente.length+'</span>':''}${typeof aqKaeuferBadge==='function'?aqKaeuferBadge(o):''}${typeof twObjektChip==='function'?twObjektChip(o):''}${typeof ob24AkteLink==='function'?ob24AkteLink(o):''}<br><span style="color:var(--muted);">${esc([o.adresse?o.akqTitel:'',o.objektart,o.ort].filter(Boolean).join(' · '))}</span></td>''')
rep('''          <td>${eig ? esc(eig.name) : '<span style="color:var(--muted);">–</span>'}</td>''',
    '''          <td>${eig ? esc(eig.name)+((eig.telefon||eig.email)?'<br><span style="color:var(--muted);font-size:10px;">'+esc(eig.telefon||eig.email)+'</span>':'') : (o.verkaeuferTelefon||o.verkaeuferEmail ? '<span style="font-size:11px;">'+esc(o.verkaeuferTelefon||o.verkaeuferEmail)+'</span>' : '<span style="color:var(--muted);">–</span>')}</td>''')

# 6) Übersicht: Kachel zeigt Akquise statt alter Jarvis-Leads
rep('''${k('Akquise-Leads', leads.filter(l=>l.status==='neu').length+' neu', leads.filter(l=>l.status==='angeschrieben').length+' angeschrieben','jv-akquise')}''',
    '''${k('Akquise', db.objekte.filter(o=>o.status==='neu').length+' neu', 'Suchen & Einfügen','akquise')}''')

# 7) Jarvis-Brücke: Akquise landet im Cockpit, Jarvis kann Ansichten öffnen
rep('''window.__JV_HOST = {
  startTab: 'start',''', '''window.__JV_HOST = {
  startTab: 'start',
  akqEintraege: (liste)=> window.__AKQ ? window.__AKQ.eintraege(liste) : {neuObjekte:0,neuKontakte:0,doppelt:0},
  akqNeu: ()=> (db.objekte||[]).filter(o=>o.status==='neu').length,
  ansicht: (k)=> wechsleAnsicht(k),''')

# 8) Version
# v26: Exposé-Import auf der Objekte-Seite brach am Ende ab (fehlendes Feld) → absichern, Ergebnis im Dialog statt alert
rep('  document.getElementById(\'exposeInput\').value = "";\n  const zweitesFeld', '  { const _ei = document.getElementById(\'exposeInput\'); if(_ei) _ei.value = ""; }\n  const zweitesFeld')
rep("  alert(`${erstellt} Objekt(e) aus Exposé(s) erstellt.${fehler>0 ? `\\n${fehler} Datei(en) konnten nicht gelesen werden.` : ''}\\n\\nName/Telefon/E-Mail sind erstmal Platzhalter (Expose 1, Telefon 1, ...) – bitte im jeweiligen Objekt manuell nachtragen. Alle anderen Werte bitte kurz gegenprüfen, da Exposés sehr unterschiedlich aufgebaut sind.`);",
    "  window.__exposeErgebnis = { erstellt, fehler };")
# v26: Spalte „Eigentümer“ zeigt auch ohne verknüpften Kontakt den eingetragenen Namen
rep("<td>${eig ? esc(eig.name)+((eig.telefon||eig.email)?'<br><span style=\"color:var(--muted);font-size:10px;\">'+esc(eig.telefon||eig.email)+'</span>':'') : (o.verkaeuferTelefon||o.verkaeuferEmail ? '<span style=\"font-size:11px;\">'+esc(o.verkaeuferTelefon||o.verkaeuferEmail)+'</span>' : '<span style=\"color:var(--muted);\">–</span>')}</td>",
    "<td>${(() => { const _n = (typeof aqName === 'function' ? aqName(o) : (eig ? eig.name : o.verkaeuferName)) || ''; const _t = (typeof aqTel === 'function' ? aqTel(o) : (eig ? eig.telefon : o.verkaeuferTelefon)) || (typeof aqMail === 'function' ? aqMail(o) : (eig ? eig.email : o.verkaeuferEmail)) || ''; return _n ? esc(_n) + (_t ? '<br><span style=\"color:var(--muted);font-size:10px;\">' + esc(_t) + '</span>' : '') : (_t ? '<span style=\"font-size:11px;\">' + esc(_t) + '</span>' : '<span style=\"color:var(--muted);\">–</span>'); })()}</td>")
rep("if(r && r.ok){ alert('Import erfolgreich ('+r.anzahl+'). Das Programm lädt jetzt neu.'); location.reload(); }", "if(r && r.ok){ window.__mcNichtSpeichern = true; alert('Import erfolgreich ('+r.anzahl+'). Das Programm lädt jetzt neu.'); location.reload(); }")   # v25: Import nicht vom alten Stand überschreiben
_and = open('/tmp/jvb/android25.js', encoding='utf8').read(); assert '</script' not in _and.lower()
rep('<meta charset="UTF-8">', '<meta charset="UTF-8">\n<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">\n<script>\n' + _and + '\n</script>')   # v25: Handy-Ansicht und Brücke zur Android-App
rep('PC-Version v8', 'PC-Version v55')
rep('''<span>📅 ${esc(t.titel)}</span><span>${esc(t.uhrzeit||'')}</span>''', '''<span>${(typeof twPre==='function'&&twPre(t))||'📅 '}${esc(t.titel)}</span><span>${esc(t.uhrzeit||'')}</span>''')
# v22: fehlende Priorität/Status nicht als „undefined“ anzeigen
rep('return f ? f[1] : key;', "return f ? f[1] : (key == null || key === '' ? '–' : key);")
# 8a3) v21: pdf.js und Texterkennung lokal (offline), neue Seite „Käufer & Markt“
rep('<script src="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js"></script>', '<script src="vendor/pdf.min.js"></script>')
rep("pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';", "pdfjsLib.GlobalWorkerOptions.workerSrc = new URL('vendor/pdf.worker.min.js', location.href).href;")
rep('<script src="https://cdnjs.cloudflare.com/ajax/libs/tesseract.js/5.0.4/tesseract.min.js"></script>', '<script src="vendor/tess/tesseract.min.js"></script>')
rep("await Tesseract.recognize(seitenBilder[i], 'deu');", "await Tesseract.recognize(seitenBilder[i], 'deu', (typeof zlTessOptionen === 'function' ? zlTessOptionen() : {}));")
rep('{key:"objekte", label:"Objekte", icon:"🏠"},', '{key:"objekte", label:"Objekte", icon:"🏠"},\n  {key:"kaeufer", label:"Käufer & Markt", icon:"👥"},')
rep('if(aktuelleAnsicht==="objekte") return renderObjekte(main);', 'if(aktuelleAnsicht==="objekte") return renderObjekte(main);\n  if(aktuelleAnsicht==="kaeufer") return renderKaeufer(main);')
# 8a2) Objekte-Seite: nur Objekte mit Termin im Kalender (v20), umschaltbar auf „Alle“
rep('<div class="sub">Alle Immobilien in Betreuung</div>', '<div class="sub">Objekte mit Termin im Kalender – Leads ohne Termin findest du in der Akquise</div>')
rep('''        <option value="alpha">Alphabetisch (Adresse)</option>
      </select>''', '''        <option value="alpha">Alphabetisch (Adresse)</option>
      </select>
      <select id="objFilterTermin" onchange="objFilterSetzen(this.value)" title="Welche Objekte sollen hier stehen?"><option value="termin" ${typeof X20==='undefined' || X20.objFilter!=='alle' ? 'selected' : ''}>📅 Nur mit Termin</option><option value="alle" ${typeof X20!=='undefined' && X20.objFilter==='alle' ? 'selected' : ''}>Alle (inkl. Akquise-Leads)</option></select>''')
rep('let liste = db.objekte.filter(o=>{', 'let liste = db.objekte.filter(o=>{\n    if(typeof objSichtbar===\'function\' && !objSichtbar(o)) return false;')
# 8a) Objekt-Formular: Anschreiben-Vorschlag aus der Vorlage (v20)
rep('${esc(o.anschreibenText || ANSCHREIBEN_TEXT)}', "${esc(o.anschreibenText || (typeof aqAnschreibenStandard==='function' ? aqAnschreibenStandard(o) : ANSCHREIBEN_TEXT))}")
# 8b) Status-Farbe „E-Mail geschrieben“, Marketing schließt zur Akquise
rep('const map = {nicht_erreicht:"rot",', 'const map = {email_geschrieben:"tuerkis", kleinanzeigen_geschrieben:"lila", nicht_erreicht:"rot",')
rep('''onclick="wechsleAnsicht('dashboard')">✕ Schließen''', '''onclick="wechsleAnsicht('akquise')">✕ Schließen''')

# 8c) PDF: Bausteine lokal statt aus dem Internet, Speichern über das Programm
PDF_PATCH = open('/tmp/jvb/pdf_patch.js', encoding='utf8').read()
assert '</script' not in PDF_PATCH
CDN_JSPDF = '<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>'
CDN_H2C = '<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>'
LOKAL_JSPDF = '<script src="vendor/jspdf.umd.min.js"></script>\n<script>\n' + PDF_PATCH + '\n</script>'
rep(CDN_JSPDF, LOKAL_JSPDF)

# 9) Akquise-Skripte, neues Design und Karte einbinden
import json, re
akq = open('/tmp/jvb/akquise.js', encoding='utf8').read()
akq_ui = open('/tmp/jvb/akquise_ui.js', encoding='utf8').read()
des_js = open('/tmp/jvb/design.js', encoding='utf8').read()
des_css = open('/tmp/jvb/design.css', encoding='utf8').read()
gs_js = open('/tmp/jvb/google_sync.js', encoding='utf8').read()
dok_js = open('/tmp/jvb/unterlagen.js', encoding='utf8').read()
markt_js = open('/tmp/jvb/markt_kompakt.js', encoding='utf8').read()
x20_js = open('/tmp/jvb/extras20.js', encoding='utf8').read()
zl_js = open('/tmp/jvb/zeitung21.js', encoding='utf8').read()
km_js = open('/tmp/jvb/kaeufer21.js', encoding='utf8').read()
kg_js = open('/tmp/jvb/kaeufer22.js', encoding='utf8').read()
tw_js = open('/tmp/jvb/termin23.js', encoding='utf8').read()
v24_js = '\n</script>\n<script>\n'.join(open('/tmp/jvb/'+f, encoding='utf8').read() for f in ['akte24.js','markt24_kern.js','markt24.js','invest24_kern.js','invest24.js','akquise24.js'])
for t in (akq, akq_ui, des_js, des_css, gs_js, dok_js, markt_js, x20_js, zl_js, km_js, kg_js, tw_js): assert '</script' not in t and '</style' not in t
for f in ['akte24.js','markt24_kern.js','markt24.js','invest24_kern.js','invest24.js','akquise24.js']: assert '</script' not in open('/tmp/jvb/'+f, encoding='utf8').read().lower(), f
# v25: Mietrechner-Kern auch im Hauptfenster (Mietspiegel-Vergleich), Brandenburg-Mieten aus den Jarvis-Marktdaten, QR-Code, Module
_mk = json.load(open('/tmp/jvb/markt.json', encoding='utf8'))['GEBIETE']
_bb = {k: {'name': g.get('name'), 'miete': g.get('miete'), 'stand': g.get('stand'), 'quelle': g.get('quelle'), 'plz': g.get('plz') or []} for k, g in _mk.items() if g.get('land') == 'BB'}
V25_DATEI = ['vendor_qrcode.js', 'miete_daten.js', 'miete_kern.js', 'verbund25.js', 'mietvergleich25.js', 'abgleich25_kern.js', 'abgleich25.js', 'handy25.js', 'objekte26.js', 'gesuche26.js', 'vorlagen26.js', 'expose27.js', 'pruefung28.js', 'exposes29.js', 'uhr30.js', 'angeschrieben31.js', 'nachricht31.js', 'autostart32.js', 'pdf33.js', 'nav33.js', 'fehler34.js', 'grossanalyse35.js', 'handy36.js', 'kopier36.js', 'miete37.js', 'miete38_kern.js', 'miete38.js', 'grossanalyse39.js', 'grossanalyse40.js', 'katalog43.js', 'grossanalyse43.js', 'preis43.js', 'dach44.js', 'fragebogen44.js', 'bogen44.js', 'akte45.js', 'shooting46.js', 'akquise47.js', 'pipeline47.js', 'erstkontakt48.js', 'erstkontakt49.js', 'dubletten50.js', 'marketing51.js', 'hv52.js', 'akq54.js', 'ka55.js', 'geraete41.js', 'handy42.js']
for f in V25_DATEI: assert '</script' not in open('/tmp/jvb/'+f, encoding='utf8').read().lower(), f
_pdf33 = json.dumps(open('/tmp/jvb/pdfwerkzeuge33.html', encoding='utf8').read(), ensure_ascii=False).replace('</', '<\\/').replace('<!--', '<\\!--')
v25_js = 'window.MV25_BB_DATEN = ' + json.dumps(_bb, ensure_ascii=False) + ';\nwindow.PDF33_HTML = ' + _pdf33 + ';\nwindow.GA35_MASTER_STD = ' + json.dumps(open('/tmp/jvb/ga35_masterprompt.md', encoding='utf8').read(), ensure_ascii=False).replace('</', '<\\/') + ';\n</script>\n<script>\n' + '\n</script>\n<script>\n'.join(open('/tmp/jvb/'+f, encoding='utf8').read() for f in V25_DATEI)
v24_js = v24_js + '\n</script>\n<script>\n' + v25_js
i = s.index('</head>')
s = s[:i] + '<link rel="stylesheet" href="vendor/leaflet.css">\n<script src="vendor/leaflet.js"></script>\n' + s[i:]
i = s.rindex('</body>')
s = s[:i] + '<style>.b-tuerkis{background:#5fb3b3;color:#111;}.b-lila{background:#a78bfa;color:#111;}\n' + des_css + '</style>\n<script>\n' + akq + '\n</script>\n<script>\n' + akq_ui + '\n</script>\n<script>\n' + des_js + '\n</script>\n<script>\n' + gs_js + '\n</script>\n<script>\n' + dok_js + '\n</script>\n<script>\n' + markt_js + '\n</script>\n<script>\n' + x20_js + '\n</script>\n<script>\n' + zl_js + '\n</script>\n<script>\n' + km_js + '\n</script>\n<script>\n' + kg_js + '\n</script>\n<script>\n' + tw_js + '\n</script>\n<script>\n' + v24_js + '\n</script>\n' + s[i:]
# v25: Google-Brücke Version 2 (Kalender + Abgleich) und Kalender-Regeln für zwei Geräte
_alt_vorlage = s[s.index('const GS_SKRIPT_VORLAGE = '):]
_alt_vorlage = _alt_vorlage[:_alt_vorlage.index('\n')]
s = s.replace(_alt_vorlage, 'const GS_SKRIPT_VORLAGE = ' + json.dumps(open('/tmp/jvb/bruecke_v2.gs', encoding='utf8').read(), ensure_ascii=False) + ';', 1)
rep("for(const id of (db.termine||[]).filter(t=>!t.googleEventId && !t.nurLokal && t.datum && t.datum >= ab && t.datum < bis).map(t=>t.id)){",
    "for(const id of (db.termine||[]).filter(t=>!t.googleEventId && !t.nurLokal && t.datum && t.datum >= ab && t.datum < bis && (typeof ab25DarfAnlegen !== 'function' || ab25DarfAnlegen(t))).map(t=>t.id)){")
rep("      if(ev.status === 'cancelled' || erledigt.has(ev.id) || vk.has(ev.id) || gsCfg().bekannt[ev.id]) continue;",
    "      if(ev.status === 'cancelled' || erledigt.has(ev.id) || vk.has(ev.id) || gsCfg().bekannt[ev.id]) continue;\n      if(typeof ab25ImportErlaubt === 'function' && !ab25ImportErlaubt()) continue;   // v25: Termine, die nur in Google stehen, holt der PC")

# 10) Module (Hausverwaltungen, Marktanalyse, Shooting) im selben Farbschema
THEMA = '<style>:root{--bg:#0a1120;--bg2:#0e1729;--card:#111c30;--border:#1d2b44;--orange:#ff8a3d;--orange-d:#e8662a;--text:#e8eef8;--muted:#8a98b0;--green:#34d399;--red:#f87171;--yellow:#fbbf24;--blue:#60a5fa;--purple:#a78bfa;}</style>'
for name in ['HV_HTML','MA_HTML','SH_HTML']:
    a = s.index('const '+name+' = '); b = s.index('\n', a)
    lit = s[a+len('const '+name+' = '):b].rstrip(';')
    html = json.loads(lit)
    k = html.index('</head>'); html = html[:k] + THEMA + html[k:]
    if name == 'MA_HTML':
        # v20: „Genau prüfen“ am Lead → Marktanalyse übernimmt das Objekt direkt; Leads ohne Adresse mit Anzeigentitel
        def mrep(a, b):
            global html
            assert html.count(a) == 1, (name, a[:70], html.count(a)); html = html.replace(a, b)
        mrep("  if (HOST) setzeStage();\n  render();\n  draftBereit = true;", "  if (HOST) setzeStage();\n  render();\n  draftBereit = true;\n  try{ const v = HOST && HOST.vorwahlHolen && HOST.vorwahlHolen(); if (v) uebernehmeObjekt(v); }catch(e){ console.error(e); }")
        mrep("window.maReload = function(){ if (!HOST) return; setzeStage(); updateObjStatus(); renderSavedList(); };", "window.maReload = function(){ if (!HOST) return; setzeStage(); updateObjStatus(); renderSavedList(); try{ const v = HOST.vorwahlHolen && HOST.vorwahlHolen(); if (v) uebernehmeObjekt(v); }catch(e){ console.error(e); } };")
        mrep("$('objTitle').value = o.adresse || '';", "$('objTitle').value = o.adresse || o.titel || '';")
        mrep("function objektLabel(o){ return (o.adresse || '(ohne Adresse)')", "function objektLabel(o){ return (o.adresse || o.titel || '(ohne Adresse)')")
    if CDN_JSPDF in html:
        html = html.replace(CDN_H2C, '<script src="vendor/html2canvas.min.js"></script>').replace(CDN_JSPDF, LOKAL_JSPDF)
        html = html.replace("status.textContent = 'PDF heruntergeladen.';", "status.textContent = 'PDF erstellt ✓';")
        html = html.replace("pdf.addImage(part.toDataURL('image/png'), 'PNG',", "pdf.addImage(part.toDataURL('image/jpeg', 0.92), 'JPEG',")
        html = html.replace("status.textContent = 'PDF-Export fehlgeschlagen (Zeitüberschreitung). Bitte erneut versuchen.';", "status.textContent = 'PDF-Export fehlgeschlagen' + (e && e.message ? ' (' + (e.message === 'timeout' ? 'Zeitüberschreitung' : e.message) + ')' : '') + '. Bitte erneut versuchen.';")
        assert 'vendor/jspdf.umd.min.js' in html and 'PDF erstellt' in html, name
    neu = json.dumps(html, ensure_ascii=False).replace('</', '<\\/')
    s = s[:a] + 'const '+name+' = ' + neu + ';' + s[b:]
# ── v28: Durchsicht – Sicherheit (keine eingeschleusten Inhalte), Offline, Texte, schnelleres Speichern ──
rep("""${o.notizen||''}</div>""", """${mc28SicherHtml(o.notizen||'')}</div>""")
rep("""href="tel:${k.telefon.replace(/\\s/g,'')}\"""", """href="tel:${mc28Tel(k.telefon)}\"""")
rep("""href="mailto:${k.email}\"""", """href="mailto:${mc28Mail(k.email)}\"""")
rep("""href="tel:${o.verkaeuferTelefon.replace(/\\s/g,'')}\"""", """href="tel:${mc28Tel(o.verkaeuferTelefon)}\"""")
rep("""href="mailto:${o.verkaeuferEmail}\"""", """href="mailto:${mc28Mail(o.verkaeuferEmail)}\"""")
rep("""<a href="tel:${kon.telefon.replace(/\\s/g,'')}">""", """<a href="tel:${mc28Tel(kon.telefon)}">""")
rep("""Überfällige Aufgabe: „${a.titel}“ (fällig war ${a.faellig})""", """Überfällige Aufgabe: „${esc(a.titel)}“ (fällig war ${mc28Datum(a.faellig)})""")
rep("""Heute fällig: „${a.titel}“""", """Heute fällig: „${esc(a.titel)}“""")
rep("""Morgen: „${t.titel}“ – noch keine Notiz""", """Morgen: „${esc(t.titel)}“ – noch keine Notiz""")
rep("""Heute: „${t.titel}“ – für""", """Heute: „${esc(t.titel)}“ – für""")
rep("""<td style="${ueberfaellig?'color:var(--red);font-weight:700;':''}">${a.faellig||'–'}</td>""", """<td style="${ueberfaellig?'color:var(--red);font-weight:700;':''}">${a.faellig?mc28Datum(a.faellig):'–'}</td>""")
rep("""${naechster.datum}${naechster.uhrzeit?' · '+naechster.uhrzeit+' Uhr':''}""", """${mc28Datum(naechster.datum)}${naechster.uhrzeit?' · '+esc(naechster.uhrzeit)+' Uhr':''}""")
rep("""    db = JSON.parse(JSON.stringify(db));\n    const r = window.pc.speichern(JSON.stringify(db));""", """    const _txt = JSON.stringify(db);\n    db = JSON.parse(_txt);\n    const r = window.pc.speichern(_txt);""")
rep('<script src="https://cdnjs.cloudflare.com/ajax/libs/Sortable/1.15.2/Sortable.min.js"></script>', '<script src="vendor/Sortable.min.js"></script>')
rep("""<p>„Guten Tag, mein Name ist Paul Görner. Ich bin auf Ihre Immobilienanzeige in der Zeitung aufmerksam geworden. Ich wollte kurz fragen, ob das Objekt noch zum Verkauf steht?“</p>""", """<p>${mc28LeitfadenStart(o)}</p>""")
rep("""<span id="gespraechChevron" style="color:var(--muted);">${callDanielModalKontext?'▸':'▾'}</span>""", """<span id="gespraechChevron" style="color:var(--muted);">${(callDanielModalKontext||mc28LeitfadenZu(o))?'▸':'▾'}</span>""")
rep("""<div id="gespraechBody" style="display:${callDanielModalKontext?'none':'block'};""", """<div id="gespraechBody" style="display:${(callDanielModalKontext||mc28LeitfadenZu(o))?'none':'block'};""")
rep("quelle: 'Bestand vor v24'", "quelle: 'aus den Objektdaten'")
rep("'Deine Termine an diesem PC.'", "((window.pc && window.pc.geraet === 'handy') ? 'Deine Termine auf diesem Handy.' : 'Deine Termine an diesem PC.')")
assert 'cdnjs.cloudflare.com' not in s.split('const JV_HTML')[0], 'noch Internet-Skripte'
# ── v31: „Nachricht“ öffnet die Anzeige nicht noch einmal, wenn sie schon offen ist ──
rep("""akqKopieren(A.text, o.link ? (art === 'nachfassen' ? 'Nachfass-Text kopiert – Anzeige wird geöffnet, dort einfügen' : 'Nachricht kopiert – Anzeige wird geöffnet, dort einfügen und senden')""", """akqKopieren(A.text, o.link ? ex31Hinweis(o, art)""")
rep("""  if(o.link) window.open(o.link, '_blank');\n  if(art === 'nachfassen') aq2ErgebnisZeigen(""", """  if(o.link && !ex31Offen(o.link)) window.open(o.link, '_blank');\n  if(art === 'nachfassen') aq2ErgebnisZeigen(""")
# ── v34: Durchsicht – eindeutige Kennungen, Reparatur vor dem Speichern, „heute“ nach deutscher Zeit, Texte ──
rep('function uid(){ return "id"+Date.now()+Math.floor(Math.random()*10000); }',
    'function uid(){ uid.z = ((uid.z || 0) + 1) % 1296; return "id" + Date.now() + uid.z.toString(36).padStart(2, "0") + Math.floor(Math.random() * 1679616).toString(36).padStart(4, "0"); }   // v34: eindeutig auch bei vielen Einträgen in derselben Millisekunde')
rep('function uid(){ return \\"id\\"+Date.now()+Math.floor(Math.random()*10000); }',
    "function uid(){ uid.z = ((uid.z || 0) + 1) % 1296; return 'id' + Date.now() + uid.z.toString(36).padStart(2, '0') + Math.floor(Math.random() * 1679616).toString(36).padStart(4, '0'); }")
rep("""    const _txt = JSON.stringify(db);\n    db = JSON.parse(_txt);""", """    try{ if(window.AB25K && AB25K.idsReparieren) AB25K.idsReparieren(db); }catch(e){}\n    const _txt = JSON.stringify(db);\n    db = JSON.parse(_txt);""")
rep("""' · Datenmenge ca. '+kb+' KB, Limit ca. 1000 KB)""", """' · Datenmenge ca. '+kb+' KB · Tipp: Datenträger voll oder Datei von einem anderen Programm gesperrt?)""")
_h1 = s.count('new Date().toISOString().slice(0,10)') + s.count('new Date().toISOString().slice(0, 10)')
s = s.replace('new Date().toISOString().slice(0,10)', 'new Date(Date.now()-new Date().getTimezoneOffset()*6e4).toISOString().slice(0,10)')
s = s.replace('new Date().toISOString().slice(0, 10)', 'new Date(Date.now() - new Date().getTimezoneOffset() * 6e4).toISOString().slice(0, 10)')
s = s.replace('new Date(Date.now()-864e5).toISOString().slice(0,10)', 'new Date(Date.now()-864e5-new Date().getTimezoneOffset()*6e4).toISOString().slice(0,10)')
s = s.replace('new Date(Date.now() - 864e5).toISOString().slice(0, 10)', 'new Date(Date.now() - 864e5 - new Date().getTimezoneOffset() * 6e4).toISOString().slice(0, 10)')
assert _h1 >= 8, _h1
exec(open('/tmp/jvb/v36_block.py', encoding='utf8').read())
exec(open('/tmp/jvb/v37_block.py', encoding='utf8').read())
exec(open('/tmp/jvb/v38_block.py', encoding='utf8').read())
exec(open('/tmp/jvb/v39_block.py', encoding='utf8').read())
exec(open('/tmp/jvb/hv46_block.py', encoding='utf8').read())
exec(open('/tmp/jvb/hv52_block.py', encoding='utf8').read())   # v52: Bild-Anhang + Call-Hilfe fett
open(p, 'w', encoding='utf8').write(s)
print('akq_patch ok', len(s))
