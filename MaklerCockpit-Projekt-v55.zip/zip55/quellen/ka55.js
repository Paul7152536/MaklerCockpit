// ═══ MaklerCockpit v55 – Inserate schneller öffnen (PC) ═══
// Kleinanzeigen-Inserate gehen am PC im eigenen Kleinanzeigen-Fenster auf statt im Browser:
// sofort sichtbar, Werbung/Tracker blockiert, Fenster bleibt im Hintergrund bereit (nächstes Inserat öffnet sofort).
// Andere Portale (ImmoScout usw.) öffnen weiter im Browser. Handy unverändert (Kleinanzeigen-App/Browser).
function ka55Fenster(){ return !!(window.pc && window.pc.geraet === 'pc' && typeof window.pc.webfenster === 'function'); }
function ka55IstKa(u){ return /^https:\/\/([a-z0-9-]+\.)*kleinanzeigen\.de\//i.test(String(u || '')); }
function ka55Oeffnen(u){
  if(ka55Fenster() && ka55IstKa(u)){ window.pc.webfenster('oeffnen', { url: u }).catch(() => window.open(u, '_blank')); return true; }
  return false;
}
(function(){
  if(typeof aqLinkOeffnen === 'function'){
    const _a = aqLinkOeffnen;
    aqLinkOeffnen = function(id){ const o = findObjekt(id); if(o && o.link && ka55Oeffnen(o.link)) return; return _a.apply(this, arguments); };
  }
  if(typeof ak45Inserat === 'function'){
    const _b = ak45Inserat;
    ak45Inserat = function(id){ const o = findObjekt(id), u = typeof ak45Link === 'function' ? ak45Link(o) : (o && o.link); if(u && ka55Oeffnen(u)) return; return _b.apply(this, arguments); };
  }
  // Fenster beim ersten Öffnen der Akquise unsichtbar vorbereiten
  let warm = false;
  const vorwaermen = () => { if(warm || !ka55Fenster()) return; warm = true; setTimeout(() => { try{ window.pc.webfenster('vorwaermen', {}).catch(() => {}); }catch(e){} }, 3000); };
  if(typeof renderAkquise === 'function'){ const _r = renderAkquise; renderAkquise = function(){ const r = _r.apply(this, arguments); vorwaermen(); return r; }; }
  if(typeof renderObjekte === 'function'){ const _o = renderObjekte; renderObjekte = function(){ const r = _o.apply(this, arguments); try{ if(typeof OB26 !== 'undefined' && OB26.aktiv === 'akquise') vorwaermen(); }catch(e){} return r; }; }
})();
