// ═══ MaklerCockpit v48 – Telefontermin-Erstkontakt: immer 8:00, 15 Min je Anruf, alle eines Tages in EINEM Kalendereintrag ═══
// • Im Termin-Dialog am Lead direkt unter „Telefon / Vor Ort“: Knopf „📞 Telefontermin – Erstkontakt“.
// • Jeder Telefontermin mit Erstkontakt landet auf der Anrufliste des Tages (o.anrufTag) – auch schon vorhandene: die werden automatisch zusammengefügt.
// • Im Kalender steht nur, wen du anrufst: Objekt – Name – Telefon. Link, Preis, Notizen usw. stehen im Cockpit (Anrufliste).

// ── Kalendereintrag der Anrufliste: 8:00, 15 Min je Anruf, nur „wen anrufen“ ──
ak47Zeit = function(){ const a = akqDb(); return /^\d{2}:\d{2}$/.test(a.anrufZeit || '') ? a.anrufZeit : '08:00'; };
function ek48Zeile(o){ return [String(aqTitel(o) || 'Objekt').replace(/\s+/g, ' ').trim().slice(0, 60), aqName(o), aqTel(o)].filter(Boolean).join(' – '); }
ak47TerminAktualisieren = function(datum){
  const l = ak47Leads(datum), id = ak47TerminId(datum), t = (db.termine || []).find(x => x.id === id);
  if(!l.length){ if(t){ db.termine = db.termine.filter(x => x.id !== id); } return null; }
  const offen = l.filter(o => o.anrufErledigt !== datum).length;
  const daten = {
    titel: l.length === 1 ? '📞 ' + ek48Zeile(l[0]) : `📞 Anrufen: ${l.length} Telefontermine${offen < l.length ? ` (${offen} offen)` : ''}`,
    datum, uhrzeit: ak47Zeit(), dauer: Math.min(180, 15 * l.length), art: 'rueckruf', artEigene: '', ort: '', wo: 'telefon',
    notiz: l.map(o => (o.anrufErledigt === datum ? '✓ ' : '') + ek48Zeile(o)).join('\n'), objektId: null, kontaktId: null, anrufliste: true };
  if(t){
    if(['titel', 'notiz', 'dauer', 'uhrzeit', 'ort', 'wo'].some(k => t[k] !== daten[k])){ Object.assign(t, daten); t.geaendertAm = Date.now(); }
    return t;
  }
  const neu = Object.assign({ id, createdAt: Date.now(), geaendertAm: Date.now() }, daten);
  db.termine.push(neu); return neu;
};

// ── Vorhandene Telefontermine (Erstkontakt) automatisch in die Anrufliste zusammenfügen ──
function ek48IstErstkontakt(t, o){ return (t.telefonArt || o.telefonArt || ak47TelArtVorschlag(o)) === 'erstkontakt'; }
function ek48Zusammenfuegen(){
  if(!db || !Array.isArray(db.termine) || !Array.isArray(db.objekte)) return 0;
  const h = ak47Heute(), tage = new Set(), weg = new Set();
  for(const t of db.termine){
    if(t.anrufliste || !t.objektId || t.erledigt || !t.datum || t.datum < h || t.bisDatum) continue;
    if(!(t.art === 'rueckruf' || (typeof twWo === 'function' && twWo(t) === 'telefon'))) continue;
    const o = findObjekt(t.objektId); if(!o || !aqTel(o) || !ek48IstErstkontakt(t, o)) continue;
    const alt = o.anrufTag && o.anrufTag >= h ? o.anrufTag : '';
    o.anrufTag = alt && alt < t.datum ? alt : t.datum;
    if(alt && alt !== o.anrufTag) tage.add(alt);
    if(o.anrufErledigt && o.anrufErledigt !== o.anrufTag) delete o.anrufErledigt;
    if(!o.telefonArt) o.telefonArt = 'erstkontakt';
    if(!['termin', 'telefontermin', 'auftrag', 'online', 'abgeschlossen'].includes(o.status)){ o.status = 'telefontermin'; o.statusAm = Date.now(); }
    try{
      if(String(t.notiz || '').trim()) aqLog(o, 'notiz', 'Notiz zum Telefontermin: ' + String(t.notiz).trim());
      aqLog(o, 'termin', '📞 Telefontermin (Erstkontakt) ' + ak47TagKurz(o.anrufTag) + ' in die Anrufliste um ' + ak47Zeit() + ' Uhr übernommen');
    }catch(e){}
    if(t.googleEventId){ try{ const c = gsCfg(); c.zusammen = c.zusammen || {}; c.zusammen[t.googleEventId] = Date.now(); }catch(e){} }
    weg.add(t.id); tage.add(o.anrufTag);
  }
  if(weg.size) db.termine = db.termine.filter(t => !weg.has(t.id));
  tage.forEach(d => ak47TerminAktualisieren(d));
  return weg.size;
}
function ek48AlleListenAktualisieren(){
  const h = ak47Heute(), tage = new Set((db.objekte || []).map(o => o.anrufTag).filter(d => d && d >= h));
  (db.termine || []).filter(t => t.anrufliste && t.datum >= h).forEach(t => tage.add(t.datum));
  let n = 0; tage.forEach(d => { const t = (db.termine || []).find(x => x.id === ak47TerminId(d)), vor = t ? t.geaendertAm : 0; const neu = ak47TerminAktualisieren(d); if(!neu || !t || neu.geaendertAm !== vor) n++; });
  return n;
}
(function(){
  if(typeof _schreibe === 'function'){
    const _s = _schreibe;
    _schreibe = function(){
      try{
        if(ek48Zusammenfuegen()){
          setTimeout(() => { try{ if(typeof gsPlanen === 'function') gsPlanen(800); const mb = document.getElementById('modalBg'); if(!(mb && mb.classList.contains('show'))) renderMain(); }catch(e){} }, 50);
          try{ akqToast('📞 Telefontermin (Erstkontakt) in die Anrufliste um ' + ak47Zeit() + ' Uhr einsortiert', 4000); }catch(e){}
        }
      }catch(e){ console.error('ek48', e); }
      return _s.apply(this, arguments);
    };
  }
  window.addEventListener('load', () => { setTimeout(() => {
    try{
      const a = akqDb(); let n = 0;
      if(!a.ek48){ a.ek48 = true; if(a.anrufZeit === '09:00') a.anrufZeit = '08:00'; n++; }
      n += ek48Zusammenfuegen() + ek48AlleListenAktualisieren();
      if(n){ save(); try{ renderMain(); }catch(e){} if(typeof gsPlanen === 'function') gsPlanen(1500); }
    }catch(e){ console.error('ek48 start', e); }
  }, 400); });
})();

// ── Termin-Dialog am Lead: Knopf „📞 Telefontermin – Erstkontakt“ direkt unter Telefon / Vor Ort ──
function ek48Waehlen(){
  const o = findObjekt(AQ_TQ && AQ_TQ.objektId); if(!o) return;
  AQ_TQ.ek48 = true;
  try{ aq2TqArt('rueckruf'); }catch(e){}
  const r = document.querySelector('input[name="ak47telart"][value="erstkontakt"]'); if(r) r.checked = true;
  try{ twSetzen('tq_wo', 'telefon', true); }catch(e){}
  const g = x => document.getElementById(x);
  if(g('tq_zeit')){ g('tq_zeit').value = ak47Zeit(); g('tq_zeit').disabled = true; }
  const d = g('tq_dauer'); if(d){ if(![...d.options].some(op => op.value === '15')) d.insertAdjacentHTML('afterbegin', '<option value="15">15 Min.</option>'); d.value = '15'; d.disabled = true; }
  if(g('tq_slots')) g('tq_slots').style.display = 'none';
  if(g('tq_titel') && !AQ_TQ.titelManuell) g('tq_titel').value = '📞 Erstkontakt: ' + aqTitel(o);
  const k = g('ek48Knopf'); if(k) k.classList.add('an');
  const hin = g('ek48Hinweis');
  if(hin){
    const tel = aqTel(o);
    hin.innerHTML = tel ? `Landet um <b>${ak47Zeit()} Uhr</b> auf der Anrufliste des Tages (15 Min.). Im Kalender steht nur: <i>${akqEsc(ek48Zeile(o))}</i>. <a href="#" class="ek48-a" onclick="ek48Aus();return false;">anders planen</a>`
      : `<span style="color:#f87171">Keine Telefonnummer am Lead – bitte unten bei „Ort“ die Nummer eintragen.</span> <a href="#" onclick="ek48Aus();return false;">anders planen</a>`;
    hin.style.display = '';
  }
}
function ek48Aus(){
  if(AQ_TQ) AQ_TQ.ek48 = false;
  const g = x => document.getElementById(x);
  if(g('tq_zeit')) g('tq_zeit').disabled = false; if(g('tq_dauer')) g('tq_dauer').disabled = false;
  if(g('tq_slots')) g('tq_slots').style.display = '';
  const k = g('ek48Knopf'); if(k) k.classList.remove('an');
  const hin = g('ek48Hinweis'); if(hin) hin.style.display = 'none';
}
(function(){
  const _neu = aq2TerminNeu;
  aq2TerminNeu = function(art){
    const r = _neu.apply(this, arguments);
    try{
      const box = document.querySelector('#modalInner .tw-box') || document.querySelector('#modalInner .tq-arten');
      if(box && !document.getElementById('ek48Knopf')){
        box.insertAdjacentHTML('afterend', `<button type="button" id="ek48Knopf" class="ek48-knopf" onclick="ek48Waehlen()">📞 Telefontermin – Erstkontakt<small>immer ${ak47Zeit()} Uhr · 15 Min. · alle Anrufe eines Tages in einem Kalendereintrag</small></button><div id="ek48Hinweis" class="ek48-hinweis" style="display:none"></div>`);
      }
    }catch(e){ console.error('ek48 Dialog', e); }
    return r;
  };
  // Wechselt Paul danach die Art (z. B. Besichtigung), ist Erstkontakt wieder aus
  const _art = aq2TqArt;
  aq2TqArt = function(k){ const r = _art.apply(this, arguments); try{ if(k !== 'rueckruf' && AQ_TQ && AQ_TQ.ek48) ek48Aus(); }catch(e){} return r; };
  const _an = aq2TerminAnlegen;
  aq2TerminAnlegen = function(){
    const o = findObjekt(AQ_TQ && AQ_TQ.objektId), ek = !!(AQ_TQ && AQ_TQ.ek48);
    if(!o || !ek) return _an.apply(this, arguments);
    const wahl = document.querySelector('input[name="ak47telart"]:checked');
    if(wahl && wahl.value === 'nachfassen'){ ek48Aus(); return _an.apply(this, arguments); }
    const g = x => document.getElementById(x);
    if(!aqTel(o)){
      const tels = typeof vb47Tels === 'function' ? vb47Tels((g('tq_ort') || {}).value || '') : [];
      if(!tels.length){ akqToast('Für den Erstkontakt fehlt die Telefonnummer – bitte bei „Ort“ eintragen.', 5000); if(g('tq_ort')) g('tq_ort').focus(); return; }
      o.verkaeuferTelefon = tels[0]; aqLog(o, 'info', '📞 Telefonnummer eingetragen: ' + tels[0]);
    }
    const datum = (g('tq_datum') || {}).value; if(!datum) return _an.apply(this, arguments);
    const notiz = ((g('tq_notiz') || {}).value || '').trim();
    const alt = o.anrufTag && o.anrufTag >= ak47Heute() ? o.anrufTag : '';
    o.anrufTag = datum; delete o.anrufErledigt; o.telefonArt = 'erstkontakt';
    if(!['termin', 'auftrag', 'online', 'abgeschlossen'].includes(o.status)){ o.status = 'telefontermin'; o.statusAm = Date.now(); }
    if(notiz) aqLog(o, 'notiz', 'Notiz zum Telefontermin: ' + notiz);
    aqLog(o, 'termin', '📞 Telefontermin (Erstkontakt) am ' + ak47TagKurz(datum) + ' um ' + ak47Zeit() + ' Uhr – auf der Anrufliste');
    if(alt && alt !== datum) ak47TerminAktualisieren(alt);
    ak47TerminAktualisieren(datum);
    save(); schliesseModal(); try{ aq2Neu(); }catch(e){} if(typeof gsPlanen === 'function') gsPlanen(400);
    const n = ak47Leads(datum).length;
    akqToast(`📞 Erstkontakt ${ak47TagKurz(datum)} ${ak47Zeit()} Uhr – ${n === 1 ? 'eigener Kalendereintrag' : 'zusammen mit ' + (n - 1) + ' weiteren in einem Kalendereintrag'}`, 5000);
  };
  // Klick auf die Anrufliste im Kalender → Anrufliste mit allen Infos öffnen
  const _m = oeffneTerminModal;
  oeffneTerminModal = function(id){
    if(typeof id === 'string' && /^anrufliste-\d{4}-\d{2}-\d{2}$/.test(id)){ try{ schliesseModal(); }catch(e){} return ak47ListeDialog(id.slice(11)); }
    return _m.apply(this, arguments);
  };
  // Anrufliste im Cockpit: zusätzlich Erstkontakt/Nachfassen, Inserat-Link, Preis
  const _l = ak47ListeDialog;
  ak47ListeDialog = function(datum){
    const r = _l.apply(this, arguments);
    try{
      document.querySelectorAll('#modalInner .ak47-z').forEach(z => {
        const b = z.querySelector('button[onclick^="ak47Erledigt"]'); const m = b && b.getAttribute('onclick').match(/ak47Erledigt\('([^']+)'/);
        const o = m && findObjekt(m[1]); const info = z.querySelector('.ak47-info'); if(!o || !info || info.querySelector('.ek48-extra')) return;
        const link = /^https?:\/\//i.test(o.link || '') ? `<a href="#" onclick="aqLinkOeffnen('${o.id}');return false;">🔗 Inserat öffnen</a>` : (o.quelle === 'Zeitung' ? '📰 aus der Zeitung' : '');
        const art = o.telefonArt === 'nachfassen' ? '🔁 Nachfassen' : '🆕 Erstkontakt';
        info.insertAdjacentHTML('beforeend', `<div class="ek48-extra">${art}${link ? ' · ' + link : ''}</div>`);
      });
      const zeit = document.querySelector('#modalInner .ak47-zeit');
      if(zeit && !zeit.querySelector('.ek48-k')) zeit.insertAdjacentHTML('beforeend', '<div class="ek48-k mc24-muted">Im Kalender steht nur: Objekt – Name – Telefon. Link und Details stehen hier.</div>');
    }catch(e){ console.error('ek48 Liste', e); }
    return r;
  };
  const st = document.createElement('style');
  st.textContent = `.ek48-knopf{display:flex;flex-direction:column;align-items:flex-start;width:100%;margin:6px 0 4px;padding:9px 12px;border-radius:10px;border:1px dashed #38bdf8;background:rgba(56,189,248,.08);color:#7dd3fc;font-weight:600;text-align:left;cursor:pointer}
.ek48-knopf small{font-weight:400;font-size:11px;color:var(--muted);margin-top:2px}
.ek48-knopf.an{border-style:solid;background:rgba(56,189,248,.2);color:#e0f2fe}
.ek48-hinweis{font-size:12px;margin:2px 0 10px;color:var(--muted)}
.ek48-a,.ek48-extra a{color:#7dd3fc}
.ek48-extra{font-size:12px;color:var(--muted);margin-top:2px}.ek48-k{font-size:11px;margin-top:3px}`;
  document.head.appendChild(st);
})();
