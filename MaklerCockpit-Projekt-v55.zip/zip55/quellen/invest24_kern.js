/* MaklerCockpit v24 – Investment-Rechenkern (deterministisch, ohne Oberfläche, in Node testbar)
   Alle Ergebnisse vor Steuern. Fehlende Werte sind null (nicht 0) und werden als Lücke gemeldet. */

const IV24_JAHRE_MAX = 50;

function iv24N(v){ if(v === null || v === undefined || v === '') return null; const n = Number(v); return isFinite(n) ? n : null; }
function iv24R(x, d){ if(x == null || !isFinite(x)) return null; const f = Math.pow(10, d == null ? 2 : d); return Math.round(x * f) / f; }

// Erwerbsnebenkosten (Prozent vom Kaufpreis oder fester Betrag), jede Position einzeln
function iv24Nebenkosten(kaufpreis, liste){
  const pos = (liste || []).map(p => {
    const w = iv24N(p.wert);
    const betrag = w == null ? null : p.art === 'prozent' ? (kaufpreis || 0) * w / 100 : w;
    return { name: p.name || 'Position', art: p.art, wert: w, betrag };
  });
  const offen = pos.filter(p => p.betrag == null).map(p => p.name);
  return { positionen: pos, summe: pos.reduce((s, p) => s + (p.betrag || 0), 0), offen };
}

// Monatlicher Zins-/Tilgungsplan; Anschlusszins erst nach Ende der Zinsbindung
function iv24Plan(f){
  // f: { darlehen, zins, tilgungModus:'prozent'|'rate', tilgung, rate, zinsbindung (Jahre), anschlusszins, anschlusstilgung, jahre }
  const d = iv24N(f.darlehen) || 0, jahre = Math.min(IV24_JAHRE_MAX, Math.max(1, iv24N(f.jahre) || 30));
  const res = { monate: [], jahre: [], warnungen: [], rate1: 0, restNachBindung: null, annahmen: [] };
  if(d <= 0){ res.restNachBindung = 0; for(let j = 1; j <= jahre; j++) res.jahre.push({ jahr: j, zins: 0, tilgung: 0, rate: 0, rest: 0 }); return res; }
  const z1 = iv24N(f.zins);
  if(z1 == null){ res.fehlt = 'Zinssatz'; return res; }
  const bindung = Math.max(0, Math.round((iv24N(f.zinsbindung) == null ? 10 : iv24N(f.zinsbindung)) * 12));
  let z2 = iv24N(f.anschlusszins);
  if(z2 == null){ z2 = z1; res.annahmen.push('Anschlusszins nicht angegeben – gerechnet mit dem bisherigen Zins (' + z1.toLocaleString('de-DE') + ' %).'); }
  let rate;
  if(f.tilgungModus === 'rate'){ rate = iv24N(f.rate); if(rate == null){ res.fehlt = 'Monatsrate'; return res; } }
  else { const t = iv24N(f.tilgung); if(t == null){ res.fehlt = 'Tilgung'; return res; } rate = d * (z1 + t) / 100 / 12; }
  if(rate <= d * z1 / 100 / 12 + 1e-9) res.warnungen.push('Die Rate deckt nicht einmal die Zinsen – die Restschuld sinkt nicht.');
  res.rate1 = rate;
  let rest = d, zins = z1;
  const anschlussTilg = iv24N(f.anschlusstilgung) == null ? (f.tilgungModus === 'rate' ? null : iv24N(f.tilgung)) : iv24N(f.anschlusstilgung);
  for(let m = 1; m <= jahre * 12; m++){
    if(m === bindung + 1 && bindung > 0){
      res.restNachBindung = rest; zins = z2;
      if(rest > 0) rate = anschlussTilg == null ? rate : rest * (z2 + anschlussTilg) / 100 / 12;
    }
    const zm = rest * zins / 100 / 12;
    const tm = Math.max(0, Math.min(rate - zm, rest));
    const zahlung = rest > 0 ? zm + tm : 0;
    rest = Math.max(0, rest - tm);
    res.monate.push({ m, zins: zm, tilgung: tm, rate: zahlung, rest });
  }
  if(res.restNachBindung == null) res.restNachBindung = bindung === 0 ? d : (res.monate[bindung - 1] || { rest }).rest;
  for(let j = 1; j <= jahre; j++){
    const ms = res.monate.slice((j - 1) * 12, j * 12);
    res.jahre.push({ jahr: j, zins: ms.reduce((s, x) => s + x.zins, 0), tilgung: ms.reduce((s, x) => s + x.tilgung, 0), rate: ms.reduce((s, x) => s + x.rate, 0), rest: ms.length ? ms[ms.length - 1].rest : 0 });
  }
  return res;
}

// Hauptrechnung. ansicht: 'ist' | 'potenzial'
function iv24Rechnen(e, ansicht){
  ansicht = ansicht || 'ist';
  const r = { ansicht, fehlend: [], warnungen: [], annahmen: [], konventionen: [] };
  const kp = iv24N(e.kaufpreis);
  if(kp == null || kp <= 0){ r.fehlend.push('Kaufpreis'); }
  const nk = iv24Nebenkosten(kp || 0, e.nebenkosten);
  if(nk.offen.length) r.fehlend.push('Nebenkosten: ' + nk.offen.join(', '));
  const pot = e.potenzial || {};
  const istPot = ansicht === 'potenzial';
  const sanierungIst = iv24N(e.sanierung) || 0;
  const massnahmen = istPot ? (iv24N(pot.massnahmen) || 0) : 0;
  const sanierung = sanierungIst + massnahmen;
  const finK = iv24N(e.finanzierungskosten) || 0;
  r.kaufpreis = kp; r.nebenkosten = nk; r.sanierung = sanierung; r.finanzierungskosten = finK;
  r.gesamtkapitalbedarf = (kp || 0) + nk.summe + sanierung + finK;
  r.investitionVorFinanzierung = (kp || 0) + nk.summe + sanierung;
  r.konventionen.push('Gesamtkapitalbedarf = Kaufpreis + Erwerbsnebenkosten + anfängliche Maßnahmen + anfängliche Finanzierungskosten (jede Position nur einmal).');
  // Finanzierung
  const ek = iv24N(e.eigenkapital);
  if(ek == null) r.fehlend.push('Eigenkapital');
  const ekW = Math.max(0, ek || 0);
  let darlehen;
  if(e.darlehenModus === 'betrag'){ darlehen = iv24N(e.darlehenBetrag); if(darlehen == null){ darlehen = 0; r.fehlend.push('Darlehensbetrag'); } }
  else if(e.darlehenModus === 'quote'){ const q = iv24N(e.darlehenQuote); if(q == null){ darlehen = 0; r.fehlend.push('Beleihung in % des Kaufpreises'); } else darlehen = (kp || 0) * q / 100; }
  else darlehen = Math.max(0, r.gesamtkapitalbedarf - ekW);
  r.darlehen = darlehen;
  r.eigenkapitalEingesetzt = Math.min(ekW, r.gesamtkapitalbedarf);
  r.eigenkapitalUeberschuss = Math.max(0, ekW - r.gesamtkapitalbedarf);
  r.finanzierungsluecke = Math.max(0, r.gesamtkapitalbedarf - r.eigenkapitalEingesetzt - darlehen);
  r.ueberfinanzierung = Math.max(0, r.eigenkapitalEingesetzt + darlehen - r.gesamtkapitalbedarf);
  if(r.finanzierungsluecke > 0.5) r.warnungen.push(`Finanzierungslücke: ${Math.round(r.finanzierungsluecke).toLocaleString('de-DE')} € sind weder durch Eigenkapital noch Darlehen gedeckt.`);
  if(r.ueberfinanzierung > 0.5) r.warnungen.push('Eigenkapital und Darlehen übersteigen den Kapitalbedarf.');
  const plan = iv24Plan({ darlehen, zins: e.zins, tilgungModus: e.tilgungModus, tilgung: e.tilgung, rate: e.rate, zinsbindung: e.zinsbindung, anschlusszins: e.anschlusszins, anschlusstilgung: e.anschlusstilgung, jahre: Math.max(iv24N(e.jahre) || 15, (iv24N(e.zinsbindung) || 10) + 5) });
  if(plan.fehlt && darlehen > 0) r.fehlend.push(plan.fehlt);
  r.plan = plan; r.warnungen.push(...plan.warnungen); r.annahmen.push(...plan.annahmen);
  // Einnahmen
  const mieteIst = iv24N(e.miete);
  let miete = mieteIst;
  r.potenzialGesichert = null;
  if(istPot){
    const pm = iv24N(pot.miete);
    if(pm == null) r.fehlend.push('Potenzialmiete');
    else miete = pm;
    r.potenzialGesichert = pot.rechtlichGeklaert === 'ja' && pot.pruef === 'geprueft';
    if(!r.potenzialGesichert) r.warnungen.push('Potenzialmiete ist nicht als rechtlich geklärt und geprüft markiert – nicht als gesicherte Einnahme verwenden.');
  }
  if(miete == null) r.fehlend.push('Nettokaltmiete (Ist)');
  const sonst = iv24N(e.sonstigeEinnahmen) || 0;
  const ausfall = iv24N(e.mietausfall); if(ausfall == null) r.annahmen.push('Mietausfall/Leerstand nicht angegeben – mit 0 % gerechnet.');
  const af = (ausfall || 0) / 100;
  r.mieteMonat = miete; r.sonstigeEinnahmen = sonst;
  r.jahresnettokaltmiete = miete == null ? null : miete * 12;
  r.konventionen.push('Jahresnettokaltmiete = monatliche Nettokaltmiete × 12; Stellplatz/sonstige Einnahmen separat.');
  r.bruttomietrendite = r.jahresnettokaltmiete != null && kp ? r.jahresnettokaltmiete / kp * 100 : null;
  r.konventionen.push('Bruttomietrendite = Jahresnettokaltmiete / Kaufpreis × 100.');
  r.kaufpreisfaktor = r.jahresnettokaltmiete ? kp / r.jahresnettokaltmiete : null;
  // Kosten (monatlich)
  const hg = iv24N(e.hausgeld), hgU = iv24N(e.hausgeldUmlagefaehig), rl = iv24N(e.ruecklage) || 0;
  let hgNichtUml = 0, hgBetrieb = 0, hgOk = true;
  if(hg != null && hg > 0){
    if(hgU == null){ hgOk = false; r.fehlend.push('Aufteilung Hausgeld (umlagefähiger Anteil)'); }
    else {
      if(hgU > hg) r.warnungen.push('Umlagefähiger Anteil ist größer als das Hausgeld – Aufteilung prüfen.');
      hgNichtUml = Math.max(0, hg - hgU);
      if(rl > hgNichtUml + 1e-9) r.warnungen.push('Rücklagenzuführung ist größer als der nicht umlagefähige Hausgeldanteil – Wirtschaftsplan prüfen (Rücklage ist nie umlagefähig).');
      hgBetrieb = Math.max(0, hgNichtUml - rl);
    }
  } else if(rl > 0 && (hg == null || hg === 0)) r.annahmen.push('Rücklagenzuführung ohne Hausgeld angegeben – als eigene Liquiditätsvorsorge gerechnet.');
  const verw = iv24N(e.verwaltung) || 0, sonstK = iv24N(e.sonstigeKosten) || 0;
  const ausfallUmlage = (hgU || 0) * af;   // bei Leerstand bleiben umlagefähige Kosten beim Eigentümer
  const instEingabe = iv24N(e.instandhaltung) || 0;
  const instZus = e.instandhaltungModus === 'gesamt' ? Math.max(0, instEingabe - rl) : instEingabe;
  if(e.instandhaltungModus === 'gesamt' && instEingabe && instEingabe < rl) r.annahmen.push('Instandhaltung gesamt ist kleiner als die Rücklagenzuführung – zusätzlich wird nichts angesetzt.');
  r.kosten = { hausgeldNichtUmlagefaehig: hgNichtUml, hausgeldBetrieb: hgBetrieb, ruecklage: rl, verwaltung: verw, sonstige: sonstK, ausfallUmlage, instandhaltungZusaetzlich: instZus };
  r.eigentuemerkosten = hgBetrieb + verw + sonstK + ausfallUmlage;
  r.liquiditaetsvorsorge = rl + instZus;
  r.konventionen.push('Hausgeld wird aufgeteilt: umlagefähiger Anteil zahlt der Mieter; Eigentümerkosten = nicht umlagefähiges Hausgeld ohne Rücklage + Verwaltung + sonstige nicht umlagefähige Kosten + bei Leerstand nicht gedeckte Umlagen.');
  r.konventionen.push('Liquiditätsvorsorge = Rücklagenzuführung + zusätzlich geplante Instandhaltung (bei „gesamt“ wird die Rücklage abgezogen, damit nichts doppelt zählt).');
  const einnahmenNachAusfall = miete == null ? null : (miete + sonst) * (1 - af);
  r.einnahmenNachAusfall = einnahmenNachAusfall;
  const rechenbar = einnahmenNachAusfall != null && hgOk && kp;
  r.ueberschussVorFinanzierung = rechenbar ? einnahmenNachAusfall - r.eigentuemerkosten - r.liquiditaetsvorsorge : null;
  r.nettorendite = rechenbar && r.investitionVorFinanzierung ? r.ueberschussVorFinanzierung * 12 / r.investitionVorFinanzierung * 100 : null;
  r.konventionen.push('Nettorendite vor Finanzierung = (Einnahmen nach Mietausfall − Eigentümerkosten − Liquiditätsvorsorge) × 12 / (Kaufpreis + Erwerbsnebenkosten + anfängliche Maßnahmen) × 100. Finanzierungskosten sind nicht im Nenner.');
  // Schuldendienst Jahr 1 (aus dem Tilgungsplan, nicht konstant unterstellt)
  const j1 = plan.jahre[0] || { zins: 0, tilgung: 0, rate: 0 };
  r.zinsJahr1 = j1.zins; r.tilgungJahr1 = j1.tilgung; r.schuldendienstMonat = j1.rate / 12;
  r.cashflowMonat = rechenbar && !(plan.fehlt && darlehen > 0) ? r.ueberschussVorFinanzierung - r.schuldendienstMonat : null;
  r.konventionen.push('Cashflow vor Steuern = Einnahmen nach Mietausfall − Eigentümerkosten − Liquiditätsvorsorge − Schuldendienst (Zins + Tilgung), alles monatlich, Jahr 1.');
  r.konventionen.push('Tilgung ist Liquiditätsabfluss und zugleich Vermögensaufbau – sie wird beim Cashflow abgezogen und separat als Vermögensaufbau gezeigt.');
  r.vermoegensaufbauMonat = j1.tilgung / 12;
  r.ekRendite = r.cashflowMonat != null && r.eigenkapitalEingesetzt > 0 ? r.cashflowMonat * 12 / r.eigenkapitalEingesetzt * 100 : null;
  r.ekRenditeHinweis = r.eigenkapitalEingesetzt > 0 ? '' : 'Ohne eingesetztes Eigenkapital ist die Eigenkapitalrendite nicht definiert (keine „unendliche“ Rendite).';
  // Potenzial: Leerstandsphase im ersten Jahr
  if(istPot && rechenbar){
    const leer = Math.min(12, Math.max(0, iv24N(pot.leerstandMonate) || 0));
    r.cashflowJahr1 = r.cashflowMonat * 12 - leer * (miete + sonst) * (1 - af) - leer * (hgU || 0) * (1 - af);
    r.annahmen.push(`Potenzial: ${leer} Monat(e) Leerstand während der Maßnahmen im ersten Jahr${iv24N(pot.zeitbedarfMonate) ? ', Zeitbedarf ' + iv24N(pot.zeitbedarfMonate) + ' Monate' : ''}.`);
  } else r.cashflowJahr1 = r.cashflowMonat != null ? r.cashflowMonat * 12 : null;
  // Liquidität
  r.liquiditaetZumKauf = r.eigenkapitalEingesetzt + r.finanzierungsluecke;
  r.restschuldNachBindung = plan.restNachBindung;
  // Mehrjahresübersicht (Mietsteigerung, Kostensteigerung, Anschlusszins ab Ende Zinsbindung)
  const ms = (iv24N(e.mietsteigerung) || 0) / 100, ks = (iv24N(e.kostensteigerung) || 0) / 100;
  r.jahre = [];
  if(rechenbar){
    let summeUnterdeckung = 0;
    plan.jahre.forEach((pj, i) => {
      const ein = (miete * Math.pow(1 + ms, i) + sonst) * (1 - af) * 12;
      const kos = (r.eigentuemerkosten + r.liquiditaetsvorsorge) * Math.pow(1 + ks, i) * 12;
      let cf = ein - kos - pj.rate;
      if(i === 0 && istPot) cf = r.cashflowJahr1;   // Leerstandsphase der Maßnahmen im ersten Jahr
      if(cf < 0 && i < (iv24N(e.zinsbindung) || 10)) summeUnterdeckung += -cf;
      r.jahre.push({ jahr: pj.jahr, einnahmen: ein, kosten: kos, zins: pj.zins, tilgung: pj.tilgung, schuldendienst: pj.rate, cashflow: cf, restschuld: pj.rest });
    });
    r.unterdeckungBisBindungsende = summeUnterdeckung;
    const nachBindung = r.jahre[Math.round(iv24N(e.zinsbindung) == null ? 10 : iv24N(e.zinsbindung))];
    r.cashflowNachBindungMonat = nachBindung ? nachBindung.cashflow / 12 : null;
  }
  r.ok = !r.fehlend.length;
  return r;
}

// Szenarien: editierbare Annahmen werden auf eine Kopie der Eingaben angewendet
const IV24_SZENARIEN_STD = {
  vorsichtig: { l: 'Vorsichtig', miete: -5, mietausfall: 5, kosten: 10, sanierung: 20, zins: 0, anschlusszins: 1.5, mietsteigerung: 0 },
  basis: { l: 'Basis', miete: 0, mietausfall: null, kosten: 0, sanierung: 0, zins: 0, anschlusszins: 0, mietsteigerung: null },
  optimistisch: { l: 'Optimistisch', miete: 3, mietausfall: 1, kosten: -5, sanierung: -10, zins: 0, anschlusszins: -0.5, mietsteigerung: null }
};
function iv24MitAnnahmen(e, s){
  const x = JSON.parse(JSON.stringify(e));
  const f = (v, p) => v == null || v === '' ? v : Number(v) * (1 + (Number(p) || 0) / 100);
  x.miete = f(e.miete, s.miete);
  if(x.potenzial) x.potenzial.miete = f(e.potenzial.miete, s.miete);
  if(s.mietausfall != null && s.mietausfall !== '') x.mietausfall = Number(s.mietausfall);
  ['verwaltung', 'sonstigeKosten', 'instandhaltung'].forEach(k => { x[k] = f(e[k], s.kosten); });
  if(e.hausgeld != null && e.hausgeld !== '' && e.hausgeldUmlagefaehig != null && e.hausgeldUmlagefaehig !== ''){
    const nu = Number(e.hausgeld) - Number(e.hausgeldUmlagefaehig), rl = Number(e.ruecklage) || 0;
    const betrieb = Math.max(0, nu - rl) * (1 + (Number(s.kosten) || 0) / 100);
    x.hausgeld = Number(e.hausgeldUmlagefaehig) + rl + betrieb;
  }
  x.sanierung = f(e.sanierung, s.sanierung);
  if(x.potenzial) x.potenzial.massnahmen = f(e.potenzial.massnahmen, s.sanierung);
  if(s.zins) x.zins = (Number(e.zins) || 0) + Number(s.zins);
  if(s.anschlusszins) x.anschlusszins = (e.anschlusszins == null || e.anschlusszins === '' ? Number(e.zins) || 0 : Number(e.anschlusszins)) + Number(s.anschlusszins);
  if(s.mietsteigerung != null && s.mietsteigerung !== '') x.mietsteigerung = Number(s.mietsteigerung);
  return x;
}
function iv24Szenarien(e, annahmen, ansicht){
  const a = annahmen || IV24_SZENARIEN_STD;
  return Object.keys(a).map(k => ({ k, l: a[k].l, annahmen: a[k], r: iv24Rechnen(iv24MitAnnahmen(e, a[k]), ansicht) }));
}
function iv24Stress(e, ansicht){
  const base = iv24Rechnen(e, ansicht);
  const faelle = [
    { k: 'keineSteigerung', l: 'Keine Mietsteigerung', e: Object.assign({}, e, { mietsteigerung: 0 }) },
    { k: 'sanierung', l: 'Sanierung 30 % teurer', e: Object.assign(JSON.parse(JSON.stringify(e)), { sanierung: (Number(e.sanierung) || 0) * 1.3, potenzial: e.potenzial ? Object.assign({}, e.potenzial, { massnahmen: (Number(e.potenzial.massnahmen) || 0) * 1.3 }) : e.potenzial }) },
    { k: 'anschluss', l: 'Anschlusszins +2 Prozentpunkte', e: Object.assign({}, e, { anschlusszins: (e.anschlusszins == null || e.anschlusszins === '' ? Number(e.zins) || 0 : Number(e.anschlusszins)) + 2 }) }
  ];
  return { basis: base, faelle: faelle.map(f => ({ k: f.k, l: f.l, r: iv24Rechnen(f.e, ansicht) })) };
}

// Maximaler Kaufpreis: numerisch zurückgerechnet, danach Vorwärts-Gegenprobe
function iv24Kennzahl(r, art){ return art === 'cashflow' ? r.cashflowMonat : art === 'brutto' ? r.bruttomietrendite : art === 'netto' ? r.nettorendite : art === 'ekRendite' ? r.ekRendite : null; }
function iv24MaxPreis(e, ziel, ansicht){
  // ziel: { art:'cashflow'|'brutto'|'netto'|'ekRendite', wert, finanzierungGedeckt:true|false }
  const art = ziel.art, soll = iv24N(ziel.wert);
  const res = { art, soll, preis: null, grenzen: [], erklaerung: '', gegenprobe: null };
  if(soll == null){ res.erklaerung = 'Kein Zielwert angegeben.'; return res; }
  const rechne = p => iv24Rechnen(Object.assign({}, e, { kaufpreis: p }), ansicht);
  const erfuellt = p => {
    const r = rechne(p), k = iv24Kennzahl(r, art);
    if(k == null) return { ok: false, r, grund: art === 'ekRendite' && r.eigenkapitalEingesetzt <= 0 ? 'Eigenkapitalrendite ist ohne Eigenkapital nicht definiert.' : 'Kennzahl nicht berechenbar: ' + r.fehlend.join(', ') };
    if(k < soll - 1e-9) return { ok: false, r, grund: '' };
    if(ziel.finanzierungGedeckt && r.finanzierungsluecke > 0.5) return { ok: false, r, grund: 'luecke' };
    return { ok: true, r };
  };
  const klein = erfuellt(1000);
  if(!klein.ok){
    if(klein.grund && klein.grund !== 'luecke'){ res.erklaerung = klein.grund; return res; }
    const k = iv24Kennzahl(klein.r, art);
    res.erklaerung = klein.grund === 'luecke' ? 'Selbst bei sehr niedrigem Kaufpreis bleibt eine Finanzierungslücke (Darlehen/Eigenkapital reichen nicht für Nebenkosten und Maßnahmen).'
      : `Unter diesen Annahmen nicht erreichbar: Selbst bei einem Kaufpreis nahe 0 € liegt ${art === 'cashflow' ? 'der Cashflow bei ' + Math.round(k).toLocaleString('de-DE') + ' €/Monat' : 'die Kennzahl bei ' + (k == null ? '–' : k.toFixed(2).replace('.', ',') + ' %')} – laufende Kosten oder Schuldendienst unabhängig vom Preis sind zu hoch bzw. die Miete zu niedrig.`;
    return res;
  }
  let lo = 1000, hi = 1000;
  while(hi < 1e9 && erfuellt(hi * 2).ok) hi *= 2;
  hi = hi * 2;
  if(hi >= 1e9){ res.erklaerung = 'Ziel wird bei jedem Preis erreicht – Eingaben prüfen (Miete/Finanzierung).'; return res; }
  for(let i = 0; i < 80 && hi - lo > 1; i++){ const mid = (lo + hi) / 2; if(erfuellt(mid).ok) lo = mid; else hi = mid; }
  let preis = Math.floor(lo / 100) * 100;
  for(let i = 0; i < 5 && erfuellt(preis + 100).ok; i++) preis += 100;   // genaue Grenze auf 100 € treffen
  const g = erfuellt(preis), naechster = erfuellt(preis + 100);
  res.preis = preis;
  res.gegenprobe = { kennzahl: iv24Kennzahl(g.r, art), erfuellt: g.ok, luecke: g.r.finanzierungsluecke, cashflow: g.r.cashflowMonat, nebenkosten: g.r.nebenkosten.summe, darlehen: g.r.darlehen, naechsterErfuellt: naechster.ok };
  res.erklaerung = 'Unter diesen Annahmen höchster Kaufpreis (auf 100 € abgerundet). Prozentuale Nebenkosten und kaufpreisabhängige Finanzierung wurden bei jedem Preis neu berechnet.';
  if(naechster.grund === 'luecke') res.grenzen.push('Begrenzt durch die Finanzierung (darüber entsteht eine Finanzierungslücke).');
  return res;
}

// Ankaufprofil gegen ein Objekt prüfen (Muss/Soll, ohne Gesamtscore)
function iv24ProfilPruefen(profil, objekt, r){
  const l = [];
  const add = (k, l2, muss, status, grund) => l.push({ k, l: l2, muss, status, grund });
  const kr = profil.kriterien || {};
  const art = kr.objektarten || {}, reg = kr.regionen || {}, bud = kr.budget || {}, cf = kr.cashflow || {}, ren = kr.rendite || {}, san = kr.sanierung || {}, verm = kr.vermietung || {}, eig = kr.eigenmittel || {};
  if((art.werte || []).length){ const ok = art.werte.includes(objekt.objektart); add('art', 'Objektart', art.muss, objekt.objektart ? (ok ? 'ok' : 'nein') : 'unbekannt', objekt.objektart ? `${objekt.objektart}${ok ? '' : ' nicht in ' + art.werte.join(', ')}` : 'Objektart unbekannt'); }
  if((reg.werte || []).length){ const ort = String(objekt.ort || '').toLowerCase(); const t = reg.werte.find(x => x && ort.includes(String(x).toLowerCase())); add('region', 'Region', reg.muss, ort ? (t ? 'ok' : 'nein') : 'unbekannt', ort ? (t ? 'liegt in ' + t : (objekt.ort || '') + ' nicht in ' + reg.werte.join(', ')) : 'Ort unbekannt'); }
  if(iv24N(bud.wert) != null) add('budget', 'Gesamtkapitalbedarf ≤ Budget', bud.muss, r.kaufpreis ? (r.gesamtkapitalbedarf <= Number(bud.wert) ? 'ok' : 'nein') : 'unbekannt', `${Math.round(r.gesamtkapitalbedarf).toLocaleString('de-DE')} € von ${Number(bud.wert).toLocaleString('de-DE')} €`);
  if(iv24N(eig.wert) != null) add('eigenmittel', 'Eigenmittelbedarf ≤ verfügbar', eig.muss, (r.liquiditaetZumKauf <= Number(eig.wert)) ? 'ok' : 'nein', `benötigt ${Math.round(r.liquiditaetZumKauf).toLocaleString('de-DE')} € (inkl. Finanzierungslücke), verfügbar ${Number(eig.wert).toLocaleString('de-DE')} €`);
  if(iv24N(cf.wert) != null) add('cashflow', 'Monatlicher Cashflow', cf.muss, r.cashflowMonat == null ? 'unbekannt' : r.cashflowMonat >= Number(cf.wert) ? 'ok' : 'nein', r.cashflowMonat == null ? 'nicht berechenbar: ' + r.fehlend.join(', ') : `${Math.round(r.cashflowMonat).toLocaleString('de-DE')} €/Monat, Ziel ${Number(cf.wert).toLocaleString('de-DE')} €`);
  if(iv24N(ren.wert) != null){ const k = ren.art === 'netto' ? r.nettorendite : r.bruttomietrendite; add('rendite', ren.art === 'netto' ? 'Nettorendite' : 'Bruttomietrendite', ren.muss, k == null ? 'unbekannt' : k >= Number(ren.wert) ? 'ok' : 'nein', k == null ? 'nicht berechenbar' : `${k.toFixed(2).replace('.', ',')} %, Ziel ${String(ren.wert).replace('.', ',')} %`); }
  if(iv24N(san.wert) != null) add('sanierung', 'Sanierungsaufwand', san.muss, r.sanierung <= Number(san.wert) ? 'ok' : 'nein', `${Math.round(r.sanierung).toLocaleString('de-DE')} € von max. ${Number(san.wert).toLocaleString('de-DE')} €`);
  if(verm.wert && verm.wert !== 'egal') add('vermietung', 'Vermietungsstatus', verm.muss, !objekt.vermietung || objekt.vermietung === 'unbekannt' ? 'unbekannt' : objekt.vermietung === verm.wert ? 'ok' : 'nein', `Objekt: ${objekt.vermietung || 'unbekannt'}, gewünscht: ${verm.wert}`);
  (kr.ausschluss || []).filter(Boolean).forEach((x, i) => add('aus' + i, 'Ausschluss: ' + x, true, 'pruefen', 'manuell prüfen – bitte als erfüllt/nicht erfüllt markieren'));
  const mussVerletzt = l.filter(x => x.muss && x.status === 'nein');
  return { liste: l, mussVerletzt: mussVerletzt.length, offen: l.filter(x => x.status === 'unbekannt' || x.status === 'pruefen').length };
}

// Unterlagen je Objektart
const IV24_UNTERLAGEN = {
  basis: ['Grundbuchauszug (aktuell)', 'Flächenunterlagen (Wohnflächenberechnung/Grundriss)', 'Energieausweis', 'Baubeschreibung/Modernisierungsnachweise'],
  Wohnung: ['Mietvertrag/Mietaufstellung', 'Nachweis tatsächlicher Mieteingänge', 'Wirtschaftsplan (Hausgeld)', 'Hausgeldabrechnungen (3 Jahre)', 'Stand Erhaltungsrücklage', 'WEG-Protokolle und Beschlusssammlung (3 Jahre)', 'Geplante Maßnahmen / Sonderumlagen', 'Teilungserklärung'],
  MFH: ['Mietaufstellung (alle Einheiten)', 'Mietverträge (alle)', 'Nachweis tatsächlicher Mieteingänge', 'Betriebskostenabrechnungen (2 Jahre)', 'Instandhaltungs- und Modernisierungshistorie', 'Geplante Maßnahmen', 'Baulastenverzeichnis'],
  Haus: ['Mietvertrag (falls vermietet)', 'Nachweis tatsächlicher Mieteingänge (falls vermietet)', 'Baulastenverzeichnis', 'Bebauungsplan/Planungsrecht'],
  Grundstück: ['Baulastenverzeichnis', 'Bebauungsplan/Planungsrecht', 'Bodenrichtwert/Bodengutachten', 'Altlastenauskunft'],
  Gewerbe: ['Mietverträge Gewerbe', 'Nachweis tatsächlicher Mieteingänge', 'Nebenkostenabrechnungen', 'Geplante Maßnahmen']
};
function iv24UnterlagenListe(objektart){
  const g = objektart === 'Wohnung' ? 'Wohnung' : objektart === 'MFH' ? 'MFH' : objektart === 'Grundstück' ? 'Grundstück' : objektart === 'Gewerbe' ? 'Gewerbe' : 'Haus';
  const basis = g === 'Grundstück' ? ['Grundbuchauszug (aktuell)'] : IV24_UNTERLAGEN.basis;
  return basis.concat(IV24_UNTERLAGEN[g]);
}

if(typeof module !== 'undefined') module.exports = { iv24Rechnen, iv24Plan, iv24Nebenkosten, iv24Szenarien, iv24Stress, iv24MaxPreis, iv24MitAnnahmen, iv24ProfilPruefen, iv24UnterlagenListe, IV24_SZENARIEN_STD, iv24Kennzahl };
