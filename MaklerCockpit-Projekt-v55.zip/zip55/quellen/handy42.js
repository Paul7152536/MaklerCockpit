// ═══ MaklerCockpit v42 – Handy: Daten-Sicherung außerhalb der App und Wiederherstellen aus Datei ═══
// Die App (ab v18) legt täglich eine Sicherung in Downloads/MaklerCockpit/Sicherungen ab; die bleibt beim Deinstallieren oder „App-Daten löschen“ erhalten.
function mc42JetztSichern(){
  if(!window.pc || typeof window.pc.sicherungExtern !== 'function'){ akqToast('Nur in der Handy-App'); return; }
  const r = window.pc.sicherungExtern(JSON.stringify(db), 'manuell');
  akqToast(r && r.ok ? '💾 Gesichert in Downloads/MaklerCockpit/Sicherungen' : '⚠️ Sicherung nicht möglich: ' + ((r && r.fehler) || ''), 5000);
}
function mc42Zahlen(d){ const n = k => Array.isArray(d[k]) ? d[k].length : 0; return { objekte: n('objekte'), kontakte: n('kontakte'), termine: n('termine'), aufgaben: n('aufgaben') }; }
function mc42Wiederherstellen(){
  const inp = document.createElement('input'); inp.type = 'file'; inp.style.display = 'none';
  inp.onchange = () => {
    const f = inp.files && inp.files[0]; inp.remove(); if(!f) return;
    if(f.size > 80e6){ akqToast('⚠️ Datei zu groß'); return; }
    const rd = new FileReader();
    rd.onload = () => {
      let d = null; try{ d = JSON.parse(String(rd.result || '')); }catch(e){}
      if(!d || typeof d !== 'object' || Array.isArray(d) || !(Array.isArray(d.objekte) || Array.isArray(d.kontakte))){ akqToast('⚠️ Das ist keine MaklerCockpit-Sicherung (JSON mit Objekten/Kontakten).', 6000); return; }
      const z = mc42Zahlen(d), jetzt = mc42Zahlen(db);
      const los = () => {
        const text = JSON.stringify(d);
        try{ if(window.pc.sicherungExtern && (jetzt.objekte + jetzt.kontakte + jetzt.termine) > 0) window.pc.sicherungExtern(JSON.stringify(db), 'vor-wiederherstellen'); }catch(e){}
        const r = window.pc.importieren(text);
        if(!r || !r.ok){ akqToast('⚠️ Wiederherstellen fehlgeschlagen: ' + ((r && r.fehler) || ''), 6000); return; }
        try{ if(typeof ab25Aktiv === 'function' && ab25Aktiv()){ const st = ab25Stand(); st.basis = {}; st.seit = 0; st.lokalSeit = {}; ab25StandSpeichern(); } }catch(e){}
        window.__mcNichtSpeichern = true; location.reload();
      };
      bestaetigeUnten(`Sicherung „${f.name}“ einspielen? Sie enthält ${z.objekte} Objekte, ${z.kontakte} Kontakte, ${z.termine} Termine. Die jetzigen Daten auf diesem Gerät (${jetzt.objekte} Objekte, ${jetzt.kontakte} Kontakte) werden ersetzt – vorher wird gesichert.`, los, 'Wiederherstellen');
    };
    rd.readAsText(f);
  };
  document.body.appendChild(inp); inp.click();
}
(function(){
  const st = document.createElement('style');
  st.textContent = '.ab42-retten{margin-top:12px;padding:10px 12px;border:1px solid var(--border);border-radius:10px;font-size:13px}.ab42-retten .mc24-muted{margin-top:4px}';
  document.head.appendChild(st);
})();
