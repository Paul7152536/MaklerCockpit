// ═══ MaklerCockpit v44 – Eigentümer-Fragebogen als ausfüllbares PDF (Dropdowns, Ankreuzkästchen, Textfelder) ═══
// Auszug aus dem Auswahlkatalog 2.0 in einfacher Sprache. Feldnamen = Katalogschlüssel, damit das ausgefüllte PDF
// später wieder in die Große Analyse eingelesen werden kann (Herkunft: Eigentümerangabe, ungeprüft).
// Läuft im Programm (PDFLib global) und in Node (für Vorschau/Tests).

const GA44_FB_VERSION = 'fb1';
// [Schlüssel, eigener Text?, Optionen] – '@…' = Sonderfeld; {g, n} = wiederholbare Gruppe mit n Plätzen
const GA44_BOGEN = [
  { t: 'Das Gebäude', f: [
    ['@art', 'Objektart'], ['stellung', 'Gebäudestellung'], ['baujahr', 'Baujahr'], ['k_genauigkeit_baujahr', 'Wie genau ist das Baujahr bekannt?'],
    ['k_baujahr_zeitraum', 'Falls nur ungefähr: Zeitraum (von – bis)'], ['k_tragende_bauweise', 'Bauweise'], ['k_herstellungsart', 'Fertighaus oder vor Ort gebaut?'],
    ['geschosse', 'Anzahl Vollgeschosse (ohne Keller und Dach)'], ['zimmer', 'Anzahl Zimmer (ohne Küche, Bad, Flur)'], ['k_wohneinheiten', 'Anzahl Wohnungen im Haus'],
    ['keller', 'Keller'], ['k_unterkellerter_anteil', 'Falls Teilkeller: welcher Anteil? (%)'], ['k_kellernutzung', 'Wie wird der Keller genutzt?'],
    ['k_dachform', 'Dachform', { bild: 1 }], ['k_dachausbau', 'Ist das Dachgeschoss ausgebaut?'], ['k_spitzboden', 'Spitzboden (oberster Dachraum)'], ['k_dacheindeckung', 'Dacheindeckung'],
    ['k_dachdaemmung_kenntnisstand', 'Ist das Dach gedämmt?'] ] },
  { t: 'Flächen', f: [
    ['wfl', 'Wohnfläche (m²)'], ['wfl_regel', 'Woher stammt die Wohnflächenangabe?', ['Wohnflächenverordnung (WoFlV)', 'II. Berechnungsverordnung (II. BV)', 'Als Wohnfläche bezeichnete DIN-277-Angabe', 'Andere dokumentierte Berechnung', 'Eigentümerangabe ohne Berechnung', 'Unbekannt']],
    ['nfl', 'Nutzfläche, z. B. Keller, Dachboden (m²)'], ['grund', 'Grundstücksgröße (m²)'],
    { g: 'aussenflaechen', n: 2, titel: 'Terrasse / Balkon', f: ['art_der_flaeche', 'tatsaechliche_grundflaeche', 'ueberdachung'] } ] },
  { t: 'Ausstattung und Zustand', f: [
    ['standard', 'Ausstattung insgesamt'], ['zustand', 'Zustand insgesamt'], ['k_bodenbelaege', 'Bodenbeläge'], ['k_fassade_aussenwandbekleidung', 'Fassade'], ['k_wanddaemmung', 'Sind die Außenwände gedämmt?'],
    ['k_anzahl_badezimmer', 'Anzahl Badezimmer'], ['k_anzahl_separate_wcs', 'Anzahl separate Gäste-WCs'],
    { g: 'baeder', n: 2, titel: 'Bad', f: ['bad_geschoss', 'jahr_der_letzten_wesentlichen_erneuerung', 'wandbelag_fliesenhoehe', 'zustand', 'sanitaerobjekte'] },
    ['k_einbaukueche', 'Einbauküche'], ['k_baujahr_einbaujahr_kueche', 'Küche eingebaut im Jahr'] ] },
  { t: 'Fenster und Rollläden', hinweis: 'Sind die Fenster im Haus unterschiedlich (z. B. unten neu, oben alt)? Dann bitte je Bereich eine Fenstergruppe ausfüllen.', f: [
    { g: 'fenster', n: 2, titel: 'Fenstergruppe', f: ['bereich_fenstergruppe', 'baujahr_erneuerungsjahr_des_fensters', 'verglasung_scheibenanzahl', 'rahmenmaterial'] },
    { g: 'sonnenschutz', n: 1, titel: 'Rollläden / Sonnenschutz', f: ['sonnenschutzart', 'bedienung_antrieb', 'abdeckung'] } ] },
  { t: 'Heizung und Energie', f: [
    { g: 'heizungen', n: 1, titel: 'Heizung', f: ['versorgungsart', 'technik_der_waermeerzeugung', 'baujahr_heizungsanlage', 'betriebszustand_laut_kenntnisstand', 'geplanter_austausch', 'waermepumpenart', 'energietraeger', 'waermeverteilung'] },
    ['k_warmwasserbereitung', 'Warmwasser'], ['k_energieausweis_unterlagenstand', 'Energieausweis'], ['ea_art', 'Art des Energieausweises'], ['ea_klasse', 'Energieklasse laut Ausweis'],
    ['ea_kw', 'Kennwert laut Ausweis (kWh/m²·a)'], ['k_photovoltaik', 'Photovoltaik'], ['k_pv_leistung', 'PV-Leistung (kWp), falls vorhanden'], ['k_batteriespeicher', 'Batteriespeicher'],
    ['k_wallbox_ladepunkt', 'Wallbox / Ladepunkt'], ['k_solarthermie', 'Solarthermie'], ['k_erneuerungsstand', 'Elektrik: wie viel ist erneuert?'] ] },
  { t: 'Modernisierungen', hinweis: 'Was wurde wann erneuert? Je Zeile eine Maßnahme.', f: [
    { g: 'modernisierungen', n: 6, tabelle: 1, f: ['bauteil_massnahme', 'jahr_der_massnahme', 'umfang_der_massnahme', 'nachweis_vorhanden'] } ] },
  { t: 'Schäden und Mängel', hinweis: 'Bitte alles nennen, was Ihnen bekannt ist – das hilft, später Überraschungen zu vermeiden.', f: [
    ['k_kellerbefund', 'Keller'],
    { g: 'schaeden', n: 3, tabelle: 1, f: ['befund_verdacht', 'betroffene_bereiche', 'beschreibung_und_umfang'] } ] },
  { t: 'Garage, Stellplätze, Nebengebäude', f: [
    { g: 'nebenanlagen', n: 2, tabelle: 1, f: ['art_der_anlage', 'anzahl', 'baujahr_anlage', 'zustand_anlage'] } ] },
  { t: 'Nutzung und Rechtliches', f: [
    ['nutzung', 'Wie wird die Immobilie genutzt?'], ['k_verfuegbarkeit', 'Ab wann ist sie frei?'], ['k_verfuegbar_ab', 'Frei ab (Datum)'], ['miete_ist', 'Falls vermietet: Nettokaltmiete pro Monat (€)'],
    ['k_rechtsform', 'Eigentumsform'], ['denkmal', 'Denkmalschutz'], ['k_bekannte_rechte_beschraenkungen', 'Eingetragene Rechte oder Lasten'],
    ['beitrag', 'Erschließungsbeiträge'], ['k_baulastenauskunft', 'Baulastenauskunft'], ['k_altlasten_auskunftsstand', 'Altlasten'] ] },
  { t: 'Unterlagen, Preis und Sonstiges', f: [
    ['@unterlagen', 'Diese Unterlagen kann ich bereitstellen'], ['@wunsch', 'Ihre Preisvorstellung (€)'], ['@notiz', 'Was sollte ich noch wissen?'],
    ['@name', 'Ausgefüllt von'], ['@datum', 'Datum'] ] }
];
function ga44San(s){ return String(s == null ? '' : s).replace(/m²/g, 'qm').replace(/²/g, '2').replace(/³/g, '3').replace(/[→←]/g, '-').replace(/[≤]/g, '<=').replace(/[≥]/g, '>=').replace(/[…]/g, '...').replace(/[^\x00-\xFF€„“”‚‘’–—•·]/g, ''); }
function ga44Opts(f){ const l = (f.o || []).map(x => Array.isArray(x) ? x[0] : x); if(!l.includes('Unbekannt')) l.push('Unbekannt'); return l; }

function ga44FragebogenErstellen(o){
  const P = o.PDFLib, kat = o.kat, { rgb, StandardFonts } = P;
  const G = {}; kat.forEach(g => { G[g.id] = g; });
  const feld = k => { for(const g of kat) if(!g.rep){ const f = g.f.find(f => f.k === k); if(f) return f; } return null; };
  const optsVon = ga44Opts;
  const NAVY = rgb(0.106, 0.165, 0.255), ORANGE = rgb(0.91, 0.467, 0.18), GRAU = rgb(0.36, 0.40, 0.46), HELL = rgb(0.95, 0.96, 0.975), RAND = rgb(0.72, 0.75, 0.80), WEISS = rgb(1, 1, 1);
  const san = ga44San;
  return (async () => {
    const doc = await P.PDFDocument.create(), form = doc.getForm();
    const F = await doc.embedFont(StandardFonts.Helvetica), FB = await doc.embedFont(StandardFonts.HelveticaBold);
    const bild = o.dachBild ? await doc.embedJpg(o.dachBild) : null;
    doc.setTitle('Objekt-Fragebogen – ' + san(o.titel || 'Immobilie')); doc.setAuthor(san(o.absender || 'Görner Immobilien'));
    doc.setSubject('Fragebogen zur Marktpreiseinschätzung'); doc.setKeywords(['MaklerCockpit-Fragebogen', GA44_FB_VERSION, 'obj:' + (o.objektId || 'frei'), 'art:' + (o.art || '')]);
    doc.setCreator('MaklerCockpit'); doc.setProducer('MaklerCockpit');
    const PW = 595.28, PH = 841.89, M = 40, B = PW - 2 * M, GAP = 14, CW = (B - GAP) / 2, UNTEN = 46;
    let page, y, spalte = 0, zeileH = 0, nr = 0;
    const text = (t, x, yy, s, f, c, maxW) => { t = san(t); if(maxW){ while(t.length > 3 && (f || F).widthOfTextAtSize(t, s) > maxW) t = t.slice(0, -2); } page.drawText(t, { x, y: yy, size: s, font: f || F, color: c || NAVY }); };
    const umbruch = (t, s, f, w) => { const out = []; let z = ''; san(t).split(/\s+/).forEach(wd => { const n = z ? z + ' ' + wd : wd; if((f || F).widthOfTextAtSize(n, s) > w && z){ out.push(z); z = wd; } else z = n; }); if(z) out.push(z); return out; };
    const neueSeite = () => {
      page = doc.addPage([PW, PH]); nr++;
      page.drawRectangle({ x: 0, y: PH - 30, width: PW, height: 30, color: NAVY });
      page.drawRectangle({ x: 0, y: PH - 33, width: PW, height: 3, color: ORANGE });
      text(o.absender || 'Görner Immobilien', M, PH - 20, 10.5, FB, WEISS);
      const r = 'Objekt-Fragebogen' + (o.titel ? ' · ' + o.titel : ''); text(r, PW - M - Math.min(300, FB.widthOfTextAtSize(san(r), 9)), PH - 19.5, 9, F, WEISS, 300);
      y = PH - 54; spalte = 0; zeileH = 0;
    };
    const zeilenEnde = () => { if(spalte){ y -= zeileH; spalte = 0; zeileH = 0; } };
    const platz = h => { if(y - h < UNTEN){ neueSeite(); return true; } return false; };
    const name = (...t) => t.join('|');
    const box = (x, yy, w, h) => ({ x, y: yy, width: w, height: h, font: F, textColor: NAVY, borderColor: RAND, backgroundColor: HELL, borderWidth: 0.8 });
    const dropdown = (n, opts, x, yy, w, wert) => {   // Feld mit sichtbarem Pfeil, damit man erkennt: hier gibt es eine Auswahl
      page.drawRectangle({ x, y: yy, width: w, height: 17, color: HELL, borderColor: RAND, borderWidth: 0.8 });
      page.drawRectangle({ x: x + w - 15, y: yy + 0.4, width: 14.6, height: 16.2, color: rgb(0.89, 0.91, 0.94) });
      page.drawSvgPath('M0,0 L7,0 L3.5,4.5 Z', { x: x + w - 11, y: yy + 10.5, color: NAVY });
      const d = form.createDropdown(n); d.addOptions(opts.map(san)); if(wert && opts.includes(wert)) d.select(san(wert));
      d.addToPage(page, { x, y: yy, width: w - 15, height: 17, font: F, textColor: NAVY, borderWidth: 0 }); d.setFontSize(8.5); return d; };
    const textfeld = (n, x, yy, w, h, wert, mehrzeilig) => { const t = form.createTextField(n); if(mehrzeilig) t.enableMultiline(); if(wert) t.setText(san(wert)); t.addToPage(page, box(x, yy, w, h)); t.setFontSize(mehrzeilig ? 8.5 : 9); return t; };
    const label = (t, x, yy, w) => { umbruch(t, 7.8, FB, w).slice(0, 2).forEach((z, i) => text(z, x, yy - i * 9, 7.8, FB, GRAU)); return umbruch(t, 7.8, FB, w).slice(0, 2).length; };
    // halbe Breite: Dropdown / Text / Zahl
    const halb = (n, l, f, wert) => {
      const lz = umbruch(l, 7.8, FB, CW).slice(0, 2).length, h = 12 + (lz - 1) * 9 + 17 + 8;
      if(spalte === 0) platz(h);
      const x = M + spalte * (CW + GAP);
      label(l, x, y - 8, CW);
      const yy = y - 8 - (lz - 1) * 9 - 21;
      if(f && f.t === 'sel') dropdown(n, f.o ? optsVon(f) : f, x, yy, CW, wert);
      else if(Array.isArray(f)) dropdown(n, f, x, yy, CW, wert);
      else if(f && f.t === 'zeitraum'){ textfeld(n + '|von', x, yy, CW / 2 - 8, 17); text('–', x + CW / 2 - 4, yy + 5, 9); textfeld(n + '|bis', x + CW / 2 + 6, yy, CW / 2 - 6, 17); }
      else textfeld(n, x, yy, CW, 17, wert);
      zeileH = Math.max(zeileH, h);
      if(spalte === 1) zeilenEnde(); else spalte = 1;
    };
    // volle Breite: Ankreuzkästchen
    const kreuze = (n, l, opts, gewaehlt) => {
      zeilenEnde();
      const zeilen = []; let z = [], b = 0;
      opts.forEach((op, i) => { const w = 13 + F.widthOfTextAtSize(san(op), 8.3) + 12; if(b + w > B && z.length){ zeilen.push(z); z = []; b = 0; } z.push([op, i, b]); b += w; });
      if(z.length) zeilen.push(z);
      platz(14 + zeilen.length * 14 + 6);
      label(l, M, y - 8, B); let yy = y - 22;
      zeilen.forEach(zz => { zz.forEach(([op, i, bx]) => { const c = form.createCheckBox(n + '|' + i); c.addToPage(page, { x: M + bx, y: yy - 1, width: 9, height: 9, borderColor: RAND, backgroundColor: HELL, borderWidth: 0.8, textColor: NAVY }); if(gewaehlt && gewaehlt.includes(op)) c.check(); text(op, M + bx + 13, yy + 0.5, 8.3); }); yy -= 14; });
      y = yy - 4;
    };
    const feldHtml = (n, l, f, wert) => {
      if(!f) return;
      if(f.t === 'multi') return kreuze(n, l, optsVon(f), wert);
      if(f.t === 'lang'){ zeilenEnde(); platz(52); label(l, M, y - 8, B); textfeld(n, M, y - 50, B, 36, wert, true); y -= 56; return; }
      halb(n, l + (f.e && !/\(/.test(l) ? ` (${f.e})` : ''), f, wert);
    };
    const abschnitt = (i, t, hinweis) => {
      zeilenEnde();
      platz(hinweis ? 64 : 50);
      y -= 6;
      page.drawRectangle({ x: M, y: y - 15, width: 4, height: 15, color: ORANGE });
      text(`${i}. ${t}`, M + 10, y - 12, 12.5, FB, NAVY);
      y -= 24;
      if(hinweis){ umbruch(hinweis, 8.5, F, B).forEach(z => { text(z, M, y - 6, 8.5, F, GRAU); y -= 11; }); y -= 3; }
    };
    const W = k => o.werte && o.werte[k];

    // ── Seite 1: Kopf ──
    neueSeite();
    text('Objekt-Fragebogen', M, y - 18, 22, FB, NAVY);
    text('für die Marktpreiseinschätzung Ihrer Immobilie', M, y - 34, 11, F, GRAU);
    y -= 50;
    const hin = ['Bitte füllen Sie aus, was Sie wissen. Alles andere einfach leer lassen oder „Unbekannt“ wählen – das ist völlig in Ordnung.',
      'Bei Auswahlfeldern auf das Feld tippen bzw. klicken und die passende Antwort wählen. Kästchen: alles ankreuzen, was zutrifft.',
      'Ausfüllen am PC mit Adobe Acrobat Reader oder im Browser, am Handy mit der kostenlosen App „Adobe Acrobat Reader“. Danach speichern und per E-Mail an mich zurücksenden.',
      'Ihre Angaben behandle ich vertraulich und verwende sie nur für die Einschätzung Ihrer Immobilie.'];
    const hz = hin.map(t => umbruch(t, 8.6, F, B - 26));
    const hh = hz.reduce((s, l) => s + l.length * 11 + 3, 0) + 14;
    page.drawRectangle({ x: M, y: y - hh, width: B, height: hh, color: rgb(0.995, 0.955, 0.925), borderColor: ORANGE, borderWidth: 0.6 });
    let yy = y - 13;
    hz.forEach(l => { page.drawCircle({ x: M + 12, y: yy + 2.8, size: 2, color: ORANGE }); l.forEach(z => { text(z, M + 20, yy, 8.6, F, NAVY); yy -= 11; }); yy -= 3; });
    y -= hh + 12;
    halb('@objekt', 'Objekt (Adresse)', null, o.adresse || ''); halb('@eigentuemer', 'Ihr Name (optional)', null, '');
    zeilenEnde();

    // ── Abschnitte ──
    GA44_BOGEN.forEach((a, ai) => {
      abschnitt(ai + 1, a.t, a.hinweis);
      a.f.forEach(e => {
        if(Array.isArray(e)){
          const [k, l, eigeneOpts, ex] = e, extra = (Array.isArray(eigeneOpts) ? ex : eigeneOpts) || {};
          if(k === '@art') return halb('@art', l, o.arten.map(x => x[1]), (o.arten.find(x => x[0] === o.art) || [])[1]);
          if(k === '@unterlagen') return kreuze('@unterlagen', l, o.unterlagen.map(u => u[1]));
          if(k === '@wunsch'){ return halb('@wunsch', l, null, ''); }
          if(k === '@notiz'){ zeilenEnde(); platz(78); label(l, M, y - 8, B); textfeld('@notiz', M, y - 72, B, 58, '', true); y -= 80; return; }
          if(k === '@name' || k === '@datum') return halb(k, l, null, '');
          const f = feld(k); if(!f) return;
          if(extra.bild && bild){
            zeilenEnde();
            const bw = 172; platz(bw + 16);
            label(l, M, y - 8, CW); dropdown('w|' + k, optsVon(f), M, y - 29, CW, W(k) && W(k).v);
            umbruch('Bitte die passende Form wählen – zur Orientierung die Bilder rechts.', 8.3, F, CW).forEach((z, i) => text(z, M, y - 46 - i * 10, 8.3, F, GRAU));
            page.drawImage(bild, { x: M + CW + GAP + (CW - bw) / 2, y: y - bw - 4, width: bw, height: bw });
            y -= bw + 12; return;
          }
          return feldHtml('w|' + k, l, Array.isArray(eigeneOpts) ? Object.assign({}, f, { o: eigeneOpts }) : f, W(k) && W(k).v);
        }
        const g = G[e.g]; if(!g) return;
        if(e.tabelle){
          zeilenEnde();
          const fs = e.f.map(k => g.f.find(f => f.k === k)).filter(Boolean);
          const breit = fs.map(f => f.t === 'jahr' || f.t === 'int' ? 0.6 : f.t === 'lang' ? 1.6 : 1.2), s = breit.reduce((a, b) => a + b, 0), gap = 6;
          const ws = breit.map(b => (B - gap * (fs.length - 1) - 16) * b / s);
          platz(30 + 22);
          let x = M + 16; fs.forEach((f, i) => { label(f.l.replace(' / Maßnahme', '').replace(' laut Kenntnisstand', ''), x, y - 8, ws[i]); x += ws[i] + gap; });
          y -= 20;
          for(let r = 1; r <= e.n; r++){
            platz(22);
            text(String(r), M + 3, y - 12, 8.5, FB, GRAU);
            let x = M + 16;
            fs.forEach((f, i) => { const n = name('g', g.id, r, f.k); if(f.t === 'sel' || f.t === 'multi') dropdown(n, optsVon(f), x, y - 17, ws[i]); else textfeld(n, x, y - 17, ws[i], 17); x += ws[i] + gap; });
            y -= 22;
          }
          y -= 4; return;
        }
        for(let r = 1; r <= e.n; r++){
          zeilenEnde(); platz(40);
          text(e.n > 1 ? `${e.titel} ${r}` : e.titel, M, y - 9, 9.5, FB, ORANGE); y -= 14;
          e.f.forEach(k => { const f = g.f.find(x => x.k === k); if(!f) return; let l = f.l; if(f.wenn){ const q = g.f.find(x => x.k === f.wenn.f); if(f.wenn.in) l += ` – nur bei ${f.wenn.in.slice(0, 2).join(' / ')}`; } feldHtml(name('g', g.id, r, k), l, f); });
          zeilenEnde(); y -= 4;
        }
      });
    });
    zeilenEnde();
    platz(30); y -= 8;
    umbruch('Vielen Dank! Bitte die Datei speichern und per E-Mail zurücksenden. Ich melde mich mit der Einschätzung bei Ihnen.', 9, FB, B).forEach(z => { text(z, M, y, 9, FB, NAVY); y -= 12; });
    // Fußzeilen
    const n = doc.getPageCount();
    doc.getPages().forEach((pg, i) => { page = pg; page.drawLine({ start: { x: M, y: 30 }, end: { x: PW - M, y: 30 }, thickness: 0.5, color: RAND }); text(`${o.absender || 'Görner Immobilien'} · Objekt-Fragebogen`, M, 20, 7.5, F, GRAU); const s = `Seite ${i + 1} von ${n}`; text(s, PW - M - F.widthOfTextAtSize(s, 7.5), 20, 7.5, F, GRAU); });
    form.updateFieldAppearances(F);
    return doc.save();
  })();
}
if(typeof module !== 'undefined' && module.exports) module.exports = { ga44FragebogenErstellen, GA44_BOGEN, ga44San, ga44Opts };
