// ═══ MaklerCockpit v26 – Kaufgesuche: bis zu 100 je Suche ═══
// Eigene Einstellungen für Kaufgesuche (Anzahl, Zeitraum), Prompt mit „Fortsetzung“, damit lange Listen nicht abbrechen.
const GS26_MAX = 100;
function gs26Einst(){
  const e = akqDb().einst;
  if(e.anzahlGesuche == null) e.anzahlGesuche = GS26_MAX;
  if(e.tageGesuche == null) e.tageGesuche = 60;
  return e;
}
function gs26Setzen(k, v){
  const e = gs26Einst(); const n = parseInt(String(v).replace(/\D/g, ''), 10);
  if(k === 'anzahlGesuche') e.anzahlGesuche = Math.max(1, Math.min(GS26_MAX, n || GS26_MAX));
  if(k === 'tageGesuche') e.tageGesuche = Math.max(7, Math.min(365, n || 60));
  save();
  document.querySelectorAll(`[data-gs26="${k}"]`).forEach(el => { el.value = e[k]; });
}
const GS26_FORTSETZUNG = (n) => `LÄNGE: Das Ziel sind bis zu ${n} Gesuche. Wenn deine Antwort zu lang wird, hör nach einem vollständigen Eintrag auf (z. B. nach Nr. 40) und schreib als letzte Zeile genau: „FORTSETZUNG: weiter ab Nr. X“. Paul fügt diese Antwort ein und schreibt dir dann „weiter“ – mach dann nahtlos mit Nr. X weiter, ohne schon genannte Gesuche zu wiederholen. Erst ganz am Schluss: „Gesamt: X Gesuche“.`;
function gs26Prompt(e){
  const n = e.anzahlGesuche || GS26_MAX, tage = e.tageGesuche || 60;
  return `Du hilfst Paul Görner (Immobilienmakler, BETTERHOMES Berlin), Käufer zu finden. Heute ist der ${new Date().toLocaleDateString('de-DE')}. Nutze die Websuche gründlich und öffne jedes Gesuch einzeln.

AUFGABE: Finde bis zu ${n} aktuelle KAUFGESUCHE von Privatleuten – Menschen, die ein Haus, eine Wohnung oder ein Grundstück kaufen wollen – im Gebiet ${e.gebiet}. Nur Gesuche der letzten ${tage} Tage, neueste zuerst.
Wo suchen (möglichst viele Quellen, Ort für Ort – erst die Berliner Bezirke, dann die Umland-Gemeinden – bis die Anzahl erreicht ist):
- kleinanzeigen.de: Häuser zum Kauf, Eigentumswohnungen, Grundstücke & Gärten – jeweils Anzeigentyp „Gesuche“, auch Seite 2, 3 …
- markt.de, quoka.de und andere Kleinanzeigen-Portale mit Gesuche-Rubrik
- Online-Kleinanzeigen regionaler Zeitungen und Anzeigenblätter (Rubrik „Kaufgesuche“ / „Suche Haus/Wohnung“)
- öffentlich sichtbare Suchanzeigen auf Immobilienportalen und in öffentlichen Gruppen, wenn ein direkter Link möglich ist
REGELN:
- NICHT aufnehmen: Gesuche von Maklern, Bauträgern oder Aufkäufern („für vorgemerkte Kunden“, „kaufe alle Immobilien“) und Gesuche mit „keine Makler“, „von privat“, „provisionsfrei“ o. ä. – diese Leute wollen keinen Makler. Gesuche mit „Makler willkommen“ oder „Provision wird übernommen“ gerne aufnehmen.
- Link = PFLICHT: direkter Link zum einzelnen Gesuch. Ohne Link keine Aufnahme. Jedes Gesuch nur einmal (gleicher Text auf zwei Portalen = ein Eintrag).
- Kontaktdaten nur, wenn sie im Gesuch stehen – sonst „Nicht angegeben“ (Kontakt dann über die Nachrichtenfunktion).
- Erfinde nichts; prüfe jeden Eintrag gegen das geöffnete Gesuch. Lieber weniger als falsche Einträge.
${GS26_FORTSETZUNG(n)}

ANTWORTFORMAT (genau so – Paul fügt deine Antwort in sein Programm ein, das liest sie automatisch):
Nummeriere die Gesuche (1., 2., 3., …). Jedes Gesuch bekommt genau diese Zeilen:
${AKQ_FORMAT_GESUCH_ZEILEN}

Keine Tabellen, kein Fettdruck, keine Erklärungen zwischen den Einträgen.`;
}
// Region-Prompt „Käufer-Gesuche (Suchkunden)“ ersetzen
(function(){
  const p = (typeof AKQ_PROMPTS !== 'undefined') ? AKQ_PROMPTS.find(x => x.key === 'gesuche') : null;
  if(!p) return;
  p.titel = 'Käufer-Gesuche (bis zu 100 Suchkunden)';
  p.text = 'Websuche nach bis zu 100 Kaufgesuchen von Privatleuten – landen als Suchkunden und werden mit deinen Objekten abgeglichen. Lange Listen kommen in mehreren Teilen („weiter“).';
  p.prompt = (e) => gs26Prompt(Object.assign({}, e, gs26Einst()));
})();
// Objekt-Prompt („KI fragen“ bei Käufer & Markt): Aufgabe 3 auf bis zu 100 Gesuche
if(typeof skKiPrompt === 'function'){
  const _gs26Obj = skKiPrompt;
  skKiPrompt = function(o){
    let t = _gs26Obj.apply(this, arguments);
    const n = gs26Einst().anzahlGesuche || GS26_MAX;
    t = t.replace('AUFGABE 3 – GESUCHE: Suche aktuelle KAUFGESUCHE', `AUFGABE 3 – GESUCHE: Suche bis zu ${n} aktuelle KAUFGESUCHE (letzte ${gs26Einst().tageGesuche} Tage, so viele passende wie du findest)`);
    return t.replace('Wenn du keine passenden Gesuche findest, schreib „Gesuche: keine gefunden“.', 'Wenn du keine passenden Gesuche findest, schreib „Gesuche: keine gefunden“.\n' + GS26_FORTSETZUNG(n));
  };
}
// Einstellungen in „Suchen lassen“ und „Suchkunden finden“
function gs26FelderHtml(){
  const e = gs26Einst();
  return `<div class="gs26-felder"><div><label>Kaufgesuche (Anzahl, max. 100)</label><input data-gs26="anzahlGesuche" inputmode="numeric" value="${e.anzahlGesuche}" onchange="gs26Setzen('anzahlGesuche', this.value)"></div>
    <div><label>Kaufgesuche (Zeitraum, Tage)</label><input data-gs26="tageGesuche" inputmode="numeric" value="${e.tageGesuche}" onchange="gs26Setzen('tageGesuche', this.value)"></div></div>`;
}
if(typeof aq2Suchen === 'function'){
  const _gs26Suchen = aq2Suchen;
  aq2Suchen = function(){
    const r = _gs26Suchen.apply(this, arguments);
    try{ const k = document.getElementById('akqKarten'); if(k && !document.querySelector('#modalInner .gs26-felder')) k.insertAdjacentHTML('beforebegin', gs26FelderHtml()); }catch(e){}
    return r;
  };
}
if(typeof kgFinden === 'function'){
  const _gs26Finden = kgFinden;
  kgFinden = function(){
    const r = _gs26Finden.apply(this, arguments);
    try{
      const karte = Array.from(document.querySelectorAll('#kgModal .sf-karte')).find(k => /KI-Websuche/.test(k.textContent));
      if(karte){
        const sp = karte.querySelector('span'); if(sp) sp.insertAdjacentHTML('beforeend', ` Bis zu <b>${gs26Einst().anzahlGesuche}</b> Gesuche; lange Listen kommen in Teilen – nach „FORTSETZUNG“ in Claude „weiter“ schreiben und jeden Teil hier einfügen.`);
        const kn = karte.querySelector('.sf-knoepfe'); if(kn) kn.insertAdjacentHTML('beforebegin', gs26FelderHtml());
      }
    }catch(e){}
    return r;
  };
}
// „FORTSETZUNG“- und „Gesamt“-Zeilen beim Einfügen ignorieren
if(typeof akqImportText === 'function'){
  const _gs26Import = akqImportText;
  akqImportText = function(text){
    const args = Array.from(arguments);
    args[0] = String(text || '').replace(/^\s*(?:\*\*)?\s*FORTSETZUNG\s*:.*$/gim, '').replace(/^\s*Gesamt\s*:\s*\d+\s*Gesuche.*$/gim, '');
    return _gs26Import.apply(this, args);
  };
}
