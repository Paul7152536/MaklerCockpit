// ═══ MaklerCockpit v40 – Große Analyse mit den Shooting-Werkzeugen (Vergleichswert, Ertragswert, Inserate, Kennzahlen, Provision) ═══
// Zweiter Reiter „🧮 Schnellbewertung“ in der Großen Analyse: dasselbe Werkzeug wie die Shooting-Analyse, aber an das gewählte Objekt
// gebunden (eigener Entwurf je Objekt, vorbelegt aus der Erfassung). „⬇ In die Große Analyse übernehmen“ holt Inserate, Portalwerte,
// fehlende Eckdaten und die Rechenergebnisse in die Erfassung. Die Ergebnisse gehen als Makler-Schnellbewertung ins Analysepaket –
// ausdrücklich nur zur Plausibilität (Angebotspreise und Pauschalfaktoren), nicht als Wertquelle.
const GA40_HAUSTYP = { EFH: '1.0', DHH: '0.97', RH: '0.9', ZFH: '1.0', MFH: '1.05' };
let GA40_HTML = null;
function ga40Html(){
  if(GA40_HTML) return GA40_HTML;
  let h = SH_HTML;
  const n = h.split('window.parent.__SH_HOST').length - 1;
  h = h.split('window.parent.__SH_HOST').join('window.parent.__GA40_HOST');
  const a = 'window.maFlush = flushDraft;';
  if(n < 1 || !h.includes(a)) throw new Error('Shooting-Werkzeug nicht gefunden');
  h = h.replace(a, a + '\n  window.ga40Werte = function(){ return { v: calcVergleich(), e: calcErtrag(), d: collectValues(), def: defaults, mode: wrapEl.dataset.mode, type: wrapEl.dataset.type }; };');
  return (GA40_HTML = h);
}
function ga40Key(){ return GA35.obj || 'frei'; }
function ga40Vorbelegung(e){
  const w = k => { const x = e.werte[k]; return x && String(x.v || '').trim() !== '' ? String(x.v).trim() : ''; };
  const typ = e.art === 'ETW' ? 'wohnung' : e.art === 'Grundstueck' ? 'grundstueck' : GA35_HAUS.includes(e.art) ? 'haus' : 'wohnung';
  const f = {}, z = v => { const n = mc24N(v); return n != null && n > 0 ? String(n) : ''; };
  const ort = [w('plz'), w('ort')].filter(Boolean).join(' '), titel = w('ortsteil') || ort;
  if(titel) f.objTitle = titel; if(ort) f.adresse = ort + (w('ortsteil') ? ' (' + w('ortsteil') + ')' : '');   // ohne Straße/Hausnummer
  if(z(w('wfl'))) f.flaeche = z(w('wfl')); if(typ === 'grundstueck' && z(w('grund'))) f.flaeche = z(w('grund'));
  if(z(w('baujahr'))) f.baujahr = z(w('baujahr'));
  if(z(w('brw'))){ f.bodenrichtwert = z(w('brw')); f.erBodenrichtwert = z(w('brw')); }
  if(z(w('grund')) && typ === 'haus'){ f.erGrundstueck = z(w('grund')); }   // „Grundstück zusätzlich“ (mfh…) bleibt leer: Wohnflächenpreise enthalten das Grundstück schon
  if(z(w('wunsch'))) f.objAngebot = Number(z(w('wunsch'))).toLocaleString('de-DE');
  if(typ === 'haus' && GA40_HAUSTYP[e.art]) f.haustyp = GA40_HAUSTYP[e.art];
  return { type: typ, mode: 'vergleich', objektId: '', shooting: true, fields: f, checks: {} };
}
window.__GA40_HOST = {
  objekte: () => [],
  getSaved: () => (db.shooting && db.shooting.saved) || [],
  setSaved: (l) => { db.shooting = db.shooting || {}; db.shooting.saved = JSON.parse(JSON.stringify(l)); save(); },
  getDraft: () => { const e = ga35Entwurf(GA35.obj); return e.schnellEntwurf || ga40Vorbelegung(e); },
  setDraft: (d) => { const e = ga35Entwurf(GA35.obj); e.schnellEntwurf = JSON.parse(JSON.stringify(d)); save(); },
  setEinschaetzung: () => {}
};
function ga40Tab(t){
  const fr = document.getElementById('ga40Frame'); try{ if(fr && fr.contentWindow.maFlush) fr.contentWindow.maFlush(); }catch(e){}
  GA35.tab = t; const m = document.getElementById('main'); if(m) m.scrollTop = 0; ga35Neuzeichnen();
}
function ga40Reiter(){
  const t = GA35.tab === 'schnell' ? 'schnell' : 'erfassung';
  return `<div class="ga40-reiter"><button class="${t === 'erfassung' ? 'aktiv' : ''}" onclick="ga40Tab('erfassung')">📋 Erfassung</button><button class="${t === 'schnell' ? 'aktiv' : ''}" onclick="ga40Tab('schnell')">🧮 Schnellbewertung <small>(Shooting-Werkzeuge)</small></button></div>`;
}
function ga40SchnellRender(main){
  const o = GA35.obj ? findObjekt(GA35.obj) : null;
  main.innerHTML = `<div class="ga35 ga40"><div class="ga40-leiste">${ga40Reiter()}
      <div class="ga40-info"><b>${ga35E(o ? aqTitel(o) : 'ohne Objekt')}</b><span class="mc24-muted">Vergleichswert, Ertragswert, Inserate, Kennzahlen – vorbelegt aus der Erfassung, wird je Objekt gespeichert.</span></div>
      <button onclick="ga40UebernahmeDialog()">⬇ In die Große Analyse übernehmen</button></div>
    <iframe id="ga40Frame" class="ga40-frame"></iframe></div>`;
  try{ document.getElementById('ga40Frame').srcdoc = ga40Html(); }
  catch(err){ main.querySelector('.ga40-frame').outerHTML = `<div class="mc24-hinweis">Werkzeug nicht verfügbar: ${ga35E(err.message)}</div>`; }
}
(function(){
  const _r = ga35Render;
  ga35Render = function(main){
    if(GA35.tab === 'schnell'){ const fr = document.getElementById('ga40Frame'); if(fr && main.contains(fr) && fr.dataset.obj === ga40Key()) return; ga40SchnellRender(main); const f2 = document.getElementById('ga40Frame'); if(f2) f2.dataset.obj = ga40Key(); return; }
    _r.apply(this, arguments);
    try{
      const k = main.querySelector('.ga35-kopf'); if(k) k.insertAdjacentHTML('afterend', ga40Reiter());
      const e = ga35Entwurf(GA35.obj), karte = ga40KarteHtml(e);
      const vgl = [...main.querySelectorAll('.ga35-karte')].find(x => /Vergleichsf/.test((x.querySelector('h3') || {}).textContent || ''));
      if(vgl) vgl.insertAdjacentHTML('afterend', karte); else main.querySelector('.ga35').insertAdjacentHTML('beforeend', karte);
    }catch(err){ console.error('ga40', err); }
  };
  const _w = ga35ObjWaehlen;
  ga35ObjWaehlen = function(){ const fr = document.getElementById('ga40Frame'); try{ if(fr) fr.contentWindow.maFlush(); }catch(e){} return _w.apply(this, arguments); };
})();
function ga40Eur(n){ return n == null || !isFinite(n) ? '–' : Math.round(n).toLocaleString('de-DE') + ' €'; }
function ga40KarteHtml(e){
  const s = e.schnell;
  if(!s) return `<div class="ga35-karte ga40-karte"><h3>🧮 Schnellbewertung (Shooting-Werkzeuge)</h3><div class="mc24-muted">Vergleichswert und Ertragswert wie in der Shooting-Analyse rechnen – vorbelegt mit den Angaben von hier. Die Ergebnisse gehen danach als Makler-Schnellbewertung zur Plausibilität in den Prompt.</div><div class="ga35-knoepfe"><button onclick="ga40Tab('schnell')">🧮 Schnellbewertung öffnen</button></div></div>`;
  const v = s.vergleich, r = s.ertrag;
  return `<div class="ga35-karte ga40-karte"><h3>🧮 Schnellbewertung <span class="mc24-muted" style="font-weight:400;font-size:13px">übernommen am ${ga35E(mc24Datum(s.stand))}</span></h3>
    <div class="ga40-werte">${v ? `<div><small>Vergleichswert (Schnell)</small><b>${ga40Eur(v.wert)}</b><span>${v.anzahl} Werte · Ø ${ga40Eur(v.mittelpreis)}/m²</span></div>` : ''}
    ${r ? `<div><small>Ertragswert (Schnell)</small><b>${ga40Eur(r.ertragswert)}</b><span>Liegenschaftszins ${String(r.liegzinsProz).replace('.', ',')} % · RND ${r.n} J.</span></div>` : ''}
    ${r && r.kaufpreisfaktor ? `<div><small>Kaufpreisfaktor / Brutto</small><b>${r.kaufpreisfaktor.toFixed(1).replace('.', ',')}-fach</b><span>${r.bruttorendite.toFixed(2).replace('.', ',')} % Bruttorendite</span></div>` : ''}</div>
    ${v && v.formel ? `<div class="mc24-muted ga40-formel">${ga35E(v.formel)}</div>` : ''}
    <div class="mc24-muted">Geht als Makler-Schnellbewertung in den Prompt – nur zur Plausibilität: Portal- und Inseratspreise sind Angebote, Faktoren und Zinssatz sind Annahmen.</div>
    <div class="ga35-knoepfe"><button class="secondary" onclick="ga40Tab('schnell')">🧮 Öffnen / ändern</button><button class="secondary" onclick="ga40SchnellWeg()">Aus der Analyse nehmen</button></div></div>`;
}
function ga40SchnellWeg(){ const e = ga35Entwurf(GA35.obj); delete e.schnell; save(); ga35Neuzeichnen(); }

// ── Übernahme ──
function ga40Lesen(){
  const fr = document.getElementById('ga40Frame');
  if(!fr || !fr.contentWindow || typeof fr.contentWindow.ga40Werte !== 'function') return null;
  try{ fr.contentWindow.maFlush(); }catch(e){}
  return fr.contentWindow.ga40Werte();
}
function ga40Vorschlaege(x, e){
  const d = x.d, F = d.fields || {}, C = d.checks || {}, def = x.def || {}, h = ga35Heute();
  const n = k => { const v = mc24N(F[k]); return v != null && isFinite(v) ? v : 0; }, geaendert = k => String(F[k] ?? '') !== String(def[k] ?? '');
  const t = k => String(F[k] || '').trim();
  const lageOrt = [ga39W(e, 'ortsteil'), ga39W(e, 'plz')].filter(Boolean).join(' · ');
  const liste = [];
  for(let i = 1; i <= 5; i++){
    const p = n('insPreis' + i), f = n('insFlaeche' + i);
    if(p > 0 && f > 0) liste.push({ k: 'ins' + i, an: !C['insExclude' + i], t: `Inserat: ${t('insAddr' + i) || 'ohne Lage'} · ${ga40Eur(p)} · ${mc24Fmt(f)} m²`, fall: { art: 'listing', datum: '', lage: t('insAddr' + i), preis: String(p), preisbasis: '', flaeche: String(f), flaeche_art: 'Wfl', grund: '', baujahr: '', zustand: '', quelle: ['Schnellbewertung', mc24SicherLink(t('insLink' + i))].filter(Boolean).join(' · '), beleg: false, notiz: 'aus der Schnellbewertung' + (C['insExclude' + i] ? ' (dort ausgeschlossen)' : '') } });
  }
  for(let i = 1; i <= 5; i++){
    const p = n('erVglPreis' + i), f = n('erVglFlaeche' + i), mi = n('erVglMiete' + i);
    if(p > 0) liste.push({ k: 'erv' + i, an: true, t: `Renditeobjekt: ${t('erVglAddr' + i) || 'ohne Lage'} · ${ga40Eur(p)}${f ? ' · ' + mc24Fmt(f) + ' m²' : ''}${mi ? ' · Miete ' + ga40Eur(mi) : ''}`, fall: { art: 'listing', datum: '', lage: t('erVglAddr' + i), preis: String(p), preisbasis: '', flaeche: f ? String(f) : '', flaeche_art: 'Wfl', grund: '', baujahr: '', zustand: '', quelle: ['Schnellbewertung (Ertrag)', mc24SicherLink(t('erVglLink' + i))].filter(Boolean).join(' · '), beleg: false, notiz: 'Angebot Renditeobjekt' + (mi ? ', Miete ' + mi + ' €' : '') } });
  }
  [['Homeday', 'vgHomeday'], ['ImmoScout24', 'vgImmoscout'], ['Immowelt', 'vgImmowelt']].forEach(([l, id]) => {
    const v = n(id); if(v > 0 && geaendert(id)) liste.push({ k: id, an: !C[id + 'Exclude'], t: `Portalwert ${l}: ${ga40Eur(v)}/m²`, fall: { art: 'listing', datum: mc24Datum(h), lage: lageOrt || 'Region', preis: String(v), preisbasis: 'EUR/m² Wfl (Portal-Preisatlas, Angebotsbasis)', flaeche: '', flaeche_art: 'Wfl', grund: '', baujahr: '', zustand: '', quelle: l + ' Preisatlas (Schnellbewertung)', beleg: false, notiz: 'Portalwert aus Angebotsdaten – kein Kaufpreis' } });
  });
  // Eckdaten nur, wenn sie in der Großen Analyse noch fehlen und im Werkzeug wirklich eingetragen wurden
  const leer = k => ga39W(e, k) === '';
  const eck = [['wfl', 'flaeche', 'Wohnfläche', 'm²'], ['baujahr', 'baujahr', 'Baujahr', ''], ['brw', 'bodenrichtwert', 'Bodenrichtwert', '€/m²'], ['brw', 'mfhBodenrichtwert', 'Bodenrichtwert', '€/m²'], ['brw', 'erBodenrichtwert', 'Bodenrichtwert', '€/m²'], ['grund', 'erGrundstueck', 'Grundstück', 'm²'], ['grund', 'mfhGrundstueck', 'Grundstück', 'm²'], ['wunsch', 'objAngebot', 'Preisvorstellung', '€']];
  const schon = new Set();
  for(const [gk, id, l, u] of eck){
    if(schon.has(gk) || !leer(gk) || !geaendert(id) || !(n(id) > 0)) continue;
    if(x.type === 'grundstueck' && gk === 'wfl') continue;
    schon.add(gk); liste.push({ k: 'feld_' + gk, an: true, t: `${l}: ${gk === 'baujahr' ? String(n(id)) : mc24Fmt(n(id))}${u ? ' ' + u : ''} (fehlt in der Erfassung – als „Annahme“)`, feld: [gk, String(n(id))] });
  }
  const erg = { stand: h, typ: x.type };
  if(x.v && x.v.wert > 0) erg.vergleich = { wert: x.v.wert, mittelpreis: x.v.mittelpreis, anzahl: x.v.anzahl, formel: x.v.formelText, werte: (x.v.werte || []).map(w => ({ label: String(w.label).slice(0, 80), wert: w.wert })) };
  const ertragGenutzt = x.mode === 'ertrag' || geaendert('erMiete') || geaendert('erMieteMonatlich');
  if(ertragGenutzt && x.e && x.e.ertragswert > 0){ const r = x.e; erg.ertrag = { rohertrag: r.rohertrag, bewkoProz: r.bewkoProz, reinertrag: r.reinertrag, bodenwert: r.bodenwert, liegzinsProz: r.liegzinsProz, n: r.n, verv: r.verv, gebaeudeertragswert: r.gebaeudeertragswert, ertragswert: r.ertragswert, miete_qm: r.miete, kaufpreis: r.kaufpreis || null, kaufpreisfaktor: r.kaufpreisfaktor, bruttorendite: r.bruttorendite, nettorendite: r.nettorendite }; }
  if(erg.vergleich || erg.ertrag) liste.unshift({ k: 'ergebnis', an: true, t: `Ergebnisse: ${erg.vergleich ? 'Vergleichswert ' + ga40Eur(erg.vergleich.wert) : ''}${erg.vergleich && erg.ertrag ? ' · ' : ''}${erg.ertrag ? 'Ertragswert ' + ga40Eur(erg.ertrag.ertragswert) : ''} (nur zur Plausibilität)`, ergebnis: erg });
  return liste;
}
function ga40UebernahmeDialog(){
  const x = ga40Lesen(); if(!x){ akqToast('Das Werkzeug lädt noch – gleich noch einmal versuchen.', 3500); return; }
  const e = ga35Entwurf(GA35.obj), l = ga40Vorschlaege(x, e);
  window.__ga40Liste = l;
  if(!l.length){ akqToast('Noch nichts zum Übernehmen – Inserate, Portalwerte oder Ertragsdaten eintragen.', 4500); return; }
  mc24Modal(`<h3>⬇ In die Große Analyse übernehmen</h3>
    <p class="mc24-muted">Inserate und Portalwerte kommen als „Angebot“ in die Vergleichsfälle (nie als Verkauf, nie als belegt). Eckdaten nur, wo in der Erfassung noch nichts steht. Bereits vorhandene Fälle werden nicht doppelt angelegt.</p>
    <div class="ga40-liste">${l.map((v, i) => `<label><input type="checkbox" data-ga40="${i}" ${v.an ? 'checked' : ''}> ${ga35E(v.t)}</label>`).join('')}</div>
    <div class="modal-actions"><span></span><div class="right"><button class="secondary" onclick="schliesseModal()">Abbrechen</button><button onclick="ga40Uebernehmen()">Übernehmen</button></div></div>`, 640);
}
function ga40Uebernehmen(){
  const l = window.__ga40Liste || [], e = ga35Entwurf(GA35.obj);
  const an = new Set([...document.querySelectorAll('[data-ga40]')].filter(c => c.checked).map(c => +c.dataset.ga40));
  let faelle = 0, felder = 0, doppelt = 0, erg = false;
  l.forEach((v, i) => {
    if(!an.has(i)) return;
    if(v.fall){
      const c = v.fall, gleich = e.vergleich.some(w => String(w.preis) === c.preis && String(w.flaeche || '') === String(c.flaeche || '') && String(w.lage || '').toLowerCase() === String(c.lage || '').toLowerCase());
      if(gleich){ doppelt++; return; } if(e.vergleich.length >= 40) return;
      e.vergleich.push(c); faelle++;
    } else if(v.feld){ e.werte[v.feld[0]] = { v: v.feld[1], s: 'assumed' }; felder++; }
    else if(v.ergebnis){ e.schnell = v.ergebnis; erg = true; }
  });
  save(); try{ schliesseModal(); }catch(x){}
  GA35.tab = 'erfassung'; ga35Neuzeichnen();
  akqToast(`⬇ Übernommen: ${faelle} ${faelle === 1 ? 'Vergleichsfall' : 'Vergleichsfälle'}${felder ? ', ' + felder + ' Eckdaten' : ''}${erg ? ', Ergebnisse' : ''}${doppelt ? ' · ' + doppelt + ' schon vorhanden' : ''}.`, 6000);
}

// ── Analysepaket: Makler-Schnellbewertung als Plausibilitätsprüfung ──
(function(){
  const _p = ga35Paket;
  ga35Paket = function(id, e){
    const p = _p.apply(this, arguments);
    try{
      const s = e && e.schnell;
      if(s && (s.vergleich || s.ertrag)) p.broker_quick_check = {
        hinweis: 'Makler-Schnellbewertung mit dem Shooting-Werkzeug. Grundlage sind Angebotspreise (Portal-Preisatlanten, Inserate) und pauschale Faktoren/Annahmen des Maklers. Nur zur Plausibilität und Diskussion verwenden – nicht als Wertquelle, nicht mitteln, keine Parameter daraus als belegt übernehmen. Abweichungen zum eigenen Ergebnis bitte kurz erklären.',
        datum: s.stand, objekttyp_werkzeug: s.typ,
        vergleichswert: s.vergleich ? { ergebnis_eur: Math.round(s.vergleich.wert), mittelwert_eur_m2: Math.round(s.vergleich.mittelpreis), anzahl_werte: s.vergleich.anzahl, formel: s.vergleich.formel, einzelwerte_eur_m2: s.vergleich.werte, status: 'assumed' } : null,
        ertragswert: s.ertrag ? { ergebnis_eur: Math.round(s.ertrag.ertragswert), rohertrag_eur_jahr: Math.round(s.ertrag.rohertrag), miete_eur_m2_monat: s.ertrag.miete_qm, bewirtschaftungskosten_prozent: s.ertrag.bewkoProz, bodenwert_eur: Math.round(s.ertrag.bodenwert), liegenschaftszins_prozent: s.ertrag.liegzinsProz, restnutzungsdauer_jahre: s.ertrag.n, vervielfaeltiger: s.ertrag.verv, kaufpreisfaktor: s.ertrag.kaufpreisfaktor, bruttorendite_prozent: s.ertrag.bruttorendite, status: 'assumed', parameter_herkunft: 'Makler-Annahmen, nicht aus einem Grundstücksmarktbericht belegt' } : null
      };
    }catch(err){ console.error('ga40 paket', err); }
    return p;
  };
  const st = document.createElement('style');
  st.textContent = `.ga40-reiter{display:flex;gap:6px;margin:8px 0 12px;flex-wrap:wrap}.ga40-reiter button{background:var(--bg2);color:var(--text);border:1px solid var(--border);border-radius:999px;padding:7px 14px;font-weight:600}.ga40-reiter button.aktiv{background:var(--orange);border-color:var(--orange);color:#111}.ga40-reiter small{font-weight:400;opacity:.8}
.ga40-leiste{display:flex;flex-wrap:wrap;align-items:center;gap:8px 14px;margin-bottom:8px}.ga40-leiste .ga40-reiter{margin:0}.ga40-info{display:flex;flex-direction:column;flex:1;min-width:200px;font-size:13px}
.ga40-frame{width:100%;height:calc(100vh - 170px);min-height:520px;border:0;border-radius:10px;background:var(--bg)}
.ga40-werte{display:flex;flex-wrap:wrap;gap:10px;margin:6px 0}.ga40-werte>div{flex:1;min-width:150px;border:1px solid var(--border);border-radius:10px;padding:8px 10px}.ga40-werte small{display:block;color:var(--muted)}.ga40-werte b{display:block;font-size:18px}.ga40-werte span{font-size:12px;color:var(--muted)}.ga40-formel{font-size:12px;margin:4px 0}
.ga40-liste{display:flex;flex-direction:column;gap:6px;margin:8px 0;max-height:50vh;overflow:auto}.ga40-liste label{display:flex;gap:8px;align-items:flex-start;font-size:13px;color:var(--text);text-transform:none;letter-spacing:0}.ga40-liste input{width:auto;margin-top:2px}
@media (max-width:760px){.ga40-frame{height:calc(100vh - 230px)}}`;
  document.head.appendChild(st);
})();
