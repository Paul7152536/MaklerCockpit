/* MaklerCockpit v11/v14 – Akquise-Ansicht im neuen Design: Kennzahlen, Filter, Lead-Karten, Detailbereich, Karte, Fotos */
let AQ2 = {sel:null, status:'offen', ort:'', art:'', q:'', sort:'neu', ansicht:'liste', fotoIdx:0, ergebnis:null, map:null, geoLaeuft:false};
const AQ_OFFEN = ['neu','email_geschrieben','kleinanzeigen_geschrieben','nicht_erreicht','nochmal_anrufen','erstkontakt'];
const AQ_KONTAKTIERT = ['email_geschrieben','kleinanzeigen_geschrieben','nicht_erreicht','nochmal_anrufen','erstkontakt'];
const AQ_TERMIN = ['termin','auftrag','online'];
const AQ_ST_KURZ = {neu:'Neu', email_geschrieben:'E-Mail geschrieben', kleinanzeigen_geschrieben:'Kleinanzeigen angeschrieben', nicht_erreicht:'Nicht erreicht', nochmal_anrufen:'Rückruf', erstkontakt:'Kontakt aufgenommen', termin:'Termin', auftrag:'Auftrag', online:'Online', abgeschlossen:'Abgeschlossen'};
const AQ_ST_FARBE = {neu:'#34d399', email_geschrieben:'#5eead4', kleinanzeigen_geschrieben:'#c4b5fd', nicht_erreicht:'#f87171', nochmal_anrufen:'#fb923c', erstkontakt:'#f59e0b', termin:'#22c55e', auftrag:'#60a5fa', online:'#a78bfa', abgeschlossen:'#94a3b8'};
const AQ_ART_KURZ = {Wohnung:'ETW', 'Grundstück':'Grundstück', Reihenhaus:'RH', Sonstiges:'Sonstiges'};

function aqKontakt(o){ return o && o.eigentuemerId ? findKontakt(o.eigentuemerId) : null; }
function aqTel(o){ const k = aqKontakt(o); return o.verkaeuferTelefon || (k && k.telefon) || ''; }
function aqMail(o){ const k = aqKontakt(o); return o.verkaeuferEmail || (k && k.email) || ''; }
function aqName(o){ const k = aqKontakt(o); return o.verkaeuferName || (k && !/^Privat – /.test(k.name||'') ? k.name : '') || ''; }
function aqOrtKurz(o){ let t = String(o.ort||'').replace(/\b\d{5}\b/g,'').trim(); t = t.split(/[,(]/)[0].trim(); return t || '–'; }
function aqDatum(iso){ if(!iso) return ''; const d = new Date(iso); return isNaN(d) ? '' : d.toLocaleDateString('de-DE'); }
function aqEur(n){ return n ? Number(n).toLocaleString('de-DE')+' €' : ''; }
function aqWoche(ts){ return ts && Date.now()-ts < 7*864e5; }
function aqTitel(o){ return o.akqTitel || o.adresse || [o.objektart, o.ort].filter(Boolean).join(' in ') || 'Objekt'; }
function aq2Fotos(o){ return (o.fotos||[]).concat(o.fotoUrl ? [o.fotoUrl] : []); }
function aq2Platzhalter(art){ const ic = {EFH:IC.haus, DHH:IC.haus, Reihenhaus:IC.haus, MFH:IC.mfh, Wohnung:IC.wohnung, 'Grundstück':IC.land, Gewerbe:IC.gewerbe}[art] || IC.haus; return `<div class="platzh ${art==='Grundstück'?'g':''}">${ic}</div>`; }
function aq2BildFehler(img, art){ const d = document.createElement('div'); d.innerHTML = aq2Platzhalter(art); img.replaceWith(d.firstChild); }
function aq2Bild(o, idx){ const f = aq2Fotos(o); if(!f.length) return aq2Platzhalter(o.objektart); const src = f[Math.min(idx||0, f.length-1)]; return `<img src="${akqEsc(src)}" loading="lazy" onerror="aq2BildFehler(this,'${akqEsc(o.objektart)}')">`; }
function aq2PrivatChip(o){ return o.privat==='ja' ? '<span class="chip ok">privat</span>' : o.privat==='unklar' ? '<span class="chip gelb">privat?</span>' : o.privat==='nein' ? '<span class="chip rot">gewerblich</span>' : ''; }

function aqGefiltert(){
  let l = (db.objekte||[]).slice();
  const st = AQ2.status;
  if(st==='offen') l = l.filter(o=>AQ_OFFEN.includes(o.status));
  else if(st==='kontaktiert') l = l.filter(o=>AQ_KONTAKTIERT.includes(o.status));
  else if(st==='mit_tel') l = l.filter(o=>AQ_OFFEN.includes(o.status) && aqTel(o));
  else if(st==='termine') l = l.filter(o=>AQ_TERMIN.includes(o.status));
  else if(st==='preis_gesenkt') l = l.filter(o=>aqPreisInfo(o));
  else if(st!=='alle') l = l.filter(o=>o.status===st);
  if(AQ2.ort) l = l.filter(o=>aqOrtKurz(o)===AQ2.ort);
  if(AQ2.art) l = l.filter(o=>o.objektart===AQ2.art);
  if(AQ2.q){ const q = akqNorm(AQ2.q); l = l.filter(o=>akqNorm([aqTitel(o),o.adresse,o.ort,o.objektart,aqName(o),aqTel(o),aqMail(o),o.quelle,o.details,(o.verlauf||[]).filter(x=>x.typ==='notiz').map(x=>x.text).join(' ')].join(' ')).includes(q)); }
  const prio = {sehr_hoch:0,hoch:1,mittel:2,niedrig:3};
  const s = {
    neu:(a,b)=>(b.createdAt||0)-(a.createdAt||0),
    inserat:(a,b)=>String(b.inseratDatum||'').localeCompare(String(a.inseratDatum||'')) || (b.createdAt||0)-(a.createdAt||0),
    preis_auf:(a,b)=>(Number(a.kaufpreis)||9e12)-(Number(b.kaufpreis)||9e12),
    preis_ab:(a,b)=>(Number(b.kaufpreis)||0)-(Number(a.kaufpreis)||0),
    prio:(a,b)=>((b.favorit?1:0)-(a.favorit?1:0)) || ((prio[a.prioritaet]??2)-(prio[b.prioritaet]??2)) || (b.createdAt||0)-(a.createdAt||0),
  }[AQ2.sort] || ((a,b)=>(b.createdAt||0)-(a.createdAt||0));
  return l.sort(s);
}

// ── Ansicht ──
function renderAkquise(main){
  try{ aqAuftragsartReparieren(); }catch(e){}
  akqDb();
  const orte = {}; (db.objekte||[]).forEach(o=>{ const k = aqOrtKurz(o); orte[k] = (orte[k]||0)+1; });
  const ortListe = Object.entries(orte).sort((a,b)=>b[1]-a[1]).map(x=>x[0]);
  main.innerHTML = `
    <div class="aq-kopf"><div class="ic">${IC.akquise}</div><div><h1>Akquise</h1><div class="sub">Finde und verwalte deine potenziellen Verkäufer.</div></div>
      <div class="knoepfe">
        <button class="secondary" onclick="aq2Suchen()" title="Prompts für Claude/ChatGPT">${IC.lupe} Suchen lassen</button>
        <button class="secondary" onclick="aq2Einfuegen()" title="KI-Ergebnis einfügen (oder einfach Strg+V auf dieser Seite)">${IC.einfuegen} Ergebnis einfügen</button>
        <button class="secondary" onclick="zlDialog()" title="Anzeigenseiten als PDF oder Foto einlesen – ohne KI">📄 Zeitung (PDF)</button>
        <button class="secondary" onclick="aqAuswertung()" title="Welche Quelle bringt Gespräche, Termine und Aufträge?">${IC.dashboard} Auswertung</button>
        <button onclick="aq2NeuerLead()">${IC.plus} Neuer Lead</button>
      </div></div>
    <div id="akqNeustart">${akqNeustartBannerHtml()}</div>
    <div id="aqErgebnis">${aq2ErgebnisHtml()}</div>
    <div class="aq-layout"><div style="min-width:0;">
      <div class="aq-kpis" id="aqKpis"></div>
      <div class="aq-filter">
        <select onchange="AQ2.status=this.value;aq2Liste()">
          ${[['offen','Alle offenen'],['alle','Alle Status']].concat(OBJEKT_STATUS.map(s=>[s[0],s[1].replace(/^\S+\s/,'')])).map(([k,l])=>`<option value="${k}" ${AQ2.status===k?'selected':''}>${l}</option>`).join('')}
          ${['mit_tel','kontaktiert','termine','preis_gesenkt'].includes(AQ2.status)?`<option value="${AQ2.status}" selected>${{mit_tel:'Mit Telefonnummer',kontaktiert:'Kontakt aufgenommen',termine:'Termine & Aufträge',preis_gesenkt:'📉 Preis gesenkt'}[AQ2.status]}</option>`:''}
          ${AQ2.status!=='preis_gesenkt' && (db.objekte||[]).some(o=>aqPreisInfo(o)) ? '<option value="preis_gesenkt">📉 Preis gesenkt</option>' : ''}
        </select>
        <select onchange="AQ2.ort=this.value;aq2Liste()"><option value="">Alle Orte</option>${ortListe.map(o=>`<option ${AQ2.ort===o?'selected':''}>${akqEsc(o)}</option>`).join('')}</select>
        <select onchange="AQ2.art=this.value;aq2Liste()"><option value="">Alle Objektarten</option>${OBJEKT_ARTEN.map(a=>`<option ${AQ2.art===a?'selected':''}>${a}</option>`).join('')}</select>
        <div class="such">${IC.lupe}<input placeholder="Suchen …" value="${akqEsc(AQ2.q)}" oninput="AQ2.q=this.value;aq2Liste()"></div>
        <div class="umschalt"><button class="${AQ2.ansicht==='liste'?'an':''}" title="Liste" onclick="AQ2.ansicht='liste';renderAkquise(document.getElementById('main'))">${IC.liste}</button><button class="${AQ2.ansicht==='karte'?'an':''}" title="Karte" onclick="AQ2.ansicht='karte';renderAkquise(document.getElementById('main'))">${IC.karte}</button></div>
        <select onchange="AQ2.sort=this.value;aq2Liste()">${[['neu','Neueste zuerst'],['inserat','Eingestellt (neueste)'],['prio','Priorität / Favoriten'],['preis_auf','Preis aufsteigend'],['preis_ab','Preis absteigend']].map(([k,l])=>`<option value="${k}" ${AQ2.sort===k?'selected':''}>${l}</option>`).join('')}</select>
      </div>
      <div id="aqListe"></div>
    </div><div id="aqDetail"></div></div>
    <div class="leer-hinweis" style="margin-top:14px;font-style:normal;">⚖️ Private Verkäufer ohne vorherige Einwilligung anzurufen oder per E-Mail/Nachricht zu bewerben, ist abmahnriskant (§ 7 UWG). Auf Anzeigen mit „keine Makler“ nicht reagieren. · Tipp: Strg+V auf dieser Seite fügt ein KI-Ergebnis oder ein Foto ein, ↑/↓ wechselt den Lead.</div>`;
  aq2Liste();
}
function aq2Kpis(){
  const alle = db.objekte||[];
  const offen = alle.filter(o=>AQ_OFFEN.includes(o.status));
  const tel = offen.filter(o=>aqTel(o));
  const kont = alle.filter(o=>AQ_KONTAKTIERT.includes(o.status));
  const term = alle.filter(o=>AQ_TERMIN.includes(o.status));
  const k = (key, kl, ic, z, l, d) => `<div class="kpi2 ${kl} ${AQ2.status===key?'aktiv':''}" onclick="AQ2.status=(AQ2.status==='${key}'&&'${key}'!=='offen')?'offen':'${key}';renderAkquise(document.getElementById('main'))">
      <div class="kr">${ic}</div><div><div class="kz">${z}</div><div class="kl">${l}</div></div>${d?`<div class="kd">+${d} ↗</div>`:''}</div>`;
  return k('offen','k-mint',IC.person,offen.length,'Offene Leads',offen.filter(o=>aqWoche(o.createdAt)).length)
    + k('mit_tel','k-blau',IC.tel,tel.length,'Mit Telefon',tel.filter(o=>aqWoche(o.createdAt)).length)
    + k('kontaktiert','k-gelb',IC.kal,kont.length,'Kontaktiert',kont.filter(o=>aqWoche(o.statusAm)).length)
    + k('termine','k-lila',IC.stern,term.length,'Termine & Aufträge',term.filter(o=>aqWoche(o.statusAm)).length);
}
function aq2Liste(){
  const kp = document.getElementById('aqKpis'); if(kp) kp.innerHTML = aq2Kpis();
  const el = document.getElementById('aqListe'); if(!el) return;
  const l = aqGefiltert();
  if(!l.find(o=>o.id===AQ2.sel)) { AQ2.sel = l.length ? l[0].id : (findObjekt(AQ2.sel) ? AQ2.sel : null); AQ2.fotoIdx = 0; }
  if(AQ2.ansicht==='karte'){ el.innerHTML = `<div id="aqKarte"></div><div class="leer-hinweis" id="aqKarteInfo" style="margin-top:6px;"></div>`; aq2Karte(l); aq2Detail(); return; }
  if(!l.length){
    el.innerHTML = (db.objekte||[]).length ? `<div class="aq-leer"><b>Keine Leads für diesen Filter</b>Filter oben ändern oder „Alle Status“ wählen.</div>`
      : `<div class="aq-leer"><b>Noch keine Leads</b>Klick auf „Suchen lassen“, kopier einen Prompt, lass Claude oder ChatGPT suchen – und füg die Antwort mit Strg+V hier ein.<div style="margin-top:14px;display:flex;gap:8px;justify-content:center;"><button onclick="aq2Suchen()">${IC.lupe.replace('<svg','<svg style="width:15px;height:15px;vertical-align:-3px;margin-right:4px"')}Suchen lassen</button><button class="secondary" onclick="aq2Einfuegen()">Ergebnis einfügen</button></div></div>`;
    aq2Detail(); return;
  }
  const tmap = aqTerminMap();
  el.innerHTML = l.slice(0,300).map(o=>{
    const tel = aqTel(o);
    return `<div class="lc ${o.id===AQ2.sel?'aktiv':''}" id="lc-${o.id}" onclick="aq2Waehlen('${o.id}')">
      <div class="lc-bild">${aq2Bild(o,0)}</div>
      <div class="lc-mitte">
        <div class="lc-titel">${o.favorit?'<span style="color:#fbbf24;">★</span> ':''}${akqEsc(aqTitel(o))}</div>
        <div class="lc-ort">${IC.pin}${akqEsc([o.adresse, o.ort].filter(Boolean).join(', ')||'Ort unbekannt')}</div>
        <div class="lc-specs">${o.wohnflaeche?`<span>${IC.flaeche}${o.wohnflaeche} m²</span>`:''}${o.zimmer?`<span>${IC.zimmer}${akqEsc(o.zimmer)} Zi.</span>`:''}${o.grundstueck?`<span>${IC.grund}${Number(o.grundstueck).toLocaleString('de-DE')} m²</span>`:''}${o.kaufpreis?`<span class="preis">${aqEur(o.kaufpreis)}</span>`:''}</div>
        <div class="lc-tags"><span class="chip">${akqEsc(AQ_ART_KURZ[o.objektart]||o.objektart||'–')}</span>${aq2PrivatChip(o)}${aqPreisChip(o)}${aqMarktChip(o)}${aqKaeuferChip(o)}${o.quelle?`<span class="chip" style="background:transparent;">${akqEsc(o.quelle)}</span>`:''}<span class="chip dok-chip" data-dokz="${o.id}">${(o.dokumente||[]).length ? '📎 ' + o.dokumente.length : ''}</span></div>
      </div>
      <div class="lc-rechts"><span class="pill st-${akqEsc(o.status)}">${AQ_ST_KURZ[o.status]||o.status}</span><span class="lc-termin" data-lct="${o.id}">${aqTerminChip(tmap[o.id])}</span>
        <span>${o.inseratDatum?'eingestellt am '+aqDatum(o.inseratDatum):'erfasst am '+aqDatum(o.createdAt)}</span>
        <span class="tel">${tel ? IC.tel+akqEsc(tel)
          : o.link ? `<a href="#" class="lc-expose" onclick="event.stopPropagation();aqLinkOeffnen('${o.id}');return false;" title="${akqEsc(o.link)}">${IC.link}Exposé öffnen</a>`
          : IC.tel+(aqMail(o)?'<span style="color:var(--muted);font-size:12px;">nur E-Mail</span>':o.chiffre?'<span style="color:var(--muted);font-size:12px;">Chiffre '+akqEsc(o.chiffre)+'</span>':'<span style="color:var(--muted);font-size:12px;">keine Kontaktdaten</span>')}</span></div>
      <div class="lc-pfeil">›</div></div>`;
  }).join('') + (l.length>300?`<div class="leer-hinweis">… ${l.length-300} weitere – Filter nutzen.</div>`:'');
  aq2Detail();
}
function aq2Waehlen(id){
  const alt = document.getElementById('lc-'+AQ2.sel); if(alt) alt.classList.remove('aktiv');
  AQ2.sel = id; AQ2.fotoIdx = 0; AQ2.linkEdit = false;
  const neu = document.getElementById('lc-'+id); if(neu) neu.classList.add('aktiv');
  aq2Detail();
}

// ── Detailbereich ──
function aq2Detail(){
  const el = document.getElementById('aqDetail'); if(!el) return;
  const o = findObjekt(AQ2.sel);
  if(!o){ el.innerHTML = `<div class="dp"><div class="dp-leer">Wähle links einen Lead aus.</div></div>`; return; }
  const fotos = aq2Fotos(o); const idx = Math.min(AQ2.fotoIdx, Math.max(fotos.length-1,0));
  const tel = aqTel(o), mail = aqMail(o), name = aqName(o);
  const z = (k, w) => `<div class="dp-zeile"><span class="k">${k}</span><span class="w">${w}</span></div>`;
  el.innerHTML = `<div class="dp"><div class="dp-scroll">
    <div class="dp-kopf">Aktiver Lead<span class="sp"></span>
      <button class="tb-icon" title="${o.favorit?'Favorit entfernen':'Als Favorit markieren'}" onclick="aq2Favorit()" style="${o.favorit?'color:#fbbf24':''}">${o.favorit?IC.sternVoll:IC.stern}</button>
      <button class="tb-icon" title="Alle Felder bearbeiten" onclick="oeffneObjektModal('${o.id}')">${IC.stift}</button>
      <button class="tb-icon" title="Mehr" onclick="aq2Mehr(event)">${IC.mehr}</button></div>
    <div class="dp-bild" id="dpBild" ondragover="event.preventDefault();this.classList.add('drop')" ondragleave="this.classList.remove('drop')" ondrop="event.preventDefault();this.classList.remove('drop');aq2FotosLaden(event.dataTransfer.files)">
      ${aq2Bild(o, idx)}<span class="pill st-${akqEsc(o.status)} ov">${AQ_ST_KURZ[o.status]||o.status}</span>
      ${fotos.length>1?`<button class="nav l" onclick="aq2Foto(-1)">${IC.links.replace('<svg','<svg style="width:18px;height:18px"')}</button><button class="nav r" onclick="aq2Foto(1)">${IC.rechts.replace('<svg','<svg style="width:18px;height:18px"')}</button><span class="zaehl">${idx+1} / ${fotos.length}</span>`:''}
      <button class="foto-neu" onclick="document.getElementById('aqFotoInput').click()" title="Foto auswählen, hierher ziehen oder mit Strg+V einfügen">📷 ${fotos.length?'Foto +':'Foto hinzufügen'}</button>
    </div>
    <input type="file" id="aqFotoInput" accept="image/*" multiple style="display:none" onchange="aq2FotosLaden(this.files)">
    ${o.link && !fotos.length && window.pc && window.pc.seite ? `<button class="secondary tiny" style="margin-top:8px;" onclick="aq2FotoAusAnzeige()">🖼️ Bild aus der Anzeige laden</button>` : ''}
    <h2>${akqEsc(aqTitel(o))}</h2>
    <div class="lc-ort">${IC.pin}${akqEsc([o.adresse, o.ort].filter(Boolean).join(', ')||'Ort unbekannt')}</div>
    ${o.kaufpreis?`<div class="preis">${aqEur(o.kaufpreis)}${o.auftragsart==='vermietung' && Number(o.kaufpreis) < 20000 ?' / Monat':''}</div>${aqPreisAltHtml(o)}`:''}
    <div class="dp-specs"><div>${IC.flaeche}${o.wohnflaeche?o.wohnflaeche+' m²':'–'}<small>Wohnfläche</small></div><div>${IC.zimmer}${o.zimmer?akqEsc(o.zimmer):'–'}<small>Zimmer</small></div><div>${IC.grund}${o.grundstueck?Number(o.grundstueck).toLocaleString('de-DE')+' m²':'–'}<small>Grundstück</small></div></div>
    <div class="lc-tags"><span class="chip">${akqEsc(o.objektart||'–')}</span>${aq2PrivatChip(o)}${o.baujahr?`<span class="chip">Bj. ${akqEsc(o.baujahr)}</span>`:''}</div>
    ${aq2MarktHtml(o)}${aqKiHtml(o)}${aqSuchkundenHtml(o)}
    <div class="dp-abschnitt"><h4>${IC.person} Kontaktdaten</h4>
      ${z(IC.person+'Name', name?akqEsc(name):'<span style="color:var(--muted)">Nicht angegeben</span>')}
      ${z(IC.tel+'Telefon', tel?`<a href="#" onclick="aq2Anrufen();return false;">${akqEsc(tel)}</a>`:'<span style="color:var(--muted)">Nicht angegeben</span>')}
      ${z(IC.mail+'E-Mail', mail?`<a href="#" onclick="aq2Email();return false;">${akqEsc(mail)}</a>`:'<span style="color:var(--muted)">Nicht angegeben</span>')}
      ${z(IC.link+'Exposé', aq2LinkHtml(o))}
      ${!tel && !mail ? `<div class="dp-hinweis-expose">${o.link ? 'Keine Telefonnummer und keine E-Mail – Kontakt über das Exposé (Nachricht übers Portal).' : 'Keine Kontaktdaten – füg oben den Link zum Exposé ein, damit du den Eigentümer erreichst.'}</div>` : ''}
    </div>
    <div class="dp-abschnitt" id="dpTermine">${aq2TermineHtml(o)}</div>
    ${typeof dokSektionHtml==='function' && dokVerfuegbar() ? `<div class="dp-abschnitt">${dokSektionHtml(o)}</div>` : ''}
    <div class="dp-abschnitt"><h4>${IC.doku} Details</h4>
      ${z('Status', `<select onchange="aq2StatusSetzen(this.value)" style="padding:5px 8px;">${OBJEKT_STATUS.map(s=>`<option value="${s[0]}" ${o.status===s[0]?'selected':''}>${s[1]}</option>`).join('')}</select>`)}
      ${z(IC.kal+'Eingestellt am', o.inseratDatum?aqDatum(o.inseratDatum):'–')}
      ${z(IC.info+'Quelle', akqEsc([o.quelle, o.quelleText, o.seite?'Seite '+o.seite:''].filter(Boolean).join(' · ')||'–'))}
      ${o.chiffre?z(IC.doku+'Chiffre', akqEsc(o.chiffre)):''}
      ${o.details?z(IC.info+'Besonderheiten', akqEsc(o.details)):''}
      ${o.statusText?z(IC.info+'Einschätzung', akqEsc(o.statusText)):''}
      ${o.anrufVersuche?z(IC.tel+'Anrufversuche', o.anrufVersuche):''}
    </div>
    <div class="dp-abschnitt"><h4>${IC.notiz} Notizen & Verlauf</h4>
      <div class="dp-notiz-neu"><textarea id="dpNotiz" placeholder="Notiz schreiben … (Strg+Enter speichert)" oninput="AQ_ENTWURF[AQ2.sel]=this.value" onkeydown="if(event.key==='Enter'&&(event.ctrlKey||event.metaKey)){event.preventDefault();aq2NotizHinzu();}">${akqEsc(AQ_ENTWURF[o.id]||'')}</textarea>
        <button class="tiny" onclick="aq2NotizHinzu()">Notiz speichern</button></div>
      <div class="vl-kopf">Verlauf</div>
      ${aqVerlaufHtml(o)}
    </div></div>
    <div id="dpErgebnis" class="dp-ergebnis"></div>
    <div class="dp-aktionen">
      ${!tel && o.link ? `<button onclick="aqLinkOeffnen('${o.id}')">${IC.link} Exposé</button>` : `<button onclick="aq2Anrufen()">${IC.tel} Anrufen</button>`}
      <button class="secondary" onclick="aq2Email()" title="${aqNachfassenFaellig(o) ? 'Nachfass-Text (Vorlage „Nachfassen“)' : mail ? 'E-Mail mit Vorlage öffnen' : 'Kurznachricht kopieren und Anzeige öffnen'}">${IC.mail} ${aqNachfassenFaellig(o) ? 'Nachfassen' : !mail && o.link ? 'Nachricht' : 'E-Mail'}</button>
      <button class="secondary" onclick="aq2TerminNeu()">${IC.kal} Termin</button>
      <button class="secondary" onclick="aq2NotizFokus()">${IC.notiz} Notiz</button>
    </div></div>`;
  aq2DpHoehe();
}
// ── v16: Exposé-Link ──
function aqLinkDomain(u){ try{ return new URL(u).hostname.replace(/^www\./,''); }catch(e){ return ''; } }
function aqLinkOeffnen(id){ const o = findObjekt(id); if(o && o.link) window.open(o.link, '_blank'); }
function aq2LinkHtml(o){
  if(o.link && !AQ2.linkEdit) return `<a href="#" onclick="aqLinkOeffnen('${o.id}');return false;" title="${akqEsc(o.link)}">Exposé öffnen ↗</a> <small style="color:var(--muted);">${akqEsc(aqLinkDomain(o.link))}</small>
    <button class="tb-icon mini" title="Link ändern" onclick="AQ2.linkEdit=true;aq2Detail();setTimeout(()=>{const f=document.getElementById('dpLink');if(f){f.focus();f.select();}},20)">${IC.stift}</button>`;
  return `<span class="dp-link-neu"><input id="dpLink" value="${akqEsc(o.link||'')}" placeholder="Link zum Exposé einfügen (https://…)" onkeydown="if(event.key==='Enter'){event.preventDefault();aq2LinkSetzen(this.value);}if(event.key==='Escape'){AQ2.linkEdit=false;aq2Detail();}">
    <button class="tiny" onclick="aq2LinkSetzen(document.getElementById('dpLink').value)">Speichern</button></span>`;
}
function aq2LinkSetzen(wert){
  const o = findObjekt(AQ2.sel); if(!o) return;
  const v = String(wert||'').trim();
  if(!v && o.link){ o.link = ''; AQ2.linkEdit = false; aqLog(o, 'info', 'Exposé-Link entfernt'); save(); aq2Liste(); return; }
  const url = akqLinkAus(v);
  if(!url){ akqToast('Bitte einen vollständigen Link einfügen (beginnt mit https://)'); return; }
  const neu = !o.link;
  o.link = url; AQ2.linkEdit = false;
  if(!o.quelle || o.quelle === 'Direktakquise'){ const q = akqQuelle({ link:url }); if(q !== 'Direktakquise') o.quelle = q; }
  aqLog(o, 'info', neu ? 'Exposé-Link hinzugefügt (' + aqLinkDomain(url) + ')' : 'Exposé-Link geändert (' + aqLinkDomain(url) + ')');
  save(); aq2Liste(); akqToast('🔗 Link zum Exposé gespeichert');
}
// Alte Importe: Kaufpreis wurde teils als Monatsmiete erkannt (Hausgeld „mtl.“ in den Details) → einmalig korrigieren
function aqAuftragsartReparieren(){
  let n = 0;
  (db.objekte||[]).forEach(o => { if(o.auftragsart === 'vermietung' && Number(o.kaufpreis) >= 20000){ o.auftragsart = 'verkauf'; n++; } });
  if(n) save();
  return n;
}
function aq2DpHoehe(){ const dp = document.querySelector('#aqDetail .dp'); if(!dp) return; const top = Math.max(dp.getBoundingClientRect().top, 70); dp.style.maxHeight = Math.max(360, window.innerHeight - top - 14) + 'px'; }
window.addEventListener('resize', aq2DpHoehe);
document.addEventListener('scroll', e=>{ if(e.target && e.target.id==='main') aq2DpHoehe(); }, true);
function aq2Neu(){ aq2Liste(); renderNav(); try{ tbGlockeAktualisieren(); }catch(e){} }
// ── Verlauf: jede Aktion und jede Notiz mit Zeitstempel ──
const AQ_VL_IC = {import:'📥', info:'🔁', status:'🏷️', anruf:'📞', email:'✉️', termin:'📅', notiz:'📝'};
const AQ_ENTWURF = {};
function aqLog(o, typ, text){
  aqVerlaufHolen(o);
  const ts = Date.now();
  o.verlauf.push({ts, typ, text:String(text||'')});
  const d = new Date(ts);
  o.notizen = (o.notizen ? o.notizen+'<br>' : '') + `${d.toLocaleDateString('de-DE')} ${d.toLocaleTimeString('de-DE',{hour:'2-digit',minute:'2-digit'})} – ${AQ_VL_IC[typ]||''} ${akqEsc(text)}`;
}
function aq2Verlauf(o, text, typ){ aqLog(o, typ||'info', text); }
// Ältere Leads: Verlauf einmalig aus den Notizen aufbauen
function aqVerlaufHolen(o){
  if(Array.isArray(o.verlauf)) return o.verlauf;
  const v = [];
  v.push({ts:o.createdAt||Date.now(), typ:'import', text:`Aus ${o.quelle||'Akquise'} übernommen${o.seite?' · Seite '+o.seite:''}`});
  const zeilen = String(o.notizen||'').split(/<br\s*\/?>/i).map(z=>z.replace(/<[^>]+>/g,'').replace(/&amp;/g,'&').replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&quot;/g,'"').replace(/&#39;/g,"'").trim());
  const tsAus = (d, t) => { const m = /(\d{1,2})\.(\d{1,2})\.(\d{4})/.exec(d); if(!m) return null; const [hh,mm] = (t||'12:00').split(':').map(Number); return new Date(+m[3], +m[2]-1, +m[1], hh||0, mm||0).getTime(); };
  for(const z of zeilen){
    let m;
    if((m = /^(\d{1,2}\.\d{1,2}\.\d{4})\s+(\d{1,2}:\d{2})\s+–\s+(.*)$/.exec(z))){
      const t = m[3]; const typ = /^Status:/.test(t) ? 'status' : /📞/.test(t) ? 'anruf' : /📅|🔁 Rückruf/.test(t) ? 'termin' : 'info';
      v.push({ts:tsAus(m[1],m[2]), typ, text:t.replace(/^[📞📅🔁]\s*/u,'').replace(/^erreicht$/,'Angerufen – erreicht').replace(/^nicht erreicht$/,'Angerufen – nicht erreicht')});
    } else if((m = /Erneut gefunden am (\d{1,2}\.\d{1,2}\.\d{4})(.*)$/.exec(z))){
      v.push({ts:tsAus(m[1]), typ:'info', text:'Erneut gefunden'+m[2].trim().replace(/^\(/,' (')});
    } else if((m = /E-Mail geschrieben am (\d{1,2}\.\d{1,2}\.\d{4})/.exec(z))){
      v.push({ts:o.emailAm||tsAus(m[1]), typ:'email', text:'E-Mail geschrieben'});
    }
  }
  if(o.leadNotiz && o.leadNotiz.trim()){ const spaet = Math.max(o.statusAm||0, o.emailAm||0, ...v.map(x=>x.ts||0)); v.push({ts:Math.min(Date.now(), spaet+60000), typ:'notiz', text:o.leadNotiz.trim()}); o.leadNotiz = ''; }
  o.verlauf = v.filter(x=>x.ts).sort((a,b)=>a.ts-b.ts);
  return o.verlauf;
}
function aqZeit(ts){
  const d = new Date(ts), h = new Date(); const tag = x => new Date(x.getFullYear(), x.getMonth(), x.getDate()).getTime();
  const diff = Math.round((tag(h)-tag(d))/864e5);
  const datum = diff===0 ? 'Heute' : diff===1 ? 'Gestern' : d.toLocaleDateString('de-DE', d.getFullYear()===h.getFullYear() ? {day:'2-digit', month:'2-digit'} : {day:'2-digit', month:'2-digit', year:'2-digit'});
  return {datum, uhr:d.toLocaleTimeString('de-DE',{hour:'2-digit',minute:'2-digit'})};
}
const AQ_VL_ALLE = {};
function aqVerlaufHtml(o){
  const v = aqVerlaufHolen(o).slice().sort((a,b)=>b.ts-a.ts);
  if(!v.length) return '<div class="vl-leer">Noch nichts passiert.</div>';
  const alle = AQ_VL_ALLE[o.id], zeigen = alle ? v : v.slice(0,6);
  return `<div class="vl">${zeigen.map(x=>{ const z = aqZeit(x.ts); return `<div class="vl-i vl-${x.typ}">
      <span class="vl-t"><span>${z.datum}</span><b>${z.uhr}</b></span><span class="vl-ic">${AQ_VL_IC[x.typ]||'•'}</span>
      <span class="vl-x">${akqEsc(x.text)}</span>${x.typ==='notiz'?`<button class="vl-weg" title="Notiz löschen" onclick="aq2NotizWeg(${x.ts})">✕</button>`:''}</div>`; }).join('')}</div>
    ${v.length>6?`<button class="secondary tiny" style="margin-top:6px;" onclick="AQ_VL_ALLE['${o.id}']=!AQ_VL_ALLE['${o.id}'];aq2Detail()">${alle?'Weniger anzeigen':'Alle '+v.length+' Einträge'}</button>`:''}`;
}
function aq2NotizHinzu(){
  const o = findObjekt(AQ2.sel); const t = document.getElementById('dpNotiz'); if(!o || !t) return;
  const text = t.value.trim(); if(!text){ t.focus(); return; }
  aqLog(o, 'notiz', text); delete AQ_ENTWURF[o.id]; save(); aq2Detail(); akqToast('📝 Notiz gespeichert');
  const n = document.getElementById('dpNotiz'); if(n) n.focus();
}
function aq2NotizWeg(ts){
  const o = findObjekt(AQ2.sel); if(!o) return;
  bestaetigeUnten('Diese Notiz löschen?', ()=>{ o.verlauf = (o.verlauf||[]).filter(x=>!(x.typ==='notiz' && x.ts===ts)); save(); aq2Detail(); });
}
function aq2StatusSetzen(st, ohneVerlauf){
  const o = findObjekt(AQ2.sel); if(!o || o.status===st) return;
  o.status = st; o.statusAm = Date.now();
  if(st==='email_geschrieben'){ o.emailAm = Date.now(); o.followupEmailVersendet = true; }
  if(st==='kleinanzeigen_geschrieben'){ o.kleinanzeigenAm = Date.now(); }
  if(!ohneVerlauf) aqLog(o, ['email_geschrieben','kleinanzeigen_geschrieben'].includes(st)?'email':'status', st==='email_geschrieben'?'E-Mail geschrieben':st==='kleinanzeigen_geschrieben'?'Per Kleinanzeigen angeschrieben':'Status: '+(AQ_ST_KURZ[st]||st));
  save(); aq2Neu();
}
function aq2Favorit(){ const o = findObjekt(AQ2.sel); if(!o) return; o.favorit = !o.favorit; if(o.favorit && o.prioritaet!=='sehr_hoch'){ o.prioritaetVorher = o.prioritaet; o.prioritaet = 'sehr_hoch'; } else if(!o.favorit && o.prioritaetVorher){ o.prioritaet = o.prioritaetVorher; } save(); aq2Liste(); }
let aqNotizTimer = null;
function aq2NotizSpeichern(v){ AQ_ENTWURF[AQ2.sel] = v; }
function aq2NotizFokus(){ const t = document.getElementById('dpNotiz'); if(t){ t.focus(); t.scrollIntoView({block:'center', behavior:'smooth'}); } }
function aq2Foto(d){ const o = findObjekt(AQ2.sel); if(!o) return; const n = aq2Fotos(o).length; AQ2.fotoIdx = (AQ2.fotoIdx + d + n) % n; aq2Detail(); }

// Anrufen / E-Mail mit Ergebnis-Knöpfen
function aq2ErgebnisZeigen(html){ const e = document.getElementById('dpErgebnis'); if(e) e.innerHTML = html; }
function aq2Anrufen(){
  const o = findObjekt(AQ2.sel); if(!o) return;
  const tel = aqTel(o);
  if(!tel){ akqToast(o.chiffre ? 'Nur Chiffre – Antwort über die Zeitung' : o.link ? 'Keine Nummer – Kontakt über die Anzeige' : 'Keine Telefonnummer vorhanden'); return; }
  window.open('tel:'+akqTelNorm(tel), '_blank');
  aq2ErgebnisZeigen(`<span style="font-size:12px;color:var(--muted);width:100%;">Wie lief der Anruf?</span>
    <button onclick="aq2Anruf('erstkontakt')">✅ Erreicht</button><button class="secondary" onclick="aq2Anruf('nicht_erreicht')">❌ Nicht erreicht</button>
    <button class="secondary" onclick="aq2TerminFrage('nochmal_anrufen')">🔁 Rückruf</button><button class="secondary" onclick="aq2TerminFrage('termin')">📅 Termin</button>`);
}
function aq2Anruf(st){
  const o = findObjekt(AQ2.sel); if(!o) return;
  o.anrufVersuche = (o.anrufVersuche||0)+1;
  aqLog(o, 'anruf', st==='erstkontakt' ? 'Angerufen – erreicht' : `Angerufen – nicht erreicht (${o.anrufVersuche}. Versuch)`);
  o.status = st; o.statusAm = Date.now(); save(); aq2Neu();
  akqToast(st==='erstkontakt' ? 'Gespeichert: Kontakt aufgenommen' : `Gespeichert: nicht erreicht (${o.anrufVersuche}. Versuch)`);
}
function aq2TerminFrage(st){ aq2ErgebnisZeigen(''); aq2TerminNeu(st==='termin' ? 'besichtigung' : 'rueckruf'); }

// ── v14: Termine direkt am Lead ──
const AQ_TA = [
  {k:'besichtigung', l:'Besichtigung', ic:'👀', dauer:60, st:'termin'},
  {k:'erstgespraech', l:'Erstgespräch', ic:'🤝', dauer:60, st:'termin'},
  {k:'akquise', l:'Akquise-Termin', ic:'🎯', dauer:60, st:'termin'},
  {k:'rueckruf', l:'Rückruf', ic:'🔁', dauer:15, st:'nochmal_anrufen'},
  {k:'termin', l:'Sonstiges', ic:'📅', dauer:60, st:''},
];
let AQ_TQ = null;
function aqTD(k){ return typeof gsDatumLang==='function' ? gsDatumLang(k) : aqDatum(k); }
function aqTermineVon(o){ return (db.termine||[]).filter(t=>t.objektId===o.id).sort((a,b)=>(a.datum+(a.uhrzeit||'')).localeCompare(b.datum+(b.uhrzeit||''))); }
function aqTerminMap(){
  const h = toDateKey(new Date()), m = {};
  (db.termine||[]).forEach(t=>{ if(!t.objektId || !t.datum || t.datum < h) return; const a = m[t.objektId]; if(!a || (t.datum+(t.uhrzeit||'')) < (a.datum+(a.uhrzeit||''))) m[t.objektId] = t; });
  return m;
}
function aqTerminChip(t){ return t ? '📅 ' + aqTD(t.datum) + (t.uhrzeit ? ' ' + t.uhrzeit : '') : ''; }
function aq2TermineHtml(o){
  const l = aqTermineVon(o), h = toDateKey(new Date());
  const kommend = l.filter(t=>t.datum>=h), vorbei = l.filter(t=>t.datum<h).reverse().slice(0,2);
  const zeile = (t, alt) => `<div class="dp-termin ${alt?'vorbei':''}" onclick="oeffneTerminModal('${t.id}')" title="Termin öffnen / ändern">
      <span class="dt-d"><b>${aqTD(t.datum)}</b><small>${t.uhrzeit ? t.uhrzeit + (typeof gsEnde==='function' ? '–' + gsEnde(t) : '') : 'ganztägig'}</small></span>
      <span class="dt-x">${typeof gsArtIcon==='function' ? gsArtIcon(t) : '📅'} ${akqEsc(typeof gsArtLabel==='function' ? gsArtLabel(t) : t.titel)}${t.ort ? `<small>${akqEsc(t.ort)}</small>` : ''}</span>${typeof gsSyncIcon==='function' ? gsSyncIcon(t) : ''}</div>`;
  const leer = `<div class="vl-leer">Noch kein Termin.${typeof gsAktiv==='function' && gsAktiv() ? ' Neue Termine gehen automatisch in deinen Google Kalender.' : ''}</div>`;
  return `<h4>${IC.kal} Termine<span class="sp"></span><button class="tiny" onclick="aq2TerminNeu()">+ Termin</button></h4>`
    + ((kommend.length || vorbei.length) ? kommend.map(t=>zeile(t,false)).join('') + vorbei.map(t=>zeile(t,true)).join('') : leer);
}
function aq2TermineAktualisieren(){
  const el = document.getElementById('dpTermine'), o = findObjekt(AQ2.sel);
  if(el && o) el.innerHTML = aq2TermineHtml(o);
  const m = aqTerminMap(); document.querySelectorAll('[data-lct]').forEach(sp=>{ sp.textContent = aqTerminChip(m[sp.dataset.lct]); });
}
function aq2TqTitel(a, o){ return (a.k==='termin' ? 'Termin' : a.l) + ': ' + aqTitel(o) + (o.ort ? ' (' + aqOrtKurz(o) + ')' : ''); }
function aq2TerminNeu(art){
  const o = findObjekt(AQ2.sel); if(!o) return;
  const a = AQ_TA.find(x=>x.k===art) || AQ_TA[0];
  AQ_TQ = { objektId:o.id, art:a.k, titelManuell:false };
  const morgen = gsTagPlus(toDateKey(new Date()), 1), ort = [o.adresse, o.ort].filter(Boolean).join(', ');
  const verbunden = typeof gsAktiv==='function' && gsAktiv();
  const inner = document.getElementById('modalInner');
  inner.innerHTML = `
    <h3>📅 Termin eintragen</h3>
    <div class="tq-lead"><div class="tq-bild">${aq2Bild(o,0)}</div><div><b>${akqEsc(aqTitel(o))}</b><small>${akqEsc([ort||'Ort unbekannt', aqName(o), aqTel(o)].filter(Boolean).join(' · '))}</small></div></div>
    <div class="tq-arten">${AQ_TA.map(x=>`<button type="button" class="tq-art ${x.k===a.k?'an':''}" data-k="${x.k}" onclick="aq2TqArt('${x.k}')">${x.ic} ${x.l}</button>`).join('')}</div>
    <div class="field-row">
      <div><label>Datum</label><input type="date" id="tq_datum" value="${morgen}" oninput="aq2TqTag()"></div>
      <div style="min-width:110px;"><label>Uhrzeit</label><input type="time" id="tq_zeit" value="10:00" step="300" oninput="aq2TqTag()"></div>
      <div style="min-width:110px;"><label>Dauer</label><select id="tq_dauer" onchange="aq2TqTag()">${GS_DAUERN.map(m=>`<option value="${m}" ${m===a.dauer?'selected':''}>${gsDauerText(m)}</option>`).join('')}</select></div>
    </div>
    <div class="tq-schnell">${[['Heute',0],['Morgen',1],['Übermorgen',2],['+1 Woche',7]].map(([l,n])=>`<button type="button" class="secondary tiny" onclick="aq2TqDatum(${n})">${l}</button>`).join('')}</div>
    <div id="tq_slots" class="ts"></div>
    <div id="tq_tag" class="tq-tag"></div>
    <label>Titel im Kalender</label><input id="tq_titel" oninput="AQ_TQ.titelManuell=true">
    <label>Ort</label><input id="tq_ort" value="${akqEsc(ort)}" placeholder="Adresse oder „Telefon“">
    <label>Notiz</label><textarea id="tq_notiz" rows="2" placeholder="z. B. Unterlagen mitbringen, Grundbuchauszug, Ansprechpartner …"></textarea>
    <label class="gs-chk" id="tq_st_wrap"><input type="checkbox" id="tq_status" checked> <span id="tq_st_text"></span></label>
    ${verbunden ? '<div class="gs-hinweis"><span style="color:var(--green);">✓</span> Geht automatisch in deinen Google Kalender – mit Telefonnummer, Adresse und Anzeige in der Beschreibung.</div>'
      : (typeof gsVerfuegbar==='function' && gsVerfuegbar() ? '<div class="gs-hinweis">Nur an diesem PC · <a href="#" onclick="schliesseModal();gsAssistent();return false;">Google Kalender verbinden</a></div>' : '')}
    <div class="modal-actions"><div></div><div class="right"><button class="secondary" onclick="schliesseModal()">Abbrechen</button><button onclick="aq2TerminAnlegen()">📅 Termin speichern</button></div></div>`;
  inner.style.width = '640px'; inner.style.maxWidth = '94vw';
  document.getElementById('modalBg').classList.add('show');
  aq2TqArt(a.k, true);
  inner.onkeydown = e => { if(e.key==='Enter' && (e.ctrlKey || e.metaKey) && document.getElementById('tq_datum')){ e.preventDefault(); aq2TerminAnlegen(); } };
}
function aq2TqArt(k, init){
  const a = AQ_TA.find(x=>x.k===k) || AQ_TA[0], o = findObjekt(AQ_TQ && AQ_TQ.objektId); if(!o) return;
  AQ_TQ.art = a.k;
  document.querySelectorAll('.tq-art').forEach(b=>b.classList.toggle('an', b.dataset.k===a.k));
  if(!AQ_TQ.titelManuell) document.getElementById('tq_titel').value = aq2TqTitel(a, o);
  if(!init) document.getElementById('tq_dauer').value = String(a.dauer);
  const ortF = document.getElementById('tq_ort'), ortLead = [o.adresse, o.ort].filter(Boolean).join(', '), telOrt = aqTel(o) ? 'Telefon ' + aqTel(o) : 'Telefon';
  if(a.k==='rueckruf' && (ortF.value===ortLead || !ortF.value)) ortF.value = telOrt;
  else if(a.k!=='rueckruf' && ortF.value===telOrt) ortF.value = ortLead;
  const w = document.getElementById('tq_st_wrap');
  w.style.display = a.st && o.status!==a.st ? '' : 'none';
  document.getElementById('tq_st_text').textContent = a.st ? 'Status auf „' + (AQ_ST_KURZ[a.st]||a.st) + '“ setzen' : '';
  aq2TqTag();
}
function aq2TqDatum(n){ document.getElementById('tq_datum').value = gsTagPlus(toDateKey(new Date()), n); aq2TqTag(); }
function aq2TqTag(){
  const el = document.getElementById('tq_tag'); if(!el) return;
  const d = document.getElementById('tq_datum').value, z = document.getElementById('tq_zeit').value, dauer = Number(document.getElementById('tq_dauer').value) || 60;
  document.getElementById('tq_dauer').disabled = !z;
  if(!d){ el.innerHTML = ''; return; }
  const l = typeof gsTermineAm==='function' ? gsTermineAm(d) : (db.termine||[]).filter(t=>t.datum===d);
  const min = s => { const [h,m] = String(s).split(':').map(Number); return h*60 + m; };
  const a0 = z ? min(z) : 0, a1 = a0 + dauer;
  const kollidiert = t => !!(z && t.uhrzeit && min(t.uhrzeit) < a1 && min(t.uhrzeit) + (Number(t.dauer)||60) > a0);
  const k = l.filter(kollidiert);
  el.innerHTML = `<div class="tq-tag-kopf">${akqEsc(aqTD(d))}: ${l.length ? l.length + ' Termin' + (l.length===1?'':'e') : 'noch nichts eingetragen'}${k.length ? ` · <span class="tq-warn">⚠️ überschneidet sich mit ${k.length===1 ? 'einem Termin' : k.length + ' Terminen'}</span>` : ''}</div>`
    + l.slice(0,6).map(t=>`<div class="tq-tz ${kollidiert(t)?'warn':''}"><b>${t.uhrzeit ? t.uhrzeit + (typeof gsEnde==='function' ? '–' + gsEnde(t) : '') : 'ganztägig'}</b> ${typeof twPre==='function' ? twPre(t) : ''}${akqEsc(t.titel)}</div>`).join('')
    + (l.length > 6 ? `<div class="tq-tz">… und ${l.length-6} weitere</div>` : '');
}
function aq2TerminAnlegen(){
  const o = findObjekt(AQ_TQ && AQ_TQ.objektId); if(!o) return;
  const g = x => document.getElementById(x);
  const a = AQ_TA.find(x=>x.k===AQ_TQ.art) || AQ_TA[0];
  const datum = g('tq_datum').value, uhrzeit = g('tq_zeit').value;
  if(!datum){ g('tq_datum').focus(); akqToast('Bitte ein Datum wählen'); return; }
  const t = { id:uid(), createdAt:Date.now(), geaendertAm:Date.now(), titel: g('tq_titel').value.trim() || aq2TqTitel(a, o), datum, uhrzeit,
    dauer: uhrzeit ? (Number(g('tq_dauer').value) || 60) : null, art:a.k, artEigene:'', ort: g('tq_ort').value.trim(), notiz: g('tq_notiz').value.trim(),
    objektId:o.id, kontaktId:o.eigentuemerId || null };
  db.termine.push(t);
  aqLog(o, 'termin', (a.k==='termin' ? 'Termin' : a.l) + ' am ' + (typeof gsKurzFest==='function' ? gsKurzFest(t) : datum + ' ' + uhrzeit));
  if(a.st && g('tq_status').checked && o.status !== a.st && g('tq_st_wrap').style.display !== 'none'){ o.status = a.st; o.statusAm = Date.now(); }
  if(a.st === 'termin') o.hatTermin = true;
  save(); schliesseModal(); aq2Neu(); if(typeof gsPlanen==='function') gsPlanen(400);
  akqToast(typeof gsAktiv==='function' && gsAktiv() ? '📅 Termin gespeichert – geht jetzt in deinen Google Kalender' : '📅 Termin gespeichert');
}
function aq2Email(){
  const o = findObjekt(AQ2.sel); if(!o) return;
  const mail = aqMail(o), text = o.anschreibenText || akqVorlageFuellen({titel:aqTitel(o), objektart:o.objektart, ort:o.ort, quelle:o.quelle, quelleText:o.quelleText, datum:o.inseratDatum, name:aqName(o)});
  if(mail){
    const betreff = `Ihre Anzeige: ${aqTitel(o)}${o.ort?' in '+aqOrtKurz(o):''}`;
    window.open(`mailto:${encodeURIComponent(mail)}?subject=${encodeURIComponent(betreff)}&body=${encodeURIComponent(text)}`, '_blank');
    aq2ErgebnisZeigen(`<span style="font-size:12px;color:var(--muted);width:100%;">E-Mail-Programm geöffnet – abgeschickt?</span><button onclick="aq2StatusSetzen('email_geschrieben');akqToast('Status: E-Mail geschrieben')">✉️ Ja, geschrieben</button><button class="secondary" onclick="aq2ErgebnisZeigen('')">Nein</button>`);
  } else {
    akqKopieren(text, o.link ? 'Anschreiben kopiert – Anzeige wird geöffnet, dort als Nachricht senden' : o.chiffre ? 'Anschreiben kopiert – Antwort per Chiffre an die Zeitung' : 'Anschreiben kopiert (keine E-Mail-Adresse hinterlegt)');
    if(o.link) window.open(o.link, '_blank');
    const ka = /kleinanzeigen|ebay-kleinanzeigen/i.test((o.link||'') + ' ' + (o.quelle||''));
    aq2ErgebnisZeigen(ka
      ? `<span style="font-size:12px;color:var(--muted);width:100%;">Nachricht bei Kleinanzeigen verschickt?</span><button onclick="aq2StatusSetzen('kleinanzeigen_geschrieben');akqToast('Status: Per Kleinanzeigen angeschrieben')">💬 Ja, angeschrieben</button><button class="secondary" onclick="aq2ErgebnisZeigen('')">Nein</button>`
      : `<span style="font-size:12px;color:var(--muted);width:100%;">Nachricht verschickt?</span><button onclick="aq2StatusSetzen('email_geschrieben');akqToast('Status: E-Mail geschrieben')">✉️ Ja</button><button class="secondary" onclick="aq2ErgebnisZeigen('')">Nein</button>`);
  }
}
function aq2Mehr(ev){
  ev.stopPropagation(); tbMenueZu();
  const o = findObjekt(AQ2.sel); if(!o) return;
  const m = document.createElement('div'); m.id = 'tbMenue'; m.className = 'tb-menue'; m.dataset.art = 'lead';
  const r = ev.currentTarget.getBoundingClientRect(); m.style.position = 'fixed'; m.style.top = (r.bottom+6)+'px'; m.style.right = (window.innerWidth-r.right)+'px';
  m.innerHTML = `<div class="mi" onclick="tbMenueZu();aq2TextKopieren('email')">✉️<div>E-Mail-Text kopieren</div></div>
    <div class="mi" onclick="tbMenueZu();aq2TextKopieren('kurz')">💬<div>Kurznachricht kopieren<small>für Kleinanzeigen & Portale</small></div></div>
    <div class="mi" onclick="tbMenueZu();aq2TextKopieren('nachfassen')">🔁<div>Nachfass-Text kopieren</div></div>
    <div class="mi" onclick="tbMenueZu();aqMarktanalyse(AQ2.sel)">📊<div>In der Marktanalyse prüfen</div></div>
    ${o.link?`<div class="mi" onclick="tbMenueZu();window.open(findObjekt(AQ2.sel).link,'_blank')">🔗<div>Anzeige öffnen</div></div>`:''}
    <div class="mi" onclick="tbMenueZu();oeffneObjektModal(AQ2.sel)">📝<div>Im Objekt-Formular öffnen</div></div>
    ${o.eigentuemerId?`<div class="mi" onclick="tbMenueZu();oeffneKontaktModal(findObjekt(AQ2.sel).eigentuemerId)">👤<div>Kontakt öffnen</div></div>`:''}
    ${aq2Fotos(o).length?`<div class="mi" onclick="tbMenueZu();aq2FotoWeg()">🗑️<div>Angezeigtes Foto entfernen</div></div>`:''}
    <div class="mi" onclick="tbMenueZu();aq2Loeschen()" style="color:#fca5a5;">⛔<div>Unbrauchbar – Lead löschen</div></div>`;
  document.body.appendChild(m);
}
function aq2FotoWeg(){
  const o = findObjekt(AQ2.sel); if(!o) return; const f = o.fotos||[];
  if(AQ2.fotoIdx < f.length) f.splice(AQ2.fotoIdx,1); else o.fotoUrl = '';
  AQ2.fotoIdx = 0; save(); aq2Liste();
}
function aq2Loeschen(){
  const id = AQ2.sel;
  bestaetigeUnten('Lead als unbrauchbar löschen?', ()=>{
    const o = findObjekt(id); const eig = o ? o.eigentuemerId : null;
    try{ akqVerworfenMerken(o); }catch(e){}
    try{ objektVerknuepfungenAufraeumen(id); }catch(e){}
    db.objekte = db.objekte.filter(x=>x.id!==id);
    try{ eigentuemerMitloeschenFallsVerwaist(eig); }catch(e){}
    AQ2.sel = null; save(); aq2Neu();
  });
}

// Fotos (verkleinert gespeichert, damit die Datendatei schlank bleibt)
function aq2Verkleinern(datei){
  return new Promise((ok, fehler)=>{
    const r = new FileReader();
    r.onload = ()=>{ const img = new Image(); img.onload = ()=>{ const max = 960, f = Math.min(1, max/Math.max(img.width, img.height)); const c = document.createElement('canvas'); c.width = Math.round(img.width*f); c.height = Math.round(img.height*f); c.getContext('2d').drawImage(img,0,0,c.width,c.height); ok(c.toDataURL('image/jpeg', .78)); }; img.onerror = fehler; img.src = r.result; };
    r.onerror = fehler; r.readAsDataURL(datei);
  });
}
async function aq2FotosLaden(files){
  const o = findObjekt(AQ2.sel); if(!o || !files || !files.length) return;
  o.fotos = o.fotos || []; let n = 0;
  for(const f of [...files].filter(f=>/^image\//.test(f.type)).slice(0, 8)){ try{ o.fotos.push(await aq2Verkleinern(f)); n++; }catch(e){} }
  o.fotos = o.fotos.slice(-8);
  if(n){ AQ2.fotoIdx = o.fotos.length-1; save(); aq2Liste(); akqToast(`📷 ${n} Foto${n===1?'':'s'} gespeichert`); }
}
async function aq2FotoAusAnzeige(){
  const o = findObjekt(AQ2.sel); if(!o || !o.link) return;
  akqToast('Lade Anzeige …');
  try{
    const r = await window.pc.seite(o.link);
    const t = (r && r.text) || '';
    const m = /<meta[^>]+property=["']og:image["'][^>]+content=["']([^"']+)["']/i.exec(t) || /<meta[^>]+content=["']([^"']+)["'][^>]+property=["']og:image["']/i.exec(t);
    if(m){ o.fotoUrl = m[1].replace(/&amp;/g,'&'); save(); aq2Liste(); akqToast('🖼️ Bild aus der Anzeige übernommen'); }
    else akqToast('Kein Bild in der Anzeige gefunden');
  }catch(e){ akqToast('Anzeige konnte nicht geladen werden'); }
}

// ── Karte (OpenStreetMap) ──
async function aq2Geo(o){
  const q = [o.adresse, o.ort].filter(Boolean).join(', ');
  if(!q) return null;
  if(o.geo && o.geo.q===q) return o.geo.lat ? o.geo : null;
  const r = await window.pc.abruf('https://nominatim.openstreetmap.org/search?format=json&limit=1&countrycodes=de&q='+encodeURIComponent(q));
  let j = []; try{ j = JSON.parse(r && r.text || '[]'); }catch(e){}
  o.geo = j[0] ? {lat:+j[0].lat, lon:+j[0].lon, q} : {q, fehler:true};
  return o.geo.lat ? o.geo : null;
}
function aq2Karte(liste){
  const info = document.getElementById('aqKarteInfo');
  if(typeof L==='undefined'){ document.getElementById('aqKarte').innerHTML = '<div class="aq-leer" style="height:100%;border:none;"><b>Karte nicht verfügbar</b>Die Kartenbibliothek fehlt.</div>'; return; }
  if(AQ2.map){ try{ AQ2.map.remove(); }catch(e){} AQ2.map = null; }
  const map = L.map('aqKarte', {zoomControl:true, attributionControl:true}).setView([52.52, 13.40], 9);
  L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {maxZoom:19, attribution:'© OpenStreetMap-Mitwirkende'}).addTo(map);
  AQ2.map = map;
  const gruppe = L.featureGroup().addTo(map);
  const setzen = o => { if(!o.geo || !o.geo.lat) return; const c = AQ_ST_FARBE[o.status] || '#2ee6a6';
    L.circleMarker([o.geo.lat, o.geo.lon], {radius: o.id===AQ2.sel ? 11 : 8, color: o.id===AQ2.sel ? '#fff' : c, weight: 2, fillColor: c, fillOpacity: .9})
      .bindTooltip(`${akqEsc(aqTitel(o))}${o.kaufpreis?' · '+aqEur(o.kaufpreis):''}`).on('click', ()=>aq2Waehlen(o.id)).addTo(gruppe); };
  liste.forEach(setzen);
  if(gruppe.getLayers().length) map.fitBounds(gruppe.getBounds().pad(.25), {maxZoom:13});
  const fehlen = liste.filter(o=>!(o.geo && o.geo.q===[o.adresse, o.ort].filter(Boolean).join(', ')) && (o.adresse||o.ort));
  if(info) info.textContent = `${gruppe.getLayers().length} von ${liste.length} Leads auf der Karte` + (fehlen.length ? ` · ${fehlen.length} werden gesucht …` : '');
  if(!fehlen.length || AQ2.geoLaeuft || !(window.pc && window.pc.abruf)) return;
  AQ2.geoLaeuft = true;
  (async ()=>{
    for(const o of fehlen.slice(0,40)){
      if(AQ2.ansicht!=='karte' || aktuelleAnsicht!=='akquise') break;
      try{ await aq2Geo(o); }catch(e){}
      if(AQ2.map===map) setzen(o);
      await new Promise(r=>setTimeout(r, 1100));
    }
    AQ2.geoLaeuft = false; save();
    if(AQ2.map===map && gruppe.getLayers().length) map.fitBounds(gruppe.getBounds().pad(.25), {maxZoom:13});
    if(info) info.textContent = `${gruppe.getLayers().length} von ${liste.length} Leads auf der Karte (Ort nicht gefunden: ${liste.filter(o=>o.geo&&o.geo.fehler).length})`;
  })();
}

// ── Suchen lassen / Einfügen / Neuer Lead (Fenster) ──
function aq2Modal(html, breit){ const m = document.getElementById('modalInner'); m.innerHTML = html; m.style.width = breit ? '760px' : ''; document.getElementById('modalBg').classList.add('show'); }
function aq2Suchen(){
  const e = akqDb().einst;
  aq2Modal(`<h3 style="display:flex;align-items:center;gap:8px;">🔎 Suchen lassen</h3>
    <div style="color:var(--muted);font-size:12px;margin-bottom:6px;">Prompt kopieren → in Claude oder ChatGPT einfügen (Websuche an; bei „Zeitung“ die Seiten anhängen) → Antwort kopieren → hier mit Strg+V einfügen.</div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:2px 12px;">
      <div style="grid-column:1/-1;"><label>Gebiet</label><input value="${akqEsc(e.gebiet)}" onchange="akqEinstSetzen('gebiet',this.value)"></div>
      <div style="grid-column:1/-1;"><label>Objektarten</label><input value="${akqEsc(e.arten)}" onchange="akqEinstSetzen('arten',this.value)"></div>
      <div><label>Anzahl (online)</label><input value="${akqEsc(e.anzahl)}" onchange="akqEinstSetzen('anzahl',this.value)"></div>
      <div><label>Zeitraum (Tage)</label><input value="${akqEsc(e.tage)}" onchange="akqEinstSetzen('tage',this.value)"></div>
      <div style="grid-column:1/-1;margin-top:8px;"><label style="display:flex;align-items:center;gap:6px;text-transform:none;font-size:12.5px;color:var(--text);"><input type="checkbox" style="width:auto;" ${e.nurPrivat?'checked':''} onchange="akqEinstSetzen('nurPrivat',this.checked)"> nur private Anbieter</label></div>
    </div>
    <div id="akqKarten" style="margin-top:8px;"></div>
    <div class="zl-tipp">📄 <b>Zeitung als PDF oder Foto?</b> Geht auch ohne KI: <a href="#" onclick="schliesseModal();zlDialog();return false;">direkt im Cockpit einlesen</a> – Angebote werden Leads, Kaufgesuche werden Suchkunden.</div>
    <div class="modal-actions"><div style="display:flex;gap:6px;"><button class="secondary" onclick="window.open('https://claude.ai/new','_blank')">Claude ↗</button><button class="secondary" onclick="window.open('https://chatgpt.com/','_blank')">ChatGPT ↗</button><button class="secondary" onclick="schliesseModal();wechsleAnsicht('jv-suchen')">🔎 KI-Suche</button></div>
      <div class="right"><button class="secondary" onclick="schliesseModal()">Schließen</button><button onclick="schliesseModal();aq2Einfuegen()">Ergebnis einfügen →</button></div></div>`, true);
  renderAkquiseKarten();
}
function aq2Einfuegen(){
  aq2Modal(`<h3>📥 Ergebnis einfügen</h3>
    <div style="color:var(--muted);font-size:12px;margin-bottom:8px;">Antwort der KI einfügen (Strg+V) – wird sofort übernommen. Erkannt werden dein Zeitungsformat, Listen mit „Objekt: / Lage: / Preis: …“, Tabellen und JARVIS-IMPORT-Blöcke.</div>
    <textarea id="akqText" style="min-height:260px;font-family:Consolas,monospace;font-size:11.5px;" placeholder="1.&#10;Name: Nicht angegeben&#10;Objekt: Voll erschlossenes Baugrundstück&#10;Lage: Ludwigsfelde&#10;Preis: 300.000 €&#10;…" onpaste="setTimeout(()=>akqEinfuegen(true),60)"></textarea>
    <div id="akqErgebnis" style="margin-top:8px;"></div>
    <div class="modal-actions"><div>${window.pc&&window.pc.zwischenablage?'<button class="secondary" onclick="akqAusZwischenablage()">📋 Aus Zwischenablage</button>':''}</div>
      <div class="right"><button class="secondary" onclick="schliesseModal()">Abbrechen</button><button onclick="akqEinfuegen()">✅ Einfügen</button></div></div>`, true);
  setTimeout(()=>{ const t = document.getElementById('akqText'); if(t) t.focus(); }, 50);
}
function akqEinfuegen(vonPaste){
  const ta = document.getElementById('akqText'); if(!ta) return;
  const t = ta.value; if(!t.trim() || (vonPaste && t.trim().length<25)) return;
  aq2ImportUndZeigen(t, ()=>{ const e = document.getElementById('akqErgebnis'); if(e) e.innerHTML = akqErgebnisHtml(); });
}
function aq2ImportUndZeigen(text, beiFehler){
  const r = akqImportText(text);
  if(!r) return;
  if(r.fehler){ if(beiFehler) beiFehler(); else akqToast('⚠️ '+r.fehler, 5000); return; }
  try{ schliesseModal(); }catch(e){}
  if(r.jarvis) return;
  if(r.hv){ wechsleAnsicht('hausverwaltungen'); return; }
  AQ2.ergebnis = r;
  const erste = (r.liste||[]).find(x=>x.neu) || (r.liste||[])[0];
  if(erste){ AQ2.sel = erste.id; if(!AQ_OFFEN.includes((findObjekt(erste.id)||{}).status)) AQ2.status = 'alle'; else if(AQ2.status!=='alle') AQ2.status = 'offen'; AQ2.ort = ''; AQ2.art = ''; AQ2.q = ''; }
  if(aktuelleAnsicht==='akquise') renderAkquise(document.getElementById('main')); else wechsleAnsicht('akquise');
  renderNav();
}
function jvClipEinlesen(){
  const el = document.getElementById('jvClipBanner'); if(!el) return;
  const t = el._text; el.remove(); aq2ImportUndZeigen(t);
}
function aq2ErgebnisHtml(){
  const r = AQ2.ergebnis; if(!r || !r.liste) return '';
  const imp = akqDb().importe.find(i=>i.id===r.id); if(imp && imp.rueckgaengig) return '';
  return `<div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;background:rgba(255,138,61,.08);border:1px solid rgba(255,138,61,.35);border-radius:12px;padding:10px 14px;margin-bottom:14px;font-size:13px;">
    <span>✅ <b>${r.neuObjekte} neue Lead${r.neuObjekte===1?'':'s'}</b> · ${r.neuKontakte} neue Kontakte${r.doppelt?` · ${r.doppelt} schon bekannt (ergänzt)`:''}</span><span style="flex:1;"></span>
    ${r.neuObjekte||r.neuKontakte?`<button class="secondary tiny" onclick="akqRueckgaengig('${r.id}');AQ2.ergebnis=null;">↩️ Rückgängig</button>`:''}<button class="secondary tiny" onclick="AQ2.ergebnis=null;document.getElementById('aqErgebnis').innerHTML='';">✕</button></div>`;
}
function aq2NeuerLead(){
  const f = (id, l, ph, typ) => `<div><label>${l}</label><input id="nl_${id}" ${typ?'type="'+typ+'"':''} placeholder="${ph||''}"></div>`;
  aq2Modal(`<h3>＋ Neuer Lead</h3>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:2px 12px;">
      <div style="grid-column:1/-1;"><label>Objekt</label><input id="nl_objekt" placeholder="z. B. Einfamilienhaus mit Garten"></div>
      ${f('lage','Lage / Adresse','Ort, Straße Nr.')}${f('preis','Preis','z. B. 349.000 €')}
      ${f('name','Name','Verkäufer')}${f('telefon','Telefon','')}
      ${f('email','E-Mail','')}${f('quelle','Quelle','Zeitung, Kleinanzeigen, Tipp …')}
      ${f('datum','Eingestellt am','','date')}
      <div><label>Privat?</label><select id="nl_privat"><option value="🟢 Ja">🟢 Ja</option><option value="🟡 Unklar" selected>🟡 Unklar</option><option value="🔴 Nein">🔴 Nein (Makler)</option></select></div>
      <div style="grid-column:1/-1;"><label>Details</label><textarea id="nl_details" placeholder="Fläche, Zimmer, Grundstück, Baujahr, Besonderheiten"></textarea></div>
      <div style="grid-column:1/-1;"><label>Link zur Anzeige</label><input id="nl_link" placeholder="https://…"></div>
    </div>
    <div class="modal-actions"><div></div><div class="right"><button class="secondary" onclick="schliesseModal()">Abbrechen</button><button onclick="aq2NeuerLeadSpeichern()">Anlegen</button></div></div>`, true);
  setTimeout(()=>document.getElementById('nl_objekt').focus(), 50);
}
function aq2NeuerLeadSpeichern(){
  const v = id => (document.getElementById('nl_'+id).value||'').trim();
  if(!v('objekt') && !v('lage')){ akqToast('Bitte mindestens Objekt oder Lage eintragen'); return; }
  const d = v('datum') ? v('datum').split('-').reverse().join('.') : '';
  const text = `1.\nName: ${v('name')||'Nicht angegeben'}\nObjekt: ${v('objekt')||'Objekt'}\nLage: ${v('lage')||'Nicht angegeben'}\nPreis: ${v('preis')||'Nicht angegeben'}\nTelefon: ${v('telefon')||'Nicht angegeben'}\nE-Mail: ${v('email')||'Nicht angegeben'}\nEingestellt am: ${d||'Nicht angegeben'}\nPrivat eindeutig: ${v('privat')}\nDetails: ${(v('details')||'Nicht angegeben').replace(/\n+/g,' ')}\nQuelle: ${v('quelle')||'Direktakquise'}\nLink: ${v('link')||'Nicht angegeben'}`;
  aq2ImportUndZeigen(text);
}

// ── Tastatur & Einfügen auf der Akquise-Seite ──
document.addEventListener('keydown', e=>{
  if(aktuelleAnsicht!=='akquise' || AQ2.ansicht!=='liste') return;
  if(['INPUT','TEXTAREA','SELECT'].includes((e.target.tagName||'')) || document.getElementById('modalBg').classList.contains('show')) return;
  if(e.key!=='ArrowDown' && e.key!=='ArrowUp') return;
  const l = aqGefiltert(); if(!l.length) return;
  e.preventDefault();
  let i = l.findIndex(o=>o.id===AQ2.sel); i = e.key==='ArrowDown' ? Math.min(i+1, l.length-1) : Math.max(i-1, 0);
  aq2Waehlen(l[i].id); const el = document.getElementById('lc-'+l[i].id); if(el) el.scrollIntoView({block:'nearest'});
});
document.addEventListener('paste', e=>{
  if(aktuelleAnsicht!=='akquise') return;
  if(['INPUT','TEXTAREA','SELECT'].includes((e.target.tagName||'')) || document.getElementById('modalBg').classList.contains('show')) return;
  const items = [...(e.clipboardData && e.clipboardData.items || [])];
  const bilder = items.filter(i=>i.kind==='file' && /^image\//.test(i.type)).map(i=>i.getAsFile()).filter(Boolean);
  if(bilder.length && AQ2.sel){ e.preventDefault(); aq2FotosLaden(bilder); return; }
  const t = e.clipboardData && e.clipboardData.getData('text');
  if(t && /^https?:\/\/\S+$/.test(t.trim()) && AQ2.sel){ const o = findObjekt(AQ2.sel); if(o && !o.link){ e.preventDefault(); aq2LinkSetzen(t.trim()); return; } }
  if(t && t.trim().length>20){ e.preventDefault(); aq2ImportUndZeigen(t); }
});
