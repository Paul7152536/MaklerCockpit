// ═══ MaklerCockpit v25 – Name, Telefon und E-Mail überall verbunden ═══
// Eine Quelle: der Kontakt. Objekt (Lead), Suchkunde und Hausverwaltung führen eine Kopie, die bei jedem Speichern abgeglichen wird.
// Wer zuletzt geändert hat, gewinnt; ändern beide Seiten dasselbe Feld unterschiedlich, entsteht ein Klärungspunkt (nichts wird still überschrieben).
const VB25_PLATZHALTER = /^(privat( –|verk[äa]ufer|person)|eigent[üu]mer\/in \(|suchkunde( \(|$)|kontakt \(|chiffre |verk[äa]ufer$|eigent[üu]mer$|hausverwaltung$|expose \d)/i;
const VB25_FELDER = [['n', 'Name'], ['t', 'Telefon'], ['m', 'E-Mail']];
function vb25Platzhalter(n){ n = String(n || '').trim(); return !n || VB25_PLATZHALTER.test(n); }
function vb25Tel(t){ let d = String(t || '').replace(/[^\d+]/g, ''); if(d.startsWith('+49')) d = '0' + d.slice(3); else if(d.startsWith('0049')) d = '0' + d.slice(4); return d.replace(/\D/g, ''); }
function vb25S(x){ return String(x == null ? '' : x).trim(); }
function vb25Gleich(f, a, b){ a = vb25S(a); b = vb25S(b); if(f === 't') return vb25Tel(a) === vb25Tel(b) && (!!a === !!b); if(f === 'm') return a.toLowerCase() === b.toLowerCase(); return a === b; }
function vb25Db(){ if(!db.vb25 || typeof db.vb25 !== 'object') db.vb25 = {}; if(!Array.isArray(db.vb25.konflikte)) db.vb25.konflikte = []; return db.vb25; }
function vb25Werte(k){ return { n: vb25S(k.name), t: vb25S(k.telefon), m: vb25S(k.email) }; }
// Kopie-Seiten: Objekt (Lead), Suchkunde, Hausverwaltung (Recherche-Liste)
const VB25_SEITEN = {
  objekt: { liste: () => db.objekte || [], kid: x => x.eigentuemerId, n: 'verkaeuferName', t: 'verkaeuferTelefon', m: 'verkaeuferEmail', titel: x => (typeof mc24Titel === 'function' ? mc24Titel(x) : (x.akqTitel || x.adresse || 'Objekt')) },
  suchkunde: { liste: () => db.gesuche || [], kid: x => x.kontaktId, n: 'name', t: 'telefon', m: 'email', felder: ['t', 'm'], titel: x => 'Suchkunde ' + (x.name || '') },   // Name des Suchkunden ist oft eine Beschreibung („Rentnerpaar“) – nur Nummer/E-Mail angleichen
  hv: { liste: () => ((db.hv || {}).verwaltungen) || [], kid: x => { const k = (db.kontakte || []).find(y => y.koop && y.koop.hvId === x.id); return k ? k.id : null; }, n: 'name', t: 'telefon', m: 'email', titel: x => 'Hausverwaltung ' + (x.name || '') }
};
function vb25Kopie(art, x){ const s = VB25_SEITEN[art]; return { n: vb25S(x[s.n]), t: vb25S(x[s.t]), m: vb25S(x[s.m]) }; }
function vb25KopieSetzen(art, x, f, v){ const s = VB25_SEITEN[art]; x[s[f]] = v; }
function vb25KontaktSetzen(k, f, v, quelle){
  if(f === 'n'){ if(!vb25S(v)) return false; k.name = vb25S(v); }
  else if(f === 't'){ k.telefon = vb25S(v); if(quelle){ k.quellen = k.quellen || {}; k.quellen.telefon = quelle; } }
  else { k.email = vb25S(v); if(quelle){ k.quellen = k.quellen || {}; k.quellen.email = quelle; } }
  return true;
}
function vb25Konflikt(art, x, k, f, kopieWert, kontaktWert){
  const kl = vb25Db().konflikte;
  const vorh = kl.find(c => !c.erledigt && c.art === art && c.xId === x.id && c.kontaktId === k.id && c.feld === f);
  if(vorh){ vorh.kopie = kopieWert; vorh.kontakt = kontaktWert; return; }
  kl.push({ id: uid(), art, xId: x.id, kontaktId: k.id, feld: f, kopie: kopieWert, kontakt: kontaktWert, am: Date.now(), erledigt: false });
}
function vb25OffenerKonflikt(art, x, k, f){ return (vb25Db().konflikte || []).some(c => !c.erledigt && c.art === art && c.xId === x.id && c.kontaktId === k.id && c.feld === f); }

// ── Abgleich (läuft vor jedem Speichern) ──
let VB25_LAEUFT = false;
function vb25Abgleichen(){
  if(VB25_LAEUFT || !db || !Array.isArray(db.kontakte)) return 0;
  VB25_LAEUFT = true;
  let n = 0;
  try{
    const kmap = new Map(db.kontakte.map(k => [k.id, k]));
    // 1) Kopien → Kontakt (Änderungen an Objekt/Suchkunde/HV in den Kontakt übernehmen)
    for(const art of Object.keys(VB25_SEITEN)){
      for(const x of VB25_SEITEN[art].liste()){
        const kid = VB25_SEITEN[art].kid(x); const k = kid ? kmap.get(kid) : null;
        if(!k){ if(x.vb25) delete x.vb25; continue; }
        const kopie = vb25Kopie(art, x), kw = vb25Werte(k);
        const snap = x.vb25 && x.vb25.k === k.id ? x.vb25 : null;
        for(const [f] of VB25_FELDER){
          if(VB25_SEITEN[art].felder && !VB25_SEITEN[art].felder.includes(f)) continue;
          if(vb25OffenerKonflikt(art, x, k, f)) continue;
          const a = kopie[f], b = kw[f];
          if(vb25Gleich(f, a, b)) continue;
          if(f === 'n' && vb25Platzhalter(a)) continue;                 // „Privatverkäufer“ o. Ä. überschreibt keinen echten Namen
          if(!snap){
            // neue Verknüpfung oder Altbestand: leere Felder ergänzen, echte Abweichung klären lassen
            if(!b){ vb25KontaktSetzen(k, f, a, VB25_SEITEN[art].titel(x)); n++; }
            else if(f === 'n'){ if(vb25Platzhalter(b)){ vb25KontaktSetzen(k, f, a); n++; } }
            else if(a){ vb25Konflikt(art, x, k, f, a, b); n++; }
            continue;
          }
          const kopieNeu = !vb25Gleich(f, a, snap[f]), kontaktNeu = !vb25Gleich(f, b, snap[f]);
          if(kopieNeu && !kontaktNeu){ if(f === 'n' && !a) continue; vb25KontaktSetzen(k, f, a, VB25_SEITEN[art].titel(x)); n++; }
          else if(kopieNeu && kontaktNeu){ vb25Konflikt(art, x, k, f, a, b); n++; }
        }
      }
    }
    // 2) Kontakt → überall (Termine, Aufgaben, Google, Kopien)
    for(const k of db.kontakte){
      const jetzt = vb25Werte(k), alt = k.vb25;
      if(alt && VB25_FELDER.some(([f]) => !vb25Gleich(f, alt[f], jetzt[f]))){ n += vb25Verteilen(k, alt, jetzt); }
      if(!alt || VB25_FELDER.some(([f]) => vb25S(alt[f]) !== jetzt[f])) k.vb25 = jetzt;
    }
    // 3) Kopien angleichen und Stand merken
    for(const art of Object.keys(VB25_SEITEN)){
      for(const x of VB25_SEITEN[art].liste()){
        const kid = VB25_SEITEN[art].kid(x); const k = kid ? kmap.get(kid) : null; if(!k) continue;
        const kw = vb25Werte(k), kopie = vb25Kopie(art, x);
        for(const [f] of VB25_FELDER){
          if(VB25_SEITEN[art].felder && !VB25_SEITEN[art].felder.includes(f)) continue;
          if(vb25OffenerKonflikt(art, x, k, f)) continue;
          if(f === 'n' && vb25Platzhalter(kw.n)) continue;              // Platzhalter-Name nicht in die Kopie schreiben
          if(!vb25Gleich(f, kopie[f], kw[f]) || (f !== 't' && kopie[f] !== kw[f])){ if(!vb25Gleich(f, kopie[f], kw[f])) n++; vb25KopieSetzen(art, x, f, kw[f]); }
        }
        const neu = vb25Kopie(art, x);
        if(!x.vb25 && (kopie.n !== neu.n || kopie.t !== neu.t || kopie.m !== neu.m)) x.vb25alt = { n: kopie.n, t: kopie.t, m: kopie.m, am: Date.now() };   // ursprüngliche Angaben sicherheitshalber merken
        const s = { k: k.id, n: neu.n, t: neu.t, m: neu.m };
        if(!x.vb25 || x.vb25.k !== s.k || x.vb25.n !== s.n || x.vb25.t !== s.t || x.vb25.m !== s.m) x.vb25 = s;
      }
    }
    // erledigte Klärungen nach 30 Tagen aufräumen
    const kl = vb25Db().konflikte; const grenze = Date.now() - 30 * 864e5;
    const rest = kl.filter(c => !c.erledigt || (c.erledigtAm || 0) > grenze); if(rest.length !== kl.length) db.vb25.konflikte = rest;
  }catch(e){ console.error('vb25', e); }
  finally{ VB25_LAEUFT = false; }
  return n;
}

// Telefonnummer/Name in Texten (Termin-Ort, Titel, Notiz, Aufgaben) ersetzen – nur bei verknüpften Einträgen
function vb25TelErsetzen(text, alt, neu){
  const a = vb25Tel(alt); if(a.length < 6) return text;
  return String(text).replace(/\+?\d[\d \/()\-]{4,}\d/g, m => vb25Tel(m) === a ? (neu || '') : m).replace(/(telefon|tel\.?)\s*:?\s*$/i, '$1').replace(/\s{2,}/g, ' ').trim();
}
function vb25NameErsetzen(text, alt, neu){
  if(vb25Platzhalter(alt) || vb25Platzhalter(neu) || alt.length < 4) return text;
  const re = new RegExp('(^|[^A-Za-zÄÖÜäöüß])' + alt.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '(?![A-Za-zÄÖÜäöüß])', 'g');
  return String(text).replace(re, (m, vor) => vor + neu);
}
function vb25Verteilen(k, alt, neu){
  let n = 0;
  const objIds = new Set((db.objekte || []).filter(o => o.eigentuemerId === k.id).map(o => o.id));
  const heute = new Date().toISOString().slice(0, 10);
  const textNeu = (s) => {
    let t = String(s || ''); const vorher = t;
    if(alt.t && !vb25Gleich('t', alt.t, neu.t)) t = vb25TelErsetzen(t, alt.t, neu.t);
    if(alt.n && alt.n !== neu.n) t = vb25NameErsetzen(t, alt.n, neu.n);
    if(alt.m && neu.m && alt.m.toLowerCase() !== neu.m.toLowerCase()) t = t.split(alt.m).join(neu.m);
    return t === vorher ? null : t;
  };
  let google = 0;
  for(const t of db.termine || []){
    if(!(t.kontaktId === k.id || (objIds.has(t.objektId) && (!t.kontaktId || t.kontaktId === k.id)))) continue;
    let g = false;
    for(const feld of ['titel', 'ort', 'notiz']){ const r = textNeu(t[feld]); if(r !== null){ t[feld] = r; g = true; } }
    if(g){ t.geaendertAm = Date.now(); n++; }
    // Google-Termin: Kontaktzeilen in der Beschreibung neu übertragen (nur heute/künftig)
    if(t.googleEventId && t.datum && t.datum >= heute){ t.gHash = ''; google++; }
  }
  for(const a of db.aufgaben || []){
    if(!(a.kontaktId === k.id || (objIds.has(a.objektId) && (!a.kontaktId || a.kontaktId === k.id)))) continue;
    let g = false;
    for(const feld of ['titel', 'notiz']){ const r = textNeu(a[feld]); if(r !== null){ a[feld] = r; g = true; } }
    if(g) n++;
  }
  // Verlauf an den Objekten
  const teile = [];
  if(!vb25Gleich('n', alt.n, neu.n) && !vb25Platzhalter(neu.n)) teile.push('Name: ' + (alt.n || '–') + ' → ' + neu.n);
  if(!vb25Gleich('t', alt.t, neu.t)) teile.push('Telefon: ' + (alt.t || '–') + ' → ' + (neu.t || '–'));
  if(!vb25Gleich('m', alt.m, neu.m)) teile.push('E-Mail: ' + (alt.m || '–') + ' → ' + (neu.m || '–'));
  if(teile.length) for(const o of db.objekte || []) if(objIds.has(o.id)){ try{ if(typeof aqLog === 'function') aqLog(o, 'kontakt', 'Kontaktdaten aktualisiert – ' + teile.join(', ')); }catch(e){} }
  if(google){ try{ if(typeof gsAktiv === 'function' && gsAktiv() && typeof gsPlanen === 'function') gsPlanen(2500); }catch(e){} }
  return n + (teile.length ? 1 : 0);
}

// ── Klärungen: abweichende Angaben auswählen ──
function vb25Offen(){ return (vb25Db().konflikte || []).filter(c => !c.erledigt && (db.kontakte || []).some(k => k.id === c.kontaktId)); }
function vb25KlaerenDialog(){
  const l = vb25Offen();
  if(!l.length){ schliesseModal(); akqToast('Keine abweichenden Kontaktdaten mehr'); return; }
  const zeile = c => {
    const k = findKontakt(c.kontaktId); const s = VB25_SEITEN[c.art]; const x = s.liste().find(y => y.id === c.xId);
    const fl = (VB25_FELDER.find(f => f[0] === c.feld) || [])[1];
    const wo = x ? s.titel(x) : 'gelöschter Eintrag';
    return `<div class="vb25-k"><div class="vb25-kt"><b>${mc24E(fl)}</b> · Kontakt „${mc24E(k.name)}“ ↔ ${mc24E(wo)}</div>
      <div class="vb25-wahl">
        <button class="secondary" onclick="vb25Entscheiden('${c.id}','kontakt')">Kontakt: <b>${mc24E(c.kontakt || '–')}</b></button>
        <button class="secondary" onclick="vb25Entscheiden('${c.id}','kopie')">${c.art === 'objekt' ? 'Objekt/Lead' : c.art === 'suchkunde' ? 'Suchkunde' : 'Hausverwaltung'}: <b>${mc24E(c.kopie || '–')}</b></button>
        ${c.feld !== 'n' ? `<button class="secondary" onclick="vb25Entscheiden('${c.id}','beide')" title="Die andere Nummer/Adresse wird in den Notizen des Kontakts gemerkt">Kontakt behalten, andere notieren</button>` : ''}
      </div></div>`;
  };
  mc24Modal(`<h3>Abweichende Kontaktdaten klären (${l.length})</h3>
    <div class="sub" style="margin-bottom:10px;">An zwei Stellen stehen unterschiedliche Angaben. Wähle, was stimmt – danach gilt es überall (Kontakte, Akquise, Objekte, Termine, Google Kalender).</div>
    ${l.map(zeile).join('')}
    <div class="modal-actions"><span></span><div class="right"><button class="secondary" onclick="schliesseModal()">Später</button></div></div>`, 720);
}
function vb25Entscheiden(id, wahl){
  const c = vb25Db().konflikte.find(x => x.id === id); if(!c) return;
  const k = findKontakt(c.kontaktId); const s = VB25_SEITEN[c.art]; const x = s.liste().find(y => y.id === c.xId);
  if(k){
    const alt = vb25Werte(k);
    if(wahl === 'kopie'){ vb25KontaktSetzen(k, c.feld, c.kopie, x ? s.titel(x) : ''); }
    if(wahl === 'beide' && c.kopie){ k.notizen = (k.notizen ? k.notizen + '\n' : '') + (c.feld === 't' ? 'Weitere Nummer: ' : 'Weitere E-Mail: ') + c.kopie + ' (aus ' + (x ? s.titel(x) : 'Lead') + ', ' + new Date().toLocaleDateString('de-DE') + ')'; }
    if(x) vb25KopieSetzen(c.art, x, c.feld, vb25Werte(k)[c.feld]);
    if(x){ const kp = vb25Kopie(c.art, x); x.vb25 = { k: k.id, n: kp.n, t: kp.t, m: kp.m }; }
    if(wahl === 'kopie') vb25Verteilen(k, alt, vb25Werte(k));
  }
  c.erledigt = true; c.erledigtAm = Date.now(); c.wahl = wahl;
  vb25Abgleichen(); save(); renderMain();
  vb25KlaerenDialog();
}

// ── Objekt-Dialog: Felder zeigen die Kontaktdaten, Änderungen gelten überall ──
function vb25Prefill(){
  const sel = document.getElementById('m_eigentuemer'); if(!sel) return;
  const f = { n: document.getElementById('m_verkaeufer_name'), t: document.getElementById('m_verkaeufer_telefon'), m: document.getElementById('m_verkaeufer_email') };
  if(!f.n || !f.t || !f.m) return;
  let k = sel.value ? findKontakt(sel.value) : null;
  const ctx = (typeof callDanielModalKontext !== 'undefined' && callDanielModalKontext);
  if(k && !ctx){
    const w = vb25Werte(k);
    for(const key of ['n', 't', 'm']){
      const el = f[key]; const auto = el.dataset.vbAuto === '1' || !el.value.trim() || el.dataset.vbStart === undefined || el.value === el.dataset.vbStart;
      if(auto && w[key] && !(key === 'n' && vb25Platzhalter(w[key]))){ el.value = w[key]; }
    }
  }
  for(const key of ['n', 't', 'm']){ f[key].dataset.vbStart = f[key].value; f[key].dataset.vbAuto = '1'; f[key].dataset.vbK = k ? k.id : ''; }
}
function vb25ModalBeschriften(){
  const inner = document.getElementById('modalInner'); if(!inner) return;
  const div = Array.from(inner.querySelectorAll('div')).find(d => /Verkäufer-Kontaktdaten \(direkt eintragbar/.test(d.textContent || '') && d.children.length === 0);
  if(div) div.innerHTML = '📇 Eigentümer-Kontaktdaten – <b>Änderungen gelten überall</b> (Kontakt, Akquise, Termine, Google Kalender). Mit Telefon oder E-Mail wird automatisch ein Kontakt angelegt bzw. ein vorhandener mit gleicher Nummer verknüpft.';
  ['m_verkaeufer_name', 'm_verkaeufer_telefon', 'm_verkaeufer_email'].forEach(id => { const el = document.getElementById(id); if(el) el.addEventListener('input', () => { el.dataset.vbAuto = '0'; }); });
}
const _vb25ObjModal = oeffneObjektModal;
oeffneObjektModal = function(){
  const r = _vb25ObjModal.apply(this, arguments);
  try{ vb25Prefill(); vb25ModalBeschriften(); }catch(e){ console.error('vb25 modal', e); }
  return r;
};
const _vb25ZeigeEig = zeigeEigentuemerKontakt;
zeigeEigentuemerKontakt = function(){
  const r = _vb25ZeigeEig.apply(this, arguments);
  try{
    const sel = document.getElementById('m_eigentuemer'); const n = document.getElementById('m_verkaeufer_name');
    if(sel && n && n.dataset.vbK !== undefined && n.dataset.vbK !== (sel.value || '')){
      // anderer Kontakt gewählt: Felder, die nicht von Hand geändert wurden, mit dessen Daten füllen
      const k = sel.value ? findKontakt(sel.value) : null;
      ['m_verkaeufer_name', 'm_verkaeufer_telefon', 'm_verkaeufer_email'].forEach((id, i) => {
        const el = document.getElementById(id); if(!el) return;
        const w = k ? vb25Werte(k)[['n', 't', 'm'][i]] : '';
        if(k && el.dataset.vbAuto !== '0' && w && !(i === 0 && vb25Platzhalter(w))) el.value = w;
        el.dataset.vbStart = el.value; el.dataset.vbK = k ? k.id : '';
      });
    }
  }catch(e){}
  return r;
};
function vb25KontaktFinden(t, m){
  const tn = vb25Tel(t), mn = vb25S(m).toLowerCase();
  return (db.kontakte || []).find(k => !k.organisation && ((tn.length >= 6 && vb25Tel(k.telefon) === tn) || (mn && vb25S(k.email).toLowerCase() === mn))) || null;
}
const _vb25SpeichereObjekt = speichereObjekt;
speichereObjekt = function(id){
  const g = i => document.getElementById(i);
  const eing = g('m_verkaeufer_name') ? { n: g('m_verkaeufer_name').value.trim(), t: g('m_verkaeufer_telefon').value.trim(), m: g('m_verkaeufer_email').value.trim() } : null;
  const start = eing ? { n: g('m_verkaeufer_name').dataset.vbStart || '', t: g('m_verkaeufer_telefon').dataset.vbStart || '', m: g('m_verkaeufer_email').dataset.vbStart || '' } : null;
  const kid = g('m_eigentuemer') ? (g('m_eigentuemer').value || null) : null;
  const vorher = new Set((db.objekte || []).map(o => o.id));
  const r = _vb25SpeichereObjekt.apply(this, arguments);
  try{
    if(!eing) return r;
    const o = id ? findObjekt(id) : (db.objekte || []).find(x => !vorher.has(x.id));
    if(!o) return r;
    const geaendert = ['n', 't', 'm'].filter(f => eing[f] !== start[f]);
    let meldung = '';
    if(o.eigentuemerId){
      const k = findKontakt(o.eigentuemerId);
      if(k && geaendert.length){
        // Von Hand geändert: das gilt – direkt in den Kontakt, damit beim Abgleich kein Klärungspunkt entsteht
        geaendert.forEach(f => { if(!(f === 'n' && vb25Platzhalter(eing.n))) vb25KontaktSetzen(k, f, eing[f], 'Objekt „' + (typeof mc24Titel === 'function' ? mc24Titel(o) : (o.adresse || '')) + '“ (von Hand)'); });
        o.vb25 = { k: k.id, n: vb25S(o.verkaeuferName), t: vb25S(o.verkaeuferTelefon), m: vb25S(o.verkaeuferEmail) };
        vb25Db().konflikte.filter(c => !c.erledigt && c.art === 'objekt' && c.xId === o.id && geaendert.includes(c.feld)).forEach(c => { c.erledigt = true; c.erledigtAm = Date.now(); c.wahl = 'hand'; });
        meldung = 'Kontaktdaten überall aktualisiert';
      }
    } else if((eing.t || eing.m) && (geaendert.length || !id)){
      // Noch kein Kontakt: vorhandenen mit gleicher Nummer/E-Mail verknüpfen oder neu anlegen
      let k = vb25KontaktFinden(eing.t, eing.m);
      if(k){
        if(eing.n && !vb25Platzhalter(eing.n) && eing.n !== k.name){
          if(vb25Platzhalter(k.name) || k.name.toLowerCase().includes(eing.n.toLowerCase()) === false && eing.n.toLowerCase().includes(k.name.toLowerCase())) k.name = eing.n;
          else if(!k.name.toLowerCase().includes(eing.n.toLowerCase())){ k.notizen = (k.notizen ? k.notizen + '\n' : '') + 'Auch eingetragen als: ' + eing.n + ' (' + new Date().toLocaleDateString('de-DE') + ')'; }
        }
        if(!k.telefon && eing.t) k.telefon = eing.t;
        if(!k.email && eing.m) k.email = eing.m;
        meldung = 'Mit vorhandenem Kontakt „' + k.name + '“ verknüpft (gleiche ' + (vb25Tel(k.telefon) === vb25Tel(eing.t) && eing.t ? 'Nummer' : 'E-Mail') + ')';
      } else {
        k = { id: uid(), createdAt: Date.now(), name: eing.n && !vb25Platzhalter(eing.n) ? eing.n : 'Eigentümer/in (' + String(o.adresse || o.akqTitel || 'Objekt').slice(0, 30) + ')', telefon: eing.t, email: eing.m, adresse: '', kontaktart: 'eigentuemer', quelle: QUELLEN.includes(o.quelle) ? o.quelle : 'Sonstiges', status: 'lead', prioritaet: 'mittel', notizen: '', quellen: { telefon: eing.t ? 'Objekt (von Hand)' : '', email: eing.m ? 'Objekt (von Hand)' : '' } };
        db.kontakte.push(k);
        meldung = 'Kontakt „' + k.name + '“ angelegt und verknüpft';
      }
      o.eigentuemerId = k.id;
      try{ if(typeof ob24KontaktVerknuepfen === 'function') ob24KontaktVerknuepfen(o, k.id, 'eigentuemer'); }catch(e){}
      o.vb25 = { k: k.id, n: vb25S(o.verkaeuferName), t: vb25S(o.verkaeuferTelefon), m: vb25S(o.verkaeuferEmail) };
    }
    const n = vb25Abgleichen();
    if(meldung || n){ save(); renderMain(); if(meldung) akqToast('📇 ' + meldung); }
  }catch(e){ console.error('vb25 speichereObjekt', e); }
  return r;
};
// Kontakt-, Suchkunden- und Aufgaben-Dialog: nach dem Speichern sofort überall angleichen
for(const fn of ['speichereKontakt', 'skSpeichern', 'ak24ApSpeichern', 'ak24KoopSpeichern', 'ak24AbschlussSpeichern', 'ob24KontaktDialogSpeichern']){
  try{
    const alt = window[fn]; if(typeof alt !== 'function') continue;
    window[fn] = function(){ const r = alt.apply(this, arguments); try{ if(vb25Abgleichen()){ save(); renderMain(); } }catch(e){} return r; };
  }catch(e){}
}
// Vor jedem Schreiben abgleichen (fängt auch Importe, Akquise, Hausverwaltungen-Modul und den Abgleich mit dem Handy ab)
const _vb25Schreibe = _schreibe;
_schreibe = function(){
  let n = 0; try{ n = vb25Abgleichen(); }catch(e){}
  const r = _vb25Schreibe.apply(this, arguments);
  if(n){ setTimeout(() => { try{ if(!document.getElementById('modalBg').classList.contains('show')) renderMain(); const fr = document.getElementById('hvFrame'); if(fr && fr.contentWindow && fr.contentWindow.hvReload) fr.contentWindow.hvReload(); }catch(e){} }, 0); }
  return r;
};
// Anzeige bevorzugt den Kontakt (falls eine Kopie einmal hinterherhinkt)
aqTel = function(o){ const k = aqKontakt(o); return (k && k.telefon) || o.verkaeuferTelefon || ''; };
aqMail = function(o){ const k = aqKontakt(o); return (k && k.email) || o.verkaeuferEmail || ''; };
aqName = function(o){ const k = aqKontakt(o); return (k && !vb25Platzhalter(k.name) ? k.name : '') || o.verkaeuferName || ''; };
try{ if(typeof skTel === 'function'){ skTel = function(g){ const k = g.kontaktId ? findKontakt(g.kontaktId) : null; return (k && k.telefon) || g.telefon || ''; }; } }catch(e){}
try{ if(typeof skMailAdr === 'function'){ skMailAdr = function(g){ const k = g.kontaktId ? findKontakt(g.kontaktId) : null; return (k && k.email) || g.email || ''; }; } }catch(e){}
// Hinweis oben: offene Klärungen
const _vb25Hinweise = tbHinweise;
tbHinweise = function(){
  const l = _vb25Hinweise.apply(this, arguments);
  try{ const n = vb25Offen().length; if(n) l.unshift({ k: 'vb25', ic: '📇', t: `${n} abweichende Kontaktangabe${n === 1 ? '' : 'n'} – bitte klären`, s: 'Klären', f: 'vb25KlaerenDialog()' }); }catch(e){}
  return l;
};
// Beim Start einmal abgleichen (Altbestand: leere Felder ergänzen, echte Abweichungen als Klärung)
window.addEventListener('load', () => {
  try{ if(vb25Abgleichen()){ save(); renderMain(); } }catch(e){ console.error('vb25 start', e); }
});
