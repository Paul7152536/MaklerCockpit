// ═══ MaklerCockpit v47 – Akquise: Kleinanzeigen-Nachricht ins Feld, „Keine Makler“, Anrufliste für morgen, 2-Wochen-Meldung ═══
// 1) PC: „Nachricht“ bei Kleinanzeigen-Leads öffnet die Anzeige im Kleinanzeigen-Fenster und trägt den Text ins Nachrichtenfeld ein.
//    Senden klickt Paul selbst (kein automatisches Verschicken – Nutzungsbedingungen, § 7 UWG). Steht „keine Makler“ im Inserat,
//    wird nichts eingetragen, nur auf Nachfrage („Trotzdem eintragen“).
// 2) „🚫 Keine Makler“-Markierung an Leads, deren Text das sagt (oder die das Fenster so erkannt hat).
// 3) „📞 Morgen anrufen“: pro Tag EIN Kalendertermin „📞 Anrufliste“ mit allen Leads (statt eines Termins je Lead).
// 4) Nachfass-Hinweise nach 5 Tagen standardmäßig aus – gemeldet wird erst nach 2 Wochen ohne Antwort (angeschrieben31, „Alle löschen?“).

const AK47_KEIN_MAKLER = /(bitte\s+)?(keine?n?|kein)\s+(makler|immobilienmakler|vermittler)|nicht\s+(an|über|ueber)\s+makler|makler\w*\s*(anfragen|angebote|anrufe)?\s*(zwecklos|unerw[üu]nscht|nicht\s+erw[üu]nscht|bitte\s+nicht|ausgeschlossen|verboten|sinnlos)|ohne\s+makler|maklerfrei|keine\s+gewerblichen\s+anfragen/i;
const AK47_MAKLER_OK = /makler\w*\s*(sind\s+|ist\s+|auch\s+|gerne\s+)?(ok(ay)?\b|willkommen|erw[üu]nscht|gerne?\b)/i;
function ak47KeinMakler(o){
  if(!o) return false;
  if(o.keinMakler === true || o.keinMakler === false) return o.keinMakler;
  const t = [o.akqTitel, o.titel, o.details, o.beschreibung, o.text, o.inseratText, o.quelleText].filter(Boolean).join(' ');
  return !!t && AK47_KEIN_MAKLER.test(t) && !AK47_MAKLER_OK.test(t);
}
function ak47KaLink(o){ const u = String((o && o.link) || '').trim(); return /^https:\/\/(www\.)?kleinanzeigen\.de\//i.test(u) ? u : ''; }
function ak47FensterDa(){ return !!(window.pc && typeof window.pc.webfenster === 'function' && window.pc.geraet === 'pc'); }

// ── 1) Nachricht im Kleinanzeigen-Fenster eintragen ──
(function(){
  const _s = aq2Senden;
  aq2Senden = function(art){
    const o = findObjekt(AQ2.sel), link = ak47KaLink(o);
    if(!o || !link || !ak47FensterDa() || aqMail(o)) return _s.apply(this, arguments);
    const _open = window.open; let abgefangen = false;
    window.open = function(u){ if(String(u) === o.link){ abgefangen = true; return null; } return _open.apply(window, arguments); };
    let A; try{ A = _s.apply(this, arguments); } finally { window.open = _open; }
    if(abgefangen && A && A.text){
      window.pc.webfenster('nachricht', { url: link, text: A.text, id: o.id }).then(r => {
        if(r && r.ok === false) akqToast('⚠️ ' + (r.fehler || 'Kleinanzeigen-Fenster ging nicht auf'), 5000);
        else akqToast('💬 Anzeige im Kleinanzeigen-Fenster – der Text wird ins Nachrichtenfeld eingetragen. Senden klickst du selbst.', 6000);
      }).catch(() => {});
    }
    return A;
  };
  const _k = kgDaten;
  kgDaten = function(d){
    if(d && d.art === 'nachricht'){
      const o = findObjekt(d.id);
      if(d.ergebnis === 'keinMakler'){
        if(o && o.keinMakler !== true){ o.keinMakler = true; aqLog(o, 'info', '🚫 Im Inserat steht „keine Makler“'); save(); try{ aq2Neu(); }catch(e){} }
        akqToast('🚫 Im Inserat steht „keine Makler“ – nichts eingetragen. Im Fenster geht „Trotzdem eintragen“.', 7000);
      } else if(d.ergebnis === 'keinFeld') akqToast('Kein Nachrichtenfeld gefunden – im Fenster einloggen bzw. „Nachricht schreiben“ klicken. Text ist in der Zwischenablage.', 7000);
      return null;
    }
    return _k.apply(this, arguments);
  };
})();

// ── 2) + 3) Markierungen in Liste und Detail ──
function ak47Heute(){ return toDateKey(new Date()); }
function ak47Morgen(){ let d = gsTagPlus(ak47Heute(), 1); if(new Date(d + 'T12:00:00').getDay() === 0) d = gsTagPlus(d, 1); return d; }   // Sonntag → Montag
function ak47TagKurz(d){ const t = new Date(d + 'T12:00:00'); return t.toLocaleDateString('de-DE', { weekday: 'short', day: '2-digit', month: '2-digit' }); }
function ak47Zeit(){ const a = akqDb(); return /^\d{2}:\d{2}$/.test(a.anrufZeit || '') ? a.anrufZeit : '09:00'; }
function ak47Geplant(o){ return o && o.anrufTag && o.anrufTag >= ak47Heute() ? o.anrufTag : ''; }
function ak47Leads(datum){ return (db.objekte || []).filter(o => o.anrufTag === datum && aqTel(o)); }
function ak47TerminId(datum){ return 'anrufliste-' + datum; }
function ak47TerminAktualisieren(datum){
  const l = ak47Leads(datum), id = ak47TerminId(datum), t = (db.termine || []).find(x => x.id === id);
  if(!l.length){ if(t){ db.termine = db.termine.filter(x => x.id !== id); } return null; }
  const offen = l.filter(o => o.anrufErledigt !== datum).length;
  const zeilen = l.map((o, i) => `${o.anrufErledigt === datum ? '✓' : '☐'} ${aqTel(o)} – ${aqName(o) || 'Privat'} – ${String(aqTitel(o) || '').slice(0, 60)}${o.ort ? ' (' + aqOrtKurz(o) + ')' : ''}`);
  const daten = { titel: `📞 Anrufliste: ${l.length} Anruf${l.length === 1 ? '' : 'e'}${offen < l.length ? ` (${offen} offen)` : ''}`, datum, uhrzeit: (t && t.uhrzeit) || ak47Zeit(),
    dauer: Math.min(120, Math.max(30, l.length * 10)), art: 'rueckruf', artEigene: '', ort: 'Telefon', notiz: 'Heute anrufen (Liste im MaklerCockpit → Akquise → 📞 Anrufliste):\n' + zeilen.join('\n'), objektId: null, kontaktId: null, anrufliste: true };
  if(t){ if(t.titel !== daten.titel || t.notiz !== daten.notiz || t.dauer !== daten.dauer){ Object.assign(t, daten); t.geaendertAm = Date.now(); } return t; }
  const neu = Object.assign({ id, createdAt: Date.now(), geaendertAm: Date.now() }, daten);
  db.termine.push(neu); return neu;
}
function ak47Planen(id, datum){
  const o = findObjekt(id); if(!o) return;
  if(!aqTel(o)){ akqToast('Keine Telefonnummer'); return; }
  datum = datum || ak47Morgen();
  const alt = o.anrufTag;
  o.anrufTag = datum; delete o.anrufErledigt;
  aqLog(o, 'termin', '📞 Auf die Anrufliste für ' + ak47TagKurz(datum) + ' gesetzt');
  if(alt && alt !== datum) ak47TerminAktualisieren(alt);
  const t = ak47TerminAktualisieren(datum);
  save(); try{ aq2Neu(); }catch(e){} if(typeof gsPlanen === 'function') gsPlanen(400);
  const n = ak47Leads(datum).length;
  akqToast(`📞 Für ${ak47TagKurz(datum)} vorgemerkt – ${n === 1 ? 'ein Kalendereintrag' : 'zusammen mit ' + (n - 1) + ' weiteren in einem Kalendereintrag'} um ${t ? t.uhrzeit : ak47Zeit()} Uhr`, 5000);
}
function ak47Entfernen(id){
  const o = findObjekt(id); if(!o || !o.anrufTag) return;
  const d = o.anrufTag; delete o.anrufTag; delete o.anrufErledigt;
  ak47TerminAktualisieren(d); save(); try{ aq2Neu(); }catch(e){} if(typeof gsPlanen === 'function') gsPlanen(400);
  akqToast('Von der Anrufliste genommen');
}
function ak47KnopfHtml(o, klein){
  if(!o || !aqTel(o)) return '';
  const g = ak47Geplant(o);
  if(g) return `<span class="ak47-geplant${klein ? ' klein' : ''}" title="Steht auf der Anrufliste">📞 ${g === ak47Heute() ? 'heute' : ak47TagKurz(g)}${o.anrufErledigt === g ? ' ✓' : ''}<button class="ak47-x" onclick="event.stopPropagation();ak47Entfernen('${o.id}')" title="Von der Anrufliste nehmen">✕</button></span>`;
  return `<button class="ak47-morgen${klein ? ' klein' : ''}" onclick="event.stopPropagation();ak47Planen('${o.id}')" title="Morgen anrufen – alle Anrufe eines Tages stehen in EINEM Kalendereintrag">📞 Morgen anrufen</button>`;
}
function ak47ListeDialog(datum){
  datum = datum || ak47Heute();
  const tage = Array.from(new Set((db.objekte || []).map(o => o.anrufTag).filter(d => d && d >= ak47Heute()))).sort();
  if(!tage.includes(datum)) datum = tage[0] || datum;
  const l = ak47Leads(datum), t = (db.termine || []).find(x => x.id === ak47TerminId(datum)), E = mc24E;
  mc24Modal(`<h3>📞 Anrufliste</h3>
    <div class="ak47-tage">${tage.map(d => `<button class="${d === datum ? '' : 'secondary'} tiny" onclick="ak47ListeDialog('${d}')">${d === ak47Heute() ? 'Heute' : ak47TagKurz(d)} (${ak47Leads(d).length})</button>`).join('') || '<span class="mc24-muted">Keine Anrufe geplant.</span>'}</div>
    ${l.length ? `<div class="ak47-zeit">Kalendereintrag um <input type="time" value="${E((t && t.uhrzeit) || ak47Zeit())}" onchange="ak47ZeitSetzen('${datum}', this.value)"> Uhr · ein Eintrag für alle ${l.length}</div>
    <div class="ak47-liste">${l.map(o => `<div class="ak47-z${o.anrufErledigt === datum ? ' fertig' : ''}">
      <div class="ak47-info"><b>${E(aqTitel(o) || 'Lead')}</b><div class="mc24-muted">${E([aqName(o), aqOrtKurz(o), o.kaufpreis ? aqEur(o.kaufpreis) : ''].filter(Boolean).join(' · '))}</div></div>
      <a class="ak47-tel" href="#" onclick="ak47Anrufen('${o.id}');return false;">📞 ${E(aqTel(o))}</a>
      <button class="secondary tiny" onclick="ak47Erledigt('${o.id}','${datum}')">${o.anrufErledigt === datum ? '↺ offen' : '✓ erledigt'}</button>
      <button class="secondary tiny" title="Von der Liste nehmen" onclick="ak47Entfernen('${o.id}');ak47ListeDialog('${datum}')">✕</button></div>`).join('')}</div>` : ''}
    <div class="modal-actions"><span class="mc24-muted" style="font-size:12px;">Im Kalender steht pro Tag nur EIN Eintrag mit allen Nummern.</span><div class="right"><button class="secondary" onclick="schliesseModal()">Schließen</button></div></div>`, 640);
}
function ak47ZeitSetzen(datum, z){
  if(!/^\d{2}:\d{2}$/.test(z)) return;
  akqDb().anrufZeit = z;
  const t = (db.termine || []).find(x => x.id === ak47TerminId(datum)); if(t){ t.uhrzeit = z; t.geaendertAm = Date.now(); }
  save(); if(typeof gsPlanen === 'function') gsPlanen(400); akqToast('Uhrzeit gespeichert: ' + z + ' Uhr');
}
function ak47Anrufen(id){
  schliesseModal();
  if(typeof wechsleAnsicht === 'function' && aktuelleAnsicht !== 'akquise') wechsleAnsicht('akquise');
  AQ2.sel = id; try{ aq2Liste(); }catch(e){}
  setTimeout(() => { try{ aq2Anrufen(); }catch(e){} }, 120);
}
function ak47Erledigt(id, datum){
  const o = findObjekt(id); if(!o) return;
  if(o.anrufErledigt === datum) delete o.anrufErledigt; else o.anrufErledigt = datum;
  ak47TerminAktualisieren(datum); save(); if(typeof gsPlanen === 'function') gsPlanen(400); ak47ListeDialog(datum);
}
function ak47Balken(){
  const liste = document.getElementById('aqListe'); if(!liste) return;
  let b = document.getElementById('ak47Balken');
  const h = ak47Leads(ak47Heute()), offen = h.filter(o => o.anrufErledigt !== ak47Heute()).length, m = ak47Leads(ak47Morgen()).length;
  if(!h.length && !m){ if(b) b.remove(); return; }
  if(!b){ b = document.createElement('div'); b.id = 'ak47Balken'; liste.parentNode.insertBefore(b, liste); }
  b.innerHTML = `<div class="ak47-balken" onclick="ak47ListeDialog()"><b>📞 Anrufliste</b><span>${h.length ? `heute ${offen} von ${h.length} offen` : ''}${h.length && m ? ' · ' : ''}${m ? `${ak47TagKurz(ak47Morgen())}: ${m}` : ''}</span><span class="ak47-auf">Öffnen ›</span></div>`;
}
(function(){
  const _l = aq2Liste;
  aq2Liste = function(){
    const r = _l.apply(this, arguments);
    try{
      ak47Balken();
      document.querySelectorAll('#aqListe .lc').forEach(k => {
        const o = findObjekt(String(k.id || '').replace(/^lc-/, '')); if(!o) return;
        const tags = k.querySelector('.lc-tags');
        if(tags && ak47KeinMakler(o) && !tags.querySelector('.ak47-km')) tags.insertAdjacentHTML('afterbegin', '<span class="chip ak47-km" title="Im Inserat steht, dass keine Makler gewünscht sind">🚫 Keine Makler</span>');
        const tel = k.querySelector('.lc-rechts .tel');
        if(tel && aqTel(o) && !k.querySelector('.ak47-morgen, .ak47-geplant')) tel.insertAdjacentHTML('afterend', ak47KnopfHtml(o, true));
      });
    }catch(err){ console.error('ak47 Liste', err); }
    return r;
  };
  const _d = aq2Detail;
  aq2Detail = function(){
    const r = _d.apply(this, arguments);
    try{
      const o = findObjekt(AQ2.sel), el = document.getElementById('aqDetail'); if(!o || !el) return r;
      if(ak47KeinMakler(o) && !el.querySelector('.ak47-warn')){ const tags = el.querySelector('.lc-tags'); if(tags) tags.insertAdjacentHTML('afterend', `<div class="ak47-warn">🚫 <b>Keine Makler gewünscht</b> – laut Inserat. Anschreiben lieber lassen.${o.keinMakler === true ? '' : ` <a href="#" onclick="ak47KmSetzen('${o.id}', false);return false;">Stimmt nicht</a>`}</div>`); }
      const telZ = [...el.querySelectorAll('.dp-zeile')].find(z => /Telefon/.test((z.querySelector('.k') || {}).textContent || ''));
      if(telZ && aqTel(o) && !telZ.querySelector('.ak47-morgen, .ak47-geplant')) telZ.querySelector('.w').insertAdjacentHTML('beforeend', ' ' + ak47KnopfHtml(o));
    }catch(err){ console.error('ak47 Detail', err); }
    return r;
  };
  const _a = aq2Anruf;
  aq2Anruf = function(st){
    const o = findObjekt(AQ2.sel), heute = ak47Heute();
    if(o && o.anrufTag && o.anrufTag <= heute){ o.anrufErledigt = o.anrufTag; ak47TerminAktualisieren(o.anrufTag); }
    const r = _a.apply(this, arguments);
    try{
      if(o && st === 'nicht_erreicht') aq2ErgebnisZeigen(`<span style="font-size:12px;color:var(--muted);width:100%;">Nicht erreicht – morgen nochmal?</span><button onclick="ak47Planen('${o.id}');aq2ErgebnisZeigen('')">📞 Morgen nochmal anrufen</button><button class="secondary" onclick="aq2ErgebnisZeigen('')">Nein</button>`);
      if(typeof gsPlanen === 'function') gsPlanen(800);
    }catch(e){}
    return r;
  };
  const _h = tbHinweise;
  tbHinweise = function(){
    const l = _h.apply(this, arguments);
    try{
      const h = ak47Leads(ak47Heute()).filter(o => o.anrufErledigt !== ak47Heute()).length;
      if(h) l.unshift({ k: 'ak47', n: h, ic: '📞', t: `Anrufliste heute: ${h} Anruf${h === 1 ? '' : 'e'} offen`, s: 'Liste öffnen', f: 'ak47ListeDialog()' });
    }catch(e){}
    return l;
  };
})();
function ak47KmSetzen(id, wert){ const o = findObjekt(id); if(!o) return; o.keinMakler = wert; save(); aq2Neu(); }
// ── 4) Nachfass-Hinweise (5 Tage) einmalig aus – Meldung erst nach 2 Wochen ──
window.addEventListener('load', () => {
  try{
    const a = akqDb();
    if(!a.v47Hinweise){ db.hinweisEinst = Object.assign({}, db.hinweisEinst || {}); if(db.hinweisEinst.nachfassen === undefined) db.hinweisEinst.nachfassen = false; a.v47Hinweise = 1; save(); }
  }catch(e){ console.error('ak47', e); }
});
(function(){
  const st = document.createElement('style');
  st.textContent = `.ak47-morgen{background:none;border:1px solid var(--orange);color:var(--orange);border-radius:999px;padding:2px 10px;font-size:12px;font-weight:600;white-space:nowrap;cursor:pointer}
.ak47-morgen.klein{padding:1px 8px;font-size:11px;margin-top:3px}
.ak47-geplant{display:inline-flex;gap:4px;align-items:center;background:rgba(255,138,61,.16);color:var(--orange);border-radius:999px;padding:2px 4px 2px 10px;font-size:12px;font-weight:600;white-space:nowrap}
.ak47-geplant.klein{font-size:11px;margin-top:3px}.ak47-x{background:none;border:0;color:var(--muted);padding:0 5px;cursor:pointer;font-size:12px}
.ak47-km{background:rgba(239,68,68,.15) !important;color:#f87171 !important;border-color:rgba(239,68,68,.4) !important}
.ak47-warn{margin:8px 0;padding:8px 10px;border:1px solid rgba(239,68,68,.45);background:rgba(239,68,68,.10);border-radius:8px;font-size:13px}
.ak47-balken{display:flex;gap:12px;align-items:center;margin:0 0 8px;padding:9px 12px;border:1px solid var(--orange);border-radius:10px;background:rgba(255,138,61,.10);cursor:pointer;font-size:13px}.ak47-auf{margin-left:auto;color:var(--orange);font-weight:600}
.ak47-tage{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:10px}.ak47-zeit{font-size:13px;margin-bottom:8px}.ak47-zeit input{width:auto;display:inline-block;padding:3px 6px}
.ak47-liste{display:flex;flex-direction:column;gap:6px;max-height:55vh;overflow:auto}
.ak47-z{display:flex;gap:8px;align-items:center;border:1px solid var(--border);border-radius:8px;padding:7px 9px}.ak47-z.fertig{opacity:.55}.ak47-z.fertig .ak47-info b{text-decoration:line-through}
.ak47-info{flex:1;min-width:0}.ak47-info b{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.ak47-tel{white-space:nowrap;font-weight:600}
@media (max-width:760px){.ak47-z{flex-wrap:wrap}.ak47-info{flex-basis:100%}}`;
  document.head.appendChild(st);
})();

// ── 5) Status „📞 Telefontermin“ mit Zusatz Erstkontakt / Nachfassen (Pauls Wunsch 18.11.2026) ──
// Telefontermin im Termin-Dialog (früher „Rückruf“) bzw. als nächster Schritt im Gesprächsabschluss → Status „Telefontermin“.
// Erstkontakt = noch nie erreicht/gesprochen, Nachfassen = es gab schon ein Gespräch. Anzeige z. B. „📞 Telefontermin · Erstkontakt“.
// Außerdem: Status „Nochmal anrufen“ heißt jetzt überall so (vorher stand in der Liste „Rückruf“).
(function(){
  try{
    if(!OBJEKT_STATUS.some(s => s[0] === 'telefontermin')){ const i = OBJEKT_STATUS.findIndex(s => s[0] === 'nochmal_anrufen'); OBJEKT_STATUS.splice(i + 1, 0, ['telefontermin', '📞 Telefontermin']); }
    ['telefontermin'].forEach(s => { if(!AQ_OFFEN.includes(s)) AQ_OFFEN.push(s); if(!AQ_KONTAKTIERT.includes(s)) AQ_KONTAKTIERT.push(s); });
    AQ_ST_KURZ.telefontermin = 'Telefontermin';
    AQ_ST_KURZ.nochmal_anrufen = 'Nochmal anrufen';
    const r = AQ_TA.find(a => a.k === 'rueckruf'); if(r){ r.l = 'Telefontermin'; r.ic = '📞'; r.st = 'telefontermin'; r.dauer = 15; }
  }catch(e){ console.error('ak47 Status', e); }
})();
function ak47TelArtVorschlag(o){
  if(!o) return 'erstkontakt';
  const gesprochen = ['erstkontakt', 'termin', 'auftrag', 'online', 'abgeschlossen'].includes(o.status) || (o.verlauf || []).some(v => v.typ === 'gespraech' || /Angerufen – erreicht/.test(String(v.text || '')));
  return gesprochen ? 'nachfassen' : 'erstkontakt';
}
function ak47StatusText(o){ return o && o.status === 'telefontermin' ? '📞 Telefontermin' + (o.telefonArt === 'nachfassen' ? ' · Nachfassen' : o.telefonArt === 'erstkontakt' ? ' · Erstkontakt' : '') : ''; }
function ak47PillsSetzen(wurzel){
  (wurzel || document).querySelectorAll('.pill.st-telefontermin').forEach(p => {
    const id = (p.closest('.lc') && p.closest('.lc').id.replace(/^lc-/, '')) || (p.closest('#aqDetail') && AQ2.sel) || '';
    const o = id && findObjekt(id); if(o) p.textContent = ak47StatusText(o);
  });
}
(function(){
  const _l = aq2Liste, _d = aq2Detail;
  aq2Liste = function(){ const r = _l.apply(this, arguments); try{ ak47PillsSetzen(document.getElementById('aqListe')); }catch(e){} return r; };
  aq2Detail = function(){
    const r = _d.apply(this, arguments);
    try{
      const o = findObjekt(AQ2.sel), el = document.getElementById('aqDetail'); if(!o || !el) return r;
      ak47PillsSetzen(el);
      if(o.status === 'telefontermin'){ const sel = [...el.querySelectorAll('.dp-zeile')].find(z => /Status/.test((z.querySelector('.k') || {}).textContent || '')); const w = sel && sel.querySelector('.w');
        if(w && !w.querySelector('.ak47-telart')) w.insertAdjacentHTML('beforeend', ` <span class="ak47-telart">${['erstkontakt', 'nachfassen'].map(a => `<button class="${o.telefonArt === a ? '' : 'secondary'} tiny" onclick="ak47TelArt('${o.id}','${a}')">${a === 'erstkontakt' ? 'Erstkontakt' : 'Nachfassen'}</button>`).join('')}</span>`); }
    }catch(e){ console.error('ak47 Status Detail', e); }
    return r;
  };
  // Status von Hand auf „Telefontermin“ → Art vorschlagen
  const _st = aq2StatusSetzen;
  aq2StatusSetzen = function(st){ const o = findObjekt(AQ2.sel); if(o && st === 'telefontermin' && !o.telefonArt) o.telefonArt = ak47TelArtVorschlag(o); return _st.apply(this, arguments); };
  // Termin-Dialog: bei „Telefontermin“ Auswahl Erstkontakt / Nachfassen
  const _ta = aq2TqArt;
  aq2TqArt = function(k){
    const r = _ta.apply(this, arguments);
    try{
      const o = findObjekt(AQ_TQ && AQ_TQ.objektId), arten = document.querySelector('.tq-arten'); if(!o || !arten) return r;
      let box = document.getElementById('ak47TqArt');
      if(k !== 'rueckruf'){ if(box) box.remove(); return r; }
      if(!box){ arten.insertAdjacentHTML('afterend', `<div id="ak47TqArt" class="ak47-tqart"><span>Telefontermin für</span>${['erstkontakt', 'nachfassen'].map(a => `<label><input type="radio" name="ak47telart" value="${a}" ${ak47TelArtVorschlag(o) === a ? 'checked' : ''}> ${a === 'erstkontakt' ? 'Erstkontakt' : 'Nachfassen'}</label>`).join('')}</div>`); }
      if(!AQ_TQ.titelManuell){ const t = document.getElementById('tq_titel'); if(t) t.value = '📞 Telefontermin: ' + aqTitel(o) + (o.ort ? ' (' + aqOrtKurz(o) + ')' : ''); }
    }catch(e){ console.error('ak47 Termin', e); }
    return r;
  };
  const _an = aq2TerminAnlegen;
  aq2TerminAnlegen = function(){
    const o = findObjekt(AQ_TQ && AQ_TQ.objektId), art = AQ_TQ && AQ_TQ.art, w = document.querySelector('input[name="ak47telart"]:checked');
    const wahl = w ? w.value : '';
    const r = _an.apply(this, arguments);
    try{ if(o && art === 'rueckruf' && wahl){ o.telefonArt = wahl; if(o.status === 'telefontermin'){ aqLog(o, 'info', '📞 Telefontermin (' + (wahl === 'nachfassen' ? 'Nachfassen' : 'Erstkontakt') + ')'); } save(); aq2Neu(); } }catch(e){}
    return r;
  };
  const st = document.createElement('style');
  st.textContent = `.st-telefontermin{background:rgba(56,189,248,.16);color:#7dd3fc}
.ak47-tqart{display:flex;flex-wrap:wrap;gap:6px 14px;align-items:center;margin:4px 0 10px;padding:8px 10px;border:1px solid var(--border);border-radius:8px;font-size:13px}.ak47-tqart label{display:flex;gap:5px;align-items:center;margin:0;text-transform:none;letter-spacing:0;font-size:13px;color:var(--text)}.ak47-tqart input{width:auto;margin:0}
.ak47-telart{display:inline-flex;gap:4px;margin-left:6px}`;
  document.head.appendChild(st);
})();
function ak47TelArt(id, a){ const o = findObjekt(id); if(!o) return; o.telefonArt = a; save(); aq2Neu(); }
