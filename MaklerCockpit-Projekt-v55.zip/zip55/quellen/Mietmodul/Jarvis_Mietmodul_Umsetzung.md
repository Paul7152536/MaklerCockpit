# Umsetzung: Mietpotenzial in Jarvis und Marktanalyse

Version 1.0 | 15.11.2026 | Auftrag für die Coding-KI

## Ziel

Erweitere das vorhandene Jarvis-/MaklerCockpit-System um eine quellengebundene Mietpotenzialanalyse je Wohnung oder Haus. Die vorhandene Kaufpreis-Marktanalyselogik bleibt erhalten. Verwende vorhandene IDs, Berechtigungen, Dokumentenablage, Terminlogik, Datenbankkonventionen und Oberflächenkomponenten. Untersuche zuerst die tatsächliche Projektstruktur; erfinde keine bereits vorhandenen APIs oder Zugänge.

Fachgrundlagen sind Mietmodul_Handbuch.md, Jarvis_Mietrecht_Bauskript.md sowie die beiden Analyse-/Updateprompts. Der aktualisierte 02_Masterprompt.md verlangt künftig ein eigenes rental_analysis-Ergebnis.

## 1. Sichtbares Ergebnis je Objekt

| Bereich | Pflichtinhalt |
|---|---|
| Überblick | Ist-Miete, Marktspanne, Durchschnitt, Median, OVM, geprüfte Mietempfehlung, Jahresmiete, Datenstand |
| Vergleichsangebote | Bis 20 geeignete Einzelobjekte; Rohpreis, bereinigte Nettomiete, Fläche, €/m², Quelle, Datum, Eignung |
| Statistik | Min/Max mit Objektbezug, Mittel, Median, P25/P75, optional Flächengewichtung; n und Filter sichtbar |
| Region | Amtliche/primäre Aggregate mit Raumzuschnitt und Beobachtungszeitraum |
| Rechtsprüfung | Geltungsbereich, Gebiet, Vertrag, Bindungen, OVM-Nachweis, Ausnahmen, Auskunftsstatus |
| Erhöhung | Passender Rechtsweg mit Rechenschritten, Restbudget und Wirkungstermin |
| Investition | Kosten, Erhaltung, Förderung, rechtlicher Mehrbetrag, zeitlicher Beginn und Wirtschaftlichkeit |
| Inserat | Generierter Text nur aus aktuellem freigegebenem Snapshot |
| Quellen | Abruf, Geltung, Fundstelle, Nutzungsrecht und Änderungen |

Karten dürfen keine Zahlen zeigen, deren Bezugsart verborgen bleibt. Kein Sammelfeld „Maximalmiete“ für Angebotsmaximum und Rechtsgrenze. Zeige vorläufige Informationen auch bei offenen Akten; sperre nur die hiervon abhängige definitive Aussage.

## 2. Datenmodell ergänzen

Verwende das vorhandene Modell, ergänzt um folgende fachliche Entitäten:

- rental_comparable: Objektbezug, Quell-ID, Portal-ID, URL, Beobachtungs-/Veröffentlichungsdatum, Fläche mit Definition, Wohnungs-Nettokaltmiete, Mietbestandteile, Bau-/Ausstattungsfakten, Lagegenauigkeit, Rohdatenhash, Status und Eignung.
- rental_comparable_group: kanonische Dubletten-ID und Preisereignisse. Ein Objekt zählt pro Stichtagsbestand einmal.
- rental_market_snapshot: Zielobjekt, Filter, Zeitraum, verwendete IDs, Ausschlusslog, Kennzahlen, Quantilmethode, Einheiten, Qualität und Quellenstände.
- regional_rent_snapshot: Region/Gemeindeschlüssel, Mietbegriff, Objektsegment, Zeitraum, Mittel/Median/Spannenart und Fallzahl. Fehlende Extremwerte bleiben null.
- rental_legal_assessment: Szenario und rechtlicher Zeitpunkt, Gebietsregelversionen, Mietspiegelfassung, Merkmalsnachweise, Bindungen, Ausnahme-/Auskunftsbelege, Status und Fachprüfung.
- rental_potential_snapshot: references zu Markt/Recht/Vertrag/Rechnung, Ist, Marktvarianten, Rechtsgrenze, Empfehlung, Erhöhungsweg, Timing und Inseratstextstatus.
- rental_refresh_run: geplanter Termin, Zeitzone, idempotency_key, Baseline, Quellenchecks, Änderungen, Fehler, neue Snapshots und nächste Prüfung.

Geldwerte als Dezimalwerte beziehungsweise bestehende centgenaue Geldtypen; Einheitspreise und Quotienten mit ausreichender Präzision. Datenstatus unknown, not_applicable, confirmed, disputed getrennt halten. Keine boolesche False-Vorgabe für ungeprüfte Ausnahmen. Quellenbelege je Wert referenzieren.

## 3. Regionale Regelpakete

Bundesrecht, Landesverordnung, kommunaler Mietspiegel und individuelle Bindungen bilden getrennte versionierte Ebenen. Für jede Regel: normative Fundstelle, Abruf, gültig ab/bis, sachlicher und räumlicher Bereich, Übergangsregeln, fachlicher Bestätiger und Status. Mietpreisbremse und Kappungsgrenze niemals mit einer gemeinsamen Laufzeit speichern.

Gemeindegrenzen anhand amtlicher Zuordnung auflösen. Die vollständigen Brandenburger Listen aus dem Handbuch sind eine überprüfte Baseline, keine unveränderliche Programmkonstante. Bei unbekanntem Datum/Gebiet gibt es keine automatisch bestätigte Mietpreisprüfung.

## 4. Statistikrechner

Implementiere Einzelpreis = belegte Wohnungs-Nettokaltmiete / bestätigte Wohnfläche, Mittel der Einzelpreise, Median und beobachtete Extreme. Ein optionaler flächengewichteter Wert erhält eine eigene Benennung. Quantile nach linearer Interpolation h=(n-1)*q. Eingaben, unveränderte Rohpreise, Bereinigung und Ausgaben werden gemeinsam gespeichert.

Eignung geht vor Anzahl. Keine automatische Entfernung teurer/günstiger Fälle allein wegen des Preises. Keine automatische Warmmietenbereinigung ohne Daten. Keine Untermischung von Küche/Stellplatz/Möbeln, wenn deren Ausgangsdefinition nicht vergleichbar ist. Weniger als fünf geeignete Fälle erzeugen einen deutlichen Vorläufigkeitsstatus; acht Fälle sind keine Garantie statistischer Repräsentativität.

## 5. Rechts- und Erhöhungsrechner anbinden

Verwende den vorhandenen Kern für Mietspiegel, Neuvermietung, §558, Staffel, Index, Modernisierung, Heizung und Betriebskosten. Ergänze fehlende Wege gemäß Handbuch; unterstelle keine bestehende Umsetzung. Jede Route hat eine Mindestdatenprüfung und verwendet das zum Sachverhalt passende Regelpaket.

Für §558 ist die vollständige relevante Chronik mit Ausgangsstichtag und Normalisierung nötig. Für Modernisierung gelten eigene Kosten-/Förder-/Restbudgetprüfungen und Wirkungstermine. Bei Heizung und Wärmepumpe müssen die aktuellen gesetzlichen Sonderregeln und Übergangsfälle unterstützt werden. Betriebskosten benötigen CO2-Stufenmodell und den zum passenden Anlageneinbaufall gehörenden künftigen Pfad nach §5a CO2KostAufG; die Anwendungstermine 2028/2029 werden getrennt vom heutigen Rechts-/Abrufstand gespeichert. Keine freie Addition konkurrierender Rechtswege für dieselbe Verbesserung.

Eine fachliche Freigabe ist Datenstatus und Benutzeraktion, kein vom Sprachmodell erfundener Satz. Freigaben beziehen sich auf den konkreten Snapshot. Änderungen an Fakten oder Regeln setzen betroffene Veröffentlichungsfreigaben aus und verlangen Neuberechnung.

## 6. PDF und Inserat

Ergänze die Marktanalyse um das Kapitel „Mietpotenzial und Ertrag“. Zeige Ist, beobachtete Marktdaten, OVM, rechtlichen Weg und Empfehlung in getrennten Spalten. Quellen und Geltungsdatum jeder entscheidenden Aussage müssen im Anhang auffindbar sein. Tabellenköpfe werden über Seitenumbrüche wiederholt. Kundenausgaben enthalten keine unnötigen persönlichen Mieterinformationen.

Ein Inserat verwendet nur freigegebene Daten. Ist-Rendite und Potenzialrendite erhalten eigene Kennzeichnungen. Bei bestehendem Vertrag darf ein Neuvermietungsszenario nicht als aktuell verfügbare Einnahme erscheinen. Abhängigkeiten wie Leerstand, Investition und Wirkungstermin stehen beim Betrag.

## 7. Zweiwochenlauf

Implementiere einen dauerhaft ausführbaren Hintergrundjob nach Jarvis_Mietmodul_Updateprompt.md. Verwende Europe/Berlin und einen gespeicherten Montagstermin als Anker, danach alle zwei Wochen. Erstelle vor dem Produktivbetrieb einen manuellen Probelauf mit echten Quellenchecks.

Aufgaben: Rechtsquellen und Inkrafttreten prüfen, Landeslisten/Mietspiegel abgleichen, neue VPI-Monate importieren, regionale Veröffentlichungen datieren, aktive Suchprofile aktualisieren, Dubletten zusammenführen, Statistiken neu rechnen und Auswirkungen ausweisen.

Es gibt zwei getrennte Ausgänge: Datensnapshot und Vorschlag für rechtliche Regeländerungen. Gesetzesänderungen werden nach fachlicher Kontrolle aktiviert. Fehler behalten die letzte bestätigte Version, kennzeichnen ihre Aktualität und erzeugen einen Hinweis. Ein fehlgeschlagener Abruf ist kein Beleg für unveränderte Daten.

Der Sprachmodellaufruf erhält nur notwendige Daten. Portalzugang und Nutzungsrechte werden anhand der tatsächlich verfügbaren Zugänge geprüft. Kein automatischer Datenkauf. Der Job schreibt in die eigene vorhandene Ablage; ein Versand an Dritte ist nicht Bestandteil dieses Auftrags.

## 8. Inhaltlich notwendige Abnahmefälle

| Fall | Erwartung |
|---|---|
| Beispielwerte 10/10,5/11/11,5/12/12/12,5/13/14/16 | Mittel 12,25; Median 12; Min 10; Max 16; P25 11,125; P75 12,875 |
| Zwei Portale, gleiche Wohnung | Ein Vergleichsobjekt, zwei Quellen |
| Nur Warmmiete ohne Aufteilung | Keine geratene Nettokaltmiete |
| Berliner Haus von 1990 | Kein direktes Berliner Mietspiegelfeld; Mietpreisbremse separat prüfen |
| Unbekannte Gemeinde | Rechtsergebnis vorläufig/gesperrt |
| Rangsdorf / Zossen | Getrennte Gebietsauflösung nach aktueller Baseline |
| Mietspiegel 5,90/7,30/9,55; Gruppen +,+,+,-,- | 7,75 €/m²; bei 60 m² 465 € |
| 465 € OVM, Standard-Mietpreisbremse | 511,50 € monatlich; keine Rundung auf 511,80 € |
| 600 € Dreijahresbasis, 660 € aktuell, 720 € OVM, 15 % | Ziel 690 €, Mehrbetrag 30 € |
| Gleicher Fall, OVM 680 € | Ziel 680 €, Mehrbetrag 20 € |
| 21.000 Kosten, 6.000 Erhaltung, 3.000 Zuschuss | §559-Rohbetrag 80 €/Monat |
| 70 m², Ausgang 6,50 €/m², 100 € bereits genutzt | Allgemeiner Rest 40 €; neuer Betrag höchstens 40 € im Beispiel |
| Vereinfachung 9.000 € ohne Vorbudgetverbrauch | 30-%-Abzug; Rohbetrag 42 €/Monat vor weiteren Grenzen |
| Heizungs-Regelfall 9.000 €, 15-%-Abzug, 3.000 € Förderung, 60 m² | Roh 38,75 €, höchstens 30 € bei freiem Heizungsrahmen |
| Wärmepumpe ohne erforderlichen Nachweis und ohne Ausnahme | Hälftige Kostenbasis beachten, keine volle automatische Umlage |
| Fiktiver VPI 120 -> 124, Basis 800 € | Ungerundet 826,666... €; Fristen/Form separat |
| Ankündigung/Erklärung noch nicht zugegangen | Kein gespeicherter Wirksamkeitsnachweis |
| Aktive Indexvereinbarung | §558 gesperrt; passende Route wählen |
| Neues Gesetz nur als Entwurf gefunden | Beobachtung; kein produktives Regelupdate |
| Jahresbericht erneut abgerufen | Jahr bleibt unverändert; kein erfundener aktueller Zweiwochenwert |
| Quellenausfall | failure/unknown, letzter gültiger Snapshot; kein „unverändert“ |

Führe sinnvolle Integrationsprüfungen über die tatsächlich vorhandene Anwendung aus. Die Zahlenfälle prüfen Ergebnisse und rechtliche Verzweigungen. Erstelle keine Tests, die nur Implementierungszeilen wiederholen. Bestätige am Ende die ausgeführten Fälle und verbleibenden fachlichen Lücken.

## 9. Ablieferung durch die Coding-KI

Liefere implementierte Funktionen, Schema-/Datenbankmigrationen, manuell auslösbaren und geplanten Aktualisierungslauf, Berechnungsprotokoll, PDF-Beispiel, ausgeführte Abnahmeergebnisse und eine kurze Betriebsanleitung. Nenne notwendige Zugänge und noch fehlende Norm-/Datensätze konkret. Behaupte weder eine laufende Zweiwochenaktualisierung ohne Scheduler noch eine Datenquelle, die technisch nicht angebunden wurde.
