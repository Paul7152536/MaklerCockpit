# Jarvis-Prompt: Aktualisierung alle zwei Wochen

Version 1.0 | 15.11.2026 | Europe/Berlin

Dieser Prompt beschreibt den Inhalt eines Laufs. Die Wiederholung muss ein Scheduler auslösen. Bei einer nicht angebundenen Installation liefert der Lauf ein Updatepaket; er behauptet keinen erfolgreichen Import in Jarvis.

```text
AUFTRAG
Aktualisiere für Paul Görner / Görner Immobilien die Quellen- und Datenbasis des Jarvis-Moduls „Miete & Ertrag“ für Berlin und Brandenburg. Nutze den tatsächlichen Laufzeitpunkt in Europe/Berlin als Recherchestichtag und den letzten erfolgreichen Lauf als Vergleichsbasis. Übernimm neu eingegebene Objekt-/Suchprofile. Arbeite quellengebunden und dokumentiere jede Änderung.

EINGABEN
- Letzter erfolgreich bestätigter Quellensnapshot samt Hashes/Versionen.
- Aktives fachlich bestätigtes Regelpaket und Anwendungszeiträume.
- Aktive Objekt-IDs mit genehmigten Suchprofilen; keine unnötigen Mieterdaten.
- Bereits bekannte offene Fragen und angekündigte Inkrafttretensdaten.
Fehlt der alte Snapshot, erstelle eine Baseline und kennzeichne, dass ein belastbarer Änderungsvergleich noch fehlt. Fehlende Objektprofile bedeuten einen regionalen Quellenlauf, keine vorgetäuschte objektweise Aktualisierung.

1. BUNDESRECHT
Prüfe amtlich die für Mietpreise/Erhöhungen relevanten BGB-Vorschriften, insbesondere §§549,555a-555e,556-556g,557-559f,560-561, ferner BetrKV, HeizkostenV, CO2KostAufG, das einschlägige Gebäude-/Heizungsrecht und Übergangsvorschriften. Suche nach wichtigen neuen einschlägigen Entscheidungen bei BGH/BVerfG sowie amtlichen Fundstellen. Prüfe nur tatsächlich relevante Entscheidungen näher; behaupte keine vollständige Erfassung aller deutschen Gerichtsverfahren.

2. LAND UND GEMEINDE
Prüfe Berliner Mietenbegrenzungs- und Kappungsgrenzenverordnung mit getrennten Geltungszeiträumen. Prüfe beide Brandenburger Verordnungen mit vollständigen Gemeindelisten und getrennten Enddaten. Prüfe neue Mietspiegel, Straßen-/Wohnlagenverzeichnisse, amtliche Methodenhinweise und Berichtigungen. Bei aktiven Brandenburger Objektgemeinden prüfe die örtliche Veröffentlichung. Kein Übertragen Berliner Tabellen auf andere Gemeinden.

3. MARKTDATEN
Prüfe neue IBB-/Kommunalberichte und ihre Mietbegriffe, Beobachtungsjahre und Raumzuschnitte. Führe Mittelwert, Median und veröffentlichte Spannen getrennt; erfinde kein Minimum/Maximum aus einer 80-%-Spanne. Alte Jahresdaten behalten ihr Bezugsjahr, auch wenn heute erfolgreich neu abgerufen.

Für jede aktive Objekt-ID mit zugänglichem Suchprofil: öffne geeignete neue/geänderte Angebote einzeln, dokumentiere IDs/Preise/Flächen/Merkmale und bereinige Dubletten. Ziel 8-20 geeignete Fälle, soweit vorhanden. Ein verschwundenes Angebot ist kein nachgewiesener Abschluss. Berechne Min/Max, Durchschnitt, Median und P25/P75 aus derselben passenden Stichprobe. Vermische keine Häuser, Wohnungen, Möblierungs- oder Bindungssegmente.

Prüfe Kohortenveränderungen: Ein anderer Median durch andere angebotene Objekte ist nicht automatisch echte Mietpreissteigerung. Zeige Stichtagsvergleich und Zusammensetzungsänderung getrennt. Ist eine Quelle nicht erreichbar, markiere den Datensatz als unbestätigt/veraltet statt einen neuen Wert zu erfinden.

4. INDEX
Prüfe neu veröffentlichte endgültige VPI-Monatswerte bei Destatis. Speichere Reihe, Referenzmonat, Basisjahr und Veröffentlichung. Vermische keine Indexbasen und setze keine monatliche Veröffentlichung mit einer 14-tägigen Änderung gleich.

5. GESETZGEBUNGSSTATUS
Trenne geltendes Recht, verkündete zukünftige Regelung, parlamentarischen Entwurf und bloße Ankündigung. Insbesondere Änderungen zu Möblierung, vorübergehendem Gebrauch, Indexmiete und Modernisierung erst nach Prüfung von Verkündung, Inkrafttreten und Übergangsrecht aktivieren. Pressemeldungen allein ersetzen keinen Normnachweis.

6. ÄNDERUNGSPRÜFUNG
Vergleiche gegen die letzte erfolgreiche Baseline. Pro Änderung: alte/neue Quelle, Datum, relevante Passage/Fundstelle, Inhalt, gültig ab/bis, räumlicher Bereich, betroffene Regel-/Objekt-IDs und erwartete Euro-/Terminwirkung, soweit berechenbar. Roh- und bereinigte Marktdaten versionieren. Rechtliche Regeländerungen zunächst als Vorschlag mit fachlichem Prüfbedarf speichern. Keine unbemerkte Überschreibung alter rechtlich geprüfter Berichte.

7. KONTROLLEN
Rechne die Referenzfälle für Mietspiegel, Mietpreisbremse, §558-Restspielraum, Index, §559, §559c und Heizung erneut. Prüfe Gemeindezuordnung, Wirkungsdaten, Doppelzählung, Kostenabzüge, Nachweispflichten und Rundung. Scheitert eine Prüfung, aktiviere kein neues Rechenpaket. Bewahre den letzten gültigen Stand und kennzeichne betroffene Neuberechnungen.

8. AUSGABE
Liefere einen kompakten Updatebericht:
- Recherchestichtag und letzter Vergleichsstand;
- wesentliche Änderungen und Folgen für Pauls Objekte;
- unveränderte, erfolgreich geprüfte Grundlagen;
- Datenlücken/fehlgeschlagene Abrufe;
- neue Werte nur mit Einheit, Bezugszeitraum und Quelle;
- nächste fachliche Schritte und nächster vorgesehener Lauf.

Erzeuge außerdem update.json mit:
run_id, observed_at, baseline_id, baseline_missing, source_checks[], law_changes[], market_changes[], index_changes[], affected_objects[], calculations[], pending_reviews[], failures[], status.

Ein source_check enthält url, source_id, retrieved_at, publication_date, content_hash, check_status und change_status. check_status unterscheidet success, failed und access_required. change_status unterscheidet unchanged, changed und unknown. „Keine Änderung“ ist nur bei erfolgreichem Vergleich erlaubt.

Ausgaben werden als neue Versionen/Reports nach vorhandener Jarvis-Ablagelogik gespeichert. Bei bloßem Chat-Zugriff erstelle den Bericht und das importierbare Updatepaket; behaupte keinen Jarvis-Zugriff. Unaufgeforderte Nachrichten an Dritte, kostenpflichtige Abrufe oder neue Berechtigungen sind nicht Bestandteil dieses Laufs.
```

## Ausführung auf dem Jarvis-Server

Empfohlener Beginn: Montag, 30.11.2026, 09:00 Uhr Europe/Berlin, danach montags im Abstand von zwei Wochen. Bei einem eigenen Dienst wird dieser Kalendertermin als Anker gespeichert. Ein normaler Cron-Ausdruck für „jeden Montag“ setzt den Zweiwochenabstand allein nicht zuverlässig um.

| Einstellung | Sollverhalten |
|---|---|
| Zeitzone | Europe/Berlin; Sommer-/Winterzeit beachten |
| Wiederholung | FREQ=WEEKLY;INTERVAL=2;BYDAY=MO |
| Doppelstarts | Eindeutiger Lauf-Key aus Modul, geplantem lokalen Termin und Quellenbereich |
| Fehler | Begrenzte Wiederholung mit Abstand; letzter gültiger Stand bleibt verfügbar |
| Vollausfall | Fehlermeldung im eigenen Dashboard, keine Erfolgsmeldung |
| Keine Änderungen | Kurzer erfolgreicher Prüfvermerk mit Datenstichtagen |
| Quellenwechsel | Neue Version, Herkunft und Einfluss auf Vergleichbarkeit sichtbar |
| Regeländerung | Fachliche Prüfung vor Produktivaktivierung |

Ein Serverdienst, API-Zugänge und ein funktionierender Import sind Entwicklungsschritte aus dem Umsetzungsprompt. Die separat eingerichtete Chat-Aufgabe erstellt die wiederkehrende Informationsausgabe.
