// ═══ MaklerCockpit v26 – Zwei Felder: Objekte, die ich betreue · Akquise-Objekte ═══
// Jedes Objekt hat einen Bereich: „betreut“ (Auftrag, online, verkauft/vermietet) oder „akquise“ (Lead).
// Wird aus einem Akquise-Objekt ein Auftrag, wandert es automatisch zu „betreut“. Von Hand gesetzte Bereiche bleiben.
const OB26_BETREUT_STATUS = ['auftrag', 'online', 'abgeschlossen'];
const OB26 = { aktiv: 'betreut', filterGesetzt: false };
function ob26Bereich(o){ return o && (o.bereich === 'betreut' || o.bereich === 'akquise') ? o.bereich : (OB26_BETREUT_STATUS.includes(o && o.status) ? 'betreut' : 'akquise'); }
function ob26Esc(s){ return typeof esc === 'function' ? esc(s) : String(s == null ? '' : s); }
// Bereich vergeben/nachziehen (beim Start und vor jedem Speichern)
let OB26_GEWANDERT = [];
function ob26Pruefen(){
  let n = 0;
  for(const o of db.objekte || []){
    if(o.bereich !== 'betreut' && o.bereich !== 'akquise'){ o.bereich = ob26Bereich(o); n++; continue; }
    if(o.bereich === 'akquise' && OB26_BETREUT_STATUS.includes(o.status) && !o.bereichFest){
      o.bereich = 'betreut'; o.bereichSeit = Date.now(); n++;
      OB26_GEWANDERT.push(o);
      try{ if(typeof aqLog === 'function') aqLog(o, 'status', 'Zu „Objekte, die ich betreue“ verschoben (Auftrag)'); }catch(e){}
    }
  }
  return n;
}
const _ob26Schreibe = _schreibe;
_schreibe = function(){
  let n = 0; try{ n = ob26Pruefen(); }catch(e){}
  const r = _ob26Schreibe.apply(this, arguments);
  if(OB26_GEWANDERT.length){
    const l = OB26_GEWANDERT.splice(0);
    setTimeout(() => { try{ akqToast(`🏠 ${l.length === 1 ? '„' + (typeof mc24Titel === 'function' ? mc24Titel(l[0]) : (l[0].adresse || 'Objekt')) + '“ ist' : l.length + ' Objekte sind'} jetzt bei „Objekte, die ich betreue“`, 4500); if(aktuelleAnsicht === 'objekte' && !document.getElementById('modalBg').classList.contains('show')) renderMain(); }catch(e){} }, 0);
  }
  return r;
};
window.addEventListener('load', () => { try{ if(ob26Pruefen()) save(); }catch(e){} });

// ── Objekte-Seite: zwei Felder ──
function ob26Zahlen(){
  const l = db.objekte || [];
  const b = l.filter(o => ob26Bereich(o) === 'betreut'), a = l.filter(o => ob26Bereich(o) === 'akquise');
  const termin = typeof objHatTermin === 'function' ? a.filter(o => objHatTermin(o)).length : 0;
  const zaehl = (liste, st) => liste.filter(o => o.status === st).length;
  return { b: b.length, a: a.length, auftrag: zaehl(b, 'auftrag'), online: zaehl(b, 'online'), fertig: zaehl(b, 'abgeschlossen'), termin };
}
function ob26FelderHtml(){
  const z = ob26Zahlen();
  const feld = (k, ic, titel, unter) => `<button class="ob26-feld ${OB26.aktiv === k ? 'aktiv' : ''}" onclick="ob26Wechseln('${k}')"><span class="ob26-ic">${ic}</span><span class="ob26-t"><b>${titel}</b><small>${unter}</small></span><span class="ob26-n">${k === 'betreut' ? z.b : z.a}</span></button>`;
  return `<div class="ob26-felder">
    ${feld('betreut', '🏠', 'Objekte, die ich betreue', `${z.auftrag} im Auftrag · ${z.online} online · ${z.fertig} verkauft/vermietet`)}
    ${feld('akquise', '🎯', 'Akquise-Objekte', `${z.termin} mit Termin · ${z.a - z.termin} ohne Termin`)}
  </div>`;
}
function ob26Wechseln(k){ OB26.aktiv = k === 'akquise' ? 'akquise' : 'betreut'; renderMain(); }
const _ob26Sichtbar = typeof objSichtbar === 'function' ? objSichtbar : (() => true);
objSichtbar = function(o){
  if(ob26Bereich(o) !== OB26.aktiv) return false;
  return OB26.aktiv === 'betreut' ? true : _ob26Sichtbar(o);
};
const _ob26RenderObjekte = renderObjekte;
renderObjekte = function(main){
  if(!OB26.filterGesetzt && typeof X20 !== 'undefined'){ X20.objFilter = 'alle'; OB26.filterGesetzt = true; }
  const r = _ob26RenderObjekte.apply(this, arguments);
  try{
    const h1 = main.querySelector('h1'), sub = main.querySelector('.sub');
    if(sub) sub.textContent = OB26.aktiv === 'betreut' ? 'Deine Aufträge: im Auftrag, online, verkauft/vermietet' : 'Leads aus der Akquise – mit und ohne Termin';
    if(h1) h1.insertAdjacentHTML('afterend', ob26FelderHtml());
    const ft = document.getElementById('objFilterTermin'); if(ft) ft.style.display = OB26.aktiv === 'betreut' ? 'none' : '';
    const fs = document.getElementById('objFilterStatus');
    if(fs){ Array.from(fs.options).forEach(op => { if(op.value !== 'alle') op.hidden = (OB26_BETREUT_STATUS.includes(op.value) ? 'betreut' : 'akquise') !== OB26.aktiv && !(OB26.aktiv === 'akquise' && op.value === 'auftrag'); }); }
    const neu = Array.from(main.querySelectorAll('.toolbar button')).find(b => /Neues Objekt/.test(b.textContent));
    if(neu) neu.textContent = OB26.aktiv === 'betreut' ? '+ Neues betreutes Objekt' : '+ Neues Akquise-Objekt';
    const ex = Array.from(main.querySelectorAll('.toolbar button')).find(b => /Exposé/.test(b.textContent));
    if(ex){ ex.textContent = '📄 Aus Exposé(s) erstellen'; ex.title = OB26.aktiv === 'betreut' ? 'Eigene Exposés (PDF) einlesen → landen bei „Objekte, die ich betreue“' : 'Exposés (PDF) einlesen → landen als Akquise-Objekte'; }
    renderObjekteTabelle();
  }catch(e){ console.error('ob26', e); }
  return r;
};
const _ob26Tabelle = renderObjekteTabelle;
renderObjekteTabelle = function(){
  const r = _ob26Tabelle.apply(this, arguments);
  try{
    const el = document.getElementById('objTabelle'); if(!el) return r;
    el.querySelectorAll('.obj-filter-hinweis').forEach(x => x.remove());
    if(OB26.aktiv === 'akquise' && typeof X20 !== 'undefined' && X20.objFilter !== 'alle'){
      const weg = (db.objekte || []).filter(o => ob26Bereich(o) === 'akquise' && typeof objHatTermin === 'function' && !objHatTermin(o)).length;
      if(weg) el.insertAdjacentHTML('beforeend', `<div class="obj-filter-hinweis">${weg} Akquise-Lead${weg === 1 ? '' : 's'} ohne Termin ausgeblendet – <a href="#" onclick="objFilterSetzen('alle');return false;">alle zeigen</a></div>`);
    }
    if(!el.querySelector('tbody tr') && !el.querySelector('.ob26-leer')){
      el.insertAdjacentHTML('beforeend', `<div class="ob26-leer">${OB26.aktiv === 'betreut' ? 'Noch keine betreuten Objekte. Sobald ein Akquise-Objekt den Status „Auftrag erhalten“ bekommt, landet es hier – oder lege es direkt an bzw. lies dein Exposé ein.' : 'Keine Akquise-Objekte für diesen Filter.'}</div>`);
    }
  }catch(e){}
  return r;
};

// ── Objekt-Dialog: Bereich wählen ──
const _ob26Modal = oeffneObjektModal;
oeffneObjektModal = function(id){
  const r = _ob26Modal.apply(this, arguments);
  try{
    const o = id ? findObjekt(id) : null;
    const bereich = o ? ob26Bereich(o) : (aktuelleAnsicht === 'objekte' ? OB26.aktiv : 'akquise');
    const adr = document.getElementById('m_adresse'), formular = adr ? adr.closest('#modalInner > div') : null;
    const h3 = document.querySelector('#modalInner h3');
    if((formular || h3) && !document.getElementById('ob26Bereich')){
      (formular || h3).insertAdjacentHTML(formular ? 'beforebegin' : 'afterend', `<div class="ob26-wahl" id="ob26Bereich" data-wert="${bereich}" data-start="${bereich}">
        <button type="button" class="${bereich === 'betreut' ? 'aktiv' : ''}" onclick="ob26WahlSetzen('betreut')">🏠 Von mir betreut</button>
        <button type="button" class="${bereich === 'akquise' ? 'aktiv' : ''}" onclick="ob26WahlSetzen('akquise')">🎯 Akquise</button></div>`);
    }
    if(!o && bereich === 'betreut'){ const st = document.getElementById('m_status'); if(st && st.value !== 'auftrag' && Array.from(st.options).some(x => x.value === 'auftrag')) st.value = 'auftrag'; }
  }catch(e){ console.error('ob26 modal', e); }
  return r;
};
function ob26WahlSetzen(k){
  const w = document.getElementById('ob26Bereich'); if(!w) return;
  w.dataset.wert = k; w.querySelectorAll('button').forEach(b => b.classList.toggle('aktiv', (k === 'betreut') === /betreut/.test(b.textContent)));
  const st = document.getElementById('m_status');
  if(st && k === 'betreut' && !OB26_BETREUT_STATUS.includes(st.value)) st.value = 'auftrag';
}
const _ob26Speichere = speichereObjekt;
speichereObjekt = function(id){
  const w = document.getElementById('ob26Bereich');
  const wahl = w ? w.dataset.wert : null, start = w ? w.dataset.start : null;
  const vorher = new Set((db.objekte || []).map(o => o.id));
  const r = _ob26Speichere.apply(this, arguments);
  try{
    const o = id ? findObjekt(id) : (db.objekte || []).find(x => !vorher.has(x.id));
    if(o && wahl){
      if(!id){ o.bereich = wahl; if(wahl === 'betreut') o.herkunftBereich = 'direkt'; }
      else if(wahl !== start){ o.bereich = wahl; o.bereichFest = true; o.bereichSeit = Date.now(); }
      if(wahl === 'akquise' && OB26_BETREUT_STATUS.includes(o.status) && wahl !== start) o.bereichFest = true;
      save(); if(aktuelleAnsicht === 'objekte') renderMain();
    }
  }catch(e){ console.error('ob26 speichern', e); }
  return r;
};
// Akquise-Liste: direkt als „betreut“ angelegte Objekte (z. B. eigene Exposés) gehören nicht in die Akquise
if(typeof aqGefiltert === 'function'){
  const _ob26Gef = aqGefiltert;
  aqGefiltert = function(){ return _ob26Gef.apply(this, arguments).filter(o => !(o.herkunftBereich === 'direkt' && ob26Bereich(o) === 'betreut')); };
}

// ── Exposé lesen: Adresse auch mit „Adresse:/Lage:“-Zeile und mehr Straßenarten, Zimmer als Feld ──
if(typeof parseExposeText === 'function'){
  const _ob26Parse = parseExposeText;
  parseExposeText = function(text){
    const e = _ob26Parse.apply(this, arguments);
    try{
      const t = String(text || '');
      const zeile = t.match(/(?:Objekt-?)?(?:Adresse|Anschrift|Lage|Standort)\s*:?\s*([A-ZÄÖÜ][^\n,]{2,60}?\s\d{1,4}\s?[a-zA-Z]?)\s*,\s*(\d{5})\s+([A-ZÄÖÜ][\wäöüß\- ]{2,40})/);
      const strasse = /([A-ZÄÖÜ][a-zäöüßA-ZÄÖÜ.\-]+(?:\s[A-ZÄÖÜa-zäöüß.\-]+){0,2}\s?(?:straße|strasse|str\.|weg|allee|platz|gasse|damm|ring|park|chaussee|ufer|steig|pfad|markt|hof|zeile|promenade|berg|feld|garten|aue|grund|winkel|siedlung|anger|heide|steg)\s?\d{1,4}\s?[a-zA-Z]?)\b/;
      if(zeile){
        if(!e.adresse || /^Expose|\.pdf$/i.test(e.adresse)) e.adresse = zeile[1].trim();
        if(!e.ort) e.ort = zeile[2] + ' ' + zeile[3].trim().split(/\s{2,}|\n/)[0];
      } else if(!e.adresse){ const m = t.match(strasse); if(m) e.adresse = m[1].trim(); }
      if(!e.zimmer || !/^\d{1,2}([.,]5)?$/.test(String(e.zimmer).trim())){
        const z = t.match(/Zimmer(?:anzahl)?\s*:?\s*(\d{1,2}(?:[.,]5)?)\b/i) || t.match(/\b(\d{1,2}(?:[.,]5)?)\s*-?\s*Zimmer/i);
        if(z) e.zimmer = z[1]; else delete e.zimmer;
      }
      if(e.ort) e.ort = String(e.ort).replace(/\s+(Objektart|Objekttyp|Objekt|Kaufpreis|Preis|Wohnfläche|Grundstück\w*|Zimmer|Baujahr|Etage|Lage|Adresse|Heiz\w*|Provision|Energie\w*|Zustand|Ausstattung|Beschreibung|Referenz\S*|Kontakt|Telefon)\b.*$/i, '').trim();
      if(!e.objektart || e.objektart === 'Sonstiges'){
        const art = /einfamilienhaus|\bEFH\b/i.test(t) ? 'EFH' : /doppelhaush/i.test(t) ? 'DHH' : /reihen(?:end|mittel)?haus/i.test(t) ? 'Reihenhaus' : /mehrfamilienhaus|\bMFH\b/i.test(t) ? 'MFH' : /grundstück|bauland/i.test(t) && !/wohnfläche/i.test(t) ? 'Grundstück' : /wohnung|etagenwohnung|apartment|penthouse|maisonette/i.test(t) ? 'Wohnung' : '';
        if(art) e.objektart = art;
      }
    }catch(err){}
    return e;
  };
}
// ── Exposé-Import: landet im gerade gewählten Feld ──
if(typeof exposesImportieren === 'function'){
  const _ob26Expose = exposesImportieren;
  exposesImportieren = async function(files){
    const ziel = aktuelleAnsicht === 'objekte' ? OB26.aktiv : 'akquise';
    const vorher = new Set((db.objekte || []).map(o => o.id));
    window.__exposeErgebnis = null;
    let r; try{ r = await _ob26Expose.apply(this, arguments); }catch(err){ console.error('Exposé-Import', err); }
    try{
      const neu = (db.objekte || []).filter(o => !vorher.has(o.id));
      for(const o of neu){
        const zm = String(o.notizen || '').match(/Zimmer:\s*(\d{1,2}(?:[.,]5)?)/); if(zm && !o.zimmer) o.zimmer = zm[1].replace(',', '.');
        o.bereich = ziel; o.quelle = o.quelle || 'Exposé';
        if(ziel === 'betreut'){
          o.herkunftBereich = 'direkt'; o.status = 'auftrag';
          // eigenes Exposé: dort steht der Makler, nicht der Eigentümer → Platzhalter entfernen
          if(/^Expose \d+$/.test(o.verkaeuferName || '')) o.verkaeuferName = '';
          if(/^Telefon \d+$/.test(o.verkaeuferTelefon || '')) o.verkaeuferTelefon = '';
          if(/^Email \d+$/.test(o.verkaeuferEmail || '')) o.verkaeuferEmail = '';
        }
      }
      save(); if(aktuelleAnsicht === 'objekte') renderMain();
      const erg = window.__exposeErgebnis || { erstellt: neu.length, fehler: 0 };
      const zeile = o => `<li><b>${ob26Esc(o.adresse || '–')}</b>${o.ort ? ', ' + ob26Esc(o.ort) : ''} · ${ob26Esc(o.objektart || '')}${o.kaufpreis ? ' · ' + Number(o.kaufpreis).toLocaleString('de-DE') + ' €' : ' · <span class="mc24-rot">Preis fehlt</span>'}${o.wohnflaeche ? ' · ' + o.wohnflaeche + ' m²' : ''}${o.grundstueck ? ' · Grundstück ' + o.grundstueck + ' m²' : ''}${o.baujahr ? ' · Bj. ' + o.baujahr : ''}</li>`;
      if(typeof mc24Modal === 'function') mc24Modal(`<h3>📄 ${neu.length} Objekt${neu.length === 1 ? '' : 'e'} aus Exposé${neu.length === 1 ? '' : 's'} angelegt</h3>
        <p>Abgelegt bei <b>${ziel === 'betreut' ? '🏠 Objekte, die ich betreue' : '🎯 Akquise-Objekte'}</b>.${ziel === 'betreut' ? ' Der Eigentümer steht nicht im Exposé – bitte im Objekt eintragen.' : ' Name/Telefon sind Platzhalter (Expose 1, Telefon 1 …) – bitte nachtragen.'}</p>
        <ul class="ob26-liste">${neu.map(zeile).join('')}</ul>
        ${erg.fehler ? `<div class="mc24-hinweis">${erg.fehler} Datei(en) konnten nicht gelesen werden.</div>` : ''}
        <p class="mc24-muted">Exposés sind sehr unterschiedlich aufgebaut – bitte die Werte kurz gegenprüfen (Klick aufs Objekt).</p>
        <div class="modal-actions"><span></span><div class="right"><button onclick="schliesseModal()">OK</button></div></div>`, 620);
    }catch(e){ console.error('ob26 exposé', e); }
    return r;
  };
}
// Objektakte: Bereich im Kopf anzeigen und umschalten
if(typeof MC24 !== 'undefined' && MC24.akte && Array.isArray(MC24.akte.knoepfe)){
  MC24.akte.knoepfe.push(o => `<button class="secondary" title="Bereich wechseln" onclick="ob26AkteWechseln('${o.id}')">${ob26Bereich(o) === 'betreut' ? '🏠 Betreut' : '🎯 Akquise'}</button>`);
}
function ob26AkteWechseln(id){
  const o = findObjekt(id); if(!o) return;
  o.bereich = ob26Bereich(o) === 'betreut' ? 'akquise' : 'betreut'; o.bereichFest = true; o.bereichSeit = Date.now();
  save(); renderMain(); akqToast(o.bereich === 'betreut' ? '🏠 Jetzt bei „Objekte, die ich betreue“' : '🎯 Jetzt bei den Akquise-Objekten');
}
