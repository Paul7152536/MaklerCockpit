// ═══ MaklerCockpit v31 – „Nachricht“ öffnet das Exposé nicht noch einmal ═══
// Das Cockpit merkt sich, welche Anzeigen du gerade geöffnet hast (Exposé-Knopf, „Alle öffnen“, Nachricht).
// Ist die Anzeige in den letzten 12 Stunden schon geöffnet worden, kopiert „Nachricht“ nur den Text – kein zweiter Tab.
const EX31_OFFEN = new Map();
const EX31_FRIST = 12 * 3600 * 1000;
function ex31Norm(u){ return String(u || '').trim().replace(/#.*$/, '').replace(/\/+$/, ''); }
function ex31Offen(u){ const t = EX31_OFFEN.get(ex31Norm(u)); return !!t && Date.now() - t < EX31_FRIST; }
(function(){
  const _open = window.open;
  window.open = function(url){
    try{ if(url && /^https?:/i.test(String(url))) EX31_OFFEN.set(ex31Norm(url), Date.now()); }catch(e){}
    return _open.apply(window, arguments);
  };
})();
function ex31Hinweis(o, art){
  if(ex31Offen(o.link)) return art === 'nachfassen' ? 'Nachfass-Text kopiert – die Anzeige ist schon offen, dort einfügen' : 'Nachricht kopiert – die Anzeige ist schon offen, dort einfügen und senden';
  return art === 'nachfassen' ? 'Nachfass-Text kopiert – Anzeige wird geöffnet, dort einfügen' : 'Nachricht kopiert – Anzeige wird geöffnet, dort einfügen und senden';
}
function ex31NochmalOeffnen(id){ const o = findObjekt(id); if(o && o.link){ EX31_OFFEN.delete(ex31Norm(o.link)); window.open(o.link, '_blank'); } }
const _ex31Senden = aq2Senden;
aq2Senden = function(){
  const o = findObjekt(AQ2.sel);
  const warOffen = !!(o && o.link && !aqMail(o) && ex31Offen(o.link));
  const r = _ex31Senden.apply(this, arguments);
  try{
    const erg = document.getElementById('dpErgebnis');
    if(warOffen && erg && !erg.querySelector('.ex31-nochmal')){
      erg.insertAdjacentHTML('beforeend', `<button class="secondary ex31-nochmal" onclick="ex31NochmalOeffnen('${o.id}')" title="Falls du den Tab schon geschlossen hast">Anzeige nicht mehr offen? Öffnen ↗</button>`);
    }
  }catch(e){}
  return r;
};
