/**
 * MaklerCockpit – Kalender-Brücke
 * Verbindet dein MaklerCockpit (PC-Programm) dauerhaft mit deinem Google Kalender.
 * Das Skript läuft nur in DEINEM Google-Konto. Den Schlüssel unten nicht weitergeben.
 */
const SCHLUESSEL = '%%SCHLUESSEL%%';
const API = 'https://www.googleapis.com/calendar/v3';

function doPost(e) {
  let a;
  try { a = JSON.parse(e.postData.contents); } catch (x) { return antwort_({ ok: false, status: 400, fehler: 'Ungültige Anfrage' }); }
  if (!a || a.key !== SCHLUESSEL) return antwort_({ ok: false, status: 403, code: 'schluessel', fehler: 'Falscher Schlüssel' });
  try {
    if (a.aktion === 'test') {
      const r = abruf_('GET', '/users/me/calendarList', { maxResults: 1 }, null);
      return antwort_({ ok: r.ok, status: r.status, data: r.data, email: CalendarApp.getDefaultCalendar().getId(), version: 1 });
    }
    const pfad = String(a.pfad || '');
    if (!/^\/(users\/me\/calendarList|calendars\/[^?#\s]+)$/.test(pfad)) return antwort_({ ok: false, status: 400, fehler: 'Pfad nicht erlaubt' });
    return antwort_(abruf_(String(a.methode || 'GET'), pfad, a.query || {}, a.body || null));
  } catch (x) {
    return antwort_({ ok: false, status: 0, fehler: String((x && x.message) || x) });
  }
}

function abruf_(methode, pfad, query, body) {
  const q = Object.keys(query)
    .filter(function (k) { return query[k] !== undefined && query[k] !== null && query[k] !== ''; })
    .map(function (k) { return [].concat(query[k]).map(function (v) { return encodeURIComponent(k) + '=' + encodeURIComponent(v); }).join('&'); })
    .join('&');
  const opt = { method: methode.toLowerCase(), headers: { Authorization: 'Bearer ' + ScriptApp.getOAuthToken() }, muteHttpExceptions: true };
  if (body) { opt.contentType = 'application/json'; opt.payload = JSON.stringify(body); }
  const r = UrlFetchApp.fetch(API + pfad + (q ? '?' + q : ''), opt);
  const st = r.getResponseCode();
  const txt = r.getContentText();
  let data = null;
  try { data = txt ? JSON.parse(txt) : null; } catch (x) {}
  return { ok: st >= 200 && st < 300, status: st, data: data };
}

function antwort_(o) {
  return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON);
}

function doGet() {
  return ContentService.createTextOutput('MaklerCockpit Kalender-Brücke läuft.');
}
