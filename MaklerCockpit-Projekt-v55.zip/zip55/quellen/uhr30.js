// ═══ MaklerCockpit v30 – Uhrzeit per Zifferblatt wählen (statt der Liste mit zwei Spalten) ═══
// Gilt für alle Uhrzeit-Felder im Cockpit (Termin, Lead-Termin, Abwesenheit …). Eintippen geht weiterhin.
// Stunden: außen 1–12, innen 13–24 (00). Danach Minuten in 5er-Schritten. Am Handy bleibt die Uhr von Android.
const UHR30 = { el: null, input: null, modus: 'h', h: null, m: null };
function uhr30Aktiv(){ return !(window.pc && window.pc.geraet === 'handy'); }
function uhr30Zwei(n){ return String(n).padStart(2, '0'); }
function uhr30Lesen(v){ const m = /^(\d{1,2}):(\d{2})/.exec(String(v || '')); return m ? { h: Math.min(23, +m[1]), m: Math.min(59, +m[2]) } : { h: null, m: null }; }
// Position einer Zahl auf dem Zifferblatt (0 = oben, im Uhrzeigersinn)
function uhr30Pos(schritt, von12, radius){ const w = (schritt / von12) * 2 * Math.PI - Math.PI / 2; return { x: 130 + radius * Math.cos(w), y: 130 + radius * Math.sin(w) }; }
function uhr30Html(){
  const { modus, h, m } = UHR30;
  let zahlen = '', zeiger = '';
  if(modus === 'h'){
    for(let i = 1; i <= 12; i++){ const p = uhr30Pos(i % 12, 12, 100); zahlen += `<div class="uhr30-z${h === i ? ' an' : ''}" style="left:${p.x}px;top:${p.y}px">${i}</div>`; }
    for(let i = 13; i <= 24; i++){ const wert = i % 24, p = uhr30Pos(i % 12, 12, 64); zahlen += `<div class="uhr30-z innen${h === wert ? ' an' : ''}" style="left:${p.x}px;top:${p.y}px">${wert === 0 ? '00' : wert}</div>`; }
    if(h != null){ const innen = h === 0 || h > 12; const p = uhr30Pos(h % 12, 12, innen ? 64 : 100); zeiger = uhr30Zeiger(p); }
  } else {
    for(let i = 0; i < 60; i += 5){ const p = uhr30Pos(i, 60, 100); zahlen += `<div class="uhr30-z${m === i ? ' an' : ''}" style="left:${p.x}px;top:${p.y}px">${uhr30Zwei(i)}</div>`; }
    if(m != null){ const p = uhr30Pos(m, 60, 100); zeiger = uhr30Zeiger(p) + (m % 5 ? `<div class="uhr30-punkt" style="left:${p.x}px;top:${p.y}px"></div>` : ''); }
  }
  return `<div class="uhr30-kopf"><button type="button" class="uhr30-anz${modus === 'h' ? ' an' : ''}" data-uhr="h">${h == null ? '--' : uhr30Zwei(h)}</button><span>:</span><button type="button" class="uhr30-anz${modus === 'm' ? ' an' : ''}" data-uhr="m">${m == null ? '--' : uhr30Zwei(m)}</button></div>
    <div class="uhr30-blatt" data-uhr="blatt"><div class="uhr30-mitte"></div>${zeiger}${zahlen}</div>
    <div class="uhr30-tipp">${modus === 'h' ? 'Stunde wählen – außen 1–12, innen 13–24' : 'Minuten wählen'}</div>
    <div class="uhr30-fuss"><button type="button" class="secondary" data-uhr="leer">Leeren</button><span></span><button type="button" class="secondary" data-uhr="ab">Abbrechen</button><button type="button" data-uhr="ok">OK</button></div>`;
}
function uhr30Zeiger(p){
  const dx = p.x - 130, dy = p.y - 130, l = Math.sqrt(dx * dx + dy * dy), w = Math.atan2(dy, dx) * 180 / Math.PI;
  return `<div class="uhr30-zeiger" style="width:${l}px;transform:rotate(${w}deg)"></div>`;
}
function uhr30Zeichnen(){ if(UHR30.el) UHR30.el.innerHTML = uhr30Html(); }
function uhr30Lage(){
  const e = UHR30.el, i = UHR30.input; if(!e || !i) return;
  if(!document.body.contains(i)){ uhr30Zu(); return; }
  const r = i.getBoundingClientRect(), b = e.offsetWidth || 292, hh = e.offsetHeight || 400;
  let top = r.bottom + 6; if(top + hh > innerHeight - 8) top = Math.max(8, r.top - hh - 6);
  let left = Math.min(Math.max(8, r.left), innerWidth - b - 8);
  e.style.top = Math.round(top) + 'px'; e.style.left = Math.round(left) + 'px';
}
function uhr30Auf(input){
  if(!uhr30Aktiv() || !input || input.disabled || input.readOnly) return;
  if(UHR30.input === input && UHR30.el) return;
  uhr30Zu();
  const v = uhr30Lesen(input.value);
  Object.assign(UHR30, { input, modus: 'h', h: v.h, m: v.m, start: input.value });
  const e = document.createElement('div'); e.className = 'uhr30'; e.id = 'uhr30';
  document.body.appendChild(e); UHR30.el = e; uhr30Zeichnen(); uhr30Lage();
  // Fokus bleibt im Feld (Eintippen geht weiter), Klicks im Zifferblatt stehlen ihn nicht
  e.addEventListener('mousedown', ev => { ev.preventDefault(); });
  e.addEventListener('pointerdown', uhr30Druck);
  e.addEventListener('click', uhr30Klick);
  clearInterval(UHR30.wacht);
  UHR30.wacht = setInterval(() => { const i = UHR30.input; if(!UHR30.el || !i || !document.body.contains(i) || !i.offsetParent){ clearInterval(UHR30.wacht); uhr30Zu(); } }, 400);
}
function uhr30Zu(){ if(UHR30.el){ UHR30.el.remove(); } UHR30.el = null; UHR30.input = null; }
function uhr30Setzen(fertig){
  const i = UHR30.input; if(!i) return;
  if(UHR30.h == null) return;
  const v = uhr30Zwei(UHR30.h) + ':' + uhr30Zwei(UHR30.m == null ? 0 : UHR30.m);
  if(i.value !== v){ i.value = v; i.dispatchEvent(new Event('input', { bubbles: true })); i.dispatchEvent(new Event('change', { bubbles: true })); }
  if(fertig) uhr30Zu();
}
// Zifferblatt: tippen oder ziehen
function uhr30Wert(ev){
  const blatt = UHR30.el && UHR30.el.querySelector('.uhr30-blatt'); if(!blatt) return null;
  const r = blatt.getBoundingClientRect(), dx = ev.clientX - r.left - 130, dy = ev.clientY - r.top - 130;
  const dist = Math.sqrt(dx * dx + dy * dy); if(dist < 18 || dist > 135) return null;
  let w = Math.atan2(dy, dx) + Math.PI / 2; if(w < 0) w += 2 * Math.PI;
  if(UHR30.modus === 'h'){ let s = Math.round(w / (2 * Math.PI) * 12) % 12; const innen = dist < 82; if(innen) return s === 0 ? 0 : s + 12; return s === 0 ? 12 : s; }
  return (Math.round(w / (2 * Math.PI) * 12) % 12) * 5;
}
function uhr30Druck(ev){
  if(!ev.target.closest('.uhr30-blatt')) return;
  ev.preventDefault();
  const anwenden = e2 => { const w = uhr30Wert(e2); if(w == null) return; if(UHR30.modus === 'h') UHR30.h = w; else UHR30.m = w; uhr30Zeichnen(); };
  anwenden(ev);
  const zieh = e2 => anwenden(e2);
  const los = e2 => {
    document.removeEventListener('pointermove', zieh); document.removeEventListener('pointerup', los);
    if(!UHR30.el) return;
    if(UHR30.modus === 'h' && UHR30.h != null){ if(UHR30.m == null) UHR30.m = 0; uhr30Setzen(false); UHR30.modus = 'm'; uhr30Zeichnen(); }
    else if(UHR30.modus === 'm' && UHR30.m != null){ uhr30Setzen(false); setTimeout(() => { if(UHR30.el) uhr30Zu(); }, 220); }
  };
  document.addEventListener('pointermove', zieh); document.addEventListener('pointerup', los);
}
function uhr30Klick(ev){
  const k = ev.target.closest('[data-uhr]'); if(!k) return;
  const a = k.dataset.uhr;
  if(a === 'h' || a === 'm'){ UHR30.modus = a; uhr30Zeichnen(); }
  else if(a === 'ok'){ uhr30Setzen(true); uhr30Zu(); }
  else if(a === 'ab'){ const i = UHR30.input; if(i && i.value !== UHR30.start){ i.value = UHR30.start; i.dispatchEvent(new Event('input', { bubbles: true })); i.dispatchEvent(new Event('change', { bubbles: true })); } uhr30Zu(); }
  else if(a === 'leer'){ const i = UHR30.input; if(i){ i.value = ''; i.dispatchEvent(new Event('input', { bubbles: true })); i.dispatchEvent(new Event('change', { bubbles: true })); } uhr30Zu(); }
}
// Öffnen beim Klick ins Uhrzeit-Feld; Eintippen aktualisiert das Zifferblatt
document.addEventListener('mousedown', ev => {
  const i = ev.target && ev.target.closest ? ev.target.closest('input[type="time"]') : null;
  if(i){ uhr30Auf(i); return; }
  if(UHR30.el && !ev.target.closest('.uhr30')) uhr30Zu();
}, true);
document.addEventListener('input', ev => {
  if(UHR30.el && ev.target === UHR30.input){ const v = uhr30Lesen(ev.target.value); UHR30.h = v.h; UHR30.m = v.m; uhr30Zeichnen(); }
}, true);
document.addEventListener('keydown', ev => {
  if(!UHR30.el) return;
  if(ev.key === 'Escape'){ ev.stopPropagation(); uhr30Zu(); }
  else if(ev.key === 'Enter' && ev.target === UHR30.input){ uhr30Zu(); }
  else if(ev.key === 'Tab') uhr30Zu();
}, true);
window.addEventListener('scroll', () => { if(UHR30.el) uhr30Lage(); }, true);
window.addEventListener('resize', () => { if(UHR30.el) uhr30Lage(); });
// am PC die alte Auswahlliste (zwei Spalten) ausblenden – das Zifferblatt ersetzt sie
window.addEventListener('load', () => { if(uhr30Aktiv()) document.documentElement.classList.add('uhr30-an'); });
