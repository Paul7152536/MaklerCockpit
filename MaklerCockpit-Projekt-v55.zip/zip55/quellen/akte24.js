/* MaklerCockpit v24 – Gemeinsame Datenbasis und zentrale Objektakte
   - Herkunft/Prüfstatus für wichtige Angaben (o.angaben), Widersprüche bleiben parallel erhalten
   - mehrere Kontakte je Objekt mit Rolle (o.kontakte), Organisationen + Ansprechpartner in den vorhandenen Kontakten
   - Objektakte mit Kontakten, Gesprächen, Aufgaben, Terminen, Unterlagen, Analysen, Investmentprüfungen
   - Löschen ohne unbemerkte verwaiste Verweise, idempotente Migration */

const MC24 = { akteId: null, zurueck: 'objekte', akte: { abschnitte: [], knoepfe: [] }, lead: { knoepfe: [] }, kontakt: { abschnitte: [] }, termin: { knoepfe: [] }, start: [] };

// ── Hilfen ──
function mc24E(s){ return typeof akqEsc === 'function' ? akqEsc(s) : String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]); }
function mc24N(v){ if(v === null || v === undefined || v === '') return null; const n = typeof v === 'number' ? v : Number(String(v).replace(/\s/g, '').replace(/\.(?=\d{3}(\D|$))/g, '').replace(',', '.')); return isFinite(n) ? n : null; }
function mc24Eur(n, d){ return n == null || !isFinite(n) ? '–' : Number(n).toLocaleString('de-DE', { minimumFractionDigits: d || 0, maximumFractionDigits: d || 0 }) + ' €'; }
function mc24Zahl(n, d){ return n == null || !isFinite(n) ? '–' : Number(n).toLocaleString('de-DE', { minimumFractionDigits: d || 0, maximumFractionDigits: d || 0 }); }
function mc24Pz(n, d){ return n == null || !isFinite(n) ? '–' : Number(n).toLocaleString('de-DE', { minimumFractionDigits: d == null ? 2 : d, maximumFractionDigits: d == null ? 2 : d }) + ' %'; }
function mc24Fmt(n){ return n == null || n === '' || !isFinite(n) ? '' : Number(n).toLocaleString('de-DE', { maximumFractionDigits: 2 }); }
function mc24Heute(){ return toDateKey(new Date()); }
function mc24Datum(x){ if(!x) return '–'; const s = typeof x === 'number' ? toDateKey(new Date(x)) : String(x).slice(0, 10); const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s); return m ? `${m[3]}.${m[2]}.${m[1]}` : mc24E(x); }
function mc24Modal(html, breite){
  const inner = document.getElementById('modalInner'); inner.innerHTML = html;
  inner.style.width = (breite || 720) + 'px'; inner.style.maxWidth = '96vw';
  document.getElementById('modalBg').classList.add('show');
  return inner;
}
function mc24Kopieren(text, meldung){
  const fertig = () => akqToast(meldung || '📋 Kopiert');
  try{ if(navigator.clipboard && navigator.clipboard.writeText){ navigator.clipboard.writeText(text).then(fertig, () => mc24KopierenAlt(text, fertig)); return; } }catch(e){}
  mc24KopierenAlt(text, fertig);
}
function mc24KopierenAlt(text, fertig){ const t = document.createElement('textarea'); t.value = text; t.style.position = 'fixed'; t.style.opacity = '0'; document.body.appendChild(t); t.select(); try{ document.execCommand('copy'); }catch(e){} t.remove(); fertig(); }
function mc24Titel(o){ return o ? (typeof aqTitel === 'function' ? aqTitel(o) : (o.akqTitel || o.adresse || o.objektart || 'Objekt')) : 'Objekt gelöscht'; }
function mc24OrtKurz(o){ return o ? (typeof aqOrtKurz === 'function' ? aqOrtKurz(o) : (o.ort || '')) : ''; }
function mc24SicherLink(u){ try{ const x = new URL(String(u || '')); return /^https?:$/.test(x.protocol) ? x.href : ''; }catch(e){ return ''; } }
function mc24LinkHtml(u, text){ const s = mc24SicherLink(u); return s ? `<a href="#" onclick="window.open(${mc24E(JSON.stringify(s))},'_blank');return false;">${mc24E(text || s)}</a>` : mc24E(text || u || ''); }

// PDF über den Hauptprozess (Chromium) erzeugen und mit „Speichern unter“ ablegen
async function mc24Pdf(html, name){
  if(!(window.pc && window.pc.htmlZuPdf)){
    const w = window.open('', '_blank'); if(w){ w.document.write(html); w.document.close(); w.print(); }
    return { ok: false, fehler: 'PDF nur in der PC-Version – Druckansicht geöffnet.' };
  }
  akqToast('📄 PDF wird erstellt …');
  const r = await window.pc.htmlZuPdf(html);
  if(!r || !r.ok){ akqToast('⚠️ PDF fehlgeschlagen: ' + ((r && r.fehler) || 'unbekannt')); return r || { ok: false }; }
  const s = await window.pc.dateiSpeichern(name, r.base64);
  if(s && s.ok){ akqToast('✅ PDF gespeichert: ' + s.name); try{ window.pc.dateiOeffnen(s.pfad, 'datei'); }catch(e){} }
  return s;
}
function mc24Drucken(html){
  const f = document.createElement('iframe'); f.style.position = 'fixed'; f.style.width = '0'; f.style.height = '0'; f.style.border = '0';
  document.body.appendChild(f); f.contentDocument.open(); f.contentDocument.write(html); f.contentDocument.close();
  setTimeout(() => { try{ f.contentWindow.focus(); f.contentWindow.print(); }catch(e){} setTimeout(() => f.remove(), 2000); }, 200);
}

// ── Module (abschaltbar) ──
function mc24Module(){ if(!db.module || typeof db.module !== 'object') db.module = {}; if(db.module.akquise24 === undefined) db.module.akquise24 = true; return db.module; }
function mc24ModulAn(k){ try{ return mc24Module()[k] !== false; }catch(e){ return true; } }

// ── Aufgaben (vorhandene Aufgabenverwaltung, ohne Dubletten) ──
function mc24AufgabeAnlegen(a){
  db.aufgaben = db.aufgaben || [];
  const gleich = db.aufgaben.find(x => x.status !== 'erledigt' && (x.titel || '') === (a.titel || '') && (x.objektId || null) === (a.objektId || null) && (x.kontaktId || null) === (a.kontaktId || null) && (x.typ || '') === (a.typ || ''));
  if(gleich){ if(a.faellig && (!gleich.faellig || a.faellig < gleich.faellig)) gleich.faellig = a.faellig; return gleich; }
  const neu = Object.assign({ id: uid(), createdAt: Date.now(), status: 'offen', prioritaet: 'mittel', notiz: '' }, a);
  db.aufgaben.push(neu);
  return neu;
}
function mc24AufgabeErledigt(id, an){ const a = (db.aufgaben || []).find(x => x.id === id); if(!a) return; a.status = an === false ? 'offen' : 'erledigt'; a.erledigtAm = an === false ? null : Date.now(); save(); }

// ── Angaben mit Herkunft ──
const AN24_FELDER = [
  { k: 'wohnflaeche', l: 'Wohnfläche', einheit: 'm²', typ: 'zahl', alt: 'wohnflaeche' },
  { k: 'nutzflaeche', l: 'Nutzfläche', einheit: 'm²', typ: 'zahl' },
  { k: 'grundstueck', l: 'Grundstücksfläche', einheit: 'm²', typ: 'zahl', alt: 'grundstueck' },
  { k: 'zimmer', l: 'Zimmer', typ: 'zahl', alt: 'zimmer' },
  { k: 'baujahr', l: 'Baujahr', typ: 'zahl', alt: 'baujahr' },
  { k: 'zustand', l: 'Zustand', typ: 'auswahl', optionen: [['neuwertig', 'neuwertig / Neubau'], ['saniert', 'saniert / modernisiert'], ['gepflegt', 'gepflegt'], ['renovierungsbeduerftig', 'renovierungsbedürftig'], ['sanierungsbeduerftig', 'sanierungsbedürftig']] },
  { k: 'kaufpreis', l: 'Preis (Vorstellung/Angebot)', einheit: '€', typ: 'zahl', alt: 'kaufpreis' },
  { k: 'miete_ist', l: 'Ist-Nettokaltmiete / Monat', einheit: '€', typ: 'zahl' },
  { k: 'hausgeld', l: 'Hausgeld gesamt / Monat', einheit: '€', typ: 'zahl' },
  { k: 'hausgeld_umlage', l: 'davon umlagefähig / Monat', einheit: '€', typ: 'zahl' },
  { k: 'ruecklage_zufuehrung', l: 'Rücklagenzuführung / Monat', einheit: '€', typ: 'zahl' },
  { k: 'ruecklage_stand', l: 'Erhaltungsrücklage (Stand)', einheit: '€', typ: 'zahl' },
  { k: 'modernisierung', l: 'Modernisierungen', typ: 'text' },
  { k: 'energie', l: 'Energie / Heizung', typ: 'text' },
  { k: 'vermietung', l: 'Vermietungsstatus', typ: 'auswahl', optionen: [['bezugsfrei', 'bezugsfrei'], ['vermietet', 'vermietet'], ['teilvermietet', 'teilvermietet'], ['eigengenutzt', 'eigengenutzt']] }
];
const AN24_HERKUNFT = [['belegt', 'belegt'], ['eigentuemer', 'Eigentümerangabe'], ['geschaetzt', 'geschätzt'], ['offen', 'Herkunft offen']];
const AN24_PRUEF = [['ungeprueft', 'ungeprüft'], ['geprueft', 'geprüft'], ['vorschlag', 'Vorschlag'], ['abgelehnt', 'verworfen']];
function an24Feld(k){ return AN24_FELDER.find(f => f.k === k); }
function an24L(liste, k){ const x = liste.find(y => y[0] === k); return x ? x[1] : (k || '–'); }
function an24Box(o, k){ if(!o.angaben || typeof o.angaben !== 'object') o.angaben = {}; if(!o.angaben[k]) o.angaben[k] = { werte: [], aktiv: null }; return o.angaben[k]; }
function an24Aktiv(o, k){ const b = o && o.angaben && o.angaben[k]; return b && b.aktiv ? (b.werte.find(w => w.id === b.aktiv) || null) : null; }
function an24Wert(o, k){
  const a = an24Aktiv(o, k); if(a) return a.wert;
  const f = an24Feld(k); if(f && f.alt && o && o[f.alt] !== undefined && o[f.alt] !== null && o[f.alt] !== '') return f.typ === 'zahl' ? mc24N(o[f.alt]) : o[f.alt];
  return null;
}
function an24Norm(f, w){ if(w == null || w === '') return null; if(f && f.typ === 'zahl'){ const n = mc24N(w); return n == null ? null : Math.round(n * 100) / 100; } return String(w).trim().toLowerCase(); }
function an24Setzen(o, k, eintrag, opt){
  opt = opt || {};
  const f = an24Feld(k), box = an24Box(o, k);
  const w = Object.assign({ id: uid(), herkunft: 'offen', quelle: '', dokId: null, erfasst: mc24Heute(), erfasstZeit: new Date().toISOString(), bezug: '', pruef: 'ungeprueft', notiz: '', von: 'manuell' }, eintrag);
  w.wert = f && f.typ === 'zahl' ? mc24N(w.wert) : (w.wert == null ? null : String(w.wert));
  // gleicher Wert gleicher Herkunft schon vorhanden → nicht doppelt anlegen
  const dop = box.werte.find(x => an24Norm(f, x.wert) === an24Norm(f, w.wert) && x.herkunft === w.herkunft && (x.quelle || '') === (w.quelle || '') && x.von === w.von);
  if(dop){ if(opt.aktivieren && box.aktiv !== dop.id) an24Aktivieren(o, k, dop.id); return dop; }
  box.werte.push(w);
  if(opt.aktivieren || (!box.aktiv && opt.aktivierenWennLeer)) an24Aktivieren(o, k, w.id, opt.entscheidung);
  return w;
}
function an24Aktivieren(o, k, id, entscheidung){
  const f = an24Feld(k), box = an24Box(o, k), w = box.werte.find(x => x.id === id); if(!w) return;
  box.aktiv = id;
  if(w.pruef === 'vorschlag') w.pruef = 'ungeprueft';
  if(f && f.alt) o[f.alt] = w.wert == null ? '' : (f.typ === 'zahl' ? w.wert : w.wert);
  if(entscheidung) box.entscheidung = { wertId: id, text: entscheidung, am: new Date().toISOString() };
}
// Widersprüche: mehrere unterschiedliche, nicht verworfene Werte ohne dokumentierte Entscheidung danach
function an24Konflikte(o){
  const l = [];
  for(const f of AN24_FELDER){
    const box = o && o.angaben && o.angaben[f.k]; if(!box || box.werte.length < 2) continue;
    const gueltig = box.werte.filter(w => w.pruef !== 'abgelehnt' && w.wert != null && w.wert !== '');
    const verschieden = [...new Set(gueltig.map(w => an24Norm(f, w.wert)))];
    if(verschieden.length < 2) continue;
    const letzte = Math.max(...gueltig.map(w => Date.parse(w.erfasstZeit || w.erfasst) || 0));
    if(box.entscheidung && Date.parse(box.entscheidung.am) >= letzte) continue;
    l.push({ feld: f, werte: gueltig, aktiv: box.aktiv });
  }
  return l;
}
function an24Wtext(f, w){ if(w == null || w === '') return 'unbekannt'; if(f.typ === 'auswahl') return an24L(f.optionen, w); if(f.typ === 'zahl') return f.k === 'baujahr' ? String(Math.round(w)) : f.einheit === '€' ? mc24Eur(w) : mc24Zahl(w, 2).replace(/,00$/, '') + (f.einheit ? ' ' + f.einheit : ''); return String(w); }

// ── Kontakte je Objekt, Organisationen ──
const MC24_ROLLEN = [['eigentuemer', 'Eigentümer/in'], ['miteigentuemer', 'Miteigentümer/in'], ['entscheider', 'Entscheider/in'], ['ansprechpartner', 'Ansprechpartner/in'], ['bevollmaechtigt', 'Bevollmächtigte/r'], ['hausverwaltung', 'Hausverwaltung'], ['mieter', 'Mieter/in'], ['sonstige', 'Sonstige']];
function ob24Kontakte(o){ return (o && o.kontakte || []).map(x => ({ k: findKontakt(x.kontaktId), rolle: x.rolle, kontaktId: x.kontaktId })).filter(x => x.k); }
function ob24KontaktVerknuepfen(o, kontaktId, rolle){
  if(!o || !kontaktId) return;
  if(!Array.isArray(o.kontakte)) o.kontakte = [];
  const v = o.kontakte.find(x => x.kontaktId === kontaktId);
  if(v){ if(rolle) v.rolle = rolle; } else o.kontakte.push({ kontaktId, rolle: rolle || 'ansprechpartner' });
  if((rolle === 'eigentuemer') && !o.eigentuemerId) o.eigentuemerId = kontaktId;
}
function ob24KontaktLoesen(o, kontaktId){
  o.kontakte = (o.kontakte || []).filter(x => x.kontaktId !== kontaktId);
  if(o.eigentuemerId === kontaktId) o.eigentuemerId = ((o.kontakte || []).find(x => x.rolle === 'eigentuemer') || {}).kontaktId || null;
}
function ob24ObjekteVonKontakt(kid){ return (db.objekte || []).filter(o => o.eigentuemerId === kid || (o.kontakte || []).some(x => x.kontaktId === kid)); }
function mc24Organisationen(){ return (db.kontakte || []).filter(k => k.organisation); }
function mc24Ansprechpartner(orgId){ return (db.kontakte || []).filter(k => k.orgId === orgId); }
function mc24Kontaktstopp(k){ return !!(k && k.kontaktstopp && k.kontaktstopp.aktiv) || !!(k && k.orgId && mc24Kontaktstopp(findKontakt(k.orgId))); }
// Hauptkontakt eines Objekts (Eigentümer, sonst erster verknüpfter); legt bei Bedarf den Verkäufer-Kontakt aus den Lead-Daten an
function ob24Hauptkontakt(o, anlegen){
  if(!o) return null;
  let k = o.eigentuemerId ? findKontakt(o.eigentuemerId) : null;
  if(!k){ const x = ob24Kontakte(o)[0]; if(x) k = x.k; }
  if(!k && anlegen){
    if(typeof erstelleVerkaeuferKontaktFallsNoetig === 'function') erstelleVerkaeuferKontaktFallsNoetig(o);
    if(!o.eigentuemerId){
      const neu = { id: uid(), createdAt: Date.now(), name: o.verkaeuferName || 'Eigentümer/in (' + mc24Titel(o).slice(0, 30) + ')', telefon: o.verkaeuferTelefon || '', email: o.verkaeuferEmail || '', adresse: '', kontaktart: 'eigentuemer', quelle: o.quelle || 'Sonstiges', status: 'lead', prioritaet: 'mittel', notizen: '' };
      db.kontakte.push(neu); o.eigentuemerId = neu.id;
    }
    k = findKontakt(o.eigentuemerId);
    if(k) ob24KontaktVerknuepfen(o, k.id, 'eigentuemer');
  }
  return k;
}

// ── Migration (idempotent; zweimal ausführen ändert nichts) ──
function mc24Migrieren(){
  const vorher = JSON.stringify(db);
  ['objekte', 'kontakte', 'aufgaben', 'termine', 'notizen', 'marktanalysen'].forEach(k => { if(!Array.isArray(db[k])) db[k] = []; });
  if(!Array.isArray(db.analysen24)) db.analysen24 = [];
  if(!db.invest24 || typeof db.invest24 !== 'object') db.invest24 = {};
  if(!Array.isArray(db.invest24.profile)) db.invest24.profile = [];
  if(!Array.isArray(db.invest24.pruefungen)) db.invest24.pruefungen = [];
  mc24Module();
  for(const o of db.objekte){
    if(!Array.isArray(o.kontakte)) o.kontakte = [];
    if(o.eigentuemerId && findKontakt(o.eigentuemerId) && !o.kontakte.some(x => x.kontaktId === o.eigentuemerId)) o.kontakte.push({ kontaktId: o.eigentuemerId, rolle: 'eigentuemer' });
    o.kontakte = o.kontakte.filter(x => x && findKontakt(x.kontaktId));
    if(!o.angaben || typeof o.angaben !== 'object') o.angaben = {};
    for(const f of AN24_FELDER){
      if(!f.alt || o.angaben[f.k]) continue;
      const v = o[f.alt]; if(v === undefined || v === null || v === '') continue;
      const wert = f.typ === 'zahl' ? mc24N(v) : v; if(wert == null) continue;
      const id = 'b' + o.id + '_' + f.k;   // feste ID → wiederholte Migration erzeugt nichts Neues
      o.angaben[f.k] = { werte: [{ id, wert, herkunft: 'offen', quelle: 'Bestand vor v24', dokId: null, erfasst: o.createdAt ? toDateKey(new Date(o.createdAt)) : '', bezug: '', pruef: 'ungeprueft', notiz: '', von: 'bestand' }], aktiv: id };
    }
  }
  if(!db.meta || typeof db.meta !== 'object') db.meta = {};
  if(!db.meta.schema24) db.meta.schema24 = { version: 1, am: new Date().toISOString() };
  const geaendert = JSON.stringify(db) !== vorher;
  if(geaendert) save();
  return geaendert;
}

// ── Prüfung der Verweise (für Tests und den Abschnitt „Datenstand“) ──
function mc24Verweise(){
  const ob = new Set((db.objekte || []).map(o => o.id)), ko = new Set((db.kontakte || []).map(k => k.id)), l = [];
  (db.objekte || []).forEach(o => (o.kontakte || []).forEach(x => { if(!ko.has(x.kontaktId)) l.push('Objekt ' + o.id + ' → Kontakt ' + x.kontaktId); }));
  (db.analysen24 || []).forEach(a => { if(a.objektId && !ob.has(a.objektId) && !a.objektGeloescht) l.push('Analyse ' + a.id + ' → Objekt ' + a.objektId); });
  ((db.invest24 || {}).pruefungen || []).forEach(p => { if(p.objektId && !ob.has(p.objektId) && !p.objektGeloescht) l.push('Investment ' + p.id + ' → Objekt ' + p.objektId); });
  (db.aufgaben || []).forEach(a => { if(a.objektId && !ob.has(a.objektId)) l.push('Aufgabe ' + a.id + ' → Objekt'); if(a.kontaktId && !ko.has(a.kontaktId)) l.push('Aufgabe ' + a.id + ' → Kontakt'); });
  (db.notizen || []).forEach(n => { if(n.objektId && !ob.has(n.objektId)) l.push('Notiz ' + n.id + ' → Objekt'); if(n.kontaktId && !ko.has(n.kontaktId)) l.push('Notiz ' + n.id + ' → Kontakt'); });
  (db.kontakte || []).forEach(k => { if(k.orgId && !ko.has(k.orgId)) l.push('Kontakt ' + k.id + ' → Organisation'); });
  return l;
}
function mc24ObjektBezug(id){
  return {
    analysen: (db.analysen24 || []).filter(a => a.objektId === id && !a.objektGeloescht),
    invest: ((db.invest24 || {}).pruefungen || []).filter(p => p.objektId === id && !p.objektGeloescht),
    gespraeche: (db.notizen || []).filter(n => n.objektId === id),
    aufgaben: (db.aufgaben || []).filter(a => a.objektId === id),
    termine: (db.termine || []).filter(t => t.objektId === id)
  };
}
// Alle Löschwege laufen über objektVerknuepfungenAufraeumen → Analysen/Investments werden archiviert (sichtbar markiert), nicht verwaist
const _mc24ObjAufr = objektVerknuepfungenAufraeumen;
objektVerknuepfungenAufraeumen = function(objektId){
  const o = findObjekt(objektId), schnapp = { titel: mc24Titel(o), ort: o ? (o.ort || '') : '', am: new Date().toISOString() };
  (db.analysen24 || []).forEach(a => { if(a.objektId === objektId) a.objektGeloescht = schnapp; });
  ((db.invest24 || {}).pruefungen || []).forEach(p => { if(p.objektId === objektId) p.objektGeloescht = schnapp; });
  (db.notizen || []).forEach(n => { if(n.objektId === objektId){ n.objektId = null; n.objektTitel = schnapp.titel; } });
  return _mc24ObjAufr.apply(this, arguments);
};
const _mc24KonAufr = kontaktVerknuepfungenAufraeumen;
kontaktVerknuepfungenAufraeumen = function(kontaktId){
  (db.objekte || []).forEach(o => { if((o.kontakte || []).some(x => x.kontaktId === kontaktId)) ob24KontaktLoesen(o, kontaktId); });
  (db.kontakte || []).forEach(k => { if(k.orgId === kontaktId) k.orgId = null; });
  (db.notizen || []).forEach(n => { if(n.kontaktId === kontaktId){ n.kontaktId = null; } });
  return _mc24KonAufr.apply(this, arguments);
};
// Verkäufer-Kontakt nur mitlöschen, wenn an ihm nichts hängt (Gespräche, Einwände, Kontaktstopp, weitere Objekte, Organisation)
function mc24KontaktHatHistorie(kid){
  const k = findKontakt(kid); if(!k) return false;
  return !!((k.einwaende || []).length || k.kontaktstopp || k.organisation || k.orgId || k.koop || (db.notizen || []).some(n => n.kontaktId === kid) || (db.objekte || []).some(o => (o.kontakte || []).some(x => x.kontaktId === kid)));
}
const _mc24EigMit = eigentuemerMitloeschenFallsVerwaist;
eigentuemerMitloeschenFallsVerwaist = function(kontaktId){
  if(kontaktId && mc24KontaktHatHistorie(kontaktId)) return;   // bleibt erhalten (z. B. dokumentierter Kontaktstopp)
  return _mc24EigMit.apply(this, arguments);
};
loescheObjekt = function(id){
  const b = mc24ObjektBezug(id), teile = [];
  if(b.analysen.length) teile.push(`${b.analysen.length} Marktanalyse(n)`);
  if(b.invest.length) teile.push(`${b.invest.length} Investmentprüfung(en)`);
  if(b.gespraeche.length) teile.push(`${b.gespraeche.length} Gesprächsnotiz(en)`);
  const zus = teile.length ? ` Verknüpft: ${teile.join(', ')} – Analysen/Prüfungen bleiben archiviert (Hinweis „Objekt gelöscht“), Notizen bleiben beim Kontakt.` : '';
  const offeneAufg = b.aufgaben.filter(a => a.status !== 'erledigt').length;
  const ob = findObjekt(id), eig = ob && ob.eigentuemerId ? findKontakt(ob.eigentuemerId) : null;
  const eigText = eig ? (mc24KontaktHatHistorie(eig.id) || (db.objekte || []).some(x => x.id !== id && x.eigentuemerId === eig.id) ? ` Kontakt „${eig.name}“ bleibt erhalten.` : ` Kontakt „${eig.name}“ wird mitgelöscht (hängt an keinem anderen Objekt).`) : '';
  bestaetigeUnten('Objekt wirklich löschen?' + zus + (offeneAufg ? ` ${offeneAufg} offene Aufgabe(n) verlieren den Objektbezug.` : '') + eigText, () => {
    const o = db.objekte.find(x => x.id === id);
    const eigentuemerId = o ? o.eigentuemerId : null;
    objektVerknuepfungenAufraeumen(id);
    db.objekte = db.objekte.filter(x => x.id !== id);
    eigentuemerMitloeschenFallsVerwaist(eigentuemerId);
    save(); schliesseModal(); if(aktuelleAnsicht === 'akte') wechsleAnsicht(MC24.zurueck || 'objekte'); else renderMain();
  });
};
loescheKontakt = function(id){
  const k = findKontakt(id); if(!k) return;
  const ob = ob24ObjekteVonKontakt(id).length, ap = mc24Ansprechpartner(id).length, no = (db.notizen || []).filter(n => n.kontaktId === id).length;
  const teile = [ob ? `an ${ob} Objekt(en) verknüpft (Verknüpfung wird gelöst)` : '', ap ? `${ap} Ansprechpartner werden von der Organisation gelöst` : '', no ? `${no} Gesprächsnotiz(en) bleiben ohne Kontakt erhalten` : ''].filter(Boolean);
  bestaetigeUnten('Kontakt wirklich löschen?' + (teile.length ? ' ' + teile.join('; ') + '.' : ''), () => {
    kontaktVerknuepfungenAufraeumen(id);
    db.kontakte = db.kontakte.filter(x => x.id !== id);
    save(); schliesseModal(); renderMain();
  });
};

// ── Altes Objektformular: Änderungen der Kerndaten werden als Angabe festgehalten ──
const _mc24SpeichereObjekt = speichereObjekt;
speichereObjekt = function(id){
  const vorher = id ? JSON.parse(JSON.stringify(findObjekt(id) || {})) : null;
  const anzahl = (db.objekte || []).length;
  const r = _mc24SpeichereObjekt.apply(this, arguments);
  try{
    const o = id ? findObjekt(id) : (db.objekte.length > anzahl ? db.objekte[db.objekte.length - 1] : null);
    if(o){
      let geaendert = false;
      for(const f of AN24_FELDER){
        if(!f.alt) continue;
        const neu = o[f.alt], alt = vorher ? vorher[f.alt] : undefined;
        if(an24Norm(f, neu) === an24Norm(f, alt) && (vorher || neu === '' || neu == null)) continue;
        if(neu === '' || neu == null){ if(an24Aktiv(o, f.k)){ an24Box(o, f.k).aktiv = null; geaendert = true; } continue; }
        if(an24Norm(f, neu) === an24Norm(f, an24Wert(o, f.k)) && an24Aktiv(o, f.k)) continue;
        an24Setzen(o, f.k, { wert: neu, herkunft: 'offen', quelle: 'Objektformular', von: 'manuell' }, { aktivieren: true, entscheidung: 'im Objektformular geändert' });
        geaendert = true;
      }
      if(!Array.isArray(o.kontakte)) o.kontakte = [];
      if(o.eigentuemerId && !o.kontakte.some(x => x.kontaktId === o.eigentuemerId)){ o.kontakte.push({ kontaktId: o.eigentuemerId, rolle: 'eigentuemer' }); geaendert = true; }
      if(geaendert) save();
    }
  }catch(e){ console.error('Angaben', e); }
  return r;
};

// ── Objektformular: Zugang zur Akte ──
const _mc24ObjModal = oeffneObjektModal;
oeffneObjektModal = function(id){
  const r = _mc24ObjModal.apply(this, arguments);
  try{
    if(id){
      const h = document.querySelector('#modalInner .sk-im-modal') || document.querySelector('#modalInner h3');   // Suchkunden-Kasten bleibt direkt unter dem Titel
      if(h && !document.getElementById('mc24AkteBtn')) h.insertAdjacentHTML('afterend', `<div class="mc24-leiste" id="mc24AkteBtn"><button class="secondary tiny" onclick="ob24Oeffnen('${id}')">📁 Objektakte öffnen</button><span>Kontakte, Gespräche, Aufgaben, Unterlagen, Analysen und Investments an einem Ort.</span></div>`);
    }
  }catch(e){ console.error(e); }
  return r;
};

// ── Kontaktformular: Organisation, Ansprechpartner, Kontaktstopp, Quellen der Kontaktdaten, Objekte ──
const _mc24KontaktModal = oeffneKontaktModal;
oeffneKontaktModal = function(id){
  const r = _mc24KontaktModal.apply(this, arguments);
  try{
    const k = id ? findKontakt(id) : {};
    const act = document.querySelector('#modalInner .modal-actions'); if(!act) return r;
    const orgs = mc24Organisationen().filter(x => x.id !== id);
    const ks = k.kontaktstopp || {}, q = k.quellen || {};
    const obj = id ? ob24ObjekteVonKontakt(id) : [];
    const ap = id && k.organisation ? mc24Ansprechpartner(id) : [];
    act.insertAdjacentHTML('beforebegin', `<div class="mc24-kontakt">
      <div class="field-row">
        <div><label class="gs-chk" style="margin-top:10px;"><input type="checkbox" id="m_k_org" ${k.organisation ? 'checked' : ''}> Organisation / Firma (z. B. Hausverwaltung)</label></div>
        <div><label>Gehört zu Organisation</label><select id="m_k_orgid"><option value="">–</option>${orgs.map(x => `<option value="${x.id}" ${k.orgId === x.id ? 'selected' : ''}>${mc24E(x.name)}</option>`).join('')}</select></div>
        <div><label>Rolle / Funktion</label><input id="m_k_rolle" value="${mc24E(k.rolle || '')}" placeholder="z. B. Vermietung, Geschäftsführung"></div>
      </div>
      <div class="field-row">
        <div><label>Quelle der Telefonnummer</label><input id="m_k_qtel" value="${mc24E(q.telefon || '')}" placeholder="z. B. Impressum der Website, Inserat"></div>
        <div><label>Quelle der E-Mail</label><input id="m_k_qmail" value="${mc24E(q.email || '')}" placeholder="nur tatsächlich vorliegende Adressen"></div>
      </div>
      <label class="gs-chk"><input type="checkbox" id="m_k_stopp" ${ks.aktiv ? 'checked' : ''} onchange="document.getElementById('m_k_stopp_grund').style.display=this.checked?'':'none'"> Kontaktstopp – nicht mehr kontaktieren / nicht nachfassen</label>
      <input id="m_k_stopp_grund" style="display:${ks.aktiv ? '' : 'none'}" value="${mc24E(ks.grund || '')}" placeholder="Grund und Datum (z. B. ausdrücklich gewünscht am …)">
      ${ap.length ? `<div class="mc24-mini"><b>Ansprechpartner:</b> ${ap.map(x => `<a href="#" onclick="oeffneKontaktModal('${x.id}');return false;">${mc24E(x.name)}</a>${x.rolle ? ' (' + mc24E(x.rolle) + ')' : ''}`).join(' · ')}</div>` : ''}
      ${obj.length ? `<div class="mc24-mini"><b>Objekte:</b> ${obj.map(o => `<a href="#" onclick="ob24Oeffnen('${o.id}');return false;">📁 ${mc24E(mc24Titel(o))}</a> <span class="mc24-muted">(${mc24E(an24L(MC24_ROLLEN, ((o.kontakte || []).find(x => x.kontaktId === id) || {}).rolle || 'eigentuemer'))})</span>`).join(' · ')}</div>` : ''}
      ${id ? MC24.kontakt.abschnitte.map(f => { try{ return f(k) || ''; }catch(e){ console.error(e); return ''; } }).join('') : ''}
    </div>`);
  }catch(e){ console.error('Kontakt v24', e); }
  return r;
};
const _mc24SpeichereKontakt = speichereKontakt;
speichereKontakt = function(id){
  const g = x => document.getElementById(x);
  const extra = g('m_k_org') ? { organisation: g('m_k_org').checked, orgId: g('m_k_orgid').value || null, rolle: g('m_k_rolle').value.trim(), quellen: { telefon: g('m_k_qtel').value.trim(), email: g('m_k_qmail').value.trim() }, stopp: g('m_k_stopp').checked, stoppGrund: g('m_k_stopp_grund').value.trim() } : null;
  const n = (db.kontakte || []).length;
  const r = _mc24SpeichereKontakt.apply(this, arguments);
  if(extra){
    const k = id ? findKontakt(id) : (db.kontakte.length > n ? db.kontakte[db.kontakte.length - 1] : null);
    if(k){
      k.organisation = extra.organisation; k.orgId = extra.organisation ? null : extra.orgId; k.rolle = extra.rolle; k.quellen = extra.quellen;
      const war = k.kontaktstopp && k.kontaktstopp.aktiv;
      k.kontaktstopp = extra.stopp ? { aktiv: true, grund: extra.stoppGrund, am: war ? (k.kontaktstopp.am || mc24Heute()) : mc24Heute() } : (war ? { aktiv: false, aufgehobenAm: mc24Heute(), grund: k.kontaktstopp.grund } : null);
      save(); renderMain();
    }
  }
  return r;
};

// ── Objektakte ──
function ob24Oeffnen(id){
  if(!findObjekt(id)) return akqToast('Objekt nicht gefunden');
  schliesseModal();
  if(aktuelleAnsicht !== 'akte') MC24.zurueck = aktuelleAnsicht;
  MC24.akteId = id; wechsleAnsicht('akte');
}
function ob24AkteLink(o){ return o ? ` <span class="mc24-aktelink" title="Objektakte öffnen" onclick="event.stopPropagation();ob24Oeffnen('${o.id}')">📁</span>` : ''; }
function ob24NaechsterTermin(o){ const h = mc24Heute(); return (db.termine || []).filter(t => t.objektId === o.id && t.datum >= h).sort((a, b) => (a.datum + (a.uhrzeit || '')).localeCompare(b.datum + (b.uhrzeit || '')))[0] || null; }
function ob24LetzteAnalyse(o){ return (db.analysen24 || []).filter(a => a.objektId === o.id && !a.objektGeloescht).sort((a, b) => (b.erstellt || 0) - (a.erstellt || 0))[0] || null; }
function ob24Fokus(o){
  const l = [];
  const t = ob24NaechsterTermin(o);
  if(t) l.push({ ic: typeof twIcon === 'function' && twIcon(t) || '📅', t: `Nächster Termin: ${gsDatumLang(t.datum)}${t.uhrzeit ? ' ' + t.uhrzeit : ''} – ${t.titel}`, a: `oeffneTerminModal('${t.id}')` });
  const offen = (db.aufgaben || []).filter(a => a.objektId === o.id && a.status !== 'erledigt');
  const faellig = offen.filter(a => a.faellig && a.faellig <= mc24Heute());
  if(faellig.length) l.push({ ic: '⏰', t: `${faellig.length} Aufgabe(n) fällig: ${faellig.map(a => a.titel).slice(0, 2).join(' · ')}`, warn: true });
  const k = an24Konflikte(o);
  if(k.length) l.push({ ic: '⚠️', t: `${k.length} widersprüchliche Angabe(n): ${k.map(x => x.feld.l).join(', ')}`, warn: true, a: `document.getElementById('akteKonflikte').scrollIntoView({behavior:'smooth'})` });
  const a = ob24LetzteAnalyse(o);
  if(a){ const r = typeof ma24AnalyseAuswerten === 'function' ? ma24AnalyseAuswerten(a) : null; l.push({ ic: '📊', t: `Marktanalyse vom ${mc24Datum(a.erstellt)}${r ? ' – ' + (r.spanne && r.spanne.von != null ? mc24Eur(r.spanne.von) + ' – ' + mc24Eur(r.spanne.bis) : 'keine belastbare Spanne') + ', Datenqualität ' + r.qualitaet.stufe : ''}`, a: `ma24Oeffnen('${a.id}')` }); }
  else l.push({ ic: '📊', t: 'Noch keine Marktanalyse', a: `ma24Neu('${o.id}')`, knopf: 'Analyse starten' });
  MC24.start.forEach(f => { try{ const x = f(o); if(x) l.push(...[].concat(x)); }catch(e){ console.error(e); } });
  return l;
}
function ob24Render(main){
  const o = findObjekt(MC24.akteId);
  if(!o){ main.innerHTML = `<div class="vl-leer">Objekt nicht gefunden. <a href="#" onclick="wechsleAnsicht('objekte');return false;">Zu den Objekten</a></div>`; return; }
  const b = mc24ObjektBezug(o.id), fokus = ob24Fokus(o);
  const konf = an24Konflikte(o);
  const knoepfe = MC24.akte.knoepfe.map(f => { try{ return f(o) || ''; }catch(e){ return ''; } }).join('');
  main.innerHTML = `
  <div class="aq-kopf"><div class="ic">${IC.objekte || ''}</div><div><h1>${mc24E(mc24Titel(o))}</h1><div class="sub">${mc24E([o.objektart, o.ort, typeof AQ_ST_KURZ !== 'undefined' ? (AQ_ST_KURZ[o.status] || o.status) : o.status].filter(Boolean).join(' · '))} · Objektakte</div></div>
    <div class="knoepfe"><button class="secondary" onclick="wechsleAnsicht('${mc24E(MC24.zurueck || 'objekte')}')">← Zurück</button></div></div>
  <div class="mc24-aktionen">${knoepfe}<button class="secondary" onclick="oeffneObjektModal('${o.id}')">✎ Bearbeiten</button><button class="secondary" onclick="ma24Neu('${o.id}')">📊 Marktanalyse</button><button class="secondary" onclick="iv24Neu('${o.id}')">💶 Investmentprüfung</button></div>
  <div class="mc24-fokus">${fokus.map(f => `<div class="mc24-fz ${f.warn ? 'warn' : ''}" ${f.a && !f.knopf ? `onclick="${f.a}"` : ''}><span>${f.ic}</span><div>${mc24E(f.t)}</div>${f.knopf ? `<button class="tiny" onclick="${f.a}">${mc24E(f.knopf)}</button>` : ''}</div>`).join('')}</div>
  <div class="mc24-akte">
    <div class="mc24-karte breit"><h3>Kerndaten und Herkunft <span class="sp"></span><button class="tiny" onclick="an24Dialog('${o.id}')">+ Angabe erfassen</button></h3>${an24TabelleHtml(o)}</div>
    <div class="mc24-karte breit" id="akteKonflikte"><h3>Widersprüche und Klärung</h3>${konf.length ? konf.map(x => an24KonfliktHtml(o, x)).join('') : '<div class="vl-leer">Keine widersprüchlichen Angaben.</div>'}</div>
    ${MC24.akte.abschnitte.map(f => { try{ return f(o) || ''; }catch(e){ console.error(e); return ''; } }).join('')}
    <div class="mc24-karte"><h3>Kontakte <span class="sp"></span><button class="tiny" onclick="ob24KontaktDialog('${o.id}')">+ Kontakt verknüpfen</button></h3>${ob24KontakteHtml(o)}</div>
    <div class="mc24-karte"><h3>Aufgaben <span class="sp"></span><button class="tiny" onclick="ob24AufgabeDialog('${o.id}')">+ Aufgabe</button></h3>${ob24AufgabenHtml(b.aufgaben)}</div>
    <div class="mc24-karte"><h3>Termine</h3>${b.termine.length ? b.termine.slice().sort((x, y) => (y.datum + (y.uhrzeit || '')).localeCompare(x.datum + (x.uhrzeit || ''))).slice(0, 8).map(t => typeof gsTerminZeile === 'function' ? gsTerminZeile(t, true) : mc24E(t.titel)).join('') : '<div class="vl-leer">Keine Termine.</div>'}</div>
    <div class="mc24-karte"><h3>Gespräche</h3>${ob24GespraecheHtml(b.gespraeche)}</div>
    <div class="mc24-karte"><h3>Unterlagen <span class="sp"></span><button class="tiny secondary" onclick="oeffneObjektModal('${o.id}')">verwalten</button></h3>${(o.dokumente || []).length ? (o.dokumente || []).map(d => `<div class="mc24-z"><span>📎</span><div><a href="#" onclick="dokOeffnen('${o.id}','${d.id}');return false;">${mc24E(d.name)}</a><small>${mc24E(d.kat || '')} · ${mc24Datum(d.am)}</small></div></div>`).join('') : '<div class="vl-leer">Keine Unterlagen.</div>'}</div>
    <div class="mc24-karte"><h3>Marktanalysen <span class="sp"></span><button class="tiny" onclick="ma24Neu('${o.id}')">+ Neue Analyse</button></h3>${ob24AnalysenHtml(o, b.analysen)}</div>
    <div class="mc24-karte"><h3>Investmentprüfungen <span class="sp"></span><button class="tiny" onclick="iv24Neu('${o.id}')">+ Prüfung</button></h3>${b.invest.length ? b.invest.map(p => { const r = typeof iv24ErgebnisVon === 'function' ? iv24ErgebnisVon(p) : null; return `<div class="mc24-z" onclick="iv24Oeffnen('${p.id}')"><span>💶</span><div><b>${mc24E(p.name || 'Prüfung')}</b><small>${mc24Datum(p.erstellt)}${r && r.cashflowMonat != null ? ' · Cashflow ' + mc24Eur(r.cashflowMonat) + '/Monat' : ''} · ${mc24E((p.entscheidung || {}).status ? IV24_ENTSCHEIDUNG_TEXT[p.entscheidung.status] : 'offen')}</small></div></div>`; }).join('') : '<div class="vl-leer">Noch keine Investmentprüfung.</div>'}</div>
    <div class="mc24-karte"><h3>Verlauf</h3>${(o.verlauf || []).slice(-8).reverse().map(v => `<div class="mc24-z"><span>•</span><div>${mc24E(v.text || v.t || '')}<small>${v.zeit ? mc24Datum(v.zeit) : ''}</small></div></div>`).join('') || '<div class="vl-leer">Noch kein Verlauf.</div>'}</div>
  </div>`;
}
function an24TabelleHtml(o){
  const zeilen = AN24_FELDER.map(f => {
    const a = an24Aktiv(o, f.k), box = (o.angaben || {})[f.k], w = a ? a.wert : an24Wert(o, f.k);
    const vorschlaege = box ? box.werte.filter(x => x.pruef === 'vorschlag') : [];
    if(w == null && !vorschlaege.length && !['wohnflaeche', 'baujahr', 'zustand', 'kaufpreis'].includes(f.k)) return '';
    const dok = a && a.dokId ? (o.dokumente || []).find(d => d.id === a.dokId) : null;
    return `<tr><td>${mc24E(f.l)}</td><td><b>${mc24E(an24Wtext(f, w))}</b>${vorschlaege.length ? vorschlaege.map(v => `<div class="mc24-vorschlag">Vorschlag: ${mc24E(an24Wtext(f, v.wert))} <small>(${mc24E(v.quelle || v.von)})</small> <button class="tiny" onclick="an24Uebernehmen('${o.id}','${f.k}','${v.id}')">übernehmen</button> <button class="tiny secondary" onclick="an24Verwerfen('${o.id}','${f.k}','${v.id}')">verwerfen</button></div>`).join('') : ''}</td>
      <td>${a ? `<span class="mc24-h h-${a.herkunft}">${mc24E(an24L(AN24_HERKUNFT, a.herkunft))}</span>` : (w == null ? '<span class="mc24-h h-fehlt">fehlt</span>' : '')}</td>
      <td>${a ? (a.pruef === 'geprueft' ? '<span class="mc24-ok">✓ geprüft</span>' : `<button class="tiny secondary" onclick="an24Pruefen('${o.id}','${f.k}')">als geprüft markieren</button>`) : ''}</td>
      <td class="mc24-muted">${a ? mc24E([a.quelle, dok ? '📎 ' + dok.name : '', a.bezug ? 'Stand ' + mc24Datum(a.bezug) : '', 'erfasst ' + mc24Datum(a.erfasst)].filter(Boolean).join(' · ')) : ''}${a && a.notiz ? `<br>${mc24E(a.notiz)}` : ''}</td>
      <td><button class="tiny secondary" onclick="an24Dialog('${o.id}','${f.k}')">✎</button></td></tr>`;
  }).join('');
  return `<table class="mc24-tab"><tr><th>Angabe</th><th>Wert</th><th>Herkunft</th><th>Prüfung</th><th>Quelle / Stand</th><th></th></tr>${zeilen}</table><div class="mc24-muted" style="margin-top:6px;">„fehlt“ heißt unbekannt – nicht 0. Neue KI-Angaben erscheinen als Vorschlag und ändern nichts, bis du sie übernimmst.</div>`;
}
function an24KonfliktHtml(o, x){
  const f = x.feld;
  return `<div class="mc24-konflikt"><b>${mc24E(f.l)}</b>: ${x.werte.map(w => `<span class="mc24-kw ${w.id === x.aktiv ? 'aktiv' : ''}">${mc24E(an24Wtext(f, w.wert))} <small>${mc24E(an24L(AN24_HERKUNFT, w.herkunft))}${w.quelle ? ', ' + mc24E(w.quelle) : ''}${w.von === 'ki' ? ', KI' : ''} · ${mc24Datum(w.erfasst)}</small></span>`).join(' ↔ ')}
    <div class="mc24-muted">${mc24E(an24Bedeutung(f))}</div>
    <div class="mc24-knoepfe"><button class="tiny" onclick="an24KlaerenDialog('${o.id}','${f.k}')">Entscheidung dokumentieren</button><button class="tiny secondary" onclick="an24KlaerAufgabe('${o.id}','${f.k}')">Rückfrage als Aufgabe</button></div></div>`;
}
function an24Bedeutung(f){
  return ({ wohnflaeche: 'Wirkt direkt auf €/m², Preisspanne und Rendite. Rückfrage: Wohnflächenberechnung oder Aufmaß anfordern.', baujahr: 'Bestimmt Vergleichbarkeit und Abschreibung. Rückfrage: Baujahr laut Baugenehmigung/Energieausweis.', kaufpreis: 'Preisvorstellung und Angebotspreis sauber trennen.', miete_ist: 'Ist-Miete bestimmt Rendite und Cashflow. Rückfrage: Mietvertrag und Kontoauszüge.', hausgeld: 'Ohne Aufteilung ist der Eigentümeranteil unklar. Rückfrage: Wirtschaftsplan anfordern.', hausgeld_umlage: 'Rückfrage: Wirtschaftsplan mit Aufteilung umlagefähig/nicht umlagefähig.', modernisierung: 'Unbestätigte Modernisierungen nicht als Vorteil werten. Rückfrage: Rechnungen/Nachweise.', zustand: 'Beeinflusst die Auswahl der Vergleichsobjekte.' })[f.k] || 'Bitte klären, welche Angabe gilt.';
}
function an24Dialog(oid, feld){
  const o = findObjekt(oid); if(!o) return;
  const f = an24Feld(feld) || AN24_FELDER[0];
  const a = an24Aktiv(o, f.k);
  mc24Modal(`<h3>Angabe erfassen</h3>
    <div class="field-row"><div><label>Angabe</label><select id="an_feld" onchange="an24Dialog('${oid}', this.value)">${AN24_FELDER.map(x => `<option value="${x.k}" ${x.k === f.k ? 'selected' : ''}>${x.l}</option>`).join('')}</select></div>
      <div><label>Wert${f.einheit ? ' (' + f.einheit + ')' : ''}</label>${f.typ === 'auswahl' ? `<select id="an_wert"><option value="">unbekannt</option>${f.optionen.map(x => `<option value="${x[0]}" ${a && a.wert === x[0] ? 'selected' : ''}>${x[1]}</option>`).join('')}</select>` : f.typ === 'text' ? `<input id="an_wert" value="${mc24E(a ? a.wert : '')}">` : `<input id="an_wert" inputmode="decimal" value="${a && a.wert != null ? mc24E(f.k === 'baujahr' ? String(a.wert) : mc24Fmt(a.wert)) : ''}" placeholder="leer = unbekannt">`}</div></div>
    <div class="field-row"><div><label>Herkunft</label><select id="an_herkunft">${AN24_HERKUNFT.map(x => `<option value="${x[0]}" ${x[0] === 'eigentuemer' ? 'selected' : ''}>${x[1]}</option>`).join('')}</select></div>
      <div><label>Quelle (z. B. Exposé, Telefonat, Wirtschaftsplan 2026)</label><input id="an_quelle"></div></div>
    <div class="field-row"><div><label>Dokument</label><select id="an_dok"><option value="">–</option>${(o.dokumente || []).map(d => `<option value="${d.id}">${mc24E(d.name)}</option>`).join('')}</select></div>
      <div><label>Stand / Bezugszeitpunkt</label><input id="an_bezug" type="date"></div></div>
    <label>Notiz</label><input id="an_notiz">
    <label class="gs-chk"><input type="checkbox" id="an_geprueft"> Angabe ist geprüft</label>
    <label class="gs-chk"><input type="checkbox" id="an_aktiv" checked> Ab sofort diesen Wert verwenden (sonst nur als abweichende Angabe zur Klärung festhalten)</label>
    <div class="modal-actions"><div></div><div class="right"><button class="secondary" onclick="schliesseModal()">Abbrechen</button><button onclick="an24DialogSpeichern('${oid}')">Speichern</button></div></div>`, 640);
}
function an24DialogSpeichern(oid){
  const o = findObjekt(oid), g = x => document.getElementById(x); if(!o) return;
  const k = g('an_feld').value, f = an24Feld(k), roh = g('an_wert').value.trim();
  if(f.typ === 'zahl' && roh && mc24N(roh) == null){ akqToast('Bitte eine Zahl eingeben (leer = unbekannt).'); return; }
  const aktiv = g('an_aktiv').checked;
  an24Setzen(o, k, { wert: roh === '' ? null : roh, herkunft: g('an_herkunft').value, quelle: g('an_quelle').value.trim(), dokId: g('an_dok').value || null, bezug: g('an_bezug').value, notiz: g('an_notiz').value.trim(), pruef: g('an_geprueft').checked ? 'geprueft' : 'ungeprueft', von: 'manuell', erfasstZeit: new Date().toISOString() }, { aktivieren: aktiv, entscheidung: aktiv ? 'neu erfasst und übernommen' : null });
  save(); schliesseModal(); renderMain();
}
function an24Pruefen(oid, k){ const o = findObjekt(oid), a = an24Aktiv(o, k); if(a){ a.pruef = 'geprueft'; a.geprueftAm = mc24Heute(); save(); renderMain(); } }
function an24Uebernehmen(oid, k, id){ const o = findObjekt(oid); an24Aktivieren(o, k, id, 'Vorschlag übernommen'); save(); renderMain(); akqToast('Übernommen – Herkunft und Quelle bleiben gespeichert'); }
function an24Verwerfen(oid, k, id){ const o = findObjekt(oid), w = an24Box(o, k).werte.find(x => x.id === id); if(w){ w.pruef = 'abgelehnt'; w.verworfenAm = mc24Heute(); } save(); renderMain(); }
function an24KlaerenDialog(oid, k){
  const o = findObjekt(oid), f = an24Feld(k), x = an24Konflikte(o).find(y => y.feld.k === k); if(!x) return;
  mc24Modal(`<h3>Klären: ${mc24E(f.l)}</h3><div class="mc24-muted">${mc24E(an24Bedeutung(f))}</div>
    ${x.werte.map(w => `<label class="gs-chk"><input type="radio" name="an_k" value="${w.id}" ${w.id === x.aktiv ? 'checked' : ''}> <b>${mc24E(an24Wtext(f, w.wert))}</b> – ${mc24E(an24L(AN24_HERKUNFT, w.herkunft))}${w.quelle ? ', ' + mc24E(w.quelle) : ''} (${mc24Datum(w.erfasst)})</label>`).join('')}
    <label>Begründung der Entscheidung</label><input id="an_begr" placeholder="z. B. laut Wohnflächenberechnung vom …">
    <div class="mc24-muted">Die anderen Angaben bleiben mit ihrer Quelle gespeichert und werden als verworfen markiert.</div>
    <div class="modal-actions"><div></div><div class="right"><button class="secondary" onclick="schliesseModal()">Abbrechen</button><button onclick="an24KlaerenSpeichern('${oid}','${k}')">Entscheidung speichern</button></div></div>`, 620);
}
function an24KlaerenSpeichern(oid, k){
  const o = findObjekt(oid), sel = document.querySelector('input[name="an_k"]:checked'); if(!sel) return;
  const text = document.getElementById('an_begr').value.trim();
  if(!text){ akqToast('Bitte kurz begründen, warum diese Angabe gilt.'); return; }
  const box = an24Box(o, k);
  box.werte.forEach(w => { if(w.id !== sel.value && w.pruef !== 'abgelehnt'){ w.pruef = 'abgelehnt'; w.verworfenAm = mc24Heute(); } });
  an24Aktivieren(o, k, sel.value, text);
  if(typeof aqLog === 'function') aqLog(o, 'notiz', `Angabe geklärt (${an24Feld(k).l}): ${an24Wtext(an24Feld(k), box.werte.find(w => w.id === sel.value).wert)} – ${text}`);
  save(); schliesseModal(); renderMain();
}
function an24KlaerAufgabe(oid, k){
  const o = findObjekt(oid), f = an24Feld(k);
  const a = mc24AufgabeAnlegen({ titel: `Klären: ${f.l} (${mc24Titel(o).slice(0, 40)})`, faellig: gsTagPlus(mc24Heute(), 3), objektId: oid, kontaktId: o.eigentuemerId || null, typ: 'klaerung', notiz: an24Bedeutung(f) });
  save(); renderMain(); akqToast('✅ Aufgabe angelegt: ' + a.titel);
}
function ob24KontakteHtml(o){
  const l = ob24Kontakte(o);
  return l.length ? l.map(x => `<div class="mc24-z"><span>${x.k.organisation ? '🏢' : '👤'}</span><div><a href="#" onclick="oeffneKontaktModal('${x.k.id}');return false;"><b>${mc24E(x.k.name)}</b></a> <span class="mc24-muted">${mc24E(an24L(MC24_ROLLEN, x.rolle))}</span>${mc24Kontaktstopp(x.k) ? ' <span class="mc24-stopp">Kontaktstopp</span>' : ''}<small>${mc24E([x.k.telefon, x.k.email].filter(Boolean).join(' · '))}</small></div><button class="tiny secondary" title="Verknüpfung lösen" onclick="ob24KontaktLoesenKlick('${o.id}','${x.k.id}')">✕</button></div>`).join('')
    : `<div class="vl-leer">Kein Kontakt verknüpft.${o.verkaeuferName || o.verkaeuferTelefon ? ` <a href="#" onclick="ob24Hauptkontakt(findObjekt('${o.id}'), true);save();renderMain();return false;">Verkäufer aus den Lead-Daten anlegen</a>` : ''}</div>`;
}
function ob24KontaktLoesenKlick(oid, kid){ const o = findObjekt(oid); ob24KontaktLoesen(o, kid); save(); renderMain(); }
function ob24KontaktDialog(oid){
  const o = findObjekt(oid);
  const ks = (db.kontakte || []).slice().sort((a, b) => String(a.name || '').localeCompare(String(b.name || ''), 'de'));
  mc24Modal(`<h3>Kontakt mit Objekt verknüpfen</h3>
    <div class="field-row"><div><label>Vorhandener Kontakt</label><select id="ob_k"><option value="">– neuen Kontakt anlegen –</option>${ks.map(k => `<option value="${k.id}">${mc24E(k.name)}${k.organisation ? ' (Organisation)' : ''}</option>`).join('')}</select></div>
      <div><label>Rolle</label><select id="ob_r">${MC24_ROLLEN.map(r => `<option value="${r[0]}">${r[1]}</option>`).join('')}</select></div></div>
    <div id="ob_neu"><div class="field-row"><div><label>Name (neu)</label><input id="ob_name"></div><div><label>Telefon</label><input id="ob_tel"></div><div><label>E-Mail</label><input id="ob_mail"></div></div></div>
    <div class="mc24-muted">Ein Kontakt wird nur einmal angelegt und kann an mehreren Objekten hängen.</div>
    <div class="modal-actions"><div></div><div class="right"><button class="secondary" onclick="schliesseModal()">Abbrechen</button><button onclick="ob24KontaktDialogSpeichern('${oid}')">Verknüpfen</button></div></div>`, 640);
  document.getElementById('ob_k').onchange = e => { document.getElementById('ob_neu').style.display = e.target.value ? 'none' : ''; };
}
function ob24KontaktDialogSpeichern(oid){
  const o = findObjekt(oid), g = x => document.getElementById(x);
  let kid = g('ob_k').value;
  if(!kid){
    const name = g('ob_name').value.trim(); if(!name){ akqToast('Bitte einen Namen eingeben oder einen Kontakt wählen.'); return; }
    const gleich = (db.kontakte || []).find(k => k.name.trim().toLowerCase() === name.toLowerCase() && ((g('ob_tel').value.trim() && k.telefon === g('ob_tel').value.trim()) || (g('ob_mail').value.trim() && k.email === g('ob_mail').value.trim())));
    if(gleich) kid = gleich.id;
    else { const k = { id: uid(), createdAt: Date.now(), name, telefon: g('ob_tel').value.trim(), email: g('ob_mail').value.trim(), adresse: '', kontaktart: g('ob_r').value === 'hausverwaltung' ? 'hausverwaltung' : 'eigentuemer', quelle: 'Sonstiges', status: 'lead', prioritaet: 'mittel', notizen: '' }; db.kontakte.push(k); kid = k.id; }
  }
  ob24KontaktVerknuepfen(o, kid, g('ob_r').value);
  save(); schliesseModal(); renderMain();
}
function ob24AufgabenHtml(l){
  const offen = l.filter(a => a.status !== 'erledigt').sort((a, b) => String(a.faellig || '9').localeCompare(String(b.faellig || '9'))), erl = l.filter(a => a.status === 'erledigt').slice(-3);
  return (offen.map(a => `<div class="mc24-z"><input type="checkbox" onchange="mc24AufgabeErledigt('${a.id}', this.checked);renderMain()"><div>${mc24E(a.titel)}<small>${a.faellig ? (a.faellig < mc24Heute() ? '<span class="mc24-rot">überfällig seit ' + mc24Datum(a.faellig) + '</span>' : 'fällig ' + mc24Datum(a.faellig)) : 'ohne Datum'}</small></div></div>`).join('')
    + erl.map(a => `<div class="mc24-z erledigt"><input type="checkbox" checked onchange="mc24AufgabeErledigt('${a.id}', this.checked);renderMain()"><div>${mc24E(a.titel)}<small>erledigt</small></div></div>`).join('')) || '<div class="vl-leer">Keine Aufgaben.</div>';
}
function ob24AufgabeDialog(oid){
  const o = findObjekt(oid);
  mc24Modal(`<h3>Aufgabe zum Objekt</h3><label>Aufgabe</label><input id="ob_at"><div class="field-row"><div><label>Fällig am</label><input type="date" id="ob_af" value="${gsTagPlus(mc24Heute(), 1)}"></div></div>
    <div class="modal-actions"><div></div><div class="right"><button class="secondary" onclick="schliesseModal()">Abbrechen</button><button onclick="ob24AufgabeSpeichern('${oid}')">Speichern</button></div></div>`, 520);
}
function ob24AufgabeSpeichern(oid){ const t = document.getElementById('ob_at').value.trim(); if(!t) return; const o = findObjekt(oid); mc24AufgabeAnlegen({ titel: t, faellig: document.getElementById('ob_af').value, objektId: oid, kontaktId: o.eigentuemerId || null, typ: 'aufgabe' }); save(); schliesseModal(); renderMain(); }
function ob24GespraecheHtml(l){
  return l.length ? l.slice().sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0)).slice(0, 6).map(n => `<div class="mc24-z"><span>💬</span><div><b>${mc24E(n.ergebnisText || n.titel || 'Notiz')}</b><small>${mc24Datum(n.datum || n.createdAt)}${n.naechsterSchritt ? ' · nächster Schritt: ' + mc24E(n.naechsterSchritt) : ''}</small>${n.text ? `<div class="mc24-muted">${mc24E(String(n.text).slice(0, 220))}</div>` : ''}</div></div>`).join('') : '<div class="vl-leer">Noch keine Gesprächsnotiz.</div>';
}
function ob24AnalysenHtml(o, l){
  const alt = (db.marktanalysen || []).filter(m => m.objektId === o.id);
  return (l.slice().sort((a, b) => (b.erstellt || 0) - (a.erstellt || 0)).map(a => { const r = typeof ma24AnalyseAuswerten === 'function' ? ma24AnalyseAuswerten(a) : null; return `<div class="mc24-z" onclick="ma24Oeffnen('${a.id}')"><span>📊</span><div><b>${a.typ === 'rent' ? 'Marktmiete' : 'Verkaufspreis'} · Version ${a.version || 1}</b><small>${mc24Datum(a.erstellt)} · ${r ? (r.spanne && r.spanne.von != null ? mc24Eur(r.spanne.von) + ' – ' + mc24Eur(r.spanne.bis) : 'keine belastbare Spanne') + ' · Qualität ' + r.qualitaet.stufe : ''}${a.status === 'abgeschlossen' ? ' · abgeschlossen' : ''}</small></div></div>`; }).join('')
    + alt.map(m => `<div class="mc24-z"><span>🗂️</span><div>${mc24E(m.titel || 'Frühere Marktanalyse')}<small>vor v24 angelegt</small></div></div>`).join('')) || '<div class="vl-leer">Noch keine Analyse.</div>';
}

// ── Navigation / Seiten ──
const _mc24RenderMain = renderMain;
renderMain = function(){
  if(aktuelleAnsicht === 'akte') return ob24Render(document.getElementById('main'));
  return _mc24RenderMain.apply(this, arguments);
};
// Lead-Detail in der Akquise: Zugang zur Akte (+ Knöpfe der Module)
const _mc24Aq2Detail = typeof aq2Detail === 'function' ? aq2Detail : null;
if(_mc24Aq2Detail) aq2Detail = function(){
  const r = _mc24Aq2Detail.apply(this, arguments);
  try{
    const o = findObjekt(AQ2.sel), tags = document.querySelector('#aqDetail .lc-tags');
    if(o && tags && !document.getElementById('mc24LeadLeiste')) tags.insertAdjacentHTML('afterend', `<div class="mc24-leadleiste" id="mc24LeadLeiste"><button class="tiny secondary" onclick="ob24Oeffnen('${o.id}')">📁 Akte</button>${MC24.lead.knoepfe.map(f => { try{ return f(o) || ''; }catch(e){ return ''; } }).join('')}</div>`);
  }catch(e){ console.error(e); }
  return r;
};

// ── Einstellungen: Module ein/aus ──
const _mc24TbMenue = tbMenue;
tbMenue = function(ev, art){
  const r = _mc24TbMenue.apply(this, arguments);
  try{
    const m = document.getElementById('tbMenue');
    if(m && art !== 'hinweise') m.insertAdjacentHTML('afterbegin', `<div class="mi" onclick="tbMenueZu();mc24ModuleDialog()">🧩<div>Module & Akquise-Erweiterung<small>Akquise-Erweiterung ${mc24ModulAn('akquise24') ? 'eingeschaltet' : 'ausgeschaltet'} · Regeln</small></div></div>`);
  }catch(e){}
  return r;
};
function mc24ModuleDialog(){
  const an = mc24ModulAn('akquise24');
  mc24Modal(`<h3>🧩 Module</h3>
    <label class="gs-chk"><input type="checkbox" id="mod_ak" ${an ? 'checked' : ''}> <b>Akquise-Erweiterung</b> – Startseite „Heute“ mit Prioritäten, Gesprächsbriefing, Verkäufermotivation, Einwände & Gesprächshilfen, Kooperationsakten Hausverwaltung, Gesprächsabschluss</label>
    <div class="mc24-muted">Ausschalten blendet alles davon sofort aus. Deine eingegebenen Daten (Gesprächsnotizen, Motivation, Einwände) bleiben gespeichert und sind beim Wiedereinschalten wieder da. Marktanalyse, Investments und Objektakte bleiben immer an.</div>
    ${an && typeof ak24RegelnDialog === 'function' ? `<div style="margin-top:10px;"><button class="secondary tiny" onclick="ak24RegelnDialog()">Prioritäten-Regeln einstellen</button> <button class="secondary tiny" onclick="ak24HilfenDialog()">Gesprächshilfen bearbeiten</button></div>` : ''}
    <div class="modal-actions"><div></div><div class="right"><button class="secondary" onclick="schliesseModal()">Schließen</button><button onclick="mc24ModuleSpeichern()">Übernehmen</button></div></div>`, 620);
}
function mc24ModuleSpeichern(){
  const an = document.getElementById('mod_ak').checked, war = mc24ModulAn('akquise24');
  mc24Module().akquise24 = an; save(); schliesseModal();
  if(an !== war){ akqToast(an ? 'Akquise-Erweiterung eingeschaltet' : 'Akquise-Erweiterung ausgeschaltet – Daten bleiben erhalten'); setTimeout(() => location.reload(), 400); }
}

window.addEventListener('load', () => {
  try{ mc24Migrieren(); }catch(e){ console.error('Migration v24', e); }
});
