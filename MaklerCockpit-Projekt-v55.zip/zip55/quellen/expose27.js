// ═══ MaklerCockpit v27 – Exposé einlesen nach Aufbau (BETTERHOMES-Vorlage) ═══
// Seite 1: fetter Titel oben, Beschreibung links, Vorteile („- …“) rechts, erstes Foto = Titelbild.
// Seite „Objektinformationen“: Objektart, Adresse, alle Felder (Referenz, Kaufpreis, Hausgeld, Energie, Zimmer, Baujahr, Etage, Flächen, Zustand, Bäder, Heizung, Lage, Ausstattung …) und Provision.
// Andere Exposés: bisheriges Verfahren (Text/Texterkennung) als Rückfall.
const EX27_MAX_BILD = 1280;   // v34: kleiner (Datendatei, Abgleich, Sicherungen)
// Nur sichere Bildquellen (eigene JPEG/PNG-Daten oder http(s)) in die Oberfläche
function ex27Src(u){ u = String(u || ''); if(/^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+\/=]+$/.test(u)) return u; const l = typeof mc24SicherLink === 'function' ? mc24SicherLink(u) : ''; return l ? l.replace(/"/g, '%22') : ''; }
function ex27Norm(s){ return String(s || '').replace(/\u00ad/g, '').replace(/[ \t\u00a0]+/g, ' ').replace(/ ([,;.:)])(?=\s|$)/g, '$1').replace(/\( /g, '(').trim(); }
function ex27Zahl(s){
  const t = String(s || '').replace(/\s/g, '');
  const m = t.match(/-?\d[\d.]*(?:,\d+)?/); if(!m) return null;
  let z = m[0];
  if(/,\d+$/.test(z)) z = z.replace(/\./g, '').replace(',', '.');
  else if(/^\d{1,3}(\.\d{3})+$/.test(z)) z = z.replace(/\./g, '');
  const n = Number(z); return isFinite(n) ? n : null;
}
// Text einer Seite → Zeilen (Wörter mit Position, nach Spalten getrennt)
function ex27Zeilen(items, breite, spalten){
  const mitte = breite / 2;
  const gruppen = [];
  for(const it of items.slice().sort((a, b) => a.y - b.y || a.x - b.x)){
    const sp = spalten ? (it.x < mitte - 4 ? 0 : 1) : 0;
    let g = gruppen.find(z => z.sp === sp && Math.abs(z.y - it.y) <= Math.max(2, Math.min(z.h, it.h) * 0.45));
    if(!g){ g = { y: it.y, h: it.h, sp, teile: [] }; gruppen.push(g); }
    g.teile.push(it); g.h = Math.max(g.h, it.h);
  }
  for(const g of gruppen){
    g.teile.sort((a, b) => a.x - b.x);
    g.x = g.teile[0].x;
    // Wörter verbinden; großer Abstand = neue „Zelle“ (Feldname | Wert)
    g.zellen = []; let akt = null, ende = -1e9;
    for(const t of g.teile){
      const luecke = t.x - ende;
      if(!akt || luecke > Math.max(14, t.h * 1.6)){ akt = { x: t.x, s: t.s }; g.zellen.push(akt); }
      else akt.s += (luecke > t.h * 0.12 && !/\s$/.test(akt.s) && !/^\s/.test(t.s) ? ' ' : '') + t.s;
      ende = t.x + (t.w || t.s.length * t.h * 0.5);
    }
    g.zellen.forEach(z => { z.s = ex27Norm(z.s); });
    g.text = ex27Norm(g.zellen.map(z => z.s).join(' '));
  }
  return gruppen.filter(g => g.text).sort((a, b) => a.sp - b.sp || a.y - b.y);
}
async function ex27Seite(pdf, nr){
  const page = await pdf.getPage(nr);
  const vp = page.getViewport({ scale: 1 });
  const tc = await page.getTextContent();
  const items = tc.items.filter(it => it.str && it.str.trim()).map(it => ({ s: it.str, x: it.transform[4], y: vp.height - it.transform[5], h: Math.abs(it.transform[3]) || it.height || 10, w: it.width }));
  return { nr, page, breite: vp.width, hoehe: vp.height, items };
}
// Erstes richtiges Foto (keine Logos/Symbole) als JPEG
async function ex27Bild(seite){
  try{
    const page = seite.page; const ops = await page.getOperatorList(); const O = pdfjsLib.OPS;
    for(let i = 0; i < ops.fnArray.length; i++){
      const fn = ops.fnArray[i];
      if(fn !== O.paintImageXObject && fn !== O.paintJpegXObject) continue;
      const [id, w, h] = ops.argsArray[i];
      if(!(w >= 400 && h >= 250 && w / h <= 3 && h / w <= 3)) continue;
      const store = String(id).startsWith('g_') ? page.commonObjs : page.objs;
      const img = await new Promise(res => { try{ store.get(id, res); }catch(e){ res(null); } setTimeout(() => res(null), 8000); });
      if(!img) continue;
      const iw = img.width || w, ih = img.height || h;
      const f = Math.min(1, EX27_MAX_BILD / iw);
      const c = document.createElement('canvas'); c.width = Math.round(iw * f); c.height = Math.round(ih * f);
      const ctx = c.getContext('2d');
      if(img.bitmap){ ctx.drawImage(img.bitmap, 0, 0, c.width, c.height); }
      else if(img.data){
        const roh = document.createElement('canvas'); roh.width = iw; roh.height = ih; const rctx = roh.getContext('2d');
        const id2 = rctx.createImageData(iw, ih), d = id2.data, s = img.data;
        if(img.kind === 3){ d.set(s.subarray(0, d.length)); }
        else if(img.kind === 2){ for(let p = 0, q = 0; q < d.length; p += 3, q += 4){ d[q] = s[p]; d[q + 1] = s[p + 1]; d[q + 2] = s[p + 2]; d[q + 3] = 255; } }
        else continue;
        rctx.putImageData(id2, 0, 0); ctx.drawImage(roh, 0, 0, c.width, c.height);
      } else if(typeof img.close === 'function' || img instanceof (window.ImageBitmap || Object)){ ctx.drawImage(img, 0, 0, c.width, c.height); }
      else continue;
      const url = c.toDataURL('image/jpeg', 0.84);
      if(url.length > 2000) return { url, breite: c.width, hoehe: c.height };
    }
  }catch(e){ console.error('Exposé-Bild', e); }
  return null;
}
const EX27_FELD = {
  'referenz-nr.': 'referenz', 'referenznummer': 'referenz', 'objekt-nr.': 'referenz', 'objektnummer': 'referenz',
  'kaufpreis': 'kaufpreis', 'preis': 'kaufpreis', 'angebotspreis': 'kaufpreis', 'kaltmiete': 'kaltmiete', 'nettokaltmiete': 'kaltmiete', 'warmmiete': 'warmmiete', 'nebenkosten': 'nebenkosten',
  'hausgeld': 'hausgeld', 'endenergieverbrauch': 'energieverbrauch', 'endenergiebedarf': 'energiebedarf', 'energieausweistyp': 'energieausweis', 'energieeffizienzklasse': 'energieklasse',
  'zimmer': 'zimmer', 'schlafzimmer': 'schlafzimmer', 'badezimmer': 'badezimmer', 'baujahr': 'baujahr', 'etage': 'etage', 'etagen': 'etagen', 'anzahl etagen': 'etagen',
  'wohnfläche': 'wohnflaeche', 'nutzfläche': 'nutzflaeche', 'grundstücksfläche': 'grundstueck', 'grundstück': 'grundstueck', 'anzahl wohnungen': 'wohnungen', 'wohneinheiten': 'wohnungen',
  'zustand': 'zustand', 'bäder / nasszellen': 'baeder', 'bäder/nasszellen': 'baeder', 'heizsystem': 'heizung', 'heizungsart': 'heizung', 'heizung': 'heizung', 'befeuerung': 'befeuerung',
  'öffentliche verkehrsmittel': 'oepnv', 'schulen': 'schulen', 'geschäfte': 'geschaefte', 'ausstattung': 'ausstattung', 'lage': 'lage', 'verfügbar ab': 'verfuegbar', 'bezugsfrei ab': 'verfuegbar',
  'stellplatz': 'stellplatz', 'stellplätze': 'stellplatz', 'garage': 'garage', 'denkmalschutz': 'denkmal', 'vermietet': 'vermietet', 'mieteinnahmen': 'mieteinnahmen', 'mieteinnahmen p.a.': 'mieteinnahmen'
};
function ex27Schluessel(label){ const l = ex27Norm(label).replace(/:$/, '').toLowerCase(); return EX27_FELD[l] || null; }
function ex27Art(typ, text){
  // zuerst die Objektart aus „Objektinformationen“, erst dann Titel/Beschreibung
  if(typ && text !== undefined){ const a = ex27Art(typ); if(a !== 'Sonstiges') return a; return ex27Art('', text); }
  const t = (String(typ || '') + ' ' + String(text || '')).toLowerCase();
  if(/mehrfamilien|zinshaus|\bmfh\b/.test(t)) return 'MFH';
  if(/doppelhaush/.test(t)) return 'DHH';
  if(/reihen(?:end|mittel|eck)?haus/.test(t)) return 'Reihenhaus';
  if(/einfamilien|\befh\b|bungalow|villa|landhaus|stadthaus/.test(t)) return 'EFH';
  if(/grundstück|bauland/.test(String(typ || '').toLowerCase())) return 'Grundstück';
  if(/wohnung|apartment|appartement|penthouse|maisonette|loft|dachgeschoss|erdgeschoss|souterrain/.test(t)) return 'Wohnung';
  if(/büro|praxis|laden|gewerbe|einzelhandel|halle|gastronomie/.test(t)) return 'Gewerbe';
  if(/haus/.test(String(typ || '').toLowerCase())) return 'EFH';
  return 'Sonstiges';
}
// Hauptfunktion: liefert strukturierte Daten oder null (dann Rückfall auf das alte Verfahren)
async function ex27Lesen(datei, status){
  if(!window.pdfjsLib) throw new Error('pdf.js nicht verfügbar');
  const pdf = await pdfjsLib.getDocument({ data: await datei.arrayBuffer() }).promise;
  const seiten = [];
  for(let i = 1; i <= Math.min(pdf.numPages, 6); i++) seiten.push(await ex27Seite(pdf, i));
  const textGesamt = seiten.map(s => s.items.map(i => i.s).join(' ')).join('\n');
  if(textGesamt.replace(/\s/g, '').length < 40) return { seitenzahl: pdf.numPages, ohneText: true, bild: seiten[0] ? await ex27Bild(seiten[0]) : null };
  const ex = { seitenzahl: pdf.numPages, titel: '', beschreibung: '', vorteile: [], felder: {}, felderListe: [], typ: '', adresse: '', plz: '', ort: '', provision: '', erkannt: false };
  // ── Seite 1: Titel = größte Schrift im oberen Bereich ──
  const s1 = seiten[0];
  const fuss = /^alle angaben beruhen/i;
  const oben = s1.items.filter(i => i.y < s1.hoehe * 0.45);
  const maxH = Math.max(...oben.map(i => i.h), 0);
  if(maxH > 0){
    const titelItems = oben.filter(i => i.h >= maxH * 0.85).sort((a, b) => a.y - b.y || a.x - b.x);
    ex.titel = ex27Zeilen(titelItems, s1.breite, false).map(z => z.text).join(' ').replace(/\s+/g, ' ').trim();
  }
  // ── Seite 1: Beschreibung (linke Spalte) und Vorteile („- …“) ──
  const zeilen1 = ex27Zeilen(s1.items.filter(i => i.h < maxH * 0.85 && !fuss.test(i.s)), s1.breite, true);
  const koerperH = (() => { const hs = zeilen1.map(z => z.h).sort((a, b) => a - b); return hs[Math.floor(hs.length / 2)] || 10; })();
  const bullet = /^\s*[-–•▪●■]\s+/;
  let letzte = null;
  for(const z of zeilen1.filter(z => z.sp === 1)){
    if(fuss.test(z.text)) break;
    if(bullet.test(z.text)){ letzte = { y: z.y, text: z.text.replace(bullet, '').trim() }; ex.vorteile.push(letzte); }
    else if(letzte && z.y - letzte.y < koerperH * 2.2 && !/:$/.test(z.text)){ letzte.text = (letzte.text.endsWith('-') ? letzte.text.slice(0, -1) : letzte.text + ' ') + z.text; letzte.y = z.y; }
    else letzte = null;
  }
  ex.vorteile = ex.vorteile.map(v => ex27Norm(v.text)).filter(Boolean);
  const links = zeilen1.filter(z => z.sp === 0 && !fuss.test(z.text) && Math.abs(z.h - koerperH) <= koerperH * 0.35);
  let besch = '';
  for(const z of links){ if(besch.endsWith('-') && /^[a-zäöüß]/.test(z.text)) besch = besch.slice(0, -1) + z.text; else besch += (besch ? ' ' : '') + z.text; }
  ex.beschreibung = ex27Norm(besch);
  // ── Objektinformationen ──
  for(const s of seiten){
    const kopf = s.items.find(i => /^objektinformationen$/i.test(ex27Norm(i.s)));
    if(!kopf) continue;
    ex.erkannt = true;
    const items = s.items.filter(i => i.y > kopf.y + 1 && i.x >= kopf.x - 12 && !fuss.test(i.s));
    const zeilen = ex27Zeilen(items, s.breite, false).filter(z => !fuss.test(z.text));
    const kopfzeilen = [];
    let block = null, provision = null, letzteKV = null, xWert = null;
    const feldSetzen = (label, wert) => {
      label = ex27Norm(label).replace(/:$/, ''); wert = ex27Norm(wert);
      if(!label || !wert) return null;
      const eintrag = [label, wert]; ex.felderListe.push(eintrag);
      const k = ex27Schluessel(label); if(k && ex.felder[k] == null) ex.felder[k] = wert;
      if(/provision|courtage/i.test(label) && !ex.provision) ex.provision = label + ': ' + wert;
      return { eintrag, k };
    };
    const blockZu = () => { if(block){ feldSetzen(block.label, block.wert.join(' ')); block = null; } };
    for(let i = 0; i < zeilen.length; i++){
      const z = zeilen[i], vor = zeilen[i - 1];
      const abstand = vor ? z.y - vor.y : 0, zeilenH = z.h || 10;
      // Provisions-Satz („Unsere Provision beträgt …“), auch über zwei Zeilen
      if(provision !== null){
        if(abstand < zeilenH * 1.9 && !/:$/.test(z.text)){ provision += ' ' + z.text; if(/\.\s*$/.test(z.text)){ ex.provision = ex27Norm(provision); provision = null; } continue; }
        ex.provision = ex27Norm(provision); provision = null;
      }
      if(/^(unsere|die|eine|ihre)?\s*(käufer)?(provision|courtage|maklerprovision)\s+(beträgt|von|in höhe|ist|wird|i\.?\s?h\.?)/i.test(z.text) || /^(für|bei) (den|dem) käufer.*provision/i.test(z.text)){
        blockZu(); letzteKV = null;
        if(/\.\s*$/.test(z.text)) ex.provision = ex27Norm(z.text); else provision = z.text;
        continue;
      }
      // Zweite Zeile eines Werts aus der Tabelle (gleiche Spalte, direkt darunter)
      if(z.zellen.length === 1 && letzteKV && !block && Math.abs(z.x - letzteKV.x) < 8 && z.y - letzteKV.y < zeilenH * 1.9){
        letzteKV.r.eintrag[1] = ex27Norm(letzteKV.r.eintrag[1] + ' ' + z.text);
        if(letzteKV.r.k && ex.felder[letzteKV.r.k] != null) ex.felder[letzteKV.r.k] = letzteKV.r.eintrag[1];
        letzteKV.y = z.y; continue;
      }
      // Tabellenzeile „Feldname   Wert“ (Wert in der Werte-Spalte)
      const z0 = z.zellen[0], z1 = z.zellen[1];
      const istKV = z.zellen.length >= 2 && !/:$/.test(z0.s) && z0.s.length <= 40 &&
        (ex27Schluessel(z0.s) || (xWert != null ? Math.abs(z1.x - xWert) < 10 : z1.x - z0.x > 50)) && !(block && !ex27Schluessel(z0.s) && (xWert == null || Math.abs(z1.x - xWert) >= 10));
      if(istKV){
        blockZu();
        if(xWert == null) xWert = z1.x;
        const r = feldSetzen(z0.s, z.zellen.slice(1).map(x => x.s).join(' '));
        letzteKV = r ? { r, x: z1.x, y: z.y } : null;
        continue;
      }
      letzteKV = null;
      // Abschnitt „Zustand:“ / „Heizsystem:“ … mit Wert in den Zeilen darunter
      const m = z.text.match(/^([^:]{2,40}):\s*(.*)$/);
      if(m && (ex27Schluessel(m[1]) || /^[A-ZÄÖÜ]/.test(m[1]))){
        blockZu();
        block = { label: m[1], wert: m[2] ? [m[2]] : [] };
        continue;
      }
      if(block){
        if(abstand > zeilenH * 2.6 && block.wert.length) blockZu();
        else { block.wert.push(z.text); continue; }
      }
      if(ex.felderListe.length === 0) kopfzeilen.push(z.text);
    }
    blockZu();
    if(provision) ex.provision = ex27Norm(provision);
    // Kopf: Objektart, Straße, PLZ Ort
    for(const k of kopfzeilen){
      const p = k.match(/^(\d{5})\s+(.+)$/);
      if(p){ ex.plz = p[1]; ex.ort = p[2].trim(); continue; }
      if(!ex.adresse && /\d+\s*[a-zA-Z]?$/.test(k) && /[a-zäöüß]{3}/.test(k) && !/^\d/.test(k)) { ex.adresse = k.replace(/\s{2,}/g, ' '); continue; }
      if(!ex.typ) ex.typ = k;
    }
    break;
  }
  // Längere Texte auf den Folgeseiten (Objektbeschreibung, Lage, Ausstattung, Sonstiges)
  const UEB = /^(objektbeschreibung|beschreibung|lagebeschreibung|lage|mikrolage|makrolage|infrastruktur|ausstattung|ausstattungsbeschreibung|sonstiges|sonstige angaben|weitere informationen)$/i;
  ex.abschnitte = [];
  for(const s of seiten.slice(1)){
    let akt = null;
    for(const z of ex27Zeilen(s.items, s.breite, true)){
      if(fuss.test(z.text)){ akt = null; continue; }
      if(z.zellen.length === 1 && UEB.test(z.text)){ akt = { titel: z.text, sp: z.sp, y: z.y, h: z.h, text: '' }; ex.abschnitte.push(akt); continue; }
      if(!akt) continue;
      if(z.sp !== akt.sp || z.y - akt.y > Math.max(akt.h, z.h) * 3.2){ akt = null; continue; }
      akt.text = akt.text.endsWith('-') && /^[a-zäöüß]/.test(z.text) ? akt.text.slice(0, -1) + z.text : (akt.text ? akt.text + ' ' : '') + z.text;
      akt.y = z.y; akt.h = z.h;
    }
  }
  ex.abschnitte = ex.abschnitte.map(a => ({ titel: a.titel, text: ex27Norm(a.text) })).filter(a => a.text.length > 40);
  if(!ex.beschreibung){ const b = ex.abschnitte.find(a => /beschreibung/i.test(a.titel)); if(b) ex.beschreibung = b.text; }
  // Adresse/Ort zur Not aus einer Zeile „Straße Nr., PLZ Ort“ (z. B. Grundriss-Seite)
  if(!ex.plz){
    const m = textGesamt.match(/([A-ZÄÖÜ][^\n,]{2,50}?\s\d{1,4}\s?[a-zA-Z]?),\s*(\d{5})\s+([A-ZÄÖÜ][^\n]{2,50}?)(?:\s{2,}|\n|$)/);
    if(m){ ex.adresse = ex.adresse || m[1].trim(); ex.plz = m[2]; ex.ort = m[3].trim(); }
  }
  if(status) status('Titelbild wird übernommen …');
  ex.bild = await ex27Bild(s1) || (seiten[1] ? await ex27Bild(seiten[1]) : null);
  ex.objektart = ex27Art(ex.typ, ex.titel + ' ' + ex.beschreibung);
  return ex;
}
// Zustand → Auswahl der Objektakte
function ex27Zustand(t){
  t = String(t || '').toLowerCase();
  if(/\bneu|erstbezug|neuwertig/.test(t)) return 'neuwertig';
  if(/saniert|modernisiert|renoviert|kernsan/.test(t) && !/bedürftig/.test(t)) return 'saniert';
  if(/sanierungsbed|abriss|rohbau/.test(t)) return 'sanierungsbeduerftig';
  if(/renovierungsbed|modernisierungsbed/.test(t)) return 'renovierungsbeduerftig';
  if(/gut|gepflegt|ordentlich|einwandfrei/.test(t)) return 'gepflegt';
  return null;
}
// Daten ins Objekt übernehmen (neu oder vorhandenes aktualisieren)
function ex27InsObjekt(o, ex, datei){
  const F = ex.felder || {};
  const quelle = 'Exposé' + (F.referenz ? ' Ref. ' + F.referenz : '') + ' (' + datei + ')';
  if(ex.titel) o.akqTitel = ex.titel;
  if(ex.adresse) o.adresse = ex.adresse;
  if(ex.plz) o.ort = ex.plz + ' ' + ex.ort;
  if(ex.objektart && ex.objektart !== 'Sonstiges') o.objektart = ex.objektart; else if(!o.objektart) o.objektart = 'Sonstiges';
  if(ex.typ) o.objekttyp = ex.typ;
  const zahl = k => F[k] != null ? ex27Zahl(F[k]) : null;
  const kp = zahl('kaufpreis'); if(kp > 1000) o.kaufpreis = kp;
  const km = zahl('kaltmiete'); if(km > 0 && !kp){ o.kaufpreis = km; o.auftragsart = 'vermietung'; }
  const wf = zahl('wohnflaeche'); if(wf > 0) o.wohnflaeche = wf;
  const gs = zahl('grundstueck'); if(gs > 0) o.grundstueck = gs;
  const nf = zahl('nutzflaeche'); if(nf > 0) o.nutzflaeche = nf;
  const zi = zahl('zimmer'); if(zi > 0) o.zimmer = zi;
  const bj = zahl('baujahr'); if(bj > 1500 && bj < 2100) o.baujahr = bj;
  if(F.etage) o.etage = F.etage;
  const hg = zahl('hausgeld'); if(hg > 0) o.hausgeld = hg;
  if(F.referenz) o.referenz = F.referenz;
  if(ex.provision) o.provisionText = ex.provision;
  if(ex.beschreibung) o.details = ex.beschreibung;
  o.vorteile = ex.vorteile || [];
  const energie = [F.heizung, F.energieverbrauch ? 'Endenergieverbrauch ' + F.energieverbrauch : '', F.energiebedarf ? 'Endenergiebedarf ' + F.energiebedarf : '', F.energieausweis, F.energieklasse ? 'Klasse ' + F.energieklasse : ''].filter(Boolean).join(' · ');
  o.expose = { datei, eingelesen: Date.now(), titel: ex.titel, typ: ex.typ, felder: ex.felderListe, vorteile: ex.vorteile, beschreibung: ex.beschreibung, abschnitte: (ex.abschnitte || []).filter(a => a.text !== ex.beschreibung), provision: ex.provision, seiten: ex.seitenzahl };
  // Titelbild nur einmal speichern (o.titelbild); Akquise-Karten zeigen es über aq2Fotos als erstes Foto
  if(ex.bild && ex.bild.url) o.titelbild = ex.bild.url;
  // Objektakte: Angaben mit Herkunft „Eigentümerangabe“ (so steht es im Exposé) und Quelle
  try{
    if(typeof an24Setzen === 'function'){
      const setz = (k, wert) => { if(wert == null || wert === '' || wert === 0) return; an24Setzen(o, k, { wert, herkunft: 'eigentuemer', quelle, von: 'manuell', notiz: 'aus dem Exposé eingelesen' }, { aktivierenWennLeer: true }); };
      setz('wohnflaeche', wf); setz('grundstueck', gs); setz('nutzflaeche', nf); setz('zimmer', zi); setz('baujahr', bj); setz('kaufpreis', kp > 1000 ? kp : null); setz('hausgeld', hg);
      setz('zustand', ex27Zustand(F.zustand)); setz('energie', energie || null);
    }
  }catch(e){ console.error('Exposé → Akte', e); }
  const altN = String(o.notizen || '').replace(/(<br>)?📄 Aus Exposé „[^“]*“ eingelesen am [^<]*/g, '').replace(/^<br>/, '');
  o.notizen = [/^Automatisch aus Exposé/.test(altN) ? '' : altN, `📄 Aus Exposé „${mc24E(datei)}“ eingelesen am ${new Date().toLocaleDateString('de-DE')} – bitte kurz gegenprüfen.`].filter(Boolean).join('<br>');
  return o;
}
function ex27Doppelt(ex){
  const n = s => String(s || '').toLowerCase().replace(/str\.|strasse/g, 'straße').replace(/[^a-z0-9äöüß]/g, '');
  return (db.objekte || []).find(o => (ex.felder && ex.felder.referenz && o.referenz === ex.felder.referenz) ||
    (ex.adresse && ex.plz && n(o.adresse) === n(ex.adresse) && String(o.ort || '').includes(ex.plz)));
}
// Neuer Exposé-Import (ersetzt den alten; Rückfall auf das alte Lesen bei unbekanntem Aufbau)
exposesImportieren = async function(files){
  const dateien = Array.from(files || []).filter(f => /pdf$/i.test(f.name) || f.type === 'application/pdf');
  if(!dateien.length) return;
  const ziel = aktuelleAnsicht === 'objekte' && typeof OB26 !== 'undefined' ? OB26.aktiv : 'akquise';
  const statusEl = document.createElement('div'); statusEl.className = 'bottom-confirm'; statusEl.id = 'exposeStatus'; statusEl.innerHTML = '<span id="exposeStatusText">Starte Exposé-Import …</span>'; document.body.appendChild(statusEl);
  const setStatus = t => { const el = document.getElementById('exposeStatusText'); if(el) el.textContent = t; };
  const neu = [], aktualisiert = [], fehler = [];
  for(let i = 0; i < dateien.length; i++){
    const d = dateien[i];
    try{
      setStatus(`Datei ${i + 1} von ${dateien.length}: ${d.name} – lese Aufbau …`);
      let ex = null;
      try{ ex = await ex27Lesen(d, setStatus); }catch(e){ console.error('ex27', e); }
      if(!ex || !ex.erkannt){
        // unbekannter Aufbau oder Scan: altes Verfahren (Text bzw. Texterkennung)
        setStatus(`Datei ${i + 1} von ${dateien.length}: ${d.name} – lese Text …`);
        const text = await pdfTextAuslesen(d, setStatus);
        const dt = parseExposeText(text);
        ex = Object.assign({ titel: '', vorteile: [], beschreibung: '', felderListe: [], felder: {} }, ex || {}, { adresse: dt.adresse || '', plz: (String(dt.ort || '').match(/\d{5}/) || [])[0] || '', ort: String(dt.ort || '').replace(/^\d{5}\s*/, ''), objektart: dt.objektart, erkannt: false });
        ['kaufpreis', 'wohnflaeche', 'grundstueck', 'baujahr', 'zimmer', 'hausgeld', 'zustand'].forEach(k => { if(dt[k]) ex.felder[k] = String(dt[k]); });
        if(dt.heizsystem) ex.felder.heizung = dt.heizsystem;
        if(!ex.titel){ const t = String(text || '').split('\n').map(x => x.trim()).find(x => x.length > 8 && x.length < 120); if(t) ex.titel = t; }
      }
      const dupe = ex27Doppelt(ex);
      const o = dupe || { id: uid(), createdAt: Date.now(), eigentuemerId: null, verkaeuferName: '', verkaeuferTelefon: '', verkaeuferEmail: '', status: ziel === 'betreut' ? 'auftrag' : 'neu', prioritaet: 'mittel', verlauf: [], quelle: 'Exposé', bereich: ziel };
      if(!dupe){ if(ziel === 'betreut') o.herkunftBereich = 'direkt'; db.objekte.push(o); }
      else if(ziel === 'betreut' && !o.bereichFest){
        // eigenes Exposé zu einem bekannten Lead → Auftrag, wandert zu „betreut“
        if(typeof OB26_BETREUT_STATUS !== 'undefined' && !OB26_BETREUT_STATUS.includes(o.status)) o.status = 'auftrag';
        o.bereich = 'betreut';
      }
      ex27InsObjekt(o, ex, d.name);
      if(!o.adresse && !o.akqTitel) o.adresse = typeof dateinameAlsObjektname === 'function' ? dateinameAlsObjektname(d.name) : d.name.replace(/\.pdf$/i, '');
      try{ if(typeof aqLog === 'function') aqLog(o, 'info', dupe ? `Exposé „${d.name}“ erneut eingelesen – Daten aktualisiert` : `Aus Exposé „${d.name}“ angelegt`); }catch(e){}
      (dupe ? aktualisiert : neu).push({ o, ex });
    }catch(e){ console.error('Exposé', d.name, e); fehler.push(d.name); }
  }
  statusEl.remove();
  ['exposeInput', 'exposeInput2'].forEach(id => { const el = document.getElementById(id); if(el) el.value = ''; });
  save(); renderMain();
  ex27Ergebnis(neu, aktualisiert, fehler, ziel);
};
function ex27Ergebnis(neu, akt, fehler, ziel){
  const e = s => typeof mc24E === 'function' ? mc24E(s) : String(s || '');
  const zeile = ({ o, ex }, alt) => `<div class="ex27-z">${ex27Src(o.titelbild) ? `<img src="${ex27Src(o.titelbild)}" alt="">` : '<div class="ex27-ohne">kein Bild</div>'}<div><b>${e(o.akqTitel || o.adresse)}</b>${alt ? ' <span class="chip">aktualisiert</span>' : ''}
    <div class="mc24-muted">${e([o.adresse, o.ort].filter(Boolean).join(', '))} · ${e(o.objekttyp || o.objektart)}</div>
    <div>${o.kaufpreis ? Number(o.kaufpreis).toLocaleString('de-DE') + ' €' : '<span class="mc24-rot">Preis fehlt</span>'}${o.wohnflaeche ? ' · ' + o.wohnflaeche + ' m²' : ''}${o.zimmer ? ' · ' + o.zimmer + ' Zi.' : ''}${o.baujahr ? ' · Bj. ' + o.baujahr : ''}${o.hausgeld ? ' · Hausgeld ' + o.hausgeld + ' €' : ''}</div>
    <div class="mc24-muted">${(ex.vorteile || []).length} Vorteile · ${(ex.felderListe || []).length} Angaben aus „Objektinformationen“${ex.erkannt ? '' : ' · <span class="mc24-rot">Aufbau nicht erkannt – Werte bitte prüfen</span>'}</div></div></div>`;
  const alle = neu.length + akt.length;
  mc24Modal(`<h3>📄 ${alle} Exposé${alle === 1 ? '' : 's'} eingelesen</h3>
    <p>${neu.length ? `${neu.length} neu bei <b>${ziel === 'betreut' ? '🏠 Objekte, die ich betreue' : '🎯 Akquise-Objekte'}</b>` : ''}${neu.length && akt.length ? ' · ' : ''}${akt.length ? `${akt.length} schon vorhanden – aktualisiert statt doppelt angelegt` : ''}.</p>
    ${neu.map(x => zeile(x, false)).join('')}${akt.map(x => zeile(x, true)).join('')}
    ${fehler.length ? `<div class="mc24-hinweis">Nicht lesbar: ${fehler.map(e).join(', ')}</div>` : ''}
    ${ziel === 'betreut' ? '<p class="mc24-muted">Der Eigentümer steht nicht im Exposé – bitte im Objekt eintragen.</p>' : ''}
    <div class="modal-actions"><span></span><div class="right">${neu.length + akt.length === 1 ? `<button class="secondary" onclick="schliesseModal();ob24Oeffnen('${(neu[0] || akt[0]).o.id}')">Objektakte öffnen</button>` : ''}<button onclick="schliesseModal()">OK</button></div></div>`, 680);
}
// ── Anzeige: Exposé-Karte mit Titelbild oben in der Objektakte ──
function ex27KarteHtml(o){
  if(!o.titelbild && !o.expose) return '';
  const e = s => mc24E(s);
  const ex = o.expose || {};
  const felder = (ex.felder || []).filter(([l]) => !/^referenz/i.test(l));
  return `<div class="mc24-karte breit ex27-karte"><h3>📄 Exposé${ex.datei ? ` <span class="mc24-muted" style="font-weight:400;font-size:12px;">${e(ex.datei)} · ${new Date(ex.eingelesen).toLocaleDateString('de-DE')}</span>` : ''}<span class="sp"></span>${o.titelbild ? `<button class="tiny secondary" onclick="ex27BildWeg('${o.id}')">Titelbild entfernen</button>` : ''}</h3>
    <div class="ex27-oben">${ex27Src(o.titelbild) ? `<img class="ex27-bild" src="${ex27Src(o.titelbild)}" alt="Titelbild">` : ''}
      <div class="ex27-text"><div class="ex27-titel">${e(o.akqTitel || ex.titel || '')}</div>
        ${o.referenz ? `<div class="mc24-muted">Referenz-Nr. ${e(o.referenz)}</div>` : ''}
        ${(o.vorteile || []).length ? `<ul class="ex27-vorteile">${o.vorteile.map(v => `<li>${e(v)}</li>`).join('')}</ul>` : ''}</div></div>
    ${ex.beschreibung ? `<p class="ex27-besch">${e(ex.beschreibung)}</p>` : ''}
    ${(ex.abschnitte || []).map(a => `<div class="ex27-abschnitt"><b>${e(a.titel)}</b><p class="ex27-besch">${e(a.text)}</p></div>`).join('')}
    ${felder.length ? `<details class="ex27-info" open><summary>Objektinformationen (${felder.length})</summary><table class="mc24-tab kv">${ex.typ ? `<tr><td>Objektart</td><td>${e(ex.typ)}</td></tr>` : ''}${felder.map(([l, w]) => `<tr><td>${e(l)}</td><td>${e(w)}</td></tr>`).join('')}${ex.provision ? `<tr><td>Provision</td><td>${e(ex.provision)}</td></tr>` : ''}</table></details>` : ''}
  </div>`;
}
function ex27BildWeg(id){ const o = findObjekt(id); if(!o) return; delete o.titelbild; save(); renderMain(); }
// Akquise-Karten/Lead-Ansicht: Titelbild als erstes Foto
const _ex27Fotos = aq2Fotos;
aq2Fotos = function(o){ const f = _ex27Fotos.apply(this, arguments); return o && ex27Src(o.titelbild) ? [o.titelbild].concat(f.filter(x => x !== o.titelbild)) : f; };
const _ex27FotoWeg = aq2FotoWeg;
aq2FotoWeg = function(){
  const o = findObjekt(AQ2.sel);
  if(o && o.titelbild){ if(!AQ2.fotoIdx){ delete o.titelbild; AQ2.fotoIdx = 0; save(); aq2Liste(); return; } AQ2.fotoIdx--; }
  return _ex27FotoWeg.apply(this, arguments);
};
const _ex27Akte = ob24Render;
ob24Render = function(main){
  const r = _ex27Akte.apply(this, arguments);
  try{
    const o = findObjekt(MC24.akteId); if(!o) return r;
    const grid = main.querySelector('.mc24-akte'); const html = ex27KarteHtml(o);
    if(grid && html) grid.insertAdjacentHTML('afterbegin', html);
    const ic = main.querySelector('.aq-kopf .ic'); const bild = ex27Src(o.titelbild || (o.fotos || [])[0]);
    if(ic && bild){ ic.innerHTML = `<img src="${bild}" alt="">`; ic.classList.add('ex27-ic'); }
  }catch(e){ console.error('ex27 Akte', e); }
  return r;
};
// ── Objekte-Liste: Titelbild klein vorn, Exposé-Titel fett ──
const _ex27Tabelle = renderObjekteTabelle;
renderObjekteTabelle = function(){
  const r = _ex27Tabelle.apply(this, arguments);
  try{
    document.querySelectorAll('#objTabelle tbody tr.row').forEach(tr => {
      const m = /oeffneObjektModal\('([^']+)'\)/.exec(tr.getAttribute('onclick') || ''); if(!m) return;
      const o = findObjekt(m[1]); if(!o) return;
      const zelle = tr.children[1]; if(!zelle) return;
      const bild = ex27Src(o.titelbild || (o.fotos || [])[0]);
      if(bild && !zelle.querySelector('.ex27-mini')) zelle.insertAdjacentHTML('afterbegin', `<img class="ex27-mini" src="${bild}" alt="" loading="lazy">`);
      if(o.expose && o.akqTitel){
        const b = zelle.querySelector('b'); const sp = Array.from(zelle.querySelectorAll('span')).filter(x => /--muted/.test(x.getAttribute('style') || '')).pop();
        if(b) b.textContent = o.akqTitel;
        if(sp) sp.textContent = [o.adresse, o.objekttyp || o.objektart, o.ort].filter(Boolean).join(' · ');
      }
    });
  }catch(e){}
  return r;
};
// ── Objekt-Dialog: Titel bearbeitbar ──
const _ex27Modal = oeffneObjektModal;
oeffneObjektModal = function(id){
  const r = _ex27Modal.apply(this, arguments);
  try{
    const o = id ? findObjekt(id) : null;
    const adr = document.getElementById('m_adresse'); const reihe = adr ? adr.closest('.field-row') : null;
    if(reihe && !document.getElementById('m_titel27')){
      reihe.insertAdjacentHTML('beforebegin', `<div><label>Titel${o && o.expose ? ' (aus dem Exposé)' : ''}</label><input id="m_titel27" value="${typeof esc === 'function' ? esc(o ? o.akqTitel || '' : '') : ''}" placeholder="z. B. Ruhig wohnen mit Terrasse ins Grüne"></div>`);
    }
  }catch(e){}
  return r;
};
const _ex27Speichere = speichereObjekt;
speichereObjekt = function(id){
  const t = document.getElementById('m_titel27'); const titel = t ? t.value.trim() : null;
  const vorher = new Set((db.objekte || []).map(o => o.id));
  const r = _ex27Speichere.apply(this, arguments);
  try{ if(titel !== null){ const o = id ? findObjekt(id) : (db.objekte || []).find(x => !vorher.has(x.id)); if(o && (o.akqTitel || '') !== titel){ o.akqTitel = titel; save(); if(aktuelleAnsicht === 'objekte' || aktuelleAnsicht === 'akte') renderMain(); } } }catch(e){}
  return r;
};
