/* MaklerCockpit v24 – Investments: Ankaufprofile, Kalkulation (Ist/Potenzial), Szenarien, Stress, maximaler Kaufpreis,
   Unterlagenprüfung, Vergleich und Entscheidung. Rechenkern: invest24_kern.js (alles vor Steuern). */

const IV24 = { tab: 'pruefung', sel: null, vergleich: {}, vergleichAnsicht: 'eigene', profilSel: null, max: null };
const IV24_ENTSCHEIDUNG = [['weiterpruefen', 'Weiter prüfen'], ['verhandeln', 'Verhandeln'], ['kaufentscheidung', 'Kaufentscheidung getroffen'], ['ablehnen', 'Ablehnen']];
const IV24_ENTSCHEIDUNG_TEXT = Object.fromEntries(IV24_ENTSCHEIDUNG);
const IV24_UNT_STATUS = [['fehlt', 'fehlt'], ['vorhanden', 'vorhanden'], ['geprueft', 'geprüft'], ['rueckfrage', 'Rückfrage']];
const IV24_POT_HERKUNFT = [['mietspiegel', 'Mietspiegel-Einordnung'], ['marktanalyse', 'Marktanalyse (Angebote)'], ['gutachten', 'Gutachten'], ['eigentuemer', 'Eigentümerangabe'], ['schaetzung', 'eigene Schätzung']];
function iv24Db(){ if(!db.invest24) db.invest24 = { profile: [], pruefungen: [] }; return db.invest24; }
function iv24P(id){ return iv24Db().pruefungen.find(p => p.id === (id || IV24.sel)) || null; }
function iv24ErgebnisVon(p, ansicht){ return iv24Rechnen(p.e, ansicht || p.ansicht || 'ist'); }
function iv24Berlin(o){ const t = String((o && o.ort) || '') + ' ' + String((o && o.adresse) || ''); const plz = (t.match(/\b1[0-4]\d{3}\b/) || [])[0]; return /berlin/i.test(t) || (plz && Number(plz) >= 10115 && Number(plz) <= 14199); }

// ── Anlegen (Daten aus der Objektakte übernehmen, nichts doppelt erfassen) ──
function iv24Neu(oid){
  const offen = iv24Db().pruefungen.find(p => p.objektId === oid && !p.objektGeloescht && !(p.entscheidung && ['ablehnen', 'kaufentscheidung'].includes(p.entscheidung.status)));
  if(oid && offen){ iv24Oeffnen(offen.id); akqToast('Laufende Prüfung geöffnet'); return; }
  const obj = (db.objekte || []).slice().sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
  mc24Modal(`<h3>💶 Neue Investmentprüfung</h3><label>Objekt</label><select id="iv_o">${obj.map(o => `<option value="${o.id}" ${o.id === oid ? 'selected' : ''}>${mc24E(mc24Titel(o))}${o.ort ? ' · ' + mc24E(mc24OrtKurz(o)) : ''}</option>`).join('')}</select>
    <div class="mc24-muted">Kaufpreis, Miete, Hausgeld und Flächen werden aus der Objektakte übernommen (mit Herkunft). Steuer wird nicht gerechnet – alle Ergebnisse vor Steuern.</div>
    <div class="modal-actions"><div></div><div class="right"><button class="secondary" onclick="schliesseModal()">Abbrechen</button><button onclick="iv24Anlegen(document.getElementById('iv_o').value)">Anlegen</button></div></div>`, 600);
}
function iv24Anlegen(oid, ohneOeffnen){
  const o = findObjekt(oid); if(!o) return null;
  const be = iv24Berlin(o);
  const e = {
    kaufpreis: an24Wert(o, 'kaufpreis'), wohnflaeche: an24Wert(o, 'wohnflaeche'),
    nebenkosten: [
      { id: uid(), name: 'Grunderwerbsteuer', art: 'prozent', wert: be ? 6.0 : 6.5, hinweis: `Vorschlag ${be ? 'Berlin 6,0 %' : 'Brandenburg 6,5 %'} (Recherche 08.11.2026) – bitte prüfen` },
      { id: uid(), name: 'Notar und Grundbuch', art: 'prozent', wert: 2.0, hinweis: 'Annahme ca. 2 % – bitte prüfen' },
      { id: uid(), name: 'Maklerprovision', art: 'prozent', wert: 3.57, hinweis: 'Annahme 3,57 % – 0, wenn ohne Makler' }
    ],
    sanierung: null, finanzierungskosten: null, eigenkapital: null,
    darlehenModus: 'rest', darlehenQuote: 100, darlehenBetrag: null, zins: 3.91, zinsHinweis: 'Vorschlag: 10 Jahre Sollzins laut Recherche 08.11.2026 – tagesaktuell prüfen', tilgungModus: 'prozent', tilgung: 2, rate: null, zinsbindung: 10, anschlusszins: null, anschlusstilgung: null,
    miete: an24Wert(o, 'miete_ist'), sonstigeEinnahmen: null, mietausfall: 2, mietsteigerung: 0,
    hausgeld: an24Wert(o, 'hausgeld'), hausgeldUmlagefaehig: an24Wert(o, 'hausgeld_umlage'), ruecklage: an24Wert(o, 'ruecklage_zufuehrung'),
    verwaltung: null, sonstigeKosten: null, instandhaltungModus: 'zusaetzlich', instandhaltung: null, kostensteigerung: 0, jahre: 15,
    potenzial: { miete: null, massnahmen: null, zeitbedarfMonate: null, leerstandMonate: null, herkunft: '', voraussetzung: '', pruef: 'ungeprueft', rechtlichGeklaert: 'unbekannt' }
  };
  const ma = ob24LetzteAnalyse(o);
  const p = { id: uid(), objektId: oid, name: mc24Titel(o), erstellt: Date.now(), ansicht: 'ist', analyseId: ma ? ma.id : null, profilId: (iv24Db().profile[0] || {}).id || null, e,
    herkunft: Object.fromEntries(['kaufpreis', 'miete_ist', 'hausgeld', 'hausgeld_umlage', 'ruecklage_zufuehrung', 'wohnflaeche'].map(k => { const a = an24Aktiv(o, k); return [k, a ? { herkunft: a.herkunft, pruef: a.pruef, quelle: a.quelle } : null]; })),
    szenarien: JSON.parse(JSON.stringify(IV24_SZENARIEN_STD)), ziel: { art: 'cashflow', wert: 0, finanzierungGedeckt: false },
    unterlagen: iv24UnterlagenListe(o.objektart).map(n => ({ id: uid(), name: n, status: 'fehlt', dokId: null, fundstelle: '', notiz: '' })),
    entscheidung: null, entscheidungen: [], profilChecks: {} };
  iv24Db().pruefungen.push(p); save();
  if(!ohneOeffnen){ schliesseModal(); iv24Oeffnen(p.id); }
  return p;
}
function iv24Oeffnen(id){ schliesseModal(); IV24.sel = id; IV24.tab = 'pruefung'; IV24.max = null; wechsleAnsicht('investments24'); }
function iv24Set(pfad, wert){
  const p = iv24P(); if(!p) return;
  const teile = pfad.split('.'); let x = p;
  for(let i = 0; i < teile.length - 1; i++){ if(x[teile[i]] == null) x[teile[i]] = {}; x = x[teile[i]]; }
  x[teile[teile.length - 1]] = wert; IV24.max = null;
  save(); renderMain();
}
function iv24Num(v){ return mc24N(v); }

// ── Seite ──
function iv24Render(main){
  const d = iv24Db();
  if(!iv24P() && d.pruefungen.length) IV24.sel = d.pruefungen.slice().sort((a, b) => (b.erstellt || 0) - (a.erstellt || 0))[0].id;
  main.innerHTML = `
  <div class="aq-kopf"><div class="ic">${IC.investments24 || ''}</div><div><h1>Investments</h1><div class="sub">Ankaufprofil, vollständige Kalkulation vor Steuern, Szenarien, maximaler Kaufpreis, Unterlagen und Entscheidung.</div></div>
    <div class="knoepfe"><button class="secondary" onclick="wechsleAnsicht('jv-rechner')" title="Bisheriger Deal-Rechner">Deal-Rechner</button><button onclick="iv24Neu()">${IC.plus || '+'} Neue Prüfung</button></div></div>
  <div class="vl-tabs km-tabs">${[['pruefung', '🧮 Prüfungen (' + d.pruefungen.length + ')'], ['vergleich', '⚖️ Vergleich'], ['profile', '🎯 Ankaufprofile (' + d.profile.length + ')']].map(([k, l]) => `<button class="${IV24.tab === k ? 'an' : ''}" onclick="IV24.tab='${k}';renderMain()">${l}</button>`).join('')}</div>
  <div id="ivInhalt">${IV24.tab === 'vergleich' ? iv24VergleichHtml() : IV24.tab === 'profile' ? iv24ProfileHtml() : iv24PruefungenHtml()}</div>`;
}
function iv24PruefungenHtml(){
  const l = iv24Db().pruefungen.slice().sort((a, b) => (b.erstellt || 0) - (a.erstellt || 0));
  const p = iv24P();
  return `<div class="ma24-layout"><div class="ma24-liste">${l.map(x => { const r = iv24ErgebnisVon(x); return `<div class="ma24-lz ${x.id === IV24.sel ? 'an' : ''}" onclick="IV24.sel='${x.id}';IV24.max=null;renderMain()"><b>${mc24E(x.name)}</b><small>${mc24Datum(x.erstellt)} · ${x.ansicht === 'potenzial' ? 'Potenzial' : 'Ist'}${x.objektGeloescht ? ' · <span class="mc24-rot">Objekt gelöscht</span>' : ''} · ${mc24E(x.entscheidung ? IV24_ENTSCHEIDUNG_TEXT[x.entscheidung.status] : 'offen')}</small><small>${r.cashflowMonat != null ? 'Cashflow ' + mc24Eur(r.cashflowMonat) + '/Monat' : 'Cashflow nicht berechenbar'} · brutto ${mc24Pz(r.bruttomietrendite)}</small></div>`; }).join('') || '<div class="vl-leer">Noch keine Prüfung. „Neue Prüfung“ oder aus der Objektakte.</div>'}</div>
    <div class="ma24-haupt">${p ? iv24DetailHtml(p) : ''}</div></div>`;
}
function iv24Kachel(l, w, s, warn){ return `<div class="iv24-k ${warn ? 'warn' : ''}"><small>${l}</small><b>${w}</b>${s ? `<small>${s}</small>` : ''}</div>`; }
function iv24Datenqualitaet(p, r){
  const g = [], o = findObjekt(p.objektId); let pk = 0;
  const he = k => (p.herkunft || {})[k];
  if(r.fehlend.length) g.push('fehlende Eingaben: ' + r.fehlend.join(', ')); else pk += 2;
  const miete = he('miete_ist'); if(miete && (miete.herkunft === 'belegt' || miete.pruef === 'geprueft')){ pk++; g.push('Ist-Miete belegt/geprüft'); } else g.push('Ist-Miete nicht belegt');
  const hg = he('hausgeld'); if(p.e.hausgeld && hg && (hg.herkunft === 'belegt' || hg.pruef === 'geprueft')){ pk++; g.push('Hausgeld belegt/geprüft'); } else if(p.e.hausgeld) g.push('Hausgeld nicht belegt');
  const u = p.unterlagen || [], gp = u.filter(x => x.status === 'geprueft').length;
  if(u.length){ if(gp / u.length >= 0.6){ pk++; g.push(`${gp} von ${u.length} Unterlagen geprüft`); } else g.push(`nur ${gp} von ${u.length} Unterlagen geprüft`); }
  if(o && an24Konflikte(o).length) { pk--; g.push('widersprüchliche Objektangaben'); }
  return { stufe: pk >= 4 ? 'hoch' : pk >= 2 ? 'mittel' : 'niedrig', gruende: g };
}
function iv24DetailHtml(p){
  const o = findObjekt(p.objektId), e = p.e, r = iv24ErgebnisVon(p), rIst = iv24Rechnen(e, 'ist'), rPot = iv24Rechnen(e, 'potenzial');
  const dq = iv24Datenqualitaet(p, r);
  const prof = iv24Db().profile.find(x => x.id === p.profilId);
  const pr = prof ? iv24ProfilPruefen(prof, { objektart: o ? o.objektart : null, ort: o ? o.ort : '', vermietung: o ? an24Wert(o, 'vermietung') : null }, r) : null;
  const unt = (p.unterlagen || []).filter(x => x.status === 'fehlt' || x.status === 'rueckfrage');
  const offen = r.fehlend.map(f => f + ' fehlt').concat(r.warnungen).concat(unt.length ? [`${unt.length} Unterlage(n) fehlen oder mit Rückfrage`] : []).concat(pr && pr.mussVerletzt ? [`${pr.mussVerletzt} Muss-Kriterium/-Kriterien des Ankaufprofils nicht erfüllt`] : []);
  const dis = '';
  const nf = (pfad, l, w, einheit, ph, hinweis) => `<div><label>${l}${einheit ? ' (' + einheit + ')' : ''}</label><input inputmode="decimal" value="${mc24E(mc24Fmt(w))}" placeholder="${mc24E(ph || 'unbekannt')}" onchange="iv24Set('${pfad}', iv24Num(this.value))">${hinweis ? `<small class="mc24-muted">${mc24E(hinweis)}</small>` : ''}</div>`;
  const her = k => { const h = (p.herkunft || {})[k]; return h ? `Objektakte: ${an24L(AN24_HERKUNFT, h.herkunft)}${h.pruef === 'geprueft' ? ', geprüft' : ''}` : ''; };
  const pot = e.potenzial || {};
  return `<div class="ma24-kopf"><div><h2>${mc24E(p.name)}</h2><div class="mc24-muted">${o ? mc24E([o.objektart, o.ort].filter(Boolean).join(' · ')) : 'Objekt gelöscht'} · angelegt ${mc24Datum(p.erstellt)} · alle Werte vor Steuern</div></div>
    <div class="mc24-knoepfe">${o ? `<button class="tiny secondary" onclick="ob24Oeffnen('${o.id}')">📁 Akte</button>` : ''}${p.analyseId ? `<button class="tiny secondary" onclick="ma24Oeffnen('${p.analyseId}')">📊 Marktanalyse</button>` : ''}<button class="tiny secondary" onclick="iv24Loeschen('${p.id}')">🗑</button></div></div>
  <div class="iv24-ansicht"><span>Aktive Ansicht:</span>${[['ist', 'Ist-Zustand'], ['potenzial', 'Potenzial']].map(([k, l]) => `<button class="${p.ansicht === k ? 'an' : ''}" onclick="iv24Set('ansicht','${k}')">${l}</button>`).join('')}
    <span class="mc24-muted">${p.ansicht === 'potenzial' ? (rPot.potenzialGesichert ? 'Potenzialannahmen aktiv (geprüft, rechtlich geklärt).' : '⚠️ Potenzialannahmen aktiv – nicht gesichert.') : 'Nur Ist-Miete und Ist-Kosten – keine Potenzialannahmen.'}</span></div>
  <div class="iv24-kacheln">
    ${iv24Kachel('Gesamtkapitalbedarf', mc24Eur(r.gesamtkapitalbedarf), 'Kaufpreis ' + mc24Eur(r.kaufpreis) + ' + NK ' + mc24Eur(r.nebenkosten.summe))}
    ${iv24Kachel('Eigenkapital eingesetzt', mc24Eur(r.eigenkapitalEingesetzt), 'Darlehen ' + mc24Eur(r.darlehen))}
    ${iv24Kachel('Finanzierungslücke', mc24Eur(r.finanzierungsluecke), r.finanzierungsluecke > 0.5 ? 'nicht gedeckt!' : 'gedeckt', r.finanzierungsluecke > 0.5)}
    ${iv24Kachel('Cashflow vor Steuern', r.cashflowMonat == null ? 'nicht berechenbar' : mc24Eur(r.cashflowMonat) + '/Monat', r.cashflowMonat == null ? mc24E(r.fehlend.join(', ')) : 'Jahr 1 · Vermögensaufbau Tilgung ' + mc24Eur(r.vermoegensaufbauMonat) + '/Monat', r.cashflowMonat != null && r.cashflowMonat < 0)}
    ${iv24Kachel('Bruttomietrendite', mc24Pz(r.bruttomietrendite), r.kaufpreisfaktor ? 'Faktor ' + mc24Zahl(r.kaufpreisfaktor, 1) : '')}
    ${iv24Kachel('Nettorendite vor Finanzierung', mc24Pz(r.nettorendite), 'Nenner: Kaufpreis + NK + Maßnahmen')}
    ${iv24Kachel('EK-Cashflow-Rendite', r.ekRendite == null ? 'nicht definiert' : mc24Pz(r.ekRendite), r.ekRendite == null ? mc24E(r.ekRenditeHinweis || 'Cashflow fehlt') : '')}
    ${iv24Kachel('Restschuld nach Zinsbindung', mc24Eur(r.restschuldNachBindung), r.cashflowNachBindungMonat != null ? 'danach Cashflow ' + mc24Eur(r.cashflowNachBindungMonat) + '/Monat' : '')}
  </div>
  <div class="mc24-fokus">${offen.length ? `<div class="mc24-fz warn"><span>⚠️</span><div><b>Offene Punkte (${offen.length})</b><small>${mc24E(offen.slice(0, 4).join(' · '))}</small></div></div>` : '<div class="mc24-fz"><span>✓</span><div><b>Keine offenen Rechenlücken</b></div></div>'}
    <div class="mc24-fz"><span>🧾</span><div><b>Datenqualität ${dq.stufe}</b><small>${mc24E(dq.gruende.join('; '))}</small></div></div>
    <div class="mc24-fz"><span>➡️</span><div><b>${p.entscheidung ? IV24_ENTSCHEIDUNG_TEXT[p.entscheidung.status] : 'Noch keine Entscheidung'}</b><small>${p.entscheidung ? mc24E(p.entscheidung.naechsterSchritt || '') + (p.entscheidung.wiedervorlage ? ' · Wiedervorlage ' + mc24Datum(p.entscheidung.wiedervorlage) : '') : 'Eingaben vervollständigen, Unterlagen prüfen, dann entscheiden'}</small></div></div></div>
  <div class="mc24-akte">
  <div class="mc24-karte"><h3>Kauf</h3>
    <div class="field-row">${nf('e.kaufpreis', 'Kaufpreis', e.kaufpreis, '€', '', her('kaufpreis'))}${nf('e.sanierung', 'Anfängliche Maßnahmen', e.sanierung, '€', '0 wenn keine')}${nf('e.finanzierungskosten', 'Anfängliche Finanzierungskosten', e.finanzierungskosten, '€', 'z. B. Bereitstellung, Gutachten')}</div>
    <table class="mc24-tab"><tr><th>Erwerbsnebenkosten</th><th>Art</th><th>Wert</th><th>Betrag</th><th></th></tr>${(e.nebenkosten || []).map((n, i) => `<tr><td><input value="${mc24E(n.name)}" onchange="iv24NkSet(${i},'name',this.value)">${n.hinweis ? `<small class="mc24-muted">${mc24E(n.hinweis)}</small>` : ''}</td><td><select onchange="iv24NkSet(${i},'art',this.value)"><option value="prozent" ${n.art === 'prozent' ? 'selected' : ''}>% vom Kaufpreis</option><option value="betrag" ${n.art === 'betrag' ? 'selected' : ''}>Betrag €</option></select></td><td><input inputmode="decimal" value="${mc24Fmt(n.wert)}" onchange="iv24NkSet(${i},'wert',iv24Num(this.value))" style="max-width:110px;"></td><td>${mc24Eur((r.nebenkosten.positionen[i] || {}).betrag)}</td><td><button class="tiny secondary" onclick="iv24NkWeg(${i})">✕</button></td></tr>`).join('')}
      <tr><td colspan="3"><button class="tiny secondary" onclick="iv24NkNeu()">+ Position</button></td><td><b>${mc24Eur(r.nebenkosten.summe)}</b></td><td></td></tr></table></div>
  <div class="mc24-karte"><h3>Finanzierung</h3>
    <div class="field-row">${nf('e.eigenkapital', 'Eigenkapital', e.eigenkapital, '€')}<div><label>Darlehen</label><select onchange="iv24Set('e.darlehenModus', this.value)"><option value="rest" ${e.darlehenModus === 'rest' ? 'selected' : ''}>Bedarf minus Eigenkapital</option><option value="quote" ${e.darlehenModus === 'quote' ? 'selected' : ''}>% des Kaufpreises</option><option value="betrag" ${e.darlehenModus === 'betrag' ? 'selected' : ''}>fester Betrag</option></select></div>
      ${e.darlehenModus === 'quote' ? nf('e.darlehenQuote', 'Beleihung', e.darlehenQuote, '%') : e.darlehenModus === 'betrag' ? nf('e.darlehenBetrag', 'Darlehensbetrag', e.darlehenBetrag, '€') : `<div><label>Darlehen</label><div class="ma24-fix">${mc24Eur(r.darlehen)}</div></div>`}</div>
    <div class="field-row">${nf('e.zins', 'Sollzins', e.zins, '% p. a.', '', e.zinsHinweis)}<div><label>Tilgung</label><select onchange="iv24Set('e.tilgungModus', this.value)"><option value="prozent" ${e.tilgungModus !== 'rate' ? 'selected' : ''}>anfängliche Tilgung %</option><option value="rate" ${e.tilgungModus === 'rate' ? 'selected' : ''}>Monatsrate €</option></select></div>${e.tilgungModus === 'rate' ? nf('e.rate', 'Monatsrate', e.rate, '€') : nf('e.tilgung', 'Anfängliche Tilgung', e.tilgung, '%')}</div>
    <div class="field-row">${nf('e.zinsbindung', 'Zinsbindung', e.zinsbindung, 'Jahre')}${nf('e.anschlusszins', 'Anschlusszins (ab Ende Zinsbindung)', e.anschlusszins, '%', 'unbekannt = gleicher Zins')}${nf('e.anschlusstilgung', 'Anschlusstilgung', e.anschlusstilgung, '%', 'wie bisher')}</div>
    <div class="mc24-muted">Rate Monat 1: ${mc24Eur(r.plan.rate1, 2)} · Zins Jahr 1: ${mc24Eur(r.zinsJahr1)} · Tilgung Jahr 1: ${mc24Eur(r.tilgungJahr1)}</div></div>
  <div class="mc24-karte"><h3>Einnahmen (Ist)</h3>
    <div class="field-row">${nf('e.miete', 'Nettokaltmiete', e.miete, '€/Monat', '', her('miete_ist'))}${nf('e.sonstigeEinnahmen', 'Stellplatz/sonstige Einnahmen', e.sonstigeEinnahmen, '€/Monat', 'separat')}${nf('e.mietausfall', 'Leerstand/Mietausfall', e.mietausfall, '% der Einnahmen', '', 'Annahme 2 % (Mietausfallwagnis) – anpassen')}${nf('e.mietsteigerung', 'Mietsteigerung', e.mietsteigerung, '% p. a.', '0')}</div></div>
  <div class="mc24-karte"><h3>Kosten (monatlich)</h3>
    <div class="field-row">${nf('e.hausgeld', 'Hausgeld gesamt', e.hausgeld, '€', '', her('hausgeld'))}${nf('e.hausgeldUmlagefaehig', 'davon umlagefähig', e.hausgeldUmlagefaehig, '€', 'aus dem Wirtschaftsplan', her('hausgeld_umlage'))}${nf('e.ruecklage', 'davon Rücklagenzuführung', e.ruecklage, '€', '', her('ruecklage_zufuehrung'))}</div>
    <div class="field-row">${nf('e.verwaltung', 'Miet-/SE-Verwaltung (nicht im Hausgeld)', e.verwaltung, '€')}${nf('e.sonstigeKosten', 'Sonstige nicht umlagefähige Kosten', e.sonstigeKosten, '€')}<div><label>Instandhaltung</label><select onchange="iv24Set('e.instandhaltungModus', this.value)"><option value="zusaetzlich" ${e.instandhaltungModus !== 'gesamt' ? 'selected' : ''}>zusätzlich zur Rücklage</option><option value="gesamt" ${e.instandhaltungModus === 'gesamt' ? 'selected' : ''}>gesamt inkl. Rücklage</option></select></div>${nf('e.instandhaltung', 'Instandhaltung', e.instandhaltung, '€')}${nf('e.kostensteigerung', 'Kostensteigerung', e.kostensteigerung, '% p. a.', '0')}</div>
    <div class="mc24-muted">Eigentümerkosten ${mc24Eur(r.eigentuemerkosten, 2)} (Hausgeld nicht umlagefähig ohne Rücklage ${mc24Eur(r.kosten.hausgeldBetrieb, 2)}, Verwaltung ${mc24Eur(r.kosten.verwaltung, 2)}, Sonstiges ${mc24Eur(r.kosten.sonstige, 2)}, bei Leerstand nicht gedeckte Umlagen ${mc24Eur(r.kosten.ausfallUmlage, 2)}) · Liquiditätsvorsorge ${mc24Eur(r.liquiditaetsvorsorge, 2)} (Rücklage ${mc24Eur(r.kosten.ruecklage, 2)} + zusätzliche Instandhaltung ${mc24Eur(r.kosten.instandhaltungZusaetzlich, 2)})</div></div>
  <div class="mc24-karte breit"><h3>Potenzial (getrennt vom Ist)</h3>
    <div class="field-row">${nf('e.potenzial.miete', 'Potenzialmiete', pot.miete, '€/Monat')}${nf('e.potenzial.massnahmen', 'Maßnahmenkosten', pot.massnahmen, '€')}${nf('e.potenzial.zeitbedarfMonate', 'Zeitbedarf', pot.zeitbedarfMonate, 'Monate')}${nf('e.potenzial.leerstandMonate', 'Leerstandsphase', pot.leerstandMonate, 'Monate')}</div>
    <div class="field-row"><div><label>Herkunft</label><select onchange="iv24Set('e.potenzial.herkunft', this.value)"><option value="">– bitte wählen –</option>${IV24_POT_HERKUNFT.map(x => `<option value="${x[0]}" ${pot.herkunft === x[0] ? 'selected' : ''}>${x[1]}</option>`).join('')}</select></div><div><label>Voraussetzung</label><input value="${mc24E(pot.voraussetzung || '')}" placeholder="z. B. Mieterwechsel, Modernisierung" onchange="iv24Set('e.potenzial.voraussetzung', this.value)"></div>
      <div><label>Prüfstatus</label><select onchange="iv24Set('e.potenzial.pruef', this.value)">${[['ungeprueft', 'ungeprüft'], ['geprueft', 'geprüft']].map(x => `<option value="${x[0]}" ${pot.pruef === x[0] ? 'selected' : ''}>${x[1]}</option>`).join('')}</select></div><div><label>Rechtlich geklärt?</label><select onchange="iv24Set('e.potenzial.rechtlichGeklaert', this.value)">${['unbekannt', 'ja', 'nein'].map(x => `<option ${pot.rechtlichGeklaert === x ? 'selected' : ''}>${x}</option>`).join('')}</select></div></div>
    <div class="mc24-muted">Rechtlich ungeklärte Mieterhöhungen gelten nicht als gesicherte Einnahmen (Mietpreisbremse, Mietspiegel, Kappung – im Mietrechner prüfen). <a href="#" onclick="wechsleAnsicht('jv-miete');return false;">Mietrechner öffnen</a></div>
    <table class="mc24-tab"><tr><th></th><th>Ist${p.ansicht === 'ist' ? ' (aktiv)' : ''}</th><th>Potenzial${p.ansicht === 'potenzial' ? ' (aktiv)' : ''}</th></tr>
      ${[['Miete/Monat', x => mc24Eur(x.mieteMonat)], ['Gesamtkapitalbedarf', x => mc24Eur(x.gesamtkapitalbedarf)], ['Cashflow/Monat (stabil)', x => mc24Eur(x.cashflowMonat)], ['Cashflow Jahr 1', x => mc24Eur(x.cashflowJahr1)], ['Bruttomietrendite', x => mc24Pz(x.bruttomietrendite)], ['Nettorendite', x => mc24Pz(x.nettorendite)], ['gesichert?', x => x.ansicht === 'ist' ? 'Ist-Werte' : (x.potenzialGesichert ? 'ja' : 'nein – Annahme')]].map(([l, f]) => `<tr><td>${l}</td><td>${f(rIst)}</td><td>${f(rPot)}</td></tr>`).join('')}</table></div>
  ${iv24SzenarienHtml(p)}
  ${iv24MaxHtml(p)}
  ${iv24UnterlagenHtml(p, o)}
  ${iv24ProfilHtml(p, prof, pr)}
  ${iv24EntscheidungHtml(p)}
  <div class="mc24-karte breit"><h3>Rechenweg, Annahmen und Tilgungsplan</h3>
    <details class="gs-details" open><summary>Rechenkonventionen</summary><ul class="mc24-ul">${r.konventionen.map(k => `<li>${mc24E(k)}</li>`).join('')}</ul></details>
    ${r.annahmen.length ? `<div><b>Aktive Annahmen:</b><ul class="mc24-ul">${r.annahmen.map(k => `<li>${mc24E(k)}</li>`).join('')}</ul></div>` : ''}
    <details class="gs-details"><summary>Jahresübersicht (Zins, Tilgung, Cashflow, Restschuld)</summary><table class="mc24-tab"><tr><th>Jahr</th><th>Einnahmen</th><th>Kosten</th><th>Zins</th><th>Tilgung</th><th>Cashflow</th><th>Restschuld</th></tr>${(r.jahre || []).slice(0, Math.max(12, (Number(e.zinsbindung) || 10) + 3)).map(j => `<tr ${j.jahr === (Number(e.zinsbindung) || 10) + 1 ? 'class="ma24-anschluss"' : ''}><td>${j.jahr}</td><td>${mc24Eur(j.einnahmen)}</td><td>${mc24Eur(j.kosten)}</td><td>${mc24Eur(j.zins)}</td><td>${mc24Eur(j.tilgung)}</td><td>${mc24Eur(j.cashflow)}</td><td>${mc24Eur(j.restschuld)}</td></tr>`).join('')}</table><div class="mc24-muted">Markierte Zeile: erstes Jahr mit Anschlusszins. Monatsgenauer Annuitätenplan.</div></details>
    <button class="tiny secondary" onclick="mc24Kopieren(iv24KiErklaerung(iv24P()), '📋 Prompt kopiert')">📋 KI-Erklärung anfordern (die KI rechnet nicht neu)</button></div>
  </div>`;
}
function iv24NkSet(i, k, v){ const p = iv24P(); p.e.nebenkosten[i][k] = v; if(k === 'wert') delete p.e.nebenkosten[i].hinweis; IV24.max = null; save(); renderMain(); }
function iv24NkNeu(){ const p = iv24P(); p.e.nebenkosten.push({ id: uid(), name: 'Weitere Position', art: 'betrag', wert: null }); save(); renderMain(); }
function iv24NkWeg(i){ const p = iv24P(); p.e.nebenkosten.splice(i, 1); save(); renderMain(); }
function iv24Loeschen(id){ bestaetigeUnten('Diese Investmentprüfung löschen? (Entscheidungen und Begründungen gehen verloren)', () => { db.invest24.pruefungen = db.invest24.pruefungen.filter(p => p.id !== id); IV24.sel = null; save(); renderMain(); }); }
function iv24KiErklaerung(p){
  const r = iv24ErgebnisVon(p);
  const z = { ansicht: p.ansicht, kaufpreis: r.kaufpreis, nebenkosten: r.nebenkosten.summe, gesamtkapitalbedarf: r.gesamtkapitalbedarf, eigenkapital: r.eigenkapitalEingesetzt, darlehen: r.darlehen, finanzierungsluecke: r.finanzierungsluecke, miete_monat: r.mieteMonat, eigentuemerkosten_monat: r.eigentuemerkosten, liquiditaetsvorsorge_monat: r.liquiditaetsvorsorge, schuldendienst_monat: r.schuldendienstMonat, cashflow_monat_vor_steuern: r.cashflowMonat, bruttomietrendite_prozent: r.bruttomietrendite, nettorendite_prozent: r.nettorendite, restschuld_nach_zinsbindung: r.restschuldNachBindung, fehlend: r.fehlend, warnungen: r.warnungen, annahmen: r.annahmen };
  return `Erkläre mir (Immobilienmakler, Berlin) in einfachen Worten, was diese bereits berechneten Kennzahlen einer Kapitalanlage bedeuten und welche drei Punkte ich vor einem Kauf klären sollte. Rechne nichts neu und ersetze keine Zahlen – die Werte stammen aus meinem Programm (vor Steuern):
${JSON.stringify(z, null, 1)}
Keine Steuer- oder Rechtsberatung, keine Kaufempfehlung. Deutsch, höchstens 12 Sätze.`;
}

// Szenarien + Stress
function iv24SzenarienHtml(p){
  const sz = iv24Szenarien(p.e, p.szenarien, p.ansicht), basis = sz.find(s => s.k === 'basis') || sz[1];
  const st = iv24Stress(p.e, p.ansicht);
  const diff = (x, b) => x == null || b == null ? '' : ` <small class="${x - b < 0 ? 'mc24-rot' : 'mc24-ok'}">(${x - b >= 0 ? '+' : ''}${mc24Zahl(x - b, 0)})</small>`;
  const feld = (k, a, l) => `<input inputmode="decimal" value="${mc24Fmt(p.szenarien[k][a])}" placeholder="wie Basis" onchange="iv24Set('szenarien.${k}.${a}', iv24Num(this.value))" style="max-width:80px;" title="${l}">`;
  return `<div class="mc24-karte breit"><h3>Szenarien (Annahmen editierbar)</h3>
    <table class="mc24-tab"><tr><th></th>${sz.map(s => `<th>${mc24E(s.l)}</th>`).join('')}</tr>
      ${[['miete', 'Miete Δ %'], ['mietausfall', 'Leerstand/Ausfall %'], ['kosten', 'Kosten Δ %'], ['sanierung', 'Sanierung Δ %'], ['anschlusszins', 'Anschlusszins Δ Prozentpunkte'], ['mietsteigerung', 'Mietsteigerung % p. a.']].map(([a, l]) => `<tr><td>${l}</td>${sz.map(s => `<td>${feld(s.k, a, l)}</td>`).join('')}</tr>`).join('')}
      <tr class="iv24-trenn"><td><b>Cashflow/Monat Jahr 1</b></td>${sz.map(s => `<td><b>${mc24Eur(s.r.cashflowMonat)}</b>${s.k !== 'basis' ? diff(s.r.cashflowMonat, basis.r.cashflowMonat) : ''}</td>`).join('')}</tr>
      <tr><td>Cashflow/Monat nach Zinsbindung</td>${sz.map(s => `<td>${mc24Eur(s.r.cashflowNachBindungMonat)}${s.k !== 'basis' ? diff(s.r.cashflowNachBindungMonat, basis.r.cashflowNachBindungMonat) : ''}</td>`).join('')}</tr>
      <tr><td>Nettorendite</td>${sz.map(s => `<td>${mc24Pz(s.r.nettorendite)}</td>`).join('')}</tr>
      <tr><td>Gesamtkapitalbedarf</td>${sz.map(s => `<td>${mc24Eur(s.r.gesamtkapitalbedarf)}</td>`).join('')}</tr>
      <tr><td>Finanzierungslücke</td>${sz.map(s => `<td>${mc24Eur(s.r.finanzierungsluecke)}</td>`).join('')}</tr></table>
    <h4 style="margin:12px 0 4px;">Stressfälle (gegenüber Basis)</h4>
    <table class="mc24-tab"><tr><th>Fall</th><th>Cashflow Jahr 1</th><th>Cashflow nach Zinsbindung</th><th>Gesamtkapitalbedarf</th><th>Lücke</th></tr>
      <tr><td>Basis</td><td>${mc24Eur(st.basis.cashflowMonat)}</td><td>${mc24Eur(st.basis.cashflowNachBindungMonat)}</td><td>${mc24Eur(st.basis.gesamtkapitalbedarf)}</td><td>${mc24Eur(st.basis.finanzierungsluecke)}</td></tr>
      ${st.faelle.map(f => `<tr><td>${mc24E(f.l)}</td><td>${mc24Eur(f.r.cashflowMonat)}${diff(f.r.cashflowMonat, st.basis.cashflowMonat)}</td><td>${mc24Eur(f.r.cashflowNachBindungMonat)}${diff(f.r.cashflowNachBindungMonat, st.basis.cashflowNachBindungMonat)}</td><td>${mc24Eur(f.r.gesamtkapitalbedarf)}</td><td>${mc24Eur(f.r.finanzierungsluecke)}</td></tr>`).join('')}</table>
    <div class="mc24-muted">Der Anschlusszins wirkt erst ab dem Ende der Zinsbindung. Kein Szenario ist eine Prognose.</div></div>`;
}
// Maximaler Kaufpreis
function iv24MaxHtml(p){
  const z = p.ziel || { art: 'cashflow', wert: 0 };
  const m = IV24.max && IV24.max.id === p.id ? IV24.max.res : null;
  return `<div class="mc24-karte"><h3>Maximaler Kaufpreis</h3>
    <div class="field-row"><div><label>Ziel</label><select onchange="iv24Set('ziel.art', this.value)">${[['cashflow', 'Cashflow vor Steuern mindestens (€/Monat)'], ['brutto', 'Bruttomietrendite mindestens (%)'], ['netto', 'Nettorendite mindestens (%)'], ['ekRendite', 'EK-Cashflow-Rendite mindestens (%)']].map(x => `<option value="${x[0]}" ${z.art === x[0] ? 'selected' : ''}>${x[1]}</option>`).join('')}</select></div>
      <div><label>Zielwert</label><input inputmode="decimal" value="${mc24Fmt(z.wert)}" onchange="iv24Set('ziel.wert', iv24Num(this.value))"></div></div>
    <label class="gs-chk"><input type="checkbox" ${z.finanzierungGedeckt ? 'checked' : ''} onchange="iv24Set('ziel.finanzierungGedeckt', this.checked)"> Finanzierung muss gedeckt sein (keine Finanzierungslücke)</label>
    <button class="tiny" onclick="IV24.max={id:'${p.id}',res:iv24MaxPreis(iv24P().e, iv24P().ziel, iv24P().ansicht)};renderMain()">Berechnen</button>
    ${m ? (m.preis != null ? `<div class="iv24-max"><b>${mc24Eur(m.preis)}</b> <span class="mc24-muted">unter diesen Annahmen (${p.ansicht === 'potenzial' ? 'Potenzial' : 'Ist'})</span><div class="mc24-muted">${mc24E(m.erklaerung)} ${mc24E(m.grenzen.join(' '))}</div>
      <div class="mc24-muted">Gegenprobe (Vorwärtsrechnung mit ${mc24Eur(m.preis)}): ${z.art === 'cashflow' ? 'Cashflow ' + mc24Eur(m.gegenprobe.kennzahl, 2) + '/Monat' : 'Kennzahl ' + mc24Pz(m.gegenprobe.kennzahl)} – Ziel ${m.gegenprobe.erfuellt ? 'erfüllt ✓' : 'nicht erfüllt'}; bei +100 € ${m.gegenprobe.naechsterErfuellt ? 'noch erfüllt' : 'nicht mehr erfüllt'}. Nebenkosten ${mc24Eur(m.gegenprobe.nebenkosten)}, Darlehen ${mc24Eur(m.gegenprobe.darlehen)}, Lücke ${mc24Eur(m.gegenprobe.luecke)}.</div>
      <button class="tiny secondary" onclick="iv24Set('entscheidung', Object.assign({}, iv24P().entscheidung || {status:'weiterpruefen'}, {zielpreis: ${m.preis}}))">als Zielpreis übernehmen</button></div>`
      : `<div class="mc24-hinweis">${mc24E(m.erklaerung)}</div>`) : '<div class="mc24-muted">Prozentuale Nebenkosten und kaufpreisabhängige Finanzierung werden bei jedem Preis neu berechnet. Die App rechnet – eine KI erklärt höchstens.</div>'}</div>`;
}
// Unterlagen
function iv24UnterlagenHtml(p, o){
  const docs = o ? (o.dokumente || []) : [];
  return `<div class="mc24-karte breit"><h3>Unterlagenprüfung <span class="sp"></span><button class="tiny secondary" onclick="iv24UntNeu()">+ Unterlage</button></h3>
    <table class="mc24-tab"><tr><th>Unterlage</th><th>Status</th><th>Dokument</th><th>Fundstelle / Notiz</th><th></th></tr>
    ${(p.unterlagen || []).map((u, i) => `<tr class="iv24-u-${u.status}"><td>${mc24E(u.name)}${u.ki && u.ki.text ? `<div class="mc24-muted">KI-Auszug (${mc24E(u.ki.quelle || 'ohne Quelle')}, ${u.ki.pruef === 'geprueft' ? 'geprüft' : 'ungeprüft'}): „${mc24E(u.ki.text.slice(0, 160))}“</div>` : ''}</td>
      <td><select onchange="iv24UntSet(${i},'status',this.value)">${IV24_UNT_STATUS.map(x => `<option value="${x[0]}" ${u.status === x[0] ? 'selected' : ''}>${x[1]}</option>`).join('')}</select></td>
      <td><select onchange="iv24UntSet(${i},'dokId',this.value||null)"><option value="">–</option>${docs.map(d => `<option value="${d.id}" ${u.dokId === d.id ? 'selected' : ''}>${mc24E(d.name)}</option>`).join('')}</select>${u.dokId && o ? ` <a href="#" onclick="dokOeffnen('${o.id}','${u.dokId}');return false;">öffnen</a>` : ''}</td>
      <td><input value="${mc24E(u.fundstelle || '')}" placeholder="z. B. Seite 4, TOP 7" onchange="iv24UntSet(${i},'fundstelle',this.value)"><input value="${mc24E(u.notiz || '')}" placeholder="Notiz" onchange="iv24UntSet(${i},'notiz',this.value)"></td>
      <td><button class="tiny secondary" title="KI-Auszug erfassen" onclick="iv24KiAuszug(${i})">KI</button>${u.status === 'rueckfrage' || u.status === 'fehlt' ? `<button class="tiny secondary" title="Klärungsaufgabe" onclick="iv24UntAufgabe(${i})">Aufgabe</button>` : ''}</td></tr>`).join('')}</table>
    <div class="mc24-muted">KI-Auszüge immer mit Quelle und Prüfstatus – keine automatische rechtliche Freigabe.</div></div>`;
}
function iv24UntSet(i, k, v){ const p = iv24P(); p.unterlagen[i][k] = v; if(k === 'status') p.unterlagen[i].am = mc24Heute(); save(); renderMain(); }
function iv24UntNeu(){ const p = iv24P(); p.unterlagen.push({ id: uid(), name: 'Weitere Unterlage', status: 'fehlt', dokId: null, fundstelle: '', notiz: '' }); save(); renderMain(); }
function iv24UntAufgabe(i){ const p = iv24P(), u = p.unterlagen[i], o = findObjekt(p.objektId); const a = mc24AufgabeAnlegen({ titel: `Unterlage klären: ${u.name} (${p.name.slice(0, 40)})`, faellig: gsTagPlus(mc24Heute(), 3), objektId: p.objektId, kontaktId: o ? o.eigentuemerId : null, typ: 'klaerung', notiz: u.notiz || '' }); u.aufgabeId = a.id; save(); renderMain(); akqToast('✅ Aufgabe angelegt'); }
function iv24KiAuszug(i){
  const p = iv24P(), u = p.unterlagen[i], k = u.ki || {};
  mc24Modal(`<h3>KI-Auszug: ${mc24E(u.name)}</h3><div class="mc24-muted">Auszug aus einem Dokument, den eine KI geliefert hat. Bleibt als ungeprüft markiert, bis du ihn am Original geprüft hast.</div>
    <label>Auszug</label><textarea id="ka_t" rows="4">${mc24E(k.text || '')}</textarea><div class="field-row"><div><label>Quelle (Dokument, Seite)</label><input id="ka_q" value="${mc24E(k.quelle || '')}"></div><div><label>Prüfstatus</label><select id="ka_p"><option value="ungeprueft">ungeprüft</option><option value="geprueft" ${k.pruef === 'geprueft' ? 'selected' : ''}>am Original geprüft</option></select></div></div>
    <div class="modal-actions"><div></div><div class="right"><button class="secondary" onclick="schliesseModal()">Abbrechen</button><button onclick="iv24KiAuszugSpeichern(${i})">Speichern</button></div></div>`, 640);
}
function iv24KiAuszugSpeichern(i){ const p = iv24P(), g = x => document.getElementById(x).value; const q = g('ka_q').trim(); if(g('ka_t').trim() && !q){ akqToast('Bitte die Quelle angeben.'); return; } p.unterlagen[i].ki = { text: g('ka_t').trim(), quelle: q, pruef: g('ka_p'), am: mc24Heute() }; save(); schliesseModal(); renderMain(); }
// Profil-Abgleich
function iv24ProfilHtml(p, prof, pr){
  const l = iv24Db().profile;
  return `<div class="mc24-karte"><h3>Abgleich mit Ankaufprofil</h3>
    <select onchange="iv24Set('profilId', this.value||null)"><option value="">– kein Profil –</option>${l.map(x => `<option value="${x.id}" ${p.profilId === x.id ? 'selected' : ''}>${mc24E(x.name)}</option>`).join('')}</select>
    ${pr ? `<table class="mc24-tab">${pr.liste.map(x => { const man = (p.profilChecks || {})[x.k]; const st = x.status === 'pruefen' ? (man || 'pruefen') : x.status; return `<tr><td>${st === 'ok' ? '✅' : st === 'nein' ? '❌' : '❔'}</td><td><b>${mc24E(x.l)}</b> <small class="mc24-muted">${x.muss ? 'Muss' : 'Soll'}</small><br><small class="mc24-muted">${mc24E(x.grund)}</small></td><td>${x.status === 'pruefen' ? `<select onchange="iv24Set('profilChecks.${x.k}', this.value||null)"><option value="">offen</option><option value="ok" ${man === 'ok' ? 'selected' : ''}>trifft nicht zu</option><option value="nein" ${man === 'nein' ? 'selected' : ''}>trifft zu</option></select>` : ''}</td></tr>`; }).join('')}</table>
      <div class="mc24-muted">${pr.mussVerletzt ? `${pr.mussVerletzt} Muss-Kriterium/-Kriterien verletzt. ` : ''}${pr.offen ? pr.offen + ' Punkt(e) offen. ' : ''}Kein Gesamtscore und keine automatische Kaufempfehlung – Abweichungen sind begründet aufgeführt.</div>` : l.length ? '' : '<div class="mc24-muted">Noch kein Profil. Unter „Ankaufprofile“ anlegen.</div>'}</div>`;
}
// Entscheidung
function iv24EntscheidungHtml(p){
  const e = p.entscheidung || {};
  return `<div class="mc24-karte"><h3>Entscheidung</h3>
    <div class="field-row"><div><label>Status</label><select id="ie_st">${IV24_ENTSCHEIDUNG.map(x => `<option value="${x[0]}" ${e.status === x[0] ? 'selected' : ''}>${x[1]}</option>`).join('')}</select></div><div><label>Zielpreis</label><input id="ie_zp" inputmode="decimal" value="${mc24Fmt(e.zielpreis)}"></div><div><label>Wiedervorlage</label><input type="date" id="ie_wv" value="${mc24E(e.wiedervorlage || '')}"></div></div>
    <label>Begründung</label><textarea id="ie_b" rows="2">${mc24E(e.begruendung || '')}</textarea>
    <div class="field-row"><div><label>Offene Bedingungen</label><input id="ie_bed" value="${mc24E(e.bedingungen || '')}"></div><div><label>Nächster Schritt</label><input id="ie_ns" value="${mc24E(e.naechsterSchritt || '')}"></div></div>
    <button class="tiny" onclick="iv24EntscheidungSpeichern()">Entscheidung speichern</button>
    <div class="mc24-muted">Keine automatische Kaufhandlung und keine verbindliche Finanzierungszusage.</div>
    ${(p.entscheidungen || []).length ? `<div style="margin-top:8px;"><b>Verlauf:</b>${p.entscheidungen.slice().reverse().map(x => `<div class="mc24-muted">${mc24Datum(x.am)} · ${mc24E(IV24_ENTSCHEIDUNG_TEXT[x.status])}${x.zielpreis ? ' · Zielpreis ' + mc24Eur(x.zielpreis) : ''}${x.begruendung ? ' – ' + mc24E(x.begruendung) : ''}</div>`).join('')}</div>` : ''}</div>`;
}
function iv24EntscheidungSpeichern(){
  const p = iv24P(), g = x => document.getElementById(x).value;
  const e = { status: g('ie_st'), zielpreis: mc24N(g('ie_zp')), wiedervorlage: g('ie_wv'), begruendung: g('ie_b').trim(), bedingungen: g('ie_bed').trim(), naechsterSchritt: g('ie_ns').trim(), am: new Date().toISOString() };
  if(e.status === 'ablehnen' && !e.begruendung){ akqToast('Bitte einen Ablehnungsgrund angeben – er wird aufbewahrt.'); return; }
  p.entscheidung = e; (p.entscheidungen = p.entscheidungen || []).push(Object.assign({}, e));
  if(e.wiedervorlage && e.status !== 'ablehnen') mc24AufgabeAnlegen({ titel: `Investment wiedervorlegen: ${p.name.slice(0, 50)}${e.naechsterSchritt ? ' – ' + e.naechsterSchritt : ''}`, faellig: e.wiedervorlage, objektId: p.objektId, typ: 'investment' });
  const o = findObjekt(p.objektId); if(o && typeof aqLog === 'function') aqLog(o, 'notiz', `Investmentprüfung: ${IV24_ENTSCHEIDUNG_TEXT[e.status]}${e.begruendung ? ' – ' + e.begruendung : ''}`);
  save(); renderMain(); akqToast('Entscheidung gespeichert');
}

// ── Vergleich mehrerer Objekte ──
function iv24VergleichHtml(){
  const l = iv24Db().pruefungen;
  if(!l.length) return '<div class="vl-leer">Noch keine Prüfungen zum Vergleichen.</div>';
  if(!Object.keys(IV24.vergleich).length) l.slice(0, 3).forEach(p => IV24.vergleich[p.id] = true);
  const sel = l.filter(p => IV24.vergleich[p.id]);
  const ans = p => IV24.vergleichAnsicht === 'eigene' ? (p.ansicht || 'ist') : IV24.vergleichAnsicht;
  const gemischt = new Set(sel.map(ans)).size > 1;
  const rs = sel.map(p => ({ p, r: iv24Rechnen(p.e, ans(p)), dq: null }));
  rs.forEach(x => x.dq = iv24Datenqualitaet(x.p, x.r));
  const zeile = (l2, f) => `<tr><td>${l2}</td>${rs.map(x => `<td>${f(x)}</td>`).join('')}</tr>`;
  return `<div class="mc24-karte"><div class="mc24-knoepfe">${l.map(p => `<label class="gs-chk"><input type="checkbox" ${IV24.vergleich[p.id] ? 'checked' : ''} onchange="IV24.vergleich['${p.id}']=this.checked;renderMain()"> ${mc24E(p.name)}</label>`).join('')}</div>
    <div class="iv24-ansicht"><span>Rechenbasis:</span>${[['eigene', 'je Prüfung gewählt'], ['ist', 'alle Ist'], ['potenzial', 'alle Potenzial']].map(([k, t]) => `<button class="${IV24.vergleichAnsicht === k ? 'an' : ''}" onclick="IV24.vergleichAnsicht='${k}';renderMain()">${t}</button>`).join('')}</div>
    ${gemischt ? '<div class="mc24-hinweis">⚠️ Achtung: Die Spalten mischen Ist- und Potenzialbasis. Für einen fairen Vergleich „alle Ist“ oder „alle Potenzial“ wählen.</div>' : ''}</div>
  <div class="mc24-karte breit" style="overflow:auto;"><table class="mc24-tab iv24-vgl"><tr><th></th>${rs.map(x => `<th>${mc24E(x.p.name)}<br><small>${ans(x.p) === 'potenzial' ? 'Basis: Potenzial' + (x.r.potenzialGesichert ? '' : ' (ungesichert)') : 'Basis: Ist'}</small></th>`).join('')}</tr>
    ${zeile('Kaufpreis', x => mc24Eur(x.r.kaufpreis))}${zeile('Gesamtinvestition', x => mc24Eur(x.r.gesamtkapitalbedarf))}${zeile('Eigenmittel', x => mc24Eur(x.r.eigenkapitalEingesetzt))}${zeile('Finanzierungslücke', x => mc24Eur(x.r.finanzierungsluecke))}
    ${zeile('Miete/Monat', x => mc24Eur(x.r.mieteMonat))}${zeile('Cashflow/Monat (vor Steuern)', x => mc24Eur(x.r.cashflowMonat))}${zeile('Bruttomietrendite', x => mc24Pz(x.r.bruttomietrendite))}${zeile('Nettorendite', x => mc24Pz(x.r.nettorendite))}
    ${zeile('Maßnahmen', x => mc24Eur(x.r.sanierung))}${zeile('Datenqualität', x => mc24E(x.dq.stufe))}${zeile('Offene Risiken', x => { const u = (x.p.unterlagen || []).filter(y => y.status === 'fehlt' || y.status === 'rueckfrage').length; return mc24E([x.r.fehlend.length ? x.r.fehlend.length + ' Lücke(n)' : '', x.r.warnungen.length ? x.r.warnungen.length + ' Warnung(en)' : '', u ? u + ' Unterlage(n) offen' : ''].filter(Boolean).join(', ') || '–'); })}
    ${zeile('Entscheidung', x => mc24E(x.p.entscheidung ? IV24_ENTSCHEIDUNG_TEXT[x.p.entscheidung.status] : 'offen'))}</table></div>`;
}

// ── Ankaufprofile ──
function iv24ProfileHtml(){
  const l = iv24Db().profile;
  if(!l.find(x => x.id === IV24.profilSel)) IV24.profilSel = l.length ? l[0].id : null;
  const p = l.find(x => x.id === IV24.profilSel);
  return `<div class="ma24-layout"><div class="ma24-liste">${l.map(x => `<div class="ma24-lz ${x.id === IV24.profilSel ? 'an' : ''}" onclick="IV24.profilSel='${x.id}';renderMain()"><b>${mc24E(x.name)}</b><small>${mc24E([(x.kriterien.objektarten || {}).werte ? x.kriterien.objektarten.werte.join(', ') : '', x.kriterien.budget && x.kriterien.budget.wert ? 'bis ' + mc24Eur(x.kriterien.budget.wert) : ''].filter(Boolean).join(' · '))}</small></div>`).join('')}<button class="tiny" onclick="iv24ProfilNeu()">+ Profil</button></div>
    <div class="ma24-haupt">${p ? iv24ProfilForm(p) : '<div class="vl-leer">Lege ein Ankaufprofil an, um Objekte gegen deine Kriterien zu prüfen.</div>'}</div></div>`;
}
function iv24ProfilNeu(){
  const p = { id: uid(), name: 'Mein Ankaufprofil', kriterien: { budget: { wert: null, muss: true }, eigenmittel: { wert: null, muss: true }, regionen: { werte: [], muss: false }, objektarten: { werte: ['Wohnung'], muss: true }, cashflow: { wert: 0, muss: false }, rendite: { art: 'brutto', wert: null, muss: false }, sanierung: { wert: null, muss: false }, vermietung: { wert: 'egal', muss: false }, ausschluss: [] } };
  iv24Db().profile.push(p); IV24.profilSel = p.id; save(); renderMain();
}
function iv24ProfilForm(p){
  const k = p.kriterien;
  const muss = (pfad, an) => `<select onchange="iv24ProfilSet('${pfad}.muss', this.value==='1')"><option value="1" ${an ? 'selected' : ''}>Muss</option><option value="0" ${!an ? 'selected' : ''}>Soll</option></select>`;
  const zahl = (pfad, l, w, e) => `<div><label>${l}${e ? ' (' + e + ')' : ''}</label><input inputmode="decimal" value="${mc24Fmt(w)}" onchange="iv24ProfilSet('${pfad}.wert', mc24N(this.value))"></div>`;
  return `<div class="mc24-karte"><h3><input value="${mc24E(p.name)}" onchange="iv24ProfilSet('name', this.value)" style="font-size:15px;font-weight:700;"> <span class="sp"></span><button class="tiny secondary" onclick="iv24ProfilLoeschen('${p.id}')">🗑</button></h3>
    <table class="mc24-tab">
      <tr><td>${zahl('kriterien.budget', 'Budget (Gesamtkapitalbedarf max.)', k.budget.wert, '€')}</td><td>${muss('kriterien.budget', k.budget.muss)}</td></tr>
      <tr><td>${zahl('kriterien.eigenmittel', 'Verfügbare Eigenmittel', k.eigenmittel.wert, '€')}</td><td>${muss('kriterien.eigenmittel', k.eigenmittel.muss)}</td></tr>
      <tr><td><label>Regionen (Kommas)</label><input value="${mc24E((k.regionen.werte || []).join(', '))}" onchange="iv24ProfilSet('kriterien.regionen.werte', this.value.split(',').map(s=>s.trim()).filter(Boolean))"></td><td>${muss('kriterien.regionen', k.regionen.muss)}</td></tr>
      <tr><td><label>Objektarten</label><div class="mc24-knoepfe">${OBJEKT_ARTEN.map(a => `<label class="gs-chk"><input type="checkbox" ${(k.objektarten.werte || []).includes(a) ? 'checked' : ''} onchange="iv24ProfilArt('${a}', this.checked)"> ${a}</label>`).join('')}</div></td><td>${muss('kriterien.objektarten', k.objektarten.muss)}</td></tr>
      <tr><td>${zahl('kriterien.cashflow', 'Gewünschter Cashflow vor Steuern', k.cashflow.wert, '€/Monat')}</td><td>${muss('kriterien.cashflow', k.cashflow.muss)}</td></tr>
      <tr><td><div class="field-row"><div><label>Renditeziel</label><select onchange="iv24ProfilSet('kriterien.rendite.art', this.value)"><option value="brutto" ${k.rendite.art !== 'netto' ? 'selected' : ''}>Bruttomietrendite</option><option value="netto" ${k.rendite.art === 'netto' ? 'selected' : ''}>Nettorendite</option></select></div>${zahl('kriterien.rendite', 'mindestens', k.rendite.wert, '%')}</div></td><td>${muss('kriterien.rendite', k.rendite.muss)}</td></tr>
      <tr><td>${zahl('kriterien.sanierung', 'Tolerierter Sanierungsaufwand max.', k.sanierung.wert, '€')}</td><td>${muss('kriterien.sanierung', k.sanierung.muss)}</td></tr>
      <tr><td><label>Vermietungsstatus</label><select onchange="iv24ProfilSet('kriterien.vermietung.wert', this.value)">${[['egal', 'egal'], ['vermietet', 'vermietet'], ['bezugsfrei', 'bezugsfrei']].map(x => `<option value="${x[0]}" ${k.vermietung.wert === x[0] ? 'selected' : ''}>${x[1]}</option>`).join('')}</select></td><td>${muss('kriterien.vermietung', k.vermietung.muss)}</td></tr>
      <tr><td colspan="2"><label>Ausschlusskriterien (eines pro Zeile, z. B. Erbbaurecht, Zwangsversteigerung)</label><textarea rows="3" onchange="iv24ProfilSet('kriterien.ausschluss', this.value.split(/\\n+/).map(s=>s.trim()).filter(Boolean))">${mc24E((k.ausschluss || []).join('\n'))}</textarea></td></tr></table>
    <div class="mc24-muted">Muss = hartes Kriterium, Soll = Wunsch. Abweichungen werden je Objekt begründet angezeigt – ohne Score und ohne automatische Kaufempfehlung.</div></div>`;
}
function iv24ProfilSet(pfad, wert){ const p = iv24Db().profile.find(x => x.id === IV24.profilSel); if(!p) return; const t = pfad.split('.'); let x = p; for(let i = 0; i < t.length - 1; i++) x = x[t[i]]; x[t[t.length - 1]] = wert; save(); renderMain(); }
function iv24ProfilArt(a, an){ const p = iv24Db().profile.find(x => x.id === IV24.profilSel); const w = new Set(p.kriterien.objektarten.werte || []); if(an) w.add(a); else w.delete(a); p.kriterien.objektarten.werte = [...w]; save(); renderMain(); }
function iv24ProfilLoeschen(id){ bestaetigeUnten('Profil löschen?', () => { db.invest24.profile = db.invest24.profile.filter(x => x.id !== id); db.invest24.pruefungen.forEach(p => { if(p.profilId === id) p.profilId = null; }); save(); renderMain(); }); }

// ── Einbindung ──
const _iv24RenderMain = renderMain;
renderMain = function(){ if(aktuelleAnsicht === 'investments24') return iv24Render(document.getElementById('main')); return _iv24RenderMain.apply(this, arguments); };
window.addEventListener('load', () => {
  try{
    const i = NAV.findIndex(n => n.key === 'marktanalyse24');
    if(!NAV.some(n => n.key === 'investments24')) NAV.splice(i >= 0 ? i + 1 : 3, 0, { key: 'investments24', label: 'Investments', icon: '💶' });
    if(typeof IC === 'object' && !IC.investments24) IC.investments24 = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M17.5 6.5A7 7 0 1 0 17.5 17.5"/><path d="M4 10h9M4 14h9"/></svg>';
    renderNav();
  }catch(e){ console.error('Investments v24', e); }
});
