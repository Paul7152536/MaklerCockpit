/* MaklerCockpit v21 – Käufer & Markt
   Suchkunden (Kaufgesuche aus Zeitung / KI / von Hand), Trefferquote Objekt ↔ Gesuch,
   Seite „Käufer & Markt“ mit Markt-Check, Käufergruppen, Finanzierbarkeit und „Käufer finden“. */

const KM = { tab:'objekte', filter:null, sel:null, q:'', skQ:'', skFilter:'aktiv' };
const SK_MIN = 55;                                   // ab dieser Trefferquote gilt ein Suchkunde als passend
const SK_FIN_STD = { zins:4.0, tilgung:2.0, ek:10, quote:35, notar:2.0, makler:3.57, stand:'10.11.2026' };
const SK_ART_LANG = { EFH:'Einfamilienhaus', DHH:'Doppelhaushälfte', Reihenhaus:'Reihenhaus', Wohnung:'Wohnung', 'Grundstück':'Grundstück', MFH:'Mehrfamilienhaus', Gewerbe:'Gewerbe' };
function kmEinst(){ return Object.assign({}, SK_FIN_STD, db.kaeuferEinst || {}); }
function skListe(){ if(!Array.isArray(db.gesuche)) db.gesuche = []; return db.gesuche; }
function skFind(id){ return skListe().find(g => g.id === id); }

// ═════════ Orte vergleichen ═════════
const SK_CACHE = new Map();
const SK_FUELL = ['berlin', 'bei', 'an', 'der', 'ot', 'am', 'im', 'a', 'd', 'in', 'und', 'oder'];
function skOrtInfo(text){
  const k = String(text || '');
  if(SK_CACHE.has(k)) return SK_CACHE.get(k);
  const n = x20Norm(k);
  const tok = n.trim().split(' ').filter(t => t && t.length > 1 && !SK_FUELL.includes(t) && !/^\d+$/.test(t));
  let gid = null; try{ gid = aqGebietFinden(k)[0]; }catch(e){}
  if(gid === 'bb_wandlitz' && /sch(ö|oe)nwalde[\s-]*glien/i.test(k)) gid = null;     // Schönwalde-Glien ≠ Schönwalde (Wandlitz)
  let land = gid ? (gid.startsWith('be_') ? 'BE' : 'BB') : (/\bberlin\b/i.test(k) ? 'BE' : null);
  if(!land && typeof ZL_ORTE_EXTRA !== 'undefined' && ZL_ORTE_EXTRA.some(o => n.includes(x20Norm(o)))) land = 'BB';
  if(!land){ const plz = /\b(1[0-6]\d{3})\b/.exec(k); if(plz) land = +plz[1] < 14000 ? 'BE' : 'BB'; }
  const r = { n, tok, gid, land };
  if(SK_CACHE.size > 3000) SK_CACHE.clear();
  SK_CACHE.set(k, r);
  return r;
}
function skOrtVergleich(gOrt, oi){
  const a = skOrtInfo(gOrt);
  if(a.tok.length && a.tok.every(t => oi.tok.includes(t))) return 'genau';
  if(a.gid && oi.gid && a.gid === oi.gid) return a.gid.startsWith('be_') ? 'bezirk' : 'genau';
  return null;
}
function skObjMiete(o){ return o.auftragsart === 'vermietung' && Number(o.kaufpreis) < 20000; }

// ═════════ Trefferquote ═════════
function skPasst(o, g){
  if(!o || !g || (g.status && g.status !== 'aktiv') || o.status === 'abgeschlossen') return null;
  if((g.nutzung === 'miete') !== skObjMiete(o)) return null;
  const gr = []; let p = 0, max = 30;
  if(g.arten && g.arten.length){ if(!g.arten.includes(o.objektart)) return null; p += 30; gr.push([1, SK_ART_LANG[o.objektart] || o.objektart]); }
  else p += 15;
  max += 30;
  const oi = skOrtInfo([o.ort, o.adresse].filter(Boolean).join(' '));
  const orte = g.orte || [];
  let lage = null, lageTxt = '';
  for(const go of orte){ const v = skOrtVergleich(go, oi); if(v === 'genau'){ lage = 'genau'; lageTxt = go; break; } if(v === 'bezirk' && !lage){ lage = 'bezirk'; lageTxt = go; } }
  if(!lage && g.berlinAlle && oi.land === 'BE'){ lage = 'region'; lageTxt = 'Berlin'; }
  if(!lage && g.umland && oi.land === 'BB'){ lage = 'region'; lageTxt = 'Umland'; }
  if(lage === 'genau'){ p += 30; gr.push([1, lageTxt]); }
  else if(lage === 'bezirk'){ p += 24; gr.push([1, 'gleicher Bezirk wie ' + lageTxt]); }
  else if(lage === 'region'){ p += 18; gr.push([1, lageTxt]); }
  else if(!orte.length && !g.berlinAlle && !g.umland){ p += 12; gr.push([0, 'Lage offen']); }
  else return null;
  const kp = Number(o.kaufpreis) || 0;
  if(g.preisMax){
    max += 25;
    if(!kp){ p += 10; gr.push([0, 'Preis unbekannt']); }
    else if(kp <= g.preisMax){ p += 25; gr.push([1, aqEur(kp) + ' ≤ ' + aqEur(g.preisMax)]); }
    else if(kp <= g.preisMax * 1.12){ p += 12; gr.push([0, Math.round((kp / g.preisMax - 1) * 100) + ' % über Budget']); }
    else return null;
  }
  const zi = parseFloat(String(o.zimmer || '').replace(',', '.')) || 0;
  if(g.zimmerMin){ max += 7; if(!zi) p += 3; else if(zi >= g.zimmerMin){ p += 7; gr.push([1, String(zi).replace('.', ',') + ' Zi.']); } else if(zi >= g.zimmerMin - 1){ p += 2; gr.push([0, 'nur ' + String(zi).replace('.', ',') + ' Zi.']); } else return null; }
  const fl = Number(o.wohnflaeche) || 0;
  if(g.flaecheMin){ max += 5; if(!fl) p += 2; else if(fl >= g.flaecheMin){ p += 5; gr.push([1, fl + ' m²']); } else if(fl >= g.flaecheMin * 0.9){ p += 2; gr.push([0, fl + ' m² (gesucht ab ' + g.flaecheMin + ')']); } else return null; }
  const gs = Number(o.grundstueck) || 0;
  if(g.grundstueckMin){ max += 3; if(!gs) p += 1; else if(gs >= g.grundstueckMin){ p += 3; gr.push([1, 'Grundstück ' + gs.toLocaleString('de-DE') + ' m²']); } else gr.push([0, 'Grundstück kleiner']); }
  return { score:Math.round(p / max * 100), gruende:gr };
}
function skTrefferFuer(o){ return skListe().map(g => ({ g, m:skPasst(o, g) })).filter(x => x.m && x.m.score >= SK_MIN).sort((a, b) => b.m.score - a.m.score); }
function skObjekteFuer(g){ return (db.objekte || []).map(o => ({ o, m:skPasst(o, g) })).filter(x => x.m && x.m.score >= SK_MIN).sort((a, b) => b.m.score - a.m.score); }
function skName(g){
  const k = g.kontaktId ? (db.kontakte || []).find(x => x.id === g.kontaktId) : null;
  return g.name || (k && k.name) || (g.chiffre ? 'Chiffre ' + g.chiffre : 'Suchkunde');
}
function skTel(g){ const k = g.kontaktId ? (db.kontakte || []).find(x => x.id === g.kontaktId) : null; return g.telefon || (k && k.telefon) || ''; }
function skMailAdr(g){ const k = g.kontaktId ? (db.kontakte || []).find(x => x.id === g.kontaktId) : null; return g.email || (k && k.email) || ''; }

// ═════════ Übernehmen (Zeitung, KI, von Hand) ═════════
function skUebernehmen(liste, importId){
  const heute = new Date().toLocaleDateString('de-DE');
  const r = { neu:0, doppelt:0, kontakteNeu:0, treffer:0, ids:[] };
  importId = importId || ('imp' + Date.now());
  const trefferObj = new Set();
  (liste || []).forEach(e => {
    const tel = akqTelNorm(e.telefon), mail = String(e.email || '').toLowerCase(), ch = String(e.chiffre || '').replace(/\s+/g, '').toUpperCase();
    let k = db.kontakte.find(x => (mail && String(x.email || '').toLowerCase() === mail) || (tel.length >= 7 && akqTelNorm(x.telefon) === tel));
    if(!k && (tel.length >= 7 || mail)){
      k = { id:uid(), createdAt:Date.now(), name: e.name || ((e.wer || 'Suchkunde') + ' (' + (e.telefon || mail) + ')'), telefon:e.telefon || '', email:mail, adresse:'',
        kontaktart:'kaeufer', quelle:e.quelle || 'Zeitung', status:'interessent', prioritaet:'mittel', notizen:`Suchkunde (${heute}): sucht ${zlGesuchKurz(e)}${e.quelleText ? ' – ' + e.quelleText : ''}`, importId };
      db.kontakte.push(k); r.kontakteNeu++;
    }
    const textN = x20Norm(e.text || '').trim();
    const dupe = skListe().find(g => (ch && String(g.chiffre || '').replace(/\s+/g, '').toUpperCase() === ch) || (e.link && g.link === e.link) ||
      (k && g.kontaktId === k.id && g.nutzung === (e.nutzung || 'kauf') && (!(g.arten || []).length || !(e.arten || []).length || g.arten.some(a => e.arten.includes(a)))) ||
      (textN.length > 30 && x20Norm(g.text || '').trim() === textN));
    if(dupe){
      ['preisMax', 'zimmerMin', 'flaecheMin', 'grundstueckMin'].forEach(f => { if(e[f]) dupe[f] = e[f]; });
      if((e.arten || []).length) dupe.arten = e.arten;
      if((e.orte || []).length) dupe.orte = e.orte;
      if(e.text) dupe.text = e.text;
      dupe.zuletzt = Date.now();
      (dupe.verlauf = dupe.verlauf || []).push({ ts:Date.now(), text:'Erneut gefunden' + (e.quelleText ? ' (' + e.quelleText + ')' : '') });
      r.doppelt++;
      skObjekteFuer(dupe).forEach(x => trefferObj.add(x.o.id));
      return;
    }
    const g = { id:uid(), createdAt:Date.now(), importId, status:'aktiv', kontaktId:k ? k.id : null, name:e.name || e.wer || '', telefon:e.telefon || '', email:mail,
      chiffre:e.chiffre || '', link:e.link || '', text:e.text || '', arten:e.arten || [], orte:e.orte || [], berlinAlle:!!e.berlinAlle, umland:!!e.umland,
      preisMax:Math.round(e.preisMax || 0), zimmerMin:e.zimmerMin || 0, flaecheMin:e.flaecheMin || 0, grundstueckMin:e.grundstueckMin || 0, nutzung:e.nutzung || 'kauf',
      wuensche:e.wuensche || [], quelle:e.quelle || 'Zeitung', quelleText:e.quelleText || '', datum:e.datum || '', seite:e.seite || '', notiz:'', informiert:{},
      verlauf:[{ ts:Date.now(), text:'Übernommen' + (e.quelleText || e.quelle ? ' aus ' + (e.quelleText || e.quelle) : '') }] };
    skListe().push(g); r.neu++; r.ids.push(g.id);
    skObjekteFuer(g).forEach(x => trefferObj.add(x.o.id));
  });
  r.treffer = trefferObj.size;
  save();
  return r;
}
// KI-Ergebnis („Anzeigentyp: Gesuch“) → Suchkunde
function skAusKi(e){
  const lage = String(e.lageRoh || e.ort || '');
  const t = [e.sucht || e.titel || '', lage ? 'in ' + lage : '', e.budget ? 'bis ' + e.budget : (e.preisText ? 'bis ' + e.preisText : ''), e.details || ''].filter(Boolean).join(', ');
  const k = zlGesuchKriterien(t);
  if(lage){
    const o = lage.split(/\s*(?:,|\/|\boder\b|\bund\b|;)\s*/).map(x => x.replace(/^(raum|n[äa]he|umgebung|bereich|im raum)\s+/i, '').trim()).filter(x => x.length >= 3 && /^[A-ZÄÖÜ]/.test(x));
    if(o.length) k.orte = o.filter(x => !/^(berlin|umland|brandenburg)$/i.test(x));
    k.berlinAlle = o.some(x => /^berlin$/i.test(x)); if(/umland|speckg|brandenburg/i.test(lage)) k.umland = true;
  }
  if(e.budget){ const b = akqPreis(e.budget); if(b) k.preisMax = b < 5000 && k.nutzung !== 'miete' ? b * 1000 : b; }
  return Object.assign(k, { text:t, name:e.name || '', telefon:e.telefon || '', email:e.email || '', chiffre:e.chiffre || '', link:e.link || '', quelle:e.quelle === 'Direktakquise' ? 'KI-Suche' : e.quelle, quelleText:e.quelleText || '', datum:e.datum || '', seite:e.seite || '' });
}
// Rückgängig entfernt auch die Suchkunden dieses Imports
const _skRueckgaengig = akqRueckgaengig;
akqRueckgaengig = function(importId){
  const weg = skListe().filter(g => g.importId === importId).length;
  db.gesuche = skListe().filter(g => g.importId !== importId);
  const r = _skRueckgaengig.apply(this, arguments);
  if(weg){ akqToast(`↩️ Rückgängig – auch ${weg} Suchkunde${weg === 1 ? '' : 'n'} entfernt`); if(aktuelleAnsicht === 'kaeufer') renderMain(); }
  return r;
};

// ═════════ Käufergruppen + Finanzierbarkeit ═════════
function skFinanz(o){
  const preis = Number(o.kaufpreis) || 0; if(!(preis >= 30000) || skObjMiete(o)) return null;
  const E = kmEinst(), oi = skOrtInfo([o.ort, o.adresse].filter(Boolean).join(' '));
  const grest = oi.land === 'BB' ? 6.5 : 6.0;
  const nkProz = grest + E.notar + E.makler;
  const nk = preis * nkProz / 100, ek = nk + preis * E.ek / 100, darlehen = preis * (1 - E.ek / 100);
  const rate = darlehen * (E.zins + E.tilgung) / 100 / 12, netto = rate / (E.quote / 100);
  return { preis, grest, nkProz, nk, ek, darlehen, rate, netto, E, land:oi.land };
}
function skKaeufergruppen(o, mv){
  const art = o.objektart, fl = Number(o.wohnflaeche) || 0, zi = parseFloat(String(o.zimmer || '').replace(',', '.')) || 0, gr = Number(o.grundstueck) || 0, bj = parseInt(o.baujahr) || 0;
  const txt = [o.akqTitel, o.details, o.adresse].join(' ').toLowerCase(), land = skOrtInfo([o.ort, o.adresse].filter(Boolean).join(' ')).land;
  const l = [];
  if(['EFH', 'DHH', 'Reihenhaus'].includes(art)){
    if(zi >= 4 || fl >= 110 || (!zi && !fl)) l.push(['👨‍👩‍👧 Familien mit Kindern', [zi ? zi + ' Zimmer' : '', gr ? gr.toLocaleString('de-DE') + ' m² Grundstück' : 'eigener Garten'].filter(Boolean).join(', ') + ' – Platz zum Großwerden']);
    if(/bungalow|ebenerdig|barrierefrei|erdgeschoss/.test(txt) || (fl && fl < 100)) l.push(['🧓 Paare 55+', 'kompakt' + (/bungalow|ebenerdig/.test(txt) ? ' und ebenerdig' : '') + ' – Verkleinerung aus dem großen Haus']);
    if(land === 'BB') l.push(['🏙️ Berliner, die ins Grüne ziehen', 'mehr Fläche fürs Geld als in Berlin, Pendeln in die Stadt']);
    if(/einlieger|zweifamilien|\bzfh\b/.test(txt)) l.push(['👵 Mehrgenerationen-Familien', 'Einliegerwohnung / zwei Einheiten']);
  }
  if(art === 'Wohnung'){
    if(/vermietet/.test(txt)) l.push(['💼 Kapitalanleger', 'vermietet – Mieteinnahmen ab dem ersten Tag']);
    if((zi && zi <= 2) || (fl && fl <= 60)) l.push(['🎓 Singles & Pendler', 'kompakt und gut bezahlbar' + (/vermietet/.test(txt) ? '' : ' – Eigennutzer')]);
    else l.push(['💑 Paare & kleine Familien', (zi ? zi + ' Zimmer' : 'Wohnung') + ' zum Selbstnutzen']);
    if(/aufzug|barrierefrei|ebenerdig|erdgeschoss|\beg\b/.test(txt)) l.push(['🧓 Senioren', 'Aufzug / barrierearm']);
  }
  if(art === 'Grundstück') l.push(['🏗️ Bauherren & Familien', 'eigenes Haus bauen'], ['🏢 Bauträger', gr >= 1000 ? 'Fläche für mehrere Einheiten' : 'kleines Projekt / Doppelhaus']);
  if(art === 'MFH') l.push(['💼 Kapitalanleger & Bestandshalter', 'Mieteinnahmen, Wertsteigerung'], ['🏠 Selbstnutzer + Vermietung', 'eine Einheit selbst bewohnen']);
  if(art === 'Gewerbe') l.push(['🏪 Selbstnutzer (Praxis, Laden, Büro)', 'eigene Fläche statt Miete'], ['💼 Investoren', 'Gewerberendite']);
  if((bj && bj < 1975) || /renovierungsbed|sanierungsbed|modernisierungsbed|handwerker|bastler/.test(txt)) l.push(['🔨 Handwerker & Sanierer', 'Renovierungsbedarf = Preisvorteil, Förderung (KfW) möglich']);
  if(mv && mv.geht && mv.abw !== undefined && mv.abw <= -10) l.push(['🔎 Schnäppchenjäger & Investoren', Math.abs(mv.abw) + ' % unter dem Marktschnitt']);
  return l;
}

// ═════════ KI: Preis, Käufer, Gesuche ═════════
function skKiPrompt(o){
  const mv = aqMarktVergleich(o);
  const eck = [SK_ART_LANG[o.objektart] || o.objektart, o.wohnflaeche ? o.wohnflaeche + ' m² Wohnfläche' : '', o.zimmer ? o.zimmer + ' Zimmer' : '', o.grundstueck ? o.grundstueck + ' m² Grundstück' : '', o.baujahr ? 'Baujahr ' + o.baujahr : '', o.kaufpreis ? 'Angebotspreis ' + aqEur(o.kaufpreis) : ''].filter(Boolean).join(', ');
  return `Du hilfst Paul Görner (Immobilienmakler, BETTERHOMES Berlin) bei der Vermarktung. Heute ist der ${new Date().toLocaleDateString('de-DE')}. Nutze die Websuche gründlich.

OBJEKT: ${aqTitel(o)} in ${[o.adresse, o.ort].filter(Boolean).join(', ') || 'unbekannter Lage'}
Eckdaten: ${eck || 'keine'}
${o.details ? 'Beschreibung: ' + String(o.details).slice(0, 700) + '\n' : ''}${o.link ? 'Anzeige: ' + o.link + '\n' : ''}${mv && mv.geht && mv.ist ? `Grober Marktwert im Programm: ${mv.ist} €/m² gegenüber ca. ${mv.m2} €/m² (${mv.q}).\n` : ''}
AUFGABE 1 – PREIS: Ist der Angebotspreis marktgerecht? Vergleiche mit aktuellen Angeboten und Verkaufspreisen im Ort (€/m²). Ein Satz Ergebnis + kurze Begründung.
AUFGABE 2 – KÄUFER: Welche 2–3 Käufergruppen passen am besten, und warum? Woran erkennt man sie, wie spricht man sie an (Kanäle, Argumente)?
AUFGABE 3 – GESUCHE: Suche aktuelle KAUFGESUCHE von Privatleuten, die zu diesem Objekt passen könnten – z. B. auf kleinanzeigen.de (Immobilien, Anzeigentyp „Gesuche“), in regionalen Anzeigenblättern online, in Gesuche-Rubriken der Portale. Keine Makler-Gesuche („für vorgemerkte Kunden“) und keine Gesuche mit „keine Makler“, „von privat“ oder „provisionsfrei“ – die wollen keinen Makler. Link PFLICHT, erfinde nichts.

ANTWORTFORMAT (genau so – Paul fügt deine Antwort in sein Programm ein):
Preis-Einschätzung: [marktgerecht / eher hoch / zu hoch / günstig – mit Begründung]
Passende Käufer: [Käufergruppen mit Grund]
Ansprache: [Kanäle und Argumente, 2–3 Sätze]

Danach die gefundenen Gesuche, nummeriert (1., 2., …), jedes so:
${AKQ_FORMAT_GESUCH_ZEILEN}
Wenn du keine passenden Gesuche findest, schreib „Gesuche: keine gefunden“.`;
}
function kmKiKopieren(id){ const o = findObjekt(id); if(!o) return; akqKopieren(skKiPrompt(o), '🤖 Prompt kopiert – in Claude/ChatGPT einfügen, Antwort danach hier mit „Antwort einfügen“ übernehmen'); }
function kmKiEinfuegen(id){
  const o = findObjekt(id); if(!o) return;
  x20Modal(`<div id="kmKiModal"><h3>📋 KI-Antwort übernehmen</h3><div class="gs-intro" style="margin-bottom:8px;">Antwort von Claude/ChatGPT zu „${akqEsc(aqTitel(o))}“ hier einfügen. Preis-Einschätzung und Käufergruppen landen am Objekt, gefundene Gesuche werden Suchkunden.</div>
    <textarea id="kmKiText" style="min-height:240px;" placeholder="Preis-Einschätzung: …&#10;Passende Käufer: …"></textarea>
    <div class="modal-actions"><span></span><div class="right"><button class="secondary" onclick="schliesseModal()">Abbrechen</button><button onclick="kmKiUebernehmen('${o.id}')">Übernehmen</button></div></div></div>`, 680);
  setTimeout(() => { const t = document.getElementById('kmKiText'); if(t) t.focus(); }, 30);
}
function skKiAbschnitt(text, schluessel){
  const re = new RegExp('^\\s*[*#\\-•]*\\s*(?:' + schluessel + ')\\s*\\**\\s*:\\s*\\**\\s*([\\s\\S]*?)(?=\\n\\s*[*#\\-•]*\\s*(?:preis[\\s-]*einsch[äa]tzung|passende\\s*k[äa]ufer|k[äa]ufergruppen?|ansprache|anzeigentyp|gesuche|\\d{1,2}\\s*[.)])\\b|$)', 'im');
  const m = re.exec(text); return m ? m[1].replace(/\*\*/g, '').replace(/\s+\n/g, '\n').trim() : '';
}
function kmKiUebernehmen(id){
  const o = findObjekt(id), t = String((document.getElementById('kmKiText') || {}).value || ''); if(!o || !t.trim()) return;
  const r = skKiAntwort(o, t);
  schliesseModal(); renderMain();
  akqToast(`🤖 Übernommen${r.preis ? ' · Preis-Einschätzung' : ''}${r.kaeufer ? ' · Käufergruppen' : ''}${r.sk ? ` · ${r.sk.neu} neue Suchkunde${r.sk.neu === 1 ? '' : 'n'}` : ''}`, 4000);
}
function skKiAntwort(o, t){
  const preis = skKiAbschnitt(t, 'preis[\\s-]*einsch[äa]tzung|preis[\\s-]*check|marktpreis');
  const kaeufer = skKiAbschnitt(t, 'passende\\s*k[äa]ufer|k[äa]ufergruppen?|zielgruppe');
  const ansprache = skKiAbschnitt(t, 'ansprache');
  if(preis) o.kiPreis = preis.slice(0, 600);
  if(kaeufer) o.kiKaeufer = kaeufer.slice(0, 800);
  if(ansprache) o.kiAnsprache = ansprache.slice(0, 800);
  if(preis || kaeufer){ o.kiAm = Date.now(); try{ aqLog(o, 'info', '🤖 KI-Einschätzung übernommen' + (preis ? ': ' + preis.split(/[.–\n]/)[0].slice(0, 60) : '')); }catch(e){} }
  let sk = null;
  try{
    const r = akqLesen(t);
    const ges = (r.eintraege || []).filter(e => e.typ === 'gesuch');
    if(ges.length) sk = skUebernehmen(ges.map(skAusKi));
  }catch(e){ console.error(e); }
  save();
  return { preis, kaeufer, sk };
}
function aqKiHtml(o){
  if(!o.kiPreis && !o.kiKaeufer) return '';
  return `<div class="ki-box"><div class="mv-kopf"><span>🤖 KI-Einschätzung</span>${o.kiAm ? `<small>${new Date(o.kiAm).toLocaleDateString('de-DE')}</small>` : ''}</div>${o.kiPreis ? `<div><b>Preis:</b> ${akqEsc(o.kiPreis)}</div>` : ''}${o.kiKaeufer ? `<div><b>Passende Käufer:</b> ${akqEsc(o.kiKaeufer)}</div>` : ''}${o.kiAnsprache ? `<div><b>Ansprache:</b> ${akqEsc(o.kiAnsprache)}</div>` : ''}</div>`;
}

// ═════════ Am Akquise-Lead ═════════
function aqKaeuferChip(o){ const n = skTrefferFuer(o).length; return n ? `<span class="chip sk-chip" title="${n} Suchkunde${n === 1 ? '' : 'n'} passt">👥 ${n}</span>` : ''; }
function aqSuchkundenHtml(o){
  const tr = skTrefferFuer(o); if(!tr.length) return '';
  return `<div class="sk-box"><div class="mv-kopf"><span>👥 ${tr.length} Suchkunde${tr.length === 1 ? '' : 'n'} sucht so etwas</span><button class="secondary tiny" onclick="kmOeffnen('${o.id}')">Details</button></div>
    ${tr.slice(0, 3).map(x => `<div class="sk-box-z"><span class="sk-score-mini s${x.m.score >= 85 ? 3 : x.m.score >= 70 ? 2 : 1}">${x.m.score} %</span><b>${akqEsc(skName(x.g))}</b> – sucht ${akqEsc(zlGesuchKurz(x.g))}</div>`).join('')}
    ${AQ_OFFEN.includes(o.status) ? `<div class="mv-sub">Argument beim Verkäufer: „Ich habe bereits vorgemerkte Käufer, die genau so etwas in ${akqEsc(aqOrtText(o) || 'Ihrer Gegend')} suchen.“</div>` : ''}</div>`;
}
function kmOeffnen(id){ KM.tab = 'objekte'; KM.filter = 'alle'; KM.sel = id; wechsleAnsicht('kaeufer'); }

// ═════════ Seite „Käufer & Markt“ ═════════
const KM_FILTER = [['auftrag', 'Aufträge & Online'], ['termin', 'Mit Termin / Auftrag'], ['treffer', 'Mit passenden Suchkunden'], ['alle', 'Alle Objekte & Leads']];
function kmObjekte(f){
  const alle = (db.objekte || []).filter(o => o.status !== 'abgeschlossen');
  if(f === 'auftrag') return alle.filter(o => ['auftrag', 'online'].includes(o.status));
  if(f === 'termin') return alle.filter(o => ['termin', 'auftrag', 'online'].includes(o.status) || (typeof objHatTermin === 'function' && objHatTermin(o)));
  if(f === 'treffer') return alle.filter(o => skTrefferFuer(o).length);
  return alle;
}
function kmStandardFilter(){
  if(kmObjekte('auftrag').length) return 'auftrag';
  if(kmObjekte('termin').length) return 'termin';
  if(kmObjekte('treffer').length) return 'treffer';
  return 'alle';
}
function renderKaeufer(main){
  if(!KM.filter) KM.filter = kmStandardFilter();
  const nSk = skListe().filter(g => g.status !== 'erledigt').length;
  main.innerHTML = `
    <div class="aq-kopf"><div class="ic">${IC.kaeufer || IC.kontakte}</div><div><h1>Käufer & Markt</h1><div class="sub">Deine Objekte: Marktpreis, wer passt – und passende Käufer finden.</div></div>
      <div class="knoepfe">
        <button class="secondary" onclick="kgFinden()" title="Zeitung, Kleinanzeigen oder KI-Websuche – Gesuche landen automatisch hier">🔎 Suchkunden finden</button>
        <button onclick="skBearbeiten()">${IC.plus} Suchkunde</button>
      </div></div>
    <div class="vl-tabs km-tabs"><button class="${KM.tab === 'objekte' ? 'an' : ''}" onclick="KM.tab='objekte';renderMain()">🏠 Objekte</button><button class="${KM.tab === 'suchkunden' ? 'an' : ''}" onclick="KM.tab='suchkunden';renderMain()">👥 Suchkunden <span class="km-zahl">${nSk}</span></button></div>
    <div id="kmInhalt"></div>`;
  if(KM.tab === 'suchkunden') kmSuchkunden(); else kmObjekteTab();
}
function kmObjekteTab(){
  const el = document.getElementById('kmInhalt'); if(!el) return;
  el.innerHTML = `<div class="aq-layout"><div style="min-width:0;">
      <div class="aq-filter">
        <select onchange="KM.filter=this.value;KM.sel=null;kmListe()">${KM_FILTER.map(([k, l]) => `<option value="${k}" ${KM.filter === k ? 'selected' : ''}>${l} (${kmObjekte(k).length})</option>`).join('')}</select>
        <div class="such">${IC.lupe}<input placeholder="Suchen …" value="${akqEsc(KM.q)}" oninput="KM.q=this.value;kmListe()"></div>
      </div>
      <div id="kmListe"></div>
    </div><div id="kmDetail"></div></div>`;
  kmListe();
}
function kmListe(){
  const el = document.getElementById('kmListe'); if(!el) return;
  let l = kmObjekte(KM.filter);
  const q = KM.q.trim().toLowerCase();
  if(q) l = l.filter(o => [aqTitel(o), o.ort, o.adresse, o.objektart].join(' ').toLowerCase().includes(q));
  l.sort((a, b) => (['auftrag', 'online'].includes(b.status) - ['auftrag', 'online'].includes(a.status)) || (skTrefferFuer(b).length - skTrefferFuer(a).length) || ((b.createdAt || 0) - (a.createdAt || 0)));
  if(!l.find(o => o.id === KM.sel)) KM.sel = l.length ? l[0].id : null;
  if(!l.length){
    el.innerHTML = `<div class="aq-leer"><b>${KM.filter === 'auftrag' ? 'Noch keine Aufträge' : 'Keine Objekte für diesen Filter'}</b>${KM.filter === 'auftrag' ? 'Sobald ein Lead auf „Auftrag“ oder „Online“ steht, erscheint er hier. Oben kannst du auf „Alle Objekte & Leads“ umschalten.' : 'Filter oben ändern.'}</div>`;
    kmDetail(); return;
  }
  el.innerHTML = l.slice(0, 200).map(o => {
    const n = skTrefferFuer(o).length;
    return `<div class="lc ${o.id === KM.sel ? 'aktiv' : ''}" onclick="KM.sel='${o.id}';kmListe()">
      <div class="lc-bild">${aq2Bild(o, 0)}</div>
      <div class="lc-mitte"><div class="lc-titel">${akqEsc(aqTitel(o))}</div>
        <div class="lc-ort">${IC.pin}${akqEsc([o.adresse, o.ort].filter(Boolean).join(', ') || 'Ort unbekannt')}</div>
        <div class="lc-specs">${o.wohnflaeche ? `<span>${IC.flaeche}${o.wohnflaeche} m²</span>` : ''}${o.zimmer ? `<span>${IC.zimmer}${akqEsc(o.zimmer)} Zi.</span>` : ''}${o.kaufpreis ? `<span class="preis">${aqEur(o.kaufpreis)}</span>` : ''}</div>
        <div class="lc-tags">${aqMarktChip(o)}${aqPreisChip(o)}${n ? `<span class="chip sk-chip">👥 ${n} Suchkunde${n === 1 ? '' : 'n'}</span>` : ''}${o.kiPreis ? '<span class="chip">🤖 KI</span>' : ''}</div></div>
      <div class="lc-rechts"><span class="pill st-${akqEsc(o.status)}">${AQ_ST_KURZ[o.status] || o.status}</span></div><div class="lc-pfeil">›</div></div>`;
  }).join('');
  kmDetail();
}
function kmKaUrl(o){
  const art = o.objektart, miete = skObjMiete(o);
  const kat = miete ? (art === 'Wohnung' ? ['wohnung-mieten', 203] : ['haus-mieten', 205]) : art === 'Wohnung' ? ['wohnung-kaufen', 196] : art === 'Grundstück' ? ['grundstuecke-garten', 207] : ['haus-kaufen', 208];
  const ort = aqOrtText(o).split(/[,(]/)[0].trim().split(/\s+/).slice(0, 2).join(' ');
  return `https://www.kleinanzeigen.de/s-${kat[0]}/anzeige:gesuche/${encodeURIComponent(ort.toLowerCase().replace(/\s+/g, '-'))}/k0c${kat[1]}`;
}
function kmDetail(){
  const el = document.getElementById('kmDetail'); if(!el) return;
  const o = findObjekt(KM.sel);
  if(!o){ el.innerHTML = `<div class="dp"><div class="dp-leer">Links ein Objekt wählen.</div></div>`; return; }
  const mv = aqMarktVergleich(o), fin = skFinanz(o), gruppen = skKaeufergruppen(o, mv), tr = skTrefferFuer(o);
  const auftrag = ['auftrag', 'online'].includes(o.status), E = kmEinst();
  const e0 = x => Math.round(x / 100) * 100;
  el.innerHTML = `<div class="dp"><div class="dp-scroll">
    <div class="dp-kopf">${auftrag ? 'Dein Objekt' : 'Lead / Objekt'}<span class="sp"></span>
      <button class="tb-icon" title="In der Akquise öffnen" onclick="AQ2.status='alle';AQ2.sel='${o.id}';wechsleAnsicht('akquise')">${IC.akquise}</button>
      <button class="tb-icon" title="Alle Felder bearbeiten" onclick="oeffneObjektModal('${o.id}')">${IC.stift}</button></div>
    <div class="dp-bild">${aq2Bild(o, 0)}<span class="pill st-${akqEsc(o.status)} ov">${AQ_ST_KURZ[o.status] || o.status}</span></div>
    <h2>${akqEsc(aqTitel(o))}</h2>
    <div class="lc-ort">${IC.pin}${akqEsc([o.adresse, o.ort].filter(Boolean).join(', ') || 'Ort unbekannt')}</div>
    ${o.kaufpreis ? `<div class="preis">${aqEur(o.kaufpreis)}${skObjMiete(o) ? ' / Monat' : ''}</div>${aqPreisAltHtml(o)}` : ''}
    <div class="dp-specs"><div>${IC.flaeche}${o.wohnflaeche ? o.wohnflaeche + ' m²' : '–'}<small>Wohnfläche</small></div><div>${IC.zimmer}${o.zimmer ? akqEsc(o.zimmer) : '–'}<small>Zimmer</small></div><div>${IC.grund}${o.grundstueck ? Number(o.grundstueck).toLocaleString('de-DE') + ' m²' : '–'}<small>Grundstück</small></div></div>
    ${aq2MarktHtml(o)}
    <div class="dp-abschnitt"><h4>🤖 KI-Einschätzung</h4>
      ${o.kiPreis || o.kiKaeufer ? aqKiHtml(o) : '<div class="km-leer">Noch keine. „KI fragen“ kopiert einen fertigen Prompt: Ist der Preis marktgerecht? Welche Käufer passen? Gibt es passende Gesuche im Netz?</div>'}
      <div class="km-knoepfe"><button class="secondary tiny" onclick="kmKiKopieren('${o.id}')">🤖 KI fragen</button><button class="secondary tiny" onclick="kmKiEinfuegen('${o.id}')">📋 Antwort einfügen</button></div></div>
    <div class="dp-abschnitt"><h4>🎯 Wer passt</h4>
      ${gruppen.length ? `<div class="km-gruppen">${gruppen.map(([t, w]) => `<div><b>${t}</b><span>${akqEsc(w)}</span></div>`).join('')}</div>` : '<div class="km-leer">Für eine Einschätzung fehlen Objektart, Fläche oder Zimmer.</div>'}
      ${fin ? `<div class="km-fin"><div class="km-fin-kopf">💶 Was ein Käufer mitbringen muss</div>
        <div class="km-fin-zahlen"><div><b>≈ ${aqEur(e0(fin.ek))}</b><small>Eigenkapital (${E.ek} % + Nebenkosten ${String(fin.nkProz.toFixed(2)).replace('.', ',')} %)</small></div><div><b>≈ ${aqEur(e0(fin.rate))}</b><small>Monatsrate (${String(E.zins).replace('.', ',')} % Zins, ${String(E.tilgung).replace('.', ',')} % Tilgung)</small></div><div><b>ab ≈ ${aqEur(e0(fin.netto))}</b><small>Haushaltsnetto im Monat (Rate ≤ ${E.quote} %)</small></div></div>
        <div class="mv-sub">Nebenkosten: Grunderwerbsteuer ${String(fin.grest).replace('.', ',')} % (${fin.land === 'BB' ? 'Brandenburg' : 'Berlin'}), Notar & Grundbuch ca. ${String(E.notar).replace('.', ',')} %, Käuferprovision ${String(E.makler).replace('.', ',')} %. Bauzins-Annahme Stand ${E.stand} – <a href="#" onclick="kmZinsAendern();return false;">ändern</a>. Grobe Rechnung, keine Finanzierungsberatung.</div></div>` : ''}
    </div>
    <div class="dp-abschnitt"><h4>👥 Passende Suchkunden ${tr.length ? `<span class="km-zahl">${tr.length}</span>` : ''}</h4>
      ${tr.length ? tr.map(x => kmTrefferHtml(o, x, auftrag)).join('') : `<div class="km-leer">Noch kein passender Suchkunde. Gesuche kommen aus der Zeitung („📄 Zeitung einlesen“), aus der KI-Suche oder von dir („+ Suchkunde“).</div>`}
    </div>
    <div class="dp-abschnitt"><h4>🔎 Käufer finden</h4>
      <div class="km-finden">
        <button class="secondary tiny" onclick="kmKiKopieren('${o.id}')">🤖 KI: passende Kaufgesuche im Netz suchen</button>
        <button class="secondary tiny" onclick="kgOeffnen('${kmKaUrl(o)}')">💬 Kleinanzeigen-Gesuche öffnen</button>
        <button class="secondary tiny" onclick="zlDialog()">📄 Gesuche aus der Zeitung einlesen</button>
      </div>
      <div class="mv-sub">Kleinanzeigen zeigt die Rubrik „${o.objektart === 'Wohnung' ? 'Eigentumswohnungen' : o.objektart === 'Grundstück' ? 'Grundstücke' : 'Häuser zum Kauf'}“, Anzeigentyp Gesuche, Suchwort ${akqEsc(aqOrtText(o).split(/[,(]/)[0] || 'Ort')}. Gefundene Gesuche einfach mit der KI-Antwort übernehmen oder per „+ Suchkunde“ anlegen.</div>
    </div>
  </div></div>`;
}
function kmTrefferHtml(o, x, auftrag){
  const g = x.g, tel = skTel(g), mail = skMailAdr(g), info = (g.informiert || {})[o.id];
  const s = x.m.score >= 85 ? 3 : x.m.score >= 70 ? 2 : 1;
  return `<div class="sk-treffer"><div class="sk-score s${s}">${x.m.score}<small>%</small></div>
    <div class="sk-mitte"><div><b>${akqEsc(skName(g))}</b> <small>${akqEsc([g.quelleText || g.quelle, g.datum ? new Date(g.datum).toLocaleDateString('de-DE') : ''].filter(Boolean).join(' · '))}</small></div>
      <div class="sk-sucht">sucht ${akqEsc(zlGesuchKurz(g))}</div>
      <div class="sk-gruende">${x.m.gruende.map(([ok, t]) => `<span class="${ok ? 'ok' : 'warn'}">${ok ? '✓' : '!'} ${akqEsc(t)}</span>`).join('')}</div>
      ${info ? `<div class="sk-info">✓ informiert am ${new Date(info).toLocaleDateString('de-DE')}</div>` : ''}</div>
    <div class="sk-aktion">${tel ? `<a class="sk-btn" href="tel:${akqEsc(akqTelNorm(tel))}" title="Anrufen: ${akqEsc(tel)}">📞</a>` : ''}${mail ? `<button class="sk-btn" title="E-Mail an ${akqEsc(mail)}" onclick="skMail('${g.id}','${o.id}')">✉️</button>` : ''}${g.link ? `<button class="sk-btn" title="Gesuch öffnen" onclick="window.open('${akqEsc(g.link)}','_blank')">🔗</button>` : ''}${g.chiffre && !tel && !mail ? `<span class="sk-ch" title="Antwort über die Zeitung">Chiffre ${akqEsc(g.chiffre)}</span>` : ''}
      <button class="sk-btn" title="${info ? 'Nicht mehr als informiert markieren' : 'Als informiert markieren'}" onclick="skInformiert('${g.id}','${o.id}')">${info ? '↩' : '✓'}</button></div></div>`;
}
function skMail(gid, oid){
  const g = skFind(gid), o = findObjekt(oid); if(!g || !o) return;
  const auftrag = ['auftrag', 'online'].includes(o.status);
  const eck = [o.wohnflaeche ? o.wohnflaeche + ' m² Wohnfläche' : '', o.zimmer ? o.zimmer + ' Zimmer' : '', o.grundstueck ? o.grundstueck + ' m² Grundstück' : '', o.kaufpreis ? (auftrag ? 'Kaufpreis ' : 'ca. ') + aqEur(o.kaufpreis) : ''].filter(Boolean).join(', ');
  const betreff = (auftrag ? 'Passendes Angebot: ' : 'Zu Ihrem Gesuch: ') + aqTitel(o) + (aqOrtText(o) ? ' in ' + aqOrtText(o) : '');
  const text = `Guten Tag${g.name && !/suchkunde|chiffre/i.test(g.name) && !/^\(/.test(g.name) ? ' ' + g.name.replace(/\s*\(.*\)\s*$/, '') : ''},

ich habe Ihr Gesuch gelesen – Sie suchen ${zlGesuchKurz(g)}.
${auftrag ? `Ich habe aktuell ein Objekt, das gut passen könnte: ${aqTitel(o)} in ${aqOrtText(o) || 'Ihrer Wunschgegend'}${eck ? ' (' + eck + ')' : ''}.

Darf ich Ihnen das Exposé schicken oder einen Besichtigungstermin vorschlagen?` : `Ich habe gerade ein Objekt in Aussicht, das zu Ihrer Suche passen könnte: ${aqTitel(o)} in ${aqOrtText(o) || 'Ihrer Wunschgegend'}${eck ? ' (' + eck + ')' : ''}.

Wenn Sie mögen, nehme ich Sie in meine Käuferliste auf und melde mich, sobald ich Unterlagen habe. Ein kurzes Telefonat wäre ideal.`}

Viele Grüße
Paul Görner
BETTERHOMES · Görner Immobilien`;
  window.open(`mailto:${encodeURIComponent(skMailAdr(g))}?subject=${encodeURIComponent(betreff)}&body=${encodeURIComponent(text)}`, '_blank');
  skInformiert(gid, oid, true);
}
function skInformiert(gid, oid, nurSetzen){
  const g = skFind(gid), o = findObjekt(oid); if(!g || !o) return;
  g.informiert = g.informiert || {};
  if(g.informiert[oid] && !nurSetzen) delete g.informiert[oid];
  else if(!g.informiert[oid]){
    g.informiert[oid] = Date.now();
    (g.verlauf = g.verlauf || []).push({ ts:Date.now(), text:'Informiert über ' + aqTitel(o) });
    try{ aqLog(o, 'info', '👥 Suchkunde informiert: ' + skName(g)); }catch(e){}
  }
  save(); if(aktuelleAnsicht === 'kaeufer') (KM.tab === 'suchkunden' ? kmSuchkunden() : kmDetail());
}
function kmZinsAendern(){
  const E = kmEinst();
  x20Modal(`<div><h3>💶 Annahmen für die Finanzierbarkeit</h3><div class="gs-intro" style="margin-bottom:10px;">Nur für die grobe Rechnung „Was ein Käufer mitbringen muss“. Bauzinsen ändern sich laufend – Stand der Voreinstellung: ${SK_FIN_STD.stand} (rund 4 % für 10 Jahre).</div>
    <div class="zl-felder km-fin-felder">
      <label>Sollzins %<input id="kmZins" type="number" step="0.05" value="${E.zins}"></label><label>Tilgung %<input id="kmTilg" type="number" step="0.5" value="${E.tilgung}"></label>
      <label>Eigenkapital % vom Preis<input id="kmEk" type="number" step="1" value="${E.ek}"></label><label>Rate max. % vom Netto<input id="kmQuote" type="number" step="1" value="${E.quote}"></label>
      <label>Käuferprovision %<input id="kmMakler" type="number" step="0.01" value="${E.makler}"></label><label>Notar & Grundbuch %<input id="kmNotar" type="number" step="0.1" value="${E.notar}"></label></div>
    <div class="modal-actions"><div><button class="secondary" onclick="db.kaeuferEinst={};save();schliesseModal();renderMain()">Voreinstellung</button></div><div class="right"><button class="secondary" onclick="schliesseModal()">Abbrechen</button><button onclick="kmZinsSpeichern()">Speichern</button></div></div></div>`, 560);
}
function kmZinsSpeichern(){
  const v = id => parseFloat(String(document.getElementById(id).value).replace(',', '.'));
  const n = { zins:v('kmZins'), tilgung:v('kmTilg'), ek:v('kmEk'), quote:v('kmQuote'), makler:v('kmMakler'), notar:v('kmNotar') };
  Object.keys(n).forEach(k => { if(!isFinite(n[k]) || n[k] < 0) delete n[k]; });
  if(n.quote === 0) delete n.quote;
  db.kaeuferEinst = Object.assign({}, n, { stand:'eigene Annahme' }); save(); schliesseModal(); renderMain();
}

// ── Suchkunden-Liste ──
function kmSuchkunden(){
  const el = document.getElementById('kmInhalt'); if(!el) return;
  let l = skListe().slice();
  if(KM.skFilter === 'aktiv') l = l.filter(g => g.status !== 'erledigt'); else if(KM.skFilter === 'erledigt') l = l.filter(g => g.status === 'erledigt');
  const q = KM.skQ.trim().toLowerCase();
  if(q) l = l.filter(g => [skName(g), g.text, (g.orte || []).join(' '), g.telefon, g.email, g.quelleText].join(' ').toLowerCase().includes(q));
  l.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
  el.innerHTML = `<div class="aq-filter">
      <select onchange="KM.skFilter=this.value;kmSuchkunden()">${[['aktiv', 'Aktive Suchkunden'], ['erledigt', 'Erledigt'], ['alle', 'Alle']].map(([k, t]) => `<option value="${k}" ${KM.skFilter === k ? 'selected' : ''}>${t}</option>`).join('')}</select>
      <div class="such">${IC.lupe}<input placeholder="Name, Ort, Telefon …" value="${akqEsc(KM.skQ)}" oninput="KM.skQ=this.value;kmSuchkunden();const i=document.querySelector('#kmInhalt .such input');if(i){i.focus();i.setSelectionRange(i.value.length,i.value.length);}"></div>
    </div>
    ${l.length ? `<div class="sk-liste">${l.map(kmSkKarte).join('')}</div>` : `<div class="aq-leer"><b>${skListe().length ? 'Keine Suchkunden für diesen Filter' : 'Noch keine Suchkunden'}</b>Kaufgesuche kommen automatisch aus der Zeitung („📄 Zeitung einlesen“) oder der KI-Suche. Du kannst sie auch von Hand anlegen („+ Suchkunde“).</div>`}`;
}
function kmSkKarte(g){
  const tr = skObjekteFuer(g), tel = skTel(g), mail = skMailAdr(g);
  return `<div class="sk-karte ${g.status === 'erledigt' ? 'erledigt' : ''}">
    <div class="sk-k-kopf"><b>${akqEsc(skName(g))}</b>${g.quelleText || g.quelle ? `<span class="chip">${akqEsc(g.quelleText || g.quelle)}</span>` : ''}<small>${g.datum ? new Date(g.datum).toLocaleDateString('de-DE') : new Date(g.createdAt).toLocaleDateString('de-DE')}</small><span class="sp"></span>
      ${g.status === 'erledigt' ? '<span class="pill">erledigt</span>' : ''}
      <button class="tb-icon" title="Bearbeiten" onclick="skBearbeiten('${g.id}')">${IC.stift}</button>
      <button class="tb-icon" title="${g.status === 'erledigt' ? 'Wieder aktiv' : 'Erledigt (hat gekauft / kein Interesse)'}" onclick="skStatus('${g.id}')">${g.status === 'erledigt' ? '↩' : '✓'}</button>
      <button class="tb-icon" title="Löschen" onclick="skLoeschen('${g.id}')">🗑</button></div>
    <div class="sk-sucht">🔎 sucht <b>${akqEsc(zlGesuchKurz(g))}</b></div>
    <div class="sk-kontakt">${tel ? `<a href="tel:${akqEsc(akqTelNorm(tel))}">📞 ${akqEsc(tel)}</a>` : ''}${mail ? `<a href="mailto:${akqEsc(mail)}">✉️ ${akqEsc(mail)}</a>` : ''}${g.chiffre ? `<span>✉️ Chiffre ${akqEsc(g.chiffre)} (über die Zeitung)</span>` : ''}${g.link ? `<a href="#" onclick="window.open('${akqEsc(g.link)}','_blank');return false;">🔗 Gesuch öffnen</a>` : ''}${!tel && !mail && !g.chiffre && !g.link ? '<span class="zl-warn">keine Kontaktdaten</span>' : ''}</div>
    <div class="sk-passt">${tr.length ? `<span>Passt zu:</span>${tr.slice(0, 6).map(x => `<button class="sk-obj ${['auftrag', 'online'].includes(x.o.status) ? 'auftrag' : ''}" onclick="kmOeffnen('${x.o.id}')" title="${akqEsc(x.m.gruende.map(r => (r[0] ? '✓ ' : '! ') + r[1]).join(' · '))}">${akqEsc(aqTitel(x.o).slice(0, 34))} · <b>${x.m.score} %</b>${['auftrag', 'online'].includes(x.o.status) ? ' · Auftrag' : ''}</button>`).join('')}${tr.length > 6 ? `<span>+${tr.length - 6}</span>` : ''}` : '<span class="km-leer">Noch kein passendes Objekt.</span>'}</div>
    ${g.text ? `<details class="sk-text"><summary>Anzeigentext</summary>${akqEsc(g.text)}${g.notiz ? `<div><b>Notiz:</b> ${akqEsc(g.notiz)}</div>` : ''}</details>` : ''}
  </div>`;
}
function skStatus(id){ const g = skFind(id); if(!g) return; g.status = g.status === 'erledigt' ? 'aktiv' : 'erledigt'; (g.verlauf = g.verlauf || []).push({ ts:Date.now(), text:g.status === 'erledigt' ? 'Erledigt' : 'Wieder aktiv' }); save(); renderMain(); }
function skLoeschen(id){
  const g = skFind(id); if(!g) return;
  const weg = () => { db.gesuche = skListe().filter(x => x.id !== id); save(); renderMain(); akqToast('Suchkunde gelöscht'); };
  if(typeof bestaetigeUnten === 'function') bestaetigeUnten(`Suchkunde „${skName(g)}“ löschen? (Der Kontakt bleibt.)`, weg, 'Löschen'); else if(confirm('Suchkunde löschen?')) weg();
}
const SK_ARTEN_WAHL = ['EFH', 'DHH', 'Reihenhaus', 'Wohnung', 'Grundstück', 'MFH', 'Gewerbe'];
function skBearbeiten(id){
  const g = id ? skFind(id) : null, v = g || { arten:[], orte:[], nutzung:'kauf' };
  const k = g && g.kontaktId ? (db.kontakte || []).find(x => x.id === g.kontaktId) : null;
  x20Modal(`<div id="skModal"><h3>${g ? '✏️ Suchkunde bearbeiten' : '👥 Neuer Suchkunde'}</h3>
    <div class="zl-felder sk-felder">
      <label>Name / wer sucht<input id="skName" value="${akqEsc(v.name || (k && k.name) || '')}" placeholder="z. B. Familie Meier"></label>
      <label>Telefon<input id="skTel" value="${akqEsc(v.telefon || (k && k.telefon) || '')}"></label>
      <label>E-Mail<input id="skMail" value="${akqEsc(v.email || (k && k.email) || '')}"></label>
      <label>Chiffre / Link<input id="skChiffre" value="${akqEsc(v.chiffre || v.link || '')}" placeholder="Chiffre oder https://…"></label>
    </div>
    <div class="vl-lbl">Sucht</div>
    <div class="sk-arten">${SK_ARTEN_WAHL.map(a => `<label class="gs-chk"><input type="checkbox" value="${a}" ${(v.arten || []).includes(a) ? 'checked' : ''}><span>${SK_ART_LANG[a]}</span></label>`).join('')}</div>
    <div class="zl-felder sk-felder">
      <label>Orte (mit Komma)<input id="skOrte" value="${akqEsc((v.orte || []).join(', ') + (v.berlinAlle ? ((v.orte || []).length ? ', ' : '') + 'Berlin' : '') + (v.umland ? ', Umland' : ''))}" placeholder="Falkensee, Dallgow, Spandau"></label>
      <label>Budget bis €<input id="skPreis" value="${v.preisMax ? Number(v.preisMax).toLocaleString('de-DE') : ''}" placeholder="500.000"></label>
      <label>Zimmer ab<input id="skZi" value="${v.zimmerMin || ''}"></label>
      <label>Wohnfläche ab m²<input id="skFl" value="${v.flaecheMin || ''}"></label>
      <label>Grundstück ab m²<input id="skGr" value="${v.grundstueckMin || ''}"></label>
      <label>Kauf oder Miete<select id="skNutzung"><option value="kauf" ${v.nutzung !== 'miete' ? 'selected' : ''}>Kauf</option><option value="miete" ${v.nutzung === 'miete' ? 'selected' : ''}>Miete</option></select></label>
    </div>
    <label class="vl-lbl" style="display:block;">Notiz</label><textarea id="skNotiz" style="min-height:60px;">${akqEsc(v.notiz || '')}</textarea>
    ${g && g.text ? `<details class="sk-text"><summary>Original-Anzeige</summary>${akqEsc(g.text)}</details>` : ''}
    <div class="modal-actions"><span></span><div class="right"><button class="secondary" onclick="schliesseModal()">Abbrechen</button><button onclick="skSpeichern(${g ? `'${g.id}'` : 'null'})">Speichern</button></div></div></div>`, 680);
}
function skSpeichern(id){
  const w = i => String((document.getElementById(i) || {}).value || '').trim();
  const zahl = s => akqZahl(String(s).replace(/[^\d.,]/g, '')) || 0;
  const arten = Array.from(document.querySelectorAll('#skModal .sk-arten input:checked')).map(x => x.value);
  const orteRoh = w('skOrte').split(/\s*[,;\/]\s*|\s+oder\s+/).map(x => x.trim()).filter(Boolean);
  const chl = w('skChiffre');
  const d = { name:w('skName'), telefon:w('skTel'), email:w('skMail').toLowerCase(), chiffre:/^https?:/i.test(chl) ? '' : chl, link:/^https?:/i.test(chl) ? chl : '',
    arten, orte:orteRoh.filter(x => !/^(berlin|umland)$/i.test(x)), berlinAlle:orteRoh.some(x => /^berlin$/i.test(x)), umland:orteRoh.some(x => /^umland$/i.test(x)),
    preisMax:zahl(w('skPreis')), zimmerMin:parseFloat(w('skZi').replace(',', '.')) || 0, flaecheMin:zahl(w('skFl')), grundstueckMin:zahl(w('skGr')), nutzung:w('skNutzung') || 'kauf', notiz:w('skNotiz') };
  if(!d.arten.length && !d.orte.length && !d.preisMax){ akqToast('Bitte mindestens Objektart, Ort oder Budget angeben'); return; }
  let g = id ? skFind(id) : null;
  if(g){
    Object.assign(g, d);
    if(g.kontaktId){ const k = (db.kontakte || []).find(x => x.id === g.kontaktId); if(k){ if(d.telefon) k.telefon = d.telefon; if(d.email) k.email = d.email; } }
    else if(d.telefon || d.email){
      const tel = akqTelNorm(d.telefon);
      let k = db.kontakte.find(x => (d.email && String(x.email || '').toLowerCase() === d.email) || (tel.length >= 7 && akqTelNorm(x.telefon) === tel));
      if(!k){ k = { id:uid(), createdAt:Date.now(), name:d.name || ('Suchkunde (' + (d.telefon || d.email) + ')'), telefon:d.telefon, email:d.email, adresse:'', kontaktart:'kaeufer', quelle:g.quelle || 'Sonstiges', status:'interessent', prioritaet:'mittel', notizen:'Suchkunde: sucht ' + zlGesuchKurz(d) }; db.kontakte.push(k); }
      g.kontaktId = k.id;
    }
    (g.verlauf = g.verlauf || []).push({ ts:Date.now(), text:'Bearbeitet' });
    save();
  } else {
    const r = skUebernehmen([Object.assign({}, d, { text:'', quelle:'von Hand', quelleText:'' })]);
    g = skFind(r.ids[0]);
    if(g){ g.notiz = d.notiz; save(); }
  }
  schliesseModal(); renderMain();
  const n = g ? skObjekteFuer(g).length : 0;
  akqToast(`👥 Suchkunde gespeichert${n ? ` – passt zu ${n} Objekt${n === 1 ? '' : 'en'}` : ''}`);
}

// ═════════ Glocke: neue Suchkunden, die zu Aufträgen passen ═════════
const _skHinweise = tbHinweise;
tbHinweise = function(){
  const l = _skHinweise(), e = db.hinweisEinst || {};
  try{
    if(e.suchkunden !== false){
      const auftraege = (db.objekte || []).filter(o => ['auftrag', 'online'].includes(o.status));
      if(auftraege.length){
        const neu = skListe().filter(g => g.status !== 'erledigt' && Date.now() - (g.createdAt || 0) < 14 * 864e5 && auftraege.some(o => { const m = skPasst(o, g); return m && m.score >= SK_MIN && !(g.informiert || {})[o.id]; }));
        if(neu.length) l.push({ k:'suchkunden', ic:'👥', t:`${neu.length} neue${neu.length === 1 ? 'r' : ''} Suchkunde${neu.length === 1 ? '' : 'n'} passt zu deinen Aufträgen`, s:'Jetzt informieren', f:`KM.tab='objekte';KM.filter='auftrag';wechsleAnsicht('kaeufer')` });
      }
    }
  }catch(err){}
  return l;
};
