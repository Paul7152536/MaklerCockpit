// ═══ MaklerCockpit v43 – „Preis-Analyse“: Prompt, der gezielt auf den erzielbaren Verkaufspreis geht ═══
// Anlass: Der strenge Master-Prompt (Prüfbericht) blockiert ohne belegte Unterlagen jeden Preis („BLOCKED“).
// Die Preis-Analyse verlangt IMMER Preisspanne + wahrscheinlichsten Verkaufspreis + Angebotspreis mit Begründung;
// fehlende Belege machen die Spanne breiter, statt das Ergebnis zu verhindern.
// Objektdaten gehen als lesbarer Steckbrief (mit Herkunft je Angabe) in den Prompt – kein JSON, keine Hausnummer, keine Eigentümerdaten.

function ga43Tag(x){
  if(!x) return '';
  if(x.p === 'Annahme / Schätzung' || (!x.q && x.s === 'assumed')) return 'Annahme';
  const q = x.q || { documented: 'laut Unterlage', owner_statement: 'Eigentümerangabe', visually_inferred: 'Besichtigung', assumed: 'Annahme' }[x.s] || '';
  const p = x.p && x.p !== 'Ungeprüfte Angabe' ? x.p : '';
  return [q, p].filter(Boolean).join(', ');
}
function ga43Zeile(l, f, x, einheit){
  const t = ga43Text(f, x); if(!t) return '';
  const tag = ga43Tag(x), z = [x.b ? 'Bereich ' + x.b : '', x.n ? 'Originalwortlaut „' + String(x.n).slice(0, 200) + '“' : ''].filter(Boolean).join('; ');
  return `- ${l}: ${t}${einheit && !/^[A-Za-zÄÖÜ]/.test(t) ? ' ' + einheit : ''}${tag ? ` [${tag}]` : ''}${z ? ` (${z})` : ''}`;
}
function ga43Steckbrief(e){
  const W = k => e.werte[k], art = (GA35_ARTEN.find(a => a[0] === e.art) || [, ''])[1] || 'unbekannt', aus = [];
  const strasse = String((W('adresse') || {}).v || '').replace(/\s+\d+\s*[a-zA-Z]?(\s*[-–\/]\s*\d+\s*[a-zA-Z]?)?\s*$/, '').trim();
  aus.push('### Objekt und Lage', `- Objektart: ${art}`, strasse ? `- Straße (ohne Hausnummer): ${strasse}` : '');
  ['plz', 'ort', 'ortsteil', 'mikrolage', 'besichtigt'].forEach(k => { const a = GA35_FELDER.find(f => f.k === k); if(a) aus.push(ga43Zeile(a.l, ga43AltDef(a), W(k))); });
  aus.push(`- Bewertungsstichtag: ${e.stichtag || ga35Heute()}`, e.region ? `- Region: ${e.region}` : '');
  GA43_KAT.forEach(g => {
    if(!ga43GrSichtbar(e, g)) return;
    let z = [];
    if(g.rep){
      ((e.gruppen43 || {})[g.id] || []).forEach((en, i) => {
        const w = en.w || {}, teile = g.f.filter(f => ga43Bed(w, f)).map(f => { const t = ga43Text(f, w[f.k]); if(!t) return ''; const tag = ga43Tag(w[f.k]); return `${f.l}: ${t}${f.e && !/^[A-Za-zÄÖÜ]/.test(t) ? ' ' + f.e : ''}${tag ? ` [${tag}]` : ''}${w[f.k].n ? ` („${String(w[f.k].n).slice(0, 120)}“)` : ''}`; }).filter(Boolean);
        if(teile.length) z.push(`- ${GA43_EINTRAG[g.id] || 'Eintrag'} ${i + 1}: ${teile.join('; ')}`);
      });
    } else {
      g.f.forEach(f => {
        if(f.k[0] === '@' || !ga43FeldSichtbar(e, f, e.werte)) return;
        const x = W(f.k); if(!x || !ga43Gesetzt(x)) return;
        z.push(ga43Zeile(f.l, f, x, f.e));
      });
      if(g.id === 'gebaeude' && W('baujahr') && !ga43Leer(W('baujahr')) && ga43Wert(e, 'k_genauigkeit_baujahr') === 'Nur Zeitraum bekannt') z.push(`- Hinweis: Nur der Baujahr-Zeitraum ist bekannt – kein Einzeljahr verwenden.`);
    }
    z = z.filter(Boolean); if(z.length) aus.push('', '### ' + g.t, ...z);
  });
  const sonst = ['brw', 'brw_stichtag', 'erbbau', 'mea', 'hausgeld', 'ruecklage', 'sonderumlage', 'stockwerk'].map(k => { const a = GA35_FELDER.find(f => f.k === k); return a && (!a.nur || !e.art || a.nur.includes(e.art)) ? ga43Zeile(a.l, ga43AltDef(a), W(k), a.e) : ''; }).filter(Boolean);
  if(sonst.length) aus.push('', '### Weitere Angaben', ...sonst);
  const alt = Object.values(e.alt43 || {}).filter(x => String(x.v || '').trim());
  if(alt.length) aus.push('', '### Freitext-Angaben (Objektakte / ältere Erfassung)', ...alt.map(x => `- ${x.l}: ${String(x.v).slice(0, 600)}`));
  if(e.notiz && String(e.notiz).trim()) aus.push('', '### Notizen des Maklers', String(e.notiz).slice(0, 2000));
  return aus.filter(x => x !== '').join('\n');
}
function ga43VergleichText(e){
  const art = { purchase: 'tatsächlicher Kaufpreis', own_closing: 'eigener Abschluss', official_aggregate: 'amtliche Statistik', listing: 'Angebot' };
  const l = (e.vergleich || []).filter(c => c.preis || c.lage);
  if(!l.length) return 'Noch keine – bitte selbst recherchieren.';
  return l.map((c, i) => `${i + 1}. ${art[c.art] || c.art || 'Angebot'} | ${ga43Hausnr(c.lage || 'Lage offen')} | ${c.preis ? c.preis + (c.preisbasis && /m²/.test(c.preisbasis) ? ' €/m²' : ' €') : 'Preis offen'} | ${c.flaeche ? c.flaeche + ' m² ' + (c.flaeche_art || '') : 'Fläche offen'} | Grundstück ${c.grund || '–'} m² | Bj. ${c.baujahr || '–'} | ${c.zustand || ''} | Quelle: ${c.quelle || '–'}${c.beleg ? ' | Beleg liegt vor' : ''}`).join('\n');
}
function ga43SchnellText(e){
  const s = e.schnell; if(!s) return '';
  const r = [];
  if(s.vergleich) r.push(`Vergleichswert (Shooting-Werkzeug): ${ga35Euro(s.vergleich.wert)} aus Ø ${ga35Euro(s.vergleich.mittelpreis)}/m² (${s.vergleich.anzahl} Werte: Portal-Preisatlanten und Inserate)${s.vergleich.formel ? ' – Formel: ' + s.vergleich.formel : ''}`);
  if(s.ertrag) r.push(`Ertragswert (Shooting-Werkzeug): ${ga35Euro(s.ertrag.ertragswert)}`);
  return r.length ? r.join('\n') + '\nNur zur Plausibilität: Portalwerte sind Angebotsniveaus, Faktoren sind Annahmen des Maklers. Falls dort ein Grundstück zusätzlich zum Wohnflächenpreis angesetzt ist, ist das eine Doppelzählung – nicht übernehmen.' : '';
}
function ga43PreisPrompt(id, e){
  const h = ga35Heute(), o = id ? findObjekt(id) : null;
  const kurz = String((o && aqTitel(o)) || 'objekt').toLowerCase().replace(/ä/g, 'ae').replace(/ö/g, 'oe').replace(/ü/g, 'ue').replace(/ß/g, 'ss').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 24);
  const nr = ga35Db().laeufe.filter(l => l.objektId === (id || 'frei') && l.art === 'preis').length + 1;
  const runId = `PA-${h.replace(/-/g, '')}-${kurz || 'objekt'}-v${nr}`;
  const wunsch = e.werte.wunsch && mc24N(e.werte.wunsch.v), angebot = e.werte.angebot && mc24N(e.werte.angebot.v);
  const anh = GA35_UNTERLAGEN.filter(([k]) => e.unterlagen[k]).map(([, l]) => l);
  const p = ga35Pruefen(e), schnell = ga43SchnellText(e);
  const berlin = e.region === 'Berlin' || /^1[0-4]\d{3}$/.test(String((e.werte.plz || {}).v || ''));
  const text = `Du bist erfahrener Immobilienbewerter und Makler für ${berlin ? 'Berlin' : 'Berlin und Brandenburg'}. Ermittle für das Objekt unten den realistisch erzielbaren Verkaufspreis. Ich brauche eine klare Zahl mit Spanne und eine Begründung, die ich dem Eigentümer erklären kann – keinen Gutachten-Vorbehaltstext.

## Spielregeln
1. Du nennst IMMER einen Preis: Preisspanne (von–bis), wahrscheinlichsten Verkaufspreis und empfohlenen Angebotspreis. Fehlende oder ungeprüfte Angaben sind kein Grund, keinen Preis zu nennen. Nimm die Angaben unten als Arbeitsgrundlage (Eigentümerangaben und Annahmen gelten vorläufig als richtig), mach die Spanne bei unsicherer Datenlage breiter und sag, welche Angabe das Ergebnis am stärksten verändern würde und um wie viel Euro.
2. Recherchiere selbst mit der Websuche und öffne jede Quelle: aktuelle Angebote vergleichbarer Objekte (gleiche Objektart, gleicher Ortsteil und direkte Nachbarortsteile, Wohnfläche etwa ±25 %, ähnliches Grundstück, Baujahr und Zustand) – möglichst 6 bis 12 Fälle. Die schon vorhandenen Vergleichsfälle unten prüfst du mit. Nutze außerdem, was erreichbar ist: Immobilienpreis-Info und Marktbericht des Gutachterausschusses (tatsächliche Kaufpreise), Bodenrichtwert (BORIS). Scheitert ein Abruf, mach ohne weiter und erwähne es in einem Satz.
3. Angebotspreise sind keine Verkaufspreise. Leite den erzielbaren Preis über einen begründeten Verhandlungsabschlag ab (als Spanne, Herkunft der Annahme nennen). Tatsächliche Kaufpreise haben Vorrang vor Angeboten.
4. Mach jeden Vergleichsfall vergleichbar: Preis je m² Wohnfläche, dann Zu- und Abschläge in Prozent für Lage, Größe, Grundstück, Baujahr/Zustand/Modernisierung, Ausstattung und Energie – je mit kurzer Begründung. Schlecht passende Fälle gering gewichten oder mit Grund weglassen.
5. Plausibilisiere mit einem zweiten Weg (z. B. Bodenwert aus Bodenrichtwert × Grundstück plus Gebäude-Kurzrechnung, oder amtliches Preisniveau). Grundstück nicht doppelt zählen: Wohnflächenpreise von Häusern enthalten das Grundstück schon. Wirkt eine Angabe unplausibel (z. B. ein Bodenrichtwert, der nicht zur Lage passt), sag das und rechne mit dem recherchierten Wert.
6. Der Wunschpreis des Eigentümers wird erst am Ende zum Vergleich eingeordnet – er darf das Ergebnis nicht beeinflussen.
7. Rechne nach (mit dem Code-Werkzeug, falls vorhanden). Keine erfundenen Zahlen, keine erfundenen Quellen, keine Eigentümerdaten, keine Hausnummer.

## So sieht deine Antwort aus
### 1. Ergebnis (ganz oben, höchstens 8 Zeilen)
- Realistischer Verkaufspreis: … € bis … €
- Wahrscheinlichster Verkaufspreis: … € (≈ … €/m² Wohnfläche)
- Empfohlener Angebotspreis: … € (Verhandlungsspielraum bis … €)
- Wunschpreis des Eigentümers: ${wunsch ? ga35Euro(wunsch) : '(nicht genannt)'} → Einordnung: realistisch / ambitioniert / zu hoch um ca. … %
- Sicherheit der Einschätzung: hoch / mittel / gering – in einem Satz, warum
### 2. Warum dieser Preis
5 bis 7 Punkte in einfacher Sprache, die ich so im Eigentümergespräch sagen kann (Lage, Vergleichsangebote, Zustand, Grundstück, Marktlage …).
### 3. Vergleichsfälle
Tabelle: Nr. | Lage | Objektart | Wohnfläche | Grundstück | Baujahr | Angebots- bzw. Kaufpreis | €/m² | Zu-/Abschläge gesamt mit Kurzbegründung | angepasster €/m² | Gewicht | Link
### 4. Rechenweg
Kurz und nachvollziehbar: gewichteter €/m² → × Wohnfläche → Verhandlungsabschlag → Spanne. Dazu der zweite Weg zur Plausibilisierung in 2–3 Zeilen.
### 5. Preisstrategie
Drei Varianten – schnell verkaufen / marktgerecht / ambitioniert: jeweils Angebotspreis, grob erwartete Vermarktungsdauer und Risiko.
### 6. Was den Preis noch verändert
Höchstens 5 Punkte mit Euro-Wirkung (z. B. „Wohnfläche 150 statt 164 m²: ca. −60.000 €“) und welche Unterlagen ich beim Eigentümer anfordern soll.
### 7. Kopierblock fürs MaklerCockpit – AUSGABE ZUM KOPIEREN
Genau EIN Codeblock (zwischen \`\`\` und \`\`\`), nur dieses JSON, Zahlen ohne Tausenderpunkte:
{"run_id":"${runId}","status":"vorlaeufig oder belastbar","valuation":{"low_eur":0,"central_eur":0,"high_eur":0,"band_type":"erzielbarer Verkaufspreis","quality_grade":"hoch, mittel oder gering"},"angebotspreis_eur":0,"eur_m2":0,"vergleichsfaelle":0}

Wenn du Dateien erstellen kannst: zusätzlich ein Kundenbericht als PDF (höchstens 4 Seiten, Absender Görner Immobilien) mit den Abschnitten 1, 2, 3 und 5 – verständlich für den Eigentümer, ohne interne Kürzel, ohne Hausnummer und ohne Eigentümerdaten.

## Objekt (Erfassung im MaklerCockpit, Stand ${mc24Datum(h)})
Herkunft in eckigen Klammern: Eigentümerangabe, laut Unterlage, Besichtigung, Annahme. „Unbekannt“ oder fehlende Angaben sind keine Negativaussagen.
${ga43Steckbrief(e)}

## Preise des Eigentümers (nur zum Vergleich am Ende)
- Wunschpreis: ${wunsch ? ga35Euro(wunsch) : 'nicht genannt'}
- Aktueller Angebotspreis (falls schon inseriert): ${angebot ? ga35Euro(angebot) : 'nicht inseriert / nicht genannt'}

## Vorhandene Vergleichsfälle (bitte prüfen und ergänzen)
${ga43VergleichText(e)}
${schnell ? `\n## Vorarbeit des Maklers\n${schnell}\n` : ''}
## Unterlagen
${anh.length ? 'Diesem Chat beigefügt: ' + anh.join(', ') + '. Prüfe die Angaben oben dagegen; bei Widerspruch gilt die Unterlage.' : 'Keine Unterlagen beigefügt – alle Angaben stammen aus der Erfassung.'}
${p.fehlt.length || p.warn.length ? `\n## Hinweise aus der Vorprüfung (kein Grund, keinen Preis zu nennen)\n${p.fehlt.map(x => '- ' + x.t.replace(' (ohne das kein Ergebnis)', '')).concat(p.warn.slice(0, 8).map(w => '- ' + w)).join('\n')}` : ''}`;
  return { runId, text };
}
function ga43PreisKopieren(){
  const id = GA35.obj, e = ga35Entwurf(id);
  if(!e.art){ akqToast('Erst die Objektart wählen – die braucht die Preis-Analyse.', 4500); return; }
  const r = ga43PreisPrompt(id, e), g = ga35Db();
  g.laeufe.push({ id: uid(), objektId: id || 'frei', runId: r.runId, art: 'preis', am: Date.now(), stichtag: e.stichtag || ga35Heute(), prompt: r.text, ergebnis: null });
  g.laeufe.filter(l => l.objektId === (id || 'frei') && l.prompt).sort((a, b) => b.am - a.am).slice(5).forEach(l => { delete l.prompt; });
  save();
  if(id){ try{ aqLog(findObjekt(id), 'notiz', `💶 Preis-Analyse vorbereitet (${r.runId})`); }catch(err){} }
  akqKopieren(r.text, 'Preis-Prompt kopiert – in ChatGPT oder Claude (mit Websuche) einfügen, Unterlagen anhängen');
  ga35Neuzeichnen();
}
(function(){
  const _r = ga35Render;
  ga35Render = function(main){
    _r.apply(this, arguments);
    if(GA35.tab === 'schnell') return;
    try{
      const alt = main.querySelector('button[onclick="ga35PromptKopieren()"]');
      if(alt && !main.querySelector('.ga43-preisknopf')){
        alt.textContent = '🔬 Ausführlicher Prüfbericht'; alt.className = 'secondary'; alt.title = 'Strenger Prüfbericht nach dem Master-Prompt – nennt ohne belegte Unterlagen oft keinen Preis';
        alt.insertAdjacentHTML('beforebegin', '<button class="ga43-preisknopf" onclick="ga43PreisKopieren()" title="Prompt für den erzielbaren Verkaufspreis: Spanne, Angebotspreis, Begründung">💶 Preis-Analyse: Prompt kopieren</button>');
        const erg = main.querySelector('button[onclick="ga35ErgebnisDialog()"]'); if(erg) erg.textContent = '📥 Ergebnis einfügen';
        const leiste = alt.closest('.ga35-aktion'); if(leiste) leiste.insertAdjacentHTML('afterend', '<div class="mc24-muted ga43-preisinfo">💶 <b>Preis-Analyse</b>: Preisspanne, wahrscheinlicher Verkaufspreis, Angebotspreis und Begründung fürs Eigentümergespräch. Danach den Kopierblock über „📥 Ergebnis einfügen“ zurückholen. 🔬 Der Prüfbericht ist die strenge Gutachten-Variante.</div>');
      }
    }catch(err){ console.error('preis43', err); }
  };
  const _l = ga35ErgebnisLesen;
  ga35ErgebnisLesen = function(txt){
    const erg = _l.apply(this, arguments);
    try{
      let t = String(txt || '').trim(); const m = /```(?:json)?\s*([\s\S]*?)```/.exec(t); if(m) t = m[1];
      const r = JSON.parse(t.slice(t.indexOf('{'), t.lastIndexOf('}') + 1));
      const n = typeof r.angebotspreis_eur === 'number' ? r.angebotspreis_eur : mc24N(r.angebotspreis_eur);
      if(n && isFinite(n) && n > 0 && n < 1e10) erg.angebot = Math.round(n);
    }catch(e){}
    return erg;
  };
  const _h = ga35LaufHtml;
  ga35LaufHtml = function(l){
    let html = _h.apply(this, arguments);
    if(l.art === 'preis') html = html.replace(`<b>${ga35E(l.runId)}</b>`, `<b>💶 ${ga35E(l.runId)}</b>`);
    if(l.ergebnis && l.ergebnis.angebot) html = html.replace(' · Status ', ` · Angebotspreis <b>${ga35Euro(l.ergebnis.angebot)}</b> · Status `);
    return html;
  };
  const _d = ga35ErgebnisDialog;
  ga35ErgebnisDialog = function(){
    _d.apply(this, arguments);
    try{ const p = document.querySelector('#modalBg p.mc24-muted'); if(p && /report\.json/.test(p.textContent)) p.textContent = 'Den Kopierblock (Preis-Analyse) bzw. report.json (Prüfbericht) aus dem KI-Chat hier einfügen. Übernommen werden nur Preisspanne, Angebotspreis, Status und Sicherheit.'; }catch(e){}
  };
  const st = document.createElement('style');
  st.textContent = `.ga43-preisinfo{font-size:12px;margin:-4px 0 12px}`;
  document.head.appendChild(st);
})();
