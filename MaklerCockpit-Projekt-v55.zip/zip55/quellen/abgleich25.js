// ═══ MaklerCockpit v25 – Abgleich PC ↔ Handy: Oberfläche, Zeitplan, Kalender-Regeln ═══
// Daten laufen über die eigene Google-Brücke (Apps Script) in das Google Drive des Nutzers. Schlüssel bleiben im Hauptprozess bzw. in der App.
const AB25_HANDY = !!(window.pc && window.pc.geraet === 'handy');
const AB25 = { laeuft: false, timer: null, nochmal: false, renderNoetig: false, version: null, statusText: '' };
let AB25ST = null;
function ab25Verfuegbar(){ return !!(window.pc && typeof window.pc.abgleichStand === 'function' && typeof window.pc.google === 'function'); }
function ab25Stand(){
  if(AB25ST) return AB25ST;
  let s = null; try{ const t = window.pc.abgleichStand('lesen'); if(t) s = JSON.parse(t); }catch(e){}
  AB25ST = s && typeof s === 'object' ? s : {};
  if(!AB25ST.geraet) AB25ST.geraet = (AB25_HANDY ? 'handy-' : 'pc-') + Math.random().toString(36).slice(2, 10);
  AB25ST.basis = AB25ST.basis || {}; AB25ST.lokalSeit = AB25ST.lokalSeit || {}; AB25ST.protokoll = AB25ST.protokoll || [];
  return AB25ST;
}
function ab25StandSpeichern(){ try{ if(AB25ST) window.pc.abgleichStand('schreiben', JSON.stringify(AB25ST)); }catch(e){ console.error('ab25 Stand', e); } }
function ab25Aktiv(){ return ab25Verfuegbar() && !!ab25Stand().aktiv; }
function ab25E(s){ return typeof mc24E === 'function' ? mc24E(s) : String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }
function ab25Vor(ts){ if(!ts) return 'noch nie'; const s = Math.round((Date.now() - ts) / 1000); if(s < 60) return 'gerade eben'; if(s < 3600) return 'vor ' + Math.round(s / 60) + ' Min.'; if(s < 86400) return 'vor ' + Math.round(s / 3600) + ' Std.'; return new Date(ts).toLocaleString('de-DE', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }); }
async function ab25Senden(p){ const r = await window.pc.google('abgleich', p); return r || { ok: false, fehler: 'Keine Antwort' }; }
function ab25Kurz(v){ try{ const t = typeof v === 'string' ? v : JSON.stringify(v); return t && t.length > 160 ? t.slice(0, 160) + '…' : t; }catch(e){ return ''; } }

// ── Abgleich ausführen ──
async function ab25Sync(grund, opt){
  if(!ab25Aktiv()) return null;
  if(AB25.laeuft){ AB25.nochmal = true; return null; }
  if(navigator.onLine === false){ ab25Stand().fehler = 'Offline – wird abgeglichen, sobald wieder Netz da ist.'; ab25Stand().code = 'offline'; ab25Anzeigen(); return null; }
  clearTimeout(AB25.timer); AB25.timer = null;
  AB25.laeuft = true; ab25Anzeigen();
  const st = ab25Stand();
  AB25.intern = true; try{ if(typeof _saveTimer !== 'undefined' && _saveTimer){ clearTimeout(_saveTimer); _schreibe(); } }catch(e){} AB25.intern = false;
  try{
    const erg = await AB25K.runde(() => db, st, ab25Senden, Object.assign({ zwischenstand: async () => ab25StandSpeichern() }, opt || {}));
    st.letzter = Date.now(); st.fehler = ''; st.code = ''; st.zuGross = erg.zuGross || []; AB25.version = 2;
    st.letzteZahlen = { gesendet: erg.gesendet, empfangen: erg.empfangen, zusammen: erg.zusammengefuehrt };
    if(erg.protokoll.length) st.protokoll = erg.protokoll.map(p => ({ am: Date.now(), pfad: p.pfad, art: p.art, text: p.text, behalten: ab25Kurz(p.behalten), ersetzt: ab25Kurz(p.ersetzt) })).concat(st.protokoll).slice(0, 60);
    if(erg.geaendert) ab25NachEmpfang(erg.bereiche || []);
    else if(erg.repariert){ AB25.intern = true; try{ _schreibe(); }catch(e){} AB25.intern = false; }
    ab25KalenderTeilen();
    return erg;
  }catch(e){
    st.fehler = String(e.message || e); st.code = e.code || '';
    if(e.code === 'massenloeschung') ab25MassenDialog(e.anzahl);
    if(e.code === 'neustart') ab25Planen(500);
    return null;
  }finally{
    AB25.laeuft = false; ab25StandSpeichern(); ab25Anzeigen();
    if(AB25.nochmal){ AB25.nochmal = false; ab25Planen(1500); }
  }
}
function ab25Planen(ms){ if(!ab25Aktiv()) return; clearTimeout(AB25.timer); AB25.timer = setTimeout(() => ab25Sync('aenderung'), ms == null ? 4000 : ms); }
function ab25ModalOffen(){ const m = document.getElementById('modalBg'); return !!(m && m.classList.contains('show')); }
function ab25NachEmpfang(bereiche){
  AB25.intern = true; try{ if(typeof _saveTimer !== 'undefined' && _saveTimer) clearTimeout(_saveTimer); _schreibe(); }catch(e){ try{ save(); }catch(e2){} } AB25.intern = false;
  // eingebettete Module mit eigener Kopie neu laden
  try{ if(bereiche.includes('hv')){ const fr = document.getElementById('hvFrame'); if(fr && fr.contentWindow && fr.contentWindow.hvReload) fr.contentWindow.hvReload(); } }catch(e){}
  try{ if(bereiche.includes('marktanalysen') || bereiche.includes('immowert')){ const fr = document.getElementById('maFrame'); if(fr && fr.contentWindow && fr.contentWindow.maReload) fr.contentWindow.maReload(); } }catch(e){}
  try{ if(bereiche.some(b => /^jarvis/.test(b)) && aktuelleAnsicht === 'jarvis' && !ab25ModalOffen()) renderMain(); }catch(e){}
  if(ab25ModalOffen()) AB25.renderNoetig = true;
  else { try{ if(aktuelleAnsicht !== 'jarvis') renderMain(); renderNav(); }catch(e){} }
}
// Fehlende Einträge: wirklich löschen oder zurückholen?
function ab25MassenDialog(n){
  mc24Modal(`<h3>⚠️ ${n} Einträge fehlen auf diesem Gerät</h3>
    <p>Seit dem letzten Abgleich fehlen hier ${n} Einträge, die auf deinen anderen Geräten noch da sind. Zum Schutz wurde <b>nichts</b> gelöscht.</p>
    <p>Wenn du sie absichtlich gelöscht hast, kannst du das auf alle Geräte übertragen. Sonst holt das Cockpit sie vom Abgleich-Speicher zurück.</p>
    <div class="modal-actions"><button class="secondary" onclick="schliesseModal(); ab25Sync('loeschen', { loeschenErlaubt: true })">Ja, überall löschen</button><div class="right"><button onclick="ab25Zurueckholen()">Zurückholen (empfohlen)</button></div></div>`, 560);
}
function ab25Zurueckholen(){ schliesseModal(); const st = ab25Stand(); st.basis = {}; st.seit = 0; ab25StandSpeichern(); ab25Sync('zurueckholen', { ohneBasis: 'zusammen' }); }

// ── Kalender-Regeln für mehrere Geräte (v41: PC, Handy, Tablet, zweiter PC) ──
// Neue Termine trägt das Gerät in Google ein, auf dem sie entstanden sind. Termine, die nur in Google angelegt wurden, holt genau EIN Gerät:
// das Kalender-Hauptgerät (db.ab25Haupt, wird mit abgeglichen). Standard: der PC, auf dem das Google-Skript eingerichtet wurde.
function ab25IstHaupt(){
  if(!ab25Aktiv()) return !AB25_HANDY;
  const st = ab25Stand(), h = db && db.ab25Haupt;
  if(!h) return !AB25_HANDY && st.rolle !== 'zweit';
  return h === st.geraet;
}
function ab25DarfAnlegen(t){
  if(!ab25Aktiv()) return true;
  const g = ab25Stand().geraet;
  if(!ab25IstHaupt()) return t.erstelltAuf === g;
  if(t.erstelltAuf && t.erstelltAuf !== g && Date.now() - (t.createdAt || 0) < 20 * 60e3) return false;
  return true;
}
function ab25ImportErlaubt(){ return !ab25Aktiv() ? true : ab25IstHaupt(); }
function ab25HauptWerden(){
  bestaetigeUnten('Dieses Gerät zum Kalender-Hauptgerät machen? Es holt dann Termine, die nur in Google angelegt wurden. Das bisherige Hauptgerät hört damit auf.', () => {
    db.ab25Haupt = ab25Stand().geraet; save(); akqToast('📅 Dieses Gerät ist jetzt das Kalender-Hauptgerät'); ab25Dialog(true);
  }, 'Hauptgerät werden');
}
function ab25KalenderTeilen(){
  try{
    const c = typeof gsCfg === 'function' ? gsCfg() : null; if(!c) return;
    const haupt = ab25IstHaupt();
    if(haupt && !db.ab25Haupt && ab25Aktiv() && !AB25_HANDY){ db.ab25Haupt = ab25Stand().geraet; save(); }
    if(haupt && c.kalenderId){ const neu = { kalenderId: c.kalenderId, kalenderName: c.kalenderName || '' }; if(!db.ab25Kalender || db.ab25Kalender.kalenderId !== neu.kalenderId || db.ab25Kalender.kalenderName !== neu.kalenderName){ db.ab25Kalender = neu; save(); } }
    if(!haupt && !c.kalenderId && db.ab25Kalender && db.ab25Kalender.kalenderId){ c.kalenderId = db.ab25Kalender.kalenderId; c.kalenderName = db.ab25Kalender.kalenderName || ''; c.pausiert = false; save(); if(typeof gsPlanen === 'function') setTimeout(() => { try{ gsStatusLaden && gsStatusLaden().then(() => gsPlanen(1500)); }catch(e){} }, 500); }
  }catch(e){}
}

// ── Vor jedem Schreiben: neue Termine diesem Gerät zuordnen, danach Abgleich planen ──
const _ab25Schreibe = _schreibe;
_schreibe = function(){
  if(window.__mcNichtSpeichern){ _saveTimer = null; return; }   // nach einem Import: alten Stand nicht mehr zurückschreiben
  try{
    if(ab25Verfuegbar()){
      const st = ab25Stand();
      for(const t of db.termine || []) if(!t.erstelltAuf && !st.basis['termine|' + t.id]) t.erstelltAuf = st.geraet;
    }
  }catch(e){}
  const r = _ab25Schreibe.apply(this, arguments);
  // v34: Änderungen während eines laufenden Abgleichs gleich danach nachschicken (nicht erst nach 2 Minuten)
  try{ if(ab25Aktiv()){ if(!AB25.laeuft) ab25Planen(); else if(!AB25.intern) AB25.nochmal = true; } }catch(e){}
  return r;
};
const _ab25Schliesse = schliesseModal;
schliesseModal = function(){ const r = _ab25Schliesse.apply(this, arguments); if(AB25.renderNoetig){ AB25.renderNoetig = false; setTimeout(() => { try{ renderMain(); renderNav(); }catch(e){} }, 0); } return r; };

// ── Anzeige (Seitenleiste / Kopfzeile) ──
function ab25Anzeigen(){
  let el = document.getElementById('ab25Status');
  if(!ab25Verfuegbar()) return;
  if(!el){
    const fuss = document.querySelector('.sb-fuss');
    if(!fuss || !fuss.parentNode) return;
    el = document.createElement('div'); el.id = 'ab25Status'; el.className = 'ab25-status'; el.onclick = () => ab25Dialog();
    fuss.parentNode.insertBefore(el, fuss);
  }
  const st = ab25Stand();
  if(!st.aktiv){ el.innerHTML = AB25_HANDY ? '<span class="ab25-p grau"></span> Nicht gekoppelt' : '<span class="ab25-p grau"></span> 🔗 Abgleich aus'; el.title = 'Geräte koppeln und abgleichen'; return; }
  const farbe = AB25.laeuft ? 'blau' : st.fehler ? 'rot' : 'gruen';
  el.innerHTML = `<span class="ab25-p ${farbe}"></span> ${AB25.laeuft ? 'Gleiche ab …' : st.fehler ? 'Abgleich: Problem' : 'Abgeglichen ' + ab25Vor(st.letzter)}`;
  el.title = st.fehler || ('Letzter Abgleich: ' + (st.letzter ? new Date(st.letzter).toLocaleString('de-DE') : '–'));
}
setInterval(() => { try{ ab25Anzeigen(); }catch(e){} }, 30000);
const _ab25RenderNav = renderNav;
renderNav = function(){ const r = _ab25RenderNav.apply(this, arguments); try{ ab25Anzeigen(); }catch(e){} return r; };

// ── Einrichtungs-Dialog ──
function ab25Code(){ return (typeof GS_SKRIPT_VORLAGE === 'string' ? GS_SKRIPT_VORLAGE : ''); }
async function ab25SkriptCodeKopieren(){
  const sk = await window.pc.google('skriptSchluessel');
  if(!sk || !sk.schluessel){ akqToast('Schlüssel nicht verfügbar'); return; }
  const code = ab25Code().replace('%%SCHLUESSEL%%', sk.schluessel);
  try{ await navigator.clipboard.writeText(code); akqToast('📋 Neuer Skript-Code kopiert'); }catch(e){ mc24Kopieren ? mc24Kopieren(code) : null; }
}
async function ab25Pruefen(){
  const box = document.getElementById('ab25Pruef'); if(box) box.innerHTML = '⏳ Prüfe dein Google-Skript …';
  const st = await window.pc.google('status');
  if(!st || !st.verbunden || st.modus !== 'skript'){ AB25.version = 0; if(box) box.innerHTML = ''; return ab25Dialog(); }
  const t = await window.pc.google('abgleich', { aktion: 'test' });
  AB25.version = t && t.ok ? (t.version || 1) : (t && t.code === 'skript_alt' ? 1 : (t && t.version) || 1);
  AB25.statusText = t && t.ok ? '' : ((t && t.fehler) || '');
  ab25Dialog(true);
}
async function ab25Dialog(geprueft){
  if(!ab25Verfuegbar()){ akqToast('Der Abgleich ist in dieser Version nicht verfügbar'); return; }
  if(AB25_HANDY) return ab25HandyDialog();
  const st = ab25Stand();
  const g = await window.pc.google('status');
  const skript = g && g.verbunden && g.modus === 'skript';
  if(skript && AB25.version == null) return ab25Pruefen();
  let inhalt = '';
  if(!skript){
    inhalt = `<div class="ab41-weg"><b>Hast du das Cockpit schon auf einem anderen Gerät gekoppelt (PC, Handy oder Tablet)?</b><p class="mc24-muted">Dann dieses Gerät einfach mit dem Kopplungscode verbinden – kein Google-Skript einrichten nötig. Den Code zeigt jedes gekoppelte Gerät unter <b>⚙ → Geräte & Abgleich → Kopplungscode anzeigen</b>.</p><button onclick="ab41KoppelDialog()">🔗 Mit Kopplungscode verbinden</button></div>
      <h4>Erstes Gerät einrichten</h4><p>Für den Abgleich nutzt das Cockpit dein <b>eigenes Google-Skript</b> (dieselbe Brücke wie für den Kalender). Die Daten liegen dann in deinem Google Drive im Ordner „MaklerCockpit-Abgleich“ – kostenlos und nur in deinem Konto.</p>
      <p>${g && g.verbunden ? 'Dein Kalender ist über die Google-Cloud-Anmeldung verbunden – dafür bitte auf die Skript-Verbindung umstellen.' : 'Google ist noch nicht verbunden.'}</p>
      <div class="modal-actions"><span></span><div class="right"><button class="secondary" onclick="schliesseModal()">Später</button><button onclick="schliesseModal(); gsAnleitung()">Google-Skript einrichten</button></div></div>`;
  } else if((AB25.version || 1) < 2){
    inhalt = `<p>Dein Google-Skript ist noch <b>Version 1</b> (nur Kalender). Für den Abgleich braucht es einmal den neuen Code – deine Web-App-Adresse bleibt gleich:</p>
      <ol class="gs-schritte">
        <li><b>Neuen Code kopieren</b> <button class="secondary tiny" onclick="ab25SkriptCodeKopieren()">📋 Code kopieren</button></li>
        <li>${typeof gsLink === 'function' ? gsLink('https://script.google.com/home', 'script.google.com') : 'script.google.com'} öffnen → dein Projekt <i>MaklerCockpit Kalender</i> → den alten Code komplett ersetzen → speichern (<b>Strg + S</b>).</li>
        <li><b>Bereitstellen</b> → <i>Bereitstellungen verwalten</i> → beim bestehenden Eintrag auf ✎ <b>Bearbeiten</b> → Version: <b>Neue Version</b> → <b>Bereitstellen</b>.</li>
        <li>Google fragt nach Zugriff auf <b>Google Drive</b> (dort liegen die Abgleich-Daten): <b>Zugriff autorisieren</b> → dein Konto → <i>Erweitert</i> → <i>Zu … wechseln</i> → <b>Zulassen</b>.</li>
        <li>Hier auf <b>Prüfen</b> klicken.</li>
      </ol>
      ${AB25.statusText ? `<div class="gs-fehler">${ab25E(AB25.statusText)}</div>` : ''}<div id="ab25Pruef" class="mc24-muted"></div>
      <div class="modal-actions"><span></span><div class="right"><button class="secondary" onclick="schliesseModal()">Später</button><button onclick="ab25Pruefen()">Prüfen</button></div></div>`;
  } else {
    const z = st.letzteZahlen || {};
    const prot = (st.protokoll || []).slice(0, 12);
    inhalt = `<div class="ab25-leiste"><span class="ab25-p ${st.aktiv ? (st.fehler ? 'rot' : 'gruen') : 'grau'}"></span><div><b>${st.aktiv ? (st.fehler ? 'Abgleich mit Problem' : 'Abgleich ist eingeschaltet') : 'Abgleich ist aus'}</b><div class="mc24-muted">${st.aktiv ? 'Letzter Abgleich ' + ab25Vor(st.letzter) + (z.gesendet != null ? ` · ${z.gesendet} gesendet, ${z.empfangen} empfangen` : '') : 'Google-Skript Version 2 ist bereit.'}${st.fehler ? '<br><span class="mc24-rot">' + ab25E(st.fehler) + '</span>' : ''}</div></div>
        <span class="sp"></span>${st.aktiv ? `<button class="secondary tiny" onclick="ab25Sync('manuell').then(() => ab25Dialog(true))">⟳ Jetzt abgleichen</button>` : ''}</div>
      ${st.aktiv ? `
        <h4>🔗 Weiteres Gerät koppeln (Handy, Tablet, zweiter PC)</h4>
        <ol class="gs-schritte"><li><b>Handy:</b> App <b>MaklerCockpit Handy</b> installieren → „Koppeln“. <b>Tablet / zweiter PC:</b> MaklerCockpit-exe starten → ⚙ → <b>Geräte & Abgleich</b> → „Mit Kopplungscode verbinden“.</li>
          <li>Hier den Kopplungscode anzeigen und übertragen: QR-Code mit der Kamera scannen (Handy-Kamera oder Windows-App „Kamera“) und den Text kopieren – oder den Code dir selbst schicken und danach löschen.</li>
          <li>Das neue Gerät holt alle Daten. Jedes gekoppelte Gerät kann den Code für das nächste Gerät anzeigen.</li></ol>
        <div id="ab25Kopplung"><button onclick="ab25KopplungZeigen()">Kopplungscode anzeigen</button> <span class="mc24-muted">Der Code enthält den Zugang zu deinen Daten – nur auf eigene Geräte übertragen.</span></div>
        ${(st.zuGross || []).length ? `<div class="mc24-hinweis">${st.zuGross.length} sehr große Einträge (z. B. Fotos in Analysen) bleiben nur auf diesem Gerät.</div>` : ''}
        ${prot.length ? `<details class="ab25-prot"><summary>Protokoll: ${prot.length} zusammengeführte Änderungen</summary>${prot.map(p => `<div class="ab25-pz"><span class="mc24-muted">${new Date(p.am).toLocaleString('de-DE', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' })}</span> ${ab25E(p.text)} <code>${ab25E(p.pfad)}</code>${p.ersetzt ? `<div class="mc24-muted">ersetzt: ${ab25E(p.ersetzt)}</div>` : ''}</div>`).join('')}</details>` : ''}
        <details class="ab25-prot"><summary>Erweitert</summary>
          <p class="mc24-muted">Gerät: ${ab25E(st.geraet)} · Stand ${st.seit || 0}</p>
          <p class="mc24-muted">📅 Kalender: ${ab25IstHaupt() ? '<b>Dieses Gerät ist das Kalender-Hauptgerät</b> – es holt Termine, die nur in Google angelegt wurden.' : 'Ein anderes Gerät ist das Kalender-Hauptgerät. Dieses Gerät trägt nur seine eigenen neuen Termine in Google ein.'}</p>
          ${ab25IstHaupt() ? '' : '<button class="secondary tiny" onclick="ab25HauptWerden()">Zum Kalender-Hauptgerät machen</button>'}
          <button class="secondary tiny" onclick="ab25Ausschalten()">Abgleich auf diesem PC ausschalten</button>
          <button class="secondary tiny" onclick="ab25Neuaufbau()">Abgleich-Speicher leeren und neu hochladen</button>
        </details>` : `
        <p>Beim Einschalten lädt der PC einmal alle Cockpit-Daten in deinen Google-Drive-Ordner „MaklerCockpit-Abgleich“. Danach gleicht er Änderungen automatisch ab (nach jedem Speichern und alle 2 Minuten).</p>
        <p class="mc24-muted">Bleibt nur auf diesem Gerät: Google-Zugang, Cloud-Sicherungs-Ordner, Kalender-Einstellung, ein ggf. eingetragener KI-API-Schlüssel und die Unterlagen-Dateien.</p>`}
      <div class="modal-actions"><span></span><div class="right"><button class="secondary" onclick="schliesseModal()">Schließen</button>${st.aktiv ? '' : '<button onclick="ab25Einschalten()">Abgleich einschalten</button>'}</div></div>`;
  }
  mc24Modal(`<h3>🔗 Geräte & Abgleich</h3>${inhalt}`, 680);
}
async function ab25Einschalten(){
  const st = ab25Stand(); st.aktiv = true; st.fehler = ''; ab25StandSpeichern();
  mc24Modal(`<h3>📱 Abgleich wird eingerichtet</h3><p>⏳ Die Daten werden hochgeladen – je nach Menge 10 Sekunden bis wenige Minuten.</p>`, 480);
  const erg = await ab25Sync('einschalten');
  if(erg){ akqToast(`✅ Abgleich eingeschaltet – ${erg.gesendet} Einträge hochgeladen`); }
  ab25Dialog(true);
}
function ab25Ausschalten(){ const st = ab25Stand(); st.aktiv = false; ab25StandSpeichern(); ab25Anzeigen(); ab25Dialog(true); }
function ab25Neuaufbau(){
  bestaetigeUnten('Abgleich-Speicher in Google Drive leeren und mit den Daten dieses PCs neu aufbauen? Das Handy holt danach alles neu.', async () => {
    const r = await window.pc.google('abgleich', { aktion: 'abgleichLeeren', bestaetigung: 'LEEREN' });
    if(!r || !r.ok){ akqToast('Leeren fehlgeschlagen: ' + ((r && r.fehler) || '')); return; }
    const st = ab25Stand(); st.basis = {}; st.lokalSeit = {}; st.seit = 0; st.epoche = null; ab25StandSpeichern();
    await ab25Sync('neuaufbau', { ohneBasis: 'zusammen' }); ab25Dialog(true);
  });
}
async function ab25KopplungZeigen(){
  const r = await window.pc.google('kopplung');
  const box = document.getElementById('ab25Kopplung'); if(!box) return;
  if(!r || !r.ok){ box.innerHTML = '<span class="mc24-rot">' + ab25E((r && r.fehler) || 'Nicht möglich') + '</span>'; return; }
  let svg = '';
  try{ const q = qrcode(0, 'M'); q.addData(r.code); q.make(); svg = q.createSvgTag({ cellSize: 4, margin: 3, scalable: true }); }catch(e){}
  box.innerHTML = `<div class="ab25-kopp"><div class="ab25-qr">${svg}</div><div><label>Kopplungscode</label><textarea readonly rows="4" onclick="this.select()">${ab25E(r.code)}</textarea>
    <button class="secondary tiny" onclick="navigator.clipboard.writeText(${ab25E(JSON.stringify(r.code))}).then(()=>akqToast('📋 Kopplungscode kopiert'))">📋 Kopieren</button>
    <div class="mc24-muted">Nicht weitergeben. Wer den Code hat, kann deine Cockpit-Daten lesen. Falls er doch in falsche Hände gerät: im Google-Skript einen neuen Schlüssel eintragen und neu koppeln.</div></div></div>`;
}

// ── Handy: Koppeln / Status ──
function ab25HandyDialog(){
  const st = ab25Stand();
  const gekoppelt = window.pc.gekoppelt && window.pc.gekoppelt();
  if(!gekoppelt || !st.aktiv){
    mc24Modal(`<h3>🔗 Koppeln</h3>
      <p>Auf einem schon gekoppelten Gerät (PC, Tablet oder Handy): <b>⚙ → Geräte & Abgleich → Kopplungscode anzeigen</b>. Den QR-Code mit der Kamera scannen, Text kopieren und hier einfügen.</p>
      <textarea id="ab25Code" rows="4" placeholder="MC1-…"></textarea>
      <div id="ab25KStatus" class="mc24-muted"></div>
      <div class="ab42-retten"><b>Daten weg?</b> Wenn das Handy schon gekoppelt war, kommen nach dem Koppeln alle Daten aus dem Abgleich zurück. Ohne Abgleich: <button class="secondary tiny" onclick="mc42Wiederherstellen()">📂 Aus Sicherungsdatei wiederherstellen</button><div class="mc24-muted">Die App legt täglich eine Sicherung in <b>Downloads/MaklerCockpit/Sicherungen</b> ab – die bleibt auch beim Deinstallieren erhalten.</div></div>
      <div class="modal-actions"><span></span><div class="right"><button class="secondary" onclick="schliesseModal()">Später</button><button onclick="ab25Koppeln()">Koppeln</button></div></div>`, 520);
    return;
  }
  const z = st.letzteZahlen || {};
  mc24Modal(`<h3>🔗 Geräte & Abgleich</h3>
    <div class="ab25-leiste"><span class="ab25-p ${st.fehler ? 'rot' : 'gruen'}"></span><div><b>${st.fehler ? 'Problem beim Abgleich' : 'Gekoppelt'}</b><div class="mc24-muted">Letzter Abgleich ${ab25Vor(st.letzter)}${z.gesendet != null ? ` · ${z.gesendet} gesendet, ${z.empfangen} empfangen` : ''}${st.fehler ? '<br><span class="mc24-rot">' + ab25E(st.fehler) + '</span>' : ''}</div></div></div>
    <h4>Weiteres Gerät koppeln (Tablet, zweiter PC, Handy)</h4>
    <div id="ab25Kopplung"><button class="secondary" onclick="ab25KopplungZeigen()">Kopplungscode anzeigen</button> <span class="mc24-muted">Nur auf eigene Geräte übertragen.</span></div>
    <p class="mc24-muted">📅 ${ab25IstHaupt() ? 'Dieses Gerät ist das Kalender-Hauptgerät.' : 'Neue Termine von hier trägt das Handy selbst in Google ein; Termine aus Google holt das Kalender-Hauptgerät.'}</p>
    <p class="mc24-muted">💾 Tägliche Sicherung: <b>Downloads/MaklerCockpit/Sicherungen</b> (bleibt auch beim Deinstallieren). <button class="secondary tiny" onclick="mc42JetztSichern()">Jetzt sichern</button> <button class="secondary tiny" onclick="mc42Wiederherstellen()">Wiederherstellen …</button></p>
    <p class="mc24-muted">Unterlagen-Dateien (PDFs), Zeitungsseiten-Auslesen und das Kleinanzeigen-Fenster gibt es nur am PC.</p>
    <div class="modal-actions"><button class="secondary" onclick="ab25Entkoppeln()">Entkoppeln</button><div class="right"><button class="secondary" onclick="schliesseModal()">Schließen</button><button onclick="ab25Sync('manuell').then(() => ab25HandyDialog())">⟳ Jetzt abgleichen</button></div></div>`, 520);
}
async function ab25Koppeln(){
  const code = String((document.getElementById('ab25Code') || {}).value || '').trim();
  const box = document.getElementById('ab25KStatus');
  if(!/^MC1-[\w-]{20,}$/.test(code)){ if(box) box.innerHTML = '<span class="mc24-rot">Das ist kein gültiger Kopplungscode (beginnt mit „MC1-“).</span>'; return; }
  if(box) box.textContent = '⏳ Verbinde …';
  const r = await window.pc.koppeln(code);
  if(!r || !r.ok){ if(box) box.innerHTML = '<span class="mc24-rot">' + ab25E((r && r.fehler) || 'Kopplung fehlgeschlagen') + '</span>'; return; }
  const st = ab25Stand(); st.aktiv = true; st.basis = {}; st.seit = 0; st.lokalSeit = {}; st.fehler = ''; ab25StandSpeichern();
  if(box) box.textContent = '⏳ Hole alle Daten vom PC …';
  const erg = await ab25Sync('kopplung');
  schliesseModal();
  if(erg){ akqToast(`✅ Gekoppelt – ${erg.empfangen} Einträge geholt`); try{ if(typeof gsStatusLaden === 'function') gsStatusLaden(); }catch(e){} renderNav(); wechsleAnsicht(typeof ak24An === 'function' && ak24An() ? 'heute' : 'akquise'); }
  else ab25HandyDialog();
}
function ab25Entkoppeln(){
  bestaetigeUnten('Handy entkoppeln? Die Daten auf dem Handy werden gelöscht (auf den anderen Geräten bleibt alles). Vorher wird eine Sicherung in Downloads/MaklerCockpit/Sicherungen abgelegt.', () => {
    try{ const r = window.pc.sicherungExtern && window.pc.sicherungExtern(JSON.stringify(db), 'vor-entkoppeln'); if(window.pc.sicherungExtern && !(r && r.ok) && !confirm('Die Sicherung konnte nicht abgelegt werden (' + ((r && r.fehler) || '') + '). Trotzdem entkoppeln und die Daten auf dem Handy löschen?')) return; }catch(e){}
    try{ window.pc.entkoppeln && window.pc.entkoppeln(); }catch(e){}
    try{ window.pc.abgleichStand('loeschen'); }catch(e){}
    AB25ST = null;
    try{ window.pc.importieren('{}'); }catch(e){}
    window.__mcNichtSpeichern = true;
    location.reload();
  });
}

// ── Menü, Hinweise, Zeitplan ──
const _ab25Menue = tbMenue;
tbMenue = function(ev, art){
  const r = _ab25Menue.apply(this, arguments);
  try{
    const m = document.getElementById('tbMenue'); const st = ab25Verfuegbar() ? ab25Stand() : null;
    if(m && art !== 'hinweise' && st) m.insertAdjacentHTML('afterbegin', `<div class="mi" onclick="tbMenueZu();ab25Dialog()">🔗<div>Geräte & Abgleich<small>${st.aktiv ? (st.fehler ? 'Problem: ' + ab25E(st.fehler.slice(0, 50)) : 'abgeglichen ' + ab25Vor(st.letzter)) : (AB25_HANDY ? 'mit dem PC koppeln' : 'Cockpit auch auf dem Handy nutzen')}</small></div></div>`);
  }catch(e){}
  return r;
};
const _ab25Hinweise = tbHinweise;
tbHinweise = function(){
  const l = _ab25Hinweise.apply(this, arguments);
  try{ const st = ab25Stand(); if(ab25Aktiv() && st.fehler && st.code !== 'offline') l.unshift({ k: 'ab25', ic: '🔗', t: 'Abgleich: ' + st.fehler.slice(0, 90), s: 'Ansehen', f: 'ab25Dialog()' }); }catch(e){}
  return l;
};
window.addEventListener('load', () => {
  if(!ab25Verfuegbar()) return;
  setTimeout(() => { ab25Anzeigen(); if(ab25Aktiv()) ab25Sync('start'); else if(AB25_HANDY) ab25HandyDialog(); }, 1500);
  setInterval(() => { if(ab25Aktiv() && !AB25.laeuft) ab25Sync('intervall'); }, AB25_HANDY ? 60000 : 120000);
  document.addEventListener('visibilitychange', () => { if(document.visibilityState === 'visible') ab25Planen(800); });
  window.addEventListener('online', () => ab25Planen(1000));
});

// ── v41: PC / Tablet mit dem Kopplungscode eines anderen Geräts verbinden ──
function ab41KoppelDialog(){
  mc24Modal(`<h3>🔗 Mit Kopplungscode verbinden</h3>
    <p>Auf einem schon gekoppelten Gerät (PC, Handy oder Tablet): <b>⚙ → Geräte & Abgleich → Kopplungscode anzeigen</b>. Den Text hier einfügen. Tipp: Den QR-Code kann die Windows-App „Kamera“ lesen.</p>
    <textarea id="ab41Code" rows="4" placeholder="MC1-…"></textarea>
    <p class="mc24-muted">Dieses Gerät holt danach alle Daten aus dem Abgleich. Was hier schon eingetragen ist, bleibt erhalten und wird dazugenommen. Vorher wird eine Sicherung angelegt.</p>
    <div id="ab41Status" class="mc24-muted"></div>
    <div class="modal-actions"><span></span><div class="right"><button class="secondary" onclick="schliesseModal()">Abbrechen</button><button onclick="ab41Koppeln()">Verbinden</button></div></div>`, 560);
}
async function ab41Koppeln(){
  const code = String((document.getElementById('ab41Code') || {}).value || '').replace(/\s+/g, '');
  const box = document.getElementById('ab41Status');
  if(!/^MC1-[\w-]{20,}$/.test(code)){ if(box) box.innerHTML = '<span class="mc24-rot">Das ist kein gültiger Kopplungscode (beginnt mit „MC1-“).</span>'; return; }
  if(box) box.textContent = '⏳ Verbinde mit deinem Google-Skript …';
  const r = await window.pc.google('koppeln', code);
  if(!r || !r.ok){ if(box) box.innerHTML = '<span class="mc24-rot">' + ab25E((r && r.fehler) || 'Kopplung fehlgeschlagen') + '</span>'; return; }
  try{ if(typeof window.pc.sicherungSchreiben === 'function') window.pc.sicherungSchreiben('vor-kopplung-' + Date.now() + '.json', JSON.stringify(db)); }catch(e){}
  const st = ab25Stand(); st.aktiv = true; st.rolle = 'zweit'; st.basis = {}; st.seit = 0; st.lokalSeit = {}; st.fehler = ''; ab25StandSpeichern();
  if(box) box.textContent = '⏳ Hole alle Daten …';
  const erg = await ab25Sync('kopplung');
  schliesseModal();
  if(erg){ akqToast(`✅ Gekoppelt – ${erg.empfangen} Einträge geholt`); try{ if(typeof gsStatusLaden === 'function') gsStatusLaden(); }catch(e){} renderNav(); renderMain(); }
  else ab25Dialog(true);
}
