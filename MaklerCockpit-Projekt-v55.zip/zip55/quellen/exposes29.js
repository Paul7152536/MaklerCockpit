// ═══ MaklerCockpit v29 – Alle neuen Exposés auf Knopfdruck öffnen ═══
// Akquise: Leads mit Status „Neu“ und Exposé-Link (berücksichtigt Ort/Objektart/Suche) → im Browser öffnen.
// PC: alle auf einmal (bei vielen wahlweise in 10er-Portionen). Handy: eins nach dem anderen über eine Leiste.
const EX29 = { rest: [], gesamt: 0, offen: 0, portion: 10, aktuell: null };
function ex29Handy(){ return !!(window.pc && window.pc.geraet === 'handy'); }
function ex29Url(o){ return o && o.link ? mc24SicherLink(String(o.link).trim()) : ''; }
function ex29Liste(){
  let l = [];
  const alt = AQ2.status; AQ2.status = 'neu';
  try{ l = aqGefiltert(); }catch(e){ l = (db.objekte || []).slice(); } finally { AQ2.status = alt; }
  const schon = new Set();
  return l.filter(o => {
    if(!o || o.status !== 'neu') return false;
    const u = ex29Url(o); if(!u || schon.has(u)) return false;
    schon.add(u); return true;
  });
}
function ex29BalkenHtml(){
  const n = ex29Liste().length;
  if(!n) return '';
  const filter = AQ2.ort || AQ2.art || AQ2.q;
  return `<div class="ex29-balken"><span>🔗 <b>${n}</b> neue${n === 1 ? 'r' : ''} Lead${n === 1 ? '' : 's'} mit Exposé-Link${filter ? ' <span class="ex29-filter">(gefiltert)</span>' : ''}</span>
    <button class="secondary" onclick="ex29Oeffnen()">${ex29Handy() ? 'Nacheinander öffnen' : (n === 1 ? 'Exposé öffnen' : `Alle ${n} öffnen`)}</button></div>`;
}
function ex29BalkenSetzen(){
  const liste = document.getElementById('aqListe'); if(!liste) return;
  let b = document.getElementById('ex29Balken');
  if(!b){ b = document.createElement('div'); b.id = 'ex29Balken'; liste.parentNode.insertBefore(b, liste); }
  b.innerHTML = ex29BalkenHtml();
}
const _ex29Liste = aq2Liste;
aq2Liste = function(){ const r = _ex29Liste.apply(this, arguments); try{ ex29BalkenSetzen(); }catch(e){ console.error('ex29', e); } return r; };

function ex29Oeffnen(){
  const liste = ex29Liste();
  if(!liste.length){ akqToast('Keine neuen Leads mit Exposé-Link'); return; }
  EX29.rest = liste.map(o => o.id); EX29.gesamt = liste.length; EX29.offen = 0;
  if(ex29Handy()){ EX29.portion = 1; return ex29Weiter(); }
  if(liste.length <= 15){ EX29.portion = liste.length; return ex29Weiter(); }
  mc24Modal(`<h3>🔗 ${liste.length} Exposés öffnen</h3>
    <p>Jedes Exposé öffnet sich als eigener Tab in deinem Browser.</p>
    <p class="mc24-muted">Bei sehr vielen Seiten auf einmal fragt Kleinanzeigen manchmal nach einer Bestätigung („kein Roboter“). In Portionen geht es ruhiger.</p>
    <div class="modal-actions"><button class="secondary" onclick="schliesseModal()">Abbrechen</button><div class="right">
      <button class="secondary" onclick="schliesseModal();EX29.portion=10;ex29Weiter()">In 10er-Portionen</button>
      <button onclick="schliesseModal();EX29.portion=${liste.length};ex29Weiter()">Alle ${liste.length} öffnen</button></div></div>`, 480);
}
function ex29Weiter(){
  const ids = EX29.rest.splice(0, EX29.portion);
  const objekte = ids.map(id => findObjekt(id)).filter(o => o && ex29Url(o));
  if(!objekte.length){ ex29Fertig(); return; }
  EX29.aktuell = objekte[objekte.length - 1].id;
  if(ex29Handy() || objekte.length === 1){
    objekte.forEach(o => window.open(ex29Url(o), '_blank'));
  } else {
    // am PC kurz nacheinander, damit der Browser keine Seite verschluckt
    objekte.forEach((o, i) => setTimeout(() => window.open(ex29Url(o), '_blank'), i * 350));
  }
  EX29.offen += objekte.length;
  if(EX29.rest.length) ex29LeisteZeigen(objekte[objekte.length - 1]);
  else { ex29LeisteWeg(); akqToast(EX29.gesamt === 1 ? 'Exposé geöffnet' : `${EX29.gesamt} Exposés werden im Browser geöffnet`, 3500); }
}
function ex29LeisteZeigen(o){
  let l = document.getElementById('ex29Leiste');
  if(!l){ l = document.createElement('div'); l.id = 'ex29Leiste'; l.className = 'ex29-leiste'; document.body.appendChild(l); }
  const handy = ex29Handy();
  const weiter = handy ? 'Nächstes ▶' : `Nächste ${Math.min(EX29.portion, EX29.rest.length)} öffnen`;
  l.innerHTML = `<div class="ex29-text">${handy ? `<span>Exposé <b>${EX29.offen}</b> von ${EX29.gesamt}</span><span class="ex29-titel">${mc24E(aqTitel(o) || o.adresse || '')}</span>` : `<span><b>${EX29.offen}</b> von ${EX29.gesamt} Exposés geöffnet</span>`}</div>
    <div class="ex29-knoepfe">${handy ? `<button class="secondary" onclick="ex29Zeigen()" title="Diesen Lead im Cockpit anzeigen">Lead</button>` : ''}<button onclick="ex29Weiter()">${weiter}</button><button class="secondary" onclick="ex29Fertig()" title="Beenden">✕</button></div>`;
}
function ex29Zeigen(){
  const id = EX29.aktuell; if(!id) return;
  if(aktuelleAnsicht !== 'akquise') wechsleAnsicht('akquise');
  if(document.getElementById('lc-' + id)) aq2Waehlen(id); else { AQ2.status = 'alle'; AQ2.sel = id; renderMain(); }
}
function ex29LeisteWeg(){ const l = document.getElementById('ex29Leiste'); if(l) l.remove(); }
function ex29Fertig(){ EX29.rest = []; ex29LeisteWeg(); }
