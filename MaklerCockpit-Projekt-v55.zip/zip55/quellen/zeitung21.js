/* MaklerCockpit v21 – Zeitung lesen
   PDF (mit Text oder eingescannt) bzw. Foto rein → Spalten und Anzeigen erkennen → Angebote werden Leads, Gesuche werden Suchkunden.
   Alles läuft auf dem PC (pdf.js + Texterkennung), ohne Internet und ohne Kosten. */

// ═════════ 1) Erkennen: was ist eine Immobilienanzeige, was ein Gesuch? ═════════
const ZL_IMMO = /(einfamilienh|zweifamilienh|mehrfamilienh|doppelhaus|reihen\w*haus|\bhaus\b|h[aä]uschen|h[äa]user\b|\befh\b|\bzfh\b|\bmfh\b|\bdhh\b|\brh\b|\breh\b|\brmh\b|bungalow|\bvilla\b|landhaus|resthof|bauernhaus|siedlungshaus|stadthaus|eigenheim|wohnung|\bwhg\b|\betw\b|apartment|appartement|penthouse|maisonette|grundst|baugrund|bauland|bauplatz|bauerwartungsland|\bgrst\b|\bgrdst\b|gewerbefl|ladenlokal|b[uü]ror[aä]ume|praxisr[aä]ume|lagerhalle|gewerbeeinheit|zinshaus|renditeobjekt|anlageobjekt|immobilie)/i;
const ZL_FREMD = /(ferienwohnung|ferienhaus|\bfewo\b|urlaub|[uü]bernachtung|\/nacht|pro nacht|stellenangebot|\(m\/w\/d\)|\(w\/m\/d\)|minijob|aushilfe|reinigungskraft|\bkm\b.*t[uü]v|t[uü]v neu|wohnwagen|wohnmobil|garage zu vermieten|stellplatz)/i;
const ZL_MAKLER = /(makler|immobilien\s*(gmbh|ag|kg|ug|gbr|service|b[uü]ro|kontor|partner|management|gruppe|team)|immobilienb[uü]ro|vorgemerkte\s*kunden|f[uü]r\s*(unsere|vorgemerkte|solvente)\s*(kunden|k[aä]ufer)|im\s*kundenauftrag|provision|courtage|\bivd\b|\brdm\b|\bvdm\b|bautr[aä]ger|projektentwickl|sofortige\s*bewertung|kostenlose\s*(wert)?(ermittlung|bewertung|einsch[aä]tzung))/i;
const ZL_PRIVAT_TXT = /(von\s*privat|\bprivat\b|privatverkauf|privatanbieter|ohne\s*makler|keine\s*makler|bitte\s*keine\s*makler|makleranfragen\s*(zwecklos|unerw[uü]nscht)|provisionsfrei|keine\s*provision|kein\s*makler)/i;
const ZL_GESUCH = /\b(such(e|en|t)|gesucht|kaufgesuch|mietgesuch|zu\s*kaufen\s*gesucht|kaufe|kaufen\s*gerne|m[oö]chten\s*kaufen|erwerben)\b/i;
const ZL_ANGEBOT = /\b(verkaufe|verkaufen|zu\s*verkaufen|verkauf\b|biete|abzugeben|\bvb\b|vhb|kaufpreis|\bkp\b|festpreis|\bfp\b|zu\s*vermieten|vermiete|frei\s*ab|ab\s*sofort\s*frei|bezugsfrei)\b/i;
const ZL_MONATE = { januar:1, jan:1, februar:2, feb:2, 'märz':3, maerz:3, 'mär':3, april:4, apr:4, mai:5, juni:6, jun:6, juli:7, jul:7, august:8, aug:8, september:9, sep:9, sept:9, oktober:10, okt:10, november:11, nov:11, dezember:12, dez:12 };

function zlNorm(s){ return String(s || '').replace(/­/g, '').replace(/[ \t ]+/g, ' ').replace(/\s*\n\s*/g, ' ').trim(); }
// OCR-Eigenheiten glätten: m? / m 2 → m², „O“ in Telefonnummern bleibt (zu riskant)
function zlOcrGlatt(s){ return String(s || '').replace(/\bm\s?(?:\?2?|²|2)(?=[\s.,;)]|$)/g, 'm²').replace(/\bqm\b/gi, 'm²').replace(/€\s*,-/g, '€').replace(/\s+([.,;:])/g, '$1').replace(/[|]/g, 'I'); }
// v22: „Makler okay“, „gerne auch über Makler“, „Provision wird gezahlt“ → ausdrücklich makleroffen (kein Makler-Inserat, nicht aussortieren)
const ZL_MAKLER_OK = /(makler\w*\s*(sind\s+|ist\s+|auch\s+|gerne\s+)?(ok(ay)?\b|willkommen|erw[üu]nscht|gerne?\s+gesehen|kein\s+problem|m[öo]glich|erlaubt|angenehm)|(gerne|gern|auch)\s+(auch\s+|gern\s+|gerne\s+)?(von|[üu]ber|durch|mit)\s+(einem\s+|einer\s+|dem\s+)?makler(n|in)?\b|makler\w*\s+d[üu]rfen|(k[äa]ufer)?provision\s*(wird\s+|w[üu]rde\s+)?(auch\s+)?(bezahlt|gezahlt|[üu]bernommen|ok(ay)?\b|kein\s+problem)|zahle[n]?\s+(auch\s+|gerne\s+)?(die\s+)?(k[äa]ufer)?provision|provision\s+zahle[n]?\s+(ich|wir))/i;
function zlMaklerOk(t){ return ZL_MAKLER_OK.test(String(t || '')); }
function zlOhneMaklerVerneinung(t){ return String(t || '').replace(new RegExp(ZL_MAKLER_OK.source, 'gi'), ' OFFENHINWEIS ').replace(/(bitte\s*)?(keine|ohne|kein)\s*makler(anfragen)?|makleranfragen\s*(zwecklos|unerw[uü]nscht)|provisionsfrei|keine\s*provision/gi, ' PRIVATHINWEIS '); }
// v22: Suchende, die keinen Makler wollen („keine Makler“, „von privat“, „provisionsfrei“ …), werden gar nicht erst übernommen
const ZL_KEIN_MAKLER = /((bitte\s+)?(keine?n?|ohne|kein)\s+(makler|immobilienmakler|vermittler)|nicht\s+(an|über|ueber)\s+makler|makler(anfragen|angebote|anrufe)?\s*(zwecklos|unerw[üu]nscht|nicht\s+erw[üu]nscht|bitte\s+nicht|ausgeschlossen|verboten|sinnlos)|von\s+privat|nur\s+(von\s+)?privat|privat\s+an\s+privat|provisionsfrei|ohne\s+(k[äa]ufer)?provision|keine\s+(k[äa]ufer)?provision|ohne\s+courtage|keine\s+courtage|maklerfrei)/i;
function zlKeinMakler(t){ t = String(t || ''); return !zlMaklerOk(t) && ZL_KEIN_MAKLER.test(t); }
function zlIstMakler(t){ return ZL_MAKLER.test(zlOhneMaklerVerneinung(t)); }

function zlRubrik(text){
  const t = String(text || '').toLowerCase().replace(/[^a-zäöüß&\s\-–\/]/g, ' ').replace(/\s+/g, ' ').trim();
  if(!t || t.length > 48 || /\d/.test(text)) return null;
  if(/gesuch|\bsuch(e|en)\b|wohnungssuch|kaufgesuch|mietgesuch/.test(t)) return 'gesuch';
  if(/ferien|urlaub|reise/.test(t)) return 'fremd';
  if(/vermiet|mietangebot|mietwohnung|zu vermieten|\bmieten\b|\bmiete\b/.test(t)) return 'miete';
  if(/immobil|h[äa]user|\bhaus\b|wohnung|eigentum|grundst|verkauf|gewerbe|bauland|anlage|zinsh/.test(t)) return 'verkauf';
  if(/kfz|auto|motor|fahrzeug|stellen|job|bekanntsch|partner|tier|veranstalt|unterricht|dienstleist|verschied|flohmarkt|m[öo]bel|haushalt|leser|trauer|gl[üu]ckw|kontakte|computer|elektro|sammler|verschenk|camping|wohnwagen|boot|sport|garten\s*&|amtlich|bekanntmach/.test(t)) return 'fremd';
  return null;
}

// ═════════ 2) Zeilen → Spalten → Blöcke ═════════
// Zeile: { x0, x1, y (oben), h, text, fett, gross }
function zlMedian(a){ if(!a.length) return 0; const s = a.slice().sort((x, y) => x - y); return s[Math.floor(s.length / 2)]; }
function zlSegmente(st){
  // Stücke (Wörter / Textschnipsel) zu Zeilenstücken verbinden – große waagerechte Lücke = neue Spalte
  st = st.slice().sort((a, b) => (a.yb - b.yb) || (a.x0 - b.x0));
  const zeilen = [];
  for(const s of st){
    let z = null;
    for(let i = zeilen.length - 1; i >= 0 && i >= zeilen.length - 60; i--){
      const k = zeilen[i], tol = 0.5 * Math.min(k.hb, s.h);
      if(Math.abs(k.yb - s.yb) < tol && s.x0 - k.x1 < s.luecke && s.x0 - k.x1 > -0.6 * s.h){ z = k; break; }
    }
    if(z){
      const l = s.x0 - z.x1;
      z.text += (l > 0.15 * s.h && !/\s$/.test(z.text) && !/^\s/.test(s.text) ? ' ' : '') + s.text;
      z.x1 = Math.max(z.x1, s.x1); z.y = Math.min(z.y, s.y); z.hs.push(s.h); z.ybs.push(s.yb); z.fettZ += s.fett ? s.text.length : 0; z.alle += s.text.length;
    } else zeilen.push({ x0:s.x0, x1:s.x1, y:s.y, yb:s.yb, ybs:[s.yb], h:s.h, hb:s.h, hs:[s.h], text:s.text, fett:s.fett, fettAnfang:s.fett, fettZ:s.fett ? s.text.length : 0, alle:s.text.length, ocr:!!s.ocr });
  }
  zeilen.forEach(z => { z.text = z.text.replace(/\s+/g, ' ').trim(); z.fett = z.fettZ > z.alle * 0.6; z.h = zlMedian(z.hs); z.yb = zlMedian(z.ybs); delete z.hs; delete z.ybs; });
  return zeilen.filter(z => z.text);
}
function zlZeilenAusPdf(items, vt, fonts){
  // items: pdf.js-Textstücke; vt: viewport.transform; fonts: { fontName: echter Name }
  const st = items.filter(it => it.str && it.str.trim()).map(it => {
    const m = [vt[0] * it.transform[0] + vt[2] * it.transform[1], vt[1] * it.transform[0] + vt[3] * it.transform[1], vt[0] * it.transform[2] + vt[2] * it.transform[3], vt[1] * it.transform[2] + vt[3] * it.transform[3], vt[0] * it.transform[4] + vt[2] * it.transform[5] + vt[4], vt[1] * it.transform[4] + vt[3] * it.transform[5] + vt[5]];
    const size = Math.hypot(m[2], m[3]) || Math.abs(it.height) || 8, sx = Math.hypot(m[0], m[1]) / (Math.hypot(it.transform[0], it.transform[1]) || 1);
    const name = (fonts && fonts[it.fontName]) || it.fontName || '';
    return { x0:m[4], x1:m[4] + (it.width || 0) * sx, y:m[5] - size, yb:m[5], h:size, luecke:1.1 * size, text:it.str, fett:/bold|black|heavy|semibold|demi|-bd\b|fett/i.test(name) };
  });
  return zlSegmente(st);
}
function zlZeilenAusOcr(daten, faktor){
  // Zeilen der Texterkennung an großen Lücken in Spalten-Stücke teilen (Tesseract verbindet enge Spalten gern zu einer Zeile)
  const f = faktor || 1;
  const woerter = (daten.words || []).filter(x => x && x.text && x.text.trim() && x.bbox);
  const hMed = zlMedian(woerter.filter(x => /[A-Za-zÄÖÜäöüß0-9]{3,}/.test(x.text)).map(x => (x.bbox.y1 - x.bbox.y0) / f)) || 10;
  const gut = x => {
    const t = x.text.trim(), h = (x.bbox.y1 - x.bbox.y0) / f, b = (x.bbox.x1 - x.bbox.x0) / f;
    if(x.confidence < 30) return false;                                   // Störzeichen
    if(h < 0.35 * hMed && b > 1.5 * hMed) return false;                  // Trennlinien
    if(/^[—\-–_=~.,·:;!|'"‚‘’`´^°*]+$/.test(t) && (x.confidence < 60 || b > 1.5 * hMed)) return false;
    return true;
  };
  const yb = x => { const h = (x.bbox.y1 - x.bbox.y0) / f; if(h > 1.6 * hMed) return x.bbox.y0 / f + hMed; return x.bbox.y1 / f - (/[gjpqyµ,;()\[\]@]/.test(x.text) ? 0.22 * h : 0); };
  const lines = daten.lines || [];
  // Falls die Zeilen ihre Wörter nicht mitliefern: jedes Wort genau einer Zeile zuordnen (nächste Zeilenmitte)
  let zuordnung = null;
  if(lines.length && !lines.some(l => Array.isArray(l.words) && l.words.length)){
    zuordnung = lines.map(() => []);
    woerter.forEach(w => {
      const cx = (w.bbox.x0 + w.bbox.x1) / 2, cy = (w.bbox.y0 + w.bbox.y1) / 2;
      let best = -1, bd = Infinity;
      lines.forEach((l, i) => { if(cx < l.bbox.x0 - 2 || cx > l.bbox.x1 + 2 || cy < l.bbox.y0 - 4 || cy > l.bbox.y1 + 4) return; const d = Math.abs(cy - (l.bbox.y0 + l.bbox.y1) / 2); if(d < bd){ bd = d; best = i; } });
      if(best >= 0) zuordnung[best].push(w);
    });
  }
  const out = [];
  lines.forEach((l, li) => {
    const ws = (zuordnung ? zuordnung[li] : (l.words || [])).filter(gut).slice().sort((a, b) => a.bbox.x0 - b.bbox.x0);
    let seg = null;
    const zu = () => { if(seg && seg.ws.length){ const w = seg.ws; out.push({ x0:w[0].bbox.x0 / f, x1:Math.max(...w.map(x => x.bbox.x1)) / f, y:Math.min(...w.map(x => x.bbox.y0)) / f, yb:zlMedian(w.map(yb)), h:zlMedian(w.map(x => (x.bbox.y1 - x.bbox.y0) / f)), text:zlOcrGlatt(w.map(x => x.text.trim()).join(' ')), fett:false, fettAnfang:false, fettZ:0, alle:1, ocr:true }); } seg = null; };
    ws.forEach(w => {
      const h = (w.bbox.y1 - w.bbox.y0) / f;
      if(seg && (w.bbox.x0 / f - seg.x1) > 1.05 * Math.max(hMed, Math.min(h, hMed * 1.6))) zu();
      if(!seg) seg = { ws:[], x1:0 };
      seg.ws.push(w); seg.x1 = Math.max(seg.x1, w.bbox.x1 / f);
    });
    zu();
  });
  if(!out.length) return woerter.filter(gut).map(x => ({ x0:x.bbox.x0 / f, x1:x.bbox.x1 / f, y:x.bbox.y0 / f, yb:yb(x), h:(x.bbox.y1 - x.bbox.y0) / f, text:x.text, fett:false, ocr:true }));
  return out.filter(z => z.text.length > 1);
}
function zlSpalten(zeilen){
  const breiten = zeilen.filter(z => z.text.length > 18).map(z => z.x1 - z.x0);
  const W = zlMedian(breiten) || 150, H = zlMedian(zeilen.map(z => z.h)) || 8;
  const kopf = [], spalten = [];
  const oben = Math.min(...zeilen.map(z => z.y));
  zeilen.slice().sort((a, b) => (a.x1 - a.x0) - (b.x1 - b.x0)).forEach(z => {
    const w = z.x1 - z.x0;
    if(w > W * 1.7 || (z.h > H * 1.6 && !zlRubrik(z.text) && (!z.ocr || z.y < oben + 4 * H))){ kopf.push(z); return; }
    let best = null, bestOv = 0;
    for(const c of spalten){ const ov = Math.min(c.x1, z.x1) - Math.max(c.x0, z.x0); if(ov > bestOv){ bestOv = ov; best = c; } }
    if(best && bestOv >= Math.min(w, best.x1 - best.x0) * 0.45){ best.z.push(z); if(w <= W * 1.25){ best.x0 = Math.min(best.x0, z.x0); best.x1 = Math.max(best.x1, z.x1); } }
    else spalten.push({ x0:z.x0, x1:z.x1, z:[z] });
  });
  // überlappende Spalten zusammenführen
  spalten.sort((a, b) => a.x0 - b.x0);
  const fertig = [];
  for(const c of spalten){
    const v = fertig[fertig.length - 1];
    if(v && Math.min(v.x1, c.x1) - Math.max(v.x0, c.x0) > 0.35 * Math.min(v.x1 - v.x0, c.x1 - c.x0)){ v.z.push(...c.z); v.x1 = Math.max(v.x1, c.x1); }
    else fertig.push(c);
  }
  fertig.forEach(c => c.z.sort((a, b) => a.y - b.y));
  return { spalten: fertig, kopf: kopf.sort((a, b) => a.y - b.y) };
}
function zlBloecke(spalte, info){
  const z = spalte.z; if(!z.length) return [];
  const hMed = zlMedian(z.map(x => x.h)) || 8;
  const yb = x => (x.yb !== undefined ? x.yb : x.y + x.h);
  const schritte = []; for(let i = 1; i < z.length; i++){ const d = yb(z[i]) - yb(z[i - 1]); if(d > 0.6 * hMed && d < 2.6 * hMed) schritte.push(d); }
  const dMed = zlMedian(schritte) || hMed * 1.2;
  const out = []; let akt = null;
  const neu = () => { if(akt && akt.z.length) out.push(akt); akt = { z:[] }; };
  neu();
  z.forEach((l, i) => {
    const gross = l.h > hMed * 1.18;
    const offen = /[,;:]|\b(in|im|an|am|der|die|das|den|mit|und|oder|zu|zur|f[uü]r|bei|von|sucht|suche|suchen|biete|verkaufe|kaufe)$/i.test(l.text.trim());
    const nurText = l.ocr && l.text.split(/\s+/).length <= 4 && !/[,.;:\d€]/.test(l.text) && /^[A-ZÄÖÜ]/.test(l.text);
    const istRubrik = (gross || (l.fett && l.fettZ >= l.alle) || nurText) && !offen && !/[@.,;:\d€]/.test(l.text) && l.text.length <= 48 && !!zlRubrik(l.text);
    if(istRubrik){ neu(); out.push({ z:[l], rubrik:zlRubrik(l.text) }); return; }
    if(i > 0 && akt.z.length){
      const v = z[i - 1], d = yb(l) - yb(v);
      if(d > dMed * 1.3 + 0.5 || (l.fettAnfang && !v.fettAnfang && akt.z.length >= 2 && d > dMed * 1.12) || (gross !== (v.h > hMed * 1.18) && !l.ocr)) neu();
    }
    akt.z.push(l);
  });
  neu();
  return out.map(b => { b.text = zlZusammen(b.z.map(l => l.text)); b.fett = b.z[0].fett || b.z[0].fettAnfang; return b; });
}
function zlZusammen(zeilen){
  let t = '';
  zeilen.forEach(s => {
    if(!t){ t = s; return; }
    if(/[a-zäöüß]-$/.test(t) && /^[a-zäöüß]/.test(s)) t = t.slice(0, -1) + s;        // Silbentrennung
    else if(/-$/.test(t)) t += s;                                                   // Bindestrich-Wort (Dallgow-\nDöberitz)
    else if(/[@.]$/.test(t) && /^[a-z0-9]/i.test(s) && /@/.test(t + s) && !/\s/.test(s.split(/[\s,;]/)[0].slice(0, 1))) t += (/\.$/.test(t) && /^(de|com|net|org)\b/i.test(s) ? '' : (/@$/.test(t) ? '' : ' ')) + s;
    else t += ' ' + s;
  });
  return zlNorm(t);
}

// ═════════ 3) Felder aus dem Anzeigentext ═════════
function zlTel(t){
  t = String(t || '');
  let m = /(?:tel(?:efon)?\.?|☎|📞|handy|mobil|fon|ruf(?:nummer)?)\s*[:.]?\s*((?:\+49|0049|\(?0)[\d\s\/\-–()]{5,24}\d)/i.exec(t);
  if(!m) m = /(?:^|[\s,;:(])((?:\+49|0049|0)\d{2,5}(?:[\s\/\-–]{0,3}\d){4,12})(?![\d]*\s*(?:€|euro|m²|qm|km|t€|%))/i.exec(t);
  if(!m) return '';
  const n = m[1].replace(/–/g, '-').replace(/\s{2,}/g, ' ').replace(/[\s\/\-]+$/, '').trim(), d = n.replace(/\D/g, '');
  return d.length >= 7 && d.length <= 15 ? n : '';
}
function zlMail(t){ const m = /[\w.+-]+@[\w-]+(?:\.[\w-]+)*\.[a-z]{2,}/i.exec(String(t || '')); return m ? m[0].replace(/[.,;]+$/, '').toLowerCase() : ''; }
function zlChiffre(t){ const m = /chiffre\s*(?:nr\.?|nummer)?\s*[:.\-]?\s*([A-ZÄÖÜ]{0,4}\s?\d[\w\-\/]{0,10})/i.exec(String(t || '')); return m ? m[1].trim() : ''; }
function zlBetraege(t){
  const l = []; t = String(t || '');
  const re = /(\d{1,3}(?:[.\s]\d{3})+|\d{3,7})(?:,(?:\d{2}|-{1,2}))?\s*(?:€|euro\b|eur\b)|(?:€|eur\b)\s*(\d{1,3}(?:[.\s]\d{3})+|\d{3,7})|(\d+(?:[.,]\d+)?)\s*(t€|teur\b|tsd\.?\s*(?:€|euro)?|mio\.?\s*(?:€|euro)?|millionen)/gi;
  let m;
  while((m = re.exec(t))){
    let w;
    if(m[4]){ const z = parseFloat(m[3].replace(/\./g, '').replace(',', '.')); w = /mio|million/i.test(m[4]) ? z * 1e6 : z * 1000; }
    else w = Number(String(m[1] || m[2]).replace(/[.\s]/g, ''));
    if(w > 0) l.push({ w:Math.round(w), i:m.index, s:m[0], vor:t.slice(Math.max(0, m.index - 14), m.index).toLowerCase(), nach:t.slice(m.index + m[0].length, m.index + m[0].length + 14).toLowerCase() });
  }
  return l;
}
function zlPreisAngebot(t, miete){
  const b = zlBetraege(t).filter(x => !/(provision|courtage|kaution|hausgeld|nebenkosten|\bnk)\s*:?\s*(ca\.?\s*)?$/.test(x.vor) && !/^\s*(%|\/\s*std|pro\s*std|\/\s*nacht|provision)/.test(x.nach));
  if(!b.length) return { w:0, s:'' };
  let p;
  if(miete) p = b.find(x => /kalt|warm|miete|mtl|monat|\+\s*nk/.test(x.nach + x.vor)) || b.find(x => x.w < 20000) || b[0];
  else p = b.filter(x => x.w >= 10000).sort((x, y) => y.w - x.w)[0] || b[0];
  const vb = /\bvb\b|vhb|verhandlungsbasis/i.test(p.vor + p.nach) ? ' VB' : '';
  const ks = miete ? (/warm/.test(p.nach) ? ' warm' : ' kalt') : '';
  return { w:p.w, s:p.w.toLocaleString('de-DE') + ' €' + vb + ks };
}
function zlDatumAus(t){
  t = String(t || '');
  let m = /(\d{1,2})\.\s*(januar|februar|m[äa]rz|april|mai|juni|juli|august|september|oktober|november|dezember)\s*(\d{4})/i.exec(t);
  if(m){ const mo = ZL_MONATE[m[2].toLowerCase().replace('ä', 'ä')] || ZL_MONATE[m[2].toLowerCase().replace('ae', 'ä')] || ZL_MONATE[m[2].toLowerCase()]; if(mo) return `${m[3]}-${String(mo).padStart(2, '0')}-${String(m[1]).padStart(2, '0')}`; }
  m = /\b(\d{1,2})\.(\d{1,2})\.(20\d{2})\b/.exec(t);
  if(m) return `${m[3]}-${String(m[2]).padStart(2, '0')}-${String(m[1]).padStart(2, '0')}`;
  return '';
}
const ZL_ORTE_EXTRA = ['Brieselang', 'Schönwalde-Glien', 'Elstal', 'Ketzin', 'Paaren', 'Groß Glienicke', 'Kremmen', 'Leegebruch', 'Oberkrämer', 'Bötzow', 'Marwitz', 'Fahrland', 'Marquardt', 'Bergfelde', 'Borgsdorf', 'Hohen Neuendorf', 'Hennigsdorf', 'Velten', 'Nauen', 'Wustermark', 'Ludwigsfelde', 'Erkner', 'Strausberg', 'Eberswalde', 'Luckenwalde', 'Birkenwerder', 'Michendorf', 'Beelitz', 'Großbeeren', 'Rangsdorf', 'Zossen', 'Wildau', 'Eichwalde', 'Schulzendorf', 'Woltersdorf', 'Ahrensfelde', 'Werneuchen', 'Biesenthal', 'Mittenwalde', 'Trebbin', 'Seeburg', 'Priort', 'Rathenow', 'Premnitz', 'Friesack', 'Rhinow', 'Dyrotz', 'Wansdorf', 'Pausin', 'Perwenitz', 'Zeestow', 'Wernitz', 'Buchow-Karpzow', 'Etzin', 'Falkenrehde', 'Töplitz', 'Glindow', 'Petzow', 'Kloster Lehnin', 'Groß Kreutz', 'Teltow', 'Stahnsdorf'];
let ZL_ORTSLISTE = null;
function zlOrtsliste(){
  if(ZL_ORTSLISTE) return ZL_ORTSLISTE;
  const l = [];
  if(typeof MC_MARKT !== 'undefined') for(const [gid, g] of Object.entries(MC_MARKT.gebiete)) for(const w of (g.begriffe || []).concat([g.name])) l.push({ w, gid, n:x20Norm(w) });
  ZL_ORTE_EXTRA.forEach(w => { if(!l.some(x => x.n === x20Norm(w))) l.push({ w, gid:null, n:x20Norm(w) }); });
  l.sort((a, b) => b.n.length - a.n.length);
  return ZL_ORTSLISTE = l;
}
function zlOrteIn(text){
  const t = x20Norm(text), out = [];
  let rest = t;
  for(const o of zlOrtsliste()){
    if(o.n.trim().length < 4) continue;
    if(rest.includes(o.n)){ out.push(o.w); rest = rest.split(o.n).join(' # '); }
  }
  return out;
}
const ZL_KEIN_ORT = /^(suche|suchen|junge|familie|biete|verkaufe|verkauf|wir|ich|f[uü]r|kaufe|paar|rentner|privat|sch[oö]n|gro[sß]|helle?s?|gepfl|freist|neu|top|achtung|exklusiv|traum|ruhig|modern|saniert|zentral|tausche|immobilie|haus|wohnung|grundst|eigentum|efh|etw|dhh|reihen|bungalow|villa|baugrund|bauland|apartment|zimmer|\d)/i;
function zlOrtAngebot(t){
  const m = /^\s*([A-ZÄÖÜ][\wäöüß.\-\/]*(?:\s+(?:OT|b\.|bei|an\s+der|a\.\s*d\.|\/)?\s*[A-ZÄÖÜ][\wäöüß.\-\/]*){0,3})\s*(?::|,|–|—| - )/.exec(t);
  if(m && !ZL_KEIN_ORT.test(m[1]) && !ZL_IMMO.test(m[1]) && m[1].length <= 40) return m[1].replace(/[.,]+$/, '').trim();
  const p = /\b(?:in|im|nahe|bei|OT)\s+((?:Berlin-)?[A-ZÄÖÜ][\wäöüß\-]+(?:\s+(?:OT\s+)?[A-ZÄÖÜ][\wäöüß\-]+)?)/.exec(t);
  if(p && !ZL_KEIN_ORT.test(p[1])) return p[1];
  const o = zlOrteIn(t); if(o.length) return o[0];
  const plz = /\b(1[0-9]\d{3})\s+([A-ZÄÖÜ][\wäöüß\-]+)/.exec(t); if(plz) return plz[1] + ' ' + plz[2];
  return '';
}
function zlTitel(art, fl, t){
  const lc = t.toLowerCase();
  let l = { EFH: /zweifamilien|\bzfh\b/.test(lc) ? 'Zweifamilienhaus' : /bungalow/.test(lc) ? 'Bungalow' : /villa/.test(lc) ? 'Villa' : /resthof|bauernhaus/.test(lc) ? 'Resthof' : 'Einfamilienhaus',
    DHH:'Doppelhaushälfte', Reihenhaus: /reihenend|\breh\b/.test(lc) ? 'Reihenendhaus' : /reihenmittel|\brmh\b/.test(lc) ? 'Reihenmittelhaus' : 'Reihenhaus',
    Wohnung: /apartment|appartement/.test(lc) ? 'Apartment' : fl.zimmer ? fl.zimmer + '-Zimmer-Wohnung' : 'Eigentumswohnung', Grundstück: /baugrund|bauland|bauplatz/.test(lc) ? 'Baugrundstück' : 'Grundstück',
    MFH:'Mehrfamilienhaus', Gewerbe:'Gewerbeobjekt' }[art] || 'Immobilie';
  if(['EFH', 'DHH', 'Reihenhaus', 'MFH'].includes(art)){ if(fl.zimmer) l += ', ' + fl.zimmer + ' Zi.'; if(fl.wohnflaeche) l += ', ' + fl.wohnflaeche + ' m²'; }
  else if(art === 'Wohnung'){ if(fl.wohnflaeche) l += ', ' + fl.wohnflaeche + ' m²'; }
  else if(art === 'Grundstück'){ if(fl.grundstueck) l += ', ' + fl.grundstueck.toLocaleString('de-DE') + ' m²'; }
  return l;
}
// ── Gesuch: Wunschkriterien ──
function zlGesuchKriterien(text){
  const t = String(text || ''), lc0 = t.toLowerCase(), A = new Set();
  // „Grundstück für ein Einfamilienhaus“ / „zum Bau eines EFH“ → gesucht wird das Grundstück, nicht das Haus
  const lc = /grundst|bauland|baugrund|bauplatz|parzelle/.test(lc0) ? lc0.replace(/(f[üu]r|zum\s+bau\s+(?:eines|einer|von)|zur\s+bebauung\s+mit|bebaubar\s+mit|geeignet\s+f[üu]r)\s+(?:ein(?:en|em|e)?\s+|unser(?:en|em|e)?\s+)?(?:eigenes?\s+|kleines?\s+)?(efh|einfamilienh\w*|dhh|doppelh\w*|zweifamilienh\w*|mfh|mehrfamilienh\w*|haus|h[äa]uschen|bungalow|eigenheim|tiny\s*house)/g, ' ') : lc0;
  if(/\befh\b|einfamilienh|bungalow|\bvilla\b|landhaus|freistehend/.test(lc)) A.add('EFH');
  if(/\bdhh\b|doppelhaus/.test(lc)) A.add('DHH');
  if(/\brh\b|\breh\b|reihen\w*haus/.test(lc)) A.add('Reihenhaus');
  if(/zweifamilienh|\bzfh\b/.test(lc)) A.add('EFH');
  if(!A.size && /\bhaus\b|h[äa]user\b|h[äa]uschen|eigenheim/.test(lc)) ['EFH', 'DHH', 'Reihenhaus'].forEach(a => A.add(a));
  if(/wohnung|\betw\b|\bwhg\b|apartment|appartement|penthouse|maisonette/.test(lc)) A.add('Wohnung');
  else if(!A.size && /\d\s*-?\s*zi(\.|\b|mmer)/.test(lc)) A.add('Wohnung');
  const hausOderWhg = A.size > 0;
  if(/bauland|baugrund|bauplatz|bauerwartungsland|parzelle|wochenendgrundst|erholungsgrundst/.test(lc) || (/grundst/.test(lc) && (!hausOderWhg || /(haus|wohnung|efh|dhh)\s*(\/|oder|bzw\.?|und)\s*(bau)?grundst|grundst\w*\s*(\/|oder|bzw\.?)\s*(haus|efh)/.test(lc)))) A.add('Grundstück');
  if(/mehrfamilienh|\bmfh\b|zinshaus|renditeobjekt|anlageobjekt/.test(lc)) A.add('MFH');
  if(/gewerbe|ladenlokal|b[uü]ror[aä]ume|halle\b/.test(lc)) A.add('Gewerbe');
  const miete = /zur\s*miete|\bmieten\b|\bmiete\b|warm\b|kalt\b|mietwohnung|nachmieter/.test(lc) && !/\bkauf\b|zu\s*kaufen|erwerb/.test(lc);
  // Budget
  let preisMax = 0;
  const bm = /(?:bis(?:\s*zu)?|max(?:imal)?\.?|h[öo]chstens|budget|preis\s*bis|kp\s*bis|kaufpreis\s*bis|bis\s*ca\.?)\s*(?:ca\.?\s*)?(\d[\d.,\s]*\d|\d)\s*(mio\.?|millionen|t€|teur|tsd\.?|tausend|k€|€|euro|,-)?/i.exec(t);
  if(bm){ const z = Number(bm[1].replace(/[.\s]/g, '').replace(',', '.')), e = (bm[2] || '').toLowerCase(); preisMax = /mio|million/.test(e) ? z * 1e6 : /t€|teur|tsd|tausend|k€/.test(e) ? z * 1000 : (!miete && z < 5000 && !e) ? z * 1000 : z; }
  if(!preisMax){ const b = zlBetraege(t).filter(x => miete ? x.w < 5000 : x.w >= 20000); if(b.length) preisMax = Math.max(...b.map(x => x.w)); }
  // Zimmer, Fläche, Grundstück
  let zimmerMin = 0, m;
  if((m = /(?:ab|mind(?:estens)?\.?|min\.?|nicht\s*unter)\s*(\d+(?:[.,]5)?)\s*-?\s*(?:zi\b|zi\.|zimmer|r[äa]ume)/i.exec(t))) zimmerMin = parseFloat(m[1].replace(',', '.'));
  else if((m = /(\d+(?:[.,]5)?)\s*(?:-|bis|–)\s*\d+(?:[.,]5)?\s*-?\s*(?:zi\b|zi\.|zimmer|r[äa]ume)/i.exec(t))) zimmerMin = parseFloat(m[1].replace(',', '.'));
  else if((m = /(\d+(?:[.,]5)?)\s*-?\s*(?:zi\b|zi\.|zimmer|r[äa]ume)/i.exec(t))) zimmerMin = parseFloat(m[1].replace(',', '.'));
  let flaecheMin = 0, grundstueckMin = 0;
  if((m = /(?:grundst\w*|grdst\.?|grst\.?)\s*(?:von\s*)?(?:ab|mind(?:estens)?\.?|min\.?)?\s*(?:ca\.?\s*)?(\d[\d.]{2,6})\s*(?:m²|m2|qm)/i.exec(t)) || (m = /(?:ab|mind(?:estens)?\.?|min\.?)\s*(\d[\d.]{2,6})\s*(?:m²|m2|qm)\s*(?:gro(?:ß|ss)es\s*)?(?:grundst|grdst|grst|garten)/i.exec(t))) grundstueckMin = Number(m[1].replace(/\./g, ''));
  if((m = /(?:ab|mind(?:estens)?\.?|min\.?|nicht\s*unter)\s*(\d{2,4})\s*(?:m²|m2|qm)(?!\s*(?:gro(?:ß|ss)es\s*)?(?:grundst|grdst|grst|garten))/i.exec(t))) flaecheMin = Number(m[1]);
  else if((m = /(?:wohnfl\w*|wfl\.?)\s*(?:ab|mind\.?|min\.?)?\s*(?:ca\.?\s*)?(\d{2,4})/i.exec(t))) flaecheMin = Number(m[1]);
  // Orte: Text nach „in / im Raum / Raum / Nähe / Umgebung“ + bekannte Orte
  const orte = [];
  const reIn = /(?:\bin\b|\bim\s+raum\b|\braum\b|\bn[äa]he\b|\bumgebung\b|\bbereich\b|\bumkreis\s+(?:von\s+)?\d*\s*(?:km\s*)?(?:um|von)?\b)\s+(.{3,120})/gi;
  let r;
  while((r = reIn.exec(t))){
    let s = r[1].split(/,\s*(?=[a-zäöü0-9])|\s(?=(?:ab|bis|max|mit|zur|zum|f[uü]r|gern|gerne|auch|tel|ca|von|evtl|bevorzugt|kauf|miete|und\s+umgebung)\b)|[.;!](?=\s|$)|\s+\d/i)[0];
    s.split(/\s*(?:,|\/|\boder\b|\bund\b|\bbzw\.?|\bu\.)\s*/).map(x => x.replace(/[()]/g, '').trim()).filter(x => /^[A-ZÄÖÜ]/.test(x) && x.length >= 3 && !ZL_KEIN_ORT.test(x) && !ZL_IMMO.test(x)).forEach(x => { if(!orte.some(o => x20Norm(o) === x20Norm(x))) orte.push(x); });
  }
  zlOrteIn(t).forEach(w => { if(!orte.some(o => x20Norm(o).includes(x20Norm(w)) || x20Norm(w).includes(x20Norm(o)))) orte.push(w); });
  const berlinAlle = /\bberlin\b(?!\s*-)/i.test(t) && orte.every(o => /^berlin$/i.test(o) || !/berlin/i.test(o)) && orte.some(o => /^berlin$/i.test(o));
  const umland = /umland|speckg[üu]rtel|stadtrand|brandenburg\b|berliner\s+n[äa]he/i.test(lc);
  const wuensche = ['garten', 'balkon', 'terrasse', 'aufzug', 'keller', 'garage', 'stellplatz', 'ebenerdig', 'barrierefrei', 'kamin', 'see', 'wasserlage', 'renovierungsbed', 'sanierungsbed', 'vermietet', 'bezugsfrei', 'neubau', 'altbau'].filter(w => lc.includes(w));
  return { arten:[...A], nutzung: miete ? 'miete' : 'kauf', preisMax:Math.round(preisMax), zimmerMin, flaecheMin, grundstueckMin, orte:orte.filter(o => !/^(berlin|umland)$/i.test(o)), berlinAlle, umland, wuensche };
}
function zlWer(t){ const m = /^\s*(.{3,40}?)\s+(?:sucht|suchen)\b/i.exec(t); return m && !/^(ich|wir)$/i.test(m[1].trim()) ? m[1].trim() : ''; }

// ═════════ 4) Blöcke → Anzeigen ═════════
function zlAnalysieren(seiten, meta){
  meta = meta || {};
  const roh = [];
  let datum = meta.datum || '', rubrik = null;
  seiten.forEach(s => {
    const { spalten, kopf } = zlSpalten(s.zeilen);
    if(!datum) datum = zlDatumAus(kopf.map(k => k.text).join(' ')) || zlDatumAus(s.zeilen.slice(0, 12).map(k => k.text).join(' '));
    spalten.forEach(sp => zlBloecke(sp).forEach(b => {
      if(b.rubrik){ rubrik = b.rubrik; roh.push({ rubrikText:b.text, rubrik }); return; }
      roh.push({ text:b.text, rubrik, seite:s.nr, fett:b.fett });
    }));
  });
  // Bruchstücke zusammenführen (Anzeige über Spaltengrenze oder mit Leerzeile)
  const bl = [], schnipsel = [];
  const ohneKontakt = x => String(x || '').replace(/[\w.+-]+@[\w-]+(?:\.[\w-]+)+/g, ' ').replace(/(?:https?:\/\/|www\.)\S+/gi, ' ');
  roh.forEach(b => {
    if(b.rubrikText){ bl.push(b); return; }
    const v = bl[bl.length - 1];
    // reine Kontakt-Fortsetzung (E-Mail, Telefon, Web) gehört zur Anzeige davor
    const rest = ohneKontakt(b.text).replace(/(?:tel(?:efon)?\.?|e-?mail:?|☎|fon)\s*/gi, ' ').replace(/(?:\+49|0)[\d\s\/\-–()]{5,}\d/g, ' ').replace(/[\s,.;:–-]+/g, '');
    if(v && !v.rubrikText && v.rubrik === b.rubrik && rest.length <= 3 && b.text.length < 80){ v.text = zlZusammen([v.text, b.text]); return; }
    if(b.text.length < 25 && !/\d{3}/.test(b.text)){ schnipsel.push(b); return; }
    const kontakt = x => !!(zlTel(x) || zlMail(x) || zlChiffre(x));
    if(v && !v.rubrikText && v.rubrik === b.rubrik && !kontakt(v.text) && (ZL_IMMO.test(ohneKontakt(v.text)) || ZL_GESUCH.test(v.text)) && !ZL_IMMO.test(ohneKontakt(b.text).slice(0, 40)) && !(b.fett && ZL_IMMO.test(b.text)) && (kontakt(b.text) || zlBetraege(b.text).length) && b.text.length < 160){
      v.text = zlZusammen([v.text, b.text]); v.zusammen = true; return;
    }
    bl.push(Object.assign({}, b));
  });
  const angebote = [], gesuche = [], weg = schnipsel.map(b => ({ text:b.text, grund:'zu kurz' }));
  bl.filter(b => !b.rubrikText).forEach(b => {
    const t = zlOcrGlatt(b.text), lc = t.toLowerCase();
    const kurz = t.length > 90 ? t.slice(0, 87) + '…' : t;
    if(t.length < 25){ weg.push({ text:kurz, grund:'zu kurz' }); return; }
    if(b.rubrik === 'fremd' && !(ZL_IMMO.test(t) && /(verkauf|biete|such|vermiet)/i.test(t))){ weg.push({ text:kurz, grund:'andere Rubrik' }); return; }
    if(ZL_FREMD.test(t)){ weg.push({ text:kurz, grund:'keine Immobilie (Ferienwohnung, Job, Fahrzeug …)' }); return; }
    if(!ZL_IMMO.test(ohneKontakt(t))){ weg.push({ text:kurz, grund:'keine Immobilie' }); return; }
    const tel = zlTel(t), mail = zlMail(t), chiffre = zlChiffre(t);
    const duenn = !tel && !mail && !chiffre && !zlBetraege(t).length;     // Bruchstück (z. B. schlecht gescannt) – zur Prüfung anbieten, nicht vorauswählen
    const makler = zlIstMakler(t), privatHinweis = ZL_PRIVAT_TXT.test(t);
    const gesuchWort = ZL_GESUCH.test(t), angebotWort = ZL_ANGEBOT.test(t);
    const istGesuch = (b.rubrik === 'gesuch' && !/\b(verkaufe|zu\s*verkaufen|biete|abzugeben)\b/i.test(t)) || (gesuchWort && !angebotWort && b.rubrik !== 'verkauf' && b.rubrik !== 'miete') || (gesuchWort && !/\b(verkaufe|zu\s*verkaufen|biete|abzugeben)\b/i.test(t) && /^\s*(?:\S+\s+)?(?:such(?:e|en|t)|kaufe)\b/i.test(t));
    if(istGesuch){
      if(makler){ weg.push({ text:kurz, grund:'Makler-Gesuch (kein echter Käufer)' }); return; }
      if(zlKeinMakler(t)){ weg.push({ text:kurz, grund:'„Keine Makler“ gewünscht – nicht übernommen' }); return; }
      const k = zlGesuchKriterien(t);
      gesuche.push(Object.assign({ text:t, wer:zlWer(t), telefon:tel, email:mail, chiffre, seite:b.seite, datum, quelleText:meta.quelle || '', duenn }, k));
      return;
    }
    const miete = b.rubrik === 'miete' || /zu\s*vermieten|vermiete\b|\bkalt\b|\bwarm\b|\+\s*nk\b|kaution|nachmieter/i.test(t);
    const art = akqObjektart(t);
    const fl = akqFlaechen(t, art);
    const zx = /(\d)\s*[x×]\s*(\d+(?:[.,]5)?)\s*-?\s*(?:zi\b|zi\.|zimmer)/i.exec(t); if(zx) fl.zimmer = String(+zx[1] * parseFloat(zx[2].replace(',', '.'))).replace('.', ',');
    const preis = zlPreisAngebot(t, miete);
    const ort = zlOrtAngebot(t);
    const privat = makler ? '🔴 Nein – Makler/gewerblich' : privatHinweis ? '🟢 Ja – „privat“/„keine Makler“ in der Anzeige' : '🟡 Unklar – kein Hinweis';
    angebote.push({
      f:{ objekt:zlTitel(art, fl, t), lage:ort, preis:preis.s, telefon:tel, email:mail, kontakt:chiffre ? 'Chiffre ' + chiffre : '', details:t, privat, quelle:meta.quelle || 'Zeitung', seite:meta.seitePrefix ? meta.seitePrefix + b.seite : 'S. ' + b.seite, datum:datum ? datum.split('-').reverse().join('.') : '', status:(makler ? 'Makler' : privatHinweis ? 'Privatangebot' : 'Herkunft unklar') + (chiffre ? ' · nur Chiffre' : '') + ' · aus PDF gelesen' },
      titel:'', miete, makler, text:t, duenn
    });
  });
  return { angebote, gesuche, weg, datum, rubriken:bl.filter(b => b.rubrikText).map(b => b.rubrikText) };
}

// ═════════ 5) Dateien lesen: PDF mit Text, eingescannt oder Fotos ═════════
const ZL = { laeuft:false, abbruch:false, ergebnis:null, quelle:'', datum:'', seiten:[], bericht:null, dateien:[] };
function zlPdfBereit(){
  if(!window.pdfjsLib) return false;
  try{ const w = pdfjsLib.GlobalWorkerOptions.workerSrc || ''; if(!w || /^https?:/.test(w)) pdfjsLib.GlobalWorkerOptions.workerSrc = new URL('vendor/pdf.worker.min.js', location.href).href; }catch(e){}
  return true;
}
function zlTessOptionen(){ const basis = new URL('vendor/tess/', location.href).href; return { workerPath:basis + 'worker.min.js', corePath:basis, langPath:basis.replace(/\/$/, ''), workerBlobURL:false, gzip:true, cacheMethod:'none' }; }
let ZL_TESS = null;
async function zlOcrWorker(){
  if(ZL_TESS) return ZL_TESS;
  if(!window.Tesseract) throw new Error('Die Texterkennung ist nicht verfügbar.');
  ZL_TESS = await Tesseract.createWorker('deu', 1, zlTessOptionen());
  return ZL_TESS;
}
async function zlOcrEnde(){ if(ZL_TESS){ const w = ZL_TESS; ZL_TESS = null; try{ await w.terminate(); }catch(e){} } }
async function zlOcrCanvas(canvas){ const w = await zlOcrWorker(); const r = await w.recognize(canvas); return zlZeilenAusOcr(r.data, 1); }
async function zlPdfSeiteRendern(page){
  const vp1 = page.getViewport({ scale:1 });
  const scale = Math.min(300 / 72, 5200 / Math.max(vp1.width, vp1.height));
  const vp = page.getViewport({ scale });
  const c = document.createElement('canvas'); c.width = Math.round(vp.width); c.height = Math.round(vp.height);
  const ctx = c.getContext('2d'); ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, c.width, c.height);
  await page.render({ canvasContext:ctx, viewport:vp }).promise;
  return c;
}
async function zlBildCanvas(file){
  const url = URL.createObjectURL(file);
  try{
    const img = await new Promise((ok, nein) => { const i = new Image(); i.onload = () => ok(i); i.onerror = () => nein(new Error('Bild nicht lesbar')); i.src = url; });
    let f = 1; const lang = Math.max(img.naturalWidth, img.naturalHeight);
    if(lang > 5200) f = 5200 / lang; else if(lang < 2200) f = Math.min(2, 2600 / lang);
    const c = document.createElement('canvas'); c.width = Math.round(img.naturalWidth * f); c.height = Math.round(img.naturalHeight * f);
    const ctx = c.getContext('2d'); ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, c.width, c.height); ctx.drawImage(img, 0, 0, c.width, c.height);
    return c;
  } finally { URL.revokeObjectURL(url); }
}
async function zlDateiLesen(file, fortschritt){
  const name = file.name || 'Datei';
  if(/\.pdf$/i.test(name) || file.type === 'application/pdf'){
    if(!zlPdfBereit()) throw new Error('Der PDF-Leser ist nicht verfügbar.');
    const pdf = await pdfjsLib.getDocument({ data:new Uint8Array(await file.arrayBuffer()) }).promise;
    const out = [];
    for(let i = 1; i <= pdf.numPages; i++){
      if(ZL.abbruch) break;
      fortschritt(`${name} – Seite ${i} von ${pdf.numPages} …`, i - 1, pdf.numPages);
      const page = await pdf.getPage(i), vp = page.getViewport({ scale:1 });
      const tc = await page.getTextContent();
      const zeichen = tc.items.reduce((s, it) => s + String(it.str || '').trim().length, 0);
      let bilder = 0; const fonts = {};
      try{
        const ops = await page.getOperatorList(), O = pdfjsLib.OPS;
        bilder = ops.fnArray.filter(f => f === O.paintImageXObject || f === O.paintJpegXObject || f === O.paintInlineImageXObject).length;
        for(const it of tc.items){ if(it.fontName && !(it.fontName in fonts)){ try{ const fo = page.commonObjs.get(it.fontName); fonts[it.fontName] = (fo && (fo.name || fo.loadedName)) || ''; }catch(e){ fonts[it.fontName] = ''; } } }
      }catch(e){}
      if(zeichen >= 120 && !(bilder > 0 && zeichen < 1200)) out.push({ nr:i, zeilen:zlZeilenAusPdf(tc.items, vp.transform, fonts), art:'text', datei:name });
      else {
        fortschritt(`${name} – Seite ${i} von ${pdf.numPages}: eingescannt, Texterkennung läuft …`, i - 0.5, pdf.numPages);
        const c = await zlPdfSeiteRendern(page);
        out.push({ nr:i, zeilen:await zlOcrCanvas(c), art:'ocr', datei:name });
        c.width = c.height = 1;
      }
      try{ page.cleanup(); }catch(e){}
    }
    return out;
  }
  if(/^image\//.test(file.type) || /\.(jpe?g|png|webp|bmp)$/i.test(name)){
    fortschritt(`${name} – Texterkennung läuft …`, 0.5, 1);
    const c = await zlBildCanvas(file);
    const z = await zlOcrCanvas(c); c.width = c.height = 1;
    return [{ nr:1, zeilen:z, art:'ocr', datei:name }];
  }
  throw new Error(name + ': Bitte ein PDF oder Fotos (JPG/PNG) nehmen.');
}

// ═════════ 6) Dialog: Zeitung einlesen ═════════
function zlQuelleAusDatei(n){ return String(n || '').replace(/\.[a-z0-9]+$/i, '').replace(/[_]+/g, ' ').replace(/\s*\b(seite|s)\s*\d+\b/ig, '').replace(/\s+/g, ' ').trim().slice(0, 50); }
function zlDialog(dateien){
  ZL.ergebnis = null; ZL.bericht = null; ZL.abbruch = false; ZL.seiten = [];
  if(ZL.quelleAuto){ ZL.quelle = ''; ZL.datum = ''; }
  x20Modal(`<div id="zlModal"><h3>📄 Zeitung einlesen</h3>
    <div class="gs-intro">PDF der Anzeigenseiten (E-Paper oder eingescannt) oder Fotos hier reinziehen. Das Cockpit liest die Immobilienanzeigen selbst aus: <b>Angebote</b> werden Akquise-Leads, <b>Kaufgesuche</b> werden Suchkunden. Alles bleibt auf deinem PC – ohne KI, ohne Kosten.</div>
    <div class="zl-drop" id="zlDrop" ondragover="event.preventDefault();this.classList.add('an')" ondragleave="this.classList.remove('an')" ondrop="event.preventDefault();event.stopPropagation();this.classList.remove('an');zlStart(event.dataTransfer.files)" onclick="document.getElementById('zlDatei').click()">
      <div class="zl-ic">📄</div><b>PDF oder Fotos hierher ziehen</b><small>oder klicken zum Auswählen · mehrere Dateien gehen auch</small></div>
    <input type="file" id="zlDatei" accept=".pdf,application/pdf,image/*" multiple style="display:none" onchange="zlStart(this.files)">
    <div class="zl-felder"><label>Zeitung / Quelle<input id="zlQuelle" placeholder="z. B. Havelland Kurier" value="${akqEsc(ZL.quelle)}" oninput="ZL.quelle=this.value;ZL.quelleAuto=false"></label><label>Erscheinungsdatum<input id="zlDatum" type="date" value="${akqEsc(ZL.datum)}" oninput="ZL.datum=this.value"><small>leer = aus der Zeitung lesen</small></label></div>
    <div id="zlStatus"></div><div id="zlErgebnis"></div>
    <div class="modal-actions"><div><button class="secondary" id="zlKiKnopf" style="display:none" onclick="zlKiKopieren()">🤖 Mit KI genauer auswerten</button></div><div class="right"><button class="secondary" onclick="zlSchliessen()">Schließen</button><button id="zlUebernehmenKnopf" style="display:none" onclick="zlUebernehmen()">Übernehmen</button></div></div></div>`, 760);
  if(dateien && dateien.length) zlStart(dateien);
}
function zlSchliessen(){ ZL.abbruch = true; zlOcrEnde(); schliesseModal(); }
function zlStatus(t, anteil){
  const el = document.getElementById('zlStatus'); if(!el) return;
  el.innerHTML = t ? `<div class="zl-status">${anteil !== undefined ? `<div class="zl-balken"><span style="width:${Math.round(Math.max(0.03, Math.min(1, anteil)) * 100)}%"></span></div>` : ''}<div>${t}</div></div>` : '';
}
async function zlStart(files){
  files = Array.from(files || []).filter(f => /\.pdf$/i.test(f.name) || f.type === 'application/pdf' || /^image\//.test(f.type) || /\.(jpe?g|png|webp|bmp)$/i.test(f.name));
  if(!files.length){ akqToast('Bitte ein PDF oder Fotos nehmen'); return; }
  if(ZL.laeuft) return;
  ZL.laeuft = true; ZL.abbruch = false; ZL.dateien = files.map(f => f.name);
  if(!ZL.quelle){ ZL.quelle = zlQuelleAusDatei(files[0].name); ZL.quelleAuto = true; const q = document.getElementById('zlQuelle'); if(q) q.value = ZL.quelle; }
  const drop = document.getElementById('zlDrop'); if(drop) drop.classList.add('klein');
  document.getElementById('zlErgebnis').innerHTML = '';
  const seiten = []; const fehler = [];
  const t0 = Date.now();
  try{
    for(let d = 0; d < files.length; d++){
      if(ZL.abbruch) break;
      try{
        const s = await zlDateiLesen(files[d], (t, i, n) => zlStatus(`⏳ ${akqEsc(t)}`, (d + (n ? i / n : 0)) / files.length));
        s.forEach(x => { x.nr = seiten.length + 1; seiten.push(x); });
      }catch(e){ console.error(e); fehler.push(files[d].name + ': ' + (e.message || e)); }
    }
  } finally { ZL.laeuft = false; zlOcrEnde(); }
  if(!document.getElementById('zlModal')) return;
  ZL.seiten = seiten;
  const r = zlAnalysieren(seiten, { quelle:ZL.quelle || 'Zeitung', datum:ZL.datum || '' });
  r.ocrSeiten = seiten.filter(s => s.art === 'ocr').length; r.textSeiten = seiten.length - r.ocrSeiten; r.sek = Math.round((Date.now() - t0) / 1000); r.fehler = fehler;
  const nurPrivat = !!(akqDb().einst || {}).nurPrivat;
  r.angebote.forEach(a => { a.an = !a.miete && !(nurPrivat && a.makler) && !a.duenn; });
  r.gesuche.forEach(g => { g.an = !g.duenn; });
  ZL.ergebnis = r;
  if(!ZL.datum && r.datum){ const dd = document.getElementById('zlDatum'); if(dd) dd.value = r.datum; }
  zlStatus(`✅ ${seiten.length} Seite${seiten.length === 1 ? '' : 'n'} gelesen${r.ocrSeiten ? ` (${r.ocrSeiten} davon per Texterkennung)` : ''} in ${r.sek} s${r.datum ? ' · Ausgabe vom ' + r.datum.split('-').reverse().join('.') : ''}${fehler.length ? `<div class="gs-fehler" style="margin-top:6px;">${fehler.map(akqEsc).join('<br>')}</div>` : ''}`);
  zlErgebnisZeigen();
}
function zlGesuchKurz(g){
  const arten = (g.arten || []).map(a => ({ EFH:'EFH', DHH:'DHH', Reihenhaus:'RH', Wohnung:'Wohnung', 'Grundstück':'Grundstück', MFH:'MFH', Gewerbe:'Gewerbe' }[a] || a)).join('/') || 'Immobilie';
  const orte = (g.orte || []).join(', ') + (g.berlinAlle ? (g.orte && g.orte.length ? ', ' : '') + 'ganz Berlin' : '') + (g.umland ? ' + Umland' : '');
  return `${arten}${orte ? ' in ' + orte : ''}${g.preisMax ? ' · bis ' + aqEur(g.preisMax) + (g.nutzung === 'miete' ? ' Miete' : '') : ''}${g.zimmerMin ? ' · ab ' + String(g.zimmerMin).replace('.', ',') + ' Zi.' : ''}${g.flaecheMin ? ' · ab ' + g.flaecheMin + ' m²' : ''}${g.grundstueckMin ? ' · Grundstück ab ' + g.grundstueckMin.toLocaleString('de-DE') + ' m²' : ''}${g.nutzung === 'miete' ? ' · zur Miete' : ''}`;
}
function zlErgebnisZeigen(){
  const r = ZL.ergebnis, el = document.getElementById('zlErgebnis'); if(!r || !el) return;
  const kontakt = x => x.telefon ? '📞 ' + akqEsc(x.telefon) : x.email ? '✉️ ' + akqEsc(x.email) : x.chiffre ? 'Chiffre ' + akqEsc(x.chiffre) : '<span class="zl-warn">kein Kontakt</span>';
  const privChip = a => a.makler ? '<span class="chip zl-makler">Makler</span>' : /🟢/.test(a.f.privat) ? '<span class="chip zl-privat">privat</span>' : '';
  const ang = r.angebote.map((a, i) => `<label class="zl-zeile"><input type="checkbox" ${a.an ? 'checked' : ''} onchange="ZL.ergebnis.angebote[${i}].an=this.checked;zlKnopf()"><span><b>${akqEsc(a.f.objekt)}</b>${a.f.lage ? ' · ' + akqEsc(a.f.lage) : ''}${a.f.preis ? ' · ' + akqEsc(a.f.preis) : ''} ${privChip(a)}${a.miete ? '<span class="chip">Vermietung</span>' : ''}${a.duenn ? '<span class="chip zl-duenn" title="Kein Preis und kein Kontakt erkannt – evtl. schlecht lesbar. Bitte prüfen.">⚠ unvollständig</span>' : ''}<small>${kontakt({ telefon:a.f.telefon, email:a.f.email, chiffre:(a.f.kontakt || '').replace(/^Chiffre\s*/, '') })} · <span class="zl-text" title="${akqEsc(a.text)}">${akqEsc(a.text.slice(0, 110))}${a.text.length > 110 ? '…' : ''}</span></small></span></label>`).join('');
  const ges = r.gesuche.map((g, i) => { const n = typeof skObjekteFuer === 'function' ? skObjekteFuer(Object.assign({ status:'aktiv' }, g)).length : 0; return `<label class="zl-zeile"><input type="checkbox" ${g.an ? 'checked' : ''} onchange="ZL.ergebnis.gesuche[${i}].an=this.checked;zlKnopf()"><span><b>${akqEsc(g.wer || (g.chiffre ? 'Chiffre ' + g.chiffre : 'Suchkunde'))}</b> sucht ${akqEsc(zlGesuchKurz(g))}${n ? ` <span class="chip zl-treffer">passt zu ${n} Objekt${n === 1 ? '' : 'en'}</span>` : ''}${g.duenn ? '<span class="chip zl-duenn">⚠ ohne Kontakt</span>' : ''}<small>${kontakt(g)} · <span class="zl-text" title="${akqEsc(g.text)}">${akqEsc(g.text.slice(0, 110))}${g.text.length > 110 ? '…' : ''}</span></small></span></label>`; }).join('');
  const weg = r.weg.filter(w => w.grund !== 'zu kurz');
  el.innerHTML = `${r.angebote.length || r.gesuche.length ? '' : `<div class="gs-hinweis">Keine Immobilienanzeigen erkannt. Ist es die richtige Seite? Bei schlechten Scans hilft „Mit KI genauer auswerten“.</div>`}
    ${r.angebote.length ? `<div class="zl-kopf">🏠 Angebote <span>${r.angebote.length}</span><a href="#" onclick="zlAlle('angebote');return false;">alle an/aus</a></div><div class="zl-liste">${ang}</div>` : ''}
    ${r.gesuche.length ? `<div class="zl-kopf">👥 Kaufgesuche → Suchkunden <span>${r.gesuche.length}</span><a href="#" onclick="zlAlle('gesuche');return false;">alle an/aus</a></div><div class="zl-liste">${ges}</div>` : ''}
    ${weg.length ? `<details class="zl-weg"><summary>${weg.length} nicht übernommen (keine Immobilie, Makler-Gesuch …)</summary>${weg.map(w => `<div><b>${akqEsc(w.grund)}:</b> ${akqEsc(w.text)}</div>`).join('')}</details>` : ''}`;
  document.getElementById('zlKiKnopf').style.display = ZL.seiten.length ? '' : 'none';
  zlKnopf();
}
function zlAlle(k){ const l = ZL.ergebnis[k]; const an = !l.every(x => x.an); l.forEach(x => x.an = an); zlErgebnisZeigen(); }
function zlKnopf(){
  const b = document.getElementById('zlUebernehmenKnopf'), r = ZL.ergebnis; if(!b || !r) return;
  const a = r.angebote.filter(x => x.an).length, g = r.gesuche.filter(x => x.an).length;
  b.style.display = (a + g) ? '' : 'none';
  b.textContent = `Übernehmen: ${a ? a + ' Lead' + (a === 1 ? '' : 's') : ''}${a && g ? ' + ' : ''}${g ? g + ' Suchkunde' + (g === 1 ? '' : 'n') : ''}`;
}
function zlUebernehmen(){
  const r = ZL.ergebnis; if(!r) return;
  const datum = ZL.datum || r.datum || '';
  const quelle = (ZL.quelle || 'Zeitung').trim();
  const angebote = r.angebote.filter(x => x.an).map(a => { const f = Object.assign({}, a.f, { quelle:quelle + ' (Zeitung)', datum:datum ? datum.split('-').reverse().join('.') : a.f.datum }); return akqAufbereiten({ f, titel:'' }); });
  const ber = angebote.length ? akqUebernehmen(angebote, 'Zeitung (PDF)') : { id:'imp' + Date.now(), neuObjekte:0, neuKontakte:0, doppelt:0, liste:[] };
  let sk = { neu:0, doppelt:0, kontakteNeu:0, treffer:0 };
  const ges = r.gesuche.filter(x => x.an);
  if(ges.length && typeof skUebernehmen === 'function') sk = skUebernehmen(ges.map(g => Object.assign({}, g, { quelle:'Zeitung', quelleText:quelle, datum:datum || g.datum })), ber.id);
  ZL.bericht = { ber, sk };
  const el = document.getElementById('zlErgebnis');
  if(el) el.innerHTML = `<div class="gs-ok">✅ ${ber.neuObjekte} neue Lead${ber.neuObjekte === 1 ? '' : 's'}${ber.doppelt ? ` · ${ber.doppelt} schon bekannt (Preis/Link aktualisiert)` : ''}${ges.length ? ` · ${sk.neu} neue Suchkunde${sk.neu === 1 ? '' : 'n'}${sk.doppelt ? `, ${sk.doppelt} schon bekannt` : ''}` : ''}${sk.treffer ? `<br><b>👥 Die Suchkunden passen zu ${sk.treffer} Objekt${sk.treffer === 1 ? '' : 'en'}</b> – siehe „Käufer & Markt“.` : ''}</div>
    <div class="gs-knoepfe" style="margin-top:10px;"><button onclick="schliesseModal();wechsleAnsicht('akquise')">Zur Akquise</button>${ges.length ? `<button class="secondary" onclick="schliesseModal();KM.tab='suchkunden';wechsleAnsicht('kaeufer')">Zu den Suchkunden</button>` : ''}<button class="secondary" onclick="zlRueckgaengig()">↩️ Rückgängig</button></div>`;
  ['zlUebernehmenKnopf', 'zlKiKnopf'].forEach(id => { const b = document.getElementById(id); if(b) b.style.display = 'none'; });
  const drop = document.getElementById('zlDrop'); if(drop) drop.style.display = 'none';
  if(aktuelleAnsicht === 'akquise' || aktuelleAnsicht === 'kaeufer') renderMain();
  try{ tbGlockeAktualisieren(); }catch(e){}
}
function zlRueckgaengig(){ const b = ZL.bericht; if(!b) return; akqRueckgaengig(b.ber.id); schliesseModal(); }
function zlKiKopieren(){
  const p = AKQ_PROMPTS.find(x => x.key === 'zeitung'); const a = akqDb();
  const e = Object.assign({ gebiet:'Berlin und Umland', arten:'Häuser, Wohnungen, Grundstücke', nurPrivat:false, anzahl:20, tage:3 }, a.einst || {});
  const text = ZL.seiten.map(s => { const { spalten } = zlSpalten(s.zeilen); return `--- Seite ${s.nr} (${s.datei}) ---\n` + spalten.map(sp => zlBloecke(sp).map(b => b.text).join('\n\n')).join('\n\n'); }).join('\n\n');
  const prompt = p.prompt(e).replace(/Im Anhang sind Seiten aus Zeitungen\/Anzeigenblättern \(Fotos oder PDF\)\./, 'Unten steht der ausgelesene Text von Anzeigenseiten einer Zeitung' + (ZL.quelle ? ' („' + ZL.quelle + '“)' : '') + ' – Spalten können etwas durcheinander sein, Lesefehler der Texterkennung bitte sinnvoll korrigieren.') + '\n\nTEXT DER SEITEN:\n' + text;
  akqKopieren(prompt, '🤖 Prompt mit dem Zeitungstext kopiert – in Claude/ChatGPT einfügen, Antwort hier mit Strg+V einfügen');
}
// Datei auf die Seite gezogen (Akquise / Käufer & Markt) → Dialog; sonst nie das Fenster wegnavigieren lassen
document.addEventListener('dragover', e => { if(e.dataTransfer && Array.from(e.dataTransfer.types || []).includes('Files')) e.preventDefault(); });
document.addEventListener('drop', e => {
  if(!e.dataTransfer || !e.dataTransfer.files || !e.dataTransfer.files.length) return;
  e.preventDefault();
  const bg = document.getElementById('modalBg'); if(bg && bg.classList.contains('show')) return;
  if(!['akquise', 'kaeufer'].includes(aktuelleAnsicht)) return;
  if(e.target && e.target.closest && e.target.closest('#dpBild, .dok-sektion, .dok-drop, [ondrop]')) return;
  const f = Array.from(e.dataTransfer.files).filter(x => /\.pdf$/i.test(x.name) || x.type === 'application/pdf');
  if(f.length) zlDialog(f);
});
