// ═══ MaklerCockpit v37/v38 – Mietpotenzial: Daten, Rechnen (Recht), Auffrischung. Karte, Texte, Vergleichsangebote, Prompt und Import: miete38.js ═══
// + Mietdaten-Auffrischung alle 2 Wochen über Jarvis (Prompt → JARVIS-IMPORT typ=mieten → hier gespeichert).
// Grundlagen: Angebotsmieten (CBRE/Berlin Hyp 2026 bzw. aufgefrischte Jarvis-Daten), Berliner Mietspiegel 2026 über den
// Mietrechner-Kern (MR), Gebietsregeln (MR.gebiet). Orientierung, keine Rechtsberatung, keine Zusicherung.
const MP37_TAGE = 14;
const MP37_RECHT = {
  stand: '2026-11-15',
  punkte: [
    { t: 'Mietpreisbremse Berlin', s: 'Ganz Berlin, Mietenbegrenzungsverordnung vom 11.11.2025, gültig 01.01.2026–31.12.2029. Bei Neuvermietung höchstens ortsübliche Vergleichsmiete + 10 %.', u: 'https://www.berlin.de/sen/sbw/_assets/service/rechtsvorschriften/bereich-wohnen/vo19-298.pdf' },
    { t: 'Ausnahmen von der Mietpreisbremse', s: 'Wohnungen, die nach dem 01.10.2014 erstmals genutzt und vermietet wurden (gilt auch für jede spätere Vermietung) · erste Vermietung nach umfassender Modernisierung · eine höhere Vormiete darf bleiben (ohne im letzten Jahr vereinbarte Erhöhungen). Der Mieter muss vor Abgabe seiner Vertragserklärung in Textform darüber informiert werden.', u: 'https://www.buzer.de/556f_BGB.htm' },
    { t: 'Berliner Mietspiegel 2026', s: 'Qualifiziert, gilt seit 28.05.2026, Median 7,71 €/m². Gilt nicht für Ein-/Zweifamilien- und Reihenhäuser, Neubau ab Bezug 2025 und preisgebundene Wohnungen.', u: 'https://www.berlin.de/sen/sbw/presse/pressemeldungen/pressemitteilung.1674998.php' },
    { t: 'Ordnungswidrigkeit (§ 5 WiStG)', s: 'Mehr als 20 % über der ortsüblichen Vergleichsmiete bei Ausnutzung eines geringen Angebots: Bußgeld bis 50.000 €. Gilt auch für Neubau und möblierte Wohnungen. Die Mietpreisprüfstelle Berlin scannt seit Juni 2026 monatlich automatisch Mietinserate (im ersten Scan 46 % auffällig).', u: 'https://www.boerse-express.com/news/articles/berlin-scannt-7700-inserate-46-verdaechtig-auf-mietbremsen-verstoss-931129' },
    { t: 'Mietwucher (§ 291 StGB)', s: 'Strafbar; die Rechtsprechung nimmt ihn etwa ab 50 % über der Vergleichsmiete an (Richtwert, keine Zahl im Gesetz).', u: 'https://www.berliner-mieterverein.de/?p=95332' },
    { t: 'Mietendeckel', s: 'Den Berliner Mietendeckel (MietenWoG Bln) hat das Bundesverfassungsgericht am 25.03.2021 für nichtig erklärt – er gilt nicht. Ein bundesweiter Mietendeckel ist nur ein Antrag der Linken (BT-Drs. 21/7688), nicht beschlossen.', u: 'https://dserver.bundestag.de/btd/21/076/2107688.pdf' },
    { t: 'Kappungsgrenze (laufende Mietverträge)', s: 'Berlin: höchstens 15 % in 3 Jahren bis zur Vergleichsmiete (Verordnung bis 10.05.2028). Brandenburg: 15 % in 36 Gemeinden (bis 31.12.2030), sonst 20 %.', u: 'https://www.buzer.de/558_BGB.htm' },
    { t: 'Brandenburg', s: 'Mietpreisbremse in 36 Gemeinden (Verordnung bis 31.12.2029), z. B. Potsdam, Falkensee, Teltow, Kleinmachnow. Außerhalb dieser Gemeinden gibt es keine Mietpreisbremse.', u: 'https://bravors.brandenburg.de/verordnungen/mietbegrenzv_2025' },
    { t: 'Möblierte Wohnungen', s: 'Unterliegen schon heute der Mietpreisbremse. Der Möblierungszuschlag ist gesetzlich noch nicht geregelt (Entwurf Mietrecht II: Zuschlag gesondert ausweisen, höchstens 1 % des Möbel-Zeitwerts pro Monat).', u: 'https://dserver.bundestag.de/btd/21/068/2106807.pdf' },
    { t: 'Mietrecht II (Entwurf)', s: 'Regierungsentwurf BT-Drs. 21/6807, Anhörung am 14.10.2026, noch nicht beschlossen: Indexmiete gedämpft (über 3 % nur zur Hälfte), Kurzzeitmiete 6–8 Monate, Möblierungszuschlag ausweisen.', u: 'https://www.bundestag.de/dokumente/textarchiv/2026/kw42-pa-recht-mieten-1221718' },
    { t: 'Mietenkataster Berlin', s: 'Am 02.07.2026 beschlossen: Vermieter müssen Miete, Fläche usw. an ein Register melden (Aufbau läuft, Meldepflicht voraussichtlich ab 2028).', u: 'https://www.haufe.de/immobilien/wirtschaft-politik/berlin-das-sind-die-plaene-nach-dem-mietendeckel_84342_544236.html' }
  ]
};
const MP37_SALDO = [[-5, '−5 sehr einfach (alle Gruppen negativ)'], [-3, '−3 einfach'], [-2, '−2'], [-1, '−1 etwas unter Durchschnitt'], [0, '±0 durchschnittlich (Mittelwert)'], [1, '+1 etwas besser'], [2, '+2'], [3, '+3 gehoben'], [5, '+5 sehr gut (alle Gruppen positiv)']];

function mp37Db(){ if(!db.mieten37 || typeof db.mieten37 !== 'object') db.mieten37 = {}; const m = db.mieten37; if(!m.gebiete) m.gebiete = {}; if(!Array.isArray(m.recht)) m.recht = []; if(!Array.isArray(m.verlauf)) m.verlauf = []; return m; }
function mp37E(s){ return mc24E(s == null ? '' : String(s)); }
function mp37Z(n, d){ return n == null || !isFinite(n) ? '–' : Number(n).toLocaleString('de-DE', { minimumFractionDigits: d == null ? 2 : d, maximumFractionDigits: d == null ? 2 : d }); }
function mp37Eur(n){ return n == null || !isFinite(n) ? '–' : Math.round(n).toLocaleString('de-DE') + ' €'; }
function mp37Heute(){ return new Date(Date.now() - new Date().getTimezoneOffset() * 6e4).toISOString().slice(0, 10); }
function mp37DatumDe(iso){ const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(String(iso || '')); return m ? `${m[3]}.${m[2]}.${m[1]}` : String(iso || ''); }
function mp37Norm(s){ return String(s || '').toLowerCase().replace(/ä/g, 'ae').replace(/ö/g, 'oe').replace(/ü/g, 'ue').replace(/ß/g, 'ss').replace(/\(.*?\)/g, '').replace(/[^a-z0-9]+/g, ''); }
// Fälligkeit der Auffrischung
function mp37Alter(){ const m = mp37Db(); if(!m.importiert) return null; return Math.floor((Date.now() - m.importiert) / 864e5); }
function mp37Faellig(){ const a = mp37Alter(); return a == null || a >= MP37_TAGE; }
function mp37StandText(){
  const m = mp37Db();
  if(!m.importiert) return 'noch nie aufgefrischt – eingebaut sind IBB-Wohnungsmarktbericht 2025 und CBRE-Wohnmarktreport 2026 (Angebote 2025)';
  const a = mp37Alter(), naechste = new Date(m.importiert + MP37_TAGE * 864e5);
  return `Stand ${mp37DatumDe(m.stand)} (vor ${a} Tag${a === 1 ? '' : 'en'}) · ${a >= MP37_TAGE ? 'Auffrischung fällig' : 'nächste am ' + naechste.toLocaleDateString('de-DE')}`;
}

// ── Gebietsdaten: aufgefrischt (db.mieten37) vor eingebaut (MV25) ──
function mp37GebietSchluessel(name){
  const n = mp37Norm(name);
  if(!n) return null;
  if(n === 'berlin' || n === 'berlingesamt') return 'berlin';
  for(const [bez, b] of Object.entries(MV25.bezirke)) if(mp37Norm(bez) === n) return b.gid;
  for(const [bez, b] of Object.entries(MV25.bezirke)) if(mp37Norm(bez).startsWith(n) || n.startsWith(mp37Norm(bez))) return b.gid;
  for(const [gid, g] of Object.entries(MV25_BB)) if(mp37Norm(g.name) === n) return gid;
  return 'x_' + n.slice(0, 30);
}
function mp37Daten(lage){
  const m = mp37Db(), out = { ebenen: [] };
  const neu = k => m.gebiete[k] || null;
  if(lage.land === 'BE'){
    const b = lage.bezirk ? MV25.bezirke[lage.bezirk] : null, j = b ? neu(b.gid) : null;
    if(j && j.median) out.ebenen.push({ ebene: 'Bezirk ' + lage.bezirk, median: j.median, unten: j.unten, oben: j.oben, bestand: j.bestand, neubau: j.neubau, trend: j.trend_12m, quelle: j.quelle, url: j.url, stand: j.zeitraum || mp37DatumDe(j.datum), neu: true });
    if(lage.plz && MV25_PLZ[lage.plz]) out.ebenen.push({ ebene: 'PLZ ' + lage.plz, median: MV25_PLZ[lage.plz], quelle: MV25.quelle, url: MV25.url, stand: MV25.stand });
    if(b && !(j && j.median)) out.ebenen.push({ ebene: 'Bezirk ' + lage.bezirk, median: b.m, unten: b.u, oben: b.o, quelle: MV25.quelle, url: MV25.url, stand: MV25.stand });
    const be = neu('berlin');
    out.berlin = be && be.median ? { median: be.median, unten: be.unten, oben: be.oben, quelle: be.quelle, stand: be.zeitraum || mp37DatumDe(be.datum) } : { median: MV25.berlin.m, unten: MV25.berlin.u, oben: MV25.berlin.o, quelle: MV25.quelle, stand: MV25.stand };
    // Spanne (günstig/teuer): aus der genauesten Ebene, die sie hat; sonst Berlin
    const mitSpanne = out.ebenen.find(e => e.unten && e.oben);
    out.unten = mitSpanne ? mitSpanne.unten : out.berlin.unten; out.oben = mitSpanne ? mitSpanne.oben : out.berlin.oben;
    out.spanneEbene = mitSpanne ? mitSpanne.ebene : 'Berlin gesamt';
  } else if(lage.land === 'BB'){
    const g = MV25_BB[lage.gid] || {}, j = neu(lage.gid);
    if(j && j.median) out.ebenen.push({ ebene: 'Gemeinde ' + (g.name || ''), median: j.median, unten: j.unten, oben: j.oben, bestand: j.bestand, neubau: j.neubau, trend: j.trend_12m, quelle: j.quelle, url: j.url, stand: j.zeitraum || mp37DatumDe(j.datum), neu: true });
    else if(g.miete) out.ebenen.push({ ebene: 'Gemeinde ' + g.name, median: mv25N(g.miete), quelle: g.quelle || 'Jarvis-Marktdaten', stand: g.stand || '' });
    const mitSpanne = out.ebenen.find(e => e.unten && e.oben);
    out.unten = mitSpanne ? mitSpanne.unten : null; out.oben = mitSpanne ? mitSpanne.oben : null; out.spanneEbene = mitSpanne ? mitSpanne.ebene : '';
  }
  out.haupt = out.ebenen[0] || null;
  return out;
}
// Mietvergleich (v25) nutzt aufgefrischte Werte ebenfalls
(function(){
  const _mv25J = mv25Jarvis;
  mv25Jarvis = function(gid){
    try{ const j = mp37Db().gebiete[gid]; if(j && j.median > 3 && j.median < 80) return { m: j.median, stand: j.zeitraum || mp37DatumDe(j.datum), quelle: j.quelle || 'Mietdaten-Auffrischung', url: j.url || '' }; }catch(e){}
    return _mv25J.apply(this, arguments);
  };
})();

// ── Eingaben: Objektakte + Einstellungen am Objekt (o.miete37) ──
function mp37Eingaben(o, a){
  const x = mv25AusObjekt(o), w = (a && a.eingabe && a.eingabe.werte) || {};
  const val = k => (w[k] && w[k].wert != null ? w[k].wert : null);
  const s = Object.assign({ saldo: 0, neubau: 'auto', umfMod: false, vormiete: null, moebliert: false, ovmManuell: null, wohnlage: '', belegt: false, mietart: '', letzteErh: '', mieteVorher: null }, o.miete37 || {});
  return {
    flaeche: mv25N(val('wohnflaeche') != null ? val('wohnflaeche') : x.flaeche), baujahr: mv25N(val('baujahr') != null ? val('baujahr') : x.baujahr),
    objektart: (a && a.eingabe && a.eingabe.objektart) || o.objekttyp || o.objektart || '', ort: o.ort, adresse: o.adresse,
    wohnlage: s.wohnlage || x.wohnlage || '', miete: mv25N(x.miete), vermietung: x.vermietung, s
  };
}
function mp37IstHaus(art){ const t = String(art || '').toLowerCase(); return /einfamil|zweifamil|reihen|doppelh|\befh\b|\bzfh\b|\bdhh\b|\brh\b|bungalow|villa|^haus$|landhaus/.test(t) && !/mehrfamil|mfh|wohnung|etw/.test(t); }
function mp37Merkmale(saldo){ const g = (MR && MR.GRUPPEN) || ['bad', 'kueche', 'wohnung', 'gebaeude', 'umfeld'], m = {}; const n = Math.max(-5, Math.min(5, Math.round(saldo || 0))); g.slice(0, Math.abs(n)).forEach(k => { m[k] = n > 0 ? '+' : '-'; }); return m; }

// ── Rechnen ──
function mp37Rechnen(o, a){
  const e = mp37Eingaben(o, a), s = e.s, hinweise = [];
  const lage = mv25Lage(e.ort, e.adresse), daten = mp37Daten(lage);
  const fl = e.flaeche && e.flaeche > 5 ? e.flaeche : null;
  const r = { e, lage, daten, fl, hinweise };
  // Gebiet (Mietpreisbremse, Kappung)
  let g = null; try{ g = MR.gebiet([lage.plz, lage.land === 'BE' ? 'Berlin' : (lage.gemeinde || ''), e.ort || ''].filter(Boolean).join(' ')); }catch(err){}
  r.gebiet = g;
  r.bremseGebiet = !!(g && g.bremse);
  // Neubau-Ausnahme
  const bj = e.baujahr;
  r.neubau = s.neubau === 'ja' ? true : s.neubau === 'nein' ? false : !!(bj && bj >= 2015);
  if(s.neubau === 'auto' && bj === 2014) hinweise.push('Baujahr 2014: Die Neubau-Ausnahme gilt nur bei erstmaliger Nutzung und Vermietung nach dem 01.10.2014 – bitte unter „Neubau-Ausnahme“ festlegen.');
  r.neubauVermutet = s.neubau === 'auto' && r.neubau;
  r.ausnahme = r.neubau ? 'Neubau (erstmals genutzt und vermietet nach dem 01.10.2014)' : s.umfMod ? 'Erste Vermietung nach umfassender Modernisierung' : '';
  r.bremse = r.bremseGebiet && !r.ausnahme;
  // Mietspiegel / ortsübliche Vergleichsmiete
  r.ms = null; r.msFehler = '';
  if(lage.land === 'BE' && !mp37IstHaus(e.objektart) && fl && bj && bj <= 2024){
    const ort = [lage.plz, 'Berlin', lage.bezirk || ''].filter(Boolean).join(' ');
    const je = {};
    for(const wl of ['einfach', 'mittel', 'gut']){
      try{ const v = MR.vergleichsmiete({ flaeche: fl, baujahr: bj, ort, wohnlage: wl, merkmale: mp37Merkmale(s.saldo) }); je[wl] = { qm: v.qm, u: v.feld.u, m: v.feld.m, o: v.feld.o, feld: v.feld.zeile || v.feld.nr || '' }; }
      catch(err){ je[wl] = { fehler: err.message }; }
    }
    const wl = e.wohnlage && je[e.wohnlage] && !je[e.wohnlage].fehler ? e.wohnlage : null;
    const basis = wl || (je.mittel && !je.mittel.fehler ? 'mittel' : null);
    if(basis) r.ms = Object.assign({ wohnlage: basis, sicher: !!wl, je }, je[basis]);
    else r.msFehler = (je.mittel && je.mittel.fehler) || 'Keine Einordnung möglich.';
    if(r.ms && !wl){ const ok = Object.values(je).filter(x => !x.fehler); r.ms.von = Math.min(...ok.map(x => x.qm)); r.ms.bis = Math.max(...ok.map(x => x.qm)); hinweise.push('Wohnlage unbekannt – gerechnet mit mittlerer Lage. Über 🛰 ermitteln oder von Hand wählen.'); }
  } else if(lage.land === 'BE'){
    r.msFehler = mp37IstHaus(e.objektart) ? 'Ein-/Zweifamilien- und Reihenhäuser fallen nicht unter den Mietspiegel.' : !fl ? 'Wohnfläche fehlt.' : !bj ? 'Baujahr fehlt.' : bj > 2024 ? 'Neubau ab Bezug 2025 ist im Mietspiegel 2026 nicht enthalten.' : '';
  } else if(lage.land === 'BB') r.msFehler = 'Für Brandenburg ist kein Mietspiegel hinterlegt (Potsdam hat einen eigenen) – Vergleichsmiete von Hand eintragen.';
  const ovmManuell = mv25N(s.ovmManuell);
  r.ovm = ovmManuell && ovmManuell > 2 ? ovmManuell : r.ms ? r.ms.qm : null;
  r.ovmQuelle = ovmManuell && ovmManuell > 2 ? 'von Hand (Gutachten/Vergleichswohnungen)' : r.ms ? `Berliner Mietspiegel 2026, Feld ${r.ms.feld}, ${({ einfach: 'einfache', mittel: 'mittlere', gut: 'gute' })[r.ms.wohnlage]} Wohnlage${r.ms.sicher ? '' : ' (angenommen)'}, Ausstattung ${s.saldo > 0 ? '+' : ''}${s.saldo}` : '';
  // Grenzen
  const vormieteQm = mv25N(s.vormiete) && fl ? mv25N(s.vormiete) / fl : null;
  r.vormieteQm = vormieteQm;
  if(r.ovm){
    r.grenzeBremse = r.bremse ? Math.max(r.ovm * 1.10, vormieteQm || 0) : null;
    r.wistg = r.ovm * 1.20; r.wucher = r.ovm * 1.50;
  }
  if(r.bremse && vormieteQm && r.ovm && vormieteQm > r.ovm * 1.10) hinweise.push('Die Vormiete liegt über Vergleichsmiete + 10 % und darf beibehalten werden (Erhöhungen, die im letzten Jahr vor Vertragsende vereinbart wurden, zählen nicht mit). Dem neuen Mieter vor Vertragsschluss in Textform mitteilen.');
  if(r.bremseGebiet && !r.ovm) hinweise.push('Die Mietpreisbremse gilt auch hier, aber ohne Vergleichsmiete lässt sich die Obergrenze nicht berechnen – Vergleichsmiete über Gutachten, Mietdatenbank oder tatsächlich vereinbarte Mieten vergleichbarer Objekte belegen und unten eintragen (Portalangebote reichen dafür nicht).');
  if(s.moebliert) hinweise.push('Möbliert: Die Mietpreisbremse gilt auch für möblierte Wohnungen. Einen Möblierungszuschlag nur angemessen und gesondert ausweisen (gesetzlich noch nicht geregelt).');
  if(mp37IstHaus(e.objektart)) hinweise.push('Die Angebotsmieten der Marktberichte beziehen sich überwiegend auf Wohnungen – bei Häusern nur als grobe Orientierung nutzen.');
  // Markt
  const h = daten.haupt;
  r.markt = { unten: daten.unten, median: h ? (r.neubau && h.neubau ? h.neubau : h.median) : null, oben: daten.oben, medianText: h ? (r.neubau && h.neubau ? 'Neubau-Median ' : 'Median ') + h.ebene : '', quelle: h ? h.quelle : '', stand: h ? h.stand : '', url: h ? h.url : '' };
  // Empfehlung fürs Inserat
  const cap = r.bremse ? r.grenzeBremse : (r.ovm ? r.wistg : null);
  r.cap = cap;
  r.realistisch = cap != null ? Math.min(r.markt.median != null ? r.markt.median : cap, cap) : r.markt.median;
  r.von = r.ovm != null && r.realistisch != null ? Math.min(r.ovm, r.realistisch) : null;
  r.bis = cap != null ? cap : null;
  r.marktUeberGrenze = cap != null && r.markt.median != null && r.markt.median > cap;
  // Ist-Miete (vermietet)
  if(e.miete && fl){
    r.istQm = e.miete / fl;
  }
  return r;
}

// (Inserattexte und Karte: miete38.js)
function mp37Setzen(oid, k, wert){
  const o = findObjekt(oid); if(!o) return;
  o.miete37 = Object.assign({}, o.miete37 || {}, { [k]: wert === '' ? null : wert });
  save(); mp37Neuzeichnen();
}
function mp37Neuzeichnen(){ const m = document.getElementById('mp37Modal'); if(m){ const oid = m.dataset.oid; m.outerHTML = mp37ModalInhalt(findObjekt(oid)); } else renderMain(); }
function mp37BerichtSetzen(an){ const a = ma24A(); if(!a || ma24Gesperrt(a)) return; a.mp37Bericht = !!an; save(); }
function mp37RechtStand(){ const m = mp37Db(); return m.rechtStand && m.rechtStand > MP37_RECHT.stand ? m.rechtStand : MP37_RECHT.stand; }
function mp37RechtHtml(){
  const m = mp37Db(), neu = (m.recht || []).filter(x => x && x.thema);
  const liste = MP37_RECHT.punkte.map(p => `<li><b>${mp37E(p.t)}:</b> ${mp37E(p.s)} <a href="${mp37E(p.u)}" target="_blank" rel="noopener">Quelle</a></li>`).join('');
  const aktuell = neu.length ? `<div class="mc24-muted" style="margin-top:6px"><b>Letzte Auffrischung (${mp37DatumDe(m.stand)}):</b></div><ul>${neu.map(x => { const u = mc24SicherLink(x.url); return `<li>${x.geaendert ? '🆕 ' : ''}${mp38RechtStatus(x)}<b>${mp37E(x.thema)}:</b> ${mp37E(x.stand)}${x.wichtig_fuer_neuvermietung ? ' – ' + mp37E(x.wichtig_fuer_neuvermietung) : ''}${u ? ` <a href="${mp37E(u)}" target="_blank" rel="noopener">Quelle</a>` : ''}</li>`; }).join('')}</ul>` : '';
  return `<ul class="mp37-recht">${liste}</ul>${aktuell}`;
}
// Aus dem Objekt (Akte) heraus
function mp37ModalInhalt(o){ return `<div id="mp37Modal" data-oid="${mp37E(o.id)}">${mp37KarteHtml(o, null, false)}<div class="modal-actions"><span></span><div class="right"><button onclick="schliesseModal()">Schließen</button></div></div></div>`; }
function mp37FuerObjekt(oid){ const o = findObjekt(oid); if(!o) return; mc24Modal(mp37ModalInhalt(o), 900); }
(function(){
  const _mvAkte = mv25AkteKarte;
  mv25AkteKarte = function(o){ const h = _mvAkte.apply(this, arguments) || ''; try{ return h + `<div class="mc24-knoepfe" style="margin:6px 0 10px"><button class="tiny secondary" onclick="mp37FuerObjekt('${mp37E(o.id)}')">🏷️ Mietpotenzial & Inserattext</button></div>`; }catch(e){ return h; } };
})();

// ── Marktanalyse: Karte im Schritt „Ergebnis“ + Abschnitt im Eigentümerbericht ──
(function(){
  const _erg = ma24SchrittErgebnis;
  ma24SchrittErgebnis = function(a, r, o){
    const h = _erg.apply(this, arguments);
    let k = ''; try{ k = mp37KarteHtml(o, a, a.status === 'abgeschlossen'); }catch(e){ console.error('mp37', e); }
    const anker = '<div class="mc24-karte"><h3>Preisstrategie</h3>';
    return h.includes(anker) ? h.replace(anker, k + anker) : h + k;
  };
  const _berichtHtml = ma24BerichtHtmlFuer;
  ma24BerichtHtmlFuer = function(a){
    let h = _berichtHtml.apply(this, arguments);
    try{
      const o = ma24Obj(a); if(!o || a.mp37Bericht === false) return h;
      const r = mp37Rechnen(o, a); if(r.realistisch == null && r.ovm == null) return h;
      const sek = mp38BerichtAbschnitt(r);
      h = h.includes('</body>') ? h.replace('</body>', sek + '</body>') : h + sek;
    }catch(e){ console.error('mp37 bericht', e); }
    return h;
  };
  if(typeof ma24BerichtText === 'function'){
    const _bt = ma24BerichtText;
    ma24BerichtText = function(b){ let t = _bt.apply(this, arguments); try{ const a = b && b.analyse, o = a && ma24Obj(a); if(o && a.mp37Bericht !== false){ const r = mp37Rechnen(o, a); if(r.realistisch != null || r.ovm != null) t += '\n\nMIETPOTENZIAL\n' + mp37Texte(r).lang; } }catch(e){} return t; };
  }
})();

// ── Auffrischung alle 2 Wochen: Prompt, Import, Erinnerung ──
// (Prompt und Import der Mietdaten: miete38.js)
function mp37Zahl(v){ const n = typeof v === 'number' ? v : mv25N(v); return n != null && isFinite(n) && n >= 3 && n <= 80 ? Math.round(n * 100) / 100 : null; }
function mp37Txt(v, max){ return v == null ? '' : String(v).replace(/[<>]/g, '').slice(0, max || 200).trim(); }
function mp37JsonZeilen(text){
  let t = String(text || ''); const st = t.search(/JARVIS-IMPORT/i); if(st >= 0) t = t.slice(st);
  const en = t.search(/JARVIS-ENDE/i); if(en >= 0) t = t.slice(0, en);
  if((t.match(/"/g) || []).length < 4) t = t.replace(/[“”„]/g, '"');
  const out = []; let i = 0;
  while((i = t.indexOf('{', i)) >= 0){
    let tiefe = 0, str = false, esc = false, j = i;
    for(; j < t.length; j++){ const c = t[j]; if(str){ if(esc) esc = false; else if(c === '\\') esc = true; else if(c === '"') str = false; continue; } if(c === '"') str = true; else if(c === '{') tiefe++; else if(c === '}'){ tiefe--; if(!tiefe) break; } }
    if(j >= t.length) break;
    try{ const o = JSON.parse(t.slice(i, j + 1)); if(o && typeof o === 'object' && !Array.isArray(o)) out.push(o); }catch(e){}
    i = j + 1;
  }
  return out;
}
function mp37ImportText(text){
  const liste = mp37JsonZeilen(text);
  if(!liste.length) return '⚠️ Kein Block gefunden – bitte die ganze Antwort von JARVIS-IMPORT bis JARVIS-ENDE einfügen.';
  return mp37Import(liste);
}
function mp37Dialog(){
  const m = mp37Db(), g = Object.values(m.gebiete || {});
  mc24Modal(`<h3>🏷️ Mietdaten auffrischen <small class="mc24-muted">(alle 2 Wochen)</small></h3>
    <p class="mc24-muted">${mp37E(mp37StandText())}${g.length ? ` · ${g.length} Gebiete gespeichert` : ''}</p>
    ${m.zusammenfassung ? `<div class="mc24-hinweis">${mp37E(m.zusammenfassung)}</div>` : ''}
    <ol class="mp37-schritte"><li><button onclick="mc24Kopieren(mp37Prompt(document.getElementById('mp37Zusatz').value), '📋 Prompt kopiert – in Claude oder ChatGPT mit Websuche einfügen')">📋 Prompt kopieren</button> <input id="mp37Zusatz" placeholder="optional: weitere Orte, z. B. Bernau, Erkner" style="max-width:300px"></li>
      <li>In <b>Claude</b> oder <b>ChatGPT</b> einfügen (Websuche an) und absenden.</li>
      <li>Den Codeblock aus der Antwort kopieren und hier einfügen:</li></ol>
    <textarea id="mp37Text" rows="8" style="width:100%;font-family:monospace;font-size:12px" placeholder="JARVIS-IMPORT typ=mieten&#10;{…}&#10;JARVIS-ENDE"></textarea>
    <div id="mp37Meld" class="mc24-muted"></div>
    <div class="modal-actions"><button class="secondary" onclick="schliesseModal(); wechsleAnsicht('jarvis')" title="Der Prompt steht auch in Jarvis unter „Suchen“ – mit Erinnerung alle 2 Wochen">Jarvis öffnen</button><div class="right"><button class="secondary" onclick="schliesseModal()">Schließen</button><button onclick="mp37DialogEinlesen()">📥 Einlesen</button></div></div>`, 720);
}
function mp37DialogEinlesen(){
  const t = document.getElementById('mp37Text').value, b = mp37ImportText(t);
  const el = document.getElementById('mp37Meld'); if(el) el.textContent = b;
  if(!/^⚠️/.test(b)){ akqToast(b.slice(0, 140), 6000); setTimeout(() => { try{ schliesseModal(); }catch(e){} renderMain(); }, 1800); }
}
function mp37RechtQuittieren(){ const m = mp37Db(); if(m.rechtNeu) m.rechtNeu.quittiert = true; save(); }
function mp37RechtDialog(){
  const m = mp37Db();
  mc24Modal(`<h3>🆕 Rechtsänderung Miete (Stand ${mp37DatumDe(m.stand)})</h3>${mp37RechtHtml()}<div class="modal-actions"><span></span><div class="right"><button onclick="mp37RechtQuittieren(); schliesseModal(); try{ tbGlockeAktualisieren(); }catch(e){}">Gelesen</button></div></div>`, 760);
}
// Glocke
(function(){
  const _h = tbHinweise;
  tbHinweise = function(){
    const l = _h.apply(this, arguments);
    try{
      const ein = db.hinweisEinst || {}, m = mp37Db();
      if(ein.mp37 !== false && mp37Faellig()) l.push({ k: 'mp37', ic: '🏷️', t: 'Mietdaten auffrischen (alle 2 Wochen)', s: m.importiert ? 'Letzter Stand ' + mp37DatumDe(m.stand) : 'Für Mietpotenzial und Mietvergleich', f: 'mp37Dialog()' });
      if(m.rechtNeu && !m.rechtNeu.quittiert) l.unshift({ k: 'mp37r', ic: '⚖️', t: 'Neue Rechtslage Miete: ' + m.rechtNeu.punkte.slice(0, 2).join(', '), s: 'Antippen zum Lesen', f: 'mp37RechtDialog()' });
    }catch(e){}
    return l;
  };
})();
(function(){
  const st = document.createElement('style');
  st.textContent = `.mp37 .mp37-chips{margin:6px 0 8px}.mp37-chip{display:inline-block;padding:3px 9px;border-radius:999px;font-size:12px;border:1px solid var(--border);background:var(--bg2)}
.mp37-chip.gelb{border-color:var(--yellow);color:var(--yellow)}.mp37-chip.gruen{border-color:var(--green);color:var(--green)}
.mp37-ein{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:6px 12px;margin-bottom:8px}.mp37-ein label{font-size:12px;color:var(--muted)}.mp37-ein select,.mp37-ein input:not([type=checkbox]){width:100%}
.mp37-w{display:flex;gap:6px}.mp37-haken{display:flex;flex-direction:column;justify-content:flex-end;gap:4px}.mp37-haken label,.mp37-bericht{display:flex!important;gap:6px;align-items:center;color:var(--text)!important;font-size:13px!important;text-transform:none;letter-spacing:0}.mp37-haken input,.mp37-bericht input{width:auto;margin:0}
.mp37-tabwrap{overflow-x:auto}.mp37-tab td small{color:var(--muted)}.mp37-tab tr.mp37-grenze td{background:rgba(52,211,153,.08)}.mp37-tab tr.mp37-warn td{color:var(--muted);font-size:12px}.mp37-tab tr.mp37-recht td:first-child{border-left:3px solid var(--blue)}.mp37-tab tr.mp37-markt td:first-child{border-left:3px solid var(--orange)}.mp37-tab tr.mp37-grenze td:first-child{border-left:3px solid var(--green)}
.mp37-ist{margin:8px 0;font-size:13px}.mp37-ergebnis{border:1px solid var(--orange);border-radius:10px;padding:10px 12px;margin:10px 0}.mp37-ergebnis small{display:block;color:var(--muted)}.mp37-ergebnis b{font-size:20px;margin-right:10px}.mp37-ergebnis span{color:var(--muted)}
.mp37-warn-t{color:var(--yellow);font-size:12px;margin-top:4px}.mp37-vorschau{font-size:12px;color:var(--muted);margin-top:6px;white-space:pre-wrap}.mp37-faellig{color:var(--yellow)}
.mp37-hinweise{margin:6px 0 4px 18px;padding:0;font-size:12px;color:var(--muted)}.mp37-recht{margin:6px 0 0 18px;padding:0;font-size:12px}.mp37-recht li{margin-bottom:4px}.mp37-schritte{padding-left:20px}.mp37-schritte li{margin-bottom:6px}
@media (max-width:760px){.mp37-ein{grid-template-columns:1fr 1fr}}@media (max-width:480px){.mp37-ein{grid-template-columns:1fr}}@media (max-width:760px){.mp37-tab th:nth-child(4),.mp37-tab td:nth-child(4){display:none}}`;
  document.head.appendChild(st);
})();
