// ═══ MaklerCockpit v25 – Mietvergleich: Ist-Miete gegen Bezirk/PLZ und Mietspiegel ═══
// Angebotsmieten: CBRE/Berlin Hyp Wohnmarktreport Berlin 2026 (Mietangebote 2025, Median nettokalt) – aktualisierbar über Jarvis („Gebiete auffrischen“).
// Bestand: Berliner Mietspiegel 2026 (ortsübliche Vergleichsmiete) über den Mietrechner-Kern. Rechenhilfe, keine Rechtsberatung.
const MV25 = {
  quelle: 'CBRE/Berlin Hyp Wohnmarktreport Berlin 2026', url: 'https://www.berlinhyp.de/files/media/press/2026/cbre-berlin-hyp-wohnmarktreport-berlin-2026.pdf', stand: 'Mietangebote 2025',
  berlin: { m: 15.80, u: 7.06, o: 28.57 },
  bezirke: {
    'Charlottenburg-Wilmersdorf': { m: 19.23, u: 8.05, o: 31.67, gid: 'be_cw' }, 'Friedrichshain-Kreuzberg': { m: 19.47, u: 7.33, o: 31.03, gid: 'be_fk' },
    'Lichtenberg': { m: 13.33, u: 6.51, o: 24.49, gid: 'be_li' }, 'Marzahn-Hellersdorf': { m: 11.57, u: 6.21, o: 22.01, gid: 'be_mh' },
    'Mitte': { m: 20.01, u: 8.40, o: 32.63, gid: 'be_mitte' }, 'Neukölln': { m: 13.56, u: 6.90, o: 26.67, gid: 'be_nk' },
    'Pankow': { m: 16.97, u: 7.78, o: 28.85, gid: 'be_pankow' }, 'Reinickendorf': { m: 12.62, u: 7.33, o: 23.97, gid: 'be_rd' },
    'Spandau': { m: 12.50, u: 6.99, o: 22.65, gid: 'be_sp' }, 'Steglitz-Zehlendorf': { m: 15.00, u: 7.92, o: 26.53, gid: 'be_sz' },
    'Tempelhof-Schöneberg': { m: 15.90, u: 7.61, o: 30.00, gid: 'be_ts' }, 'Treptow-Köpenick': { m: 15.56, u: 7.02, o: 23.93, gid: 'be_tk' }
  },
  // Median Angebotsmiete je PLZ-Gebiet (alle Segmente) – gleiche Quelle; PLZ mit zu wenigen Angeboten fehlen
  plz: 'Charlottenburg-Wilmersdorf:10585=18.33,10587=19.92,10589=19.87,10623=22.16,10625=19.55,10627=19.60,10629=21.46,10707=21.02,10709=20.28,10711=19.46,10713=20.12,10715=21.57,10717=18.45,10719=23.61,10789=20.35,13627=8.24,14050=16.90,14052=18.00,14055=15.52,14057=18.62,14059=19.39,14193=19.41,14197=11.75,14199=21.15;'
    + 'Friedrichshain-Kreuzberg:10243=21.18,10245=20.78,10247=19.00,10249=20.00,10961=17.57,10963=16.50,10965=19.43,10967=20.26,10969=12.79,10997=18.00,10999=18.95;'
    + 'Lichtenberg:10315=16.00,10317=16.00,10318=16.66,10319=9.25,10365=12.83,10367=9.66,10369=8.64,13051=8.39,13053=13.04,13055=15.25,13057=8.64,13059=7.78;'
    + 'Marzahn-Hellersdorf:12619=12.50,12621=14.30,12623=14.43,12627=12.22,12629=14.91,12679=7.33,12681=8.32,12683=15.00,12685=10.52,12687=13.65,12689=7.77;'
    + 'Mitte:10115=21.49,10117=23.88,10119=22.21,10178=20.11,10179=22.89,10551=17.39,10553=18.00,10555=16.90,10557=22.50,10559=17.42,10785=22.46,10787=22.94,13347=18.00,13349=15.86,13351=16.86,13353=18.01,13355=11.01,13357=17.35,13359=15.21;'
    + 'Neukölln:12043=17.06,12045=17.35,12047=20.00,12049=16.50,12051=16.47,12053=17.00,12055=17.83,12057=8.01,12059=16.70,12347=14.22,12349=12.26,12351=9.64,12353=9.36,12355=11.80,12357=12.87,12359=9.16;'
    + 'Pankow:10405=19.99,10407=18.57,10409=9.99,10435=21.00,10437=20.00,10439=19.29,13086=17.47,13088=19.03,13089=16.91,13125=11.16,13127=15.53,13129=,13156=15.47,13158=15.83,13159=,13187=16.30,13189=16.68;'
    + 'Reinickendorf:13403=12.06,13405=13.98,13407=14.25,13409=13.33,13435=8.66,13437=12.48,13439=7.78,13465=14.59,13467=14.24,13469=11.44,13503=14.23,13505=,13507=13.61,13509=12.22;'
    + 'Spandau:13581=14.60,13583=9.26,13585=15.00,13587=14.00,13589=9.02,13591=12.18,13593=7.62,13595=11.82,13597=11.45,13599=10.29,13629=16.64,14089=15.38;'
    + 'Steglitz-Zehlendorf:12163=16.72,12165=17.00,12167=15.28,12169=15.50,12203=16.44,12205=15.71,12207=12.65,12209=14.00,12247=15.00,12249=11.76,14109=15.07,14129=14.39,14163=16.43,14165=13.17,14167=17.64,14169=14.74,14195=18.84,14053=;'
    + 'Tempelhof-Schöneberg:10777=18.95,10779=19.99,10781=27.00,10783=15.03,10823=18.82,10825=18.35,10827=18.79,10829=21.51,12099=17.82,12101=12.90,12103=16.67,12105=17.75,12107=12.85,12109=14.53,12157=15.43,12159=23.42,12161=16.17,12277=13.94,12279=9.04,12305=11.47,12307=12.15,12309=8.89;'
    + 'Treptow-Köpenick:12435=16.06,12437=15.16,12439=18.70,12459=12.20,12487=14.00,12489=15.00,12524=15.00,12526=15.65,12527=18.55,12555=17.76,12557=15.70,12559=11.56,12587=11.37,12589=14.82',
  ortsteile: {
    'Mitte': 'Mitte|Moabit|Hansaviertel|Tiergarten|Wedding|Gesundbrunnen',
    'Friedrichshain-Kreuzberg': 'Friedrichshain|Kreuzberg',
    'Pankow': 'Prenzlauer Berg|Weißensee|Blankenburg|Heinersdorf|Karow|Pankow|Buch|Französisch Buchholz|Niederschönhausen|Rosenthal|Wilhelmsruh',
    'Charlottenburg-Wilmersdorf': 'Charlottenburg|Wilmersdorf|Schmargendorf|Grunewald|Westend|Halensee',
    'Spandau': 'Spandau|Haselhorst|Siemensstadt|Staaken|Gatow|Kladow|Hakenfelde|Falkenhagener Feld|Wilhelmstadt',
    'Steglitz-Zehlendorf': 'Steglitz|Lichterfelde|Lankwitz|Zehlendorf|Dahlem|Nikolassee|Wannsee',
    'Tempelhof-Schöneberg': 'Schöneberg|Friedenau|Tempelhof|Mariendorf|Marienfelde|Lichtenrade',
    'Neukölln': 'Neukölln|Britz|Buckow|Rudow|Gropiusstadt',
    'Treptow-Köpenick': 'Treptow|Plänterwald|Baumschulenweg|Johannisthal|Schöneweide|Altglienicke|Adlershof|Bohnsdorf|Köpenick|Friedrichshagen|Rahnsdorf|Grünau|Müggelheim|Schmöckwitz',
    'Marzahn-Hellersdorf': 'Marzahn|Biesdorf|Kaulsdorf|Mahlsdorf|Hellersdorf',
    'Lichtenberg': 'Lichtenberg|Friedrichsfelde|Karlshorst|Falkenberg|Malchow|Wartenberg|Hohenschönhausen|Fennpfuhl|Rummelsburg',
    'Reinickendorf': 'Reinickendorf|Tegel|Konradshöhe|Heiligensee|Frohnau|Hermsdorf|Waidmannslust|Lübars|Wittenau|Märkisches Viertel|Borsigwalde'
  },
  mietspiegel: { median: 7.71, name: 'Berliner Mietspiegel 2026', url: 'https://www.berlin.de/sen/sbw/presse/pressemeldungen/pressemitteilung.1674998.php' },
  kappungBis: '10.05.2028'
};
const MV25_PLZ = {}, MV25_PLZ_BEZIRK = {};
MV25.plz.split(';').forEach(teil => { const [bez, liste] = teil.split(':'); (liste || '').split(',').forEach(x => { const [p, v] = x.split('='); if(!p) return; MV25_PLZ_BEZIRK[p] = bez; if(v) MV25_PLZ[p] = Number(v); }); });
const MV25_BB = (typeof window !== 'undefined' && window.MV25_BB_DATEN) || {};

function mv25N(v){ return typeof mc24N === 'function' ? mc24N(v) : (v == null || v === '' ? null : Number(String(v).replace(',', '.'))); }
function mv25Z(n, d){ return n == null || !isFinite(n) ? '–' : Number(n).toLocaleString('de-DE', { minimumFractionDigits: d == null ? 2 : d, maximumFractionDigits: d == null ? 2 : d }); }
function mv25Esc(s){ return typeof mc24E === 'function' ? mc24E(s) : String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }
// Lage aus Ort/Adresse: PLZ → Bezirk; sonst Bezirk-/Ortsteilname; Brandenburg über die Jarvis-Gemeinden
function mv25Lage(ort, adresse){
  const t = [adresse, ort].filter(Boolean).join(' ');
  const plz = (t.match(/\b(1[0-6]\d{3})\b/) || [])[1] || '';
  if(plz && MV25_PLZ_BEZIRK[plz]) return { land: 'BE', bezirk: MV25_PLZ_BEZIRK[plz], plz };
  for(const [gid, g] of Object.entries(MV25_BB)) if(plz && (g.plz || []).includes(plz)) return { land: 'BB', gid, gemeinde: g.name, plz };
  const low = t.toLowerCase();
  for(const [gid, g] of Object.entries(MV25_BB)){ if(!g.name) continue; const n = g.name.toLowerCase().replace(/\s*\(.*?\)/g, '').replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); if(n.length > 2 && new RegExp('(^|[^a-zäöüß])' + n + '([^a-zäöüß]|$)').test(low)) return { land: 'BB', gid, gemeinde: g.name, plz }; }
  if(/\bberlin\b|^1[0-4]\d{3}\b/i.test(t) || plz.startsWith('1') && Number(plz) < 14200){
    for(const bez of Object.keys(MV25.bezirke)) if(low.includes(bez.toLowerCase())) return { land: 'BE', bezirk: bez, plz };
    const kand = [];
    for(const [bez, liste] of Object.entries(MV25.ortsteile)) for(const ot of liste.split('|')) if(new RegExp('(^|[^a-zäöüß])' + ot.toLowerCase() + '([^a-zäöüß]|$)').test(low)) kand.push([ot.length, bez]);
    if(kand.length){ kand.sort((a, b) => b[0] - a[0]); return { land: 'BE', bezirk: kand[0][1], plz }; }
    return { land: 'BE', bezirk: null, plz };
  }
  return { land: null, plz };
}
// Jarvis-Aktualisierung („Gebiete auffrischen“) hat Vorrang vor den eingebauten Werten
function mv25Jarvis(gid){
  try{ const g = db.jarvis && db.jarvis.markt_gebiete && db.jarvis.markt_gebiete[gid]; const v = g ? mv25N(g.miete_m2) : null; return v && v > 3 && v < 60 ? { m: v, stand: g.stand || '', quelle: g.quelle || 'Jarvis-Recherche', url: g.url || '' } : null; }catch(e){ return null; }
}
function mv25Referenz(lage){
  const r = { angebot: null, bezirk: null, plz: null, ebene: '', hinweise: [] };
  if(lage.land === 'BE'){
    const b = lage.bezirk ? MV25.bezirke[lage.bezirk] : null;
    if(b){
      const j = mv25Jarvis(b.gid);
      r.bezirk = { name: lage.bezirk, m: j ? j.m : b.m, u: b.u, o: b.o, quelle: j ? j.quelle + (j.stand ? ' (' + j.stand + ')' : '') : MV25.quelle + ' – ' + MV25.stand, jarvis: !!j, url: j ? j.url : MV25.url, cbre: b.m };
    }
    if(lage.plz && MV25_PLZ[lage.plz]) r.plz = { plz: lage.plz, m: MV25_PLZ[lage.plz], quelle: MV25.quelle + ' – ' + MV25.stand };
    r.angebot = r.plz ? { m: r.plz.m, ebene: 'PLZ ' + r.plz.plz } : r.bezirk ? { m: r.bezirk.m, ebene: 'Bezirk ' + r.bezirk.name } : { m: MV25.berlin.m, ebene: 'Berlin gesamt' };
    if(!r.bezirk) r.hinweise.push('Bezirk nicht erkannt – bitte PLZ im Ort eintragen (z. B. „10365 Berlin“).');
  } else if(lage.land === 'BB'){
    const g = MV25_BB[lage.gid] || {}; const j = mv25Jarvis(lage.gid);
    const m = j ? j.m : mv25N(g.miete);
    if(m) r.angebot = { m, ebene: 'Gemeinde ' + (g.name || ''), quelle: j ? j.quelle + (j.stand ? ' (' + j.stand + ')' : '') : (g.quelle || 'Jarvis-Marktdaten') + (g.stand ? ' (' + g.stand + ')' : '') };
    else r.hinweise.push('Für diese Gemeinde liegt noch keine Angebotsmiete vor – über Jarvis („Gebiete auffrischen“, Umland) ergänzen.');
  } else r.hinweise.push('Lage nicht erkannt – Vergleich nur für Berlin und das Berliner Umland.');
  return r;
}
function mv25Stufe(abw){
  if(abw == null || !isFinite(abw)) return { k: '', t: '–' };
  if(abw <= -25) return { k: 'weit-unter', t: 'weit unter dem Schnitt' };
  if(abw <= -10) return { k: 'unter', t: 'unter dem Schnitt' };
  if(abw < 10) return { k: 'mittel', t: 'im Schnitt' };
  if(abw < 25) return { k: 'ueber', t: 'über dem Schnitt' };
  return { k: 'weit-ueber', t: 'weit über dem Schnitt' };
}
function mv25Abw(ist, ref){ return ist != null && ref ? (ist / ref - 1) * 100 : null; }
// Mietspiegel 2026: nur Berlin, nur Wohnungen in Mehrfamilienhäusern
function mv25Mietspiegel(a, lage){
  if(lage.land !== 'BE') return { fehler: 'Der Berliner Mietspiegel gilt nur in Berlin.' };
  if(typeof MR === 'undefined' || !MR.vergleichsmiete) return { fehler: 'Mietrechner nicht geladen.' };
  if(/haus|efh|zfh|reihen|doppel/i.test(String(a.objektart || '')) && !/mehrfamil|mfh/i.test(String(a.objektart || ''))) return { fehler: 'Ein- und Zweifamilienhäuser fallen nicht unter den Mietspiegel.' };
  if(!a.flaeche) return { fehler: 'Wohnfläche fehlt.' };
  if(!a.baujahr) return { fehler: 'Baujahr fehlt – ohne Baujahr keine Einordnung.' };
  const ort = [lage.plz, 'Berlin', lage.bezirk || ''].filter(Boolean).join(' ');
  const je = {};
  for(const wl of ['einfach', 'mittel', 'gut']){
    try{ const v = MR.vergleichsmiete({ flaeche: a.flaeche, baujahr: a.baujahr, ort, wohnlage: wl, merkmale: {} }); je[wl] = { qm: v.qm, u: v.feld.u, o: v.feld.o, feld: v.feld.zeile || v.feld.nr || '' }; }catch(e){ je[wl] = { fehler: e.message }; }
  }
  const wl = a.wohnlage && je[a.wohnlage] && !je[a.wohnlage].fehler ? a.wohnlage : null;
  const ok = Object.values(je).filter(x => !x.fehler);
  if(!ok.length) return { fehler: (je.mittel && je.mittel.fehler) || 'Keine Einordnung möglich.' };
  return { je, wl, qm: wl ? je[wl].qm : null, von: Math.min(...ok.map(x => x.qm)), bis: Math.max(...ok.map(x => x.qm)), u: wl ? je[wl].u : null, o: wl ? je[wl].o : null };
}
function mv25Rechnen(a){
  const lage = mv25Lage(a.ort, a.adresse);
  const ref = mv25Referenz(lage);
  const fl = mv25N(a.flaeche), miete = mv25N(a.miete), pot = mv25N(a.potenzialMiete);
  const qm = miete != null && fl ? miete / fl : null, potQm = pot != null && fl ? pot / fl : null;
  const r = { lage, ref, fl, miete, qm, potQm, hinweise: ref.hinweise.slice() };
  if(ref.angebot){ r.abwAngebot = mv25Abw(qm, ref.angebot.m); r.stufe = mv25Stufe(r.abwAngebot); }
  if(ref.bezirk) r.abwBezirk = mv25Abw(qm, ref.bezirk.m);
  r.ms = mv25Mietspiegel({ flaeche: fl, baujahr: mv25N(a.baujahr), objektart: a.objektart, wohnlage: a.wohnlage }, lage);
  if(r.ms && !r.ms.fehler && qm != null){
    const ovm = r.ms.qm != null ? r.ms.qm : (r.ms.von + r.ms.bis) / 2;
    r.abwMs = mv25Abw(qm, ovm);
    if(qm < ovm){
      const ziel = Math.min(ovm, qm * 1.15);
      r.potenzial558 = { ziel, mehrMonat: (ziel - qm) * fl, mehrJahr: (ziel - qm) * fl * 12, kappungGreift: qm * 1.15 < ovm, ovm, unsicher: r.ms.qm == null };
    }
    r.bremse = { grenze: ovm * 1.10, ueber: qm > ovm * 1.10 };
    if(potQm != null) r.potenzialBremse = { grenze: ovm * 1.10, ueber: potQm > ovm * 1.10 };
  }
  return r;
}
function mv25Chip(r){
  if(!r || r.qm == null || !r.stufe || !r.stufe.k) return '';
  return `<span class="mv25-chip mv25-${r.stufe.k}" title="Ist-Miete ${mv25Z(r.qm)} €/m² gegenüber Angebotsmiete ${mv25Z(r.ref.angebot.m)} €/m² (${mv25Esc(r.ref.angebot.ebene)})">${r.abwAngebot > 0 ? '+' : ''}${mv25Z(r.abwAngebot, 0)} % · ${r.stufe.t}</span>`;
}
function mv25Balken(ist, punkte){
  // einfache Skala: Punkte {l, v} + Ist-Markierung
  const werte = punkte.map(p => p.v).concat(ist != null ? [ist] : []).filter(v => v != null && isFinite(v));
  if(werte.length < 2) return '';
  const min = Math.max(0, Math.min(...werte) * 0.85), max = Math.max(...werte) * 1.08;
  const pos = v => ((v - min) / (max - min) * 100).toFixed(1) + '%';
  return `<div class="mv25-skala">${punkte.filter(p => p.v != null).map(p => `<span class="mv25-pkt" style="left:${pos(p.v)}" title="${mv25Esc(p.l)}: ${mv25Z(p.v)} €/m²"><i></i><em>${mv25Esc(p.k || p.l)}</em></span>`).join('')}${ist != null ? `<span class="mv25-ist" style="left:${pos(ist)}" title="Ist-Miete ${mv25Z(ist)} €/m²"><i></i><em>Ist ${mv25Z(ist)}</em></span>` : ''}</div>`;
}
function mv25KarteHtml(r, ctx){
  ctx = ctx || {};
  const z = (l, v, extra) => `<tr><td>${l}</td><td>${v}${extra ? ' <span class="mc24-muted">' + extra + '</span>' : ''}</td></tr>`;
  const ref = r.ref, ms = r.ms || {};
  const rows = [];
  rows.push(z('Ist-Nettokaltmiete', r.qm != null ? `<b>${mv25Z(r.qm)} €/m²</b>` : '<span class="mc24-muted">fehlt</span>', r.miete != null ? mv25Z(r.miete, 0) + ' €/Monat' + (r.fl ? ' · ' + mv25Z(r.fl, 0) + ' m²' : '') : (ctx.fehltText || '')));
  if(ref.plz) rows.push(z('Angebotsmiete PLZ ' + ref.plz.plz, mv25Z(ref.plz.m) + ' €/m²', r.qm != null ? (r.qm >= ref.plz.m ? '+' : '') + mv25Z(mv25Abw(r.qm, ref.plz.m), 0) + ' %' : ''));
  if(ref.bezirk) rows.push(z('Angebotsmiete Bezirk ' + mv25Esc(ref.bezirk.name), mv25Z(ref.bezirk.m) + ' €/m²', (r.abwBezirk != null ? (r.abwBezirk >= 0 ? '+' : '') + mv25Z(r.abwBezirk, 0) + ' % · ' : '') + 'günstigstes Zehntel bis ' + mv25Z(ref.bezirk.u) + ' €/m², teuerstes ab ' + mv25Z(ref.bezirk.o) + ' €/m²'));
  else if(ref.angebot && r.lage.land === 'BB') rows.push(z('Angebotsmiete ' + mv25Esc(ref.angebot.ebene), mv25Z(ref.angebot.m) + ' €/m²', r.qm != null ? (r.abwAngebot >= 0 ? '+' : '') + mv25Z(r.abwAngebot, 0) + ' %' : ''));
  if(r.lage.land === 'BE'){
    if(ms.fehler) rows.push(z('Mietspiegel 2026', '<span class="mc24-muted">' + mv25Esc(ms.fehler) + '</span>'));
    else{
      const wlSel = ctx.objektId ? `<select class="mv25-wl" onchange="mv25WohnlageSetzen('${ctx.objektId}', this.value)"><option value="">Wohnlage?</option>${['einfach', 'mittel', 'gut'].map(w => `<option value="${w}" ${ms.wl === w ? 'selected' : ''}>${w}</option>`).join('')}</select> <button class="tiny secondary" onclick="mv25WohnlageAuto('${ctx.objektId}')" title="Wohnlage über das Berliner Straßenverzeichnis (Geodienst) ermitteln">🛰️ ermitteln</button>` : '';
      const wert = ms.qm != null ? `<b>${mv25Z(ms.qm)} €/m²</b> <span class="mc24-muted">(Spanne ${mv25Z(ms.u)}–${mv25Z(ms.o)}, Wohnlage ${ms.wl})</span>` : `${mv25Z(ms.von)}–${mv25Z(ms.bis)} €/m² <span class="mc24-muted">je nach Wohnlage</span>`;
      rows.push(z('Vergleichsmiete Mietspiegel 2026', wert + (r.abwMs != null ? ` · Ist ${r.abwMs >= 0 ? '+' : ''}${mv25Z(r.abwMs, 0)} %` : '') + (wlSel ? '<div style="margin-top:4px;">' + wlSel + '</div>' : '')));
    }
    rows.push(z('Berlin zum Vergleich', 'Angebote ' + mv25Z(MV25.berlin.m) + ' €/m²', 'Bestand laut Mietspiegel 2026 (Median aller Mieten): ' + mv25Z(MV25.mietspiegel.median) + ' €/m²'));
  }
  const fazit = [];
  if(r.qm != null && r.stufe && r.stufe.k){
    fazit.push(`<b>Gegenüber Neuvermietungen ${r.stufe.t}</b> (${r.abwAngebot >= 0 ? '+' : ''}${mv25Z(r.abwAngebot, 0)} % zu ${mv25Esc(ref.angebot.ebene)}). Laufende Mieten liegen fast immer unter den Angebotsmieten – entscheidend für die Bewertung ist der Mietspiegel.`);
  }
  if(r.potenzial558){
    const p = r.potenzial558;
    fazit.push(`<b>Erhöhung bis zur Vergleichsmiete möglich</b> (§ 558 BGB): auf ${mv25Z(p.ziel)} €/m² = <b>+${mv25Z(p.mehrMonat, 0)} €/Monat</b> (${mv25Z(p.mehrJahr, 0)} €/Jahr)${p.kappungGreift ? ' – begrenzt durch die Kappungsgrenze 15 % in 3 Jahren (Berlin bis ' + MV25.kappungBis + '), der Rest später' : ''}${p.unsicher ? '. Ohne Wohnlage gerechnet mit der Mitte der Spanne' : ''}. Voraussetzung: Miete seit 15 Monaten unverändert; Kappung bezieht sich auf die Miete vor 3 Jahren.`);
  } else if(r.abwMs != null && r.abwMs >= 0) fazit.push('Die Miete liegt bereits auf oder über der Vergleichsmiete – eine Erhöhung nach § 558 ist derzeit nicht möglich.');
  if(r.bremse && r.bremse.ueber) fazit.push(`Bei einer späteren Neuvermietung gilt die Mietpreisbremse: höchstens ${mv25Z(r.bremse.grenze)} €/m² (Vergleichsmiete + 10 %), außer bei Ausnahmen (höhere Vormiete, Erstbezug nach 01.10.2014, umfassende Modernisierung).`);
  if(r.potenzialBremse && r.potenzialBremse.ueber) fazit.push(`<span class="mc24-rot">Die Potenzialmiete (${mv25Z(r.potQm)} €/m²) liegt über der Mietpreisbremse (${mv25Z(r.potenzialBremse.grenze)} €/m²)</span> – nur mit belegter Ausnahme ansetzen.`);
  const skala = mv25Balken(r.qm, [
    r.ms && !r.ms.fehler ? { l: 'Mietspiegel', k: 'Mietspiegel', v: r.ms.qm != null ? r.ms.qm : (r.ms.von + r.ms.bis) / 2 } : null,
    ref.bezirk ? { l: 'Bezirk ' + ref.bezirk.name + ' (Angebote)', k: 'Bezirk', v: ref.bezirk.m } : null,
    ref.plz ? { l: 'PLZ ' + ref.plz.plz + ' (Angebote)', k: 'PLZ', v: ref.plz.m } : null,
    !ref.bezirk && ref.angebot ? { l: ref.angebot.ebene, k: 'Angebote', v: ref.angebot.m } : null
  ].filter(Boolean));
  const quelle = r.lage.land === 'BE' ? `Angebotsmieten: ${ref.bezirk && ref.bezirk.jarvis ? mv25Esc(ref.bezirk.quelle) + ' (über Jarvis aktualisiert), sonst ' : ''}<a href="${MV25.url}" target="_blank" rel="noopener">${MV25.quelle}</a>, ${MV25.stand}, Median nettokalt · Mietspiegel: <a href="${MV25.mietspiegel.url}" target="_blank" rel="noopener">${MV25.mietspiegel.name}</a>` : (ref.angebot && ref.angebot.quelle ? 'Angebotsmiete: ' + mv25Esc(ref.angebot.quelle) : '');
  return `<div class="mc24-karte mv25-karte"><h3>🏷️ Mietvergleich ${mv25Chip(r)}<span class="sp"></span><button class="tiny secondary" onclick="mv25Aktualisieren()" title="Aktuellere Bezirksmieten per KI-Prompt holen (Jarvis → Gebiete auffrischen)">↻ Werte aktualisieren</button></h3>
    ${skala}
    <table class="mc24-tab kv">${rows.join('')}</table>
    ${fazit.length ? `<ul class="mv25-fazit">${fazit.map(f => '<li>' + f + '</li>').join('')}</ul>` : ''}
    ${r.hinweise.length ? `<div class="mc24-muted">${r.hinweise.map(mv25Esc).join(' ')}</div>` : ''}
    <div class="mc24-muted mv25-quelle">${quelle}. Rechenhilfe, keine Rechtsberatung.</div></div>`;
}
// ── Einbindung: Objektakte ──
function mv25AusObjekt(o){
  const w = k => (typeof an24Wert === 'function' ? an24Wert(o, k) : o[k]);
  return { miete: w('miete_ist'), flaeche: w('wohnflaeche') || o.wohnflaeche, baujahr: w('baujahr') || o.baujahr, objektart: o.objektart, ort: o.ort, adresse: o.adresse, wohnlage: (o.mv25 || {}).wohnlage || '', vermietung: w('vermietung') };
}
function mv25AkteKarte(o){
  try{
    const a = mv25AusObjekt(o);
    const vermietet = /vermietet/.test(String(a.vermietung || '')) || a.miete != null;
    if(!vermietet || !/wohnung|mehrfamil|mfh|haus|etw/i.test(String(o.objektart || 'Wohnung'))) return '';
    return mv25KarteHtml(mv25Rechnen(a), { objektId: o.id, fehltText: 'Ist-Miete in der Akte unter „Angaben“ eintragen' });
  }catch(e){ console.error('mv25 akte', e); return ''; }
}
if(typeof MC24 !== 'undefined' && MC24.akte && Array.isArray(MC24.akte.abschnitte)) MC24.akte.abschnitte.push(o => mv25AkteKarte(o));
// ── Einbindung: Investments ──
if(typeof iv24DetailHtml === 'function'){
  const _mv25IvDetail = iv24DetailHtml;
  iv24DetailHtml = function(p){
    const h = _mv25IvDetail.apply(this, arguments);
    try{
      const o = findObjekt(p.objektId); const e = p.e || {};
      if(!o) return h;
      const a = mv25AusObjekt(o); a.miete = e.miete; a.flaeche = e.wohnflaeche || a.flaeche; a.potenzialMiete = e.potenzial && e.potenzial.miete;
      if(a.miete == null && a.potenzialMiete == null && !/vermietet/.test(String(a.vermietung || ''))) return h;
      return h + mv25KarteHtml(mv25Rechnen(a), { objektId: o.id });
    }catch(err){ console.error('mv25 invest', err); return h; }
  };
}
function mv25WohnlageSetzen(oid, wl){ const o = findObjekt(oid); if(!o) return; o.mv25 = Object.assign({}, o.mv25 || {}, { wohnlage: wl, quelle: wl ? 'von Hand' : '' }); save(); renderMain(); }
// Wohnlage über Nominatim + Geodienst Berlin (Straßenverzeichnis 2026, Ersatz 2024) – wie im Mietrechner
function mv25Utm33(lat, lon){
  const a = 6378137, f = 1 / 298.257222101, k0 = 0.9996, lon0 = 15 * Math.PI / 180, e2 = f * (2 - f), ep2 = e2 / (1 - e2);
  const phi = lat * Math.PI / 180, lam = lon * Math.PI / 180;
  const N = a / Math.sqrt(1 - e2 * Math.sin(phi) ** 2), T = Math.tan(phi) ** 2, C = ep2 * Math.cos(phi) ** 2, A = Math.cos(phi) * (lam - lon0);
  const M = a * ((1 - e2 / 4 - 3 * e2 * e2 / 64 - 5 * e2 ** 3 / 256) * phi - (3 * e2 / 8 + 3 * e2 * e2 / 32 + 45 * e2 ** 3 / 1024) * Math.sin(2 * phi) + (15 * e2 * e2 / 256 + 45 * e2 ** 3 / 1024) * Math.sin(4 * phi) - (35 * e2 ** 3 / 3072) * Math.sin(6 * phi));
  return [k0 * N * (A + (1 - T + C) * A ** 3 / 6 + (5 - 18 * T + T * T + 72 * C - 58 * ep2) * A ** 5 / 120) + 500000,
    k0 * (M + N * Math.tan(phi) * (A * A / 2 + (5 - T + 9 * C + 4 * C * C) * A ** 4 / 24 + (61 - 58 * T + T * T + 600 * C - 330 * ep2) * A ** 6 / 720))];
}
async function mv25Text(url){ const r = window.pc && window.pc.abruf ? await window.pc.abruf(url) : null; if(!r || !r.ok) throw new Error(r && r.fehler ? r.fehler : 'HTTP ' + (r && r.status)); return r.text; }
function mv25LageAus(p){
  for(const [k, v] of Object.entries(p || {})){ if(!/^(wol|wohnlage|lage|wl)$/i.test(k) && !/wohnlage/i.test(k)) continue; const t = String(v || '').toLowerCase().trim();
    if(/^e$|einf/.test(t)) return 'einfach'; if(/^m$|mittl|mittel/.test(t)) return 'mittel'; if(/^g$|gut/.test(t)) return 'gut'; }
  return null;
}
async function mv25WohnlageAuto(oid){
  const o = findObjekt(oid); if(!o) return;
  if(!o.adresse || !/\d/.test(o.adresse)){ akqToast('Für die Wohnlage braucht es Straße und Hausnummer in der Adresse'); return; }
  akqToast('🛰️ Suche Wohnlage …', 6000);
  try{
    const q = [o.adresse, o.ort].filter(Boolean).join(', ');
    const j = JSON.parse(await mv25Text('https://nominatim.openstreetmap.org/search?format=jsonv2&limit=1&countrycodes=de&addressdetails=1&accept-language=de&q=' + encodeURIComponent(/berlin|\b1\d{4}\b/i.test(q) ? q : q + ', Berlin')));
    if(!Array.isArray(j) || !j.length) throw new Error('Adresse nicht gefunden');
    if(!/berlin/i.test((j[0].address || {}).state || '')) throw new Error('Adresse liegt nicht in Berlin');
    const [x, y] = mv25Utm33(+j[0].lat, +j[0].lon); const hnr = (String(o.adresse).match(/(\d+\s*[a-z]?)\s*$/i) || [])[1];
    let fehler = '';
    for(const jahr of [2026, 2024]){
      try{
        const basis = `https://gdi.berlin.de/services/wfs/wohnlagenadr${jahr}`; let typ = `wohnlagenadr${jahr}:wohnlagenadr${jahr}`;
        try{ const cap = await mv25Text(basis + '?SERVICE=WFS&REQUEST=GetCapabilities&VERSION=2.0.0'); const m = /<(?:wfs:)?FeatureType[^>]*>[\s\S]*?<(?:wfs:)?Name>([^<]+)<\/(?:wfs:)?Name>/i.exec(cap); if(m) typ = m[1].trim(); }catch(e){}
        const d = 40; const url = `${basis}?SERVICE=WFS&VERSION=2.0.0&REQUEST=GetFeature&TYPENAMES=${encodeURIComponent(typ)}&OUTPUTFORMAT=application/json&COUNT=50&BBOX=${(x - d).toFixed(1)},${(y - d).toFixed(1)},${(x + d).toFixed(1)},${(y + d).toFixed(1)},urn:ogc:def:crs:EPSG::25833`;
        const fj = JSON.parse(await mv25Text(url)); const fs = (fj.features || []).filter(f => f && f.properties && mv25LageAus(f.properties));
        if(!fs.length){ fehler = 'keine Adresse in der Nähe gefunden'; continue; }
        const dist = f => { const c = f.geometry && f.geometry.coordinates; return Array.isArray(c) && typeof c[0] === 'number' ? Math.hypot(c[0] - x, c[1] - y) : 999; };
        const passend = hnr ? fs.filter(f => String(f.properties.hnr || f.properties.hausnummer || '').replace(/\s/g, '').toLowerCase() === hnr.replace(/\s/g, '').toLowerCase()) : [];
        const best = (passend.length ? passend : fs).sort((a, b) => dist(a) - dist(b))[0];
        const lage = mv25LageAus(best.properties);
        o.mv25 = Object.assign({}, o.mv25 || {}, { wohnlage: lage, quelle: (jahr === 2026 ? 'Straßenverzeichnis 2026' : 'Wohnlagen 2024 – für 2026 prüfen') + (passend.length ? '' : ' (Hausnr. nicht exakt)') });
        save(); renderMain(); akqToast(`Wohnlage ${lage} übernommen (${jahr})`); return;
      }catch(e){ fehler = e.message; }
    }
    throw new Error(fehler || 'nicht gefunden');
  }catch(e){ akqToast('Wohnlage nicht gefunden (' + e.message + ') – bitte von Hand wählen', 5500); }
}
function mv25Aktualisieren(){
  mc24Modal(`<h3>Bezirksmieten aktualisieren</h3>
    <p>Die eingebauten Werte stammen aus dem <a href="${MV25.url}" target="_blank" rel="noopener">${MV25.quelle}</a> (${MV25.stand}). Neuere Werte holst du über Jarvis:</p>
    <ol><li>Jarvis öffnen → <b>Prompts</b> → <b>„Kaufpreise und Mieten je Bezirk auffrischen“</b> kopieren.</li><li>In deine KI einfügen (z. B. Claude mit Websuche).</li><li>Die Antwort in Jarvis unter <b>Import</b> einfügen.</li></ol>
    <p class="mc24-muted">Danach nutzt der Mietvergleich automatisch die neuen Angebotsmieten (mit Quelle und Stand). Die PLZ-Werte und der Mietspiegel bleiben wie eingebaut.</p>
    <div class="modal-actions"><span></span><div class="right"><button class="secondary" onclick="schliesseModal()">Schließen</button><button onclick="schliesseModal(); wechsleAnsicht('jarvis')">Jarvis öffnen</button></div></div>`, 560);
}
