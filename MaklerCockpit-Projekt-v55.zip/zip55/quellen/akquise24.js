/* MaklerCockpit v24 – Akquise-Erweiterung (abschaltbar unter ⚙ → Module)
   Gesprächsbriefing · Verkäufermotivation · Prioritäten „Heute“ · Einwände & Gesprächshilfen · Kooperationsakte Hausverwaltung · Gesprächsabschluss
   Nutzt vorhandene Kontakte, Aufgaben, Termine und Notizen – keine Parallelverwaltung. Daten bleiben beim Ausschalten erhalten. */

function ak24An(){ return typeof mc24ModulAn === 'function' ? mc24ModulAn('akquise24') : true; }
function ak24Db(){
  if(!db.ak24 || typeof db.ak24 !== 'object') db.ak24 = {};
  const a = db.ak24;
  if(!a.regeln) a.regeln = JSON.parse(JSON.stringify(AK24_REGELN_STD));
  for(const k of Object.keys(AK24_REGELN_STD)) if(!a.regeln[k]) a.regeln[k] = JSON.parse(JSON.stringify(AK24_REGELN_STD[k]));
  if(!a.hilfen) a.hilfen = {};
  if(!a.prio) a.prio = {};
  return a;
}
const AK24_REGELN_STD = {
  rueckruf: { an: true, l: 'Vereinbarter Rückruf heute oder überfällig' },
  termin: { an: true, l: 'Eigentümertermin steht bevor – Briefing oder Analyse fehlt', tage: 3, analyseTage: 180 },
  zusage: { an: true, l: 'Kontakt hat Antwort oder Unterlage zugesagt (Termin erreicht)' },
  nachfassen: { an: true, l: 'Nachfass- oder Klärungsaufgabe fällig' },
  blockiert: { an: true, l: 'Offene Frage blockiert den nächsten Schritt' },
  koop: { an: true, l: 'Kooperation: vereinbarter nächster Schritt fällig' }
};
const AK24_EINWAND = [['privatverkauf', 'Privatverkauf gewünscht'], ['provision', 'Provision zu hoch'], ['maklerkontakt', 'Bereits Maklerkontakt'], ['preis', 'Preisvorstellung weicht ab'], ['spaeter', 'Verkauf erst später'], ['sonstiges', 'Sonstiges']];
const AK24_EINWAND_STATUS = [['offen', 'offen'], ['besprochen', 'besprochen'], ['ausgeraeumt', 'ausgeräumt'], ['besteht', 'besteht weiter']];
const AK24_HILFEN_STD = {
  privatverkauf: 'Verständlich – viele Eigentümer starten zunächst privat. Darf ich fragen, was Ihnen dabei am wichtigsten ist: Preis, Tempo oder wenig Aufwand? Ich zeige Ihnen gern, welche Aufgaben ich übernehmen würde (Unterlagen, Besichtigungen, Prüfung der Interessenten) – Sie entscheiden danach in Ruhe.',
  provision: 'Die Kosten sind ein berechtigter Punkt. Lassen Sie uns konkret durchgehen, welche Leistungen enthalten sind und wie sich die Provision zwischen Käufer und Verkäufer aufteilt. Danach können Sie selbst einschätzen, ob es sich für Sie lohnt.',
  maklerkontakt: 'Danke für die Offenheit. Wenn ein Auftrag besteht, respektiere ich das selbstverständlich. Darf ich mich zu einem späteren Zeitpunkt noch einmal melden, falls sich etwas ändert?',
  preis: 'Ihre Preisvorstellung habe ich notiert. Ich bereite gern eine Übersicht vergleichbarer Angebote mit Quellen vor, damit wir die Einschätzung auf nachvollziehbare Daten stützen können – ohne dass Sie sich jetzt festlegen müssen.',
  spaeter: 'Kein Problem. Wann wäre ein guter Zeitpunkt, wieder zu sprechen? Bis dahin kann ich Ihnen eine Markteinschätzung vorbereiten, damit Sie eine Grundlage für Ihre Planung haben.',
  sonstiges: 'Danke für den Hinweis. Was müsste aus Ihrer Sicht geklärt sein, damit wir weitersprechen können?'
};
function ak24Hilfe(kat){ const h = ak24Db().hilfen; return h[kat] != null ? h[kat] : (AK24_HILFEN_STD[kat] || ''); }
const AK24_MOTIV = [
  ['verkaufsgrund', 'Verkaufsgrund'], ['zeitraum', 'Gewünschter Verkaufszeitraum'], ['vermarktung', 'Bisherige Vermarktung'], ['erwartungen', 'Erwartungen an den Makler'],
  ['preisvorstellung', 'Preisvorstellung'], ['verhandlung', 'Erklärte Verhandlungsbereitschaft'], ['entscheider', 'Entscheidungsträger'], ['maklerbindung', 'Bestehende Maklerbindung (soweit mitgeteilt)']
];
const AK24_ERGEBNIS = [['interesse', 'Erreicht – Interesse'], ['termin', 'Erreicht – Termin vereinbart'], ['spaeter', 'Erreicht – später wieder melden'], ['kein_interesse', 'Erreicht – kein Interesse'], ['nicht_erreicht', 'Nicht erreicht'], ['kontaktstopp', 'Kontaktstopp gewünscht'], ['abgeschlossen', 'Abgeschlossen / erledigt']];
const AK24_SCHRITT = [['keiner', 'Kein weiterer Schritt'], ['rueckruf', '📞 Rückruf'], ['telefontermin', '📞 Telefontermin'], ['vorort', '📍 Termin vor Ort'], ['unterlagen', 'Unterlagen senden'], ['zusage', 'Zusage des Kontakts abwarten'], ['aufgabe', 'Sonstige Aufgabe']];
const AK24_KOOP_STATUS = [['recherchiert', 'recherchiert'], ['kontakt_offen', 'Kontakt offen'], ['gesprochen', 'gesprochen'], ['interesse', 'Interesse'], ['konkreter_fall', 'konkreter Fall'], ['aktiv', 'aktive Kooperation'], ['kein_bedarf', 'aktuell kein Bedarf'], ['kontaktstopp', 'Kontaktstopp']];
const AK24_HV_STATUS = { offen: 'recherchiert', nicht_erreicht: 'kontakt_offen', rueckruf: 'gesprochen', interesse: 'interesse', termin: 'interesse', kooperation: 'aktiv', absage: 'kein_bedarf' };
function ak24L(l, k){ return an24L(l, k); }

// ── Gesprächsdaten (vorhandene Notizen) ──
function ak24Gespraeche(filter){ return (db.notizen || []).filter(n => n.typ === 'gespraech' && (!filter.objektId || n.objektId === filter.objektId) && (!filter.kontaktIds || filter.kontaktIds.includes(n.kontaktId))).sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0)); }
function ak24KontaktIdsVonObjekt(o){ return [...new Set([o.eigentuemerId].concat((o.kontakte || []).map(x => x.kontaktId)).filter(Boolean))]; }
function ak24Einwaende(k){ return (k && k.einwaende) || []; }
function ak24EinwaendeObjekt(o){ return ak24KontaktIdsVonObjekt(o).flatMap(id => ak24Einwaende(findKontakt(id)).map(e => Object.assign({ kontaktId: id }, e))).filter(e => !e.objektId || e.objektId === o.id); }

// ── 4.1 Gesprächsbriefing (ohne KI aus gespeicherten Daten) ──
function ak24BriefingDaten(ziel){
  let o = ziel.objektId ? findObjekt(ziel.objektId) : null, k = ziel.kontaktId ? findKontakt(ziel.kontaktId) : null;
  const t = ziel.terminId ? (db.termine || []).find(x => x.id === ziel.terminId) : null;
  if(t){ if(!o && t.objektId) o = findObjekt(t.objektId); if(!k && t.kontaktId) k = findKontakt(t.kontaktId); }
  if(!o && k){ const ob = ob24ObjekteVonKontakt(k.id); if(ob.length === 1) o = ob[0]; }
  if(o && !k) k = ob24Hauptkontakt(o, false);
  const org = k && (k.organisation ? k : (k.orgId ? findKontakt(k.orgId) : null));
  const kontaktIds = o ? ak24KontaktIdsVonObjekt(o) : [k && k.id, ...(org ? [org.id].concat(mc24Ansprechpartner(org.id).map(x => x.id)) : [])].filter(Boolean);
  const gespr = ak24Gespraeche(o ? { objektId: o.id } : { kontaktIds });
  const gesprK = o ? [] : [];
  const aufg = (db.aufgaben || []).filter(a => a.status !== 'erledigt' && ((o && a.objektId === o.id) || (!o && kontaktIds.includes(a.kontaktId))));
  const m = (o && o.motivation) || {};
  const einw = o ? ak24EinwaendeObjekt(o) : kontaktIds.flatMap(id => ak24Einwaende(findKontakt(id)).map(e => Object.assign({ kontaktId: id }, e)));
  const analyse = o ? (db.analysen24 || []).filter(a => a.objektId === o.id && a.status === 'abgeschlossen').sort((a, b) => (b.abgeschlossenAm || b.erstellt || 0) - (a.abgeschlossenAm || a.erstellt || 0))[0] : null;
  const naechsterTermin = o ? ob24NaechsterTermin(o) : (db.termine || []).filter(x => kontaktIds.includes(x.kontaktId) && x.datum >= mc24Heute()).sort((a, b) => (a.datum + (a.uhrzeit || '')).localeCompare(b.datum + (b.uhrzeit || '')))[0];
  const fragen = ((m.offeneFragen || []).filter(f => !f.erledigt).map(f => f.text + (f.blockiert ? ' (blockiert nächsten Schritt)' : '')))
    .concat(o ? an24Konflikte(o).map(x => `${x.feld.l}: widersprüchliche Angaben (${x.werte.map(w => an24Wtext(x.feld, w.wert)).join(' / ')})`) : [])
    .concat(o ? ['wohnflaeche', 'baujahr', 'zustand'].filter(kk => an24Wert(o, kk) == null).map(kk => an24Feld(kk).l + ' unbekannt') : []);
  return { o, k, org, t, gespr, gesprK, aufg, m, einw: einw.filter(e => e.status !== 'ausgeraeumt'), analyse, naechsterTermin, fragen, kontaktIds };
}
function ak24MotivText(m, key){ if((m.unbekannt || {})[key]) return 'unbekannt'; const v = m[key]; return v ? v : null; }
function ak24BriefingHtml(d, druck){
  const { o, k, org } = d, e = mc24E;
  const zeile = (l, w) => w ? `<tr><th>${e(l)}</th><td>${w}</td></tr>` : '';
  const kern = o ? ['wohnflaeche', 'zimmer', 'grundstueck', 'baujahr', 'zustand'].map(kk => { const f = an24Feld(kk), w = an24Wert(o, kk), a = an24Aktiv(o, kk); return w == null ? '' : `${e(f.l)} ${e(an24Wtext(f, w))}${a && a.herkunft !== 'belegt' ? ' <small>(' + e(an24L(AN24_HERKUNFT, a.herkunft)) + ')</small>' : ''}`; }).filter(Boolean).join(' · ') : '';
  const preis = o ? an24Wert(o, 'kaufpreis') : null, pa = o ? an24Aktiv(o, 'kaufpreis') : null;
  const kontakte = o ? ob24Kontakte(o) : (k ? [{ k, rolle: k.rolle || '' }] : []);
  const g0 = d.gespr[0];
  const motiv = AK24_MOTIV.map(([kk, l]) => { const v = ak24MotivText(d.m, kk); return v ? zeile(l, e(v)) : ''; }).join('');
  const ar = d.analyse && typeof ma24AnalyseAuswerten === 'function' ? ma24AnalyseAuswerten(d.analyse) : null;
  const koop = org && org.koop ? org.koop : null;
  return `<div class="ak24-brief">
    ${o ? `<h4>Objekt</h4><table class="mc24-tab kv">${zeile('Objekt', e([o.objektart, mc24Titel(o)].filter(Boolean).join(' · ')))}${zeile('Lage', e([o.adresse, o.ort].filter(Boolean).join(', ') || 'unbekannt'))}${zeile('Kerndaten', kern || '<span class="mc24-muted">keine Angaben</span>')}${zeile('Preisvorstellung', preis != null ? e(mc24Eur(preis)) + (pa ? ' <small>(' + e(an24L(AN24_HERKUNFT, pa.herkunft)) + ')</small>' : '') : (ak24MotivText(d.m, 'preisvorstellung') ? e(ak24MotivText(d.m, 'preisvorstellung')) : '<span class="mc24-muted">unbekannt</span>'))}</table>` : ''}
    ${koop ? `<h4>Kooperation ${e(org.name)}</h4><table class="mc24-tab kv">${zeile('Status', e(ak24L(AK24_KOOP_STATUS, koop.status || 'recherchiert')))}${zeile('Verwaltungstyp', e(koop.verwaltungstyp || ''))}${zeile('Gebiete', e(koop.gebiete || ''))}${zeile('Bisherige Vermietungslösung', e(koop.vermietungsloesung || ''))}${zeile('Eigene Vermietungsabteilung', e(koop.eigeneVermietung || 'unbekannt'))}${zeile('Kooperationsbedarf', e(koop.bedarf || ''))}${zeile('Vereinbarungen', e(koop.vereinbarungen || ''))}${zeile('Anlass für Kontakt', e(koop.anlass || ''))}</table>` : ''}
    <h4>Ansprechpartner</h4>${kontakte.length ? kontakte.map(x => `<div>${x.k.organisation ? '🏢' : '👤'} <b>${e(x.k.name)}</b> ${x.rolle ? '<span class="mc24-muted">' + e(an24L(MC24_ROLLEN, x.rolle)) + '</span>' : ''}${druck ? '' : ' ' + e([x.k.telefon, x.k.email].filter(Boolean).join(' · '))}${mc24Kontaktstopp(x.k) ? ' <span class="mc24-stopp">Kontaktstopp</span>' : ''}</div>`).join('') : '<div class="mc24-muted">keine Kontakte verknüpft</div>'}
    ${ak24MotivText(d.m, 'entscheider') ? `<div>Weitere Entscheidungsträger: ${e(ak24MotivText(d.m, 'entscheider'))}</div>` : ''}
    <h4>Letztes Gespräch und Vereinbarungen</h4>${g0 ? `<div><b>${mc24Datum(g0.datum || g0.createdAt)}</b> – ${e(ak24L(AK24_ERGEBNIS, g0.ergebnis))}${g0.ergebnisText ? ': ' + e(g0.ergebnisText) : ''}${g0.naechsterSchritt ? `<br>Vereinbart: ${e(g0.naechsterSchritt)}${g0.wann ? ' (' + mc24Datum(g0.wann) + ')' : ''}` : ''}${g0.gespraechsnotiz ? `<div class="mc24-muted">Notiz: ${e(String(g0.gespraechsnotiz).slice(0, 400))}</div>` : ''}</div>` : '<div class="mc24-muted">noch kein Gespräch dokumentiert</div>'}
    ${d.gespr.slice(1, 3).map(g => `<div class="mc24-muted">${mc24Datum(g.datum || g.createdAt)}: ${e(ak24L(AK24_ERGEBNIS, g.ergebnis))}${g.naechsterSchritt ? ' → ' + e(g.naechsterSchritt) : ''}</div>`).join('')}
    ${d.aufg.length ? `<div><b>Offene Aufgaben:</b> ${d.aufg.map(a => e(a.titel) + (a.faellig ? ' (' + mc24Datum(a.faellig) + ')' : '')).join(' · ')}</div>` : ''}
    ${o ? `<h4>Verkaufsgrund, Zeithorizont, Erwartungen</h4>${motiv ? `<table class="mc24-tab kv">${motiv}${d.m.freitext ? zeile('Notiz', e(d.m.freitext)) : ''}</table>` : '<div class="mc24-muted">noch nichts erfasst – nichts davon annehmen, im Gespräch erfragen</div>'}` : ''}
    ${o ? `<h4>Marktanalyse</h4>${d.analyse ? `<div>Bestätigte Analyse vom ${mc24Datum(d.analyse.abgeschlossenAm || d.analyse.erstellt)}: ${ar && ar.spanne && ar.spanne.von != null ? e(mc24Eur(ar.spanne.von) + ' – ' + mc24Eur(ar.spanne.bis)) + ' (Median ' + e(mc24Eur(ar.spanne.mitte)) + ')' : 'keine belastbare Spanne'} · Datenqualität ${e(ar ? ar.qualitaet.stufe : '–')}</div>` : '<div class="mc24-muted">keine bestätigte Marktanalyse</div>'}` : ''}
    <h4>Offene Fragen</h4>${d.fragen.length ? '<ul>' + d.fragen.map(f => `<li>${e(f)}</li>`).join('') + '</ul>' : '<div class="mc24-muted">keine</div>'}
    <h4>Bekannte Einwände</h4>${d.einw.length ? d.einw.map(x => `<div><b>${e(ak24L(AK24_EINWAND, x.kategorie))}</b>${x.wortlaut ? ': „' + e(x.wortlaut) + '“' : ''} <span class="mc24-muted">(${e(ak24L(AK24_EINWAND_STATUS, x.status))}, ${mc24Datum(x.datum)})</span>${x.reaktion ? `<div class="mc24-muted">Vereinbarte Reaktion: ${e(x.reaktion)}</div>` : ''}${druck ? '' : `<div class="ak24-hilfe">💡 ${e(ak24Hilfe(x.kategorie))}</div>`}</div>`).join('') : '<div class="mc24-muted">keine</div>'}
    <h4>Nächster Schritt</h4>${d.naechsterTermin ? `<div>${typeof twPre === 'function' ? twPre(d.naechsterTermin) : ''}${e(d.naechsterTermin.titel)} – ${gsDatumLang(d.naechsterTermin.datum)} ${e(d.naechsterTermin.uhrzeit || '')}</div>` : (g0 && g0.naechsterSchritt ? `<div>${e(g0.naechsterSchritt)}</div>` : '<div class="mc24-muted">nichts vereinbart</div>')}
  </div>`;
}
function ak24BriefingText(d){
  const div = document.createElement('div'); div.innerHTML = ak24BriefingHtml(d, true);
  div.querySelectorAll('h4').forEach(h => h.textContent = '\n' + h.textContent.toUpperCase());
  div.querySelectorAll('tr').forEach(tr => tr.insertAdjacentText('beforeend', '\n'));
  div.querySelectorAll('th').forEach(th => th.insertAdjacentText('beforeend', ': '));
  div.querySelectorAll('div,li').forEach(x => x.insertAdjacentText('beforeend', '\n'));
  return div.textContent.replace(/\n{3,}/g, '\n\n').trim();
}
let AK24_BRIEF = null;
function ak24Briefing(ziel){
  const d = ak24BriefingDaten(ziel); AK24_BRIEF = { ziel, d };
  if(d.o){ d.o.briefingAm = new Date().toISOString(); save(); }
  if(d.t){ d.t.briefingAm = new Date().toISOString(); save(); }
  const titel = d.o ? mc24Titel(d.o) : (d.org ? d.org.name : d.k ? d.k.name : 'Gespräch');
  const ki = d.o && d.o.briefingKi ? d.o.briefingKi : (d.k && d.k.briefingKi) || null;
  mc24Modal(`<h3>🗒️ Gespräch vorbereiten: ${mc24E(titel)}</h3>
    <div class="mc24-muted">Nur gespeicherte Angaben – nichts ist ergänzt oder vermutet. Intern, nicht zur Weitergabe.</div>
    ${ak24BriefingHtml(d, false)}
    ${ki ? `<h4>KI-Gesprächsvorbereitung (${mc24Datum(ki.am)})</h4><div class="ak24-ki">${mc24E(ki.text).replace(/\n/g, '<br>')}</div>` : ''}
    <details class="gs-details"><summary>Optional: KI formuliert Gesprächsvorbereitung und Rückfragen</summary>
      <div class="mc24-muted">Der Prompt enthält nur die Daten oben – ohne Namen, Telefonnummern und E-Mail-Adressen. Antwort danach hier einfügen.</div>
      <div class="mc24-knoepfe"><button class="tiny" onclick="mc24Kopieren(ak24KiPrompt(AK24_BRIEF.d), '📋 Prompt kopiert – in ChatGPT/Claude einfügen')">📋 Prompt kopieren</button></div>
      <textarea id="ak_ki" rows="4" placeholder="Antwort der KI einfügen …"></textarea><button class="tiny secondary" onclick="ak24KiSpeichern()">Antwort speichern</button></details>
    <div class="modal-actions"><div class="mc24-knoepfe"><button class="secondary" onclick="mc24Kopieren(ak24BriefingText(AK24_BRIEF.d))">📋 Kopieren</button><button class="secondary" onclick="mc24Drucken(ak24BriefingDruck())">🖨️ Drucken</button><button class="secondary" onclick="mc24Pdf(ak24BriefingDruck(), 'Gespraechsbriefing.pdf')">📄 PDF</button></div>
      <div class="right"><button class="secondary" onclick="schliesseModal()">Schließen</button>${d.o || d.k ? `<button onclick="ak24Abschluss(${mc24E(JSON.stringify({ objektId: d.o ? d.o.id : null, kontaktId: d.k ? d.k.id : null, terminId: d.t ? d.t.id : null }))})">✅ Gespräch abschließen</button>` : ''}</div></div>`, 820);
}
function ak24BriefingDruck(){
  const d = AK24_BRIEF.d, titel = d.o ? mc24Titel(d.o) : (d.org ? d.org.name : (d.k ? d.k.name : ''));
  return `<!DOCTYPE html><html lang="de"><head><meta charset="utf-8"><title>Gesprächsbriefing</title><style>@page{size:A4;margin:15mm;}body{font-family:"Segoe UI",Arial,sans-serif;font-size:10.5pt;color:#1d2433;}h3{margin:0 0 4pt;}h4{margin:12pt 0 4pt;border-bottom:1pt solid #ff8a3d;}table{border-collapse:collapse;width:100%;}th,td{text-align:left;padding:2pt 5pt;border-bottom:.5pt solid #e1e6ee;vertical-align:top;}th{width:35%;color:#5b6475;}.mc24-muted{color:#6b7385;}.mc24-stopp{color:#b91c1c;font-weight:700;}small{color:#6b7385;}</style></head><body><h3>Gesprächsbriefing: ${mc24E(titel)}</h3><div class="mc24-muted">Stand ${mc24Datum(mc24Heute())} · intern</div>${ak24BriefingHtml(d, true)}</body></html>`;
}
function ak24KiPrompt(d){
  const o = d.o, m = d.m || {};
  const daten = {
    objekt: o ? { objektart: o.objektart || null, ort: o.ort || null, kerndaten: Object.fromEntries(['wohnflaeche', 'zimmer', 'grundstueck', 'baujahr', 'zustand', 'kaufpreis'].map(k => [k, an24Wert(o, k)])) } : null,
    kooperation: d.org && d.org.koop ? { verwaltungstyp: d.org.koop.verwaltungstyp || null, gebiete: d.org.koop.gebiete || null, status: d.org.koop.status || null, bedarf: d.org.koop.bedarf || null, vereinbarungen: d.org.koop.vereinbarungen || null } : null,
    motivation: Object.fromEntries(AK24_MOTIV.map(([k]) => [k, ak24MotivText(m, k)])),
    letzte_gespraeche: d.gespr.slice(0, 3).map(g => ({ datum: String(g.datum || '').slice(0, 10), ergebnis: ak24L(AK24_ERGEBNIS, g.ergebnis), vereinbart: g.naechsterSchritt || null })),
    offene_fragen: d.fragen, einwaende: d.einw.map(x => ({ art: ak24L(AK24_EINWAND, x.kategorie), wortlaut: x.wortlaut || null, status: x.status })),
    marktanalyse: d.analyse ? { datum: mc24Datum(d.analyse.abgeschlossenAm || d.analyse.erstellt) } : null
  };
  return `Bereite mich (Immobilienmakler Paul Görner, Berlin) kurz auf ein Gespräch vor. Nutze ausschließlich diese gespeicherten Daten – null bedeutet unbekannt:
${JSON.stringify(daten, null, 1)}

Liefere: 1) drei bis fünf Sätze Gesprächsvorbereitung, 2) fünf konkrete Rückfragen zu den Lücken und offenen Punkten, 3) zu jedem bekannten Einwand einen sachlichen Gesprächsvorschlag.
Regeln: Erfinde keine Motive, persönlichen Umstände, Käufer, Interessenten, Erfolge, Vergleichspreise oder Zusagen. Keine psychologische Bewertung. Unbekanntes als Frage formulieren, nicht als Annahme. Kurz, auf Deutsch.`;
}
function ak24KiSpeichern(){
  const t = (document.getElementById('ak_ki').value || '').trim(); if(!t) return;
  const d = AK24_BRIEF.d, ziel = d.o || d.k; if(!ziel) return;
  ziel.briefingKi = { text: t.slice(0, 6000), am: new Date().toISOString() }; save(); ak24Briefing(AK24_BRIEF.ziel);
}

// ── 4.2 Verkäufermotivation ──
function ak24MotivDialog(oid){
  const o = findObjekt(oid); if(!o) return;
  const m = o.motivation || {}, u = m.unbekannt || {};
  mc24Modal(`<h3>Verkäufermotivation: ${mc24E(mc24Titel(o))}</h3>
    <div class="mc24-muted">Nur festhalten, was tatsächlich gesagt wurde. „unbekannt“ = gefragt, aber nicht beantwortet. Keine Vermutungen über persönliche Umstände.</div>
    ${AK24_MOTIV.map(([k, l]) => `<div class="ak24-mf"><label>${l}</label><div class="ak24-mfz"><input id="mo_${k}" value="${mc24E(m[k] || '')}" ${u[k] ? 'disabled' : ''}><label class="gs-chk"><input type="checkbox" id="mo_u_${k}" ${u[k] ? 'checked' : ''} onchange="document.getElementById('mo_${k}').disabled=this.checked"> unbekannt</label></div></div>`).join('')}
    <label>Offene Fragen</label><div id="mo_fragen">${(m.offeneFragen || []).map((f, i) => ak24FrageZeile(f, i)).join('')}</div>
    <button class="tiny secondary" onclick="document.getElementById('mo_fragen').insertAdjacentHTML('beforeend', ak24FrageZeile({}, Date.now()))">+ Frage</button>
    <label>Freitext</label><textarea id="mo_frei" rows="2">${mc24E(m.freitext || '')}</textarea>
    <div class="modal-actions"><div></div><div class="right"><button class="secondary" onclick="schliesseModal()">Abbrechen</button><button onclick="ak24MotivSpeichern('${oid}')">Speichern</button></div></div>`, 720);
}
function ak24FrageZeile(f, i){ return `<div class="ak24-frage" data-id="${mc24E(f.id || '')}"><input class="fr_t" value="${mc24E(f.text || '')}" placeholder="z. B. Gibt es weitere Erben, die zustimmen müssen?"><label class="gs-chk"><input type="checkbox" class="fr_b" ${f.blockiert ? 'checked' : ''}> blockiert nächsten Schritt</label><label class="gs-chk"><input type="checkbox" class="fr_e" ${f.erledigt ? 'checked' : ''}> geklärt</label></div>`; }
function ak24MotivSpeichern(oid){
  const o = findObjekt(oid), m = {}, u = {};
  AK24_MOTIV.forEach(([k]) => { u[k] = document.getElementById('mo_u_' + k).checked; m[k] = u[k] ? '' : document.getElementById('mo_' + k).value.trim(); });
  m.unbekannt = u; m.freitext = document.getElementById('mo_frei').value.trim();
  m.offeneFragen = [...document.querySelectorAll('#mo_fragen .ak24-frage')].map(z => ({ id: z.dataset.id || uid(), text: z.querySelector('.fr_t').value.trim(), blockiert: z.querySelector('.fr_b').checked, erledigt: z.querySelector('.fr_e').checked })).filter(f => f.text);
  m.aktualisiert = new Date().toISOString();
  o.motivation = m;
  if(m.preisvorstellung && !u.preisvorstellung){ const n = mc24N(m.preisvorstellung.replace(/[^\d.,]/g, '')); if(n && n > 1000) an24Setzen(o, 'kaufpreis', { wert: n, herkunft: 'eigentuemer', quelle: 'Verkäufermotivation (Gespräch)', von: 'manuell' }, { aktivierenWennLeer: true }); }
  save(); schliesseModal(); renderMain();
}
function ak24MotivKarte(o){
  if(!ak24An()) return '';
  const m = o.motivation || {};
  const zeilen = AK24_MOTIV.map(([k, l]) => { const v = ak24MotivText(m, k); return `<tr><td>${l}</td><td>${v ? mc24E(v) : '<span class="mc24-muted">noch nicht erfragt</span>'}</td></tr>`; }).join('');
  const fr = (m.offeneFragen || []).filter(f => !f.erledigt);
  return `<div class="mc24-karte"><h3>Verkäufermotivation <span class="sp"></span><button class="tiny" onclick="ak24MotivDialog('${o.id}')">✎ Bearbeiten</button></h3><table class="mc24-tab kv">${zeilen}</table>${fr.length ? `<div style="margin-top:6px;"><b>Offene Fragen:</b> ${fr.map(f => mc24E(f.text) + (f.blockiert ? ' <span class="mc24-rot">(blockiert)</span>' : '')).join(' · ')}</div>` : ''}${m.aktualisiert ? `<div class="mc24-muted">aktualisiert ${mc24Datum(m.aktualisiert)}</div>` : ''}</div>`;
}

// ── 4.4 Einwände ──
function ak24EinwandDialog(kid, eid, oid){
  const k = findKontakt(kid); if(!k) return;
  const e = eid ? ak24Einwaende(k).find(x => x.id === eid) : { kategorie: 'privatverkauf', status: 'offen', datum: mc24Heute(), objektId: oid || null };
  const obj = ob24ObjekteVonKontakt(kid);
  mc24Modal(`<h3>Einwand ${eid ? 'bearbeiten' : 'erfassen'}: ${mc24E(k.name)}</h3>
    <div class="field-row"><div><label>Art</label><select id="ew_kat" onchange="document.getElementById('ew_hilfe').value=ak24Hilfe(this.value)">${AK24_EINWAND.map(x => `<option value="${x[0]}" ${e.kategorie === x[0] ? 'selected' : ''}>${x[1]}</option>`).join('')}</select></div>
      <div><label>Datum</label><input type="date" id="ew_dat" value="${mc24E(e.datum || mc24Heute())}"></div>
      <div><label>Status</label><select id="ew_st">${AK24_EINWAND_STATUS.map(x => `<option value="${x[0]}" ${e.status === x[0] ? 'selected' : ''}>${x[1]}</option>`).join('')}</select></div></div>
    ${obj.length ? `<label>Objekt</label><select id="ew_obj"><option value="">– allgemein –</option>${obj.map(o => `<option value="${o.id}" ${e.objektId === o.id ? 'selected' : ''}>${mc24E(mc24Titel(o))}</option>`).join('')}</select>` : ''}
    <label>Wortlaut (möglichst original)</label><input id="ew_wort" value="${mc24E(e.wortlaut || '')}" placeholder="„Wir wollen erst mal selbst inserieren.“">
    <label>Kontext</label><input id="ew_ktx" value="${mc24E(e.kontext || '')}">
    <label>Gesprächshilfe (Vorschlag – frei anpassbar, wird nicht automatisch versendet)</label><textarea id="ew_hilfe" rows="3">${mc24E(e.hilfe != null ? e.hilfe : ak24Hilfe(e.kategorie))}</textarea>
    <div class="mc24-knoepfe"><button class="tiny secondary" onclick="document.getElementById('ew_re').value=document.getElementById('ew_hilfe').value">↓ als vereinbarte Reaktion übernehmen</button><button class="tiny secondary" onclick="mc24Kopieren(ak24EinwandPrompt('${kid}'), '📋 Prompt kopiert')">📋 KI-Prompt für Gesprächshilfe</button></div>
    <label>Vereinbarte Reaktion / nächster Umgang</label><textarea id="ew_re" rows="2">${mc24E(e.reaktion || '')}</textarea>
    <div class="modal-actions">${eid ? `<button class="secondary" onclick="ak24EinwandLoeschen('${kid}','${eid}')">Löschen</button>` : '<div></div>'}<div class="right"><button class="secondary" onclick="schliesseModal()">Abbrechen</button><button onclick="ak24EinwandSpeichern('${kid}','${eid || ''}')">Speichern</button></div></div>`, 680);
}
function ak24EinwandPrompt(kid){
  const g = x => (document.getElementById(x) || {}).value || '';
  const kat = ak24L(AK24_EINWAND, g('ew_kat')), oid = g('ew_obj'), o = oid ? findObjekt(oid) : null;
  return `Formuliere für mich (Immobilienmakler, Berlin) eine kurze, respektvolle Gesprächshilfe zu diesem Einwand eines Eigentümers.
Einwand: ${kat}${g('ew_wort') ? ' – Wortlaut: „' + g('ew_wort') + '“' : ''}${g('ew_ktx') ? '\nKontext: ' + g('ew_ktx') : ''}
${o ? 'Objekt: ' + JSON.stringify({ objektart: o.objektart || null, ort: o.ort || null, wohnflaeche: an24Wert(o, 'wohnflaeche'), preisvorstellung: an24Wert(o, 'kaufpreis') }) : ''}
Regeln: Erfinde keine Käufer, Interessenten, Verkaufserfolge, Referenzen, Vergleichspreise oder Zusagen. Kein Druck, keine Garantien. Höchstens fünf Sätze plus eine offene Rückfrage. Deutsch.`;
}
function ak24EinwandSpeichern(kid, eid){
  const k = findKontakt(kid), g = x => document.getElementById(x); if(!k) return;
  if(!Array.isArray(k.einwaende)) k.einwaende = [];
  const daten = { kategorie: g('ew_kat').value, datum: g('ew_dat').value || mc24Heute(), status: g('ew_st').value, wortlaut: g('ew_wort').value.trim(), kontext: g('ew_ktx').value.trim(), reaktion: g('ew_re').value.trim(), hilfe: g('ew_hilfe').value, objektId: g('ew_obj') ? (g('ew_obj').value || null) : null, geaendert: new Date().toISOString() };
  if(eid) Object.assign(k.einwaende.find(x => x.id === eid), daten); else k.einwaende.push(Object.assign({ id: uid() }, daten));
  save(); schliesseModal(); renderMain();
}
function ak24EinwandLoeschen(kid, eid){ const k = findKontakt(kid); k.einwaende = ak24Einwaende(k).filter(x => x.id !== eid); save(); schliesseModal(); renderMain(); }
function ak24EinwaendeHtml(liste, kidFallback){
  return liste.length ? liste.map(x => `<div class="mc24-z" onclick="ak24EinwandDialog('${x.kontaktId || kidFallback}','${x.id}')"><span>🗨️</span><div><b>${mc24E(ak24L(AK24_EINWAND, x.kategorie))}</b> <span class="ak24-st st-${x.status}">${mc24E(ak24L(AK24_EINWAND_STATUS, x.status))}</span>${x.wortlaut ? `<small>„${mc24E(x.wortlaut)}“ · ${mc24Datum(x.datum)}</small>` : `<small>${mc24Datum(x.datum)}</small>`}${x.reaktion ? `<div class="mc24-muted">→ ${mc24E(x.reaktion)}</div>` : ''}</div></div>`).join('') : '<div class="vl-leer">Keine Einwände erfasst.</div>';
}

// ── 4.6 Gesprächsabschluss ──
let AK24_AB = null;
function ak24Abschluss(z){
  z = z || {};
  const o = z.objektId ? findObjekt(z.objektId) : null;
  let kandidaten = o ? ob24Kontakte(o).map(x => x.k) : [];
  const k0 = z.kontaktId ? findKontakt(z.kontaktId) : null;
  if(k0 && !kandidaten.includes(k0)) kandidaten.unshift(k0);
  if(k0 && k0.organisation) kandidaten = kandidaten.concat(mc24Ansprechpartner(k0.id).filter(x => !kandidaten.includes(x)));
  AK24_AB = z;
  const ohneKontakt = !kandidaten.length && o && (o.verkaeuferName || o.verkaeuferTelefon || o.verkaeuferEmail);
  mc24Modal(`<h3>✅ Gesprächsabschluss${o ? ': ' + mc24E(mc24Titel(o)) : k0 ? ': ' + mc24E(k0.name) : ''}</h3>
    ${kandidaten.length ? `<label>Gesprochen mit</label><select id="ab_k">${kandidaten.map(k => `<option value="${k.id}" ${k0 && k.id === k0.id ? 'selected' : ''}>${mc24E(k.name)}${k.organisation ? ' (Organisation)' : ''}${mc24Kontaktstopp(k) ? ' – Kontaktstopp!' : ''}</option>`).join('')}</select>` : ohneKontakt ? `<div class="mc24-muted">Beim Speichern wird ${mc24E(o.verkaeuferName || 'der Verkäufer')} aus den Lead-Daten als Kontakt angelegt.</div>` : ''}
    <div class="field-row"><div><label>Ergebnis</label><select id="ab_erg" onchange="ak24AbErgebnis()">${AK24_ERGEBNIS.map(x => `<option value="${x[0]}">${x[1]}</option>`).join('')}</select></div>
      <div><label>Ergebnis in einem Satz</label><input id="ab_ergt" placeholder="z. B. will erst Unterlagen sortieren"></div></div>
    <div class="field-row"><div><label>Nächster Schritt</label><select id="ab_schritt" onchange="ak24AbSchritt()">${AK24_SCHRITT.map(x => `<option value="${x[0]}">${x[1]}</option>`).join('')}</select></div>
      <div><label>Was genau?</label><input id="ab_schrittt" placeholder="z. B. Grundriss per E-Mail senden"></div></div>
    <div class="field-row" id="ab_wann_box"><div><label>Wann?</label><input type="date" id="ab_wann" value="${gsTagPlus(mc24Heute(), 2)}"></div><div><label>Uhrzeit (bei Terminen)</label><input type="time" id="ab_zeit" step="300"></div></div>
    <details class="gs-details" open><summary>Gesprächsnotiz (optional)</summary><textarea id="ab_notiz" rows="3" placeholder="Was wurde besprochen?"></textarea></details>
    <details class="gs-details"><summary>Einwand festhalten (optional)</summary><div class="field-row"><div><select id="ab_ew"><option value="">– kein Einwand –</option>${AK24_EINWAND.map(x => `<option value="${x[0]}">${x[1]}</option>`).join('')}</select></div><div><input id="ab_eww" placeholder="Wortlaut"></div></div></details>
    ${o ? `<details class="gs-details"><summary>Motivation aktualisieren (optional)</summary><div class="field-row"><div><label>Verkaufsgrund</label><input id="ab_mg" value="${mc24E((o.motivation || {}).verkaufsgrund || '')}"></div><div><label>Zeitraum</label><input id="ab_mz" value="${mc24E((o.motivation || {}).zeitraum || '')}"></div><div><label>Preisvorstellung</label><input id="ab_mp" value="${mc24E((o.motivation || {}).preisvorstellung || '')}"></div></div></details>` : ''}
    <div class="mc24-muted" id="ab_hinweis"></div>
    <div class="modal-actions"><div></div><div class="right"><button class="secondary" onclick="schliesseModal()">Abbrechen</button><button onclick="ak24AbschlussSpeichern()">Speichern</button></div></div>`, 720);
  ak24AbSchritt();
}
function ak24AbErgebnis(){
  const e = document.getElementById('ab_erg').value, s = document.getElementById('ab_schritt');
  if(['kontaktstopp', 'abgeschlossen', 'kein_interesse'].includes(e)) s.value = 'keiner';
  else if(e === 'nicht_erreicht' && s.value === 'keiner') s.value = 'rueckruf';
  else if(e === 'termin' && s.value === 'keiner') s.value = 'vorort';
  ak24AbSchritt();
}
function ak24AbSchritt(){
  const s = document.getElementById('ab_schritt').value, e = document.getElementById('ab_erg').value;
  document.getElementById('ab_wann_box').style.display = s === 'keiner' ? 'none' : '';
  document.getElementById('ab_hinweis').textContent = e === 'kontaktstopp' ? 'Kontaktstopp: Es wird keine Folgeaufgabe angelegt und der Kontakt erscheint nicht mehr beim Nachfassen.'
    : s === 'keiner' ? 'Kein Folgeschritt – es wird nur die Gesprächsnotiz gespeichert.'
    : ['telefontermin', 'vorort'].includes(s) ? 'Es wird genau ein Termin im Kalender angelegt (Google-Abgleich wie gewohnt).' : 'Es wird genau eine Aufgabe angelegt.';
}
function ak24AbschlussSpeichern(werte){
  const g = x => document.getElementById(x), z = AK24_AB || {};
  const v = werte || { kontaktId: g('ab_k') ? g('ab_k').value : null, ergebnis: g('ab_erg').value, ergebnisText: g('ab_ergt').value.trim(), schritt: g('ab_schritt').value, schrittText: g('ab_schrittt').value.trim(), wann: g('ab_wann').value, zeit: g('ab_zeit').value, notiz: g('ab_notiz').value.trim(), einwand: g('ab_ew').value, einwandWort: g('ab_eww').value.trim(), motiv: g('ab_mg') ? { verkaufsgrund: g('ab_mg').value.trim(), zeitraum: g('ab_mz').value.trim(), preisvorstellung: g('ab_mp').value.trim() } : null };
  const o = z.objektId ? findObjekt(z.objektId) : null;
  let k = v.kontaktId ? findKontakt(v.kontaktId) : null;
  if(!k && o) k = ob24Hauptkontakt(o, true);
  if(v.ergebnis === 'kontaktstopp') v.schritt = 'keiner';
  if(v.schritt !== 'keiner' && !v.wann){ akqToast('Bitte „Wann?“ angeben – oder „Kein weiterer Schritt“ wählen.'); return null; }
  if(v.schritt !== 'keiner' && k && mc24Kontaktstopp(k)){ akqToast('Für diesen Kontakt ist ein Kontaktstopp dokumentiert – kein Folgeschritt möglich.'); return null; }
  const schrittL = ak24L(AK24_SCHRITT, v.schritt).replace(/^\S+\s(?=[A-ZÄÖÜa-z])/, s => /[📞📍]/u.test(s) ? '' : s);
  const notiz = { id: uid(), createdAt: Date.now(), typ: 'gespraech', verarbeitet: true, datum: mc24Heute(), objektId: o ? o.id : null, kontaktId: k ? k.id : null,
    ergebnis: v.ergebnis, ergebnisText: v.ergebnisText, naechsterTyp: v.schritt, naechsterSchritt: v.schritt === 'keiner' ? '' : (schrittL + (v.schrittText ? ': ' + v.schrittText : '')), wann: v.schritt === 'keiner' ? '' : v.wann,
    text: [ak24L(AK24_ERGEBNIS, v.ergebnis) + (v.ergebnisText ? ' – ' + v.ergebnisText : ''), v.notiz].filter(Boolean).join('\n'), gespraechsnotiz: v.notiz, quelle: z.terminId ? { typ: 'termin', id: z.terminId } : z.aufgabeId ? { typ: 'aufgabe', id: z.aufgabeId } : null };
  db.notizen.push(notiz);
  // genau ein Folgeschritt
  const titelBasis = (o ? mc24Titel(o) : (k ? k.name : 'Kontakt')).slice(0, 50);
  if(v.schritt !== 'keiner'){
    if(['telefontermin', 'vorort'].includes(v.schritt) || (v.schritt === 'rueckruf' && v.zeit)){
      const art = v.schritt === 'rueckruf' ? 'rueckruf' : (k && (k.organisation || k.orgId) ? 'termin' : 'erstgespraech');
      const t = { id: uid(), createdAt: Date.now(), geaendertAm: Date.now(), titel: (v.schritt === 'rueckruf' ? 'Rückruf' : v.schritt === 'vorort' ? 'Termin vor Ort' : 'Telefontermin') + ': ' + titelBasis + (v.schrittText ? ' – ' + v.schrittText : ''),
        datum: v.wann, uhrzeit: v.zeit || '', dauer: v.zeit ? (v.schritt === 'vorort' ? 60 : 30) : null, art, artEigene: '', wo: v.schritt === 'vorort' ? 'vorort' : 'telefon',
        ort: v.schritt === 'vorort' ? (o ? [o.adresse, o.ort].filter(Boolean).join(', ') : (k && k.adresse) || '') : (k && k.telefon ? 'Telefon ' + k.telefon : ''), notiz: v.notiz, objektId: o ? o.id : null, kontaktId: k ? k.id : null, ausGespraech: notiz.id };
      db.termine.push(t); notiz.folgeArt = 'termin'; notiz.folgeId = t.id;
      if(typeof gsPlanen === 'function') gsPlanen(600);
    } else {
      const typ = v.schritt === 'zusage' ? 'zusage' : v.schritt === 'rueckruf' ? 'rueckruf' : 'nachfassen';
      const titel = (v.schritt === 'zusage' ? 'Zusage prüfen' : v.schritt === 'rueckruf' ? 'Rückruf' : v.schritt === 'unterlagen' ? 'Unterlagen senden' : 'Aufgabe') + ': ' + titelBasis + (v.schrittText ? ' – ' + v.schrittText : '');
      const a = mc24AufgabeAnlegen({ titel, faellig: v.wann, objektId: o ? o.id : null, kontaktId: k ? k.id : null, typ, ausGespraech: notiz.id });
      notiz.folgeArt = 'aufgabe'; notiz.folgeId = a.id;
    }
  }
  // Quelle (Rückruf-Termin / Aufgabe) erledigt
  if(z.terminId){ const t = (db.termine || []).find(x => x.id === z.terminId); if(t) t.erledigt = new Date().toISOString(); }
  if(z.aufgabeId){ const a = (db.aufgaben || []).find(x => x.id === z.aufgabeId); if(a){ a.status = 'erledigt'; a.erledigtAm = Date.now(); } }
  if(k && v.ergebnis === 'kontaktstopp') k.kontaktstopp = { aktiv: true, am: mc24Heute(), grund: v.ergebnisText || 'im Gespräch gewünscht' };
  if(k && v.einwand){ if(!Array.isArray(k.einwaende)) k.einwaende = []; k.einwaende.push({ id: uid(), kategorie: v.einwand, wortlaut: v.einwandWort, datum: mc24Heute(), status: 'offen', kontext: 'Gespräch ' + mc24Datum(mc24Heute()), reaktion: '', objektId: o ? o.id : null }); }
  if(o && v.motiv){ const m = o.motivation || (o.motivation = {}); Object.entries(v.motiv).forEach(([kk, w]) => { if(w){ m[kk] = w; if(m.unbekannt) m.unbekannt[kk] = false; } }); m.aktualisiert = new Date().toISOString(); }
  const org = k ? (k.organisation ? k : (k.orgId ? findKontakt(k.orgId) : null)) : null;
  if(org && org.koop){ org.koop.letzterAustausch = mc24Heute(); if(v.schritt !== 'keiner'){ org.koop.naechsterSchritt = notiz.naechsterSchritt + ' (' + mc24Datum(v.wann) + ')'; org.koop.wiedervorlage = ''; } if(['kontakt_offen', 'recherchiert'].includes(org.koop.status)) org.koop.status = v.ergebnis === 'nicht_erreicht' ? 'kontakt_offen' : 'gesprochen'; if(v.ergebnis === 'kontaktstopp'){ org.koop.status = 'kontaktstopp'; } }
  if(o){
    if(v.ergebnis === 'termin' && ['neu', 'email_geschrieben', 'kleinanzeigen_geschrieben', 'nicht_erreicht', 'nochmal_anrufen', 'telefontermin', 'erstkontakt'].includes(o.status)){ o.status = 'termin'; o.statusAm = Date.now(); }
    if(v.ergebnis === 'nicht_erreicht' && ['neu', 'email_geschrieben', 'kleinanzeigen_geschrieben'].includes(o.status)){ o.status = 'nicht_erreicht'; o.statusAm = Date.now(); }
    if(['interesse', 'spaeter'].includes(v.ergebnis) && ['neu', 'email_geschrieben', 'kleinanzeigen_geschrieben', 'nicht_erreicht', 'nochmal_anrufen', 'telefontermin'].includes(o.status)){ o.status = 'erstkontakt'; o.statusAm = Date.now(); }
    // v47: nächster Schritt „Telefontermin“ → Status „📞 Telefontermin“ (nach einem Gespräch = Nachfassen)
    if(v.schritt === 'telefontermin' && !['termin', 'auftrag', 'online', 'abgeschlossen'].includes(o.status)){ o.status = 'telefontermin'; o.statusAm = Date.now(); o.telefonArt = 'nachfassen'; }
    if(typeof aqLog === 'function') aqLog(o, 'gespraech', `Gespräch: ${ak24L(AK24_ERGEBNIS, v.ergebnis)}${v.ergebnisText ? ' – ' + v.ergebnisText : ''}${notiz.naechsterSchritt ? ' → ' + notiz.naechsterSchritt + ' (' + mc24Datum(v.wann) + ')' : ''}`);
  }
  save(); if(!werte){ schliesseModal(); renderMain(); try{ renderNav(); }catch(e){} }
  akqToast('✅ Gespräch gespeichert' + (notiz.folgeArt === 'termin' ? ' – Termin angelegt' : notiz.folgeArt === 'aufgabe' ? ' – Aufgabe angelegt' : ''));
  return notiz;
}

// ── 4.3 Prioritäten „Heute“ ──
function ak24TerminRueckruf(t){ return t.art === 'rueckruf' || (t.art === 'eigene' && /rückruf/i.test(t.artEigene || '')) || /^\s*rückruf/i.test(t.titel || ''); }
function ak24GespraechNach(objektId, kontaktId, datum){ return (db.notizen || []).some(n => n.typ === 'gespraech' && ((objektId && n.objektId === objektId) || (kontaktId && n.kontaktId === kontaktId)) && (n.datum || toDateKey(new Date(n.createdAt))) >= datum); }
function ak24Faellig(datum){ const h = mc24Heute(); if(!datum) return { t: 'ohne Datum', rang: 3 }; if(datum < h){ const tage = Math.round((Date.parse(h) - Date.parse(datum)) / 864e5); return { t: `überfällig seit ${tage} Tag${tage === 1 ? '' : 'en'}`, rang: 0, warn: true }; } if(datum === h) return { t: 'heute', rang: 1 }; const tage = Math.round((Date.parse(datum) - Date.parse(h)) / 864e5); return { t: tage === 1 ? 'morgen' : `in ${tage} Tagen`, rang: 2 }; }
function ak24Prioritaeten(){
  const R = ak24Db().regeln, h = mc24Heute(), l = [], gesperrt = [];
  const kontaktOk = (kid, oid) => { const k = kid ? findKontakt(kid) : null; const o = oid ? findObjekt(oid) : null; const k2 = !k && o ? ob24Hauptkontakt(o, false) : k; return !(k2 && mc24Kontaktstopp(k2)); };
  const add = (x, kontaktbezogen) => { if(kontaktbezogen && !kontaktOk(x.kontaktId, x.objektId)){ gesperrt.push(x); return; } l.push(x); };
  if(R.rueckruf.an) (db.termine || []).filter(t => ak24TerminRueckruf(t) && t.datum && t.datum <= h && !t.erledigt && !ak24GespraechNach(t.objektId, t.kontaktId, t.datum)).forEach(t => add({ key: 't:' + t.id, regel: 'rueckruf', anlass: 'Vereinbarter Rückruf' + (t.uhrzeit ? ' um ' + t.uhrzeit : ''), datum: t.datum, objektId: t.objektId, kontaktId: t.kontaktId, quelle: { terminId: t.id }, titel: t.titel }, true));
  if(R.rueckruf.an) (db.aufgaben || []).filter(a => a.typ === 'rueckruf' && a.status !== 'erledigt' && a.faellig && a.faellig <= h).forEach(a => add({ key: 'a:' + a.id, regel: 'rueckruf', anlass: 'Vereinbarter Rückruf', datum: a.faellig, objektId: a.objektId, kontaktId: a.kontaktId, quelle: { aufgabeId: a.id }, titel: a.titel }, true));
  if(R.termin.an){
    const bis = gsTagPlus(h, Number(R.termin.tage) || 3);
    (db.termine || []).filter(t => t.objektId && t.datum >= h && t.datum <= bis && !ak24TerminRueckruf(t) && ['besichtigung', 'akquise', 'erstgespraech', 'termin', 'eigene'].includes(t.art)).forEach(t => {
      const o = findObjekt(t.objektId); if(!o) return;
      const fehlt = [];
      if(!t.briefingAm && !(o.briefingAm && o.briefingAm.slice(0, 10) >= gsTagPlus(t.datum, -14))) fehlt.push('Briefing');
      const a = ob24LetzteAnalyse(o), alt = a ? (Date.now() - (a.erstellt || 0)) / 864e5 : null;
      if(['besichtigung', 'akquise', 'erstgespraech'].includes(t.art) && (!a || alt > (Number(R.termin.analyseTage) || 180))) fehlt.push('Marktanalyse');
      if(fehlt.length) add({ key: 'tb:' + t.id, regel: 'termin', anlass: `${typeof twPre === 'function' ? twPre(t) : ''}Eigentümertermin ${gsDatumLang(t.datum)}${t.uhrzeit ? ' ' + t.uhrzeit : ''} – ${fehlt.join(' und ')} fehlt`, datum: t.datum, objektId: t.objektId, kontaktId: t.kontaktId, quelle: { terminId: t.id }, fehlt, titel: t.titel }, false);
    });
  }
  if(R.zusage.an) (db.aufgaben || []).filter(a => a.typ === 'zusage' && a.status !== 'erledigt' && a.faellig && a.faellig <= h).forEach(a => add({ key: 'a:' + a.id, regel: 'zusage', anlass: 'Zusage fällig: ' + a.titel.replace(/^Zusage prüfen:\s*/, ''), datum: a.faellig, objektId: a.objektId, kontaktId: a.kontaktId, quelle: { aufgabeId: a.id }, titel: a.titel }, true));
  if(R.nachfassen.an) (db.aufgaben || []).filter(a => !['rueckruf', 'zusage'].includes(a.typ) && a.status !== 'erledigt' && a.faellig && a.faellig <= h).forEach(a => add({ key: 'a:' + a.id, regel: 'nachfassen', anlass: (a.typ === 'klaerung' ? 'Klärung fällig: ' : 'Aufgabe fällig: ') + a.titel, datum: a.faellig, objektId: a.objektId, kontaktId: a.kontaktId, quelle: { aufgabeId: a.id }, titel: a.titel }, !!(a.kontaktId || a.objektId) && a.typ !== 'klaerung'));
  if(R.blockiert.an) (db.objekte || []).forEach(o => ((o.motivation || {}).offeneFragen || []).filter(f => f.blockiert && !f.erledigt).forEach(f => add({ key: 'f:' + o.id + ':' + f.id, regel: 'blockiert', anlass: 'Offene Frage blockiert: ' + f.text, datum: null, objektId: o.id, kontaktId: o.eigentuemerId, quelle: { frage: f.id }, titel: f.text }, false)));
  if(R.koop.an) mc24Organisationen().filter(k => k.koop && k.koop.wiedervorlage && k.koop.wiedervorlage <= h && !['kein_bedarf', 'kontaktstopp'].includes(k.koop.status)).forEach(k => add({ key: 'k:' + k.id, regel: 'koop', anlass: 'Kooperation ' + k.name + ': ' + (k.koop.naechsterSchritt || 'nächster Schritt fällig'), datum: k.koop.wiedervorlage, objektId: null, kontaktId: k.id, quelle: {}, titel: k.name }, true));
  // Dubletten (z. B. Rückruf-Termin und Rückruf-Aufgabe für dasselbe Objekt am selben Tag)
  const gesehen = new Set(), eindeutig = [];
  for(const x of l){ const d = x.regel + '|' + (x.objektId || x.kontaktId || x.key) + '|' + (x.datum || '') + (x.regel === 'nachfassen' ? '|' + x.key : ''); if(gesehen.has(d) || gesehen.has(x.key)) continue; gesehen.add(d); gesehen.add(x.key); eindeutig.push(x); }
  const P = ak24Db().prio;
  const heute = eindeutig.filter(x => !(P[x.key] && P[x.key].stufe === 'spaeter' && P[x.key].bis > h)).map(x => Object.assign(x, { manuell: (P[x.key] || {}).stufe || '', faellig: ak24Faellig(x.datum) }));
  heute.sort((a, b) => (b.manuell === 'oben') - (a.manuell === 'oben') || (a.manuell === 'unten') - (b.manuell === 'unten') || a.faellig.rang - b.faellig.rang || String(a.datum || '9').localeCompare(String(b.datum || '9')));
  return { liste: heute, gesperrt, ausgeblendet: eindeutig.length - heute.length };
}
function ak24PrioSetzen(key, stufe){ const P = ak24Db().prio; if(!stufe) delete P[key]; else P[key] = { stufe, bis: stufe === 'spaeter' ? gsTagPlus(mc24Heute(), 1) : null, am: mc24Heute() }; save(); renderMain(); try{ renderNav(); }catch(e){} }
function ak24ErledigtKlick(key){
  const [art, id] = key.split(':');
  if(art === 'a') mc24AufgabeErledigt(id, true);
  else if(art === 't' || art === 'tb'){ const t = (db.termine || []).find(x => x.id === id); if(t){ if(art === 'tb') t.briefingAm = new Date().toISOString(); else t.erledigt = new Date().toISOString(); } save(); }
  else if(art === 'k'){ const k = findKontakt(id); if(k && k.koop){ k.koop.wiedervorlage = ''; save(); } }
  renderMain(); try{ renderNav(); }catch(e){}
}
const AK24_REGEL_ICON = { rueckruf: '📞', termin: '📅', zusage: '📨', nachfassen: '⏰', blockiert: '⛔', koop: '🏢' };
function ak24Render(main){
  const p = ak24Prioritaeten(), R = ak24Db().regeln, h = mc24Heute();
  const tt = (db.termine || []).filter(t => t.datum === h).sort((a, b) => (a.uhrzeit || '').localeCompare(b.uhrzeit || ''));
  const ueber = p.liste.filter(x => x.faellig.rang === 0).length;
  const zeile = x => {
    const o = x.objektId ? findObjekt(x.objektId) : null, k = x.kontaktId ? findKontakt(x.kontaktId) : (o ? ob24Hauptkontakt(o, false) : null);
    const ziel = JSON.stringify({ objektId: x.objektId || null, kontaktId: k ? k.id : null, terminId: x.quelle.terminId || null, aufgabeId: x.quelle.aufgabeId || null });
    const aktionen = [];
    if(['rueckruf', 'zusage', 'nachfassen', 'koop'].includes(x.regel)) aktionen.push(`<button class="tiny" onclick='ak24Abschluss(${mc24E(ziel)})'>✅ Gespräch abschließen</button>`);
    if(x.regel === 'termin'){ if(x.fehlt.includes('Briefing')) aktionen.push(`<button class="tiny" onclick='ak24Briefing(${mc24E(ziel)})'>🗒️ Briefing öffnen</button>`); if(x.fehlt.includes('Marktanalyse')) aktionen.push(`<button class="tiny secondary" onclick="ma24Neu('${x.objektId}')">📊 Analyse starten</button>`); }
    else if(o || k) aktionen.push(`<button class="tiny secondary" onclick='ak24Briefing(${mc24E(ziel)})'>🗒️ Briefing</button>`);
    if(x.regel === 'blockiert') aktionen.push(`<button class="tiny" onclick="ak24MotivDialog('${x.objektId}')">Frage klären</button>`);
    if(x.quelle.aufgabeId || x.quelle.terminId || x.regel === 'koop') aktionen.push(`<button class="tiny secondary" onclick="ak24ErledigtKlick('${x.key}')">${x.regel === 'termin' ? 'vorbereitet' : 'erledigt'}</button>`);
    return `<div class="ak24-p ${x.faellig.warn ? 'warn' : ''} ${x.manuell === 'oben' ? 'oben' : ''}"><div class="ak24-pi">${AK24_REGEL_ICON[x.regel]}</div>
      <div class="ak24-pt"><b>${mc24E(x.anlass)}</b><small>${mc24E(x.faellig.t)}${o ? ' · <a href="#" onclick="ob24Oeffnen(\'' + o.id + '\');return false;">📁 ' + mc24E(mc24Titel(o)) + '</a>' : ''}${k ? ' · 👤 ' + mc24E(k.name) + (k.telefon ? ' <span style="white-space:nowrap">' + mc24E(k.telefon) + '</span>' : '') : ''} · Regel: ${mc24E(R[x.regel].l)}</small></div>
      <div class="ak24-pa">${aktionen.join('')}<select title="Eigene Priorität" onchange="ak24PrioSetzen('${x.key}', this.value)"><option value="">Priorität: normal</option><option value="oben" ${x.manuell === 'oben' ? 'selected' : ''}>⇧ ganz oben</option><option value="unten" ${x.manuell === 'unten' ? 'selected' : ''}>⇩ nach unten</option><option value="spaeter">bis morgen ausblenden</option></select></div></div>`;
  };
  main.innerHTML = `
  <div class="aq-kopf"><div class="ic">${IC.heute || ''}</div><div><h1>Heute</h1><div class="sub">${p.liste.length ? `${p.liste.length} Punkt${p.liste.length === 1 ? '' : 'e'} zu erledigen${ueber ? `, davon ${ueber} überfällig` : ''}` : 'Alles erledigt – keine fälligen Punkte.'} · ${tt.length} Termin${tt.length === 1 ? '' : 'e'} heute</div></div>
    <div class="knoepfe"><button class="secondary" onclick="ak24RegelnDialog()">⚙ Regeln</button><button class="secondary" onclick="ak24AbschlussFrei()">✅ Gespräch abschließen</button></div></div>
  <div class="ak24-layout"><div>
    ${p.liste.map(zeile).join('') || '<div class="mc24-karte"><div class="vl-leer">Keine fälligen Rückrufe, Zusagen oder Aufgaben. Neue Punkte entstehen aus Gesprächsabschlüssen, Terminen und Aufgaben.</div></div>'}
    ${p.gesperrt.length ? `<div class="mc24-muted" style="margin-top:8px;">${p.gesperrt.length} Punkt(e) wegen dokumentiertem Kontaktstopp nicht angezeigt.</div>` : ''}${p.ausgeblendet ? `<div class="mc24-muted">${p.ausgeblendet} Punkt(e) bis morgen ausgeblendet.</div>` : ''}
  </div><div class="mc24-karte"><h3>Termine heute</h3>${tt.length ? tt.map(t => `<div>${typeof gsTerminZeile === 'function' ? gsTerminZeile(t, false) : mc24E(t.titel)}${t.objektId || t.kontaktId ? `<button class="tiny secondary ak24-tb" onclick='ak24Briefing(${mc24E(JSON.stringify({ terminId: t.id }))})'>🗒️ Briefing</button>` : ''}</div>`).join('') : '<div class="vl-leer">Keine Termine.</div>'}</div></div>`;
}
function ak24AbschlussFrei(){
  const obj = (db.objekte || []).slice().sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0)), ks = (db.kontakte || []).slice().sort((a, b) => String(a.name || '').localeCompare(String(b.name || ''), 'de'));
  mc24Modal(`<h3>Gespräch abschließen – mit wem?</h3><div class="field-row"><div><label>Objekt / Lead</label><select id="af_o"><option value="">–</option>${obj.map(o => `<option value="${o.id}">${mc24E(mc24Titel(o))}</option>`).join('')}</select></div><div><label>oder Kontakt</label><select id="af_k"><option value="">–</option>${ks.map(k => `<option value="${k.id}">${mc24E(k.name)}</option>`).join('')}</select></div></div>
    <div class="modal-actions"><div></div><div class="right"><button class="secondary" onclick="schliesseModal()">Abbrechen</button><button onclick="ak24Abschluss({objektId:document.getElementById('af_o').value||null,kontaktId:document.getElementById('af_k').value||null})">Weiter</button></div></div>`, 600);
}
function ak24RegelnDialog(){
  const R = ak24Db().regeln;
  mc24Modal(`<h3>Prioritäten-Regeln</h3><div class="mc24-muted">Jede Regel ist nachvollziehbar: Ein Punkt erscheint nur, wenn genau diese Bedingung zutrifft. Es gibt keine Abschlusswahrscheinlichkeiten. Kontakte mit Kontaktstopp werden nie zum Nachfassen vorgeschlagen.</div>
    ${Object.entries(R).map(([k, r]) => `<label class="gs-chk"><input type="checkbox" id="rg_${k}" ${r.an ? 'checked' : ''}> ${AK24_REGEL_ICON[k]} ${mc24E(r.l)}</label>${k === 'termin' ? `<div class="field-row" style="margin-left:26px;"><div><label>Vorlauf (Tage)</label><input id="rg_tage" type="number" min="0" max="30" value="${r.tage}"></div><div><label>Analyse gilt als fehlend, wenn älter als (Tage)</label><input id="rg_atage" type="number" min="1" value="${r.analyseTage}"></div></div>` : ''}`).join('')}
    <div class="modal-actions"><div></div><div class="right"><button class="secondary" onclick="schliesseModal()">Abbrechen</button><button onclick="ak24RegelnSpeichern()">Speichern</button></div></div>`, 620);
}
function ak24RegelnSpeichern(){ const R = ak24Db().regeln; Object.keys(R).forEach(k => { R[k].an = document.getElementById('rg_' + k).checked; }); R.termin.tage = Number(document.getElementById('rg_tage').value) || 0; R.termin.analyseTage = Number(document.getElementById('rg_atage').value) || 180; save(); schliesseModal(); renderMain(); }
function ak24HilfenDialog(){
  mc24Modal(`<h3>Gesprächshilfen</h3><div class="mc24-muted">Vorschläge, die beim Erfassen eines Einwands erscheinen. Keine Versprechen, keine erfundenen Käufer oder Erfolge.</div>
    ${AK24_EINWAND.map(([k, l]) => `<label>${l}</label><textarea id="hf_${k}" rows="3">${mc24E(ak24Hilfe(k))}</textarea>`).join('')}
    <div class="modal-actions"><button class="secondary" onclick="ak24Db().hilfen={};save();ak24HilfenDialog()">Standard wiederherstellen</button><div class="right"><button class="secondary" onclick="schliesseModal()">Abbrechen</button><button onclick="AK24_EINWAND.forEach(([k])=>{ak24Db().hilfen[k]=document.getElementById('hf_'+k).value});save();schliesseModal()">Speichern</button></div></div>`, 720);
}

// ── 4.5 Kooperationsakte Hausverwaltung (Organisationen in den vorhandenen Kontakten) ──
let AK24_KOOP = { filter: 'aktiv', sel: null };
function ak24KoopListe(){ return mc24Organisationen().filter(k => k.koop || k.kontaktart === 'hausverwaltung'); }
function ak24KoopRender(main){
  const alle = ak24KoopListe();
  const f = AK24_KOOP.filter;
  const liste = alle.filter(k => f === 'alle' || (f === 'aktiv' ? !['kein_bedarf', 'kontaktstopp'].includes((k.koop || {}).status) : (k.koop || {}).status === f)).sort((a, b) => String((a.koop || {}).wiedervorlage || '9').localeCompare(String((b.koop || {}).wiedervorlage || '9')) || a.name.localeCompare(b.name, 'de'));
  const hvOffen = (((db.hv || {}).verwaltungen) || []).filter(v => !alle.some(k => k.koop && k.koop.hvId === v.id)).length;
  if(!liste.find(k => k.id === AK24_KOOP.sel)) AK24_KOOP.sel = liste.length ? liste[0].id : null;
  main.innerHTML = `
  <div class="aq-kopf"><div class="ic">${IC.kooperationen || ''}</div><div><h1>Kooperationen</h1><div class="sub">Hausverwaltungen als Organisationen mit mehreren Ansprechpartnern – in deinen Kontakten, ohne Doppelte.</div></div>
    <div class="knoepfe">${hvOffen ? `<button class="secondary" onclick="ak24HvUebernehmen()">⇩ ${hvOffen} aus „Hausverwaltungen“ übernehmen</button>` : ''}<button onclick="ak24KoopNeu()">+ Organisation</button></div></div>
  <div class="mc24-hinweis">Anrufe bei Hausverwaltungen nur mit konkretem, vorher festgehaltenem Anlass (z. B. aktuelles Vermietungsinserat); E-Mails nur nach Einwilligung. Kontaktdaten nur mit Quelle – keine geratenen Adressen.</div>
  <div class="vl-tabs km-tabs">${[['aktiv', 'Laufend'], ...AK24_KOOP_STATUS, ['alle', 'Alle']].map(([k, l]) => `<button class="${f === k ? 'an' : ''}" onclick="AK24_KOOP.filter='${k}';renderMain()">${l} (${k === 'alle' ? alle.length : k === 'aktiv' ? alle.filter(x => !['kein_bedarf', 'kontaktstopp'].includes((x.koop || {}).status)).length : alle.filter(x => (x.koop || {}).status === k).length})</button>`).join('')}</div>
  <div class="aq-layout"><div>${liste.map(k => { const c = k.koop || {}; return `<div class="ak24-koopz ${k.id === AK24_KOOP.sel ? 'an' : ''}" onclick="AK24_KOOP.sel='${k.id}';renderMain()"><b>${mc24E(k.name)}</b><span class="ak24-st st-${c.status || 'recherchiert'}">${mc24E(ak24L(AK24_KOOP_STATUS, c.status || 'recherchiert'))}</span><small>${mc24E([c.verwaltungstyp, c.gebiete].filter(Boolean).join(' · '))}${mc24Ansprechpartner(k.id).length ? ' · ' + mc24Ansprechpartner(k.id).length + ' Ansprechpartner' : ''}${c.wiedervorlage ? ' · nächster Schritt ' + mc24Datum(c.wiedervorlage) : ''}</small></div>`; }).join('') || '<div class="vl-leer">Keine Organisationen in diesem Filter.</div>'}</div>
  <div>${AK24_KOOP.sel ? ak24KoopAkteHtml(findKontakt(AK24_KOOP.sel)) : ''}</div></div>`;
}
function ak24KoopAkteHtml(k){
  const c = k.koop || {}, ap = mc24Ansprechpartner(k.id), ids = [k.id].concat(ap.map(x => x.id));
  const gespr = ak24Gespraeche({ kontaktIds: ids }), aufg = (db.aufgaben || []).filter(a => ids.includes(a.kontaktId) && a.status !== 'erledigt');
  const z = (l, w) => `<tr><td>${l}</td><td>${w || '<span class="mc24-muted">unbekannt</span>'}</td></tr>`;
  return `<div class="mc24-karte"><h3>${mc24E(k.name)} <span class="sp"></span><button class="tiny secondary" onclick='ak24Briefing(${mc24E(JSON.stringify({ kontaktId: k.id }))})'>🗒️ Vorbereiten</button><button class="tiny" onclick='ak24Abschluss(${mc24E(JSON.stringify({ kontaktId: k.id }))})'>✅ Gespräch</button><button class="tiny secondary" onclick="ak24KoopDialog('${k.id}')">✎</button></h3>
    ${mc24Kontaktstopp(k) ? '<div class="mc24-stopp">Kontaktstopp dokumentiert – nicht kontaktieren.</div>' : ''}
    <table class="mc24-tab kv">${z('Status', mc24E(ak24L(AK24_KOOP_STATUS, c.status || 'recherchiert')))}${z('Telefon', k.telefon ? mc24E(k.telefon) + ((k.quellen || {}).telefon ? ` <small>(Quelle: ${mc24E(k.quellen.telefon)})</small>` : ' <small class="mc24-rot">Quelle fehlt</small>') : '')}${z('E-Mail', k.email ? mc24E(k.email) + ((k.quellen || {}).email ? ` <small>(Quelle: ${mc24E(k.quellen.email)})</small>` : ' <small class="mc24-rot">Quelle fehlt</small>') : '')}
      ${z('E-Mail-Einwilligung', c.einwilligungEmail && c.einwilligungEmail.ja ? 'ja, am ' + mc24Datum(c.einwilligungEmail.am) + (c.einwilligungEmail.wie ? ' (' + mc24E(c.einwilligungEmail.wie) + ')' : '') : 'nein / nicht dokumentiert')}
      ${z('Verwaltungstyp', mc24E(c.verwaltungstyp))}${z('Gebiete', mc24E(c.gebiete))}${z('Objektarten', mc24E(c.objektarten))}${z('Bestand', c.bestand && c.bestand.wert ? mc24E(c.bestand.wert) + (c.bestand.quelle ? ` <small>(Quelle: ${mc24E(c.bestand.quelle)})</small>` : ' <small class="mc24-rot">ohne Quelle</small>') : '')}
      ${z('Bisherige Vermietungslösung', mc24E(c.vermietungsloesung))}${z('Eigene Vermietungsabteilung', mc24E(c.eigeneVermietung || 'unbekannt'))}${z('Kooperationsbedarf', mc24E(c.bedarf))}${z('Konkreter Anlass für Kontakt', mc24E(c.anlass))}
      ${z('Letzter Austausch', c.letzterAustausch ? mc24Datum(c.letzterAustausch) : '')}${z('Vereinbarungen', mc24E(c.vereinbarungen))}${z('Nächster Schritt', mc24E(c.naechsterSchritt) + (c.wiedervorlage ? ' (' + mc24Datum(c.wiedervorlage) + ')' : ''))}</table>
    <h4 style="margin:12px 0 4px;">Ansprechpartner <button class="tiny secondary" onclick="ak24ApNeu('${k.id}')">+ Ansprechpartner</button></h4>
    ${ap.map(x => `<div class="mc24-z" onclick="oeffneKontaktModal('${x.id}')"><span>👤</span><div><b>${mc24E(x.name)}</b> <span class="mc24-muted">${mc24E(x.rolle || '')}</span><small>${mc24E([x.telefon, x.email].filter(Boolean).join(' · ') || 'keine Kontaktdaten')}</small></div></div>`).join('') || '<div class="vl-leer">Noch keine Ansprechpartner – nur mit tatsächlich vorliegenden Angaben anlegen.</div>'}
    <h4 style="margin:12px 0 4px;">Gespräche</h4>${gespr.slice(0, 5).map(g => `<div class="mc24-z"><span>💬</span><div>${mc24E(ak24L(AK24_ERGEBNIS, g.ergebnis))}${g.ergebnisText ? ' – ' + mc24E(g.ergebnisText) : ''}<small>${mc24Datum(g.datum || g.createdAt)}${g.naechsterSchritt ? ' · ' + mc24E(g.naechsterSchritt) : ''}</small></div></div>`).join('') || '<div class="vl-leer">Noch kein Gespräch.</div>'}
    ${aufg.length ? `<h4 style="margin:12px 0 4px;">Offene Aufgaben</h4>${ob24AufgabenHtml(aufg)}` : ''}</div>`;
}
function ak24KoopDialog(kid){
  const k = kid ? findKontakt(kid) : { name: '', koop: { status: 'recherchiert' } }, c = k.koop || {};
  const f = (id, l, w, ph) => `<div><label>${l}</label><input id="kp_${id}" value="${mc24E(w || '')}" placeholder="${mc24E(ph || '')}"></div>`;
  mc24Modal(`<h3>${kid ? 'Kooperationsakte bearbeiten' : 'Neue Organisation'}</h3>
    <div class="field-row">${f('name', 'Name', k.name)}<div><label>Status</label><select id="kp_status">${AK24_KOOP_STATUS.map(x => `<option value="${x[0]}" ${(c.status || 'recherchiert') === x[0] ? 'selected' : ''}>${x[1]}</option>`).join('')}</select></div></div>
    <div class="field-row">${f('tel', 'Telefon', k.telefon)}${f('qtel', 'Quelle Telefon', (k.quellen || {}).telefon, 'z. B. Impressum der Website')}</div>
    <div class="field-row">${f('mail', 'E-Mail', k.email, 'nur tatsächlich vorliegende Adresse')}${f('qmail', 'Quelle E-Mail', (k.quellen || {}).email)}</div>
    <div class="field-row">${f('typ', 'Verwaltungstyp', c.verwaltungstyp, 'Miet-, WEG-, SE-Verwaltung')}${f('geb', 'Gebiete', c.gebiete)}${f('arten', 'Objektarten', c.objektarten)}</div>
    <div class="field-row">${f('best', 'Bekannte Bestandsgröße', (c.bestand || {}).wert, 'z. B. ca. 800 Einheiten')}${f('bestq', 'Quelle Bestandsgröße', (c.bestand || {}).quelle)}</div>
    <div class="field-row">${f('loes', 'Bisherige Vermietungslösung', c.vermietungsloesung)}<div><label>Eigene Vermietungsabteilung</label><select id="kp_eig">${['unbekannt', 'ja', 'nein'].map(x => `<option ${(c.eigeneVermietung || 'unbekannt') === x ? 'selected' : ''}>${x}</option>`).join('')}</select></div></div>
    <div class="field-row">${f('bedarf', 'Kooperationsbedarf', c.bedarf)}${f('anlass', 'Konkreter Anlass für die Kontaktaufnahme', c.anlass, 'z. B. Vermietungsinserat vom 03.11.2026')}</div>
    <div class="field-row">${f('verein', 'Vereinbarungen', c.vereinbarungen)}${f('naechst', 'Nächster Schritt', c.naechsterSchritt)}<div><label>Wiedervorlage</label><input type="date" id="kp_wv" value="${mc24E(c.wiedervorlage || '')}"></div></div>
    <div class="field-row"><div><label class="gs-chk"><input type="checkbox" id="kp_ein" ${c.einwilligungEmail && c.einwilligungEmail.ja ? 'checked' : ''}> E-Mail-Einwilligung erteilt</label></div><div><label>am</label><input type="date" id="kp_einam" value="${mc24E((c.einwilligungEmail || {}).am || '')}"></div>${f('einwie', 'wie (z. B. im Telefonat)', (c.einwilligungEmail || {}).wie)}</div>
    <div class="modal-actions">${kid ? `<button class="secondary" onclick="loescheKontakt('${kid}')">Löschen</button>` : '<div></div>'}<div class="right"><button class="secondary" onclick="schliesseModal()">Abbrechen</button><button onclick="ak24KoopSpeichern('${kid || ''}')">Speichern</button></div></div>`, 820);
}
function ak24KoopSpeichern(kid){
  const g = x => (document.getElementById('kp_' + x) || {}).value || '';
  const name = g('name').trim(); if(!name){ akqToast('Name fehlt'); return; }
  let k = kid ? findKontakt(kid) : null;
  if(!k){
    k = (db.kontakte || []).find(x => x.organisation && x.name.trim().toLowerCase() === name.toLowerCase());
    if(!k){ k = { id: uid(), createdAt: Date.now(), name, telefon: '', email: '', adresse: '', kontaktart: 'hausverwaltung', quelle: 'Direktakquise', status: 'lead', prioritaet: 'mittel', notizen: '' }; db.kontakte.push(k); }
  }
  const c = Object.assign({}, k.koop || {});
  Object.assign(c, { status: g('status'), verwaltungstyp: g('typ').trim(), gebiete: g('geb').trim(), objektarten: g('arten').trim(), bestand: { wert: g('best').trim(), quelle: g('bestq').trim() }, vermietungsloesung: g('loes').trim(), eigeneVermietung: g('eig'), bedarf: g('bedarf').trim(), anlass: g('anlass').trim(), vereinbarungen: g('verein').trim(), naechsterSchritt: g('naechst').trim(), wiedervorlage: g('wv'), einwilligungEmail: { ja: document.getElementById('kp_ein').checked, am: g('einam'), wie: g('einwie').trim() } });
  Object.assign(k, { name, organisation: true, kontaktart: 'hausverwaltung', telefon: g('tel').trim(), email: g('mail').trim(), quellen: { telefon: g('qtel').trim(), email: g('qmail').trim() }, koop: c });
  if(c.status === 'kontaktstopp') k.kontaktstopp = { aktiv: true, am: mc24Heute(), grund: 'Status Kontaktstopp' };
  AK24_KOOP.sel = k.id; save(); schliesseModal(); renderMain();
}
function ak24KoopNeu(){ ak24KoopDialog(null); }
function ak24ApNeu(orgId){
  mc24Modal(`<h3>Ansprechpartner</h3><div class="mc24-muted">Nur Angaben, die tatsächlich vorliegen.</div><div class="field-row"><div><label>Name</label><input id="ap_n"></div><div><label>Rolle / Funktion</label><input id="ap_r"></div></div><div class="field-row"><div><label>Telefon</label><input id="ap_t"></div><div><label>Quelle Telefon</label><input id="ap_qt"></div></div><div class="field-row"><div><label>E-Mail</label><input id="ap_m"></div><div><label>Quelle E-Mail</label><input id="ap_qm"></div></div>
    <div class="modal-actions"><div></div><div class="right"><button class="secondary" onclick="schliesseModal()">Abbrechen</button><button onclick="ak24ApSpeichern('${orgId}')">Speichern</button></div></div>`, 620);
}
function ak24ApSpeichern(orgId){
  const g = x => document.getElementById(x).value.trim();
  const name = g('ap_n'); if(!name){ akqToast('Name fehlt'); return; }
  const dup = mc24Ansprechpartner(orgId).find(x => x.name.trim().toLowerCase() === name.toLowerCase());
  if(dup){ akqToast('Diesen Ansprechpartner gibt es schon – geöffnet.'); oeffneKontaktModal(dup.id); return; }
  db.kontakte.push({ id: uid(), createdAt: Date.now(), name, rolle: g('ap_r'), telefon: g('ap_t'), email: g('ap_m'), quellen: { telefon: g('ap_qt'), email: g('ap_qm') }, orgId, adresse: '', kontaktart: 'hausverwaltung', quelle: 'Direktakquise', status: 'lead', prioritaet: 'mittel', notizen: '' });
  save(); schliesseModal(); renderMain();
}
// aus dem Hausverwaltungen-Modul (Recherche-/Anrufliste) übernehmen – ohne Dubletten
function ak24HvUebernehmen(nurIds){
  const vw = (((db.hv || {}).verwaltungen) || []).filter(v => !nurIds || nurIds.includes(v.id));
  let neu = 0, verkn = 0, ap = 0;
  for(const v of vw){
    let k = (db.kontakte || []).find(x => x.koop && x.koop.hvId === v.id) || (db.kontakte || []).find(x => x.organisation && x.name.trim().toLowerCase() === String(v.name || '').trim().toLowerCase());
    if(k && k.koop && k.koop.hvId === v.id) continue;
    if(!k){ k = { id: uid(), createdAt: Date.now(), name: v.name || 'Hausverwaltung', telefon: v.telefon || '', email: v.email || '', adresse: '', kontaktart: 'hausverwaltung', quelle: 'Direktakquise', status: 'lead', prioritaet: 'mittel', notizen: v.notizen || '', organisation: true, quellen: { telefon: v.telefon ? (v.quelle || 'Hausverwaltungen-Modul') : '', email: v.email ? (v.quelle || 'Hausverwaltungen-Modul') : '' } }; db.kontakte.push(k); neu++; }
    else verkn++;
    k.organisation = true; k.kontaktart = 'hausverwaltung';
    k.koop = Object.assign({ status: AK24_HV_STATUS[v.status] || 'recherchiert', gebiete: v.bezirk || '', verwaltungstyp: v.art || '', bestand: { wert: v.einheiten ? String(v.einheiten) : '', quelle: v.einheiten ? (v.quelle || 'Recherche') : '' }, bedarf: v.potenzial || '', anlass: v.begruendung || '' }, k.koop || {}, { hvId: v.id });
    if(v.ansprechpartner && String(v.ansprechpartner).trim() && !mc24Ansprechpartner(k.id).some(x => x.name.trim().toLowerCase() === String(v.ansprechpartner).trim().toLowerCase())){
      db.kontakte.push({ id: uid(), createdAt: Date.now(), name: String(v.ansprechpartner).trim(), orgId: k.id, rolle: '', telefon: '', email: '', adresse: '', kontaktart: 'hausverwaltung', quelle: 'Direktakquise', status: 'lead', prioritaet: 'mittel', notizen: '' }); ap++;
    }
  }
  save(); if(aktuelleAnsicht === 'kooperationen') renderMain();
  akqToast(`🏢 ${neu} neu angelegt, ${verkn} mit vorhandener Organisation verknüpft${ap ? ', ' + ap + ' Ansprechpartner' : ''}`);
  return { neu, verkn, ap };
}

// ── Einbindung (nur wenn eingeschaltet) ──
MC24.akte.knoepfe.push(o => ak24An() ? `<button class="secondary" onclick='ak24Briefing(${mc24E(JSON.stringify({ objektId: o.id }))})'>🗒️ Gespräch vorbereiten</button><button onclick='ak24Abschluss(${mc24E(JSON.stringify({ objektId: o.id }))})'>✅ Gespräch abschließen</button>` : '');
MC24.akte.abschnitte.push(o => ak24MotivKarte(o));
MC24.akte.abschnitte.push(o => {
  if(!ak24An()) return '';
  const k = ob24Hauptkontakt(o, false);
  return `<div class="mc24-karte"><h3>Einwände <span class="sp"></span>${k ? `<button class="tiny" onclick="ak24EinwandDialog('${k.id}', null, '${o.id}')">+ Einwand</button>` : ''}</h3>${ak24EinwaendeHtml(ak24EinwaendeObjekt(o), k && k.id)}${!k ? '<div class="mc24-muted">Erst einen Kontakt verknüpfen.</div>' : ''}</div>`;
});
MC24.start.push(o => {
  if(!ak24An()) return null;
  const g = ak24Gespraeche({ objektId: o.id })[0];
  const fr = ((o.motivation || {}).offeneFragen || []).filter(f => f.blockiert && !f.erledigt);
  const l = [];
  if(g && g.naechsterSchritt) l.push({ ic: '➡️', t: `Vereinbart (${mc24Datum(g.datum)}): ${g.naechsterSchritt}${g.wann ? ' bis ' + mc24Datum(g.wann) : ''}` });
  fr.forEach(f => l.push({ ic: '⛔', t: 'Blockiert: ' + f.text, warn: true, a: `ak24MotivDialog('${o.id}')` }));
  return l;
});
MC24.lead.knoepfe.push(o => ak24An() ? `<button class="tiny secondary" onclick='ak24Briefing(${mc24E(JSON.stringify({ objektId: o.id }))})'>🗒️ Vorbereiten</button><button class="tiny" onclick='ak24Abschluss(${mc24E(JSON.stringify({ objektId: o.id }))})'>✅ Gespräch abschließen</button>` : '');
MC24.kontakt.abschnitte.push(k => {
  if(!ak24An()) return '';
  const ew = ak24Einwaende(k);
  return `<div class="ak24-imkontakt"><div class="mc24-knoepfe"><button class="tiny secondary" onclick='ak24Briefing(${mc24E(JSON.stringify({ kontaktId: k.id }))})'>🗒️ Gespräch vorbereiten</button><button class="tiny secondary" onclick='ak24Abschluss(${mc24E(JSON.stringify({ kontaktId: k.id }))})'>✅ Gespräch abschließen</button><button class="tiny secondary" onclick="ak24EinwandDialog('${k.id}')">+ Einwand</button></div>${ew.length ? `<div class="mc24-mini"><b>Einwände:</b> ${ew.map(x => `<a href="#" onclick="ak24EinwandDialog('${k.id}','${x.id}');return false;">${mc24E(ak24L(AK24_EINWAND, x.kategorie))}</a> (${mc24E(ak24L(AK24_EINWAND_STATUS, x.status))})`).join(' · ')}</div>` : ''}</div>`;
});
// Termin-Dialog: „Gespräch vorbereiten“
const _ak24TerminModal = oeffneTerminModal;
oeffneTerminModal = function(id){
  const r = _ak24TerminModal.apply(this, arguments);
  try{
    const t = id ? (db.termine || []).find(x => x.id === id) : null;
    if(ak24An() && t && (t.objektId || t.kontaktId)){
      const act = document.querySelector('#modalInner .modal-actions .right');
      if(act && !document.getElementById('ak24TerminBrief')) act.insertAdjacentHTML('afterbegin', `<button class="secondary" id="ak24TerminBrief" onclick='ak24Briefing(${mc24E(JSON.stringify({ terminId: t.id }))})'>🗒️ Gespräch vorbereiten</button>`);
    }
  }catch(e){}
  return r;
};
// Objektformular: „Gespräch vorbereiten“ neben dem Akten-Knopf
const _ak24ObjModal = oeffneObjektModal;
oeffneObjektModal = function(id){
  const r = _ak24ObjModal.apply(this, arguments);
  try{ const b = document.getElementById('mc24AkteBtn'); if(ak24An() && b && id) b.insertAdjacentHTML('beforeend', `<button class="secondary tiny" onclick='ak24Briefing(${mc24E(JSON.stringify({ objektId: id }))})'>🗒️ Gespräch vorbereiten</button>`); }catch(e){}
  return r;
};
// Seiten
const _ak24RenderMain = renderMain;
renderMain = function(){
  if(ak24An() && aktuelleAnsicht === 'heute') return ak24Render(document.getElementById('main'));
  if(ak24An() && aktuelleAnsicht === 'kooperationen') return ak24KoopRender(document.getElementById('main'));
  if(!ak24An() && (aktuelleAnsicht === 'heute' || aktuelleAnsicht === 'kooperationen')) aktuelleAnsicht = 'akquise';
  return _ak24RenderMain.apply(this, arguments);
};
// Glocke
const _ak24Hinweise = tbHinweise;
tbHinweise = function(){
  const l = _ak24Hinweise.apply(this, arguments);
  try{ if(ak24An()){ const p = ak24Prioritaeten().liste.filter(x => x.faellig.rang <= 1); if(p.length) l.unshift({ k: 'heute24', ic: '☀️', t: `${p.length} Punkt${p.length === 1 ? '' : 'e'} für heute (Rückrufe, Zusagen, Aufgaben)`, s: 'Heute öffnen', f: `wechsleAnsicht('heute')` }); } }catch(e){}
  return l;
};
// Navigation: „Heute“ ganz oben, „Kooperationen“ nach „Hausverwaltungen“; Startseite „Heute“
const _ak24RenderNav = renderNav;
renderNav = function(){
  const r = _ak24RenderNav.apply(this, arguments);
  try{
    if(ak24An()){
      const p = ak24Prioritaeten().liste.filter(x => x.faellig.rang <= 1).length;
      const b = document.querySelector('.sb-item[onclick*="\'heute\'"] .sb-badge');
      if(!b && p){ const it = document.querySelector('.sb-item[onclick*="\'heute\'"]'); if(it) it.insertAdjacentHTML('beforeend', `<span class="sb-badge">${p}</span>`); }
    }
  }catch(e){}
  return r;
};
window.addEventListener('load', () => {
  try{
    if(!ak24An()) return;
    ak24Db();
    if(!NAV.some(n => n.key === 'heute')) NAV.unshift({ key: 'heute', label: 'Heute', icon: '☀️' });
    const i = NAV.findIndex(n => n.key === 'hausverwaltungen');
    if(!NAV.some(n => n.key === 'kooperationen')) NAV.splice(i >= 0 ? i + 1 : NAV.length, 0, { key: 'kooperationen', label: 'Kooperationen', icon: '🏢' });
    if(typeof IC === 'object'){ if(!IC.heute) IC.heute = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="4"/><path d="M12 2.5v2M12 19.5v2M2.5 12h2M19.5 12h2M5.3 5.3l1.4 1.4M17.3 17.3l1.4 1.4M5.3 18.7l1.4-1.4M17.3 6.7l1.4-1.4"/></svg>'; if(!IC.kooperationen) IC.kooperationen = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="8" width="8" height="13" rx="1"/><rect x="13" y="3" width="8" height="18" rx="1"/><path d="M6 12h2M6 16h2M16 7h2M16 11h2M16 15h2"/></svg>'; }
    if(aktuelleAnsicht === 'akquise') aktuelleAnsicht = 'heute';
    renderNav(); renderMain();
  }catch(e){ console.error('Akquise v24', e); }
});
