// ═══ MaklerCockpit v31 – Anschreib-Tage merken, nach 2 Wochen ohne Antwort zum Löschen vorschlagen ═══
// Jeder Lead bekommt o.angeschrieben = [{ am, art: 'anschreiben' | 'nachfassen' }] (aus Status, E-Mail-/Kleinanzeigen-Zeit, Nachfassen, Verlauf).
// Noch „angeschrieben“ (keine Antwort) und letzte Nachricht ≥ 28 Tage her → Hinweis (Glocke, Akquise, einmal täglich beim Start) und Auswahl zum Löschen.
// Gelöschte landen in einer Sperrliste (Link/Telefon/E-Mail): neue KI-Suchen legen sie nicht wieder an.
const AN31_TAGE = 14;   // v47: Pauls Wunsch – nach 2 Wochen ohne Antwort melden (vorher 4 Wochen)
const AN31_STATUS = ['email_geschrieben', 'kleinanzeigen_geschrieben'];
const AN31_TAG_MS = 864e5;
function an31Datum(ts){ return new Date(ts).toLocaleDateString('de-DE', { day: '2-digit', month: '2-digit', year: 'numeric' }); }
function an31VorTagen(ts){ return Math.floor((Date.now() - ts) / AN31_TAG_MS); }
// Anschreib-Tage aus allem zusammentragen, was schon gespeichert ist
function an31Erfassen(o){
  if(!o) return false;
  const liste = Array.isArray(o.angeschrieben) ? o.angeschrieben.slice() : [];
  const vorher = JSON.stringify(liste);
  const dazu = (am, art) => {
    am = Number(am); if(!am || am < 1e12 || am > Date.now() + 6e4) return;
    const nah = liste.find(x => Math.abs(x.am - am) < 10 * 6e4);
    if(nah){ if(art === 'nachfassen') nah.art = 'nachfassen'; return; }
    liste.push({ am, art });
  };
  (o.verlauf || []).forEach(v => { if(v && v.typ === 'email') dazu(v.ts, /^nachgefasst/i.test(String(v.text || '')) ? 'nachfassen' : 'anschreiben'); });
  if(o.nachgefasstAm) dazu(o.nachgefasstAm, 'nachfassen');
  if(o.emailAm) dazu(o.emailAm, 'anschreiben');
  if(o.kleinanzeigenAm) dazu(o.kleinanzeigenAm, 'anschreiben');
  if(AN31_STATUS.includes(o.status)){
    if(o.statusAm) dazu(o.statusAm, 'anschreiben');
    if(!liste.length) dazu(Date.now(), 'anschreiben');   // Status von Hand gesetzt, ohne Zeitstempel
  }
  liste.sort((a, b) => a.am - b.am);
  // die erste Nachricht ist immer ein Anschreiben
  if(liste.length && liste[0].art === 'nachfassen' && !(o.verlauf || []).some(v => v.typ === 'email' && !/^nachgefasst/i.test(String(v.text || '')))) liste[0].art = 'anschreiben';
  if(JSON.stringify(liste) === vorher) return false;
  o.angeschrieben = liste; return true;
}
function an31Letzte(o){ const l = o && o.angeschrieben; return l && l.length ? l[l.length - 1].am : 0; }
function an31Faellig(o){
  if(!o || !AN31_STATUS.includes(o.status) || o.favorit) return false;
  if(o.an31Spaeter && o.an31Spaeter > Date.now()) return false;
  const l = an31Letzte(o); return !!l && Date.now() - l >= AN31_TAGE * AN31_TAG_MS;
}
function an31Liste(){ return (db.objekte || []).filter(an31Faellig).sort((a, b) => an31Letzte(a) - an31Letzte(b)); }
function an31TageText(o){
  const l = o.angeschrieben || []; if(!l.length) return '';
  return l.map(x => (x.art === 'nachfassen' ? '🔁 ' : '✉️ ') + an31Datum(x.am)).join(' · ');
}
// beim Speichern mitlaufen (erfasst auch Status-Änderungen aus dem Objekt-Dialog)
const _an31Schreibe = _schreibe;
_schreibe = function(){ try{ (db.objekte || []).forEach(an31Erfassen); }catch(e){ console.error('an31', e); } return _an31Schreibe.apply(this, arguments); };

// ── Sperrliste: gelöschte Leads ohne Antwort nicht wieder anlegen ──
function an31Register(){ const a = akqDb(); if(!Array.isArray(a.ausgeschlossen)) a.ausgeschlossen = []; return a.ausgeschlossen; }
function an31Merken(o){
  const r = an31Register();
  r.push({ link: String(o.link || '').trim(), tel: akqTelNorm(aqTel(o) || ''), mail: String(aqMail(o) || '').trim().toLowerCase(), titel: String(aqTitel(o) || '').slice(0, 120), ort: String(o.ort || '').slice(0, 80), am: Date.now(), grund: 'angeschrieben, keine Antwort', angeschrieben: (o.angeschrieben || []).map(x => x.am) });
  if(r.length > 3000) r.splice(0, r.length - 3000);
}
const _an31Uebernehmen = akqUebernehmen;
akqUebernehmen = function(eintraege, quelleHinweis){
  const r = an31Register();
  if(!r.length) return _an31Uebernehmen.apply(this, arguments);
  const links = new Set(r.map(x => x.link).filter(Boolean)), tels = new Set(r.map(x => x.tel).filter(t => t && t.length >= 7)), mails = new Set(r.map(x => x.mail).filter(Boolean));
  const raus = [], rest = (eintraege || []).filter(e => {
    const l = String(e.link || '').trim(), t = akqTelNorm(e.telefon || ''), m = String(e.email || '').trim().toLowerCase();
    const treffer = (l && links.has(l)) || (t.length >= 7 && tels.has(t)) || (m && mails.has(m));
    if(treffer) raus.push(e); return !treffer;
  });
  const ber = _an31Uebernehmen.call(this, rest, quelleHinweis);
  if(raus.length){
    try{ ber.ausgeschlossen = raus.length; }catch(e){}
    setTimeout(() => akqToast(`${raus.length} schon früher angeschrieben${raus.length === 1 ? 'er' : 'e'} Lead${raus.length === 1 ? '' : 's'} ohne Antwort übersprungen`, 4500), 1600);
  }
  return ber;
};

// ── Auswahl zum Löschen ──
function an31Dialog(){
  const l = an31Liste();
  if(!l.length){ akqToast('Keine angeschriebenen Leads, die seit 2 Wochen auf Antwort warten'); return; }
  const e = s => mc24E(s);
  const zeilen = l.map(o => `<label class="an31-zeile"><input type="checkbox" class="an31-wahl" value="${o.id}" checked onchange="an31Zaehlen()">
      <div class="an31-info"><b>${e(aqTitel(o) || o.adresse || 'Lead')}</b>
        <div class="mc24-muted">${e([aqOrtKurz(o), o.objektart, o.quelle].filter(Boolean).join(' · '))}${o.kaufpreis ? ' · ' + Number(o.kaufpreis).toLocaleString('de-DE') + ' €' : ''}</div>
        <div class="an31-tage">${e(an31TageText(o))} <span class="an31-vor">– zuletzt vor ${an31VorTagen(an31Letzte(o))} Tagen</span></div></div>
      ${ex29Url(o) ? `<a href="#" class="an31-link" onclick="event.preventDefault();event.stopPropagation();window.open('${mc24E(ex29Url(o)).replace(/'/g, '%27')}','_blank')">Anzeige ↗</a>` : ''}</label>`).join('');
  mc24Modal(`<h3>🗑 Angeschrieben – seit 2 Wochen keine Antwort</h3>
    <p>Diese Leads hast du angeschrieben, die letzte Nachricht ist mindestens 2 Wochen her und es kam nichts zurück. <b>Haken = wird gelöscht.</b></p>
    <div class="an31-alle"><button class="secondary tiny" onclick="an31AlleSetzen(true)">Alle auswählen</button><button class="secondary tiny" onclick="an31AlleSetzen(false)">Keine</button><span class="mc24-muted" id="an31Zahl"></span></div>
    <div class="an31-liste">${zeilen}</div>
    <p class="mc24-muted" style="font-size:12px;">Gelöschte Leads legt das Cockpit bei neuen Suchen nicht wieder an (gleicher Link, gleiche Nummer oder E-Mail). Nicht ausgewählte fragt es in 2 Wochen noch einmal.</p>
    <button class="an31-gross" id="an31Los" onclick="an31Loeschen()">🗑 Leads löschen</button>
    <div class="modal-actions"><span></span><div class="right"><button class="secondary" onclick="schliesseModal()">Später</button></div></div>`, 640);
  an31Zaehlen();
}
function an31AlleSetzen(an){ document.querySelectorAll('.an31-wahl').forEach(c => { c.checked = an; }); an31Zaehlen(); }
function an31Zaehlen(){
  const n = document.querySelectorAll('.an31-wahl:checked').length, alle = document.querySelectorAll('.an31-wahl').length;
  const b = document.getElementById('an31Los'); if(b){ b.textContent = n ? `🗑 ${n} Lead${n === 1 ? '' : 's'} löschen` : 'Nichts ausgewählt'; b.disabled = !n; }
  const z = document.getElementById('an31Zahl'); if(z) z.textContent = `${n} von ${alle} ausgewählt`;
}
function an31Loeschen(){
  const ja = Array.from(document.querySelectorAll('.an31-wahl:checked')).map(c => c.value);
  const nein = Array.from(document.querySelectorAll('.an31-wahl:not(:checked)')).map(c => c.value);
  an31LoeschenIds(ja, nein);
}
function an31AlleLoeschen(){   // v47: „Alle löschen?“ direkt aus Meldung, Balken oder Glocke
  const ids = an31Liste().map(o => o.id); if(!ids.length){ akqToast('Nichts mehr zu löschen'); an31KarteWeg(); return; }
  bestaetigeUnten(`Alle ${ids.length} Lead${ids.length === 1 ? '' : 's'} ohne Rückmeldung seit 2 Wochen löschen? Sie werden bei neuen Suchen nicht wieder angelegt.`, () => { an31KarteWeg(); an31LoeschenIds(ids, []); }, `🗑 Alle ${ids.length} löschen`);
}
function an31LoeschenIds(ja, nein){
  if(!ja.length) return;
  let n = 0;
  for(const id of ja){
    const o = findObjekt(id); if(!o) continue;
    const eig = o.eigentuemerId;
    try{ an31Merken(o); }catch(e){}
    try{ akqVerworfenMerken(o); }catch(e){}
    try{ objektVerknuepfungenAufraeumen(id); }catch(e){}
    db.objekte = db.objekte.filter(x => x.id !== id);
    try{ eigentuemerMitloeschenFallsVerwaist(eig); }catch(e){}
    n++;
  }
  const spaeter = Date.now() + 14 * AN31_TAG_MS;
  nein.forEach(id => { const o = findObjekt(id); if(o) o.an31Spaeter = spaeter; });
  if(typeof AQ2 !== 'undefined' && ja.includes(AQ2.sel)) AQ2.sel = null;
  save(); schliesseModal(); renderMain();
  try{ tbGlockeAktualisieren(); }catch(e){}
  an31KarteWeg();
  akqToast(`🗑 ${n} Lead${n === 1 ? '' : 's'} gelöscht${nein.length ? ` · ${nein.length} behalten (Nachfrage in 2 Wochen)` : ''}`, 4500);
}
function an31Einzeln(id){
  const o = findObjekt(id); if(!o) return;
  bestaetigeUnten(`„${aqTitel(o) || 'Lead'}“ löschen? Seit ${an31VorTagen(an31Letzte(o))} Tagen keine Antwort – wird bei neuen Suchen nicht wieder angelegt.`, () => {
    const eig = o.eigentuemerId;
    try{ an31Merken(o); akqVerworfenMerken(o); objektVerknuepfungenAufraeumen(id); }catch(e){}
    db.objekte = db.objekte.filter(x => x.id !== id);
    try{ eigentuemerMitloeschenFallsVerwaist(eig); }catch(e){}
    if(AQ2.sel === id) AQ2.sel = null;
    save(); renderMain(); akqToast('🗑 Lead gelöscht');
  });
}

// ── Anzeige: Glocke, Akquise-Balken, Karte beim Start, Lead-Liste und Lead-Detail ──
const _an31Hinweise = tbHinweise;
tbHinweise = function(){
  const l = _an31Hinweise.apply(this, arguments);
  try{
    const n = an31Liste().length;
    if(n && (db.hinweisEinst || {}).an31 !== false) l.unshift({ k: 'an31', n, ic: '🗑', t: `${n} angeschriebene Lead${n === 1 ? '' : 's'} seit 2 Wochen ohne Antwort`, s: 'Zum Löschen auswählen', f: 'an31Dialog()' });
  }catch(e){}
  return l;
};
function an31BalkenSetzen(){
  const liste = document.getElementById('aqListe'); if(!liste) return;
  let b = document.getElementById('an31Balken');
  const n = an31Liste().length;
  if(!n){ if(b) b.remove(); return; }
  if(!b){ b = document.createElement('div'); b.id = 'an31Balken'; const vor = document.getElementById('ex29Balken') || liste; vor.parentNode.insertBefore(b, vor); }
  b.innerHTML = `<div class="an31-balken"><div><b>🗑 ${n} Lead${n === 1 ? '' : 's'} seit 2 Wochen ohne Antwort</b><div class="mc24-muted">Angeschrieben, aber keine Reaktion – aufräumen?</div></div>
    <div class="an31-knoepfe"><button class="an31-gross klein" onclick="an31AlleLoeschen()">🗑 Alle löschen?</button><button class="secondary tiny" onclick="an31Dialog()">Einzeln auswählen</button></div></div>`;
}
function an31KarteZeigen(){
  const n = an31Liste().length; if(!n) return;
  const a = akqDb(), heute = new Date().toISOString().slice(0, 10);
  if(a.an31GezeigtAm === heute || document.getElementById('an31Karte')) return;
  a.an31GezeigtAm = heute; save();
  const k = document.createElement('div'); k.id = 'an31Karte'; k.className = 'an31-karte';
  k.innerHTML = `<div class="an31-karte-t">🗑 <b>${n} Lead${n === 1 ? '' : 's'}</b> seit 2 Wochen ohne Antwort</div><div class="mc24-muted">Du hast ${n === 1 ? 'ihn' : 'sie'} angeschrieben, es kam nichts zurück.</div>
    <div class="an31-karte-k"><button class="an31-gross" onclick="an31AlleLoeschen()">🗑 Alle löschen?</button><button class="secondary" onclick="an31KarteWeg();an31Dialog()">Ansehen</button><button class="secondary" onclick="an31KarteWeg()">Später</button></div>`;
  document.body.appendChild(k);
}
function an31KarteWeg(){ const k = document.getElementById('an31Karte'); if(k) k.remove(); }
const _an31Liste = aq2Liste;
aq2Liste = function(){
  const r = _an31Liste.apply(this, arguments);
  try{
    an31BalkenSetzen();
    document.querySelectorAll('#aqListe .lc').forEach(karte => {
      const o = findObjekt(String(karte.id || '').replace(/^lc-/, '')); if(o) an31Erfassen(o); if(!o || !(o.angeschrieben || []).length || !AN31_STATUS.includes(o.status)) return;
      const rechts = karte.querySelector('.lc-rechts'); if(!rechts || rechts.querySelector('.an31-am')) return;
      const t = an31Letzte(o), f = an31Faellig(o);
      rechts.insertAdjacentHTML('beforeend', `<span class="an31-am${f ? ' alt' : ''}" title="${mc24E(an31TageText(o))}">${(o.angeschrieben.slice(-1)[0].art === 'nachfassen' ? '🔁 nachgefasst ' : '✉️ angeschrieben ') + an31Datum(t)} · vor ${an31VorTagen(t)} T.</span>`);
    });
  }catch(e){ console.error('an31 Liste', e); }
  return r;
};
const _an31Detail = aq2Detail;
aq2Detail = function(){
  const r = _an31Detail.apply(this, arguments);
  try{
    const o = findObjekt(AQ2.sel); if(o) an31Erfassen(o); const tags = document.querySelector('#aqDetail .lc-tags');
    if(o && tags && (o.angeschrieben || []).length && !document.querySelector('#aqDetail .an31-box')){
      const f = an31Faellig(o), wartet = AN31_STATUS.includes(o.status);
      tags.insertAdjacentHTML('afterend', `<div class="an31-box${f ? ' alt' : ''}"><div><b>Angeschrieben:</b> ${mc24E(an31TageText(o))}</div>
        ${wartet ? `<div class="mc24-muted">Letzte Nachricht vor ${an31VorTagen(an31Letzte(o))} Tagen${f ? ' – seit 2 Wochen keine Antwort' : ' – ab ' + an31Datum(an31Letzte(o) + AN31_TAGE * AN31_TAG_MS) + ' Vorschlag zum Löschen'}</div>` : ''}
        ${f ? `<button class="an31-gross klein" onclick="an31Einzeln('${o.id}')">🗑 Lead löschen</button>` : ''}</div>`);
    }
  }catch(e){ console.error('an31 Detail', e); }
  return r;
};
window.addEventListener('load', () => {
  try{ let n = 0; (db.objekte || []).forEach(o => { if(an31Erfassen(o)) n++; }); if(n) save(); }catch(e){ console.error('an31', e); }
  setTimeout(() => { try{ an31KarteZeigen(); tbGlockeAktualisieren(); }catch(e){} }, 3500);
});
