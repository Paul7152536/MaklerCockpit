# ── v36: Prompts in den eingebetteten Werkzeugen (Jarvis, Shooting, Marktanalyse) verlangen das Ergebnis als Kopierblock ──
_HINWEIS36 = '\n\n---\nAUSGABE ZUM KOPIEREN: Ich will das Ergebnis kopieren und ins MaklerCockpit übernehmen. Gib es deshalb am Ende vollständig in einem Codeblock aus (zwischen ``` und ```). Ist oben ein bestimmtes Format verlangt (z. B. JSON, Liste oder JARVIS-IMPORT … JARVIS-ENDE), genau dieses Format im Codeblock verwenden. Erklärungen und Hinweise bitte außerhalb des Codeblocks.'
_KERN36 = 'var H36=' + json.dumps(_HINWEIS36, ensure_ascii=False) + ';var zu36=window.zu36=function(t){return (typeof t==="string"&&t.trim()&&t.indexOf("AUSGABE ZUM KOPIEREN")<0)?t.replace(/\\s+$/,"")+H36:t;};'
_JV36 = """
var flag36=false;
if(typeof promptErzeugen==="function"){var pe36=promptErzeugen;promptErzeugen=function(){var t=pe36.apply(this,arguments);return flag36?zu36(t):t;};}
if(typeof promptKopieren==="function"){var pk36=promptKopieren;promptKopieren=function(){flag36=true;try{return pk36.apply(this,arguments);}finally{flag36=false;}};}
if(typeof mrPrompt==="function"){var mp36=mrPrompt;mrPrompt=function(){var t=mp36.apply(this,arguments);return flag36?zu36(t):t;};}
if(typeof mrPromptKopieren==="function"){var mk36=mrPromptKopieren;mrPromptKopieren=function(){flag36=true;try{return mk36.apply(this,arguments);}finally{flag36=false;}};}
if(typeof handPrompt==="function"&&typeof kopieren==="function"){var hp36=handPrompt;handPrompt=function(){var k=kopieren;kopieren=function(t,m){return k.call(this,zu36(t),m);};try{return hp36.apply(this,arguments);}finally{kopieren=k;}};}"""
_BP36 = ''
for name, js in [('JV_HTML', _KERN36 + _JV36), ('SH_HTML', _KERN36 + _BP36), ('MA_HTML', _KERN36 + _BP36)]:
    a = s.index('const '+name+' = '); b = s.index('\n', a)
    lit = s[a+len('const '+name+' = '):b].rstrip(';')
    html = json.loads(lit)
    if name in ('SH_HTML', 'MA_HTML'):
        alt36 = "const p=buildPrompt(reportText(),notes());"
        assert html.count(alt36) == 1, (name, html.count(alt36))
        html = html.replace(alt36, "const p=window.zu36(buildPrompt(reportText(),notes()));")
    k = html.rindex('</body>')
    html = html[:k] + '<script>/* v36 Kopierblock */\n(function(){' + js + '\n})();</script>\n' + html[k:]
    s = s[:a] + 'const '+name+' = ' + json.dumps(html, ensure_ascii=False).replace('</', '<\\/') + ';' + s[b:]
