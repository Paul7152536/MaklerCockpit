/* MaklerCockpit v20 – Extras
   1) Automatische Sicherung in einen Cloud-Ordner (OneDrive, Google Drive, Dropbox, USB …)
   2) Anschreiben-Vorlagen: E-Mail, Kurznachricht (Kleinanzeigen & Portale), Nachfassen
   3) Preis gesenkt: Verlauf, Hervorhebung, Filter, Hinweis in der Glocke
   4) Preis-Check am Lead (€/m² gegen Marktdaten) + „Genau prüfen“ in der Marktanalyse
   5) Auswertung nach Quelle */

const X20 = { si:{ laeuft:false, ziele:null, liste:[], erreichbar:null }, vorl:{ tab:'email', e:null, feld:'vlText' }, ausw:{ tage:90 } };
function x20Modal(html, breit){
  if(typeof gsModal === 'function') return gsModal(html, breit);
  const i = document.getElementById('modalInner'); i.innerHTML = html;
  if(breit){ i.style.width = breit + 'px'; i.style.maxWidth = '94vw'; }
  document.getElementById('modalBg').classList.add('show');
}
function x20Offen(id){ const bg = document.getElementById('modalBg'); return !!(bg && bg.classList.contains('show') && document.getElementById(id)); }
function x20Wann(ts){
  if(!ts) return 'noch nie';
  const d = new Date(ts), h = new Date();
  const tage = Math.round((new Date(h.toDateString()) - new Date(d.toDateString())) / 864e5);
  const uhr = d.toLocaleTimeString('de-DE', { hour:'2-digit', minute:'2-digit' });
  return tage === 0 ? 'heute ' + uhr : tage === 1 ? 'gestern ' + uhr : d.toLocaleDateString('de-DE') + ' ' + uhr;
}
const x20Zahl = n => Math.round(Number(n) || 0).toLocaleString('de-DE');

// ═════════ 1) Automatische Sicherung ═════════
const SI_ABSTAND = 4 * 36e5;                       // alle 4 Stunden, solange das Programm offen ist
function siCfg(){ if(!db.sicherung || typeof db.sicherung !== 'object') db.sicherung = {}; return db.sicherung; }
function siVerfuegbar(){ return !!(window.pc && typeof window.pc.sicherung === 'function'); }
function siAktiv(){ const c = db.sicherung; return !!(c && c.ziel && !c.aus); }
function siFaellig(){
  if(!siVerfuegbar() || !siAktiv() || X20.si.laeuft) return false;
  const c = siCfg(), jetzt = Date.now();
  if(c.fehlerAm && jetzt - c.fehlerAm < 30 * 60 * 1000) return false;   // nach Fehler: in 30 Min. neu versuchen
  return !c.letzte || jetzt - c.letzte > SI_ABSTAND;
}
async function siJetzt(grund){
  if(!siVerfuegbar()) return { ok:false, fehler:'Die Sicherung gibt es nur in der PC-Version.' };
  const c0 = siCfg();
  if(!c0.ziel){ siAssistent(); return { ok:false, fehler:'Noch kein Sicherungsordner gewählt.' }; }
  if(X20.si.laeuft) return { ok:false, code:'laeuft' };
  X20.si.laeuft = true; siModalNeu();
  try{ if(typeof _saveTimer !== 'undefined' && _saveTimer){ clearTimeout(_saveTimer); _schreibe(); } }catch(e){}   // letzten Stand erst auf die Platte
  let r;
  try{ r = await window.pc.sicherung('jetzt', { ziel:c0.ziel, unterlagen: c0.unterlagen !== false }); }
  catch(e){ r = { ok:false, fehler:String((e && e.message) || e) }; }
  X20.si.laeuft = false;
  const c = siCfg();                                  // db kann inzwischen neu geklont sein
  if(r && r.ok){ c.letzte = r.zeit || Date.now(); c.fehler = ''; c.fehlerAm = 0; c.ordner = r.ordner || ''; c.dateien = r.unterlagenGesamt || 0; }
  else if(!(r && r.code === 'laeuft')){ c.fehler = (r && r.fehler) || 'unbekannter Fehler'; c.fehlerAm = Date.now(); }
  save();
  try{ tbGlockeAktualisieren(); }catch(e){}
  siModalNeu();
  if(grund !== 'auto') akqToast(r && r.ok ? '☁️ Gesichert' + (r.kopiert ? ' · ' + r.kopiert + ' Unterlage' + (r.kopiert === 1 ? '' : 'n') + ' neu kopiert' : '') : '⚠️ ' + ((r && r.fehler) || 'Sicherung fehlgeschlagen'), 3800);
  return r;
}
async function siAssistent(){
  if(!siVerfuegbar()){ alert('Die automatische Sicherung gibt es nur in der PC-Version.'); return; }
  X20.si.ziele = null; X20.si.erreichbar = null;
  siModalZeigen();
  try{ const r = await window.pc.sicherung('ziele'); X20.si.ziele = (r && r.ok && Array.isArray(r.ziele)) ? r.ziele : []; }catch(e){ X20.si.ziele = []; }
  const c = siCfg();
  if(c.ziel){ try{ const r = await window.pc.sicherung('pruefen', { ziel:c.ziel }); X20.si.erreichbar = !!(r && r.da); }catch(e){} }
  siModalNeu();
}
function siModalNeu(){ if(x20Offen('siModal')) siModalZeigen(); }
function siModalZeigen(){
  const c = siCfg(), z = X20.si.ziele;
  const gleich = (a, b) => String(a || '').toLowerCase() === String(b || '').toLowerCase();
  const liste = (z || []).slice();
  if(c.ziel && !liste.some(x => gleich(x.pfad, c.ziel))) liste.push({ name: c.name || 'Eigener Ordner', pfad: c.ziel });
  X20.si.liste = liste;
  let status;
  if(!c.ziel) status = `<div class="gs-hinweis">Noch nicht eingerichtet – wähle unten, wohin gesichert werden soll.</div>`;
  else if(c.aus) status = `<div class="gs-hinweis">⏸ Ausgeschaltet – es wird nicht mehr automatisch gesichert.</div>`;
  else if(X20.si.erreichbar === false) status = `<div class="gs-fehler">⚠️ Der Ordner ist gerade nicht erreichbar: ${akqEsc(c.ziel)}<br><small>Läuft OneDrive / Google Drive? Ist der USB-Stick eingesteckt?</small></div>`;
  else if(c.fehler) status = `<div class="gs-fehler">⚠️ ${akqEsc(c.fehler)}</div>`;
  else status = `<div class="gs-ok">✅ Aktiv – ${akqEsc(c.name || 'Ordner')}<br><small>${akqEsc(c.ordner || c.ziel)} · letzte Sicherung: ${x20Wann(c.letzte)}${c.dateien ? ' · ' + c.dateien + ' Unterlagen' : ''}</small></div>`;
  const optionen = z === null ? '<div class="gs-hinweis">🔍 Suche Cloud-Ordner auf diesem PC …</div>'
    : liste.length ? liste.map((x, i) => `<label class="gs-chk si-ziel"><input type="radio" name="siZiel" ${gleich(x.pfad, c.ziel) ? 'checked' : ''} onchange="siZielSetzen(${i})"><span>${akqEsc(x.name)}<small>${akqEsc(x.pfad)}</small></span></label>`).join('')
    : `<div class="gs-hinweis">Kein Cloud-Ordner gefunden. Tipp: <b>OneDrive</b> ist bei Windows dabei – einmal mit dem Microsoft-Konto anmelden, dann taucht es hier auf. Oder „Google Drive für Desktop“ installieren. Ein USB-Stick geht auch („Anderen Ordner wählen“).</div>`;
  x20Modal(`<div id="siModal"><h3>☁️ Automatische Sicherung</h3>
    <div class="gs-intro">Deine Daten liegen nur auf diesem PC. Das Cockpit legt zusätzlich automatisch eine Kopie in einen Cloud-Ordner – beim Start und danach alle 4 Stunden, solange das Programm offen ist. Geht der PC kaputt, ist nichts verloren. Kostet nichts extra.</div>
    ${status}
    <div class="si-titel">Wohin sichern?</div>
    ${optionen}
    <button class="secondary tiny" style="margin-top:8px;" onclick="siOrdnerWaehlen()">📁 Anderen Ordner wählen …</button>
    <label class="gs-chk"><input type="checkbox" ${c.unterlagen !== false ? 'checked' : ''} onchange="siCfg().unterlagen=this.checked;save()"><span>Unterlagen mitsichern (PDFs, Fotos, Grundrisse …)<small>Neue und geänderte Dateien werden jeweils dazukopiert</small></span></label>
    <div class="gs-tipp"><b>Wiederherstellen</b> (z. B. auf einem neuen PC): ⚙ → „Daten importieren (JSON)“ → im Ordner <b>MaklerCockpit-Sicherung</b> die Datei <b>daten-aktuell.json</b> wählen. Den Ordner „Unterlagen“ von dort nach Dokumente\\MaklerCockpit kopieren. Im Unterordner „Daten“ liegt außerdem für jeden der letzten 30 Tage ein Stand.<br>Die Google-Kalender-Verbindung wird aus Sicherheitsgründen nicht mitgesichert – nach dem Wiederherstellen einfach neu verbinden.</div>
    <div class="modal-actions"><div class="gs-knoepfe">${c.ziel ? `<button onclick="siJetzt()" ${X20.si.laeuft ? 'disabled' : ''}>${X20.si.laeuft ? '⏳ Sichert …' : '☁️ Jetzt sichern'}</button><button class="secondary" onclick="siOrdnerOeffnen()">Ordner öffnen</button>${c.aus ? `<button class="secondary" onclick="siEinschalten()">Wieder einschalten</button>` : `<button class="secondary" onclick="siAusschalten()">Ausschalten</button>`}` : ''}</div><div class="right"><button class="secondary" onclick="schliesseModal()">Fertig</button></div></div></div>`, 640);
}
async function siZielSetzen(i){
  const x = (X20.si.liste || [])[i]; if(!x) return;
  const c = siCfg();
  c.ziel = x.pfad; c.name = x.name; c.aus = false; c.fehler = ''; c.fehlerAm = 0; c.letzte = 0; c.ordner = '';
  save(); X20.si.erreichbar = true; siModalNeu();
  return siJetzt('einrichten');
}
async function siOrdnerWaehlen(){
  let r; try{ r = await window.pc.sicherung('waehlen'); }catch(e){ r = { ok:false, fehler:String((e && e.message) || e) }; }
  if(!r || !r.ok){ if(r && r.fehler) akqToast('⚠️ ' + r.fehler, 5000); return; }
  X20.si.liste = (X20.si.liste || []).concat([{ name: r.name || 'Eigener Ordner', pfad: r.pfad }]);
  return siZielSetzen(X20.si.liste.length - 1);
}
async function siOrdnerOeffnen(){
  const c = siCfg(); let r;
  try{ r = await window.pc.sicherung('oeffnen', { ziel:c.ziel }); }catch(e){ r = { ok:false, fehler:String(e) }; }
  if(!r || !r.ok) akqToast('⚠️ ' + ((r && r.fehler) || 'Ordner nicht gefunden') + ' – erst einmal „Jetzt sichern“.');
}
function siAusschalten(){ siCfg().aus = true; save(); siModalNeu(); try{ tbGlockeAktualisieren(); }catch(e){} akqToast('Automatische Sicherung ausgeschaltet'); }
function siEinschalten(){ siCfg().aus = false; save(); siModalNeu(); siJetzt(); }

// ═════════ 2) Anschreiben-Vorlagen ═════════
const AKQ_VORL_STD = {
  email: { betreff:'Ihre Anzeige: {objekt} in {ort}', text: AKQ_VORLAGE_STD },
  kurz: { betreff:'', text:`Hallo{anrede},

ich habe Ihre Anzeige „{objekt}“ in {ort} gesehen. Ich bin Paul Görner, Immobilienmakler bei BETTERHOMES in Berlin. Falls Sie beim Verkauf Unterstützung möchten – z. B. bei der Preisfindung oder der Auswahl geprüfter Käufer –, melde ich mich gern kurz telefonisch. Wenn nicht, ist das völlig in Ordnung.

Viele Grüße
Paul Görner` },
  nachfassen: { betreff:'Nochmal zu Ihrer Anzeige: {objekt}', text:`Hallo{anrede},

ich hatte Ihnen vor ein paar Tagen wegen Ihrer Anzeige „{objekt}“ in {ort} geschrieben. Ist das Objekt noch zu haben?

Falls der Verkauf noch nicht so läuft wie gewünscht, schaue ich mir gern unverbindlich an, woran es liegen könnte – Preis, Präsentation oder Zielgruppe. Ein kurzes Telefonat reicht dafür.

Viele Grüße
Paul Görner
BETTERHOMES · Görner Immobilien` }
};
const AKQ_VORL_ARTEN = [
  { k:'email', titel:'✉️ E-Mail', kurz:'E-Mail', sub:'Erstes Anschreiben, wenn eine E-Mail-Adresse da ist – öffnet dein E-Mail-Programm mit Betreff und Text.', betreff:true },
  { k:'kurz', titel:'💬 Kleinanzeigen & Portale', kurz:'Kurznachricht', sub:'Kurze Nachricht für Kleinanzeigen, ImmoScout & Co. – wird kopiert, die Anzeige öffnet sich, dort einfügen und senden.', betreff:false },
  { k:'nachfassen', titel:'🔁 Nachfassen', kurz:'Nachfassen', sub:'Wenn nach ein paar Tagen keine Antwort kam – wird automatisch genommen, wenn der Lead auf „E-Mail geschrieben“ oder „Kleinanzeigen angeschrieben“ steht.', betreff:true }
];
const AKQ_PLATZHALTER = [['{anrede}','Leerzeichen + Name, wenn bekannt – sonst leer. Beispiel: „Guten Tag{anrede},“'], ['{name}','Name des Verkäufers'], ['{objekt}','Anzeigentitel'], ['{ort}','Ort (ohne PLZ)'], ['{quelle_satz}','z. B. „ (Kleinanzeigen)“ oder Zeitung mit Datum'], ['{preis}','Angebotspreis'], ['{datum}','Eingestellt am']];
function akqVorlagen(){
  const a = akqDb();
  if(!a.vorlagen || typeof a.vorlagen !== 'object'){
    const eigen = a.vorlage && String(a.vorlage).trim() && a.vorlage !== AKQ_VORLAGE_STD;   // bisher angepasste Vorlage übernehmen
    a.vorlagen = { email:{ betreff:AKQ_VORL_STD.email.betreff, text: eigen ? a.vorlage : AKQ_VORL_STD.email.text } };
  }
  ['email', 'kurz', 'nachfassen'].forEach(k => {
    const v = a.vorlagen[k] = Object.assign({}, AKQ_VORL_STD[k], a.vorlagen[k] || {});
    if(!String(v.text || '').trim()) v.text = AKQ_VORL_STD[k].text;
  });
  return a.vorlagen;
}
function aqOrtText(o){ return String((o && o.ort) || '').replace(/\b\d{5}\b/g, '').replace(/\s+/g, ' ').replace(/^[\s,–-]+|[\s,–-]+$/g, '').trim(); }
function akqVorlageAnwenden(t, o){
  o = o || {};
  const name = aqName(o) || '';
  const d = o.inseratDatum ? new Date(o.inseratDatum) : null, dOk = d && !isNaN(d);
  const qs = o.quelle === 'Zeitung' ? `(${o.quelleText || 'Zeitung'}${dOk ? ' vom ' + d.toLocaleDateString('de-DE') : ''})` : o.quelle === 'Kleinanzeigen' ? '(Kleinanzeigen)' : o.quelle === 'ImmoScout' ? '(Immobilienportal)' : '';
  const map = { anrede: name ? ' ' + name : '', name, objekt: o.akqTitel || o.adresse || o.objektart || 'Immobilie', ort: aqOrtText(o) || 'Ihrer Region',
    quelle_satz: qs ? ' ' + qs : '', preis: Number(o.kaufpreis) > 0 ? aqEur(o.kaufpreis) : '', datum: dOk ? d.toLocaleDateString('de-DE') : '' };
  return String(t || '').replace(/\{(anrede|name|objekt|ort|quelle_satz|preis|datum)\}/g, (m, k) => map[k]);
}
// Alte Funktion (Import, ältere Aufrufe) → jetzt über die E-Mail-Vorlage
akqVorlageFuellen = function(e){
  e = e || {};
  return akqVorlageAnwenden(akqVorlagen().email.text, { akqTitel:e.titel || '', objektart:e.objektart, ort:e.ort || e.lageRoh || '', quelle:e.quelle, quelleText:e.quelleText, inseratDatum:e.datum, verkaeuferName:e.name || '', kaufpreis:e.preis });
};
// Text für einen Lead: eigener Text (KI-Nachricht oder von Hand angepasst) hat Vorrang – außer beim Nachfassen
function aqAnschreiben(o, art, nurVorlage){
  const V = akqVorlagen(); art = V[art] ? art : 'email';
  const v = V[art];
  const betreff = akqVorlageAnwenden(v.betreff || V.email.betreff, o);
  if(!nurVorlage && art !== 'nachfassen' && o.anschreibenEigen === true && String(o.anschreibenText || '').trim()) return { art, betreff, text:o.anschreibenText, eigen:true };
  return { art, betreff, text:akqVorlageAnwenden(v.text, o), eigen:false };
}
function aqIstLead(o){ return !!(o && o.id && (o.importId || o.akqTitel || o.link || o.quelleText || o.inseratDatum || ['Kleinanzeigen', 'ImmoScout', 'Zeitung'].includes(o.quelle))); }
function aqAnschreibenStandard(o){ return aqIstLead(o) ? aqAnschreiben(o, 'email', true).text : ANSCHREIBEN_TEXT; }
// Einmalig: Texte, die nur aus der alten Vorlage erzeugt wurden, wieder an die Vorlage koppeln
function akqAnschreibenMigrieren(){
  const a = akqDb(); if(a.anschreibenMig20) return 0;
  const muster = [a.vorlage || AKQ_VORLAGE_STD, AKQ_VORLAGE_STD].map(t => new RegExp('^' + String(t).replace(/\r/g, '').replace(/[.*+?^${}()|[\]\\]/g, '\\$&').replace(/\\\{(anrede|objekt|ort|quelle_satz)\\\}/g, '[\\s\\S]*?') + '$'));
  let n = 0;
  (db.objekte || []).forEach(o => {
    if(o.anschreibenEigen !== undefined || !aqIstLead(o)) return;
    const t = String(o.anschreibenText || '').replace(/\r/g, '');
    if(!t.trim()) return;
    if(muster.some(r => r.test(t)) || t.trim() === String(ANSCHREIBEN_TEXT).trim()){ o.anschreibenText = ''; o.anschreibenEigen = false; n++; }
    else o.anschreibenEigen = true;
  });
  akqVorlagen();
  a.anschreibenMig20 = true; save();
  return n;
}
// Editor
function akqVorlageBearbeiten(tab){
  X20.vorl = { tab: AKQ_VORL_STD[tab] ? tab : 'email', e: JSON.parse(JSON.stringify(akqVorlagen())), feld:'vlText' };
  akqVorlageZeigen();
}
function akqVorlageProbe(){
  const o = (typeof AQ2 !== 'undefined' && AQ2.sel) ? findObjekt(AQ2.sel) : null;
  if(o) return { o, label:'mit dem gewählten Lead „' + aqTitel(o).slice(0, 40) + '“' };
  return { o:{ akqTitel:'Einfamilienhaus mit Garten', ort:'14612 Falkensee', quelle:'Kleinanzeigen', verkaeuferName:'Frau Schmidt', kaufpreis:489000, inseratDatum:new Date().toISOString() }, label:'Beispiel' };
}
function akqVorlageZeigen(){
  const S = X20.vorl, art = AKQ_VORL_ARTEN.find(a => a.k === S.tab) || AKQ_VORL_ARTEN[0], v = S.e[art.k], P = akqVorlageProbe();
  x20Modal(`<div id="vorlModal"><h3>✏️ Anschreiben-Vorlagen</h3>
    <div class="vl-tabs">${AKQ_VORL_ARTEN.map(a => `<button class="${a.k === S.tab ? 'an' : ''}" onclick="akqVorlageTab('${a.k}')">${a.titel}</button>`).join('')}</div>
    <div class="gs-intro" style="margin:10px 0 4px;">${akqEsc(art.sub)}</div>
    ${art.betreff ? `<div class="vl-lbl">Betreff</div><input id="vlBetreff" value="${akqEsc(v.betreff || '')}" onfocus="X20.vorl.feld='vlBetreff'" oninput="akqVorlageEingabe()">` : ''}
    <div class="vl-lbl">Text</div>
    <textarea id="vlText" style="min-height:220px;" onfocus="X20.vorl.feld='vlText'" oninput="akqVorlageEingabe()">${akqEsc(v.text || '')}</textarea>
    <div class="vl-chips"><span>Platzhalter einfügen:</span>${AKQ_PLATZHALTER.map(([p, t]) => `<button class="chip" title="${akqEsc(t)}" onmousedown="event.preventDefault()" onclick="akqVorlageEinfuegen('${p}')">${p}</button>`).join('')}</div>
    <div class="vl-lbl">Vorschau <small>${akqEsc(P.label)}</small></div>
    <div class="vl-vorschau" id="vlVorschau"></div>
    <div class="gs-hinweis">Hat die KI zu einer Anzeige schon eine eigene Nachricht geschrieben (oder hast du den Text im Objekt angepasst), wird dieser Text genommen – fürs Nachfassen immer die Vorlage.</div>
    <div class="modal-actions"><div><button class="secondary" onclick="akqVorlageStandard()">Standardtext</button></div><div class="right"><button class="secondary" onclick="schliesseModal()">Abbrechen</button><button onclick="akqVorlageSpeichern()">Speichern</button></div></div></div>`, 720);
  akqVorlageVorschau();
}
function akqVorlageEingabe(){
  const S = X20.vorl; if(!S.e) return;
  const v = S.e[S.tab], b = document.getElementById('vlBetreff'), t = document.getElementById('vlText');
  if(b) v.betreff = b.value; if(t) v.text = t.value;
  akqVorlageVorschau();
}
function akqVorlageVorschau(){
  const el = document.getElementById('vlVorschau'); if(!el) return;
  const S = X20.vorl, v = S.e[S.tab], art = AKQ_VORL_ARTEN.find(a => a.k === S.tab), P = akqVorlageProbe();
  const b = art && art.betreff ? akqVorlageAnwenden(v.betreff, P.o) : '';
  el.innerHTML = (b ? `<div class="vl-betreff">Betreff: ${akqEsc(b)}</div>` : '') + akqEsc(akqVorlageAnwenden(v.text, P.o));
}
function akqVorlageEinfuegen(p){
  const f = document.getElementById(X20.vorl.feld) || document.getElementById('vlText'); if(!f) return;
  const a = typeof f.selectionStart === 'number' ? f.selectionStart : f.value.length, b = typeof f.selectionEnd === 'number' ? f.selectionEnd : a;
  f.value = f.value.slice(0, a) + p + f.value.slice(b);
  f.focus(); f.selectionStart = f.selectionEnd = a + p.length;
  akqVorlageEingabe();
}
function akqVorlageTab(k){ akqVorlageEingabe(); X20.vorl.tab = k; X20.vorl.feld = 'vlText'; akqVorlageZeigen(); }
function akqVorlageStandard(){ const S = X20.vorl; S.e[S.tab] = JSON.parse(JSON.stringify(AKQ_VORL_STD[S.tab])); akqVorlageZeigen(); akqToast('Standardtext eingesetzt – mit „Speichern“ übernehmen'); }
function akqVorlageSpeichern(){
  akqVorlageEingabe();
  const a = akqDb(); a.vorlagen = JSON.parse(JSON.stringify(X20.vorl.e)); a.vorlage = a.vorlagen.email.text;
  save(); schliesseModal(); akqToast('✏️ Vorlagen gespeichert');
}
// Senden am Lead: E-Mail → Mailprogramm; ohne E-Mail → Kurznachricht kopieren + Anzeige öffnen; schon angeschrieben → Nachfassen
function aqNachfassenFaellig(o){ return ['email_geschrieben', 'kleinanzeigen_geschrieben'].includes(o.status); }
function aq2Senden(art){
  const o = findObjekt(AQ2.sel); if(!o) return;
  const mail = aqMail(o);
  art = art || (aqNachfassenFaellig(o) ? 'nachfassen' : mail ? 'email' : o.link ? 'kurz' : 'email');
  const A = aqAnschreiben(o, art);
  const ka = /kleinanzeigen|ebay-kleinanzeigen/i.test((o.link || '') + ' ' + (o.quelle || ''));
  const wahl = `<span class="vl-wahl">Anderen Text kopieren: ${AKQ_VORL_ARTEN.filter(a => a.k !== art).map(a => `<a href="#" onclick="aq2TextKopieren('${a.k}');return false;">${a.kurz}</a>`).join(' · ')} · <a href="#" onclick="akqVorlageBearbeiten('${art}');return false;">Vorlagen bearbeiten</a></span>`;
  const nein = `<button class="secondary" onclick="aq2ErgebnisZeigen('')">Nein</button>`;
  const frage = t => `<span style="font-size:12px;color:var(--muted);width:100%;">${t}</span>`;
  if(mail){
    window.open(`mailto:${encodeURIComponent(mail)}?subject=${encodeURIComponent(A.betreff)}&body=${encodeURIComponent(A.text)}`, '_blank');
    aq2ErgebnisZeigen(art === 'nachfassen'
      ? frage('E-Mail zum Nachfassen geöffnet – abgeschickt?') + `<button onclick="aq2Nachgefasst('E-Mail')">🔁 Ja, nachgefasst</button>` + nein + wahl
      : frage('E-Mail-Programm geöffnet – abgeschickt?') + `<button onclick="aq2StatusSetzen('email_geschrieben');akqToast('Status: E-Mail geschrieben')">✉️ Ja, geschrieben</button>` + nein + wahl);
    return A;
  }
  akqKopieren(A.text, o.link ? (art === 'nachfassen' ? 'Nachfass-Text kopiert – Anzeige wird geöffnet, dort einfügen' : 'Nachricht kopiert – Anzeige wird geöffnet, dort einfügen und senden')
    : o.chiffre ? 'Anschreiben kopiert – Antwort per Chiffre an die Zeitung' : 'Anschreiben kopiert (keine E-Mail-Adresse hinterlegt)');
  if(o.link) window.open(o.link, '_blank');
  if(art === 'nachfassen') aq2ErgebnisZeigen(frage(ka ? 'Bei Kleinanzeigen nachgefasst?' : 'Nachricht zum Nachfassen verschickt?') + `<button onclick="aq2Nachgefasst('${ka ? 'Kleinanzeigen' : 'Nachricht'}')">🔁 Ja, nachgefasst</button>` + nein + wahl);
  else if(ka) aq2ErgebnisZeigen(frage('Nachricht bei Kleinanzeigen verschickt?') + `<button onclick="aq2StatusSetzen('kleinanzeigen_geschrieben');akqToast('Status: Per Kleinanzeigen angeschrieben')">💬 Ja, angeschrieben</button>` + nein + wahl);
  else aq2ErgebnisZeigen(frage('Nachricht verschickt?') + `<button onclick="aq2StatusSetzen('email_geschrieben');akqToast('Status: E-Mail geschrieben')">✉️ Ja</button>` + nein + wahl);
  return A;
}
aq2Email = function(){ return aq2Senden(); };
function aq2TextKopieren(art){
  const o = findObjekt(AQ2.sel); if(!o) return;
  const A = aqAnschreiben(o, art), info = AKQ_VORL_ARTEN.find(a => a.k === art);
  akqKopieren(A.text, '„' + (info ? info.kurz : 'Text') + '“ kopiert ✓');
}
function aq2Nachgefasst(kanal){
  const o = findObjekt(AQ2.sel); if(!o) return;
  o.nachgefasst = (Number(o.nachgefasst) || 0) + 1; o.nachgefasstAm = Date.now();
  if(o.status === 'email_geschrieben') o.emailAm = Date.now();
  if(o.status === 'kleinanzeigen_geschrieben') o.kleinanzeigenAm = Date.now();
  aqLog(o, 'email', 'Nachgefasst' + (kanal ? ' per ' + kanal : '') + (o.nachgefasst > 1 ? ' (' + o.nachgefasst + '. Mal)' : ''));
  save(); aq2Neu();
  akqToast('🔁 Nachgefasst – kommt keine Antwort, erinnert die Glocke in 5 Tagen wieder');
}

// ═════════ 3) Preis gesenkt ═════════
function aqPreisInfo(o){
  const start = Number(o && o.preisStart) || 0, jetzt = Number(o && o.kaufpreis) || 0;
  if(!(start > 0 && jetzt > 0 && jetzt < start)) return null;
  const diff = start - jetzt;
  return { start, jetzt, diff, proz: Math.round(diff / start * 1000) / 10, am: Number(o.preisGesenktAm) || 0 };
}
function aqProz(p){ return String(p).replace('.', ','); }
function aqPreisChip(o){ const p = aqPreisInfo(o); return p ? `<span class="chip preis-ab" title="Preis gesenkt: vorher ${aqEur(p.start)}${p.am ? ', am ' + new Date(p.am).toLocaleDateString('de-DE') : ''}">📉 −${aqProz(p.proz)} %</span>` : ''; }
function aqPreisAltHtml(o){
  const p = aqPreisInfo(o); if(!p) return '';
  return `<div class="preis-alt">📉 Preis gesenkt: vorher <s>${aqEur(p.start)}</s> · −${aqEur(p.diff)} (−${aqProz(p.proz)} %)${p.am ? ' · am ' + new Date(p.am).toLocaleDateString('de-DE') : ''}</div>`;
}
// Preis von Hand im Objekt-Formular geändert → mit Verlauf merken; eigenen Anschreiben-Text erkennen
const _x20SpeichereObjekt = speichereObjekt;
speichereObjekt = function(id){
  const vorher = id ? findObjekt(id) : null;
  const altPreis = vorher ? Number(vorher.kaufpreis) || 0 : 0, altText = vorher ? String(vorher.anschreibenText || '') : '';
  let std = ''; try{ std = vorher ? aqAnschreibenStandard(vorher) : ''; }catch(e){}
  const r = _x20SpeichereObjekt.apply(this, arguments);
  try{
    const o = id ? findObjekt(id) : null;
    if(o){
      let neu = false;
      const neuPreis = Number(o.kaufpreis) || 0;
      if(altPreis > 0 && neuPreis > 0 && neuPreis !== altPreis){ o.kaufpreis = altPreis; akqPreisAendern(o, neuPreis, 'manuell'); neu = true; }
      const t = String(o.anschreibenText || ''), n = s => String(s || '').replace(/\s+/g, ' ').trim();
      if(t !== altText){
        if(!n(altText) && n(t) === n(std)) o.anschreibenText = '';             // nur der vorgeschlagene Text – bleibt an die Vorlage gekoppelt
        else { o.anschreibenEigen = !!n(t); if(!n(t)) o.anschreibenText = ''; }
        neu = true;
      }
      if(neu){ save(); renderMain(); }
    } else if(!id && aktuelleAnsicht === 'objekte' && X20.objFilter !== 'alle'){
      const n = (db.objekte || [])[db.objekte.length - 1];
      if(n && !objHatTermin(n)) akqToast('Gespeichert – das Objekt steht hier, sobald ein Termin eingetragen ist (bis dahin in der Akquise oder unter „Alle“).', 5000);
    }
  }catch(e){ console.error('v20 speichereObjekt', e); }
  return r;
};

// ═════════ 4) Preis-Check am Lead ═════════
let X20_PLZ = null;
function x20Norm(s){ s = String(s || '').toLowerCase().replace(/ä/g, 'ae').replace(/ö/g, 'oe').replace(/ü/g, 'ue').replace(/ß/g, 'ss'); return ' ' + s.replace(/[^a-z0-9]+/g, ' ').replace(/\s+/g, ' ').trim() + ' '; }
function aqGebietFinden(...texte){
  if(typeof MC_MARKT === 'undefined') return [null, ''];
  const G = MC_MARKT.gebiete;
  if(!X20_PLZ){ X20_PLZ = {}; for(const [gid, g] of Object.entries(G)) for(const p of (g.plz || [])) X20_PLZ[p] = gid; }
  const roh = texte.map(t => String(t || '')).join(' '), txt = x20Norm(roh);
  let best = null, bestLen = 0, bestWort = '';
  for(const [gid, g] of Object.entries(G)){
    for(const wort of (g.begriffe || []).concat([g.name])){
      const nw = x20Norm(wort); if(nw.trim().length < 3) continue;
      if(txt.includes(nw) && nw.length > bestLen){ best = gid; bestLen = nw.length; bestWort = wort; }
    }
  }
  for(const p of (roh.match(/\b(1[0-9]\d{3})\b/g) || [])){
    const gid = X20_PLZ[p];
    if(gid && (best === null || G[gid].land !== G[best].land || bestLen <= 7)) return [gid, 'PLZ ' + p];
  }
  if(best) return [best, '„' + bestWort + '“'];
  return [null, /\sberlin\s/.test(txt) ? 'Berlin (Bezirk unklar)' : 'Ort nicht erkannt'];
}
const AQ_HAUS_FAKTOR = { EFH:1, DHH:0.97, Reihenhaus:0.9 };
function aqMarktVergleich(o){
  if(!o || typeof MC_MARKT === 'undefined') return null;
  const art = o.objektart, haus = Object.prototype.hasOwnProperty.call(AQ_HAUS_FAKTOR, art), whg = art === 'Wohnung';
  if(!haus && !whg) return { geht:false, grund:'art' };
  const preis = Number(o.kaufpreis) || 0, fl = Number(o.wohnflaeche) || 0;
  if(o.auftragsart === 'vermietung' && preis < 20000) return { geht:false, grund:'miete' };
  let [gid, wie] = aqGebietFinden(o.ort, o.adresse);
  if(!gid) [gid, wie] = aqGebietFinden(o.ort, o.adresse, o.akqTitel);
  if(!gid) return { geht:false, grund:'gebiet', wie };
  const g = MC_MARKT.gebiete[gid];
  let m2 = 0, q = '';
  if(haus && g.efh){ m2 = g.efh * 0.95 * AQ_HAUS_FAKTOR[art]; q = 'Hauspreise ' + g.name + ' (Angebote −5 %' + (art === 'DHH' ? ', DHH −3 %' : art === 'Reihenhaus' ? ', Reihenhaus −10 %' : '') + ')'; }
  else if(whg && g.etwKauf){ m2 = g.etwKauf; q = 'Wohnungs-Kaufpreise ' + g.name + ' (echte Verkäufe)'; }
  else if(whg && g.etw){ m2 = g.etw * 0.95; q = 'Wohnungen ' + g.name + ' (Angebote −5 %)'; }
  if(!m2) return { geht:false, grund:'daten', name:g.name };
  const r = { geht:true, gid, name:g.name, wie, m2:Math.round(m2), q, stand:g.stand || MC_MARKT.stand };
  if(!(preis >= 20000)) return Object.assign(r, { fehlt:'preis' });
  if(!(fl >= 15)) return Object.assign(r, { fehlt:'flaeche' });
  r.ist = Math.round(preis / fl); r.abw = Math.round((preis / fl / m2 - 1) * 100); r.marktwert = Math.round(m2 * fl / 1000) * 1000;
  r.stufe = r.abw >= 25 ? 'hoch2' : r.abw >= 10 ? 'hoch' : r.abw <= -15 ? 'tief' : 'ok';
  return r;
}
const AQ_MV_TEXT = { hoch2:'deutlich über Markt – gute Chance, mit Preisberatung zu punkten', hoch:'etwas über Markt', ok:'im Marktrahmen', tief:'unter Markt – geht vermutlich schnell weg' };
function aqMarktChip(o){
  const m = aqMarktVergleich(o);
  if(!m || !m.geht || m.abw === undefined || Math.abs(m.abw) < 15) return '';
  return `<span class="chip ${m.abw > 0 ? 'mv-hoch' : 'mv-tief'}" title="${x20Zahl(m.ist)} €/m² · Markt ${akqEsc(m.name)} ≈ ${x20Zahl(m.m2)} €/m²">${m.abw > 0 ? '+' : '−'}${Math.abs(m.abw)} % zum Markt</span>`;
}
function aq2MarktHtml(o){
  const m = aqMarktVergleich(o);
  const knopf = `<button class="secondary tiny" onclick="aqMarktanalyse('${o.id}')">📊 Genau prüfen</button>`;
  const ein = Number(o.einschaetzung) > 0 ? `<div class="mv-ein">Deine Einschätzung: <b>${aqEur(o.einschaetzung)}</b>${Number(o.kaufpreis) > 0 ? ' · Angebot ' + (Number(o.kaufpreis) >= Number(o.einschaetzung) ? '+' : '−') + Math.abs(Math.round((Number(o.kaufpreis) / Number(o.einschaetzung) - 1) * 100)) + ' % dazu' : ''}</div>` : '';
  if(!m) return '';
  if(!m.geht){
    const t = m.grund === 'gebiet' ? 'Keine Marktdaten für diese Lage (' + akqEsc(m.wie) + ').' : m.grund === 'art' ? 'Für ' + akqEsc(o.objektart || 'diese Objektart') + ' gibt es keine €/m²-Schnellprüfung.' : m.grund === 'miete' ? 'Vermietung – keine Kaufpreis-Einordnung.' : 'Keine Marktdaten für ' + akqEsc(m.name || 'diese Lage') + '.';
    return `<div class="mv"><div class="mv-kopf"><span>📊 Preis-Check</span>${knopf}</div><div class="mv-sub">${t}</div>${ein}</div>`;
  }
  const quelle = `<div class="mv-sub">Grobe Einordnung · ${akqEsc(m.q)} · Stand ${akqEsc(m.stand)} · Lage erkannt über ${akqEsc(m.wie)}</div>`;
  if(m.fehlt) return `<div class="mv"><div class="mv-kopf"><span>📊 Preis-Check</span>${knopf}</div><div>Markt ${akqEsc(m.name)} ≈ <b>${x20Zahl(m.m2)} €/m²</b> – ${m.fehlt === 'flaeche' ? 'Wohnfläche fehlt für den Vergleich (✏️ ergänzen)' : 'kein Kaufpreis angegeben'}.</div>${quelle}${ein}</div>`;
  return `<div class="mv ${m.stufe}"><div class="mv-kopf"><span>📊 Preis-Check</span>${knopf}</div>
    <div><b>${x20Zahl(m.ist)} €/m²</b> · Markt ${akqEsc(m.name)} ≈ ${x20Zahl(m.m2)} €/m² → <span class="mv-abw">${m.abw > 0 ? '+' : m.abw < 0 ? '−' : '±'}${Math.abs(m.abw)} %</span> <span class="mv-txt">${AQ_MV_TEXT[m.stufe]}</span></div>
    <div class="mv-sub">Marktüblich wären etwa ${aqEur(m.marktwert)}.</div>${quelle}${ein}</div>`;
}
// „Genau prüfen“: Marktanalyse öffnet sich mit diesem Lead (Fläche, Baujahr, Preis, Objektart übernommen)
function aqMarktanalyse(id){ window.__maVorwahl = id || (typeof AQ2 !== 'undefined' ? AQ2.sel : null); wechsleAnsicht('immowert'); }
(function(){
  const H = window.__MA_HOST; if(!H) return;
  H.objekte = () => (db.objekte || []).map(o => ({ id:o.id, adresse:o.adresse, titel:o.akqTitel || '', ort:o.ort, objektart:o.objektart, auftragsart:o.auftragsart, wohnflaeche:o.wohnflaeche, grundstueck:o.grundstueck, baujahr:o.baujahr, kaufpreis:o.kaufpreis, einschaetzung:o.einschaetzung }));
  H.setEinschaetzung = (id, wert) => {
    const o = findObjekt(id); if(!o) return;
    const alt = Number(o.einschaetzung) || 0; o.einschaetzung = wert;
    if(alt !== Number(wert)){ try{ aqLog(o, 'info', '📊 Marktanalyse: Einschätzung ' + aqEur(wert) + (alt ? ' (vorher ' + aqEur(alt) + ')' : '')); }catch(e){} }
    save();
  };
  H.vorwahlHolen = () => { const v = window.__maVorwahl || null; window.__maVorwahl = null; return v; };
})();

// ═════════ 5) Auswertung nach Quelle ═════════
const AQ_QUELLE_IC = { Kleinanzeigen:'💬', ImmoScout:'🏢', Zeitung:'📰', Direktakquise:'🚪', Empfehlung:'🤝', Tippgeber:'💡', 'Social Media':'📱', Bestand:'📦', Sonstiges:'•' };
function aqStufe(o){                                // 0 neu · 1 kontaktiert · 2 Gespräch · 3 Termin · 4 Auftrag
  const s = o.status;
  if(['auftrag', 'online', 'abgeschlossen'].includes(s)) return 4;
  if(s === 'termin' || o.hatTermin) return 3;
  if(s === 'erstkontakt') return 2;
  if((s && s !== 'neu') || o.emailAm || o.kleinanzeigenAm || o.anrufVersuche) return 1;
  return 0;
}
function akqVerworfenMerken(o){
  if(!o) return;
  const a = akqDb(); a.verworfen = Array.isArray(a.verworfen) ? a.verworfen : [];
  let tel = false; try{ tel = !!aqTel(o); }catch(e){}
  a.verworfen.push({ quelle:o.quelle || 'Sonstiges', am:Date.now(), erstellt:o.createdAt || Date.now(), stufe:aqStufe(o), art:o.objektart || '', tel });
  if(a.verworfen.length > 3000) a.verworfen = a.verworfen.slice(-3000);
}
function aqAuswertungDaten(tage){
  const ab = tage ? Date.now() - tage * 864e5 : 0, Q = {};
  const zeile = q => Q[q] = Q[q] || { q, leads:0, tel:0, st:[0, 0, 0, 0, 0], weg:0 };
  (db.objekte || []).forEach(o => {
    if((o.createdAt || 0) < ab) return;
    const r = zeile(o.quelle || 'Sonstiges'); r.leads++; if(aqTel(o)) r.tel++;
    const s = aqStufe(o); for(let i = 1; i <= s; i++) r.st[i]++;
  });
  (akqDb().verworfen || []).forEach(v => {
    if((v.erstellt || v.am || 0) < ab) return;
    const r = zeile(v.quelle || 'Sonstiges'); r.leads++; r.weg++; if(v.tel) r.tel++;
    for(let i = 1; i <= (v.stufe || 0); i++) r.st[i]++;
  });
  const rows = Object.values(Q).sort((x, y) => y.leads - x.leads || x.q.localeCompare(y.q));
  const sum = rows.reduce((s, r) => ({ q:'Gesamt', leads:s.leads + r.leads, tel:s.tel + r.tel, st:s.st.map((v, i) => v + r.st[i]), weg:s.weg + r.weg }), { q:'Gesamt', leads:0, tel:0, st:[0, 0, 0, 0, 0], weg:0 });
  return { rows, sum };
}
function aqAuswertung(tage){
  if(tage !== undefined) X20.ausw.tage = tage;
  const T = X20.ausw.tage, { rows, sum } = aqAuswertungDaten(T);
  const pz = (z, n) => n ? Math.round(z / n * 100) + ' %' : '–';
  const zelle = (z, n) => `<td>${z}<small>${n ? pz(z, n) : ''}</small></td>`;
  const balken = r => { const n = r.leads || 1; return `<div class="aw-balken">${[1, 2, 3, 4].map(i => r.st[i] ? `<span class="s${i}" style="width:${Math.max(2, r.st[i] / n * 100)}%"></span>` : '').join('')}</div>`; };
  const zeileHtml = (r, summe) => `<tr class="${summe ? 'summe' : ''}"><td>${summe ? '' : (AQ_QUELLE_IC[r.q] || '•') + ' '}${akqEsc(r.q)}${balken(r)}</td><td>${r.leads}</td>${zelle(r.tel, r.leads)}${zelle(r.st[1], r.leads)}${zelle(r.st[2], r.leads)}${zelle(r.st[3], r.leads)}${zelle(r.st[4], r.leads)}<td>${r.weg || '–'}</td></tr>`;
  const fazit = [];
  if(!sum.leads) fazit.push('Im gewählten Zeitraum gibt es noch keine Leads.');
  else {
    fazit.push(`Die meisten Leads kommen aus <b>${akqEsc(rows[0].q)}</b> (${rows[0].leads} von ${sum.leads}).`);
    const gut = rows.filter(r => r.leads >= 5 && r.st[3]).sort((x, y) => y.st[3] / y.leads - x.st[3] / x.leads)[0];
    if(gut) fazit.push(`Die meisten Termine pro Lead bringt <b>${akqEsc(gut.q)}</b>: ${pz(gut.st[3], gut.leads)} der Leads führen zu einem Termin.`);
    else fazit.push('Für eine Aussage, welche Quelle Termine bringt, sind es noch zu wenige Termine – ab etwa 5 Leads pro Quelle wird es aussagekräftig.');
    const liegen = sum.leads - sum.st[1] - sum.weg;
    if(liegen > 0) fazit.push(`${liegen} Lead${liegen === 1 ? ' ist' : 's sind'} noch gar nicht kontaktiert.`);
  }
  x20Modal(`<div id="awModal"><h3>📈 Auswertung nach Quelle</h3>
    <div class="gs-intro" style="margin-bottom:6px;">Welche Quelle bringt dir Gespräche, Termine und Aufträge? Gezählt werden Leads, die im Zeitraum erfasst wurden – auch die als unbrauchbar gelöschten (ab v20).</div>
    <div class="vl-tabs">${[[30, '30 Tage'], [90, '90 Tage'], [365, '12 Monate'], [0, 'Alles']].map(([t, l]) => `<button class="${T === t ? 'an' : ''}" onclick="aqAuswertung(${t})">${l}</button>`).join('')}</div>
    <div class="aw-legende"><span><i class="s1"></i>kontaktiert</span><span><i class="s2"></i>Gespräch</span><span><i class="s3"></i>Termin</span><span><i class="s4"></i>Auftrag</span></div>
    ${sum.leads ? `<div class="aw-wrap"><table class="aw-tabelle"><thead><tr><th>Quelle</th><th>Leads</th><th>mit Tel.</th><th>kontaktiert</th><th>Gespräch</th><th>Termin</th><th>Auftrag</th><th>verworfen</th></tr></thead>
      <tbody>${rows.map(r => zeileHtml(r)).join('')}${rows.length > 1 ? zeileHtml(sum, true) : ''}</tbody></table></div>` : ''}
    <div class="gs-tipp">${fazit.join(' ')}</div>
    <div class="modal-actions"><span></span><div class="right"><button onclick="schliesseModal()">Schließen</button></div></div></div>`, 860);
}

// ═════════ Glocke: Sicherung + Preis gesenkt ═════════
const _x20Hinweise = tbHinweise;
tbHinweise = function(){
  const l = _x20Hinweise(), e = db.hinweisEinst || {};
  try{
    if(siVerfuegbar() && e.sicherung !== false){
      const c = db.sicherung || {};
      if(!c.ziel) l.push({ ic:'☁️', t:'Automatische Sicherung einrichten', s:'Kopie in OneDrive / Google Drive – falls der PC ausfällt', f:'siAssistent()' });
      else if(!c.aus && c.fehler) l.unshift({ ic:'⚠️', t:'Sicherung hat nicht geklappt', s:String(c.fehler).slice(0, 90), f:'siAssistent()' });
      else if(!c.aus && c.letzte && Date.now() - c.letzte > 3 * 864e5){ const t = Math.floor((Date.now() - c.letzte) / 864e5); l.push({ k:'sicherung-alt', n:t, ic:'☁️', t:`Letzte Sicherung vor ${t} Tagen`, s:'Jetzt sichern', f:'siJetzt()' }); }
    }
  }catch(err){}
  try{
    if(e.preis !== false){
      const pl = (db.objekte || []).filter(o => o.preisGesenktAm && Date.now() - o.preisGesenktAm < 14 * 864e5 && aqPreisInfo(o) && o.status !== 'abgeschlossen');
      if(pl.length){
        const zuletzt = Math.max(...pl.map(o => o.preisGesenktAm));
        l.push({ k:'preis', ic:'📉', t:`${pl.length} Lead${pl.length === 1 ? '' : 's'} mit gesenktem Preis`, s:'Guter Anlass zum Anrufen – zuletzt am ' + new Date(zuletzt).toLocaleDateString('de-DE'), f:`AQ2.status='preis_gesenkt';wechsleAnsicht('akquise')` });
      }
    }
  }catch(err){}
  return l;
};

// ═════════ Start ═════════
window.addEventListener('load', () => {
  try{ akqAnschreibenMigrieren(); }catch(e){ console.error('v20 Anschreiben', e); }
  try{ tbGlockeAktualisieren(); }catch(e){}
  if(!siVerfuegbar()) return;
  setTimeout(() => { if(siFaellig()) siJetzt('auto'); }, 12000);
  setInterval(() => { if(siFaellig()) siJetzt('auto'); }, 20 * 60 * 1000);
});

// ═════════ 6) Termin eintragen: belegte Zeiten grau – trotzdem wählbar ═════════
const TS_VON = 7, TS_BIS = 21, TS_SCHRITT = 30;
function tsMin(s){ const m = /^(\d{1,2}):(\d{2})/.exec(String(s || '')); return m ? (+m[1]) * 60 + (+m[2]) : null; }
function tsZeit(min){ return String(Math.floor(min / 60)).padStart(2, '0') + ':' + String(min % 60).padStart(2, '0'); }
function tsTermine(d, ohne){
  const l = typeof gsTermineAm === 'function' ? gsTermineAm(d) : (db.termine || []).filter(t => t.datum === d);
  return l.filter(t => !ohne || t.id !== ohne);
}
function tsRender(c){
  const box = document.getElementById(c.box); if(!box) return;
  box._cfg = c;
  const g = id => document.getElementById(id);
  const d = g(c.datum) ? g(c.datum).value : '', z = g(c.zeit) ? g(c.zeit).value : '', dauer = (g(c.dauer) && Number(g(c.dauer).value)) || 60;
  if(!d){ box.innerHTML = ''; return; }
  const alle = tsTermine(d, box.dataset.ohne || '');
  const mitZeit = alle.filter(t => t.datum === d && tsMin(t.uhrzeit) !== null), ganz = alle.filter(t => !(t.datum === d && tsMin(t.uhrzeit) !== null));
  const bis = t => tsMin(t.uhrzeit) + (Number(t.dauer) || 60);
  const a0 = z ? tsMin(z) : null, a1 = a0 !== null ? a0 + dauer : null;
  const jetzt = new Date(), heute = toDateKey(jetzt), jetztMin = jetzt.getHours() * 60 + jetzt.getMinutes();
  const knopf = m => {
    const belegt = mitZeit.filter(t => tsMin(t.uhrzeit) < m + TS_SCHRITT && bis(t) > m);
    const an = a0 !== null && a0 < m + TS_SCHRITT && a1 > m;
    const vorbei = d < heute || (d === heute && m + TS_SCHRITT <= jetztMin);
    const tip = belegt.length ? 'Belegt: ' + belegt.map(t => t.uhrzeit + '–' + tsZeit(bis(t)) + ' ' + (typeof twPre === 'function' ? twPre(t) : '') + (t.titel || 'Termin')).join(' · ') + ' – trotzdem wählbar' : tsZeit(m) + ' frei';
    return `<button type="button" class="ts-s${m % 60 === 0 ? ' voll' : ''}${belegt.length ? ' belegt' : ''}${an ? ' an' : ''}${vorbei ? ' vorbei' : ''}" title="${akqEsc(tip)}" onclick="tsWaehlen('${c.box}','${tsZeit(m)}')">${tsZeit(m)}</button>`;
  };
  const reihen = [[], []];
  for(let m = TS_VON * 60; m < TS_BIS * 60; m += TS_SCHRITT) reihen[m < 14 * 60 ? 0 : 1].push(knopf(m));
  const aussen = mitZeit.filter(t => bis(t) <= TS_VON * 60 || tsMin(t.uhrzeit) >= TS_BIS * 60);
  const tag = typeof gsDatumLang === 'function' ? gsDatumLang(d) : d;
  const kopf = c.kopf ? `<b>${akqEsc(tag)}</b>: ${alle.length ? alle.length + ' Termin' + (alle.length === 1 ? '' : 'e') : 'noch frei'}` : '<b>Zeit wählen</b>';
  box.innerHTML = `<div class="ts-kopf">${kopf}<span class="sp"></span><span class="ts-leg"><i class="ts-i frei"></i>frei</span><span class="ts-leg"><i class="ts-i belegt"></i>belegt</span><span class="ts-leg"><i class="ts-i an"></i>gewählt</span></div>`
    + (ganz.length ? `<div class="ts-ganz">Ganztägig: ${ganz.map(t => akqEsc(t.titel || 'Termin')).join(' · ')}</div>` : '')
    + reihen.map(r => `<div class="ts-reihe">${r.join('')}</div>`).join('')
    + (aussen.length ? `<div class="ts-aussen">Außerdem: ${aussen.map(t => akqEsc(t.uhrzeit + ' ' + (t.titel || 'Termin'))).join(' · ')}</div>` : '');
}
function tsWaehlen(boxId, zeit){
  const box = document.getElementById(boxId), c = box && box._cfg; if(!c) return;
  const f = document.getElementById(c.zeit); if(f) f.value = zeit;
  const du = document.getElementById(c.dauer); if(du) du.disabled = false;
  if(typeof c.nach === 'function') c.nach(); else tsRender(c);
}
function tsMT(){ tsRender({ box:'m_t_slots', datum:'m_t_datum', zeit:'m_t_zeit', dauer:'m_t_dauer', kopf:true }); }
const _x20TqTag = aq2TqTag;
aq2TqTag = function(){
  _x20TqTag.apply(this, arguments);
  tsRender({ box:'tq_slots', datum:'tq_datum', zeit:'tq_zeit', dauer:'tq_dauer', kopf:false, nach:() => aq2TqTag() });
};

// ═════════ 7) Objekte-Seite: nur Objekte mit Termin im Kalender ═════════
X20.objFilter = 'termin';
function objTerminZaehlt(t){
  if(!t || t.art === 'rueckruf') return false;                       // Rückrufe sind keine Termine vor Ort
  const txt = String(t.titel || '') + ' ' + (t.art === 'eigene' ? (t.artEigene || '') : '');
  return !/^\s*r[üu]ckruf/i.test(txt);
}
function objHatTermin(o){
  if(['termin', 'auftrag', 'online', 'abgeschlossen'].includes(o.status)) return true;
  return (db.termine || []).some(t => t.objektId === o.id && objTerminZaehlt(t));
}
function objSichtbar(o){ return X20.objFilter === 'alle' || objHatTermin(o); }
function objFilterSetzen(v){ X20.objFilter = v === 'alle' ? 'alle' : 'termin'; const s = document.getElementById('objFilterTermin'); if(s) s.value = X20.objFilter; renderObjekteTabelle(); }
const _x20ObjTabelle = renderObjekteTabelle;
renderObjekteTabelle = function(){
  const r = _x20ObjTabelle.apply(this, arguments);
  try{
    const el = document.getElementById('objTabelle');
    if(el && X20.objFilter !== 'alle'){
      const weg = (db.objekte || []).filter(o => !objHatTermin(o)).length;
      if(weg) el.insertAdjacentHTML('beforeend', `<div class="obj-filter-hinweis">${weg} Akquise-Lead${weg === 1 ? '' : 's'} ohne Termin ausgeblendet · <a href="#" onclick="objFilterSetzen('alle');return false;">Alle zeigen</a> · <a href="#" onclick="wechsleAnsicht('akquise');return false;">zur Akquise</a></div>`);
      if(!(db.objekte || []).some(objHatTermin) && !el.querySelector('.obj-filter-leer')) el.insertAdjacentHTML('afterbegin', `<div class="obj-filter-leer">Noch kein Objekt mit Termin. Sobald du bei einem Lead einen Termin einträgst (Akquise-Termin, Erstgespräch, Besichtigung …), steht er hier.</div>`);
    }
  }catch(e){ console.error(e); }
  return r;
};
