// ═══ MaklerCockpit v26 – Anschreiben für Akquise-Objekte: Kleinanzeigen und Zeitung ═══
const VL26_KLEINANZEIGEN = `Guten Tag,

ist die Immobilie noch zum Verkauf?
Falls ja, dann senden Sie mir bitte Ihre Telefonnummer, damit ich Sie einmal anrufen kann, wenn es zeitlich bei mir passt.

Mit freundlichen Grüßen
Paul Görner`;
const VL26_ZEITUNG = `{gruss},
ich bin auf Ihre Immobilienanzeige in der Zeitung aufmerksam geworden und möchte mich gerne erkundigen, ob das Objekt aktuell noch zum Verkauf steht.
Ich bin als Immobilienmakler tätig und hätte grundsätzlich Interesse, mich näher mit dem Objekt zu beschäftigen.
Falls es noch verfügbar ist, würde ich mich über eine kurze Rückmeldung und weitere Informationen freuen.
Freundliche Grüße`;
function vl26Gruss(d){ const h = (d || new Date()).getHours(); return h >= 4 && h < 11 ? 'Guten Morgen' : h >= 18 || h < 4 ? 'Guten Abend' : 'Guten Tag'; }
function vl26IstZeitung(o){ return !!o && (o.quelle === 'Zeitung' || !!o.chiffre || /zeitung|anzeigenblatt|wochenblatt/i.test(String(o.quelleText || ''))); }
function vl26IstKleinanzeigen(o){ return !!o && /kleinanzeigen/i.test(String(o.link || '') + ' ' + String(o.quelle || '')); }
function vl26Art(o){ return vl26IstZeitung(o) ? 'zeitung' : vl26IstKleinanzeigen(o) ? 'kurz' : 'email'; }

// Vorlagen-Standard und Arten erweitern
AKQ_VORL_STD.kurz = { betreff: '', text: VL26_KLEINANZEIGEN };
AKQ_VORL_STD.zeitung = { betreff: 'Ihre Immobilienanzeige in der Zeitung', text: VL26_ZEITUNG };
(function(){
  const ka = AKQ_VORL_ARTEN.find(a => a.k === 'kurz');
  if(ka){ ka.titel = '💬 Kleinanzeigen'; ka.kurz = 'Kleinanzeigen'; ka.sub = 'Für Kleinanzeigen-Leads (und andere Portale): wird kopiert, die Anzeige öffnet sich, dort einfügen und senden.'; }
  if(!AKQ_VORL_ARTEN.some(a => a.k === 'zeitung')) AKQ_VORL_ARTEN.splice(AKQ_VORL_ARTEN.findIndex(a => a.k === 'nachfassen'), 0, { k: 'zeitung', titel: '📰 Zeitung', kurz: 'Zeitung', sub: 'Für Leads aus Zeitungsanzeigen – per E-Mail, SMS oder WhatsApp. {gruss} wird je nach Uhrzeit zu „Guten Morgen“, „Guten Tag“ oder „Guten Abend“.', betreff: true });
  if(typeof AKQ_PLATZHALTER !== 'undefined' && !AKQ_PLATZHALTER.some(p => p[0] === '{gruss}')) AKQ_PLATZHALTER.unshift(['{gruss}', 'Guten Morgen (bis 11 Uhr) · Guten Tag · Guten Abend (ab 18 Uhr)']);
})();
const _vl26Vorlagen = akqVorlagen;
akqVorlagen = function(){
  const V = _vl26Vorlagen.apply(this, arguments);
  const a = akqDb();
  if(!a.vorlagen26){
    // einmalig: die neuen Texte für Kleinanzeigen und Zeitung übernehmen (bisherige bleiben gesichert)
    a.vorlagenAlt26 = JSON.parse(JSON.stringify({ kurz: V.kurz, zeitung: V.zeitung || null }));
    V.kurz = { betreff: '', text: VL26_KLEINANZEIGEN };
    V.zeitung = { betreff: AKQ_VORL_STD.zeitung.betreff, text: VL26_ZEITUNG };
    a.vorlagen26 = true;
  }
  V.zeitung = Object.assign({}, AKQ_VORL_STD.zeitung, V.zeitung || {});
  if(!String(V.zeitung.text || '').trim()) V.zeitung.text = VL26_ZEITUNG;
  return V;
};
const _vl26Anwenden = akqVorlageAnwenden;
akqVorlageAnwenden = function(t, o){ return _vl26Anwenden.call(this, String(t || '').replace(/\{gruss\}/g, vl26Gruss()), o); };
// Standardtext je Lead nach Herkunft
aqAnschreibenStandard = function(o){ return aqIstLead(o) ? aqAnschreiben(o, vl26Art(o), true).text : ANSCHREIBEN_TEXT; };
// Senden am Lead: Zeitung → Zeitungs-Text, Kleinanzeigen → Kleinanzeigen-Text
const _vl26Senden = aq2Senden;
aq2Senden = function(art){
  const o = findObjekt(AQ2.sel);
  if(!art && o) art = aqNachfassenFaellig(o) ? 'nachfassen' : vl26Art(o) === 'email' ? undefined : vl26Art(o);
  const A = _vl26Senden.call(this, art);
  try{
    if(o && A && (art === 'zeitung' || (art === 'nachfassen' && vl26IstZeitung(o))) && !aqMail(o)){
      const tel = aqTel(o), d = (typeof vb25Tel === 'function' ? vb25Tel(tel) : String(tel || '').replace(/\D/g, ''));
      const mobil = /^01[5-7]\d{6,}$/.test(d);
      const knopf = mobil ? `<button class="secondary" onclick="window.open('https://wa.me/49${d.slice(1)}?text=${encodeURIComponent(A.text).replace(/'/g, '%27')}','_blank')">💬 WhatsApp</button><button class="secondary" onclick="window.open('sms:${d}?body=${encodeURIComponent(A.text).replace(/'/g, '%27')}','_blank')">✉️ SMS</button>` : '';
      aq2ErgebnisZeigen(`<span style="font-size:12px;color:var(--muted);width:100%;">Zeitungs-Text kopiert${mobil ? ' – per WhatsApp oder SMS schicken' : tel ? ' – Festnetznummer: am besten anrufen' : o.chiffre ? ' – Antwort per Chiffre an die Zeitung' : ''}. Verschickt?</span>${knopf}<button onclick="aq2StatusSetzen('email_geschrieben');akqToast('Status: angeschrieben')">✅ Ja, verschickt</button><button class="secondary" onclick="aq2ErgebnisZeigen('')">Nein</button>`);
    }
  }catch(e){}
  return A;
};
// Eigene Texte am Lead: von Hand geändert → bleibt; Texte aus einem KI-Import → neue Vorlage gilt (alter Text gesichert)
function vl26EigeneTexte(nurNeue){
  let n = 0;
  for(const o of db.objekte || []){
    if(o.vl26 || o.anschreibenHand) continue;
    if(typeof ob26Bereich === 'function' && ob26Bereich(o) !== 'akquise'){ continue; }
    if(!(vl26IstZeitung(o) || vl26IstKleinanzeigen(o))) continue;
    if(o.anschreibenEigen === true && String(o.anschreibenText || '').trim()){ o.anschreibenAlt26 = o.anschreibenText; o.anschreibenText = ''; o.anschreibenEigen = false; n++; }
    o.vl26 = true;
  }
  return n;
}
const _vl26Speichere = speichereObjekt;
speichereObjekt = function(id){
  const ta = document.getElementById('m_anschreiben'), vorher = ta ? ta.defaultValue : null, jetzt = ta ? ta.value : null;
  const r = _vl26Speichere.apply(this, arguments);
  try{ const o = id ? findObjekt(id) : null; if(o && ta && jetzt !== vorher && o.anschreibenEigen){ o.anschreibenHand = true; save(); } }catch(e){}
  return r;
};
const _vl26Schreibe = _schreibe;
_schreibe = function(){ try{ vl26EigeneTexte(); }catch(e){} return _vl26Schreibe.apply(this, arguments); };
window.addEventListener('load', () => { try{ akqVorlagen(); if(vl26EigeneTexte() >= 0) save(); }catch(e){ console.error('vl26', e); } });
