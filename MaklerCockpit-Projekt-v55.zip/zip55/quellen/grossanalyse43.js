// ═══ MaklerCockpit v43 – Große Analyse: Auswahlkatalog 2.0 (Stand 17.11.2026) ═══
// Auswahlfelder statt Freitext: Kerndaten offen, Bauteilgruppen aufklappbar, Suche, Mehrfachauswahl, wiederholbare Einträge
// (Fenstergruppen, Heizungsanlagen, Bäder …). Je Angabe getrennt: Quelle, Prüfstatus, Datum, Bereich, Datei/Seite, Originalwortlaut.
// Grundsätze: nichts vorbelegen, „Unbekannt“ ist keine Negativangabe, leer ist nie 0, keine automatische Diagnose aus Begriffen.
// Alte Entwürfe werden ohne Datenverlust übernommen: Freitexte bleiben als „Freitext-Angaben“ sichtbar und gehen in den Prompt.

const GA43_QUELLEN = ['Eigentümerangabe', 'Mieterangabe', 'Verwaltungsangabe', 'Eigene Besichtigung', 'Eigenes Aufmaß', 'Exposé / Inserat', 'Grundriss / Bauplan', 'Flächenberechnung', 'Bauakte / Genehmigung', 'Energieausweis', 'Rechnung / Modernisierungsbeleg', 'Gutachten / Fachbericht', 'Grundbuch / Kataster', 'Amtliche Auskunft', 'Mietvertrag', 'Sonstige Quelle'];
const GA43_PRUEF = ['Ungeprüfte Angabe', 'Durch Unterlage belegt', 'Vor Ort beobachtet', 'Fachlich geprüft', 'Annahme / Schätzung', 'Widersprüchlich'];
const GA43_PRUEF_KURZ = { 'Ungeprüfte Angabe': 'ungeprüft', 'Durch Unterlage belegt': 'belegt', 'Vor Ort beobachtet': 'beobachtet', 'Fachlich geprüft': 'geprüft', 'Annahme / Schätzung': 'Annahme', 'Widersprüchlich': 'widersprüchlich' };
const GA43_DOKQ = new Set(['Exposé / Inserat', 'Grundriss / Bauplan', 'Flächenberechnung', 'Bauakte / Genehmigung', 'Energieausweis', 'Rechnung / Modernisierungsbeleg', 'Gutachten / Fachbericht', 'Grundbuch / Kataster', 'Amtliche Auskunft', 'Mietvertrag']);
const GA43_DATENSTATUS = ['Unbekannt', 'Nicht zutreffend'];
const GA43_EXKLUSIV = new Set(['Unbekannt', 'Keine bekannt', 'Keine sichtbaren Auffälligkeiten', 'Zum Termin keine sichtbare Feuchtigkeit']);
const GA43_EINTRAG = { aussenflaechen: 'Außenfläche', nebenanlagen: 'Garage / Stellplatz / Nebengebäude', modernisierungen: 'Maßnahme', schaeden: 'Befund', heizungen: 'Heizungsanlage', mietvertraege: 'Mietvertrag', fenster: 'Fenstergruppe', sonnenschutz: 'Sonnenschutz', decken: 'Decke', treppen_tueren: 'Treppe / Tür', raeume: 'Raum / Bereich', baeder: 'Bad', flurstuecke: 'Teilfläche', rechte: 'Recht' };
const GA43_WOFLV_TYPEN = ['Terrasse', 'Balkon', 'Loggia', 'Dachterrasse', 'Dachgarten'];
// alte Freitextfelder (bis v42) → bleiben als Freitext-Angaben erhalten
const GA43_ALTTEXT = { bauweise: 'Bauweise', dach: 'Dachform / Dachausbau', nebengebaeude: 'Garage, Carport, Stellplatz, Nebengebäude', terrasse: 'Terrasse/Balkon brutto (m²)', terrasse_anteil: 'Terrasse/Balkon: davon angerechnet (%)', modern: 'Modernisierungen', schaeden: 'Schäden / Mängel / Feuchtigkeit', heizung: 'Heizung', pv: 'PV / Speicher / Wallbox', mietvertrag: 'Mietverträge', genehmigung: 'Genehmigungen', lasten: 'Baulasten, Grundbuch-Lasten, Wegerecht', teilflaechen: 'Teilflächen / Flurstücke' };
// alte Auswahlwerte → neue Optionen (nicht eindeutig zuordenbare bleiben als Freitext-Angabe erhalten)
const GA43_MAP = {
  stellung: { freistehend: 'Freistehend', DHH: 'Einseitig angebaut', REH: 'Einseitig angebaut', RMH: 'Beidseitig angebaut' },
  keller: { voll: 'Vollunterkellert', teil: 'Teilunterkellert', kein: 'Nicht unterkellert' },
  wfl_regel: { 'WoFlV': 'Wohnflächenverordnung (WoFlV)', 'II. BV': 'II. Berechnungsverordnung (II. BV)', 'DIN 277': 'Als Wohnfläche bezeichnete DIN-277-Angabe' },
  standard: { einfach: 'Einfach', mittel: 'Mittel / normal', gehoben: 'Gehoben', 'stark gehoben': 'Sehr gehoben / luxuriös' },
  zustand: { neuwertig: 'Neuwertig', gepflegt: 'Normal / gepflegt', renovierungsbeduerftig: 'Renovierungsbedürftig', sanierungsbeduerftig: 'Sanierungsbedürftig' },
  ea_art: { Bedarf: 'Bedarfsausweis', Verbrauch: 'Verbrauchsausweis' },
  nutzung: { frei: 'Leerstehend', eigengenutzt: 'Eigengenutzt', vermietet: 'Vollständig vermietet', teilvermietet: 'Teilweise vermietet' },
  denkmal: { nein: 'Kein Denkmalschutz bekannt' }
};
const GA43_SYN = { 'öl': 'heizöl', 'oel': 'heizöl', 'gas': 'gas', 'therme': 'gastherme', 'rollo': 'rollladen', 'rolladen': 'rollladen', 'rolläden': 'rollladen', 'jalousie': 'jalousie', 'glas': 'verglas', 'doppelt': 'zweifach', '2-fach': 'zweifach', '2 fach': 'zweifach', '2fach': 'zweifach', '3-fach': 'dreifach', '3 fach': 'dreifach', '3fach': 'dreifach', 'pv': 'photovoltaik', 'solar': 'solar', 'wp': 'wärmepumpe', 'fußboden': 'boden', 'fussboden': 'boden', 'teppich': 'teppich', 'kamin': 'kamin', 'ofen': 'ofen', 'feucht': 'feucht', 'nass': 'feucht', 'schimmel': 'schimmel', 'dachboden': 'spitzboden', 'isolierung': 'dämm', 'daemmung': 'dämm', 'dämmung': 'dämm', 'fliese': 'fliese', 'kueche': 'küche', 'e-auto': 'wallbox', 'laden': 'wallbox', 'strom': 'elektro', 'sicherung': 'fi-/rcd', 'tuer': 'tür', 'treppenhaus': 'treppe', 'garten': 'garten', 'zaun': 'einfriedung', 'parkplatz': 'stellplatz', 'balkon': 'balkon', 'terrasse': 'terrasse', 'fernwärme': 'fernwärme', 'nachtspeicher': 'nachtspeicher', 'tank': 'tank', 'asbest': 'faserzement', 'denkmal': 'denkmal', 'miete': 'miet' };

const GA43 = { her: new Set(), auf: {}, such: '' };
const GA43_F = {}, GA43_G = {};
GA43_KAT.forEach(g => { GA43_G[g.id] = g; if(!g.rep) g.f.forEach(f => { if(f.k[0] !== '@') GA43_F[f.k] = { f, g }; }); });
const GA43_QUELL = new Set(['wfl_regel', 'art_der_flaeche']);   // Felder, deren Änderung andere Felder ein-/ausblendet
GA43_KAT.forEach(g => g.f.forEach(f => { if(f.wenn) GA43_QUELL.add(f.wenn.f); }));
const GA43_ALTKEYS = new Set(Object.keys(GA43_F).filter(k => !k.startsWith('k_')));

// ── Objektarten erweitern (Katalog: Reihenmittel-/Reihenendhaus, Wohn- und Geschäftshaus, Gewerbe) ──
(function(){
  try{
    const i = GA35_ARTEN.findIndex(a => a[0] === 'RH');
    if(i >= 0 && !GA35_ARTEN.some(a => a[0] === 'RMH')){ GA35_ARTEN[i] = ['RH', 'Reihenhaus (ohne nähere Angabe)']; GA35_ARTEN.splice(i, 0, ['RMH', 'Reihenmittelhaus'], ['REH', 'Reihenendhaus']); }
    if(!GA35_ARTEN.some(a => a[0] === 'WGH')) GA35_ARTEN.push(['WGH', 'Wohn- und Geschäftshaus'], ['Gewerbe', 'Gewerbeobjekt']);
    const g = GA35_ARTEN.find(a => a[0] === 'Grundstueck'); if(g) g[1] = 'Unbebautes Grundstück';
    ['RMH', 'REH', 'WGH'].forEach(a => { if(!GA35_HAUS.includes(a)) GA35_HAUS.push(a); });
    GA35_FELDER.forEach(f => {
      if(f.nur && f.nur.includes('EFH')) ['RMH', 'REH', 'WGH'].forEach(a => { if(!f.nur.includes(a)) f.nur.push(a); });
      if(GA43_ALTKEYS.has(f.k) || GA43_ALTTEXT[f.k]) f.kat = 1;
      if(GA43_ALTTEXT[f.k]) delete f.w;           // Gewichtung übernimmt der Katalog (Bauweise, Heizungsanlage)
    });
    if(typeof GA40_HAUSTYP === 'object') Object.assign(GA40_HAUSTYP, { RMH: '0.9', REH: '0.9', WGH: '1.05' });
    [['bgf_ber', 'BGF-/wGF-Berechnung'], ['besicht', 'Besichtigungsprotokoll'], ['denkmal_ausk', 'Denkmalauskunft'], ['amtlich', 'Weitere amtliche Auskünfte']].forEach(u => {
      if(!GA35_UNTERLAGEN.some(x => x[0] === u[0])){ const j = GA35_UNTERLAGEN.findIndex(x => x[0] === 'brw'); GA35_UNTERLAGEN.splice(j >= 0 ? j : GA35_UNTERLAGEN.length, 0, u); }
    });
  }catch(e){ console.error('ga43 init', e); }
})();
(function(){
  const _a = ga35Art;
  ga35Art = function(o){
    const t = [o && o.objekttyp, o && o.objektart].filter(Boolean).join(' ').toLowerCase();
    if(/reihenend|\breh\b/.test(t)) return 'REH';
    if(/reihenmittel|\brmh\b/.test(t)) return 'RMH';
    if(/wohn- und geschäft|wohn-\/geschäft|wohn-und-geschäft|wgh\b/.test(t)) return 'WGH';
    if(/gewerbe|büro|laden|lager|halle|praxis/.test(t) && !/wohnung|haus/.test(t)) return 'Gewerbe';
    return _a.apply(this, arguments);
  };
})();

// ── Hilfen ──
function ga43Leer(x){ if(!x) return true; const v = x.v; if(Array.isArray(v)) return !v.length; if(v && typeof v === 'object') return !String(v.von || '').trim() && !String(v.bis || '').trim(); return v == null || String(v).trim() === ''; }
function ga43Gesetzt(x){ return x && (!ga43Leer(x) || x.st); }
function ga43S(x){   // kompatibler Herkunftsstatus für ältere Teile (Ampel, Shooting-Vorbelegung)
  if(!x) return;
  if(x.p === 'Annahme / Schätzung') x.s = 'assumed';
  else if(x.q === 'Eigene Besichtigung' || x.q === 'Eigenes Aufmaß') x.s = 'visually_inferred';
  else if(GA43_DOKQ.has(x.q) || x.p === 'Durch Unterlage belegt' || x.p === 'Fachlich geprüft') x.s = 'documented';
  else if(x.q) x.s = 'owner_statement';
}
function ga43Opt(f){ return (f.o || []).map(o => Array.isArray(o) ? o[0] : o); }
function ga43Wert(e, key){ const x = e.werte[key]; return x && !ga43Leer(x) ? x.v : ''; }
function ga43Bed(w, f){   // w = Werteobjekt des Bereichs (e.werte oder Eintrag.w)
  const b = f.wenn; if(!b) return true;
  const x = w[b.f], v = x && !ga43Leer(x) ? x.v : '';
  const vs = Array.isArray(v) ? v : [v];
  if(b.gesetzt && (v === '' || (Array.isArray(v) && !v.length))) return false;
  if(b.in && !vs.some(a => b.in.includes(a))) return false;
  if(b.nicht && vs.some(a => b.nicht.includes(a))) return false;
  return true;
}
function ga43GrSichtbar(e, g){ if(g.id === 'unterlagen') return false; return !(g.haus && e.art === 'Grundstueck'); }
function ga43FeldSichtbar(e, f, w){ if(f.bau && e.art === 'Grundstueck') return false; if(f.k === '@art' || f.k === '@unterlagen' || f.k === '@notiz') return false; return ga43Bed(w, f); }
function ga43Ziel(e, pfad, anlegen){
  const t = pfad.split(':');
  if(t[0] === 'w'){ if(!e.werte[t[1]] && anlegen) e.werte[t[1]] = {}; return e.werte[t[1]]; }
  const l = (e.gruppen43 || {})[t[1]] || [], en = l.find(x => x.id === t[2]); if(!en) return null;
  if(!en.w) en.w = {}; if(!en.w[t[3]] && anlegen) en.w[t[3]] = {}; return en.w[t[3]];
}
function ga43Def(pfad){
  const t = pfad.split(':');
  if(t[0] === 'w'){ if(GA43_F[t[1]]) return GA43_F[t[1]].f; const a = GA35_FELDER.find(f => f.k === t[1]); return a ? ga43AltDef(a) : null; }
  const g = GA43_G[t[1]]; return g ? g.f.find(f => f.k === t[3]) : null;
}
function ga43AltDef(a){ return { k: a.k, l: a.l, t: { auswahl: 'sel', lang: 'lang', zahl: 'zahl', datum: 'datum' }[a.t] || 'text', o: a.o ? a.o.filter(o => o[0] !== '') : null, e: a.e, w: a.w, alt: 1 }; }
function ga43Text(f, x){   // Anzeige-/Exportwert
  if(!x || ga43Leer(x)) return x && x.st ? x.st : '';
  const so = v => v === 'Sonstiges' ? 'Sonstiges: ' + (x.so || '(ohne Beschreibung)') : v;
  if(Array.isArray(x.v)) return x.v.map(so).join(', ');
  if(typeof x.v === 'object') return [x.v.von, x.v.bis].filter(Boolean).join('–');
  if(f && f.o && Array.isArray(f.o[0])){ const o = f.o.find(o => o[0] === x.v); if(o) return o[1]; }
  return so(String(x.v));
}

// ── Übernahme alter Entwürfe (bis v42) – nichts geht verloren ──
function ga43Migrieren(e){
  if(!e || e.v43) return;
  if(!e.gruppen43) e.gruppen43 = {}; if(!e.alt43) e.alt43 = {};
  const altLabel = (k, v) => { const a = GA35_FELDER.find(f => f.k === k), o = a && a.o && a.o.find(o => o[0] === v); return o ? o[1] : v; };
  const alt = (k, x, label) => { e.alt43[k] = { l: label || (GA35_FELDER.find(f => f.k === k) || {}).l || k, v: String(x.v), s: x.s || null }; };
  Object.keys(GA43_ALTTEXT).forEach(k => { const x = e.werte[k]; if(x && String(x.v || '').trim()){ alt(k, x, GA43_ALTTEXT[k]); delete e.werte[k]; } });
  const ea = e.werte.ea_art;   // „keiner vorhanden“ ist ein Unterlagenstand, keine Ausweisart
  if(ea && ea.v === 'keiner'){ e.werte.k_energieausweis_unterlagenstand = { v: 'Liegt nicht vor', s: ea.s, alt: 'keiner' }; ea.v = ''; }
  Object.keys(GA43_MAP).forEach(k => {
    const x = e.werte[k]; if(!x || ga43Leer(x)) return;
    const f = GA43_F[k] && GA43_F[k].f; if(!f || ga43Opt(f).includes(x.v)) return;
    const neu = GA43_MAP[k][x.v];
    if(neu){ x.alt = x.v; x.v = neu; }
    else { alt(k, { v: altLabel(k, x.v), s: x.s }); x.v = ''; }
  });
  ['ea_klasse', 'beitrag'].forEach(k => { const x = e.werte[k], f = GA43_F[k].f; if(x && !ga43Leer(x) && !ga43Opt(f).includes(x.v)){ alt(k, x); x.v = ''; } });
  const bw = e.alt43.bauweise && e.alt43.bauweise.v;
  if(bw && /massiv|stein|ziegel|beton/i.test(bw) && !e.werte.k_tragende_bauweise) e.werte.k_tragende_bauweise = { v: 'Massivbau', s: e.alt43.bauweise.s, n: bw };
  if(bw && /fertig/i.test(bw) && !e.werte.k_herstellungsart) e.werte.k_herstellungsart = { v: 'Fertig-/Elementbau', s: e.alt43.bauweise.s, n: bw };
  const dt = e.alt43.dach && e.alt43.dach.v;
  if(dt && !e.werte.k_dachform){ const d = [['krüppelwalm', 'Krüppelwalmdach'], ['walm', 'Walmdach'], ['sattel', 'Satteldach'], ['flach', 'Flachdach'], ['pult', 'Pultdach'], ['mansard', 'Mansarddach'], ['zelt', 'Zeltdach']].find(([r]) => new RegExp(r, 'i').test(dt)); if(d) e.werte.k_dachform = { v: d[1], s: e.alt43.dach.s, n: dt }; }
  const ter = e.alt43.terrasse && mc24N(e.alt43.terrasse.v);
  if(ter && !(e.gruppen43.aussenflaechen || []).length){
    const ant = e.alt43.terrasse_anteil ? mc24N(e.alt43.terrasse_anteil.v) : null, w = { tatsaechliche_grundflaeche: { v: String(e.alt43.terrasse.v), s: e.alt43.terrasse.s, n: 'aus älterer Erfassung „Terrasse/Balkon brutto“ – Art bitte wählen' } };
    if(ant != null) w.wohnflaechenanrechnung = ant === 0 ? { v: '0 % / nicht angerechnet' } : [25, 50, 100].includes(ant) ? { v: ant + ' %' } : { v: 'Anderer dokumentierter Anteil' };
    if(ant != null && ![0, 25, 50, 100].includes(ant)) w.dokumentierter_anrechnungsanteil = { v: String(ant) };
    e.gruppen43.aussenflaechen = [{ id: uid(), w }];
  }
  Object.values(e.werte).forEach(x => { if(x && x.q) ga43S(x); });
  e.v43 = 1;
}
(function(){
  const _e = ga35Entwurf;
  ga35Entwurf = function(){ const e = _e.apply(this, arguments); try{ ga43Migrieren(e); }catch(err){ console.error('ga43 migration', err); } return e; };
  const _f = ga35Felder;
  ga35Felder = function(){ const l = _f.apply(this, arguments); return GA43.ohneKat ? l.filter(f => !f.kat) : l; };
})();

// ── Oberfläche: Feld ──
function ga43Her(x, f){
  if(!x) return 'Quelle?';
  const q = x.q || (x.s ? ((GA35_STATUS.find(s => s[0] === x.s) || [])[1] || '') : '');
  return (q || 'Quelle?') + (x.p ? ' · ' + (GA43_PRUEF_KURZ[x.p] || x.p) : '');
}
function ga43FeldHtml(e, f, x, pfad, w){
  const E = ga35E, a = `data-g43="${E(pfad)}"`, v = x ? x.v : '', ist = x && !ga43Leer(x);
  let inp;
  if(f.t === 'sel'){
    const ops = (f.o || []).map(o => Array.isArray(o) ? o : [o, o]);
    if(!ops.some(o => o[0] === 'Unbekannt')) ops.push(['Unbekannt', 'Unbekannt']);
    if(f.sonst) ops.push(['Sonstiges', 'Sonstiges …']);
    let sperr = new Set();
    if(f.k === 'wohnflaechenanrechnung' && w && /WoFlV/.test(ga43Wert(e, 'wfl_regel')) && GA43_WOFLV_TYPEN.includes((w.art_der_flaeche || {}).v)) sperr = new Set(['100 %']);
    inp = `<select ${a} data-m="v"><option value="">–</option>${ops.map(([o, l]) => `<option value="${E(o)}"${String(v) === o ? ' selected' : ''}${sperr.has(o) && String(v) !== o ? ' disabled' : ''}>${E(l)}${sperr.has(o) ? ' (nach WoFlV nicht zulässig)' : ''}</option>`).join('')}</select>`;
    if(v === 'Sonstiges') inp += `<input ${a} data-m="so" value="${E(x.so || '')}" placeholder="Was genau?">`;
  } else if(f.t === 'multi'){
    const sel = Array.isArray(v) ? v : [], ops = (f.o || []).concat(f.o.includes('Unbekannt') ? [] : ['Unbekannt'], f.sonst ? ['Sonstiges'] : []);
    inp = `<div class="ga43-chips">${ops.map(o => `<button type="button" class="ga43-chip${sel.includes(o) ? ' an' : ''}" ${a} data-o="${E(o)}" onclick="ga43Chip(this)">${E(o === 'Sonstiges' ? 'Sonstiges …' : o)}</button>`).join('')}</div>`;
    if(sel.includes('Sonstiges')) inp += `<input ${a} data-m="so" value="${E(x.so || '')}" placeholder="Was genau?">`;
  } else if(f.t === 'zeitraum'){
    const z = v && typeof v === 'object' ? v : {};
    inp = `<div class="ga43-zr"><input ${a} data-m="von" inputmode="numeric" placeholder="von (Jahr)" value="${E(z.von || '')}"><span>–</span><input ${a} data-m="bis" inputmode="numeric" placeholder="bis (Jahr)" value="${E(z.bis || '')}"></div>`;
  } else if(f.t === 'lang') inp = `<textarea ${a} data-m="v" rows="2">${E(v)}</textarea>`;
  else {
    const typ = f.t === 'datum' ? 'date' : 'text', im = f.t === 'zahl' ? ' inputmode="decimal"' : (f.t === 'int' || f.t === 'jahr') ? ' inputmode="numeric"' : '';
    inp = `<input ${a} data-m="v" type="${typ}"${im} value="${E(v == null ? '' : v)}"${f.t === 'jahr' ? ' placeholder="Jahr"' : ''}>`;
  }
  const offen = GA43.her.has(pfad);
  const herKl = !x || (!x.q && !x.s) ? ' leer' : x.p === 'Widersprüchlich' ? ' rot' : x.p === 'Annahme / Schätzung' || x.s === 'assumed' ? ' gelb' : (x.p === 'Durch Unterlage belegt' || x.p === 'Fachlich geprüft' || x.s === 'documented') ? ' gruen' : '';
  const kopf = `<div class="ga43-kopf"><label>${E(f.l)}${f.e ? ` <small>${E(f.e)}</small>` : ''}${f.w === 'stop' ? ' <b class="ga43-pfl">*</b>' : ''}</label>
    <button type="button" class="ga43-her${herKl}" data-p="${E(pfad)}" onclick="ga43HerAuf(this)" title="Quelle, Prüfstatus, Datum, Bereich, Originalwortlaut${f.h ? ' – mit Hinweis' : ''}">${E(ga43Her(x, f))}${f.h ? ' ⓘ' : ''}</button></div>`;
  let panel = '';
  if(offen){
    const s = (m, ops, wert, leer) => `<select ${a} data-m="${m}"><option value="">${leer}</option>${ops.map(o => `<option${wert === o ? ' selected' : ''}>${E(o)}</option>`).join('')}</select>`;
    const t = (m, ph, typ) => `<input ${a} data-m="${m}" type="${typ || 'text'}" value="${E((x && x[m]) || '')}" placeholder="${E(ph)}">`;
    panel = `<div class="ga43-panel">${f.h ? `<div class="ga43-hinweis">ⓘ ${E(f.h)}</div>` : ''}
      <div class="ga43-pr">${s('q', GA43_QUELLEN, x && x.q, '– Quelle –')}${s('p', GA43_PRUEF, x && x.p, '– Prüfstatus –')}</div>
      <div class="ga43-pr">${t('d', 'Datum', 'date')}${t('b', 'Bereich (z. B. EG, DG, Anbau)')}${t('f', 'Datei / Seite')}</div>
      ${x && x.p === 'Fachlich geprüft' ? `<div class="ga43-pr">${t('pr', 'Geprüft von (Name/Firma)')}</div>` : ''}
      <div class="ga43-pr">${s('st', GA43_DATENSTATUS, x && x.st, ist ? '– Datenstatus: beantwortet –' : '– Datenstatus: unbeantwortet –')}</div>
      <textarea ${a} data-m="n" rows="2" placeholder="Originalwortlaut / Notiz, z. B. „2 fach verglaste Gläser“">${E((x && x.n) || '')}</textarea>
      ${x && x.alt ? `<div class="mc24-muted">Frühere Angabe: ${E(x.alt)}</div>` : ''}</div>`;
  }
  const such = [f.l, (f.o || []).map(o => Array.isArray(o) ? o[1] : o).join(' '), f.h || ''].join(' ').toLowerCase();
  return `<div class="ga43-feld${f.t === 'multi' || f.t === 'lang' ? ' breit' : ''}${f.w === 'stop' ? ' pflicht' : ''}" data-s="${E(such)}">${kopf}<div class="ga43-ein">${inp}</div>${panel}</div>`;
}
// alte Felder (Lage, Bodenrichtwert, WEG, Preise) im selben Stil
ga35Zeile = function(f, x){ return ga43FeldHtml(ga35Entwurf(GA35.obj), ga43AltDef(f), x, 'w:' + f.k, null); };

// ── Oberfläche: Gruppen ──
function ga43Zaehl(e, g){
  if(g.rep) return ((e.gruppen43 || {})[g.id] || []).length;
  return g.f.filter(f => f.k[0] !== '@' && ga43Gesetzt(e.werte[f.k])).length;
}
function ga43GruppeHtml(e, g){
  const E = ga35E, n = ga43Zaehl(e, g), auf = GA43.auf[g.id] != null ? GA43.auf[g.id] : !!g.offen;
  let inhalt;
  if(g.rep){
    const l = (e.gruppen43 || {})[g.id] || [], name = GA43_EINTRAG[g.id] || 'Eintrag';
    inhalt = l.map((en, i) => {
      const w = en.w || {}, titelF = g.f.find(f => f.t === 'text' && w[f.k] && !ga43Leer(w[f.k])) || g.f.find(f => f.t === 'sel' && w[f.k] && !ga43Leer(w[f.k]));
      const titel = titelF ? ga43Text(titelF, w[titelF.k]) : '';
      return `<div class="ga43-eintrag"><div class="ga43-ekopf"><b>${E(name)} ${i + 1}</b>${titel ? ` <span class="mc24-muted">· ${E(titel)}</span>` : ''}<button type="button" class="tiny secondary" onclick="ga43Weg('${g.id}','${E(en.id)}')" title="Eintrag entfernen">✕</button></div>
        <div class="ga43-felder">${g.f.filter(f => ga43FeldSichtbar(e, f, w)).map(f => ga43FeldHtml(e, f, w[f.k], `g:${g.id}:${en.id}:${f.k}`, w)).join('')}</div></div>`;
    }).join('') + `<button type="button" class="secondary ga43-neu" onclick="ga43Neu('${g.id}')">＋ ${E(name)} hinzufügen</button>`;
  } else {
    const sicht = g.f.filter(f => ga43FeldSichtbar(e, f, e.werte));
    const kern = sicht.filter(f => !f.detail), mehr = sicht.filter(f => f.detail);
    const zeile = f => f.k.startsWith('@verweis:') ? `<div class="ga43-feld ga43-verweis" data-s="${E(f.l.toLowerCase())}"><label>${E(f.l)}</label><button type="button" class="tiny secondary" onclick="ga43Oeffne('${f.k.split(':')[1]}')">→ je Eintrag unter „${E(GA43_G[f.k.split(':')[1]].t)}“</button></div>` : ga43FeldHtml(e, f, e.werte[f.k], 'w:' + f.k, e.werte);
    const nm = mehr.filter(f => ga43Gesetzt(e.werte[f.k])).length, mAuf = GA43.auf[g.id + ':mehr'] != null ? GA43.auf[g.id + ':mehr'] : nm > 0;
    inhalt = `<div class="ga43-felder">${kern.map(zeile).join('')}</div>` + (mehr.length ? `<details class="ga43-mehr" data-auf="${g.id}:mehr"${mAuf ? ' open' : ''} ontoggle="ga43Auf(this)"><summary>Weitere Angaben (${mehr.length}${nm ? `, ${nm} ausgefüllt` : ''})</summary><div class="ga43-felder">${mehr.map(zeile).join('')}</div></details>` : '');
  }
  return `<details class="ga43-gruppe" id="ga43g-${g.id}" data-auf="${g.id}" data-s="${E(g.t.toLowerCase())}"${auf ? ' open' : ''} ontoggle="ga43Auf(this)"><summary><span>${E(g.t)}</span>${n ? `<span class="ga43-n">${n}${g.rep ? ' ' + (n === 1 ? 'Eintrag' : 'Einträge') : ''}</span>` : ''}${g.rep ? '<span class="mc24-muted ga43-rep">mehrere möglich</span>' : ''}</summary><div class="ga43-ginhalt">${inhalt}</div></details>`;
}
function ga43KatalogHtml(e){
  const E = ga35E, gr = GA43_KAT.filter(g => ga43GrSichtbar(e, g));
  return `<div class="ga35-karte ga43"><div class="ga43-titel"><h3>🏠 Objektdetails <small class="mc24-muted">Auswahlkatalog 2.0</small></h3>
      <input type="search" id="ga43Such" class="ga43-such" placeholder="🔎 Merkmal suchen, z. B. Rollladen, Parkett, Öl, 2-fach" value="${E(GA43.such)}" oninput="ga43Suchen(this.value)"></div>
    <div class="mc24-muted ga43-info">Nur ausfüllen, was bekannt ist – alles kann offen bleiben. „Unbekannt“ und leer sind keine Negativangaben. Je Angabe über den Knopf rechts Quelle, Prüfstatus und Originalwortlaut festhalten. Unterschiedliche Bereiche (z. B. Fenster EG/DG) als eigene Einträge.</div>
    <div id="ga43Leer" class="mc24-muted" style="display:none">Kein Merkmal gefunden – über „Sonstiges …“ oder die Notizen erfassen.</div>
    ${gr.map(g => ga43GruppeHtml(e, g)).join('')}</div>` + ga43AltHtml(e);
}
function ga43AltHtml(e){
  const l = Object.entries(e.alt43 || {}); if(!l.length) return '';
  return `<div class="ga35-karte ga43-alt"><h3>📝 Freitext-Angaben <small class="mc24-muted">aus der Objektakte oder einer älteren Erfassung</small></h3>
    <div class="mc24-muted">Bleiben erhalten und gehen mit in den Prompt. Am besten in die Auswahlfelder oben übernehmen und dann hier entfernen.</div>
    ${l.map(([k, x]) => `<div class="ga43-feld breit"><div class="ga43-kopf"><label>${ga35E(x.l)}</label><button type="button" class="tiny secondary" onclick="ga43AltWeg('${ga35E(k)}')">✓ übernommen – entfernen</button></div><textarea data-g43alt="${ga35E(k)}" rows="2">${ga35E(x.v)}</textarea></div>`).join('')}</div>`;
}

(function(){
  const _r = ga35Render;
  ga35Render = function(main){
    if(GA35.tab === 'schnell') return _r.apply(this, arguments);
    const e = ga35Entwurf(GA35.obj);
    GA43.ohneKat = true;
    try{ _r.apply(this, arguments); } finally { GA43.ohneKat = false; }
    try{
      const vgl = [...main.querySelectorAll('.ga35-karte')].find(x => /Vergleichsf/.test((x.querySelector('h3') || {}).textContent || ''));
      const html = ga43KatalogHtml(e);
      if(vgl) vgl.insertAdjacentHTML('beforebegin', html); else main.querySelector('.ga35').insertAdjacentHTML('beforeend', html);
      if(GA43.such) ga43Suchen(GA43.such, true);
    }catch(err){ console.error('ga43 render', err); }
  };
})();

// ── Eingaben ──
function ga43Eingabe(ev){
  const t = ev.target; if(!t || !t.dataset) return;
  if(t.dataset.g43alt){ const e = ga35Entwurf(GA35.obj); if(e.alt43 && e.alt43[t.dataset.g43alt]){ e.alt43[t.dataset.g43alt].v = t.value; ga35Merken(false); } return; }
  const pfad = t.dataset.g43, m = t.dataset.m; if(!pfad || !m) return;
  const e = ga35Entwurf(GA35.obj), x = ga43Ziel(e, pfad, true); if(!x) return;
  const f = ga43Def(pfad);
  if(m === 'von' || m === 'bis'){ x.v = Object.assign({}, x.v && typeof x.v === 'object' ? x.v : {}, { [m]: t.value }); }
  else x[m] = t.value;
  if(m === 'q' || m === 'p') ga43S(x);
  const key = pfad.split(':').pop();
  const neu = ev.type === 'change' && (t.tagName === 'SELECT' || ((m === 'v' || m === 'von' || m === 'bis') && GA43_QUELL.has(key)));
  ga35Merken(neu);
}
document.addEventListener('input', ev => { if(aktuelleAnsicht === 'grossanalyse' && ev.target && ev.target.closest && ev.target.closest('.ga35')) ga43Eingabe(ev); });
document.addEventListener('change', ev => { if(aktuelleAnsicht === 'grossanalyse' && ev.target && ev.target.closest && ev.target.closest('.ga35')) ga43Eingabe(ev); });
function ga43Chip(b){
  const e = ga35Entwurf(GA35.obj), x = ga43Ziel(e, b.dataset.g43, true); if(!x) return;
  const o = b.dataset.o; let l = Array.isArray(x.v) ? x.v.slice() : [];
  if(l.includes(o)) l = l.filter(a => a !== o);
  else { if(GA43_EXKLUSIV.has(o)) l = []; else l = l.filter(a => !GA43_EXKLUSIV.has(a)); l.push(o); }
  x.v = l; save(); ga35Neuzeichnen();
}
function ga43HerAuf(b){ const p = b.dataset.p; if(GA43.her.has(p)) GA43.her.delete(p); else GA43.her.add(p); ga35Neuzeichnen(); }
function ga43Auf(d){ GA43.auf[d.dataset.auf] = d.open; }
function ga43Oeffne(gid){ GA43.auf[gid] = true; ga35Neuzeichnen(); const el = document.getElementById('ga43g-' + gid); if(el) el.scrollIntoView({ behavior: 'smooth', block: 'start' }); }
function ga43Neu(gid){
  const e = ga35Entwurf(GA35.obj); if(!e.gruppen43[gid]) e.gruppen43[gid] = [];
  e.gruppen43[gid].push({ id: uid(), w: {} }); GA43.auf[gid] = true; save(); ga35Neuzeichnen();
}
function ga43Weg(gid, id){
  const los = () => { const e = ga35Entwurf(GA35.obj); e.gruppen43[gid] = (e.gruppen43[gid] || []).filter(x => x.id !== id); save(); ga35Neuzeichnen(); };
  const en = ((ga35Entwurf(GA35.obj).gruppen43 || {})[gid] || []).find(x => x.id === id), voll = en && Object.values(en.w || {}).some(x => ga43Gesetzt(x));
  if(!voll) return los();
  if(typeof bestaetigeUnten === 'function') bestaetigeUnten(`${GA43_EINTRAG[gid] || 'Eintrag'} mit allen Angaben entfernen?`, los, 'Entfernen'); else if(confirm('Eintrag entfernen?')) los();
}
function ga43AltWeg(k){
  const los = () => { const e = ga35Entwurf(GA35.obj); if(e.alt43) delete e.alt43[k]; save(); ga35Neuzeichnen(); };
  if(typeof bestaetigeUnten === 'function') bestaetigeUnten('Freitext-Angabe entfernen? Nur tun, wenn sie oben in den Auswahlfeldern steht.', los, 'Entfernen'); else los();
}
function ga43Suchen(q, still){
  GA43.such = q || '';
  const box = document.querySelector('.ga43'); if(!box) return;
  const s = String(q || '').trim().toLowerCase(), gr = [...box.querySelectorAll('.ga43-gruppe')];
  if(s.length < 2){
    box.querySelectorAll('.ga43-feld').forEach(el => { el.style.display = ''; }); gr.forEach(d => { d.style.display = ''; d.open = GA43.auf[d.dataset.auf] != null ? GA43.auf[d.dataset.auf] : !!(GA43_G[d.dataset.auf] || {}).offen; });
    box.querySelectorAll('.ga43-mehr').forEach(d => { if(GA43.auf[d.dataset.auf] != null) d.open = GA43.auf[d.dataset.auf]; });
    const l = document.getElementById('ga43Leer'); if(l) l.style.display = 'none'; return;
  }
  const begriffe = [s]; Object.keys(GA43_SYN).forEach(k => { if(s === k || s.startsWith(k + ' ')) begriffe.push(GA43_SYN[k]); });
  const passt = t => begriffe.some(b => t.includes(b));
  let irgendwas = false;
  gr.forEach(d => {
    const gTreffer = passt(d.dataset.s);
    let n = 0;
    d.querySelectorAll('.ga43-feld').forEach(el => { const ok = gTreffer || passt(el.dataset.s || ''); el.style.display = ok ? '' : 'none'; if(ok) n++; });
    const g = GA43_G[d.dataset.auf], defTreffer = g && g.rep && g.f.some(f => passt([f.l, (f.o || []).join(' ')].join(' ').toLowerCase()));
    const zeigen = gTreffer || n > 0 || defTreffer;
    d.style.display = zeigen ? '' : 'none';
    if(zeigen){ d.open = true; irgendwas = true; d.querySelectorAll('.ga43-mehr').forEach(m => { if([...m.querySelectorAll('.ga43-feld')].some(el => el.style.display !== 'none')) m.open = true; }); }
  });
  const l = document.getElementById('ga43Leer'); if(l) l.style.display = irgendwas ? 'none' : '';
}

// ── Prüfregeln (Ampel/Nachforderung) ──
function ga43Regeln(e, p){
  const W = k => ga43Wert(e, k), N = k => { const v = W(k); return v === '' ? null : mc24N(v); }, G = id => (e.gruppen43 || {})[id] || [];
  const warn = t => { if(!p.warn.includes(t)) p.warn.push(t); }, haus = e.art !== 'Grundstueck';
  const zr = W('k_baujahr_zeitraum');
  if(W('k_genauigkeit_baujahr') === 'Nur Zeitraum bekannt'){
    if(zr && (zr.von || zr.bis)) p.fehlt = p.fehlt.filter(x => !/^Baujahr/.test(x.t));
    else if(!p.fehlt.some(x => /^Baujahr/.test(x.t))) p.fehlt.push({ w: 'hoch', t: 'Baujahr-Zeitraum fehlt' });
  }
  if(zr && zr.von && zr.bis && mc24N(zr.von) > mc24N(zr.bis)) warn('Baujahr-Zeitraum: „von“ liegt nach „bis“.');
  const bj = N('baujahr'), jetzt = new Date().getFullYear();
  if(bj && (bj < 1700 || bj > jetzt + 3)) warn(`Baujahr ${bj} ist ungewöhnlich – bitte prüfen.`);
  if(haus && !W('k_tragende_bauweise') && !p.fehlt.some(x => /Bauweise/.test(x.t))) p.fehlt.push({ w: 'hoch', t: 'Tragende Bauweise fehlt' });
  if(haus && e.art !== 'Gewerbe' && !G('heizungen').some(h => ['technik_der_waermeerzeugung', 'versorgungsart', 'energietraeger'].some(k => h.w && h.w[k] && !ga43Leer(h.w[k])))) p.fehlt.push({ w: 'hoch', t: 'Heizungsanlage fehlt' });
  const ka = N('k_unterkellerter_anteil');
  if(W('keller') === 'Teilunterkellert' && ka != null && !(ka > 0 && ka < 100)) warn('Unterkellerter Anteil muss bei Teilunterkellerung zwischen 0 und 100 % liegen.');
  const wd = W('k_wanddaemmung');
  if(Array.isArray(wd) && wd.includes('Keine Dämmung laut vorliegender Angabe') && wd.length > 1) warn('Wanddämmung: „Keine Dämmung“ und ein Dämmsystem gleichzeitig gewählt – widersprüchlich.');
  const dv = N('k_dachneigung_von_einzelwert'), db_ = N('k_dachneigung_bis');
  if(dv != null && db_ != null && dv > db_) warn('Dachneigung: Untergrenze größer als Obergrenze.');
  if((dv != null && (dv < 0 || dv > 90)) || (db_ != null && (db_ < 0 || db_ > 90))) warn('Dachneigung außerhalb 0–90 Grad – bitte prüfen.');
  const woflv = /WoFlV/.test(W('wfl_regel'));
  G('aussenflaechen').forEach((a, i) => {
    const w = a.w || {}, art = (w.art_der_flaeche || {}).v, an = (w.wohnflaechenanrechnung || {}).v, dok = w.dokumentierter_anrechnungsanteil && mc24N(w.dokumentierter_anrechnungsanteil.v);
    if(woflv && GA43_WOFLV_TYPEN.includes(art) && an === '100 %') warn(`Außenfläche ${i + 1} (${art}): nach WoFlV höchstens 50 % anrechenbar.`);
    if(woflv && GA43_WOFLV_TYPEN.includes(art) && dok != null && dok > 50) warn(`Außenfläche ${i + 1} (${art}): dokumentierter Anteil über 50 % ist nach WoFlV nicht zulässig.`);
    if(dok != null && (dok < 0 || dok > 100)) warn(`Außenfläche ${i + 1}: Anteil muss zwischen 0 und 100 % liegen.`);
  });
  if(W('k_aussenflaechen_in_angegebener_wohnflaech') === 'Bereits enthalten' && G('aussenflaechen').length) warn('Außenflächen sind laut Angabe schon in der angegebenen Wohnfläche enthalten – nicht doppelt anrechnen.');
  G('nebenanlagen').forEach((a, i) => { const w = a.w || {}; if(w.flaeche_anlage && !ga43Leer(w.flaeche_anlage) && (!w.flaechenbegriff_der_anlage || ga43Leer(w.flaechenbegriff_der_anlage))) warn(`Garage/Nebengebäude ${i + 1}: Fläche ohne Flächenbegriff (BGF, Nutzfläche …).`); });
  const ant = { Fensteranzahl: 0, Fensterfläche: 0 };
  G('fenster').forEach((a, i) => {
    const w = a.w || {}, an = w.anteil_am_fensterbestand && mc24N(w.anteil_am_fensterbestand.v), bas = (w.bezugsbasis_des_anteils || {}).v;
    if(an != null && !bas) warn(`Fenstergruppe ${i + 1}: Anteil ohne Bezugsbasis (Anzahl oder Fläche).`);
    if(an != null && (an < 0 || an > 100)) warn(`Fenstergruppe ${i + 1}: Anteil muss zwischen 0 und 100 % liegen.`);
    if(an != null && ant[bas] != null) ant[bas] += an;
  });
  Object.entries(ant).forEach(([b, s]) => { if(s > 100.5) warn(`Fenstergruppen: Anteile nach ${b} ergeben zusammen ${Math.round(s)} %.`); });
  const rechte = W('k_bekannte_rechte_beschraenkungen');
  if(Array.isArray(rechte) && rechte.some(r => ['Wohnrecht', 'Nießbrauch', 'Wegerecht', 'Leitungsrecht'].includes(r)) && !G('rechte').length) warn('Rechte bekannt: je Recht unter „Rechte und Löschungsvorbehalte“ den Stand im Verkauf erfassen.');
  const sch = G('schaeden').map(s => (s.w && s.w.befund_verdacht || {}).v).filter(Boolean);
  if(sch.includes('Keine Schäden bekannt') && sch.length > 1) warn('Schäden: „Keine Schäden bekannt“ und konkrete Befunde gleichzeitig erfasst.');
  if(W('ea_klasse') && W('k_energieausweis_unterlagenstand') === 'Liegt nicht vor') warn('Energieklasse eingetragen, obwohl kein Energieausweis vorliegt – Quelle prüfen.');
  if(W('ea_kw') && /Primärenergie/.test(W('k_art_des_eingetragenen_kennwerts'))) warn('Primärenergiekennwert gehört nicht ins Feld Endenergiekennwert.');
  const mietSumme = G('mietvertraege').reduce((s, m) => s + (mc24N(((m.w || {}).nettokaltmiete_einheit || {}).v) || 0), 0), mi = N('miete_ist');
  if(mietSumme && mi && Math.abs(mietSumme - mi) > 1) warn(`Summe der Mietverträge (${mc24Fmt(mietSumme)} €) weicht von der Ist-Nettokaltmiete (${mc24Fmt(mi)} €) ab.`);
  const brw = N('brw'), plzN = Number(W('plz'));
  if(brw != null && brw > 0 && brw < 100 && (e.region === 'Berlin' || (plzN >= 10115 && plzN <= 14199))) warn(`Bodenrichtwert ${mc24Fmt(brw)} €/m² ist für Berlin ungewöhnlich niedrig – Tippfehler? (BORIS prüfen)`);
  const geprueft = [];
  const pruefe = (x, l) => { if(x && x.p === 'Fachlich geprüft' && (!x.pr || !x.d || !x.f)) geprueft.push(l); };
  Object.entries(e.werte).forEach(([k, x]) => pruefe(x, (GA43_F[k] && GA43_F[k].f.l) || k));
  Object.entries(e.gruppen43 || {}).forEach(([gid, l]) => l.forEach(en => Object.entries(en.w || {}).forEach(([k, x]) => pruefe(x, (GA43_G[gid] ? GA43_G[gid].t + ': ' : '') + ((GA43_G[gid] && GA43_G[gid].f.find(f => f.k === k)) || { l: k }).l))));
  if(geprueft.length) warn(`„Fachlich geprüft“ ohne Prüfer, Datum oder Beleg: ${geprueft.slice(0, 5).join(', ')}${geprueft.length > 5 ? ' …' : ''}.`);
  p.stop = p.fehlt.filter(x => x.w === 'stop').length;
  p.stufe = p.stop ? 'STOP' : (p.kauf >= 8 && !p.fehlt.length) ? 'B' : 'C';
  return p;
}
(function(){
  const _p = ga35Pruefen;
  ga35Pruefen = function(e){
    const alt = GA43.ohneKat; GA43.ohneKat = false;
    try{ const p = _p.apply(this, arguments); try{ ga43Regeln(e, p); }catch(err){ console.error('ga43 regeln', err); } return p; }
    finally { GA43.ohneKat = alt; }
  };
})();

// ── Analysepaket & Prompt ──
function ga43Hausnr(s){ return String(s).replace(/\b([A-ZÄÖÜ][\wäöüßÄÖÜ\-]*(?:straße|strasse|str\.|weg|allee|platz|ring|damm|chaussee|gasse|ufer|steig|pfad|zeile|promenade|anger|markt|graben|kamp|stieg|bogen|garten|aue|siedlung|höhe))\s+\d{1,4}\s?[a-zA-Z]?(?:\s?[-–\/]\s?\d{1,4}\s?[a-zA-Z]?)?\b/g, '$1'); }
function ga43Runden(o){
  if(Array.isArray(o)) return o.map(ga43Runden);
  if(o && typeof o === 'object'){ const r = {}; Object.keys(o).forEach(k => { r[k] = ga43Runden(o[k]); }); return r; }
  if(typeof o === 'number' && isFinite(o) && !Number.isInteger(o)) return Math.abs(o) >= 100 ? Math.round(o) : Math.round(o * 100) / 100;
  if(typeof o === 'string') return ga43Hausnr(o);
  return o;
}
function ga43Export(f, x, heute){
  if(!x || (!ga43Gesetzt(x) && !x.n)) return null;
  let wert = null;
  if(!ga43Leer(x)){
    if(Array.isArray(x.v)) wert = x.v.map(v => v === 'Sonstiges' ? 'Sonstiges: ' + (x.so || '') : v);
    else if(typeof x.v === 'object') wert = { von: mc24N(x.v.von), bis: mc24N(x.v.bis) };
    else if(['zahl', 'int', 'jahr'].includes(f.t)){ const n = mc24N(x.v); wert = n == null ? x.v : n; }
    else wert = x.v === 'Sonstiges' ? 'Sonstiges: ' + (x.so || '') : x.v;
  }
  const r = { label: f.l, value: wert };
  if(f.e) r.unit = f.e;
  if(x.st) r.data_status = x.st;
  r.source_type = x.q || null; r.review_status = x.p || null;
  if(x.s) r.status = x.s;
  if(x.d) r.date = x.d; if(x.b) r.area = x.b; if(x.f) r.document_locator = x.f; if(x.n) r.original_wording = String(x.n).slice(0, 600); if(x.pr) r.checked_by = x.pr;
  if(x.alt) r.previous_value = x.alt;
  return r;
}
(function(){
  const _k = ga35Paket;
  ga35Paket = function(id, e){
    const alt = GA43.ohneKat; GA43.ohneKat = true; let p;
    try{ p = _k.apply(this, arguments); } finally { GA43.ohneKat = alt; }
    try{
      const h = ga35Heute(), konflikte = [];
      // Metadaten auch für die übrigen Felder (Lage, Preise, WEG …)
      p.facts.forEach(fa => { const a = GA35_FELDER.find(f => f.p === fa.field), x = a && e.werte[a.k]; if(x){ if(x.q) fa.source_type = x.q; if(x.p) fa.review_status = x.p; if(x.d) fa.date = x.d; if(x.f) fa.document_locator = x.f; if(x.n) fa.original_wording = String(x.n).slice(0, 600); } });
      // Katalogfelder (einzeln)
      GA43_KAT.forEach(g => {
        if(g.rep) return;
        g.f.forEach(f => {
          if(f.k[0] === '@') return;
          const r = ga43Export(f, e.werte[f.k], h); if(!r) return;
          const a = GA35_FELDER.find(x => x.k === f.k), fakt = Object.assign({ field: a ? a.p : 'katalog.' + g.id + '.' + f.k.replace(/^k_/, ''), group: g.t }, r, { source_id: 'S-MC', valid_at: r.date || h });
          const sichtbar = ga43GrSichtbar(e, g) || g.id === 'unterlagen', bed = ga43Bed(e.werte, f) && !(f.bau && e.art === 'Grundstueck');
          if(!sichtbar || !bed){
            if(f.k === 'baujahr' && ga43Wert(e, 'k_genauigkeit_baujahr') === 'Nur Zeitraum bekannt'){ fakt.excluded_from_valuation = true; fakt.note = 'Nur Zeitraum bekannt – Einzeljahr nur als Rohwert'; p.facts.push(fakt); }
            else konflikte.push({ field: fakt.field, label: f.l, value: fakt.value, reason: 'ausgeblendet (Bedingung oder Objektart passt nicht) – Rohwert erhalten, nicht verwenden ohne Klärung' });
            return;
          }
          p.facts.push(fakt);
        });
      });
      // Wiederholbare Gruppen
      const gruppen = [];
      GA43_KAT.filter(g => g.rep).forEach(g => {
        const l = (e.gruppen43 || {})[g.id] || [];
        const eintraege = l.map((en, i) => {
          const w = en.w || {}, werte = [];
          g.f.forEach(f => { const r = ga43Export(f, w[f.k], h); if(!r) return; if(!ga43Bed(w, f)){ konflikte.push({ field: g.id + '[' + (i + 1) + '].' + f.k, label: g.t + ': ' + f.l, value: r.value, reason: 'ausgeblendet (Bedingung nicht erfüllt) – Rohwert erhalten' }); return; } werte.push(Object.assign({ field: f.k }, r)); });
          return werte.length ? { entry: i + 1, values: werte } : null;
        }).filter(Boolean);
        if(eintraege.length) gruppen.push({ group: g.t, group_id: g.id, entries: eintraege });
      });
      p.object_details = { catalog_version: '2.0 (Stand 17.11.2026)', note: 'Mehrere Einträge einer Gruppe beschreiben verschiedene Bereiche – nicht zu einer Gesamtaussage verdichten.', groups: gruppen };
      const alt43 = Object.values(e.alt43 || {}).filter(x => String(x.v || '').trim());
      if(alt43.length) p.legacy_notes = alt43.map(x => ({ label: x.l, text: String(x.v).slice(0, 2000), status: x.s || null, note: 'Freitext aus Objektakte bzw. älterer Erfassung – mit den strukturierten Angaben abgleichen' }));
      const wid = (p.intake_check && p.intake_check.warnings || []).filter(t => /widersprüchlich|weicht|gleichzeitig|nicht zulässig|höchstens|Untergrenze|außerhalb|ungewöhnlich/i.test(t));
      if(konflikte.length || wid.length) p.conflict_log = konflikte.concat(wid.map(t => ({ reason: t })));
      if(p.broker_quick_check) p.broker_quick_check = ga43Runden(p.broker_quick_check);
      (p.comparables || []).forEach(c => { if(c.location) c.location = ga43Hausnr(c.location); });
    }catch(err){ console.error('ga43 paket', err); }
    return p;
  };
})();
const GA43_REGELN = `## Ergänzung Erfassungskatalog 2.0 (gilt zusätzlich)
- facts (Felder mit "group") und object_details stammen aus dem Auswahlkatalog des MaklerCockpits. source_type = Herkunft der Angabe, review_status = Prüfstatus. Fehlt der Prüfstatus oder steht „Ungeprüfte Angabe“, ist die Angabe nicht verifiziert – auch wenn ein Dokument als Quelle genannt ist. „Vor Ort beobachtet“ belegt nur den sichtbaren Zustand. original_wording ist der Originalwortlaut.
- „Unbekannt“, leere Felder und data_status („Unbekannt“, „Nicht zutreffend“) sind keine Negativaussagen. Leer ist nie 0.
- Nichts ableiten: keine U-Werte, Beschichtungen oder Energieklassen aus Baujahr oder Scheibenzahl; „Isolierglas“ belegt keine Wärmeschutzbeschichtung; ein Gasanschluss ist keine Gasheizung; eine Ölheizung ist kein Brennwertkessel; „überwiegend“ ist nicht 100 %; „Keine Schäden bekannt“, „Keine bekannt“ und fehlende Auskünfte (Baulasten, Altlasten) sind Kenntnisstände, keine Nachweise; „Löschung beabsichtigt“ ist keine Löschung; „augenscheinlich“ ist keine Diagnose.
- Flächen nur mit ihrem Flächenbegriff verwenden (Wohnfläche, Nutzfläche, BGF, wGF, Grundstück) und nicht gegeneinander austauschen. Außenflächen nicht doppelt anrechnen, wenn sie laut Angabe schon in der Wohnfläche enthalten sind.
- Mehrere Einträge einer Gruppe (z. B. Fenstergruppen EG/DG, mehrere Heizungsanlagen) beschreiben verschiedene Bereiche – nicht verdichten. Ist nur ein Baujahr-Zeitraum bekannt, kein Einzeljahr erfinden; excluded_from_valuation = nur Rohwert.
- Kein pauschaler Wertaufschlag je Ausstattungsmerkmal; Merkmale nur über ein passendes Bewertungsmodell berücksichtigen.
- legacy_notes = Freitext-Angaben aus Objektakte bzw. älterer Erfassung; conflict_log = ausgeblendete oder widersprüchliche Werte. Beides berücksichtigen und Widersprüche im Bericht benennen.`;
(function(){
  const _t = ga35Prompt;
  ga35Prompt = function(){ const r = _t.apply(this, arguments); r.text = r.text.replace('\n\n## Auftrag\n', '\n\n' + GA43_REGELN + '\n\n## Auftrag\n'); return r; };
  const st = document.createElement('style');
  st.textContent = `.ga43-titel{display:flex;flex-wrap:wrap;gap:8px 14px;align-items:center;justify-content:space-between}.ga43-titel h3{margin:0}
.ga43-such{flex:1;min-width:220px;max-width:460px}
.ga43-info{font-size:12px;margin:6px 0 10px}
.ga43-gruppe{border:1px solid var(--border);border-radius:10px;margin:8px 0;background:var(--bg2)}
.ga43-gruppe>summary{cursor:pointer;padding:10px 12px;font-weight:600;display:flex;gap:10px;align-items:center;flex-wrap:wrap;list-style:none}
.ga43-gruppe>summary::-webkit-details-marker{display:none}.ga43-gruppe>summary::before{content:'▸';color:var(--muted);transition:transform .15s}.ga43-gruppe[open]>summary::before{transform:rotate(90deg)}
.ga43-n{background:var(--orange);color:#fff;border-radius:999px;font-size:11px;padding:1px 8px;font-weight:600}.ga43-rep{font-size:11px;font-weight:400}
.ga43-ginhalt{padding:0 12px 12px}
.ga43-felder{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:8px 14px}
.ga43-feld{min-width:0}.ga43-feld.breit{grid-column:1/-1}
.ga43-kopf{display:flex;gap:6px;align-items:flex-end;justify-content:space-between;margin-bottom:3px}.ga43-kopf label{font-size:12px;color:var(--muted);text-transform:none;letter-spacing:0;margin:0}
.ga43-pfl{color:var(--orange)}
.ga43-her{background:none;border:1px solid var(--border);color:var(--muted);border-radius:999px;font-size:11px;padding:1px 8px;white-space:nowrap;max-width:55%;overflow:hidden;text-overflow:ellipsis;font-weight:500}
.ga43-her.leer{border-style:dashed;opacity:.75}.ga43-her.gruen{color:var(--green);border-color:var(--green)}.ga43-her.gelb{color:var(--yellow);border-color:var(--yellow)}.ga43-her.rot{color:var(--red);border-color:var(--red)}
.ga43-ein{display:flex;flex-direction:column;gap:4px}.ga43-ein select,.ga43-ein input,.ga43-ein textarea{width:100%;min-width:0}
.ga43-zr{display:flex;gap:6px;align-items:center}.ga43-zr input{flex:1}
.ga43-chips{display:flex;flex-wrap:wrap;gap:5px}
.ga43-chip{background:var(--card);border:1px solid var(--border);color:var(--text);border-radius:999px;padding:4px 10px;font-size:12px;font-weight:500;line-height:1.3}
.ga43-chip.an{background:var(--orange);border-color:var(--orange);color:#fff}
.ga43-panel{margin-top:6px;padding:8px;border:1px dashed var(--border);border-radius:8px;display:flex;flex-direction:column;gap:6px;background:var(--card)}
.ga43-pr{display:flex;gap:6px;flex-wrap:wrap}.ga43-pr>*{flex:1;min-width:130px}
.ga43-hinweis{font-size:12px;color:var(--muted)}
.ga43-mehr{margin-top:10px}.ga43-mehr>summary{cursor:pointer;font-size:13px;color:var(--orange);margin-bottom:8px}
.ga43-eintrag{border:1px solid var(--border);border-radius:8px;padding:8px 10px;margin-bottom:8px;background:var(--card)}
.ga43-ekopf{display:flex;gap:8px;align-items:center;margin-bottom:6px}.ga43-ekopf button{margin-left:auto}
.ga43-neu{margin-top:2px}
.ga43-verweis{display:flex;flex-direction:column;gap:4px}.ga43-verweis label{font-size:12px;color:var(--muted)}
.ga43-alt textarea{width:100%}
.ga35-gitter .ga43-feld{margin-bottom:7px}
@media (max-width:760px){.ga43-felder{grid-template-columns:1fr}.ga43-ginhalt{padding:0 8px 10px}.ga43-chip{padding:6px 11px;font-size:13px}.ga43-her{max-width:60%}}`;
  document.head.appendChild(st);
})();
