// ═══ MaklerCockpit v35 – „Große Analyse“: Analysepaket + Master-Prompt (Görner-Marktanalyse-System v1.1) ═══
// Unter der Shooting-Analyse. Objekt wählen → Angaben mit Herkunft (Dokument/Eigentümer/Besichtigung/Annahme) prüfen,
// Vergleichsfälle und Unterlagen erfassen → EIN Prompt (Systemregeln + Auftrag + ANALYSEPAKET_JSON) zum Einfügen in Claude/ChatGPT.
// Grundsätze aus dem Master-Prompt: nichts erfinden, fehlend = null, Kauf- und Angebotspreise getrennt, Wunschpreis nur zum Vergleich,
// keine Eigentümer-Kontaktdaten im Prompt.
(function(){ try{
  const i = NAV.findIndex(x => x.key === 'shooting');
  if(!NAV.some(x => x.key === 'grossanalyse')) NAV.splice(i >= 0 ? i + 1 : NAV.length, 0, { key: 'grossanalyse', label: 'Große Analyse', icon: '🔬' });
  if(typeof IC === 'object') IC.grossanalyse = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M6 3h9l4 4v14H6z"/><path d="M15 3v4h4"/><circle cx="11.5" cy="13" r="3"/><path d="m13.7 15.2 2.3 2.3"/></svg>';
}catch(e){ console.error('ga35 nav', e); } })();

const GA35_STATUS = [['documented', 'Dokument'], ['owner_statement', 'Eigentümer'], ['visually_inferred', 'Besichtigung'], ['assumed', 'Annahme']];
const GA35_ARTEN = [['', '– wählen –'], ['EFH', 'Einfamilienhaus'], ['DHH', 'Doppelhaushälfte'], ['RH', 'Reihenhaus'], ['ETW', 'Eigentumswohnung'], ['MFH', 'Mehrfamilienhaus'], ['ZFH', 'Zweifamilienhaus'], ['Grundstueck', 'Grundstück (unbebaut)']];
const GA35_HAUS = ['EFH', 'DHH', 'RH', 'ZFH', 'MFH'];
// Felder: k = Schlüssel, p = Feldpfad der Datenmatrix (03_Datenmatrix.csv), e = Einheit, t = Typ, nur = Objektarten, w = Gewicht für die Vollständigkeit
const GA35_FELDER = [
  { g: 'Lage', k: 'adresse', l: 'Straße + Hausnummer', p: 'lage.adresse', t: 'text', w: 'stop' },
  { g: 'Lage', k: 'plz', l: 'PLZ', p: 'lage.plz', t: 'text', w: 'stop' },
  { g: 'Lage', k: 'ort', l: 'Ort', p: 'lage.ort', t: 'text', w: 'stop' },
  { g: 'Lage', k: 'ortsteil', l: 'Ortsteil / Bezirk', p: 'lage.ortsteil', t: 'text' },
  { g: 'Lage', k: 'mikrolage', l: 'Mikrolage (Straße, Nachbarschaft, Lärm, Ausrichtung)', p: 'lage.mikrolage', t: 'lang' },
  { g: 'Lage', k: 'besichtigt', l: 'Besichtigt am', p: 'lage.besichtigungsdatum', t: 'datum', w: 'hoch' },

  { g: 'Grundstück', k: 'grund', l: 'Grundstücksfläche gesamt', p: 'grundstueck[0].flaeche_m2', e: 'm²', t: 'zahl', nur: GA35_HAUS.concat(['Grundstueck']), w: 'stop' },
  { g: 'Grundstück', k: 'teilflaechen', l: 'Teilflächen / Flurstücke (Bauland, Straßenland, Hinterland …)', p: 'grundstueck[].nutzungsqualitaet', t: 'lang', nur: GA35_HAUS.concat(['Grundstueck']) },
  { g: 'Grundstück', k: 'brw', l: 'Bodenrichtwert (falls bekannt)', p: 'grundstueck[0].brw_eur_m2', e: 'EUR/m²', t: 'zahl', nur: GA35_HAUS.concat(['Grundstueck']) },
  { g: 'Grundstück', k: 'brw_stichtag', l: 'Bodenrichtwert Stichtag', p: 'grundstueck[0].brw_stichtag', t: 'datum', nur: GA35_HAUS.concat(['Grundstueck']) },
  { g: 'Grundstück', k: 'beitrag', l: 'Erschließung / Beitragszustand', p: 'grundstueck[0].beitragszustand', t: 'text', nur: GA35_HAUS.concat(['Grundstueck']) },
  { g: 'Grundstück', k: 'lasten', l: 'Baulasten, Grundbuch-Lasten, Wegerecht', p: 'grundstueck[0].grundbuch_lasten', t: 'lang', w: 'hoch' },
  { g: 'Grundstück', k: 'erbbau', l: 'Erbbaurecht', p: 'grundstueck[0].erbbaurecht', t: 'auswahl', o: [['', '– unbekannt –'], ['nein', 'nein'], ['ja', 'ja']], w: 'stop' },
  { g: 'Grundstück', k: 'denkmal', l: 'Denkmalschutz', p: 'grundstueck[0].denkmalschutz', t: 'auswahl', o: [['', '– unbekannt –'], ['nein', 'nein'], ['ja', 'ja']] },

  { g: 'Gebäude', k: 'stellung', l: 'Gebäudestellung', p: 'gebaeude[0].gebaeudestellung', t: 'auswahl', o: [['', '–'], ['freistehend', 'freistehend'], ['DHH', 'Doppelhaushälfte'], ['RMH', 'Reihenmittelhaus'], ['REH', 'Reihenendhaus']], nur: GA35_HAUS },
  { g: 'Gebäude', k: 'baujahr', l: 'Baujahr', p: 'gebaeude[0].baujahr', t: 'zahl', w: 'hoch' },
  { g: 'Gebäude', k: 'bauweise', l: 'Bauweise (massiv, Fertighaus, Holz …)', p: 'gebaeude[0].bauweise', t: 'text', nur: GA35_HAUS, w: 'hoch' },
  { g: 'Gebäude', k: 'geschosse', l: 'Vollgeschosse', p: 'gebaeude[0].vollgeschosse', t: 'zahl', nur: GA35_HAUS },
  { g: 'Gebäude', k: 'zimmer', l: 'Zimmer', p: 'gebaeude[0].zimmer', t: 'zahl' },
  { g: 'Gebäude', k: 'keller', l: 'Keller', p: 'gebaeude[0].keller_anteil_prozent', t: 'auswahl', o: [['', '–'], ['voll', 'voll unterkellert'], ['teil', 'teilunterkellert'], ['kein', 'nicht unterkellert']], nur: GA35_HAUS },
  { g: 'Gebäude', k: 'dach', l: 'Dachform / Dachausbau', p: 'gebaeude[0].dachform', t: 'text', nur: GA35_HAUS },
  { g: 'Gebäude', k: 'nebengebaeude', l: 'Garage, Carport, Stellplatz, Nebengebäude', p: 'aussenanlage[].art', t: 'text' },

  { g: 'Flächen', k: 'wfl', l: 'Wohnfläche innen', p: 'gebaeude[0].wfl_innen_m2', e: 'm²', t: 'zahl', w: 'stop' },
  { g: 'Flächen', k: 'terrasse', l: 'Terrasse/Balkon brutto', p: 'raum[].grundflaeche_m2 (Terrasse/Balkon)', e: 'm²', t: 'zahl' },
  { g: 'Flächen', k: 'terrasse_anteil', l: 'davon angerechnet (z. B. 25 %)', p: 'raum[].anrechnungsfaktor', e: '%', t: 'zahl' },
  { g: 'Flächen', k: 'wfl_regel', l: 'Wohnfläche berechnet nach', p: 'gebaeude[0].wfl_regelwerk', t: 'auswahl', o: [['', 'unbekannt'], ['WoFlV', 'WoFlV'], ['DIN 277', 'DIN 277'], ['II. BV', 'II. BV'], ['Exposé ohne Angabe', 'Exposé ohne Angabe']], w: 'hoch' },
  { g: 'Flächen', k: 'nfl', l: 'Nutzfläche (Keller, Dachboden …)', p: 'gebaeude[0].nutzflaeche_m2', e: 'm²', t: 'zahl' },
  { g: 'Flächen', k: 'wgf', l: 'Wertrelevante Geschossfläche (wGF), falls bekannt', p: 'gebaeude[0].wgf_m2', e: 'm²', t: 'zahl', nur: GA35_HAUS },
  { g: 'Flächen', k: 'bgf', l: 'Brutto-Grundfläche (BGF), falls bekannt', p: 'gebaeude[0].bgf_m2', e: 'm²', t: 'zahl', nur: GA35_HAUS },

  { g: 'Zustand & Energie', k: 'standard', l: 'Ausstattungsstandard', p: 'gebaeude[0].ausstattungsstandard', t: 'auswahl', o: [['', '–'], ['einfach', 'einfach'], ['mittel', 'mittel'], ['gehoben', 'gehoben'], ['stark gehoben', 'stark gehoben']], w: 'hoch' },
  { g: 'Zustand & Energie', k: 'zustand', l: 'Erhaltungszustand (getrennt vom Standard!)', p: 'gebaeude[0].erhaltungszustand', t: 'auswahl', o: [['', '–'], ['neuwertig', 'neuwertig / Neubau'], ['saniert', 'saniert / modernisiert'], ['gepflegt', 'gepflegt'], ['renovierungsbeduerftig', 'renovierungsbedürftig'], ['sanierungsbeduerftig', 'sanierungsbedürftig'], ['abriss', 'abrissreif']], w: 'hoch' },
  { g: 'Zustand & Energie', k: 'modern', l: 'Modernisierungen (Jahr, Umfang, Bauteile, Nachweis)', p: 'modernisierung[]', t: 'lang' },
  { g: 'Zustand & Energie', k: 'schaeden', l: 'Schäden / Mängel / Feuchtigkeit', p: 'schaden[]', t: 'lang' },
  { g: 'Zustand & Energie', k: 'heizung', l: 'Heizung (Art, Brennstoff, Baujahr)', p: 'gebaeude[0].heizung_typ', t: 'text', w: 'hoch' },
  { g: 'Zustand & Energie', k: 'ea_art', l: 'Energieausweis', p: 'gebaeude[0].energieausweis_art', t: 'auswahl', o: [['', 'unbekannt'], ['Bedarf', 'Bedarfsausweis'], ['Verbrauch', 'Verbrauchsausweis'], ['keiner', 'keiner vorhanden']] },
  { g: 'Zustand & Energie', k: 'ea_kw', l: 'Energiekennwert', p: 'gebaeude[0].energiekennwert_kwh_m2a', e: 'kWh/(m²·a)', t: 'zahl' },
  { g: 'Zustand & Energie', k: 'ea_klasse', l: 'Energieklasse', p: 'gebaeude[0].energieklasse', t: 'text' },
  { g: 'Zustand & Energie', k: 'pv', l: 'PV / Speicher / Wallbox', p: 'gebaeude[0].pv_kwp', t: 'text' },

  { g: 'Nutzung & Recht', k: 'nutzung', l: 'Nutzung', p: 'nutzung.status', t: 'auswahl', o: [['', '–'], ['frei', 'bezugsfrei'], ['eigengenutzt', 'eigengenutzt (frei bei Übergabe)'], ['vermietet', 'vermietet'], ['teilvermietet', 'teilvermietet']], w: 'stop' },
  { g: 'Nutzung & Recht', k: 'miete_ist', l: 'Ist-Nettokaltmiete / Monat', p: 'mietvertrag[].nettokaltmiete_eur', e: 'EUR/Monat', t: 'zahl' },
  { g: 'Nutzung & Recht', k: 'mietvertrag', l: 'Mietverträge (Beginn, Staffel/Index, Besonderheiten)', p: 'mietvertrag[]', t: 'lang' },
  { g: 'Nutzung & Recht', k: 'genehmigung', l: 'Genehmigungen / nicht genehmigte Ausbauten', p: 'gebaeude[0].genehmigungsstatus', t: 'text' },
  { g: 'Nutzung & Recht', k: 'mea', l: 'Miteigentumsanteil', p: 'weg.miteigentumsanteil', t: 'text', nur: ['ETW'] },
  { g: 'Nutzung & Recht', k: 'hausgeld', l: 'Hausgeld gesamt / Monat', p: 'weg.hausgeld_eur_monat', e: 'EUR/Monat', t: 'zahl', nur: ['ETW'], w: 'hoch' },
  { g: 'Nutzung & Recht', k: 'ruecklage', l: 'Erhaltungsrücklage (Anteil, Stand)', p: 'weg.ruecklage_anteil_eur', e: 'EUR', t: 'zahl', nur: ['ETW'] },
  { g: 'Nutzung & Recht', k: 'sonderumlage', l: 'Beschlüsse / Sonderumlagen', p: 'weg.sonderumlagen', t: 'lang', nur: ['ETW'] },
  { g: 'Nutzung & Recht', k: 'stockwerk', l: 'Etage / Lage im Haus / Aufzug', p: 'weg.lage_im_gebaeude', t: 'text', nur: ['ETW'] },

  { g: 'Preise', k: 'wunsch', l: 'Wunschpreis Eigentümer (nur Vergleich!)', p: 'auftrag.eigentuemer_wunschpreis', e: 'EUR', t: 'zahl' },
  { g: 'Preise', k: 'angebot', l: 'Aktueller Angebotspreis (falls inseriert)', p: 'auftrag.aktueller_angebotspreis', e: 'EUR', t: 'zahl' },
  { g: 'Preise', k: 'kaufpreis_alt', l: 'Früherer Kaufpreis (Jahr, Betrag)', p: 'auftrag.erwerb', t: 'text' }
];
const GA35_UNTERLAGEN = [
  ['expose', 'Exposé'], ['grundriss', 'Grundrisse'], ['wfl_ber', 'Wohnflächenberechnung'], ['energie', 'Energieausweis'],
  ['grundbuch', 'Grundbuchauszug'], ['flurkarte', 'Flurkarte / Liegenschaftskarte'], ['baulast', 'Baulastenauskunft'], ['baubeschr', 'Baubeschreibung / Bauakte'],
  ['rechnungen', 'Modernisierungsnachweise / Rechnungen'], ['fotos', 'Fotos'], ['gutachten', 'Vorhandenes Gutachten'], ['mietvertraege', 'Mietverträge'],
  ['weg', 'WEG: Teilungserklärung, Protokolle, Wirtschaftsplan', ['ETW']], ['brw', 'Bodenrichtwert-Auszug (BORIS)'], ['ipi', 'Immobilienpreis-Info Berlin (Export/Screenshot)'], ['kps', 'Auskunft Kaufpreissammlung (Gutachterausschuss)']
];
const GA35_PREISART = [['purchase', 'tatsächlicher Kaufpreis'], ['own_closing', 'eigener Abschluss (belegt)'], ['official_aggregate', 'amtliche Statistik (aggregiert)'], ['listing', 'Angebot / Inserat']];
const GA35_FLAECHE = [['Wfl', 'Wohnfläche'], ['wGF', 'wGF'], ['BGF', 'BGF'], ['Grundstück', 'Grundstück'], ['', 'unbekannt']];
const GA35_LINKS = [
  ['Immobilienpreis-Info Berlin (tatsächliche Kauffälle, kostenlos)', 'https://www.berlin.de/gutachterausschuss/marktinformationen/immobilienpreis-info/'],
  ['Bodenrichtwerte Berlin', 'https://www.berlin.de/gutachterausschuss/service/informationen-zu-den-bodenrichtwerten/'],
  ['BORIS Brandenburg', 'https://boris.brandenburg.de/'],
  ['Einzelauskunft Kaufpreissammlung Berlin', 'https://service.berlin.de/dienstleistung/330797/'],
  ['Auskünfte Gutachterausschüsse Brandenburg', 'https://gutachterausschuss.brandenburg.de/gaa/de/service/auskuenfte/']
];
const GA35 = { obj: null };

function ga35Db(){
  if(!db.grossanalyse || typeof db.grossanalyse !== 'object') db.grossanalyse = {};
  const g = db.grossanalyse;
  if(!g.entwuerfe || typeof g.entwuerfe !== 'object') g.entwuerfe = {};
  if(!Array.isArray(g.laeufe)) g.laeufe = [];
  return g;
}
function ga35E(s){ return mc24E(s == null ? '' : s); }
function ga35Heute(){ return new Date(Date.now() - new Date().getTimezoneOffset() * 6e4).toISOString().slice(0, 10); }
function ga35Art(o){
  const t = [o && o.objekttyp, o && o.objektart].filter(Boolean).join(' ').toLowerCase();
  if(!t) return '';
  if(/wohnung|etw|apartment|maisonette|penthouse/.test(t)) return 'ETW';
  if(/mehrfamilien|\bmfh\b|zinshaus|wohn- und geschäft/.test(t)) return 'MFH';
  if(/zweifamilien|\bzfh\b/.test(t)) return 'ZFH';
  if(/doppelhaus|\bdhh\b/.test(t)) return 'DHH';
  if(/reihen|\brh\b|\brmh\b|\breh\b/.test(t)) return 'RH';
  if(/grundst|bauland/.test(t)) return 'Grundstueck';
  if(/einfamilien|\befh\b|haus|bungalow|villa|landhaus/.test(t)) return 'EFH';
  return '';
}
// Herkunft aus der Objektakte (v24) → Status des Master-Prompts
function ga35Herkunft(o, k){
  try{ const a = an24Aktiv(o, k); if(a) return a.herkunft === 'belegt' ? 'documented' : a.herkunft === 'geschaetzt' ? 'assumed' : 'owner_statement'; }catch(e){}
  return 'owner_statement';
}
function ga35AkteWert(o, k){ try{ return an24Wert(o, k); }catch(e){ return o ? o[k] : null; } }
// Vorbelegung aus dem Objekt (Akte, Exposé-Daten, Grunddaten) – nie aus Eigentümer-Kontaktdaten
function ga35Vorbelegen(o){
  const w = {}, setz = (k, v, s) => { if(v === null || v === undefined || v === '') return; w[k] = { v: typeof v === 'number' ? String(v).replace('.', ',') : String(v), s: s || 'owner_statement' }; };
  if(!o) return { art: '', werte: w, vergleich: [], unterlagen: {}, notiz: '', stichtag: ga35Heute(), zweck: 'Verkaufsmarktanalyse', publikum: 'owner', region: '' };
  const adr = String(o.adresse || ''), plz = (/\b(\d{5})\b/.exec(adr + ' ' + (o.ort || '')) || [])[1] || '';
  setz('adresse', adr.replace(/,?\s*\d{5}.*$/, '').trim(), 'documented');
  setz('plz', plz, 'documented');
  setz('ort', String(o.ort || '').replace(/\b\d{5}\b/, '').trim() || (/\d{5}\s+(.+)$/.exec(adr) || [])[1], 'documented');
  setz('ortsteil', o.ortsteil || o.bezirk);
  setz('wfl', ga35AkteWert(o, 'wohnflaeche'), ga35Herkunft(o, 'wohnflaeche'));
  setz('grund', ga35AkteWert(o, 'grundstueck'), ga35Herkunft(o, 'grundstueck'));
  setz('nfl', ga35AkteWert(o, 'nutzflaeche'), ga35Herkunft(o, 'nutzflaeche'));
  setz('zimmer', ga35AkteWert(o, 'zimmer'), ga35Herkunft(o, 'zimmer'));
  setz('baujahr', ga35AkteWert(o, 'baujahr'), ga35Herkunft(o, 'baujahr'));
  const z = ga35AkteWert(o, 'zustand'); if(z && GA35_FELDER.find(f => f.k === 'zustand').o.some(x => x[0] === z)) setz('zustand', z, ga35Herkunft(o, 'zustand'));
  setz('modern', ga35AkteWert(o, 'modernisierung'), ga35Herkunft(o, 'modernisierung'));
  setz('heizung', ga35AkteWert(o, 'energie'), ga35Herkunft(o, 'energie'));
  setz('miete_ist', ga35AkteWert(o, 'miete_ist'), ga35Herkunft(o, 'miete_ist'));
  setz('hausgeld', ga35AkteWert(o, 'hausgeld'), ga35Herkunft(o, 'hausgeld'));
  setz('ruecklage', ga35AkteWert(o, 'ruecklage_stand'), ga35Herkunft(o, 'ruecklage_stand'));
  const verm = ga35AkteWert(o, 'vermietung'); if(verm) setz('nutzung', { bezugsfrei: 'frei', vermietet: 'vermietet', teilvermietet: 'teilvermietet', eigengenutzt: 'eigengenutzt' }[verm] || '', ga35Herkunft(o, 'vermietung'));
  const preis = ga35AkteWert(o, 'kaufpreis');
  if(preis) setz(['online', 'inseriert'].includes(o.status) || o.link ? 'angebot' : 'wunsch', preis, 'owner_statement');
  // Exposé-Felder (v27) als Hinweise, wo passend
  const ef = (o.expose && o.expose.felder) || {};
  const such = re => { const k = Object.keys(ef).find(x => re.test(x)); return k ? ef[k] : null; };
  if(!w.heizung) setz('heizung', such(/heizung|befeuerung/i), 'documented');
  setz('ea_art', /bedarf/i.test(such(/energieausweis/i) || '') ? 'Bedarf' : /verbrauch/i.test(such(/energieausweis/i) || '') ? 'Verbrauch' : '', 'documented');
  const kw = such(/endenergie|energiekennwert|energiebedarf|energieverbrauch/i); if(kw) setz('ea_kw', (String(kw).match(/[\d.,]+/) || [''])[0], 'documented');
  setz('ea_klasse', (String(such(/effizienzklasse|energieklasse/i) || '').match(/\b[A-H]\+?\b/) || [''])[0], 'documented');
  setz('nebengebaeude', such(/garage|stellpl/i), 'documented');
  const art = ga35Art(o), plzN = Number(plz);
  return {
    art, werte: w, vergleich: [], unterlagen: o.expose ? { expose: true } : {}, notiz: '',
    stichtag: ga35Heute(), zweck: 'Verkaufsmarktanalyse', publikum: 'owner',
    region: plz ? (plzN >= 10115 && plzN <= 14199 ? 'Berlin' : 'Brandenburg / Umland') : ''
  };
}
function ga35Entwurf(id){
  const g = ga35Db(), key = id || 'frei';
  if(!g.entwuerfe[key]) g.entwuerfe[key] = ga35Vorbelegen(id ? findObjekt(id) : null);
  const e = g.entwuerfe[key];
  if(!e.werte) e.werte = {}; if(!Array.isArray(e.vergleich)) e.vergleich = []; if(!e.unterlagen) e.unterlagen = {};
  return e;
}
function ga35Felder(art){ return GA35_FELDER.filter(f => !f.nur || !art || f.nur.includes(art)); }

// ── Vollständigkeit / Nachforderungen (Abschnitt A des Master-Prompts) ──
function ga35Pruefen(e){
  const fehlt = [], warn = [], v = k => { const x = e.werte[k]; return x && String(x.v || '').trim() !== '' ? x : null; };
  if(!e.art) fehlt.push({ w: 'stop', t: 'Objektart wählen' });
  ga35Felder(e.art).forEach(f => { if(f.w && !v(f.k)) fehlt.push({ w: f.w, t: f.l + (f.w === 'stop' ? ' fehlt (ohne das kein Ergebnis)' : ' fehlt') }); });
  if(v('erbbau') && v('erbbau').v === 'ja') warn.push('Erbbaurecht: nur mit passendem Fachmodell bewertbar – Erbbauvertrag, Zins und Restlaufzeit nötig.');
  if(v('wfl') && !v('wfl_regel')) warn.push('Wohnfläche ohne Regelwerk (WoFlV/DIN 277) – Flächenbezug unklar.');
  if(v('wfl') && v('wfl').s !== 'documented' && !e.unterlagen.wfl_ber) warn.push('Wohnfläche nicht durch eine Flächenberechnung belegt.');
  const kauf = e.vergleich.filter(c => ['purchase', 'own_closing', 'official_aggregate'].includes(c.art)).length;
  if(!kauf && !e.unterlagen.ipi && !e.unterlagen.kps) warn.push('Keine tatsächlichen Kaufpreise: ' + (e.region === 'Berlin' ? 'Immobilienpreis-Info Berlin abfragen (kostenlos) und Export/Screenshot beilegen.' : 'Gutachterausschuss/Grundstücksmarktbericht prüfen.') + ' Sonst nur „Angebotsmarktindikation“.');
  if(v('wunsch') && v('angebot') && mc24N(v('wunsch').v) && mc24N(v('angebot').v) && mc24N(v('wunsch').v) !== mc24N(v('angebot').v)) warn.push('Wunschpreis und Angebotspreis unterscheiden sich – beide bleiben getrennt.');
  e.vergleich.forEach((c, i) => { if(c.preis && !c.flaeche_art) warn.push(`Vergleichsfall ${i + 1}: Flächenbezug fehlt (Wfl/wGF/BGF).`); if(c.preis && !c.quelle) warn.push(`Vergleichsfall ${i + 1}: Quelle fehlt.`); });
  const stop = fehlt.filter(x => x.w === 'stop').length;
  const stufe = stop ? 'STOP' : (kauf >= 8 && !fehlt.length) ? 'B' : 'C';
  return { fehlt, warn, stop, stufe, kauf };
}

// ── Analysepaket (Eingabevertrag 04_Eingabevorlage.json, erweitert) ──
function ga35Zahl(f, v){ if(f.t !== 'zahl') return v; const n = mc24N(v); return n == null ? v : n; }
function ga35Paket(id, e){
  const o = id ? findObjekt(id) : null, h = ga35Heute();
  const kurz = String((e.werte.adresse || {}).v || (o && aqTitel(o)) || 'objekt').toLowerCase().replace(/ä/g, 'ae').replace(/ö/g, 'oe').replace(/ü/g, 'ue').replace(/ß/g, 'ss').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 24);
  const nr = ga35Db().laeufe.filter(l => l.objektId === (id || 'frei')).length + 1;
  const runId = `GA-${h.replace(/-/g, '')}-${kurz || 'objekt'}-v${nr}`;
  const sources = [{ source_id: 'S-MC', title: 'Erfassung im MaklerCockpit (Objektakte, Gespräch, Besichtigung)', publisher: 'Görner Immobilien', file_or_url: null, published_at: null, accessed_at: h, usage_status: 'intern', allowed_purpose: 'Marktanalyse dieses Objekts', cross_case_reuse_allowed: null, external_ai_processing_allowed: true, report_disclosure_allowed: null, retention_rule: null }];
  let d = 0; const docId = {};
  GA35_UNTERLAGEN.forEach(([k, l]) => { if(e.unterlagen[k]){ const sid = 'D' + (++d); docId[k] = sid; sources.push({ source_id: sid, title: l, publisher: k === 'ipi' || k === 'kps' || k === 'brw' ? 'Gutachterausschuss / amtlich' : 'Eigentümer bzw. Objektunterlagen', file_or_url: 'als Anhang in diesem Chat (falls beigefügt)', published_at: null, accessed_at: h, usage_status: 'beigefügt', allowed_purpose: 'Marktanalyse dieses Objekts', cross_case_reuse_allowed: null, external_ai_processing_allowed: k === 'kps' ? null : true, report_disclosure_allowed: null, retention_rule: null }); } });
  const statusQuelle = s => s === 'documented' ? 'S-MC (Angabe aus Unterlagen, Dokument im Anhang prüfen)' : s === 'visually_inferred' ? 'S-MC (Besichtigung)' : s === 'assumed' ? 'S-MC (Annahme)' : 'S-MC (Eigentümerangabe)';
  const facts = [];
  ga35Felder(e.art).forEach(f => {
    const x = e.werte[f.k]; if(!x || String(x.v || '').trim() === '') return;
    if(f.k === 'adresse' && e.ohneHausnr){ facts.push({ field: f.p, value: String(x.v).replace(/\s+\d+\s*[a-zA-Z]?(\s*[-–]\s*\d+\s*[a-zA-Z]?)?$/, ''), unit: null, source_id: 'S-MC', locator: 'Hausnummer bewusst weggelassen', status: x.s, valid_at: h }); return; }
    facts.push({ field: f.p, label: f.l, value: ga35Zahl(f, x.v), unit: f.e || null, source_id: 'S-MC', locator: statusQuelle(x.s), status: x.s, valid_at: f.k === 'besichtigt' ? x.v : h });
  });
  // vollständige Exposé-Angaben (Objektinformationen) als Dokumentangaben
  if(o && o.expose && o.expose.felder && e.unterlagen.expose){
    Object.entries(o.expose.felder).slice(0, 60).forEach(([k, v]) => facts.push({ field: 'expose.' + k, value: String(v).slice(0, 300), unit: null, source_id: docId.expose || 'S-MC', locator: 'Exposé, Objektinformationen', status: 'documented', valid_at: o.expose.eingelesen ? new Date(o.expose.eingelesen).toISOString().slice(0, 10) : null }));
  }
  const comparables = e.vergleich.filter(c => c.preis || c.lage).map((c, i) => ({
    id: 'V' + (i + 1), source_id: c.quelle ? 'VQ' + (i + 1) : null, source_text: c.quelle || null,
    price_type: c.art || null, price_eur: mc24N(c.preis), price_basis: c.preisbasis || (c.art === 'official_aggregate' ? 'EUR/m² (Statistikwert)' : 'Gesamtpreis'),
    area_type: c.flaeche_art || null, area_m2: mc24N(c.flaeche), plot_m2: mc24N(c.grund), date: c.datum || null, location: c.lage || null,
    year_built: mc24N(c.baujahr), condition: c.zustand || null, dedup_group: null,
    verification_status: c.art === 'listing' ? 'listing_only' : c.beleg ? 'documented' : 'unverified', note: c.notiz || null
  }));
  comparables.forEach(c => { if(c.source_id) sources.push({ source_id: c.source_id, title: c.source_text, publisher: null, file_or_url: null, published_at: null, accessed_at: null, usage_status: c.price_type === 'listing' ? 'Angebotsdaten' : 'Kaufpreisangabe', allowed_purpose: null, cross_case_reuse_allowed: null, external_ai_processing_allowed: null, report_disclosure_allowed: null, retention_rule: null }); });
  const wunsch = e.werte.wunsch && mc24N(e.werte.wunsch.v);
  const p = ga35Pruefen(e);
  return {
    schema_version: '1.0',
    request: {
      run_id: runId, valuation_date: e.stichtag || h, quality_date: (e.werte.besichtigt && e.werte.besichtigt.v) || null, information_as_of: h,
      region: e.region || null, purpose: e.zweck || 'Verkaufsmarktanalyse', requested_output: ['report.json', 'PDF'],
      owner_wish_price_eur: wunsch || null, owner_wish_price_note: wunsch ? 'Nur zum Vergleich anzeigen – niemals zur Steuerung des Ergebniswerts verwenden.' : null
    },
    subject: { object_id: id || null, object_type: e.art || null, object_type_label: (GA35_ARTEN.find(a => a[0] === e.art) || [, null])[1], address: e.ohneHausnr ? null : ((e.werte.adresse || {}).v || null), postcode: (e.werte.plz || {}).v || null, city: (e.werte.ort || {}).v || null, district: (e.werte.ortsteil || {}).v || null },
    sources, facts, comparables,
    model_profiles: [], calculations: [], effects_register: [],
    calibration: { available: false, segment: null, test_sample_size: 0, median_absolute_percentage_error: null, interval_coverage: null },
    report_options: { language: 'de', brand: 'Görner Immobilien', audience: e.publikum || 'owner', include_personal_data: false },
    intake_check: { missing_items: p.fehlt.map(x => x.t), warnings: p.warn, expected_quality_grade_before_research: p.stufe },
    broker_notes: e.notiz ? String(e.notiz).slice(0, 4000) : null
  };
}
// Zusatz für die Nutzung in einem normalen KI-Chat (es gibt dort kein separates Rechenmodul/Regelmodul)
const GA35_CHAT_ZUSATZ = `## Ergänzung für die Nutzung in diesem Chat (gilt zusätzlich zu den Regeln oben)
- Es gibt hier kein separates Rechenmodul und keine vorgeladenen Modellprofile. Führe alle Berechnungen selbst mit deinem Code-/Analysewerkzeug aus und dokumentiere jede als calculation_results-Eintrag (Eingaben mit source_id, Formel, ungerundetes Ergebnis, Einheit). Hast du kein ausführbares Rechenwerkzeug, kennzeichne Berechnungen als ungeprüft und setze den Status höchstens auf needs_review.
- model_profiles ist leer: Recherchiere amtliche Modelle (z. B. Sachwertfaktoren, Bodenrichtwerte, Marktberichte) nur, wenn du sie tatsächlich abrufen kannst, und verwende sie nur mit vollständiger Modellbeschreibung. Sonst als Lücke benennen und mit Szenarien arbeiten.
- „Die Datei 04_Eingabevorlage.json“ entspricht der Struktur des ANALYSEPAKET_JSON unten. Felder mit „label“ und „intake_check“ sind Erfassungshilfen des MaklerCockpits.
- Quellen D1, D2 … sind die Unterlagen, die diesem Chat als Dateien beigefügt sind. Fehlt eine als beigefügt gemeldete Datei, nenne das als Lücke. Prüfe Angaben aus S-MC gegen die beigefügten Dokumente; bei Widerspruch beide Werte behalten und in conflicts aufführen.
- intake_check ist die Vorprüfung des Maklers, keine Bewertung. Die endgültige Qualitätsstufe bestimmst du selbst.
- Liefere am Ende: (1) report.json vollständig in einem Codeblock (zwischen \`\`\` und \`\`\`) – AUSGABE ZUM KOPIEREN: ich kopiere ihn mit einem Klick ins MaklerCockpit; zusätzlich gern als Datei, (2) die geprüfte PDF als Datei, (3) eine kurze priorisierte Nachforderungsliste für den Makler.`;
function ga35Master(){ const g = ga35Db(); return (g.masterprompt && String(g.masterprompt).trim()) || window.GA35_MASTER_STD || ''; }
function ga35Prompt(id, e){
  const paket = ga35Paket(id, e);
  const anh = GA35_UNTERLAGEN.filter(([k]) => e.unterlagen[k]).map(([k, l], i) => `D${i + 1} = ${l}`).join('; ');
  const auftrag = `Erstelle für das beigefügte Analysepaket die Immobilienmarktanalyse zum angegebenen Stichtag (${paket.request.valuation_date}). Wende die Systemregeln vollständig an. Führe zugelassene Recherche und Berechnung aus, soweit die Werkzeuge verfügbar sind. Gib report.json und eine geprüfte PDF aus. Bei entscheidenden Lücken erstelle einen vorläufigen Bericht mit priorisierter Nachforderungsliste. Nutze den Eigentümerwunschpreis ausschließlich zum Vergleich, niemals zur Steuerung des Ergebniswerts.` +
    (anh ? `\n\nBeigefügte Unterlagen: ${anh}.` : '\n\nEs sind keine Unterlagen beigefügt – alle Objektangaben stammen aus der Erfassung (S-MC).');
  const master = ga35Master().replace(/\n?ANALYSEPAKET_JSON:\s*\n<Hier[^>]*>\s*$/, '').replace(/## Vorlage für den jeweils neuen Nutzerauftrag[\s\S]*$/, '').trim();
  return { paket, text: `${master}\n\n${GA35_CHAT_ZUSATZ}\n\n## Auftrag\n${auftrag}\n\nANALYSEPAKET_JSON:\n\`\`\`json\n${JSON.stringify(paket, null, 2)}\n\`\`\`` };
}

// ── Oberfläche ──
function ga35Zeile(f, x){
  const v = x ? x.v : '', s = x ? x.s : 'owner_statement', a = `data-ga="${f.k}"`;
  let inp;
  if(f.t === 'auswahl') inp = `<select ${a}>${f.o.map(([w, l]) => `<option value="${ga35E(w)}"${String(v) === w ? ' selected' : ''}>${ga35E(l)}</option>`).join('')}</select>`;
  else if(f.t === 'lang') inp = `<textarea ${a} rows="2">${ga35E(v)}</textarea>`;
  else inp = `<input ${a} type="${f.t === 'datum' ? 'date' : 'text'}" ${f.t === 'zahl' ? 'inputmode="decimal"' : ''} value="${ga35E(v)}">`;
  const st = `<select class="ga35-st st-${s}" data-gs="${f.k}" title="Herkunft der Angabe">${GA35_STATUS.map(([w, l]) => `<option value="${w}"${s === w ? ' selected' : ''}>${l}</option>`).join('')}</select>`;
  return `<div class="ga35-z${f.w === 'stop' ? ' pflicht' : ''}"><label>${ga35E(f.l)}${f.e ? ` <small>${ga35E(f.e)}</small>` : ''}</label><div class="ga35-w">${inp}${st}</div></div>`;
}
function ga35VergleichHtml(e){
  const z = (c, i) => `<tr data-gv="${i}">
    <td><select data-gc="art">${GA35_PREISART.map(([w, l]) => `<option value="${w}"${c.art === w ? ' selected' : ''}>${l}</option>`).join('')}</select></td>
    <td><input data-gc="datum" value="${ga35E(c.datum)}" placeholder="MM/JJJJ"></td>
    <td><input data-gc="lage" value="${ga35E(c.lage)}" placeholder="Ortsteil / Straße"></td>
    <td><input data-gc="preis" value="${ga35E(c.preis)}" inputmode="decimal" placeholder="€"></td>
    <td><input data-gc="flaeche" value="${ga35E(c.flaeche)}" inputmode="decimal" placeholder="m²"><select data-gc="flaeche_art">${GA35_FLAECHE.map(([w, l]) => `<option value="${w}"${(c.flaeche_art || '') === w ? ' selected' : ''}>${l}</option>`).join('')}</select></td>
    <td><input data-gc="grund" value="${ga35E(c.grund)}" inputmode="decimal" placeholder="m²"></td>
    <td><input data-gc="baujahr" value="${ga35E(c.baujahr)}" inputmode="numeric" placeholder="Bj."></td>
    <td><input data-gc="zustand" value="${ga35E(c.zustand)}" placeholder="Zustand"></td>
    <td><input data-gc="quelle" value="${ga35E(c.quelle)}" placeholder="Quelle (Link, Auskunft, Abschluss-Nr.)"></td>
    <td class="ga35-c"><input type="checkbox" data-gc="beleg"${c.beleg ? ' checked' : ''} title="Beleg liegt vor"></td>
    <td><button class="tiny secondary" onclick="ga35VergleichWeg(${i})" title="Entfernen">✕</button></td></tr>`;
  return `<div class="ga35-tabwrap"><table class="ga35-tab"><thead><tr><th>Preisart</th><th>Datum</th><th>Lage</th><th>Preis</th><th>Fläche</th><th>Grundst.</th><th>Bj.</th><th>Zustand</th><th>Quelle</th><th>Beleg</th><th></th></tr></thead><tbody>${e.vergleich.map(z).join('')}</tbody></table></div>
    <div class="ga35-knoepfe"><button class="secondary" onclick="ga35VergleichNeu()">＋ Vergleichsfall</button><span class="mc24-muted">Inserate als „Angebot“ eintragen – sie gelten nie als Verkauf. Keine Zahlen ausdenken: lieber leer lassen.</span></div>`;
}
function ga35Render(main){
  const g = ga35Db(), objs = (db.objekte || []).slice().sort((a, b) => String(aqTitel(a)).localeCompare(String(aqTitel(b)), 'de'));
  if(GA35.obj && !findObjekt(GA35.obj)) GA35.obj = null;
  const id = GA35.obj, e = ga35Entwurf(id), p = ga35Pruefen(e);
  const gruppen = []; ga35Felder(e.art).forEach(f => { let gr = gruppen.find(x => x.g === f.g); if(!gr){ gr = { g: f.g, f: [] }; gruppen.push(gr); } gr.f.push(f); });
  const laeufe = g.laeufe.filter(l => l.objektId === (id || 'frei')).sort((a, b) => (b.am || 0) - (a.am || 0));
  const stufeTxt = { STOP: '⛔ STOP – Pflichtangaben fehlen', C: '🟠 Erwartbar Stufe C – vorläufige Indikation', B: '🟢 Gute Datenlage – Stufe B möglich' }[p.stufe];
  main.innerHTML = `<div class="ga35">
    <div class="ga35-kopf"><div><h2>🔬 Große Analyse</h2><div class="mc24-muted">Prüfbare Marktanalyse nach dem Görner-Master-Prompt: Angaben mit Herkunft erfassen → ein Prompt für Claude/ChatGPT → report.json + PDF.</div></div>
      <div class="ga35-wahl"><select id="ga35Obj" onchange="ga35ObjWaehlen(this.value)"><option value="">– ohne Objekt (frei erfassen) –</option>${objs.map(o => `<option value="${ga35E(o.id)}"${o.id === id ? ' selected' : ''}>${ga35E(aqTitel(o))}${o.ort ? ' · ' + ga35E(o.ort) : ''}</option>`).join('')}</select>
      <button class="secondary" onclick="ga35Neu()" title="Erfassung aus den Objektdaten neu aufbauen">↺ Neu aus Objekt</button></div></div>
    <div class="ga35-ampel s-${p.stufe}"><b>${stufeTxt}</b>${p.fehlt.length ? `<div>Fehlt: ${p.fehlt.map(x => ga35E(x.t)).join(' · ')}</div>` : ''}${p.warn.length ? `<ul>${p.warn.map(w => `<li>${ga35E(w)}</li>`).join('')}</ul>` : ''}</div>
    <div class="ga35-karte"><h3>Auftrag</h3><div class="ga35-raster">
      <div class="ga35-z pflicht"><label>Objektart</label><div class="ga35-w"><select data-gk="art">${GA35_ARTEN.map(([w, l]) => `<option value="${w}"${e.art === w ? ' selected' : ''}>${l}</option>`).join('')}</select></div></div>
      <div class="ga35-z"><label>Bewertungsstichtag</label><div class="ga35-w"><input type="date" data-gk="stichtag" value="${ga35E(e.stichtag)}"></div></div>
      <div class="ga35-z"><label>Zweck</label><div class="ga35-w"><select data-gk="zweck">${['Verkaufsmarktanalyse', 'Akquise-Orientierung (vor Auftrag)', 'Angebotspreis-Findung', 'Kaufpreisprüfung (Käuferseite)'].map(x => `<option${e.zweck === x ? ' selected' : ''}>${x}</option>`).join('')}</select></div></div>
      <div class="ga35-z"><label>Region</label><div class="ga35-w"><select data-gk="region">${['', 'Berlin', 'Brandenburg / Umland'].map(x => `<option value="${x}"${e.region === x ? ' selected' : ''}>${x || '–'}</option>`).join('')}</select></div></div>
      <div class="ga35-z"><label>Bericht für</label><div class="ga35-w"><select data-gk="publikum"><option value="owner"${e.publikum !== 'intern' ? ' selected' : ''}>Eigentümer (Kundenversion)</option><option value="intern"${e.publikum === 'intern' ? ' selected' : ''}>nur intern</option></select></div></div>
      <div class="ga35-z"><label class="ga35-chk"><input type="checkbox" data-gk="ohneHausnr"${e.ohneHausnr ? ' checked' : ''}> Hausnummer nicht an die KI geben</label></div>
    </div></div>
    <div class="ga35-gitter">${gruppen.map(gr => `<div class="ga35-karte"><h3>${ga35E(gr.g)}</h3>${gr.f.map(f => ga35Zeile(f, e.werte[f.k])).join('')}</div>`).join('')}</div>
    <div class="ga35-karte"><h3>Vergleichsfälle <small class="mc24-muted">(${p.kauf} mit tatsächlichem Kaufpreis)</small></h3>${ga35VergleichHtml(e)}</div>
    <div class="ga35-karte"><h3>Unterlagen, die ich dem Chat beifüge</h3><div class="ga35-unterl">${GA35_UNTERLAGEN.filter(u => !u[2] || !e.art || u[2].includes(e.art)).map(([k, l]) => `<label class="ga35-chk"><input type="checkbox" data-gu="${k}"${e.unterlagen[k] ? ' checked' : ''}> ${ga35E(l)}</label>`).join('')}</div>
      <div class="ga35-links">${GA35_LINKS.map(([l, u]) => `<a href="${u}" target="_blank" rel="noopener">${ga35E(l)} ↗</a>`).join('')}</div></div>
    <div class="ga35-karte"><h3>Notizen für die Analyse <small class="mc24-muted">(keine Namen/Telefonnummern)</small></h3><textarea data-gk="notiz" rows="3" placeholder="z. B. Eindruck bei der Besichtigung, Besonderheiten, Motivation für den Verkauf (ohne persönliche Daten)">${ga35E(e.notiz)}</textarea></div>
    <div class="ga35-aktion">
      <button onclick="ga35PromptKopieren()" ${p.stop ? 'title="Pflichtangaben fehlen – der Prompt geht trotzdem, die KI liefert dann einen vorläufigen Bericht"' : ''}>📋 Prompt erzeugen &amp; kopieren</button>
      <button class="secondary" onclick="ga35JsonKopieren()">{ } Nur Analysepaket (JSON)</button>
      <button class="secondary" onclick="ga35Nachforderung()">📨 Unterlagen beim Eigentümer anfragen</button>
      <button class="secondary" onclick="ga35ErgebnisDialog()">📥 Ergebnis (report.json) einfügen</button>
      <button class="secondary" onclick="ga35MasterDialog()">⚙ Master-Prompt</button>
    </div>
    ${laeufe.length ? `<div class="ga35-karte"><h3>Bisherige Analysen</h3>${laeufe.map(l => ga35LaufHtml(l)).join('')}</div>` : ''}
  </div>`;
}
function ga35Euro(n){ return n == null || !isFinite(n) ? '–' : Math.round(n).toLocaleString('de-DE') + ' €'; }
function ga35LaufHtml(l){
  const r = l.ergebnis;
  return `<div class="ga35-lauf"><div><b>${ga35E(l.runId)}</b> <span class="mc24-muted">· ${new Date(l.am).toLocaleString('de-DE', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' })} · Stichtag ${ga35E(l.stichtag || '–')}</span></div>
    ${r ? `<div>Ergebnis: <b>${ga35Euro(r.central)}</b> (Band ${ga35Euro(r.low)} – ${ga35Euro(r.high)}) · Status ${ga35E(r.status || '–')} · Stufe ${ga35E(r.grade || '–')}${r.bandTyp ? ' · ' + ga35E(r.bandTyp) : ''}</div>` : '<div class="mc24-muted">Prompt erzeugt – Ergebnis noch nicht eingefügt</div>'}
    <div class="ga35-knoepfe">${l.prompt ? `<button class="tiny secondary" onclick="ga35LaufKopieren('${ga35E(l.id)}')">Prompt erneut kopieren</button>` : ''}${r && r.central && l.objektId !== 'frei' ? `<button class="tiny secondary" onclick="ga35Uebernehmen('${ga35E(l.id)}')">Als Einschätzung ins Objekt</button>` : ''}<button class="tiny secondary" onclick="ga35LaufWeg('${ga35E(l.id)}')">Löschen</button></div></div>`;
}
let _ga35Timer = null;
function ga35Merken(neuZeichnen){ clearTimeout(_ga35Timer); _ga35Timer = setTimeout(() => { save(); if(neuZeichnen) ga35Neuzeichnen(); }, neuZeichnen ? 0 : 400); }
function ga35Neuzeichnen(){ const m = document.getElementById('main'); if(m && aktuelleAnsicht === 'grossanalyse'){ const y = m.scrollTop; ga35Render(m); m.scrollTop = y; } }
function ga35Eingabe(ev){
  const t = ev.target; if(!t || !t.closest || !t.closest('.ga35')) return;
  const e = ga35Entwurf(GA35.obj), wert = t.type === 'checkbox' ? t.checked : t.value;
  if(t.dataset.ga){ const k = t.dataset.ga; e.werte[k] = Object.assign({ s: 'owner_statement' }, e.werte[k], { v: wert }); ga35Merken(ev.type === 'change' && t.tagName === 'SELECT'); }
  else if(t.dataset.gs){ const k = t.dataset.gs; e.werte[k] = Object.assign({ v: '' }, e.werte[k], { s: wert }); t.className = 'ga35-st st-' + wert; ga35Merken(false); }
  else if(t.dataset.gk){ e[t.dataset.gk] = wert; ga35Merken(ev.type === 'change' && ['art', 'region'].includes(t.dataset.gk)); }
  else if(t.dataset.gu){ e.unterlagen[t.dataset.gu] = wert; ga35Merken(ev.type === 'change'); }
  else if(t.dataset.gc){ const i = +t.closest('tr').dataset.gv; if(e.vergleich[i]){ e.vergleich[i][t.dataset.gc] = wert; ga35Merken(ev.type === 'change' && (t.dataset.gc === 'art' || t.type === 'checkbox')); } }
}
document.addEventListener('input', ev => { if(aktuelleAnsicht === 'grossanalyse') ga35Eingabe(ev); });
document.addEventListener('change', ev => { if(aktuelleAnsicht === 'grossanalyse') ga35Eingabe(ev); });
function ga35ObjWaehlen(id){ GA35.obj = id || null; ga35Neuzeichnen(); }
function ga35Neu(){
  const key = GA35.obj || 'frei';
  const los = () => { delete ga35Db().entwuerfe[key]; save(); ga35Neuzeichnen(); };
  if(typeof bestaetigeUnten === 'function') bestaetigeUnten('Erfassung neu aus den Objektdaten aufbauen? Eigene Eingaben auf dieser Seite gehen verloren.', los, 'Neu aufbauen');
  else if(confirm('Erfassung neu aufbauen?')) los();
}
function ga35VergleichNeu(){ ga35Entwurf(GA35.obj).vergleich.push({ art: 'purchase', datum: '', lage: '', preis: '', flaeche: '', flaeche_art: 'Wfl', grund: '', baujahr: '', zustand: '', quelle: '', beleg: false }); save(); ga35Neuzeichnen(); }
function ga35VergleichWeg(i){ ga35Entwurf(GA35.obj).vergleich.splice(i, 1); save(); ga35Neuzeichnen(); }
function ga35PromptKopieren(){
  const id = GA35.obj, e = ga35Entwurf(id), r = ga35Prompt(id, e);
  const lauf = { id: uid(), objektId: id || 'frei', runId: r.paket.request.run_id, am: Date.now(), stichtag: r.paket.request.valuation_date, prompt: r.text, ergebnis: null };
  const g = ga35Db(); g.laeufe.push(lauf);
  // nur die letzten 5 Prompts je Objekt im Volltext behalten (Datendatei klein halten)
  g.laeufe.filter(l => l.objektId === lauf.objektId && l.prompt).sort((a, b) => b.am - a.am).slice(5).forEach(l => { delete l.prompt; });
  save();
  if(id){ try{ aqLog(findObjekt(id), 'notiz', `🔬 Große Analyse vorbereitet (${lauf.runId})`); }catch(err){} }
  akqKopieren(r.text, `Prompt kopiert (${Math.round(r.text.length / 1000)} Tsd. Zeichen) – in Claude/ChatGPT einfügen und die Unterlagen anhängen`);
  ga35Neuzeichnen();
}
function ga35JsonKopieren(){ const e = ga35Entwurf(GA35.obj); akqKopieren(JSON.stringify(ga35Paket(GA35.obj, e), null, 2), 'Analysepaket (JSON) kopiert'); }
function ga35LaufKopieren(lid){ const l = ga35Db().laeufe.find(x => x.id === lid); if(l && l.prompt) akqKopieren(l.prompt, 'Prompt kopiert'); }
function ga35LaufWeg(lid){ const g = ga35Db(); g.laeufe = g.laeufe.filter(x => x.id !== lid); save(); ga35Neuzeichnen(); }
function ga35Nachforderung(){
  const e = ga35Entwurf(GA35.obj), fehlen = GA35_UNTERLAGEN.filter(([k, , nur]) => !e.unterlagen[k] && !['ipi', 'kps', 'brw', 'gutachten'].includes(k) && (!nur || !e.art || nur.includes(e.art))).map(u => u[1]);
  const p = ga35Pruefen(e), angaben = p.fehlt.filter(x => !/Objektart/.test(x.t)).map(x => x.t.replace(/ fehlt.*$/, ''));
  const text = `Guten Tag,\n\nfür eine fundierte Marktanalyse Ihrer Immobilie benötige ich noch folgende Unterlagen (soweit vorhanden):\n${fehlen.map(x => '• ' + x).join('\n')}${angaben.length ? `\n\nAußerdem helfen mir diese Angaben:\n${angaben.map(x => '• ' + x).join('\n')}` : ''}\n\nGerne als Foto oder PDF per E-Mail. Vielen Dank!\n\nMit freundlichen Grüßen\nPaul Görner`;
  akqKopieren(text, 'Anfrage-Text kopiert');
}
function ga35MasterDialog(){
  const g = ga35Db(), eigen = !!(g.masterprompt && String(g.masterprompt).trim());
  mc24Modal(`<h3>⚙ Master-Prompt</h3><p class="mc24-muted">${eigen ? 'Eigene Fassung aktiv.' : 'Standard: Görner Master-Prompt Version 1.1 (13.11.2026).'} Der Teil „Vorlage für den jeweils neuen Nutzerauftrag“ wird automatisch ersetzt; dazu kommen die Chat-Ergänzung und das Analysepaket.</p>
    <textarea id="ga35Master" rows="18" style="width:100%;font-family:monospace;font-size:12px">${ga35E(ga35Master())}</textarea>
    <div class="modal-actions"><button class="secondary" onclick="ga35MasterStd()">Standard wiederherstellen</button><div class="right"><button class="secondary" onclick="schliesseModal()">Abbrechen</button><button onclick="ga35MasterSpeichern()">Speichern</button></div></div>`, 860);
}
function ga35MasterSpeichern(){ const t = document.getElementById('ga35Master').value; const g = ga35Db(); g.masterprompt = t.trim() === String(window.GA35_MASTER_STD || '').trim() ? '' : t; save(); schliesseModal(); akqToast('Master-Prompt gespeichert'); }
function ga35MasterStd(){ ga35Db().masterprompt = ''; save(); schliesseModal(); akqToast('Standard-Master-Prompt aktiv'); }
// Ergebnis zurückholen: nur Zahlen und kurze Texte aus report.json übernehmen (KI-Ausgabe = fremde Daten)
function ga35ErgebnisDialog(){
  const l = ga35Db().laeufe.filter(x => x.objektId === (GA35.obj || 'frei')).sort((a, b) => b.am - a.am);
  if(!l.length){ akqToast('Erst einen Prompt erzeugen'); return; }
  mc24Modal(`<h3>📥 Ergebnis einfügen</h3><p class="mc24-muted">Den Inhalt von report.json aus dem KI-Chat hier einfügen. Übernommen werden nur Status, Qualitätsstufe und Preisband.</p>
    <label>Zu Analyse</label><select id="ga35ErgLauf">${l.map(x => `<option value="${ga35E(x.id)}">${ga35E(x.runId)}</option>`).join('')}</select>
    <textarea id="ga35ErgText" rows="12" style="width:100%;font-family:monospace;font-size:12px" placeholder='{ "schema_version": …, "valuation": { "central_eur": … } }'></textarea>
    <div id="ga35ErgMeld" class="mc24-muted"></div>
    <div class="modal-actions"><button class="secondary" onclick="schliesseModal()">Abbrechen</button><div class="right"><button onclick="ga35ErgebnisSpeichern()">Übernehmen</button></div></div>`, 720);
}
function ga35ErgebnisLesen(txt){
  let t = String(txt || '').trim(); const m = /```(?:json)?\s*([\s\S]*?)```/.exec(t); if(m) t = m[1];
  const a = t.indexOf('{'), b = t.lastIndexOf('}'); if(a < 0 || b < a) throw new Error('Kein JSON gefunden');
  const r = JSON.parse(t.slice(a, b + 1)), v = r.valuation || {};
  const zahl = x => { const n = typeof x === 'number' ? x : mc24N(x); return n != null && isFinite(n) && n > 0 && n < 1e10 ? Math.round(n) : null; };
  const kurz = x => x == null ? null : String(x).replace(/[<>]/g, '').slice(0, 40);
  const erg = { central: zahl(v.central_eur), low: zahl(v.low_eur), high: zahl(v.high_eur), bandTyp: kurz(v.band_type), grade: kurz(v.quality_grade), status: kurz(r.status), runId: kurz(r.run_id), uebernommenAm: Date.now() };
  if(erg.status === 'blocked') erg.central = null;   // Master-Prompt: bei blocked kein freigegebener Wert
  if(erg.low && erg.high && erg.low > erg.high){ const x = erg.low; erg.low = erg.high; erg.high = x; }
  return erg;
}
function ga35ErgebnisSpeichern(){
  const meld = document.getElementById('ga35ErgMeld');
  try{
    const erg = ga35ErgebnisLesen(document.getElementById('ga35ErgText').value);
    const l = ga35Db().laeufe.find(x => x.id === document.getElementById('ga35ErgLauf').value); if(!l) throw new Error('Analyse nicht gefunden');
    if(erg.runId && erg.runId !== l.runId) meld.textContent = `Hinweis: run_id im Ergebnis (${erg.runId}) weicht ab – trotzdem übernommen.`;
    l.ergebnis = erg; save(); schliesseModal(); ga35Neuzeichnen();
    akqToast(erg.central ? `Ergebnis übernommen: ${ga35Euro(erg.central)}` : `Ergebnis übernommen (Status ${erg.status || '–'}, kein freigegebener Wert)`);
  }catch(err){ meld.textContent = '⚠️ ' + err.message; }
}
function ga35Uebernehmen(lid){
  const l = ga35Db().laeufe.find(x => x.id === lid), o = l && findObjekt(l.objektId); if(!o || !l.ergebnis || !l.ergebnis.central) return;
  o.einschaetzung = l.ergebnis.central;
  try{ aqLog(o, 'notiz', `🔬 Große Analyse ${l.runId}: ${ga35Euro(l.ergebnis.central)} (Band ${ga35Euro(l.ergebnis.low)} – ${ga35Euro(l.ergebnis.high)}, Stufe ${l.ergebnis.grade || '–'})`); }catch(err){}
  save(); akqToast('Als Einschätzung im Objekt gespeichert');
}
// Ansicht
const _ga35Render = renderMain;
renderMain = function(){
  if(aktuelleAnsicht === 'grossanalyse'){ const main = document.getElementById('main'); if(main){ try{ if(typeof pdf33Verstecken === 'function') pdf33Verstecken(); }catch(e){} ga35Render(main); return; } }
  return _ga35Render.apply(this, arguments);
};
// Aus dem Objekt heraus starten
function ga35FuerObjekt(id){ GA35.obj = id; if(typeof schliesseModal === 'function') try{ schliesseModal(); }catch(e){} wechsleAnsicht('grossanalyse'); }
(function(){
  const st = document.createElement('style');
  st.textContent = `.ga35{max-width:1280px;margin:0 auto;padding-bottom:40px}
.ga35-kopf{display:flex;gap:16px;align-items:flex-start;justify-content:space-between;flex-wrap:wrap;margin-bottom:12px}.ga35-kopf h2{margin:0 0 4px}
.ga35-wahl{display:flex;gap:8px;align-items:center}.ga35-wahl button{white-space:nowrap}.ga35-wahl select{min-width:280px;max-width:420px}
.ga35-ampel{border-radius:10px;padding:10px 14px;margin-bottom:12px;border:1px solid var(--border);background:var(--card);font-size:13px}
.ga35-ampel.s-STOP{border-color:var(--red)}.ga35-ampel.s-C{border-color:var(--yellow)}.ga35-ampel.s-B{border-color:var(--green)}.ga35-ampel ul{margin:6px 0 0 18px;padding:0}
.ga35-karte{background:var(--card);border:1px solid var(--border);border-radius:10px;padding:12px 14px;margin-bottom:12px}.ga35-karte h3{margin:0 0 10px;font-size:15px}
.ga35-gitter{display:grid;grid-template-columns:repeat(auto-fill,minmax(400px,1fr));gap:12px}.ga35-gitter .ga35-karte{margin:0}
.ga35-raster{display:grid;grid-template-columns:repeat(auto-fill,minmax(230px,1fr));gap:4px 14px}
.ga35-z{margin-bottom:7px}.ga35-z label{display:block;font-size:12px;color:var(--muted);margin-bottom:2px}.ga35-z.pflicht label::after{content:' *';color:var(--orange)}
.ga35-w{display:flex;gap:6px}.ga35-w input,.ga35-w select,.ga35-w textarea{flex:1;min-width:0}.ga35-w textarea{resize:vertical}
.ga35-st{flex:0 0 112px!important;font-size:12px}.ga35-st.st-documented{color:var(--green)}.ga35-st.st-assumed{color:var(--yellow)}.ga35-st.st-visually_inferred{color:var(--blue)}
.ga35 .ga35-chk{display:flex!important;gap:8px;align-items:center;justify-content:flex-start;font-size:13px;color:var(--text)!important;text-transform:none;letter-spacing:0;font-weight:400;margin:0;text-align:left}.ga35 .ga35-chk input{width:auto!important;flex:0 0 auto;margin:0}
.ga35-unterl{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:4px 14px}
.ga35-links{display:flex;flex-wrap:wrap;gap:6px 16px;margin-top:10px;font-size:12px}.ga35-links a{color:var(--orange)}
.ga35-tabwrap{overflow-x:auto}.ga35-tab{width:100%;border-collapse:collapse;font-size:12px}.ga35-tab th{text-align:left;color:var(--muted);font-weight:500;padding:4px}.ga35-tab td{padding:3px}.ga35-tab input,.ga35-tab select{width:100%;min-width:70px;font-size:12px}
.ga35-tab td:nth-child(5){display:flex;gap:4px;min-width:150px}.ga35-tab td:nth-child(9) input{min-width:170px}.ga35-c{text-align:center}.ga35-c input{width:auto;min-width:0}
.ga35-knoepfe{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-top:8px}
.ga35-aktion{display:flex;gap:8px;flex-wrap:wrap;margin:4px 0 14px;position:sticky;bottom:0;background:var(--bg);padding:10px 0;z-index:2}
.ga35-lauf{border-top:1px solid var(--border);padding:8px 0;font-size:13px}.ga35-lauf:first-of-type{border-top:0}
.ga35 textarea[data-gk="notiz"]{width:100%}
@media (max-width:760px){.ga35-gitter{grid-template-columns:1fr}.ga35-wahl{width:100%;flex-wrap:wrap}.ga35-wahl select{min-width:0;flex:1}.ga35-st{flex-basis:96px!important}.ga35-aktion button{flex:1 1 45%}}`;
  document.head.appendChild(st);
})();
