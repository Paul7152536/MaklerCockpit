// ═══ MaklerCockpit v49 – Anrufliste fügt jetzt wirklich alle Erstgespräche am Telefon zusammen ═══
// Warum in v48 manche Termine einzeln blieben (Pauls Kalender 19.11.):
//  1) Telefon-„Erstgespräch“ hatte den Lead auf Status „Termin“ gesetzt → v48 hielt das für „schon gesprochen“ (Nachfassen).
//  2) Lead ohne eigene Nummer (gleicher Verkäufer mit zwei Inseraten) → Nummer aus dem Termin wurde nicht übernommen.
//  3) Termin nur mit Telefonnummer, ohne Lead → passte nicht in die Liste (die kannte nur Leads).
// Jetzt: Erstgespräch/Erstkontakt per Telefon zählt immer als Erstkontakt; Nummer aus dem Termin gilt; Termine ohne Lead kommen als eigene Zeile mit.
// Gleiche Nummer (ein Verkäufer, mehrere Inserate) = EIN Anruf, eine Zeile.

function ek49Extras(){ const a = akqDb(); if(!a.anrufExtra || typeof a.anrufExtra !== 'object') a.anrufExtra = {}; return a.anrufExtra; }
function ek49Gesprochen(o){ return ['auftrag', 'online', 'abgeschlossen'].includes(o.status) || (o.verlauf || []).some(v => v.typ === 'gespraech' || /Angerufen – erreicht/.test(String(v.text || ''))); }
function ek49Erstkontakt(t, o){
  if(t.telefonArt) return t.telefonArt === 'erstkontakt';
  const txt = [t.titel, t.artEigene].filter(Boolean).join(' ');
  if(t.art === 'erstgespraech' || /erstgespr|erstkontakt/i.test(txt)) return true;
  if(/nachfass|r[üu]ckruf|zur[üu]ckruf/i.test(txt)) return false;     // vereinbarter Rückruf behält seine Uhrzeit
  if(o){ if(o.telefonArt) return o.telefonArt === 'erstkontakt'; return !ek49Gesprochen(o); }
  return false;
}
ek48IstErstkontakt = function(t, o){ return ek49Erstkontakt(t, o); };
function ek49Titel(t){
  let s = String(t.titel || '').replace(VB47_TEL, ' ').replace(/\bmit\s+[A-ZÄÖÜ][\wäöüß.\-]*(?:\s+[A-ZÄÖÜ][\wäöüß.\-]*)?/, ' ');
  s = s.replace(/📞|☎️?/g, ' ').replace(/\b(erstgespr(ä|ae)ch|erstkontakt|telefontermin|telefonat|anruf(en)?|r[üu]ckruf)\b/gi, ' ').replace(/^\s*(mit|:|–|-)\s*/i, '').replace(/\s+/g, ' ').replace(/^[\s:–-]+|[\s:–-]+$/g, '').trim();
  return /^mit\s/i.test(s) ? '' : s;
}
function ek49NameAus(t){
  const n = vb47Name(vb47Text(t)); if(n) return n;
  const m = String(t.titel || '').match(/\bmit\s+([A-ZÄÖÜ][\wäöüß.\-]*(?:\s+[A-ZÄÖÜ][\wäöüß.\-]*)?)/);
  return m ? m[1].trim() : '';
}
function ek49KurzTitel(o){ const s = String(aqTitel(o) || '').replace(/\s+/g, ' ').trim(); if(s.length <= 50) return s; const k = s.slice(0, 50); const i = k.lastIndexOf(' '); return (i > 25 ? k.slice(0, i) : k).replace(/[\s,:;–-]+$/, '') + '…'; }

// ── Zusammenfügen (ersetzt v48) ──
ek48Zusammenfuegen = function(){
  if(!db || !Array.isArray(db.termine) || !Array.isArray(db.objekte)) return 0;
  const h = ak47Heute(), tage = new Set(), weg = new Set(), X = ek49Extras();
  for(const t of db.termine){
    if(t.anrufliste || t.erledigt || !t.datum || t.datum < h || t.bisDatum) continue;
    if(!(t.art === 'rueckruf' || (typeof twWo === 'function' && twWo(t) === 'telefon'))) continue;
    const tels = vb47Tels(vb47Text(t));
    let o = t.objektId ? findObjekt(t.objektId) : null;
    if(t.objektId && !o) continue;
    if(!o){ o = vb47ObjektZuTermin(t, tels); if(o){ t.objektId = o.id; try{ aqLog(o, 'termin', '📅 Kalendertermin zugeordnet: ' + (t.titel || '')); }catch(e){} } }
    if(!ek49Erstkontakt(t, o)) continue;
    if(o){
      if(!aqTel(o)){ if(!tels[0]) continue; o.verkaeuferTelefon = tels[0]; try{ aqLog(o, 'info', '📞 Telefonnummer aus dem Termin übernommen: ' + tels[0]); }catch(e){} }
      if(!aqName(o)){ const nm = ek49NameAus(t); if(nm){ o.verkaeuferName = nm; try{ aqLog(o, 'info', '👤 Name aus dem Termin übernommen: ' + nm); }catch(e){} } }
      const alt = o.anrufTag && o.anrufTag >= h ? o.anrufTag : '';
      o.anrufTag = alt && alt < t.datum ? alt : t.datum;
      if(alt && alt !== o.anrufTag) tage.add(alt);
      if(o.anrufErledigt && o.anrufErledigt !== o.anrufTag) delete o.anrufErledigt;
      o.telefonArt = 'erstkontakt';
      if(!['termin', 'telefontermin', 'auftrag', 'online', 'abgeschlossen'].includes(o.status) || (o.status === 'termin' && !(db.termine || []).some(x => x !== t && x.objektId === o.id && x.datum >= h && typeof twWo === 'function' && twWo(x) === 'vorort'))){ o.status = 'telefontermin'; o.statusAm = Date.now(); }
      try{
        if(String(t.notiz || '').trim()) aqLog(o, 'notiz', 'Notiz zum Telefontermin: ' + String(t.notiz).trim());
        aqLog(o, 'termin', '📞 Telefontermin (Erstkontakt) ' + ak47TagKurz(o.anrufTag) + ' in die Anrufliste um ' + ak47Zeit() + ' Uhr übernommen');
      }catch(e){}
      tage.add(o.anrufTag);
    } else {
      if(!tels[0]) continue;                                        // ohne Nummer bleibt der Termin, wie er ist
      const l = X[t.datum] = Array.isArray(X[t.datum]) ? X[t.datum] : [];
      if(!l.some(e => e.tid === t.id)) l.push({ id: uid(), tid: t.id, titel: ek49Titel(t), name: ek49NameAus(t), tel: tels[0], notiz: String(t.notiz || '').trim(), am: Date.now() });
      tage.add(t.datum);
    }
    if(t.googleEventId){ try{ const c = gsCfg(); c.zusammen = c.zusammen || {}; c.zusammen[t.googleEventId] = Date.now(); }catch(e){} }
    weg.add(t.id);
  }
  if(weg.size) db.termine = db.termine.filter(t => !weg.has(t.id));
  tage.forEach(d => ak47TerminAktualisieren(d));
  return weg.size;
};

// ── Kalendereintrag: Leads + Termine ohne Lead, gleiche Nummer = ein Anruf ──
function ek49Gruppen(datum){
  const gr = new Map();
  const add = (k, titel, name, tel, fertig, quelle) => {
    const g = gr.get(k) || { titel: [], name: '', tel, fertig: true, quellen: [] };
    if(titel && !g.titel.includes(titel)) g.titel.push(titel);
    if(!g.name && name) g.name = name;
    g.fertig = g.fertig && fertig; g.quellen.push(quelle); gr.set(k, g);
  };
  ak47Leads(datum).forEach(o => add(vb25Tel(aqTel(o)) || o.id, ek49KurzTitel(o), aqName(o), aqTel(o), o.anrufErledigt === datum, { o }));
  ek49ExtraListe(datum).forEach(e => add(vb25Tel(e.tel) || e.id, e.titel, e.name, e.tel, !!e.erledigt, { e }));
  return [...gr.values()];
}
function ek49Zeile(g){ return [g.titel.join(' + '), g.name, g.tel].filter(Boolean).join(' – ') || g.tel || 'Anruf'; }
ak47TerminAktualisieren = function(datum){
  const gl = ek49Gruppen(datum), id = ak47TerminId(datum), t = (db.termine || []).find(x => x.id === id);
  if(!gl.length){ if(t){ db.termine = db.termine.filter(x => x.id !== id); } const X = ek49Extras(); if(X[datum] && !X[datum].length) delete X[datum]; return null; }
  const offen = gl.filter(g => !g.fertig).length;
  const daten = {
    titel: gl.length === 1 ? '📞 ' + ek49Zeile(gl[0]) : `📞 Anrufen: ${gl.length} Telefontermine${offen < gl.length ? ` (${offen} offen)` : ''}`,
    datum, uhrzeit: ak47Zeit(), dauer: Math.min(180, 15 * gl.length), art: 'rueckruf', artEigene: '', ort: '', wo: 'telefon',
    notiz: gl.map(g => (g.fertig ? '✓ ' : '') + ek49Zeile(g)).join('\n'), objektId: null, kontaktId: null, anrufliste: true };
  if(t){
    if(['titel', 'notiz', 'dauer', 'uhrzeit', 'ort', 'wo'].some(k => t[k] !== daten[k])){ Object.assign(t, daten); t.geaendertAm = Date.now(); }
    return t;
  }
  const neu = Object.assign({ id, createdAt: Date.now(), geaendertAm: Date.now() }, daten);
  db.termine.push(neu); return neu;
};
// Alle Tage mit Liste (Leads oder Termine ohne Lead)
function ek49Tage(){
  const h = ak47Heute(), s = new Set((db.objekte || []).map(o => o.anrufTag).filter(d => d && d >= h));
  Object.keys(ek49Extras()).forEach(d => { if(d >= h && (ek49Extras()[d] || []).length) s.add(d); });
  return [...s].sort();
}
ek48AlleListenAktualisieren = function(){
  const h = ak47Heute(), tage = new Set(ek49Tage());
  (db.termine || []).filter(t => t.anrufliste && t.datum >= h).forEach(t => tage.add(t.datum));
  let n = 0; tage.forEach(d => { const t = (db.termine || []).find(x => x.id === ak47TerminId(d)), vor = t ? t.geaendertAm : 0, neu = ak47TerminAktualisieren(d); if(!neu || !t || neu.geaendertAm !== vor) n++; });
  // alte Zusatz-Einträge (vergangene Tage) aufräumen
  const X = ek49Extras(); Object.keys(X).forEach(d => { if(d < gsTagPlus(h, -14)) delete X[d]; });
  return n;
};
function ek49Extra(datum, id){ return (ek49Extras()[datum] || []).find(e => e.id === id); }
function ek49ExtraErledigt(datum, id){ const e = ek49Extra(datum, id); if(!e) return; e.erledigt = !e.erledigt; ak47TerminAktualisieren(datum); save(); if(typeof gsPlanen === 'function') gsPlanen(400); ak47ListeDialog(datum); }
function ek49ExtraEntfernen(datum, id){ const X = ek49Extras(); X[datum] = (X[datum] || []).filter(e => e.id !== id); ak47TerminAktualisieren(datum); save(); if(typeof gsPlanen === 'function') gsPlanen(400); ak47ListeDialog(datum); }
function ek49Tel(t){ return String(t || '').replace(/[^\d+]/g, ''); }

// ── Anrufliste im Cockpit (ersetzt v47/v48) ──
ak47ListeDialog = function(datum){
  const tage = ek49Tage();
  datum = datum || ak47Heute();
  if(!tage.includes(datum)) datum = tage[0] || datum;
  const l = ak47Leads(datum), x = ek49ExtraListe(datum), E = mc24E, anz = ek49Gruppen(datum).length;
  const tagKnopf = d => `<button class="${d === datum ? '' : 'secondary'} tiny" onclick="ak47ListeDialog('${d}')">${d === ak47Heute() ? 'Heute' : ak47TagKurz(d)} (${ek49Gruppen(d).length})</button>`;
  const leadZeile = o => {
    const link = /^https?:\/\//i.test(o.link || '') ? `<a href="#" onclick="aqLinkOeffnen('${o.id}');return false;">🔗 Inserat öffnen</a>` : (o.quelle === 'Zeitung' ? '📰 aus der Zeitung' : '');
    return `<div class="ak47-z${o.anrufErledigt === datum ? ' fertig' : ''}">
      <div class="ak47-info"><b>${E(aqTitel(o) || 'Lead')}</b><div class="mc24-muted">${E([aqName(o), aqOrtKurz(o), o.kaufpreis ? aqEur(o.kaufpreis) : ''].filter(Boolean).join(' · '))}</div>
        <div class="ek48-extra">${o.telefonArt === 'nachfassen' ? '🔁 Nachfassen' : '🆕 Erstkontakt'}${link ? ' · ' + link : ''}</div></div>
      <a class="ak47-tel" href="#" onclick="ak47Anrufen('${o.id}');return false;">📞 ${E(aqTel(o))}</a>
      <button class="secondary tiny" onclick="ak47Erledigt('${o.id}','${datum}')">${o.anrufErledigt === datum ? '↺ offen' : '✓ erledigt'}</button>
      <button class="secondary tiny" title="Von der Liste nehmen" onclick="ak47Entfernen('${o.id}');ak47ListeDialog('${datum}')">✕</button></div>`;
  };
  const extraZeile = e => `<div class="ak47-z${e.erledigt ? ' fertig' : ''}">
      <div class="ak47-info"><b>${E(e.titel || 'Anruf')}</b><div class="mc24-muted">${E([e.name, 'ohne Lead im Cockpit'].filter(Boolean).join(' · '))}</div>${e.notiz ? `<div class="ek48-extra">${E(e.notiz).slice(0, 200)}</div>` : ''}</div>
      <a class="ak47-tel" href="tel:${E(ek49Tel(e.tel))}">📞 ${E(e.tel)}</a>
      <button class="secondary tiny" onclick="ek49ExtraErledigt('${datum}','${e.id}')">${e.erledigt ? '↺ offen' : '✓ erledigt'}</button>
      <button class="secondary tiny" title="Von der Liste nehmen" onclick="ek49ExtraEntfernen('${datum}','${e.id}')">✕</button></div>`;
  mc24Modal(`<h3>📞 Anrufliste</h3>
    <div class="ak47-tage">${tage.map(tagKnopf).join('') || '<span class="mc24-muted">Keine Anrufe geplant.</span>'}</div>
    ${anz ? `<div class="ak47-zeit">Kalendereintrag um <input type="time" value="${E(ak47Zeit())}" onchange="ak47ZeitSetzen('${datum}', this.value)"> Uhr · ${anz} Anruf${anz === 1 ? '' : 'e'} à 15 Min. in einem Eintrag
      <div class="ek48-k mc24-muted">Im Kalender steht nur: Objekt – Name – Telefon. Link und Details stehen hier.</div></div>
    <div class="ak47-liste">${l.map(leadZeile).join('')}${x.map(extraZeile).join('')}</div>` : ''}
    <div class="modal-actions"><span class="mc24-muted" style="font-size:12px;">Gleiche Nummer (ein Verkäufer, mehrere Inserate) = ein Anruf.</span><div class="right"><button class="secondary" onclick="schliesseModal()">Schließen</button></div></div>`, 640);
};

// ── Doppelte Zusatz-Zeilen (gleicher Termin auf zwei Geräten zusammengefügt) ausblenden ──
function ek49ExtraListe(datum){
  const l = ek49Extras()[datum] || [], gesehen = new Set();
  return l.filter(e => { const k = e.tid || ('t' + vb25Tel(e.tel)); if(gesehen.has(k)) return false; gesehen.add(k); return true; });
}

// ── „Termin bearbeiten“ / „Neuer Termin“: Knopf „📞 Telefontermin – Erstkontakt“ auch hier ──
// Ein schon gesetzter Termin lässt sich damit in die Anrufliste (8:00, 15 Min.) verschieben.
function ek49DialogUmwandeln(id){
  const g = x => document.getElementById(x);
  const datum = (g('m_t_datum') || {}).value; if(!datum){ akqToast('Bitte ein Datum wählen.'); return; }
  const oid = (g('m_t_objekt') || {}).value || null, kid = (g('m_t_kontakt') || {}).value || null;
  const o = oid ? findObjekt(oid) : null, k = kid ? findKontakt(kid) : null;
  const text = ['m_t_titel', 'm_t_ort', 'm_t_notiz', 'm_t_vbtel'].map(x => (g(x) || {}).value || '').join('\n');
  const tels = vb47Tels(text), tel = (o && aqTel(o)) || ((g('m_t_vbtel') || {}).value || '').trim() || tels[0] || (k && k.telefon) || '';
  if(!tel){ akqToast('Für den Erstkontakt fehlt die Telefonnummer – bitte bei „Telefon“ eintragen.', 5000); const f = g('m_t_vbtel') || g('m_t_ort'); if(f) f.focus(); return; }
  if(o && !aqTel(o)){ o.verkaeuferTelefon = tel; try{ aqLog(o, 'info', '📞 Telefonnummer eingetragen: ' + tel); }catch(e){} }
  const name = ((g('m_t_vbname') || {}).value || '').trim();
  if(o && name && !aqName(o)) o.verkaeuferName = name;
  if(o){ o.telefonArt = 'erstkontakt'; }
  let t = id ? (db.termine || []).find(x => x.id === id) : null;
  const daten = { titel: ((g('m_t_titel') || {}).value || '').trim() || 'Erstkontakt', datum, uhrzeit: ak47Zeit(), dauer: 15, art: 'rueckruf', wo: 'telefon', telefonArt: 'erstkontakt',
    ort: tel, notiz: ((g('m_t_notiz') || {}).value || '').trim(), objektId: oid, kontaktId: kid };
  if(t){ Object.assign(t, daten); t.geaendertAm = Date.now(); }
  else { t = Object.assign({ id: uid(), createdAt: Date.now(), geaendertAm: Date.now() }, daten); db.termine.push(t); }
  if(!o && name){ t.titel = (t.titel + ' mit ' + name).trim(); }
  const vorher = db.termine.length;
  ek48Zusammenfuegen();
  save(); schliesseModal(); try{ renderMain(); }catch(e){} if(typeof gsPlanen === 'function') gsPlanen(400);
  const n = ek49Gruppen(datum).length;
  akqToast(db.termine.length < vorher || !db.termine.includes(t)
    ? `📞 Erstkontakt ${ak47TagKurz(datum)} ${ak47Zeit()} Uhr – ${n === 1 ? 'eigener Kalendereintrag' : 'zusammen mit ' + (n - 1) + ' weiteren in einem Kalendereintrag'}`
    : '📞 Als Telefontermin gespeichert', 5000);
}
(function(){
  const _m = oeffneTerminModal;
  oeffneTerminModal = function(id){
    const r = _m.apply(this, arguments);
    try{
      if(typeof id === 'string' && /^anrufliste-/.test(id)) return r;
      const tw = document.getElementById('m_t_wo'), box = tw && tw.closest('.tw-box');
      if(box && !document.getElementById('ek49Knopf')){
        box.insertAdjacentHTML('afterend', `<button type="button" id="ek49Knopf" class="ek48-knopf" onclick="ek49DialogUmwandeln(${id ? `'${String(id).replace(/'/g, '')}'` : 'null'})">📞 Telefontermin – Erstkontakt<small>auf ${ak47Zeit()} Uhr · 15 Min. · in die Anrufliste des Tages (ein Kalendereintrag für alle)</small></button>`);
      }
    }catch(e){ console.error('ek49 Dialog', e); }
    return r;
  };
})();
