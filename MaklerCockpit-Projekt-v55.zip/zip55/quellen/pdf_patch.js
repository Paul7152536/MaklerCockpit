/* v17: PDF-Speichern im PC-Programm – jsPDF.save() öffnet „Speichern unter“ über das Programm (auch aus eingebetteten Modulen) */
(function(){
  function host(){
    try{ if(typeof window.mcPdfSpeichern === 'function' && window.pc && window.pc.dateiSpeichern) return window; }catch(e){}
    try{ var p = window.parent; if(p && p !== window && typeof p.mcPdfSpeichern === 'function' && p.pc && p.pc.dateiSpeichern) return p; }catch(e){}
    return null;
  }
  var ns = window.jspdf; if(!ns || !ns.jsPDF || ns.jsPDF.__mc) return;
  var Orig = ns.jsPDF;
  function MC(){
    var d = Reflect.construct(Orig, Array.prototype.slice.call(arguments));
    var orig = d.save;
    d.save = function(name, opts){
      var H = host();
      if(!H) return orig.call(d, name, opts);
      try{ H.mcPdfSpeichern(name || 'Dokument.pdf', d.output('datauristring').split(',')[1]); }
      catch(e){ return orig.call(d, name, opts); }
      return (opts && opts.returnPromise) ? Promise.resolve(d) : d;
    };
    return d;
  }
  Object.getOwnPropertyNames(Orig).forEach(function(k){ if(['length','name','prototype','arguments','caller'].indexOf(k) < 0){ try{ MC[k] = Orig[k]; }catch(e){} } });
  MC.prototype = Orig.prototype; MC.__mc = true;
  ns.jsPDF = MC;
})();
