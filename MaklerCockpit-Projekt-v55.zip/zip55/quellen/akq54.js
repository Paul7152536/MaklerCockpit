// ═══ MaklerCockpit v54 – Titel aus dem echten Inserat + „Schnell durchsehen“ statt vieler Browser-Tabs ═══
// • Jedes neue Kleinanzeigen-Inserat wird im Hintergrund kurz gelesen (nur der Text, ohne Fenster, ohne Bilder, ohne Werbung):
//   echter Titel, Preis, Ort, Datum, Privat/Gewerblich, Beschreibung, „keine Makler“, offline.
//   Weicht der KI-Titel ab, wird er durch den echten ersetzt (der KI-Titel bleibt im Verlauf).
// • „Schnell durchsehen“: neue Leads als Karten nacheinander – statt 10 Browser-Tabs. Inserat bei Bedarf einzeln öffnen.

const AK54 = { warte: [], laeuft: false, gebremst: 0, pos: 0, ids: [], cache: {} };
function ak54IstKa(u){ return /^https:\/\/([a-z0-9-]+\.)*kleinanzeigen\.de\/s-anzeige\//i.test(String(u || '')); }
function ak54KannLesen(){ return !!(window.pc && ((window.pc.geraet === 'pc' && typeof window.pc.webfenster === 'function') || typeof window.pc.seite === 'function')); }
function ak54Pruefbar(o){ return !!(o && ak54IstKa(o.link) && ak54KannLesen()); }
async function ak54Holen(url){
  try{
    if(window.pc && window.pc.geraet === 'pc' && typeof window.pc.webfenster === 'function') return await window.pc.webfenster('lesen', { url });
    if(window.pc && typeof window.pc.seite === 'function') return await window.pc.seite(url);
  }catch(e){ return { ok: false, fehler: String(e.message || e) }; }
  return { ok: false, fehler: 'Nur im Programm (PC/Handy) möglich' };
}
function ak54Text(el){ return el ? String(el.textContent || '').replace(/\s+/g, ' ').trim() : ''; }
function ak54Parse(html, url){
  const d = new DOMParser().parseFromString(String(html || ''), 'text/html');
  const meta = n => { const m = d.querySelector(`meta[property="${n}"], meta[name="${n}"]`); return m ? String(m.getAttribute('content') || '').trim() : ''; };
  let titel = ak54Text(d.querySelector('#viewad-title')) || meta('og:title') || ak54Text(d.querySelector('h1'));
  titel = titel.replace(/\s*[|–-]\s*(eBay\s*)?Kleinanzeigen.*$/i, '').trim();
  let status = 'online';
  const roh = String(html || '');
  if(/^(Reserviert|Gelöscht)\s*•\s*/i.test(titel)){ status = /^Reserviert/i.test(titel) ? 'reserviert' : 'offline'; titel = titel.replace(/^(Reserviert|Gelöscht)\s*•\s*/i, ''); }
  if(!d.querySelector('#viewad-title') && /(Anzeige ist nicht mehr verf[üu]gbar|wurde gel[öo]scht|nicht mehr aktiv|Seite nicht gefunden)/i.test(roh)) status = 'offline';
  const beschr = d.querySelector('#viewad-description-text');
  if(beschr) beschr.querySelectorAll('br').forEach(x => x.replaceWith('\n'));
  const beschreibung = beschr ? String(beschr.innerText || beschr.textContent || '').replace(/[ \t]+/g, ' ').replace(/\n{3,}/g, '\n\n').trim() : meta('og:description');
  const preisText = ak54Text(d.querySelector('#viewad-price'));
  const ort = ak54Text(d.querySelector('#viewad-locality'));
  const datum = ak54Text(d.querySelector('#viewad-extra-info span, #viewad-extra-info'));
  const kontakt = ak54Text(d.querySelector('#viewad-contact, .userprofile-vip-details, #viewad-profile-box'));
  const name = ak54Text(d.querySelector('.userprofile-vip a, .userprofile-vip, #viewad-contact .text-body-regular-strong'));
  let bild = meta('og:image'); if(!/^https:\/\/([a-z0-9-]+\.)*kleinanzeigen\.de\//i.test(bild)) bild = '';
  const gewerblich = /gewerblich/i.test(kontakt) ? true : /privat/i.test(kontakt) ? false : null;
  const keinMakler = typeof AK47_KEIN_MAKLER !== 'undefined' && AK47_KEIN_MAKLER.test([titel, beschreibung].join(' ')) && !(typeof AK47_MAKLER_OK !== 'undefined' && AK47_MAKLER_OK.test(beschreibung));
  const preis = typeof akqPreis === 'function' ? akqPreis(preisText) : 0;
  return { ok: !!titel || status === 'offline', titel, status, beschreibung: beschreibung.slice(0, 2500), preisText, preis, ort, datum: datum.slice(0, 40), name: name.slice(0, 60), bild, gewerblich, keinMakler, am: Date.now() };
}
async function ak54Pruefen(o, still){
  if(!ak54Pruefbar(o)) return null;
  const r = await ak54Holen(o.link);
  if(!r || !r.ok){
    if(r && (r.status === 403 || r.status === 429)) AK54.gebremst = Date.now();
    if(r && (r.status === 404 || r.status === 410)){ const x = { ok: true, status: 'offline', titel: '', am: Date.now() }; ak54Anwenden(o, x, still); return x; }
    return { ok: false, fehler: (r && (r.fehler || ('Status ' + r.status))) || 'keine Antwort' };
  }
  const x = ak54Parse(r.text, r.url);
  if(x.ok) ak54Anwenden(o, x, still);
  AK54.cache[o.id] = x;
  return x;
}
function ak54Anwenden(o, x, still){
  const alt = String(o.akqTitel || '').trim();
  o.inseratCheck = { am: x.am || Date.now(), status: x.status, titel: x.titel || '', preisText: x.preisText || '', ort: x.ort || '', datum: x.datum || '', bild: x.bild || '', gewerblich: x.gewerblich, keinMakler: !!x.keinMakler, beschreibung: x.beschreibung || '', name: x.name || '' };
  if(x.titel && akqNorm(x.titel) !== akqNorm(alt)){
    if(!o.akqTitelKI && alt) o.akqTitelKI = alt;
    o.akqTitel = x.titel;
    aqLog(o, 'info', `✏️ Titel aus dem Inserat übernommen: „${x.titel}“${alt ? ` (die KI hatte „${alt}“)` : ''}`);
  }
  if(x.preis && Number(o.kaufpreis) !== x.preis && x.preis >= 1000){
    aqLog(o, 'info', `💶 Preis aus dem Inserat: ${x.preisText}${o.kaufpreis ? ` (die KI hatte ${Number(o.kaufpreis).toLocaleString('de-DE')} €)` : ''}`);
    o.kaufpreis = x.preis;
  }
  if(x.status === 'offline' && !o.inseratOffline){ o.inseratOffline = Date.now(); aqLog(o, 'info', '❌ Inserat ist nicht mehr online'); }
  if(x.status !== 'offline' && o.inseratOffline) delete o.inseratOffline;
  if(x.keinMakler && !o.keinMakler){ o.keinMakler = true; aqLog(o, 'info', '🚫 Im Inserat steht „keine Makler“'); }
  if(x.gewerblich === true && o.privat !== 'nein'){ o.privat = 'nein'; aqLog(o, 'info', '🏢 Anbieter ist laut Inserat gewerblich'); }
  if(!aqName(o) && x.name && !/^(privat|gewerblich)/i.test(x.name)) o.verkaeuferName = x.name;
  if(!still){ try{ save(); }catch(e){} }
}
// Warteschlange: eins nach dem anderen, mit Pause – Kleinanzeigen soll nicht bremsen
function ak54Einreihen(ids){
  ids.forEach(id => { if(!AK54.warte.includes(id)) AK54.warte.push(id); });
  if(!AK54.laeuft) ak54Abarbeiten();
}
async function ak54Abarbeiten(){
  AK54.laeuft = true;
  let n = 0;
  while(AK54.warte.length){
    if(AK54.gebremst && Date.now() - AK54.gebremst < 15 * 60e3) break;     // nach „zu viele Anfragen“ 15 Min. Pause
    const o = findObjekt(AK54.warte.shift());
    if(!o || !ak54Pruefbar(o)) continue;
    try{ await ak54Pruefen(o, true); n++; }catch(e){ console.error('ak54', e); }
    if(n % 5 === 0) { try{ save(); }catch(e){} }
    await new Promise(r => setTimeout(r, 2500));
  }
  AK54.laeuft = false;
  if(n){ try{ save(); if(aktuelleAnsicht === 'akquise' || aktuelleAnsicht === 'objekte') renderMain(); }catch(e){} }
}
function ak54Offen(){ return (db.objekte || []).filter(o => ak54Pruefbar(o) && !(o.inseratCheck && o.inseratCheck.am) && ['neu', 'kleinanzeigen_geschrieben', 'email_geschrieben', ''].includes(o.status || '')); }

// Nach jedem Import: neue Kleinanzeigen-Leads prüfen
(function(){
  if(typeof akqUebernehmen !== 'function') return;
  const _u = akqUebernehmen;
  akqUebernehmen = function(){
    const vorher = new Set((db.objekte || []).map(o => o.id));
    const r = _u.apply(this, arguments);
    try{ const neu = (db.objekte || []).filter(o => !vorher.has(o.id) && ak54Pruefbar(o)).map(o => o.id); if(neu.length) setTimeout(() => ak54Einreihen(neu), 1500); }catch(e){}
    return r;
  };
})();
// Beim Start: bis zu 40 noch ungeprüfte neue Leads nachholen
window.addEventListener('load', () => setTimeout(() => { try{ const l = ak54Offen().slice(0, 40).map(o => o.id); if(l.length) ak54Einreihen(l); }catch(e){} }, 20000));

// ── Schnell durchsehen ──
function ak54Starten(ab){
  AK54.ids = ex29Liste().map(o => o.id);
  if(!AK54.ids.length){ akqToast('Keine neuen Leads mit Link'); return; }
  AK54.pos = Math.max(0, Math.min(ab || 0, AK54.ids.length - 1));
  ak54Karte();
}
function ak54E(s){ return akqEsc(s); }
async function ak54Karte(){
  const id = AK54.ids[AK54.pos], o = findObjekt(id);
  if(!o){ AK54.ids.splice(AK54.pos, 1); if(!AK54.ids.length) return schliesseModal(); AK54.pos = Math.min(AK54.pos, AK54.ids.length - 1); return ak54Karte(); }
  const c = o.inseratCheck;
  const kopf = `<div class="ak54-kopf"><b>Neue Leads durchsehen</b><span>${AK54.pos + 1} / ${AK54.ids.length}</span></div>`;
  const warn = [];
  if(c && c.status === 'offline') warn.push('<span class="ak54-w rot">❌ Inserat nicht mehr online</span>');
  if(c && c.status === 'reserviert') warn.push('<span class="ak54-w gelb">⏸ Reserviert</span>');
  if(o.keinMakler || (c && c.keinMakler)) warn.push('<span class="ak54-w rot">🚫 keine Makler</span>');
  if(c && c.gewerblich === true) warn.push('<span class="ak54-w gelb">🏢 gewerblich</span>');
  if(o.akqTitelKI) warn.push(`<span class="ak54-w blau" title="KI-Titel: ${ak54E(o.akqTitelKI)}">✏️ Titel korrigiert</span>`);
  const preis = o.kaufpreis ? Number(o.kaufpreis).toLocaleString('de-DE') + ' €' : (c && c.preisText) || '';
  const infos = [preis, (c && c.ort) || o.ort, c && c.datum, c && c.gewerblich === false ? 'privat' : ''].filter(Boolean).map(ak54E).join(' · ');
  const text = c && c.beschreibung ? c.beschreibung : (o.details || '');
  const bild = c && c.bild ? `<img class="ak54-bild" src="${ak54E(c.bild)}" alt="" onerror="this.remove()">` : '';
  const laden = ak54Pruefbar(o) && !c ? '<div class="ak54-lade">⏳ Inserat wird gelesen …</div>' : '';
  mc24Modal(`${kopf}
    <div class="ak54-karte">${bild}
      <div class="ak54-titel">${ak54E(aqTitel(o))}</div>
      ${o.akqTitelKI ? `<div class="ak54-alt">KI hatte: ${ak54E(o.akqTitelKI)}</div>` : ''}
      <div class="ak54-info">${infos}</div>${warn.length ? `<div class="ak54-warn">${warn.join(' ')}</div>` : ''}${laden}
      ${text ? `<div class="ak54-text">${ak54E(text.slice(0, 700))}${text.length > 700 ? ' …' : ''}</div>` : ''}
    </div>
    <div class="ak54-knoepfe">
      <button class="secondary" ${AK54.pos ? '' : 'disabled'} onclick="ak54Schritt(-1)">◀</button>
      <button class="secondary" onclick="ak54Verwerfen()" title="Taste Entf">🗑 Verwerfen</button>
      <button class="secondary" onclick="ak54Inserat()">🔗 Inserat ansehen</button>
      <button onclick="ak54Anschreiben()">✉️ Anschreiben</button>
      <button class="secondary" onclick="ak54Schritt(1)" title="Pfeil rechts">Weiter ▶</button>
    </div>
    <div class="ak54-fuss mc24-muted">${ex29Handy() ? 'Das Inserat wird nur gelesen – ohne Browser.' : 'Pfeiltasten ◀ ▶ blättern · Entf = verwerfen · Das Inserat wird nur gelesen, kein Browser-Tab.'}</div>`, 620);
  if(ak54Pruefbar(o) && !c){
    const x = await ak54Pruefen(o, false);
    if(AK54.ids[AK54.pos] === id && document.querySelector('.ak54-karte')){
      if(x && x.ok) ak54Karte();
      else { const l = document.querySelector('.ak54-lade'); if(l) l.textContent = '⚠️ Inserat konnte nicht gelesen werden' + (x && x.fehler ? ' (' + x.fehler + ')' : '') + ' – über „Inserat ansehen“ öffnen.'; }
    }
  }
  // nächstes schon vorladen
  const n = findObjekt(AK54.ids[AK54.pos + 1]);
  if(n && ak54Pruefbar(n) && !n.inseratCheck) setTimeout(() => ak54Pruefen(n, false).catch(() => {}), 800);
}
function ak54Schritt(d){
  const neu = AK54.pos + d;
  if(neu < 0) return;
  if(neu >= AK54.ids.length){ schliesseModal(); akqToast('✅ Alle neuen Leads durchgesehen'); try{ aq2Neu(); }catch(e){} return; }
  AK54.pos = neu; ak54Karte();
}
function ak54Verwerfen(){
  const id = AK54.ids[AK54.pos], o = findObjekt(id); if(!o) return;
  try{ akqVerworfenMerken(o); }catch(e){}
  try{ objektVerknuepfungenAufraeumen(id); }catch(e){}
  const eig = o.eigentuemerId;
  db.objekte = db.objekte.filter(x => x.id !== id);
  try{ eigentuemerMitloeschenFallsVerwaist(eig); }catch(e){}
  save(); akqToast('🗑 Verworfen: ' + (aqTitel(o) || 'Lead'), 2500);
  AK54.ids.splice(AK54.pos, 1);
  if(!AK54.ids.length){ schliesseModal(); try{ aq2Neu(); }catch(e){} return; }
  AK54.pos = Math.min(AK54.pos, AK54.ids.length - 1); ak54Karte();
}
function ak54Inserat(){
  const o = findObjekt(AK54.ids[AK54.pos]); if(!o || !o.link) return;
  if(ak54IstKa(o.link) && window.pc && window.pc.geraet === 'pc' && typeof window.pc.webfenster === 'function') window.pc.webfenster('oeffnen', { url: o.link });
  else window.open(mc24SicherLink(o.link), '_blank');
}
function ak54Anschreiben(){
  const id = AK54.ids[AK54.pos]; if(!findObjekt(id)) return;
  AK54.weiterAb = AK54.pos + 1;
  schliesseModal();
  if(aktuelleAnsicht !== 'akquise') wechsleAnsicht('akquise');
  AQ2.status = AQ2.status || 'offen'; AQ2.sel = id; renderMain();
  try{ aq2Senden(); }catch(e){ console.error('ak54 senden', e); }
}
document.addEventListener('keydown', e => {
  if(!document.querySelector('.ak54-karte')) return;
  if(/^(INPUT|TEXTAREA|SELECT)$/.test((e.target && e.target.tagName) || '')) return;
  if(e.key === 'ArrowRight'){ e.preventDefault(); ak54Schritt(1); }
  else if(e.key === 'ArrowLeft'){ e.preventDefault(); ak54Schritt(-1); }
  else if(e.key === 'Delete'){ e.preventDefault(); ak54Verwerfen(); }
});
// Knopf im Akquise-Balken: „Schnell durchsehen“ zuerst, Browser-Tabs nur noch als Zusatz
(function(){
  if(typeof ex29BalkenHtml !== 'function') return;
  ex29BalkenHtml = function(){
    const n = ex29Liste().length; if(!n) return '';
    const filter = AQ2.ort || AQ2.art || AQ2.q;
    const weiter = AK54.weiterAb && AK54.weiterAb < n ? `<button class="secondary" onclick="ak54Starten(${AK54.weiterAb})">▶ Weiter durchsehen</button>` : '';
    return `<div class="ex29-balken"><span>🔗 <b>${n}</b> neue${n === 1 ? 'r' : ''} Lead${n === 1 ? '' : 's'} mit Exposé-Link${filter ? ' <span class="ex29-filter">(gefiltert)</span>' : ''}</span>
      <span class="ak54-bk">${weiter}<button onclick="ak54Starten(0)">⚡ Schnell durchsehen</button><button class="secondary" title="Öffnet jedes Inserat als eigenen Browser-Tab (braucht viel Leistung)" onclick="ex29Oeffnen()">${ex29Handy() ? 'Nacheinander öffnen' : 'Im Browser öffnen'}</button></span></div>`;
  };
  if(typeof ex29Oeffnen === 'function'){
    const _o = ex29Oeffnen;
    ex29Oeffnen = function(){
      if(ex29Handy()) return _o.apply(this, arguments);
      const l = ex29Liste(); if(l.length <= 5) return _o.apply(this, arguments);
      mc24Modal(`<h3>🔗 ${l.length} Exposés öffnen</h3>
        <p>Viele Browser-Tabs mit Kleinanzeigen auf einmal brauchen sehr viel Leistung (Werbung, Videos, Bilder).</p>
        <p><b>⚡ Schnell durchsehen</b> zeigt die Inserate nacheinander direkt im Cockpit – nur Text und ein Bild, ohne Browser.</p>
        <div class="modal-actions"><button class="secondary" onclick="schliesseModal()">Abbrechen</button><div class="right">
          <button class="secondary" onclick="schliesseModal();EX29.rest=ex29Liste().map(o=>o.id);EX29.gesamt=EX29.rest.length;EX29.offen=0;EX29.portion=3;ex29Weiter()">Im Browser, je 3</button>
          <button onclick="schliesseModal();ak54Starten(0)">⚡ Schnell durchsehen</button></div></div>`, 500);
    };
  }
})();
// Vor dem Anschreiben: ungeprüftes Inserat erst lesen, damit der richtige Titel in der Nachricht steht
(function(){
  if(typeof aq2Senden !== 'function') return;
  const _s = aq2Senden;
  aq2Senden = function(){
    const o = findObjekt(AQ2.sel), args = arguments, self = this;
    if(o && ak54Pruefbar(o) && !o.inseratCheck && !(AK54.gebremst && Date.now() - AK54.gebremst < 15 * 60e3)){
      akqToast('⏳ Titel wird mit dem Inserat abgeglichen …', 2500);
      const weiter = () => { try{ AQ2.sel = o.id; _s.apply(self, args); }catch(e){ console.error(e); } };
      Promise.race([ak54Pruefen(o, false), new Promise(r => setTimeout(r, 4000))]).then(weiter, weiter);
      return;
    }
    return _s.apply(this, arguments);
  };
})();
// Liste: kleine Hinweise am Lead
(function(){
  if(typeof aq2Liste !== 'function') return;
  const _l = aq2Liste;
  aq2Liste = function(){
    const r = _l.apply(this, arguments);
    try{
      document.querySelectorAll('#aqListe .lc').forEach(el => {
        const o = findObjekt(el.id.replace(/^lc-/, '')); if(!o || el.querySelector('.ak54-chip')) return;
        const t = o.inseratOffline ? '<span class="ak54-chip rot" title="Inserat nicht mehr online">❌ offline</span>' : o.akqTitelKI ? `<span class="ak54-chip blau" title="KI-Titel war: ${ak54E(o.akqTitelKI)}">✏️ Titel geprüft</span>` : o.inseratCheck ? '<span class="ak54-chip gruen" title="Mit dem Inserat abgeglichen">✓ geprüft</span>' : '';
        if(!t) return;
        const ziel = el.querySelector('.lc-titel, .t, b') || el.firstElementChild; if(ziel) ziel.insertAdjacentHTML('beforeend', ' ' + t);
      });
    }catch(e){}
    return r;
  };
})();
(function(){
  const st = document.createElement('style');
  st.textContent = `.ak54-bk{display:flex;gap:6px;flex-wrap:wrap}
.ak54-kopf{display:flex;justify-content:space-between;align-items:center;margin-bottom:10px}.ak54-kopf span{color:var(--muted);font-size:13px}
.ak54-karte{border:1px solid var(--border);border-radius:12px;padding:12px;max-height:62vh;overflow:auto}
.ak54-bild{width:100%;max-height:260px;object-fit:cover;border-radius:8px;margin-bottom:8px;display:block}
.ak54-titel{font-size:17px;font-weight:700;line-height:1.3}.ak54-alt{font-size:12px;color:var(--muted);text-decoration:line-through;margin-top:2px}
.ak54-info{font-size:13px;color:var(--muted);margin:6px 0}.ak54-warn{display:flex;gap:6px;flex-wrap:wrap;margin:6px 0}
.ak54-w,.ak54-chip{font-size:11px;padding:2px 8px;border-radius:999px;border:1px solid var(--border);white-space:nowrap}
.ak54-w.rot,.ak54-chip.rot{color:#f87171;border-color:#7f1d1d}.ak54-w.gelb{color:#fbbf24;border-color:#78350f}.ak54-w.blau,.ak54-chip.blau{color:#93c5fd;border-color:#1e3a8a}.ak54-chip.gruen{color:#4ade80;border-color:#14532d}
.ak54-text{white-space:pre-wrap;font-size:13px;line-height:1.45;margin-top:8px}.ak54-lade{font-size:12px;color:#fbbf24;margin:6px 0}
.ak54-knoepfe{display:flex;gap:6px;flex-wrap:wrap;justify-content:space-between;margin-top:10px}.ak54-fuss{font-size:11px;margin-top:6px}
@media (max-width:700px){.ak54-knoepfe button{flex:1 1 auto}}`;
  document.head.appendChild(st);
})();
