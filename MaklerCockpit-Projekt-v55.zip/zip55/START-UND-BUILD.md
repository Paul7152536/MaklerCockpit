# MaklerCockpit v55 – Start & Build

## Starten (normal)
1. `MaklerCockpit-PC-v55.exe` auf den PC kopieren und doppelklicken (portable, keine Installation).
2. Deine Daten liegen weiter in `Dokumente\MaklerCockpit\daten.json` und werden beim ersten Start automatisch übernommen.
3. Vorher empfohlen: in v32 einmal „Sicherung jetzt“ ausführen.

## Akquise-Erweiterung ein-/ausschalten
Zahnrad unten links neben deinem Namen (oder PG-Kreis oben rechts) → „Module & Akquise-Erweiterung“ → Haken setzen/entfernen → Speichern. Das Cockpit lädt neu. Daten bleiben erhalten.

## Selbst bauen (Windows-exe)
Voraussetzung: Node.js 18+.

```
npm install
npx electron-builder --win portable
```
Ergebnis: `dist/MaklerCockpit-PC-v55.exe`. Die fertige Oberfläche liegt bereits gebaut in `app/index.html`; `quellen/` enthält die Einzelmodule zum Nachlesen und Weiterentwickeln (v24: `akte24.js`, `markt24_kern.js`, `markt24.js`, `invest24_kern.js`, `invest24.js`, `akquise24.js`).

## Tests
- Rechenkerne (nur Node): `node tests/v24/kern_markt.test.js` und `node tests/v24/kern_invest.test.js`
- Browser-Abnahme (Playwright): `tests/v24/test24.js`, `tests/v24/miete_check.js` – erwarten die gebaute Oberfläche unter `/tmp/pc/app/index.html`, Pfad bei Bedarf anpassen.
- Electron-Smoke (echter Hauptprozess, PDF, Sicherung, Wiederherstellung): `tests/v24/smoke24_electron.js`, Start mit `electron --no-sandbox tests/v24/smoke24_electron.js` (Pfade oben in der Datei anpassen).

## Sicherheit
- Google-Zugangsdaten bleiben lokal verschlüsselt (`google-konto.json`), nie in `daten.json` und nie in der Cloud-Sicherung.
- Keine API-Schlüssel im Projekt; die KI wird per Kopieren/Einfügen genutzt (kostenlos).
- Eigentümer-Kontaktdaten gehen nicht automatisch in KI-Prompts; Eigentümerbericht ohne genaue Adresse.

## v25: Handy & Abgleich
- Einrichtung am PC: Zahnrad → **Handy & Abgleich** (Skript auf Version 2 bringen, Abgleich einschalten, Kopplungscode anzeigen).
- Die Android-App liegt als eigenes Projekt-ZIP bei (`MaklerCockpit-Handy-v2-Projekt.zip`, Anleitung darin: `ANLEITUNG-HANDY.md`).
- Tests v25: `node tests/v25/abgleich.test.js` (Brücke + Abgleich, nur Node), `tests/v25/test25.js` und `tests/v25/android_shim.test.js` (Playwright), `tests/v25/smoke25_electron.js` (Electron).

## v27: Exposé nach Aufbau einlesen
- Modul `quellen/expose27.js` (ersetzt den Exposé-Import): liest den BETTERHOMES-Aufbau mit Positionen aus der PDF – Titel (größte Schrift oben, Seite 1), Beschreibung (linke Spalte), Vorteile („- …“, rechte Spalte, mit umbrochenen Zeilen), „Objektinformationen“ (alle Zeilen und „Feld:“-Abschnitte, Provision), erstes Foto als Titelbild (Logos werden übersprungen). Unbekannter Aufbau/Scan → bisheriges Verfahren (Text/Texterkennung).
- Tests: `tests/v27/test27.js` (Playwright, erwartet die Beispiel-PDF unter `/tmp/v27test/ex/beispiel.pdf` – Pfad anpassen; `tests/v27/variante-haus.pdf` liegt bei), `tests/v27/lesen.js <pdf>` zeigt die erkannten Rohdaten, `tests/v27/smoke27_electron.js` (Electron).

## v28: Durchsicht
- Modul `quellen/pruefung28.js` + Ersetzungen am Ende von `akq_patch.py` (Abschnitt „v28“): Notizen-HTML wird vor dem Anzeigen gesäubert, Telefon/E-Mail sicher in Links, Titel im Tagescheck als Text, deutsche Datumsangaben, Gesprächsleitfaden je Herkunft, Marketing-Bereich an der Seitenleiste, Sortierhilfe lokal (`app/vendor/Sortable.min.js`, MIT).
- Tests: `tests/v28/test28.js` (Playwright), `tests/v28/xss2.js` und `tests/v28/gross.js xss` (eingeschleuste Inhalte), `tests/v28/gross.js gross` (400 Objekte, 800 Kontakte, 1500 Termine), `tests/v28/rundgang.js 1440|390` (Bildschirmfotos aller Seiten), `tests/v28/smoke28_electron.js`.

## v29: Neue Exposés auf Knopfdruck öffnen
- Modul `quellen/exposes29.js`: Balken über der Akquise-Liste („n neue Leads mit Exposé-Link“), Liste = `aqGefiltert()` mit Status „neu“ (Ort/Objektart/Suche gelten), nur sichere http(s)-Links, gleiche Links nur einmal. PC: bis 15 sofort, sonst Auswahl „Alle“ / „10er-Portionen“ (je 350 ms versetzt). Handy: nacheinander über eine Leiste („Nächstes“, „Lead“).
- Test: `tests/v29/test29.js`, `tests/v29/smoke29_electron.js`.

## v30: Detailfeld wandert mit, Uhrzeit per Zifferblatt
- `design.css` (Abschnitt „v30“): rechte Spalte von `.aq-layout` (Akquise, Käufer & Markt, Kooperationen) ist ab 761 px Breite `position:sticky` im Scrollbereich `#main`.
- Modul `quellen/uhr30.js`: eigenes Zifferblatt für alle `input[type=time]` im Hauptfenster (PC), native Auswahlliste per CSS ausgeblendet; am Handy bleibt die Android-Uhr.
- Tests: `tests/v30/test30.js`, `tests/v30/sticky2.js`.

## v31: Anschreib-Tage, Aufräumen nach 4 Wochen, „Nachricht“ ohne zweiten Tab
- Modul `quellen/angeschrieben31.js`: `o.angeschrieben = [{am, art}]` (aus Verlauf „email“, emailAm, kleinanzeigenAm, nachgefasstAm, statusAm; läuft in `_schreibe` mit). Fällig: Status E-Mail/Kleinanzeigen geschrieben, kein Favorit, letzte Nachricht ≥ 28 Tage, nicht zurückgestellt (`o.an31Spaeter`). Hinweis in Glocke, Akquise-Balken, Karte beim Start (1× täglich, `akquise.an31GezeigtAm`), Auswahl-Dialog. Gelöschte → `akquise.ausgeschlossen` (Link/Telefon/E-Mail), `akqUebernehmen` überspringt sie.
- Modul `quellen/nachricht31.js` + Ersetzungen „v31“ in `akq_patch.py`: `window.open` merkt sich geöffnete Anzeigen 12 h; `aq2Senden` öffnet die Anzeige nur, wenn sie noch nicht offen ist.
- Test: `tests/v31/test31.js`.

## v32: Mit Windows starten
- `app/main.js`: Wahl in `Dokumente\MaklerCockpit\pc-einstellungen.json` (`autostart`, `autostartMinimiert`; nur dieser PC, nicht in daten.json). Beim Start wird der Windows-Autostart (`app.setLoginItemSettings`, Pfad = `PORTABLE_EXECUTABLE_FILE`) auf die gerade gestartete exe umgestellt. Erster Start ohne Einstellung: an, minimiert (`--minimiert`). IPC `autostart2` (lesen/setzen/Hinweis gesehen), `autostart` (alt, für Jarvis) bleibt.
- Modul `quellen/autostart32.js`: Zahnrad-Menü „Mit Windows starten“ mit Auswahl minimiert / Fenster öffnen / aus.
- Test: `tests/v32/autostart32_electron.js` (LAUF=A|B|C, Windows-Autostart nachgebildet).

## v33: PDF-Werkzeuge, Leiste springt nicht mehr
- `quellen/pdfwerkzeuge33.html` = Pauls „Alles-in-einem-PC-v9“ angepasst: Bausteine lokal (`app/vendor/`: jspdf, tess, pdf.js, **pdf-lib 1.17.1**, **peerjs 1.5.4**, Sortable), dunkles Design, Dateinamen escaped, Speichern über `mcPdfSpeichern` des Cockpits, Texterkennung mit lokalem Deutsch-Paket, pdf.js ohne eval. `akq_patch.py` bettet die Datei als `window.PDF33_HTML` ein (`</` maskiert).
- `quellen/pdf33.js`: Seite `pdfs` → fester Rahmen (srcdoc) über `#main`, bleibt beim Seitenwechsel geladen; pdf.js im Cockpit mit `isEvalSupported:false` (CVE-2024-4367).
- `quellen/nav33.js`: Scroll-Position der Leiste bleibt bei `renderNav`, jede Seite merkt sich ihre Position (Rückkehr über Leiste/Tabs).
- Tests: `tests/v33/test33.js` (Playwright; Texterkennung dort wegen file:// gesperrt), `tests/v33/pdf33_electron.js` (echtes Programm, inkl. Texterkennung).

## v34: Durchsicht – doppelte Kennungen, Abgleich-Schutz, Sicherungen
- `uid()` (Cockpit und Hausverwaltungen) = Zeit + 2-stelliger Zähler (Basis 36) + 4 Zufallszeichen, feste Länge → keine Doppel mehr bei Importen in derselben Millisekunde.
- `quellen/abgleich25_kern.js`: `idsReparieren(db)` (deterministisch: echtes Doppel weg, sonst `<id>_2`, `_3` …), läuft vor jedem Abgleich; Listen mit doppelter id bleiben Sammlungen (`idSammlung`) statt Einzelwert; alter Einzelwert einer Liste wird still abgehakt; ein von einem alten Gerät geschickter Listen-Einzelwert wird eintragsweise zusammengeführt (nie ganz gelöscht/ersetzt); zugehörige Schein-Löschungen werden übergangen; Löschschutz auch, wenn eine ganze Liste (≥ 5) leer wäre.
- `quellen/fehler34.js`: Reparatur beim Start (+ Hinweis), Hinweis bei beschädigter daten.json (`pc.ladeHinweis`), danach Abgleich-Basis zurückgesetzt. `_schreibe` repariert vor dem Speichern (akq_patch).
- `app/main.js`: Tagessicherung stündlich geprüft, Datum nach Ortszeit, nur gültiges JSON; beschädigte daten.json → `backups/beschaedigt-….json`; Import atomar (tmp + rename); `render-process-gone` → Neuladen.
- `quellen/abgleich25.js`: Änderungen während eines laufenden Abgleichs → direkt danach nachsenden; offline nicht als Fehler in der Glocke.
- „heute“ nach Ortszeit statt UTC (akq_patch ersetzt `toISOString().slice(0,10)`-Muster); Exposé-Titelbild max. 1280 px, JPEG 0,84.
- Tests: `tests/v34/` – `dup_alt.js` (zeigt den alten Fehler: Leads gehen beim Abgleich verloren), `dup_neu.js` (neue/alte Geräte gemischt), `test34.js`, `test34_abgleich.js`, `smoke34.js` (echtes Electron: beschädigte Datei, Absturz, Import), `roboter.js` (klickt jede Seite durch), `regression.sh`.

## v35: Große Analyse
- `quellen/grossanalyse35.js` (Menüpunkt unter Shooting-Analyse, Erfassung mit Herkunft, Analysepaket nach 04_Eingabevorlage, Prompt = Master-Prompt + Chat-Ergänzung + Auftrag + JSON, report.json zurück).
- `quellen/ga35_masterprompt.md` wird von akq_patch.py als `window.GA35_MASTER_STD` eingebettet; `quellen/Marktanalyse_System/` = Pauls Paket (Systemhandbuch, Datenmatrix, Referenzdaten).
- Test: `tests/v35/test35.js`.

## Mac-Version (seit v42, 16.11.2026)
- Bauen (geht auch unter Linux): `electron-builder --mac zip --arm64 --x64 --projectDir . -c.directories.output=dist-mac`
- Danach einfach signieren (ohne Apple-Konto, „ad hoc“): `rcodesign sign dist-mac/mac-arm64/MaklerCockpit.app` bzw. `dist-mac/mac/MaklerCockpit.app`, dann mit `zip -qry` (Symlinks erhalten!) neu packen.
- Starten auf dem Mac: ZIP entpacken, `MaklerCockpit.app` in „Programme“ ziehen, beim ersten Mal Rechtsklick → Öffnen (oder Terminal: `xattr -cr /Applications/MaklerCockpit.app`).
- Daten auf dem Mac: `~/Dokumente/MaklerCockpit/daten.json` (eigene Datei; Abgleich mit PC/Handy über die Kopplung wie beim Handy).
- main.js: Mac bekommt App- und Bearbeiten-Menü (⌘C/⌘V/⌘A/⌘Z), „Beim Anmelden starten“, Fenster kommt beim Klick aufs Dock-Symbol zurück. Windows unverändert.
