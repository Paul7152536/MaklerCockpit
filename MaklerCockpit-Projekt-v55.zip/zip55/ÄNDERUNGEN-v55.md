# MaklerCockpit v55 (PC/Mac) – Handy bleibt v29

## Inserate öffnen schneller
- Kleinanzeigen-Inserate („Exposé öffnen ↗“, „🔗 Inserat öffnen“ in der Objektakte, „Inserat ansehen“) gehen am PC jetzt im **eigenen Kleinanzeigen-Fenster** auf statt im Browser.
- Das Fenster ist **sofort sichtbar** (vorher erst, wenn die Seite fertig geladen war).
- **Werbung und Tracker werden blockiert** (Google-Werbung, Tag Manager, Criteo, Amazon-Ads usw.) – die Seite lädt deutlich weniger.
- **Fenster bleibt bereit**: Schließen blendet es nur aus, das nächste Inserat öffnet sofort. Beim ersten Öffnen der Akquise wird es unsichtbar vorbereitet. Beim Beenden des Programms wird es mit geschlossen.
- Du bist dort bei Kleinanzeigen angemeldet (gleiche Anmeldung wie beim „Nachricht“-Knopf).
- ImmoScout & andere Portale öffnen weiter im Browser. Handy unverändert.

## Tests
- tests/v55: test55.js (Browser), smoke55.js, smoke55ka.js (Electron: sofort sichtbar, Werbung blockiert, Fenster bleibt bereit, Programm beendet sauber). Alle Tests grün bis auf bekannte Altfehler.
