// MaklerCockpit v15/v25 – Google-Kalender-Anbindung und Abgleich mit dem Handy (Hauptprozess)
// Weg 1 (v15, empfohlen): eigenes Google-Apps-Skript im Kalender-Konto als Brücke – dauerhaft verbunden, keine Cloud-App nötig.
// Weg 2 (v14): Anmeldung über den Browser (OAuth 2.0 für Desktop-Apps, Loopback + PKCE) mit eigener Google-Cloud-App.
// Zugangsdaten liegen verschlüsselt (Windows-Benutzerkonto) in Dokumente\MaklerCockpit\google-konto.json –
// nie in daten.json. Die Oberfläche bekommt nie Token zu sehen, nur Ergebnisse der Kalender-Abrufe.
const { shell, safeStorage } = require('electron');
const http = require('http');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const SCOPE = 'openid email https://www.googleapis.com/auth/calendar';
const SKRIPT_URL = /^https:\/\/script\.google\.com\/(?:a\/macros\/[\w.-]+\/|macros\/)s\/[\w-]{20,}\/exec$/;
const API = 'https://www.googleapis.com/calendar/v3';
const warte = ms => new Promise(r => setTimeout(r, ms));
const b64url = buf => buf.toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
function fehlerMit(code, text){ const e = new Error(text); e.code = code; return e; }

module.exports = function googleEinrichten(ipcMain, ORDNER, fokus){
  const DATEI = path.join(ORDNER, 'google-konto.json');
  let konto = null;      // { modus, clientId, secret, refresh, skriptUrl, skriptKey, skriptKeyNeu, email, projekt, verbundenAm }
  let zugang = null;     // { token, bis }
  let anmeldung = null;  // laufende Browser-Anmeldung

  const verschluesselbar = () => { try{ return safeStorage.isEncryptionAvailable(); }catch(e){ return false; } };
  function verschl(t){
    if(!t) return '';
    if(verschluesselbar()){ try{ return 'enc:' + safeStorage.encryptString(String(t)).toString('base64'); }catch(e){} }
    return 'b64:' + Buffer.from(String(t), 'utf8').toString('base64');
  }
  function entschl(t){
    try{
      if(!t) return '';
      if(t.startsWith('enc:')) return safeStorage.decryptString(Buffer.from(t.slice(4), 'base64'));
      if(t.startsWith('b64:')) return Buffer.from(t.slice(4), 'base64').toString('utf8');
    }catch(e){}
    return '';
  }
  function laden(){
    if(konto) return konto;
    konto = { modus:'', clientId:'', secret:'', refresh:'', skriptUrl:'', skriptKey:'', skriptKeyNeu:'', email:'', projekt:'', verbundenAm:0 };
    try{
      const d = JSON.parse(fs.readFileSync(DATEI, 'utf8'));
      Object.assign(konto, { modus: d.modus || (d.refresh ? 'oauth' : ''), clientId: d.clientId || '', secret: entschl(d.secret), refresh: entschl(d.refresh),
        skriptUrl: entschl(d.skriptUrl), skriptKey: entschl(d.skriptKey), skriptKeyNeu: entschl(d.skriptKeyNeu),
        email: d.email || '', projekt: d.projekt || '', verbundenAm: d.verbundenAm || 0 });
    }catch(e){}
    return konto;
  }
  function sichern(){
    fs.mkdirSync(ORDNER, { recursive: true });
    const k = laden();
    const tmp = DATEI + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify({
      hinweis: 'Zugang des MaklerCockpit zu deinem Google Kalender. Verschlüsselt – nur mit deinem Windows-Benutzerkonto lesbar. Nicht weitergeben.',
      modus: k.modus, clientId: k.clientId, projekt: k.projekt, email: k.email, verbundenAm: k.verbundenAm,
      secret: verschl(k.secret), refresh: verschl(k.refresh),
      skriptUrl: verschl(k.skriptUrl), skriptKey: verschl(k.skriptKey), skriptKeyNeu: verschl(k.skriptKeyNeu)
    }, null, 1), 'utf8');
    fs.renameSync(tmp, DATEI);
  }
  function status(){
    const k = laden();
    const skript = k.modus === 'skript';
    return { modus: skript ? 'skript' : 'oauth',
      eingerichtet: skript ? !!k.skriptUrl : !!(k.clientId && k.secret),
      verbunden: skript ? !!(k.skriptUrl && k.skriptKey) : !!(k.clientId && k.secret && k.refresh),
      email: k.email, projekt: k.projekt,
      verbundenAm: k.verbundenAm, anmeldungLaeuft: !!anmeldung, verschluesselt: verschluesselbar() };
  }

  // Zugangsdatei aus der Google Cloud (client_secret_….json) oder Client-ID + Schlüssel von Hand
  function zugangsdatenLesen(arg){
    let id = '', sec = '', projekt = '';
    const roh = String((arg && arg.json) || '').trim();
    if(roh){
      let d; try{ d = JSON.parse(roh); }catch(e){ throw fehlerMit('datei', 'Das ist keine gültige Zugangsdatei von Google (JSON erwartet).'); }
      if(d && d.web && !d.installed) throw fehlerMit('typ', 'Diese Zugangsdatei gehört zu einem Client vom Typ „Webanwendung“. Bitte in der Google Cloud einen neuen Client vom Typ „Desktop-App“ anlegen.');
      const c = (d && (d.installed || d)) || {};
      id = String(c.client_id || ''); sec = String(c.client_secret || ''); projekt = String(c.project_id || '');
    } else {
      id = String((arg && arg.clientId) || '').trim(); sec = String((arg && arg.secret) || '').trim();
    }
    if(!/^[\w.-]+\.apps\.googleusercontent\.com$/.test(id)) throw fehlerMit('id', 'Die Client-ID sieht nicht richtig aus – sie endet auf „.apps.googleusercontent.com“.');
    if(!sec || sec.length < 10) throw fehlerMit('secret', 'Der Clientschlüssel (Client-Secret) fehlt. Er steht in der heruntergeladenen JSON-Datei.');
    return { id, sec, projekt };
  }

  function tokenFehler(j){
    const e = (j && j.error) || '';
    if(e === 'invalid_client' || e === 'unauthorized_client') return 'Google kennt diese Zugangsdaten nicht (Client-ID oder Schlüssel falsch bzw. gelöscht). Bitte in der Google Cloud einen neuen Desktop-Client anlegen und die neue Datei auswählen.';
    if(e === 'invalid_grant') return 'Die Google-Verbindung ist abgelaufen oder wurde widerrufen – bitte neu verbinden. (Tipp: In der Google Cloud unter „Zielgruppe“ die App auf „In Produktion“ stellen, sonst läuft sie alle 7 Tage ab.)';
    if(e === 'redirect_uri_mismatch') return 'Falscher Client-Typ – bitte in der Google Cloud einen Client vom Typ „Desktop-App“ anlegen.';
    return 'Google meldet: ' + ((j && (j.error_description || j.error)) || 'unbekannter Fehler');
  }

  async function tokenAnfrage(params){
    let r;
    try{
      r = await fetch('https://oauth2.googleapis.com/token', { method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams(params).toString() });
    }catch(e){ throw fehlerMit('netz', 'Google ist gerade nicht erreichbar (keine Internetverbindung?).'); }
    let j = {}; try{ j = await r.json(); }catch(e){}
    return { r, j };
  }

  function erfolgsSeite(ok, text){
    const farbe = ok ? '#34d399' : '#f87171';
    return `<!doctype html><html lang="de"><head><meta charset="utf-8"><title>MaklerCockpit</title></head>
<body style="margin:0;background:#0a1120;color:#e8eef8;font-family:Segoe UI,system-ui,sans-serif;display:flex;align-items:center;justify-content:center;height:100vh;">
<div style="background:#111c30;border:1px solid #26375a;border-radius:16px;padding:34px 40px;max-width:460px;text-align:center;">
<div style="font-size:42px;color:${farbe};">${ok ? '✓' : '✕'}</div>
<h2 style="margin:8px 0 10px;">${ok ? 'Google Kalender ist verbunden' : 'Das hat nicht geklappt'}</h2>
<p style="color:#8a98b0;line-height:1.5;">${text}</p></div></body></html>`;
  }

  async function verbinden(arg){
    const k = laden();
    if(arg && (arg.json || arg.clientId)){ const z = zugangsdatenLesen(arg); k.clientId = z.id; k.secret = z.sec; k.projekt = z.projekt; sichern(); }
    if(!k.clientId || !k.secret) throw fehlerMit('fehlt', 'Zuerst die Zugangsdatei aus der Google Cloud auswählen.');
    if(anmeldung) anmeldung.abbrechen('Eine neue Anmeldung wurde gestartet.');
    const verifier = b64url(crypto.randomBytes(48));
    const challenge = b64url(crypto.createHash('sha256').update(verifier).digest());
    const state = b64url(crypto.randomBytes(18));
    let redirect = '';
    const code = await new Promise((resolve, reject) => {
      let erledigt = false;
      const server = http.createServer((req, res) => {
        let u; try{ u = new URL(req.url, 'http://127.0.0.1'); }catch(e){ res.writeHead(400); res.end(); return; }
        const fehler = u.searchParams.get('error'), c = u.searchParams.get('code');
        if(u.pathname !== '/' || (!fehler && !c)){ res.writeHead(404); res.end(); return; }
        if(u.searchParams.get('state') !== state){ res.writeHead(400, { 'content-type': 'text/html; charset=utf-8' }); res.end(erfolgsSeite(false, 'Ungültige Antwort. Bitte im MaklerCockpit noch einmal auf „Mit Google anmelden“ klicken.')); return; }
        const ok = !fehler && !!c;
        res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' });
        res.end(erfolgsSeite(ok, ok ? 'Du kannst dieses Browserfenster jetzt schließen und zum MaklerCockpit zurückkehren.' : (fehler === 'access_denied' ? 'Der Zugriff wurde nicht erlaubt. Du kannst es im MaklerCockpit jederzeit erneut versuchen.' : 'Google meldet: ' + fehler)));
        fertig(ok ? null : fehlerMit('abgelehnt', fehler === 'access_denied' ? 'Anmeldung abgebrochen – der Zugriff auf den Kalender wurde nicht erlaubt.' : 'Anmeldung fehlgeschlagen: ' + fehler), c);
      });
      const timer = setTimeout(() => fertig(fehlerMit('zeit', 'Zeit abgelaufen – die Anmeldung im Browser wurde nicht innerhalb von 10 Minuten abgeschlossen.')), 600000);
      function fertig(err, c){
        if(erledigt) return; erledigt = true;
        clearTimeout(timer); anmeldung = null;
        setTimeout(() => { try{ server.close(); }catch(e){} }, 1500);
        if(err) reject(err); else resolve(c);
      }
      anmeldung = { abbrechen: (grund) => fertig(fehlerMit('abgebrochen', grund || 'Anmeldung abgebrochen.')) };
      server.on('error', e => fertig(fehlerMit('netz', 'Anmeldung konnte nicht gestartet werden: ' + (e.message || e))));
      server.listen(0, '127.0.0.1', () => {
        redirect = 'http://127.0.0.1:' + server.address().port;
        const url = 'https://accounts.google.com/o/oauth2/v2/auth?' + new URLSearchParams({
          client_id: k.clientId, redirect_uri: redirect, response_type: 'code', scope: SCOPE,
          access_type: 'offline', prompt: 'consent', include_granted_scopes: 'true',
          code_challenge: challenge, code_challenge_method: 'S256', state
        }).toString();
        Promise.resolve(shell.openExternal(url)).catch(e => fertig(fehlerMit('browser', 'Der Browser konnte nicht geöffnet werden: ' + (e.message || e))));
      });
    });
    try{ if(fokus) fokus(); }catch(e){}
    const { r, j } = await tokenAnfrage({ client_id: k.clientId, client_secret: k.secret, code, code_verifier: verifier, grant_type: 'authorization_code', redirect_uri: redirect });
    if(!r.ok || !j.access_token) throw fehlerMit('token', tokenFehler(j));
    if(!/auth\/calendar(\s|$)/.test(String(j.scope || ''))) throw fehlerMit('scope', 'Der Zugriff auf den Kalender wurde nicht erlaubt. Bitte erneut verbinden und im Google-Fenster das Häkchen beim Kalender setzen.');
    if(!j.refresh_token) throw fehlerMit('refresh', 'Google hat keinen dauerhaften Zugang erteilt. Bitte unter myaccount.google.com → Sicherheit → Drittanbieter-Apps den Zugriff von „MaklerCockpit“ entfernen und neu verbinden.');
    let email = '';
    try{ email = JSON.parse(Buffer.from(String(j.id_token || '').split('.')[1] || '', 'base64url').toString('utf8')).email || ''; }catch(e){}
    k.modus = 'oauth'; k.refresh = j.refresh_token; k.email = email; k.verbundenAm = Date.now();
    zugang = { token: j.access_token, bis: Date.now() + (Number(j.expires_in) || 3600) * 1000 };
    sichern();
    return status();
  }

  async function token(neu){
    const k = laden();
    if(!k.refresh) throw fehlerMit('nicht_verbunden', 'Google Kalender ist nicht verbunden.');
    if(!neu && zugang && zugang.bis - 60000 > Date.now()) return zugang.token;
    const { r, j } = await tokenAnfrage({ client_id: k.clientId, client_secret: k.secret, refresh_token: k.refresh, grant_type: 'refresh_token' });
    if(!r.ok || !j.access_token){
      if(['invalid_grant', 'invalid_client', 'unauthorized_client'].includes(j.error)){ k.refresh = ''; zugang = null; sichern(); throw fehlerMit('abgelaufen', tokenFehler(j)); }
      throw fehlerMit('netz', 'Google antwortet gerade nicht (' + (j.error || ('HTTP ' + r.status)) + ').');
    }
    zugang = { token: j.access_token, bis: Date.now() + (Number(j.expires_in) || 3600) * 1000 };
    return zugang.token;
  }

  function apiFehler(st, data){
    const e = (data && data.error) || {};
    const grund = ((e.errors && e.errors[0] && e.errors[0].reason) || (e.details && e.details[0] && e.details[0].reason) || e.status || '') + '';
    if(st === 403 && /accessNotConfigured|SERVICE_DISABLED/i.test(grund + ' ' + (e.message || ''))) return { code: 'api_aus', text: laden().modus === 'skript'
      ? 'Im Google-Skript fehlt der Kalender-Dienst: links bei „Dienste“ auf ＋ → „Google Calendar API“ → „Hinzufügen“. Danach speichern und unter „Bereitstellen → Bereitstellungen verwalten“ eine neue Version bereitstellen.'
      : 'Die „Google Calendar API“ ist in deinem Google-Cloud-Projekt noch nicht aktiviert (Schritt 2 der Anleitung). Nach dem Aktivieren 1–2 Minuten warten.' };
    if(st === 403 && /forbiddenForNonOrganizer|requiredAccessLevel|forbidden/i.test(grund)) return { code: 'kein_recht', text: 'Diesen Termin darfst du in Google nicht ändern (er gehört jemand anderem oder der Kalender ist schreibgeschützt).' };
    if(st === 404) return { code: 'weg', text: 'Nicht gefunden.' };
    if(st === 410) return { code: 'weg', text: 'Gelöscht.' };
    return { code: 'api', text: 'Google meldet Fehler ' + st + (e.message ? ': ' + e.message : '') };
  }

  // ── Weg 1: Google-Apps-Skript als Brücke ──
  async function skriptAnfrage(url, key, nutzlast){
    const ctrl = new AbortController(); const timer = setTimeout(() => ctrl.abort(), 60000);
    let r, text = '';
    try{
      r = await fetch(url, { method: 'POST', redirect: 'follow', signal: ctrl.signal, headers: { 'content-type': 'text/plain;charset=utf-8' }, body: JSON.stringify(Object.assign({ key }, nutzlast)) });
      text = await r.text();
    }catch(e){ throw fehlerMit('netz', e.name === 'AbortError' ? 'Dein Google-Skript antwortet nicht (Zeitüberschreitung).' : 'Keine Verbindung zu Google (Internet?).'); }
    finally{ clearTimeout(timer); }
    let j = null; try{ j = JSON.parse(text); }catch(e){}
    if(j && typeof j === 'object') return j;
    if(r.status === 404) throw fehlerMit('skript_weg', 'Diese Web-App-Adresse gibt es nicht (mehr). Im Skript unter „Bereitstellen → Neue Bereitstellung“ eine Web-App anlegen und die neue URL eintragen.');
    if(r.status === 429 || r.status >= 500) throw fehlerMit('netz', 'Google ist gerade überlastet – nächster Versuch automatisch.');
    if(/accounts\.google\.com|ServiceLogin|signin/i.test(text)) throw fehlerMit('skript_zugriff', 'Die Web-App verlangt eine Anmeldung. Bei der Bereitstellung muss „Wer hat Zugriff: Jeder“ eingestellt sein (Bereitstellen → Bereitstellungen verwalten → Bearbeiten).');
    if(/doPost/.test(text)) throw fehlerMit('skript_code', 'Im Skript fehlt der Code aus dem MaklerCockpit. Code neu einfügen, speichern und eine neue Version bereitstellen.');
    throw fehlerMit('skript', 'Unerwartete Antwort von deinem Google-Skript (HTTP ' + r.status + ').');
  }
  function skriptSchluessel(){
    const k = laden();
    if(k.modus === 'skript' && k.skriptKey) return k.skriptKey;
    if(!k.skriptKeyNeu){ k.skriptKeyNeu = b64url(crypto.randomBytes(24)); sichern(); }
    return k.skriptKeyNeu;
  }
  async function skriptVerbinden(arg){
    const k = laden();
    const url = String((arg && arg.url) || '').trim().replace(/\?.*$/, '');
    if(/\/dev$/.test(url)) throw fehlerMit('url', 'Das ist die Test-Adresse (endet auf /dev). Bitte die „Web-App-URL“ aus „Bereitstellen → Bereitstellungen verwalten“ nehmen – sie endet auf /exec.');
    if(!SKRIPT_URL.test(url)) throw fehlerMit('url', 'Das ist keine Web-App-Adresse von Google. Sie beginnt mit https://script.google.com/macros/s/ und endet auf /exec.');
    const key = skriptSchluessel();
    const j = await skriptAnfrage(url, key, { aktion: 'test' });
    if(j.code === 'schluessel') throw fehlerMit('schluessel', 'Im Skript steht ein anderer Schlüssel. Bitte den Code aus diesem Fenster neu kopieren, im Skript ersetzen, speichern und unter „Bereitstellen → Bereitstellungen verwalten → Bearbeiten“ eine neue Version bereitstellen.');
    if(!j.ok){
      const f = j.status ? apiFehler(j.status, j.data) : null;
      if(f && f.code === 'api_aus') throw fehlerMit('api_aus', 'Im Skript fehlt noch der Kalender-Dienst: links bei „Dienste“ auf ＋ → „Google Calendar API“ → „Hinzufügen“. Dann speichern und unter „Bereitstellen → Bereitstellungen verwalten → Bearbeiten“ eine neue Version bereitstellen.');
      throw fehlerMit('skript', 'Dein Google-Skript meldet: ' + (j.fehler || (f && f.text) || ('Fehler ' + j.status)));
    }
    Object.assign(k, { modus: 'skript', skriptUrl: url, skriptKey: key, skriptKeyNeu: '', email: j.email || '', verbundenAm: Date.now() });
    zugang = null; sichern();
    return status();
  }
  async function skriptApi(methode, pfad, arg){
    const k = laden();
    for(let versuch = 0; versuch < 3; versuch++){
      let j;
      try{ j = await skriptAnfrage(k.skriptUrl, k.skriptKey, { methode, pfad, query: arg.query || {}, body: arg.body || null }); }
      catch(e){ if(e.code === 'netz' && versuch < 2){ await warte(1500 * (versuch + 1)); continue; } throw e; }
      if(j.code === 'schluessel') throw fehlerMit('abgelaufen', 'Dein Google-Skript erkennt das MaklerCockpit nicht mehr (Schlüssel geändert). Bitte über ⚙ neu verbinden.');
      const st = Number(j.status) || 0;
      if(!st) throw fehlerMit('skript', 'Dein Google-Skript meldet: ' + (j.fehler || 'unbekannter Fehler'));
      const grund = JSON.stringify((j.data && j.data.error && j.data.error.errors) || '');
      if((st === 429 || st >= 500 || (st === 403 && /rateLimitExceeded|userRateLimitExceeded/.test(grund))) && versuch < 2){ await warte(1500 * Math.pow(2, versuch)); continue; }
      if(j.ok) return { ok: true, status: st, data: j.data };
      const f = apiFehler(st, j.data);
      return { ok: false, status: st, data: j.data, code: f.code, fehler: f.text };
    }
    return { ok: false, status: 0, code: 'netz', fehler: 'Google antwortet gerade nicht – später erneut versuchen.' };
  }

  async function api(arg){
    const methode = String(arg.methode || 'GET').toUpperCase();
    const pfad = String(arg.pfad || '');
    if(!['GET', 'POST', 'PATCH', 'PUT', 'DELETE'].includes(methode)) throw fehlerMit('pfad', 'Methode nicht erlaubt');
    if(!/^\/(users\/me\/calendarList|calendars\/[^?#\s]+)$/.test(pfad) || pfad.includes('..')) throw fehlerMit('pfad', 'Pfad nicht erlaubt');
    const q = new URLSearchParams();
    Object.entries(arg.query || {}).forEach(([key, v]) => { if(v === undefined || v === null || v === '') return; (Array.isArray(v) ? v : [v]).forEach(x => q.append(key, String(x))); });
    if(laden().modus === 'skript') return skriptApi(methode, pfad, arg);
    const url = API + pfad + (q.toString() ? '?' + q.toString() : '');
    let neuesToken = false;
    for(let versuch = 0; versuch < 4; versuch++){
      const t = await token(neuesToken);
      const ctrl = new AbortController(); const timer = setTimeout(() => ctrl.abort(), 30000);
      let r;
      try{
        r = await fetch(url, { method: methode, signal: ctrl.signal,
          headers: Object.assign({ authorization: 'Bearer ' + t, accept: 'application/json' }, arg.body ? { 'content-type': 'application/json' } : {}),
          body: arg.body ? JSON.stringify(arg.body) : undefined });
      }catch(e){
        clearTimeout(timer);
        if(versuch < 2){ await warte(1500 * (versuch + 1)); continue; }
        throw fehlerMit('netz', e.name === 'AbortError' ? 'Google antwortet nicht (Zeitüberschreitung).' : 'Keine Verbindung zu Google: ' + (e.message || e));
      }
      clearTimeout(timer);
      const text = await r.text().catch(() => '');
      let data = null; try{ data = text ? JSON.parse(text) : null; }catch(e){}
      if(r.status === 401 && !neuesToken){ neuesToken = true; zugang = null; continue; }
      const grund = JSON.stringify((data && data.error && data.error.errors) || '');
      if((r.status === 429 || r.status >= 500 || (r.status === 403 && /rateLimitExceeded|userRateLimitExceeded/.test(grund))) && versuch < 3){ await warte(1200 * Math.pow(2, versuch)); continue; }
      if(r.ok) return { ok: true, status: r.status, data };
      const f = apiFehler(r.status, data);
      return { ok: false, status: r.status, data, code: f.code, fehler: f.text };
    }
    return { ok: false, status: 0, code: 'netz', fehler: 'Google antwortet gerade nicht – später erneut versuchen.' };
  }

  async function trennen(arg){
    const k = laden();
    const tok = k.refresh;
    if(k.skriptKey){ k.skriptKeyNeu = k.skriptKey; }    // gleicher Schlüssel → vorhandenes Skript passt beim Neu-Verbinden weiter
    k.refresh = ''; k.email = ''; k.verbundenAm = 0; k.skriptUrl = ''; k.skriptKey = ''; k.modus = ''; zugang = null;
    if(arg && arg.allesLoeschen){ k.clientId = ''; k.secret = ''; k.projekt = ''; k.skriptKeyNeu = ''; }
    sichern();
    if(tok){ try{ await fetch('https://oauth2.googleapis.com/revoke', { method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded' }, body: 'token=' + encodeURIComponent(tok) }); }catch(e){} }
    return status();
  }

  // ── v25: Abgleich PC ↔ Handy über dieselbe Brücke (Schlüssel bleibt im Hauptprozess) ──
  async function abgleich(arg){
    const k = laden();
    if(k.modus !== 'skript' || !k.skriptUrl || !k.skriptKey) throw fehlerMit('kein_skript', 'Für den Abgleich mit dem Handy wird die Verbindung über dein Google-Skript gebraucht (⚙ → Google Kalender → „Mit eigenem Google-Skript“).');
    const p = arg || {};
    if(!['abgleich', 'abgleichStatus', 'abgleichLeeren', 'test'].includes(p.aktion)) throw fehlerMit('aktion', 'Aktion nicht erlaubt');
    const nutzlast = { aktion: p.aktion };
    if(p.aktion === 'abgleich') Object.assign(nutzlast, { geraet: String(p.geraet || ''), seit: Number(p.seit) || 0, ohneEigene: !!p.ohneEigene, aenderungen: Array.isArray(p.aenderungen) ? p.aenderungen : [] });
    if(p.aktion === 'abgleichLeeren') nutzlast.bestaetigung = p.bestaetigung;
    for(let versuch = 0; versuch < 3; versuch++){
      let j;
      try{ j = await skriptAnfrage(k.skriptUrl, k.skriptKey, nutzlast); }
      catch(e){ if(e.code === 'netz' && versuch < 2){ await warte(2000 * (versuch + 1)); continue; } throw e; }
      if(j.code === 'schluessel') throw fehlerMit('abgelaufen', 'Dein Google-Skript erkennt das MaklerCockpit nicht mehr (Schlüssel geändert).');
      if(j.code === 'belegt' && versuch < 2){ await warte(3000); continue; }
      if(!j.ok && /Pfad nicht erlaubt/.test(j.fehler || '')) throw fehlerMit('skript_alt', 'Dein Google-Skript ist noch Version 1 – bitte den neuen Code einfügen und neu bereitstellen (⚙ → Handy & Abgleich).');
      return j;
    }
    throw fehlerMit('netz', 'Google antwortet gerade nicht – später erneut versuchen.');
  }
  // Kopplungscode fürs Handy: enthält Adresse und Schlüssel – nur auf ausdrücklichen Wunsch
  function kopplung(){
    const k = laden();
    if(k.modus !== 'skript' || !k.skriptUrl || !k.skriptKey) throw fehlerMit('kein_skript', 'Erst die Verbindung über dein Google-Skript einrichten.');
    return 'MC1-' + b64url(Buffer.from(JSON.stringify({ u: k.skriptUrl, k: k.skriptKey, e: k.email || '' }), 'utf8'));
  }

  // v41: Weiteres Gerät (zweiter PC, Tablet) mit dem Kopplungscode eines schon verbundenen Geräts verbinden – kein eigenes Skript-Einrichten nötig
  async function koppeln(code){
    const c = String(code || '').trim();
    if(!/^MC1-[\w-]{20,}$/.test(c)) throw fehlerMit('code', 'Das ist kein gültiger Kopplungscode (beginnt mit „MC1-“).');
    let d; try{ d = JSON.parse(Buffer.from(c.slice(4).replace(/-/g, '+').replace(/_/g, '/'), 'base64').toString('utf8')); }catch(e){ throw fehlerMit('code', 'Der Kopplungscode ist unvollständig – bitte komplett kopieren.'); }
    const url = String((d && d.u) || ''), key = String((d && d.k) || '');
    if(!SKRIPT_URL.test(url) || key.length < 8) throw fehlerMit('code', 'Der Kopplungscode ist unvollständig – auf dem anderen Gerät neu anzeigen lassen.');
    const j = await skriptAnfrage(url, key, { aktion: 'test' });
    if(j.code === 'schluessel') throw fehlerMit('schluessel', 'Der Schlüssel passt nicht (mehr) zu deinem Google-Skript – auf dem anderen Gerät einen neuen Code anzeigen lassen.');
    if(!j.ok && !j.version) throw fehlerMit('skript', 'Dein Google-Skript meldet: ' + (j.fehler || 'keine Antwort'));
    if((Number(j.version) || 1) < 2) throw fehlerMit('skript_alt', 'Dein Google-Skript ist noch Version 1 – am ersten PC unter „Handy & Abgleich“ zuerst aktualisieren.');
    const k = laden();
    Object.assign(k, { modus: 'skript', skriptUrl: url, skriptKey: key, skriptKeyNeu: '', email: String(d.e || j.email || ''), verbundenAm: Date.now() });
    zugang = null; sichern();
    return status();
  }

  ipcMain.handle('google', async (ev, aktion, arg) => {
    try{
      if(aktion === 'status') return Object.assign({ ok: true }, status());
      if(aktion === 'einrichten'){ const z = zugangsdatenLesen(arg); const k = laden(); k.modus = 'oauth'; k.clientId = z.id; k.secret = z.sec; k.projekt = z.projekt; k.refresh = ''; k.email = ''; zugang = null; sichern(); return Object.assign({ ok: true }, status()); }
      if(aktion === 'verbinden') return Object.assign({ ok: true }, await verbinden(arg));
      if(aktion === 'skriptSchluessel') return { ok: true, schluessel: skriptSchluessel() };
      if(aktion === 'skriptVerbinden') return Object.assign({ ok: true }, await skriptVerbinden(arg));
      if(aktion === 'abbrechen'){ if(anmeldung) anmeldung.abbrechen('Anmeldung abgebrochen.'); return { ok: true }; }
      if(aktion === 'trennen') return Object.assign({ ok: true }, await trennen(arg));
      if(aktion === 'api') return await api(arg || {});
      if(aktion === 'abgleich') return await abgleich(arg || {});
      if(aktion === 'kopplung') return { ok: true, code: kopplung() };
      if(aktion === 'koppeln') return Object.assign({ ok: true }, await koppeln(arg));
      return { ok: false, fehler: 'Unbekannte Aktion' };
    }catch(e){ return { ok: false, code: e.code || 'fehler', fehler: String(e.message || e) }; }
  });

  return { status };
};
