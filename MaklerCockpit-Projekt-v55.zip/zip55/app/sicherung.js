// MaklerCockpit v20 – Sicherung in einen Cloud-Ordner (OneDrive, Google Drive, Dropbox, iCloud oder frei gewählt)
// Kopiert daten.json (mit Tagesständen) und die Unterlagen nach <Ziel>\MaklerCockpit-Sicherung\.
// Zugangsdaten (google-konto.json) werden bewusst NICHT mitkopiert.
const { shell, dialog } = require('electron');
const fs = require('fs');
const fsp = fs.promises;
const path = require('path');
const os = require('os');

module.exports = function sicherungEinrichten(ipcMain, ORDNER, DATEI, fenster){
  const UNTERLAGEN = path.join(ORDNER, 'Unterlagen');
  const ZIELNAME = 'MaklerCockpit-Sicherung';
  let laeuft = false;

  function istOrdner(p){ try{ return !!p && fs.existsSync(p) && fs.statSync(p).isDirectory(); }catch(e){ return false; } }
  function kandidaten(){
    const h = os.homedir(), env = process.env, l = [];
    const add = (name, p) => { if(istOrdner(p) && !l.some(x => path.resolve(x.pfad).toLowerCase() === path.resolve(p).toLowerCase())) l.push({ name, pfad: p }); };
    add('OneDrive', env.OneDrive); add('OneDrive (privat)', env.OneDriveConsumer); add('OneDrive (Firma)', env.OneDriveCommercial);
    add('OneDrive', path.join(h, 'OneDrive'));
    if(process.platform === 'win32') for(const lw of 'DEFGHIJKLMNOPQRSTUVWXYZ'){ add('Google Drive', lw + ':\\Meine Ablage'); add('Google Drive', lw + ':\\My Drive'); }
    add('Google Drive', path.join(h, 'Google Drive', 'Meine Ablage')); add('Google Drive', path.join(h, 'Google Drive', 'My Drive')); add('Google Drive', path.join(h, 'Google Drive'));
    for(const p of [path.join(env.APPDATA || '', 'Dropbox', 'info.json'), path.join(env.LOCALAPPDATA || '', 'Dropbox', 'info.json')]){
      try{ const j = JSON.parse(fs.readFileSync(p, 'utf8')); Object.values(j).forEach(v => v && v.path && add('Dropbox', v.path)); }catch(e){}
    }
    add('Dropbox', path.join(h, 'Dropbox'));
    add('iCloud Drive', path.join(h, 'iCloudDrive'));
    return l;
  }
  const tag = d => { const x = d || new Date(); return x.getFullYear() + '-' + String(x.getMonth() + 1).padStart(2, '0') + '-' + String(x.getDate()).padStart(2, '0'); };

  async function dateienUnter(dir){
    const out = [];
    async function lauf(d, rel){
      let eintraege = []; try{ eintraege = await fsp.readdir(d, { withFileTypes: true }); }catch(e){ return; }
      for(const e of eintraege){
        if(e.name === '_Papierkorb' || e.name.startsWith('~$') || e.name === 'desktop.ini') continue;
        const abs = path.join(d, e.name), r = rel ? rel + '/' + e.name : e.name;
        if(e.isDirectory()) await lauf(abs, r); else if(e.isFile()) out.push({ abs, rel: r });
      }
    }
    await lauf(dir, '');
    return out;
  }

  async function sichern(arg){
    const ziel = String((arg && arg.ziel) || '');
    if(!istOrdner(ziel)) return { ok: false, code: 'ziel', fehler: 'Der Sicherungsordner ist nicht erreichbar: ' + ziel + ' (Cloud-Programm geschlossen oder Laufwerk nicht da?)' };
    if(!fs.existsSync(DATEI)) return { ok: false, fehler: 'Noch keine Daten zum Sichern vorhanden.' };
    if(laeuft) return { ok: false, code: 'laeuft', fehler: 'Eine Sicherung läuft bereits.' };
    laeuft = true;
    try{
      const basis = path.join(ziel, ZIELNAME), datenDir = path.join(basis, 'Daten');
      await fsp.mkdir(datenDir, { recursive: true });
      const inhalt = await fsp.readFile(DATEI);
      JSON.parse(inhalt.toString('utf8'));                     // nur gültige Daten sichern
      await fsp.writeFile(path.join(datenDir, 'daten-' + tag() + '.json'), inhalt);
      await fsp.writeFile(path.join(basis, 'daten-aktuell.json'), inhalt);
      // Tagesstände: die letzten 30 behalten
      const alte = (await fsp.readdir(datenDir)).filter(n => /^daten-\d{4}-\d{2}-\d{2}\.json$/.test(n)).sort();
      for(const n of alte.slice(0, Math.max(0, alte.length - 30))){ try{ await fsp.unlink(path.join(datenDir, n)); }catch(e){} }
      // Unterlagen: neue und geänderte Dateien kopieren (nichts löschen – es ist eine Sicherung)
      let kopiert = 0, gesamt = 0, bytes = 0;
      if(arg.unterlagen !== false && istOrdner(UNTERLAGEN)){
        const zielU = path.join(basis, 'Unterlagen');
        for(const f of await dateienUnter(UNTERLAGEN)){
          gesamt++;
          const st = await fsp.stat(f.abs), zp = path.join(zielU, ...f.rel.split('/'));
          let gleich = false;
          try{ const zs = await fsp.stat(zp); gleich = zs.size === st.size && Math.abs(zs.mtimeMs - st.mtimeMs) < 2000; }catch(e){}
          if(gleich) continue;
          await fsp.mkdir(path.dirname(zp), { recursive: true });
          await fsp.copyFile(f.abs, zp);
          try{ await fsp.utimes(zp, st.atime, st.mtime); }catch(e){}
          kopiert++; bytes += st.size;
        }
      }
      const liesmich = path.join(basis, 'LIESMICH.txt');
      if(!fs.existsSync(liesmich)) await fsp.writeFile(liesmich, [
        'Sicherung des MaklerCockpit (automatisch)', '',
        'daten-aktuell.json  = letzter Stand aller Daten (Leads, Objekte, Kontakte, Termine …)',
        'Daten\\daten-JJJJ-MM-TT.json = Tagesstände der letzten 30 Tage',
        'Unterlagen\\        = Kopie der Unterlagen zu den Objekten', '',
        'Wiederherstellen:',
        '1. MaklerCockpit öffnen → oben rechts ⚙ → „Daten importieren (JSON)“ → daten-aktuell.json (oder einen Tagesstand) wählen.',
        '2. Den Ordner „Unterlagen“ nach Dokumente\\MaklerCockpit\\ kopieren.', '',
        'Die Google-Kalender-Verbindung wird nicht gesichert – nach dem Wiederherstellen einfach neu verbinden.'
      ].join('\r\n'), 'utf8');
      return { ok: true, zeit: Date.now(), ordner: basis, unterlagenGesamt: gesamt, kopiert, bytes };
    }catch(e){
      return { ok: false, fehler: 'Sicherung fehlgeschlagen: ' + (e.message || e) };
    }finally{ laeuft = false; }
  }

  ipcMain.handle('sicherung', async (e, aktion, arg) => {
    try{
      if(aktion === 'ziele') return { ok: true, ziele: kandidaten() };
      if(aktion === 'waehlen'){
        const r = await dialog.showOpenDialog(fenster(), { title: 'Ordner für die Sicherung wählen (z. B. OneDrive)', properties: ['openDirectory', 'createDirectory'] });
        if(r.canceled || !r.filePaths[0]) return { ok: false, abgebrochen: true };
        const p = r.filePaths[0];
        if(path.resolve(p).toLowerCase().startsWith(path.resolve(ORDNER).toLowerCase())) return { ok: false, fehler: 'Bitte einen Ordner außerhalb von Dokumente\\MaklerCockpit wählen – am besten in OneDrive, Google Drive oder auf einem USB-Stick.' };
        return { ok: true, pfad: p, name: path.basename(p) };
      }
      if(aktion === 'pruefen') return { ok: true, da: istOrdner(arg && arg.ziel) };
      if(aktion === 'jetzt') return await sichern(arg || {});
      if(aktion === 'oeffnen'){
        const p = path.join(String((arg && arg.ziel) || ''), ZIELNAME);
        if(!istOrdner(p)) return { ok: false, fehler: 'Ordner nicht gefunden.' };
        const f = await shell.openPath(p); return f ? { ok: false, fehler: f } : { ok: true };
      }
      return { ok: false, fehler: 'Unbekannte Aktion' };
    }catch(err){ return { ok: false, fehler: String(err.message || err) }; }
  });
};
