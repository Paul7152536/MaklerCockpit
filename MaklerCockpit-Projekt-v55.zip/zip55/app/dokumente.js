// MaklerCockpit v18 – Unterlagen zu Objekten (Hauptprozess)
// Dateien liegen in Dokumente\MaklerCockpit\Unterlagen\<Objekt-Ordner>\ – in daten.json stehen nur Name, Kategorie und Pfad.
const { shell, dialog } = require('electron');
const fs = require('fs');
const path = require('path');

module.exports = function dokumenteEinrichten(ipcMain, ORDNER, fenster){
  const BASIS = path.join(ORDNER, 'Unterlagen');
  const basisAbs = () => path.resolve(BASIS);
  function ordnerPfad(name){
    const n = String(name || '').trim();
    if(!n || n === '.' || n === '..' || /[\\/:*?"<>|\u0000-\u001f]/.test(n)) throw new Error('Ungültiger Ordnername');
    const dir = path.join(BASIS, n); fs.mkdirSync(dir, { recursive: true }); return dir;
  }
  function dateiPfad(rel){
    const abs = path.resolve(BASIS, String(rel || ''));
    if(!abs.startsWith(basisAbs() + path.sep)) throw new Error('Pfad nicht erlaubt');
    return abs;
  }
  function eindeutig(dir, name){
    name = String(name || 'Datei').replace(/[\\/:*?"<>|\u0000-\u001f]+/g, '_').trim() || 'Datei';
    const ext = path.extname(name), stamm = name.slice(0, name.length - ext.length);
    let n = name, i = 2;
    while(fs.existsSync(path.join(dir, n))) n = `${stamm} (${i++})${ext}`;
    return n;
  }
  const rel = (dir, n) => path.relative(BASIS, path.join(dir, n)).split(path.sep).join('/');

  ipcMain.handle('dok', async (e, aktion, arg) => {
    try{
      arg = arg || {};
      if(aktion === 'basis'){ fs.mkdirSync(BASIS, { recursive: true }); return { ok: true, basis: basisAbs() }; }
      if(aktion === 'auswaehlen'){
        const dir = ordnerPfad(arg.ordner);
        const r = await dialog.showOpenDialog(fenster(), { title: 'Unterlagen hinzufügen', properties: ['openFile', 'multiSelections'],
          filters: [{ name: 'Dokumente & Bilder', extensions: ['pdf','jpg','jpeg','png','webp','heic','gif','tif','tiff','doc','docx','xls','xlsx','odt','txt','rtf','eml','msg','zip'] }, { name: 'Alle Dateien', extensions: ['*'] }] });
        if(r.canceled || !r.filePaths.length) return { ok: false, abgebrochen: true };
        const dateien = [];
        for(const p of r.filePaths){
          const n = eindeutig(dir, path.basename(p));
          fs.copyFileSync(p, path.join(dir, n));
          dateien.push({ name: path.basename(p), datei: rel(dir, n), groesse: fs.statSync(path.join(dir, n)).size });
        }
        return { ok: true, dateien };
      }
      if(aktion === 'speichern'){
        const dir = ordnerPfad(arg.ordner);
        const daten = Buffer.from(arg.daten || []);
        if(!daten.length) return { ok: false, fehler: 'Die Datei ist leer.' };
        const n = eindeutig(dir, arg.name);
        fs.writeFileSync(path.join(dir, n), daten);
        return { ok: true, datei: { name: String(arg.name || n), datei: rel(dir, n), groesse: daten.length } };
      }
      if(aktion === 'oeffnen' || aktion === 'zeigen'){
        const abs = dateiPfad(arg.datei);
        if(!fs.existsSync(abs)) return { ok: false, code: 'weg', fehler: 'Die Datei ist nicht mehr da (verschoben oder gelöscht?).' };
        if(aktion === 'zeigen'){ shell.showItemInFolder(abs); return { ok: true }; }
        const f = await shell.openPath(abs);
        return f ? { ok: false, fehler: f } : { ok: true };
      }
      if(aktion === 'ordner'){ const dir = ordnerPfad(arg.ordner); const f = await shell.openPath(dir); return f ? { ok: false, fehler: f } : { ok: true }; }
      if(aktion === 'loeschen'){
        const abs = dateiPfad(arg.datei);
        if(!fs.existsSync(abs)) return { ok: true, weg: true };
        try{ await shell.trashItem(abs); return { ok: true, papierkorb: true }; }
        catch(err){
          const pk = path.join(BASIS, '_Papierkorb'); fs.mkdirSync(pk, { recursive: true });
          fs.renameSync(abs, path.join(pk, eindeutig(pk, path.basename(abs))));
          return { ok: true, papierkorb: false };
        }
      }
      if(aktion === 'vorhanden'){ return { ok: true, da: (arg.dateien || []).map(d => { try{ return fs.existsSync(dateiPfad(d)); }catch(err){ return false; } }) }; }
      return { ok: false, fehler: 'Unbekannte Aktion' };
    }catch(err){ return { ok: false, fehler: String(err.message || err) }; }
  });
};
