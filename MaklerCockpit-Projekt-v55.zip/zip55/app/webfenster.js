// MaklerCockpit v22/v52 – Kleinanzeigen im eigenen Fenster öffnen und Gesuche der angezeigten Seite übernehmen.
// Die Seite bekommt KEINEN Zugriff auf das Programm: Die Leiste unten meldet einen Klick nur über die Konsole,
// das Auslesen macht das Programm selbst – und nur, wenn du den Knopf drückst.
const { BrowserWindow, shell } = require('electron');

module.exports = function webfensterEinrichten(ipcMain, hauptfenster){
  let bw = null;
  const TOKEN = '__MC_' + Math.random().toString(36).slice(2, 10) + '__';
  const testErlaubt = process.env.MC_WEB_TEST === '1';
  // v52: alle Seiten von kleinanzeigen.de inkl. Unterseiten wie login.kleinanzeigen.de (Anmeldung) bleiben im Fenster
  const kaHost = u => { try{ const x = new URL(String(u || '')); return x.protocol === 'https:' && /(^|\.)kleinanzeigen\.de$/i.test(x.hostname); }catch(e){ return false; } };
  const erlaubt = u => kaHost(u) || (testErlaubt && /^http:\/\/127\.0\.0\.1:\d+\//.test(String(u || '')));

  const LEISTE = `(() => {
    if(document.getElementById('__mcLeiste')) { if(window.__mcZaehlen) window.__mcZaehlen(); return; }
    const d = document.createElement('div'); d.id = '__mcLeiste';
    d.setAttribute('style', 'position:fixed;left:0;right:0;bottom:0;z-index:2147483647;background:#0f1a2e;color:#e6edf7;font:14px/1.3 Segoe UI,Arial,sans-serif;display:flex;align-items:center;gap:10px;padding:10px 16px;box-shadow:0 -4px 18px rgba(0,0,0,.35);border-top:2px solid #ff8a3d;');
    d.innerHTML = '<b style="color:#ff8a3d;white-space:nowrap;">MaklerCockpit</b>'
      + '<button id="__mcZurueck" style="background:#1a2944;color:#e6edf7;border:1px solid #34507d;border-radius:8px;padding:7px 12px;cursor:pointer;">← Zurück</button>'
      + '<button id="__mcNehmen" style="background:#ff8a3d;color:#14100c;border:0;border-radius:8px;padding:8px 14px;font-weight:700;cursor:pointer;">👥 Gesuche dieser Seite übernehmen</button>'
      + '<button id="__mcLink" title="Link aus der Bestätigungs-Mail kopieren, dann hier klicken" style="background:#1a2944;color:#e6edf7;border:1px solid #34507d;border-radius:8px;padding:7px 12px;cursor:pointer;">🔗 Kopierten Link öffnen</button>'
      + '<span id="__mcInfo" style="color:#93a4c0;font-size:13px;"></span>';
    document.body.appendChild(d);
    document.body.style.paddingBottom = '64px';
    document.getElementById('__mcNehmen').onclick = () => { document.getElementById('__mcInfo').textContent = '⏳ wird übernommen …'; console.log('${TOKEN}nehmen'); };
    document.getElementById('__mcZurueck').onclick = () => console.log('${TOKEN}zurueck');
    document.getElementById('__mcLink').onclick = () => console.log('${TOKEN}link');
    window.__mcStatus = t => { const i = document.getElementById('__mcInfo'); if(i) i.textContent = t; };
    window.__mcZaehlen = () => {
      const detail = /\\/s-anzeige\\//.test(location.pathname);
      const n = detail ? 1 : document.querySelectorAll('article[data-adid], li[data-adid] article, .aditem').length;
      const b = document.getElementById('__mcNehmen'); if(b) b.textContent = detail ? '👥 Dieses Gesuch übernehmen' : '👥 Gesuche dieser Seite übernehmen' + (n ? ' (' + n + ')' : '');
      window.__mcStatus(detail ? '' : (/anzeige:gesuche/.test(location.href) ? 'Nur Gesuche – Angebote werden ignoriert. „Keine Makler“ wird aussortiert.' : 'Tipp: Oben bei „Anzeigentyp“ auf „Gesuche“ stellen.'));
    };
    window.__mcZaehlen();
  })()`;

  const AUSLESEN = `(() => {
    const txt = el => (el ? (el.innerText || el.textContent || '') : '').replace(/\\s+/g, ' ').trim();
    const abs = h => { try{ return new URL(h, location.href).href.split('?')[0]; }catch(e){ return ''; } };
    const out = [];
    if(/\\/s-anzeige\\//.test(location.pathname)){
      const q = s => document.querySelector(s);
      out.push({ titel: txt(q('#viewad-title') || q('h1')), text: txt(q('#viewad-description-text') || q('[itemprop="description"]') || q('#viewad-description')),
        ort: txt(q('#viewad-locality') || q('[itemprop="addressLocality"]')), preis: txt(q('#viewad-price') || q('[itemprop="price"]')),
        datum: (txt(q('#viewad-extra-info')).match(/\\d{2}\\.\\d{2}\\.\\d{4}/) || [''])[0], name: txt(q('.userprofile-vip a') || q('.userprofile-vip') || q('[class*="userprofile"] a')),
        art: txt(q('#viewad-details') || q('.addetailslist')), link: location.href.split('?')[0], detail: true });
      return { url: location.href, art: 'detail', eintraege: out };
    }
    const gesehen = new Set();
    const nimm = (c, link) => {
      if(!c || !link || gesehen.has(link)) return; gesehen.add(link);
      const titelEl = c.querySelector('h2, h3, .text-module-begin, a.ellipsis');
      const titel = txt(titelEl) || txt(c.querySelector('a[href*="/s-anzeige/"]'));
      const ganz = txt(c);
      const ortEl = c.querySelector('.aditem-main--top--left, [class*="location"], [class*="ort"]');
      const datEl = c.querySelector('.aditem-main--top--right, [class*="date"]');
      const besEl = c.querySelector('.aditem-main--middle--description, [class*="description"], p');
      const preisEl = c.querySelector('.aditem-main--middle--price-shipping--price, [class*="price"]');
      const ort = txt(ortEl) || ((ganz.match(/\\b\\d{5}\\s+[A-ZÄÖÜ][\\wäöüß\\- ]{2,40}/) || [''])[0]);
      out.push({ titel, text: txt(besEl) || ganz.replace(titel, '').slice(0, 600), ort, datum: txt(datEl), preis: txt(preisEl), link, gesuchMarke: /\\bgesuch\\b/i.test(ganz) });
    };
    document.querySelectorAll('article[data-adid], li[data-adid], .aditem').forEach(c => {
      const h = c.getAttribute('data-href') || (c.querySelector('a[href*="/s-anzeige/"]') || {}).getAttribute?.('href') || '';
      nimm(c, h ? abs(h) : '');
    });
    if(!out.length) document.querySelectorAll('a[href*="/s-anzeige/"]').forEach(a => nimm(a.closest('article, li') || a.parentElement, abs(a.getAttribute('href'))));
    return { url: location.href, art: 'liste', gesuchSeite: /anzeige:gesuche/.test(location.href), eintraege: out.slice(0, 120) };
  })()`;

  // v47: Nachricht ins Kontaktfeld der Anzeige eintragen – SENDEN klickt Paul selbst. Bei „keine Makler“ erst nachfragen.
  const KEIN_MAKLER = String.raw`(bitte\s+)?(keine?n?|kein)\s+(makler|immobilienmakler|vermittler)|nicht\s+(an|über|ueber)\s+makler|makler\w*\s*(anfragen|angebote|anrufe)?\s*(zwecklos|unerw[üu]nscht|nicht\s+erw[üu]nscht|bitte\s+nicht|ausgeschlossen|verboten|sinnlos)|ohne\s+makler|maklerfrei|keine\s+gewerblichen\s+anfragen`;
  let offen = null;   // { text, link, trotzdem }
  const FUELLEN = (text, trotzdem) => `(async () => {
    const text = ${JSON.stringify(String(text || '').slice(0, 4000))}, trotzdem = ${trotzdem ? 'true' : 'false'};
    const status = t => { if(window.__mcStatus) window.__mcStatus(t); };
    const sichtbar = el => !!el && !!(el.offsetWidth || el.offsetHeight || el.getClientRects().length);
    const knopf = (id, t, f) => { let b = document.getElementById(id); const l = document.getElementById('__mcLeiste'); if(!l) return; if(!b){ b = document.createElement('button'); b.id = id; b.setAttribute('style', 'background:#1a2944;color:#e6edf7;border:1px solid #ff8a3d;border-radius:8px;padding:7px 12px;cursor:pointer;font-weight:600;'); l.insertBefore(b, document.getElementById('__mcInfo')); } b.textContent = t; b.onclick = f; };
    const beschr = ((document.querySelector('#viewad-description-text, [itemprop="description"], #viewad-description') || {}).innerText || '') + ' ' + ((document.querySelector('#viewad-title, h1') || {}).innerText || '');
    const nb = document.getElementById('__mcNehmen'); if(nb) nb.style.display = 'none';
    if(!trotzdem && new RegExp(${JSON.stringify(KEIN_MAKLER)}, 'i').test(beschr) && !/makler\\w*\\s*(sind\\s+)?(ok|okay|willkommen|erw[üu]nscht|gerne)/i.test(beschr)){
      status('⚠️ Im Inserat steht „keine Makler“ – Nachricht wurde NICHT eingetragen.');
      knopf('__mcTrotzdem', '✍️ Trotzdem eintragen', () => console.log('${TOKEN}trotzdem'));
      return 'keinMakler';
    }
    const finde = () => [...document.querySelectorAll('textarea')].find(t => sichtbar(t) && !t.disabled && !t.readOnly && /nachricht|message|text|anfrage/i.test([t.name, t.id, t.placeholder, t.getAttribute('aria-label')].join(' ')))
      || [...document.querySelectorAll('form textarea, textarea')].find(t => sichtbar(t) && !t.disabled && !t.readOnly);
    let feld = finde();
    if(!feld){
      const k = [...document.querySelectorAll('button, a, [role="button"]')].find(b => sichtbar(b) && /nachricht\\s*(schreiben|senden)|kontaktieren|anbieter\\s+kontaktieren/i.test(b.innerText || b.textContent || ''));
      if(k) k.click();
      for(let i = 0; i < 40 && !feld; i++){ await new Promise(r => setTimeout(r, 250)); feld = finde(); }
    }
    if(!feld){
      status('Kein Nachrichtenfeld gefunden – bitte einloggen bzw. „Nachricht schreiben“ klicken. Der Text ist in der Zwischenablage (Strg+V).');
      knopf('__mcNochmal', '✍️ Text eintragen', () => console.log('${TOKEN}trotzdem'));
      return 'keinFeld';
    }
    const setter = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value').set;
    feld.focus(); setter.call(feld, text);
    feld.dispatchEvent(new Event('input', { bubbles: true })); feld.dispatchEvent(new Event('change', { bubbles: true }));
    feld.style.outline = '3px solid #ff8a3d'; feld.scrollIntoView({ block: 'center' });
    status('✍️ Nachricht eingetragen – bitte kurz prüfen und selbst auf „Senden“ klicken.');
    knopf('__mcNochmal', '↺ Text neu eintragen', () => console.log('${TOKEN}trotzdem'));
    return 'ok';
  })()`;
  async function fuellen(trotzdem){
    if(!bw || bw.isDestroyed() || !offen) return 'kein';
    let r; try{ r = await bw.webContents.executeJavaScript(FUELLEN(offen.text, trotzdem || offen.trotzdem)); }catch(e){ r = 'fehler'; }
    offen.ergebnis = r;
    const h = hauptfenster(); if(h && !h.isDestroyed()) h.webContents.send('webfenster-daten', { art: 'nachricht', ergebnis: r, link: offen.link, id: offen.id });
    return r;
  }

  function leiste(){ if(bw && !bw.isDestroyed()) bw.webContents.executeJavaScript(LEISTE).catch(() => {}); }
  // v55: Werbung und Tracker im Kleinanzeigen-Fenster blockieren → Inserate laden deutlich schneller
  const BLOCK = /(^|\.)(doubleclick\.net|googlesyndication\.com|googleadservices\.com|googletagmanager\.com|google-analytics\.com|googletagservices\.com|adservice\.google\.[a-z.]+|adnxs\.com|criteo\.(com|net)|amazon-adsystem\.com|adform\.net|adsrvr\.org|rubiconproject\.com|pubmatic\.com|smartadserver\.com|taboola\.com|outbrain\.com|yieldlab\.net|teads\.tv|casalemedia\.com|openx\.net|3lift\.com|moatads\.com|scorecardresearch\.com|hotjar\.com|facebook\.net|connect\.facebook\.net|bat\.bing\.com|analytics\.tiktok\.com|ioam\.de|xplosion\.de|emetriq\.de|theadex\.com|adition\.com|mookie1\.com|360yield\.com|bidswitch\.net|sharethrough\.com|indexww\.com|media\.net|quantserve\.com|krxd\.net|bluekai\.com|demdex\.net|agkn\.com|everesttech\.net|adsafeprotected\.com|doubleverify\.com|imrworldwide\.com|nr-data\.net|ads\.pubmatic\.com|prebid\.[a-z.]+|liadm\.com|id5-sync\.com|uidapi\.com|cdn\.confiant-integrations\.net|securepubads\.g\.doubleclick\.net)$/i;
  let blockerAn = false, beenden = false;
  function blocker(){
    if(blockerAn) return; blockerAn = true;
    try{
      const ses = require('electron').session.fromPartition('persist:kleinanzeigen');
      ses.webRequest.onBeforeRequest({ urls: ['http://*/*', 'https://*/*'] }, (d, cb) => {
        try{
          if(d.resourceType === 'mainFrame') return cb({});
          const h = new URL(d.url).hostname;
          if(BLOCK.test(h)) return cb({ cancel: true });
          if(/(^|\.)kleinanzeigen\.de$/i.test(h) && /\/(liberty|adsense|ads|adserver|prebid)\b/i.test(new URL(d.url).pathname) && d.resourceType !== 'xhr') return cb({ cancel: true });
          if(d.resourceType === 'media' && !/(^|\.)kleinanzeigen\.de$/i.test(h)) return cb({ cancel: true });
        }catch(e){}
        cb({});
      });
    }catch(e){}
  }
  function anlegen(versteckt){
    blocker();
    bw = new BrowserWindow({ show: !versteckt, backgroundColor: '#ffffff', width: 1280, height: 920, title: 'Kleinanzeigen – Gesuche finden (MaklerCockpit)', autoHideMenuBar: true,
      webPreferences: { partition: 'persist:kleinanzeigen', contextIsolation: true, nodeIntegration: false, sandbox: true } });
    try{ const ua = bw.webContents.getUserAgent().replace(/\s*(Electron|MaklerCockpit|makler-cockpit)\/\S+/gi, ''); bw.webContents.setUserAgent(ua); }catch(e){}
    bw.webContents.on('did-finish-load', () => { leiste(); if(offen && !offen.erledigt && bw.webContents.getURL().split('?')[0].split('#')[0] === offen.link.split('?')[0].split('#')[0]){ offen.erledigt = true; setTimeout(() => fuellen(false), 700); } });
    bw.webContents.on('did-navigate-in-page', () => setTimeout(leiste, 400));
    bw.webContents.setWindowOpenHandler(({ url }) => { if(erlaubt(url)) bw.loadURL(url); else if(/^https?:/i.test(url)) shell.openExternal(url); return { action: 'deny' }; });
    bw.webContents.on('will-navigate', (e, url) => { if(!erlaubt(url)){ e.preventDefault(); if(/^https?:/i.test(url)) shell.openExternal(url); } });
    bw.webContents.on('console-message', async (...args) => {
      const ev = args[0], msg = typeof ev?.message === 'string' ? ev.message : args[2];
      if(msg === TOKEN + 'zurueck'){ if(bw.webContents.canGoBack()) bw.webContents.goBack(); return; }
      if(msg === TOKEN + 'trotzdem'){ fuellen(true); return; }
      if(msg === TOKEN + 'link'){                    // v52: Bestätigungslink aus der Mail im selben Fenster öffnen (gleiche Anmeldung)
        let l = ''; try{ l = String(require('electron').clipboard.readText() || '').trim().split(/\s+/)[0]; }catch(e){}
        if(erlaubt(l)) bw.loadURL(l).catch(() => {});
        else bw.webContents.executeJavaScript(`window.__mcStatus && window.__mcStatus('In der Zwischenablage ist kein Kleinanzeigen-Link. Link in der Mail rechts anklicken → „Link kopieren“, dann nochmal.')`).catch(() => {});
        return;
      }
      if(msg !== TOKEN + 'nehmen') return;
      let daten;
      try{ daten = await bw.webContents.executeJavaScript(AUSLESEN); }catch(e){ daten = { fehler: String(e.message || e) }; }
      const h = hauptfenster();
      if(h && !h.isDestroyed()) h.webContents.send('webfenster-daten', daten);
    });
    // v55: Schließen = nur ausblenden → nächstes Inserat öffnet sofort (Anmeldung und Seitenteile bleiben geladen)
    bw.on('close', e => { if(!beenden){ e.preventDefault(); try{ bw.webContents.loadURL('about:blank'); }catch(x){} bw.hide(); } });
    bw.on('closed', () => { bw = null; });
    try{ const h = hauptfenster(); if(h && !h.__mcWfHaken){ h.__mcWfHaken = true; h.once('close', () => { beenden = true; if(bw && !bw.isDestroyed()) bw.destroy(); }); } }catch(e){}
  }
  try{ require('electron').app.on('before-quit', () => { beenden = true; }); }catch(e){}

  ipcMain.handle('webfenster', async (e, aktion, arg) => {
    try{
      if(aktion === 'oeffnen'){
        const url = String((arg && arg.url) || '');
        if(!erlaubt(url)) return { ok: false, fehler: 'Nur Seiten von kleinanzeigen.de' };
        if(!bw || bw.isDestroyed()) anlegen();
        bw.show(); bw.focus();
        bw.loadURL(url).catch(() => {});
        return { ok: true };
      }
      if(aktion === 'vorwaermen'){                 // v55: Fenster unsichtbar vorbereiten, damit das erste Inserat schnell aufgeht
        if(!bw || bw.isDestroyed()){ anlegen(true); bw.loadURL('https://www.kleinanzeigen.de/').catch(() => {}); }
        return { ok: true };
      }
      if(aktion === 'nachricht'){                   // v47: Anzeige öffnen und Nachricht eintragen (nicht senden)
        const url = String((arg && arg.url) || '');
        if(!erlaubt(url)) return { ok: false, fehler: 'Nur Seiten von kleinanzeigen.de' };
        offen = { link: url, text: String((arg && arg.text) || ''), id: String((arg && arg.id) || ''), trotzdem: !!(arg && arg.trotzdem), erledigt: false };
        try{ require('electron').clipboard.writeText(offen.text); }catch(e){}
        if(!bw || bw.isDestroyed()) anlegen();
        const jetzt = bw.webContents.getURL().split('?')[0].split('#')[0];
        if(jetzt && jetzt === url.split('?')[0].split('#')[0]){ offen.erledigt = true; bw.show(); bw.focus(); return { ok: true, ergebnis: await fuellen(false) }; }
        bw.show(); bw.focus();
        bw.loadURL(url).catch(() => {});
        return { ok: true };
      }
      if(aktion === 'status'){
        if(bw && !bw.isDestroyed()) await bw.webContents.executeJavaScript(`window.__mcStatus && window.__mcStatus(${JSON.stringify(String(arg || '').slice(0, 300))})`).catch(() => {});
        return { ok: true };
      }
      if(aktion === 'nehmen'){                      // für Tests: Knopf „übernehmen“ auslösen
        if(!bw || bw.isDestroyed()) return { ok: false };
        await bw.webContents.executeJavaScript(`document.getElementById('__mcNehmen') && document.getElementById('__mcNehmen').click()`);
        return { ok: true };
      }
      if(aktion === 'lesen'){                       // v54: Inserat nur lesen (ohne Fenster, ohne Bilder/Skripte) – für Titel-Prüfung und Schnell-Durchsicht
        const url = String((arg && arg.url) || '');
        if(!erlaubt(url)) return { ok: false, fehler: 'Nur Seiten von kleinanzeigen.de' };
        const ses = require('electron').session.fromPartition('persist:kleinanzeigen');
        const ctrl = new AbortController(); const t = setTimeout(() => ctrl.abort(), 20000);
        try{
          const r = await ses.fetch(url, { signal: ctrl.signal, redirect: 'follow', headers: { 'accept-language': 'de-DE,de;q=0.9' } });
          const buf = await r.arrayBuffer();
          const text = new TextDecoder('utf-8').decode(buf.byteLength > 1500000 ? buf.slice(0, 1500000) : buf);
          return { ok: r.ok, status: r.status, url: r.url, text };
        }catch(e){ return { ok: false, fehler: e.name === 'AbortError' ? 'Zeitüberschreitung' : String(e.message || e) }; }
        finally{ clearTimeout(t); }
      }
      if(aktion === 'schliessen'){ if(bw && !bw.isDestroyed()) bw.close(); return { ok: true }; }
      return { ok: false, fehler: 'Unbekannte Aktion' };
    }catch(err){ return { ok: false, fehler: String(err.message || err) }; }
  });
};
