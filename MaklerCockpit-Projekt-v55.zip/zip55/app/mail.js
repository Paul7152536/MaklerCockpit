// MaklerCockpit v52 – Anschreiben mit Bild-Anhang am PC.
// 1) Klassisches Outlook (Windows): Entwurf über Outlook selbst öffnen (mit Signatur und Anhang) – Senden drückst du.
// 2) Sonst: Entwurfsdatei (.eml, „X-Unsent“) erzeugen und mit dem Standard-Mailprogramm öffnen.
// Es wird nie automatisch gesendet. Die Daten gehen nur an dein eigenes Mailprogramm.
const { shell } = require('electron');
const path = require('path');
const fs = require('fs');
const os = require('os');
const { execFile } = require('child_process');

const PS = String.raw`$ErrorActionPreference = 'Stop'
$p = Get-Content -Raw -Encoding UTF8 -LiteralPath $args[0] | ConvertFrom-Json
$o = New-Object -ComObject Outlook.Application
$m = $o.CreateItem(0)
$m.To = $p.an
$m.Subject = $p.betreff
if($p.bild){ [void]$m.Attachments.Add([string]$p.bild) }
$m.Display()
$re = New-Object System.Text.RegularExpressions.Regex('<body[^>]*>', 'IgnoreCase')
$alt = [string]$m.HTMLBody
if($re.IsMatch($alt)){ $m.HTMLBody = $re.Replace($alt, { param($x) $x.Value + $p.html }, 1) } else { $m.HTMLBody = $p.html + $alt }
'ok'
`;

function sauber(n){ return String(n || 'Bild').replace(/[\\/:*?"<>|\u0000-\u001f]+/g, '_').replace(/\.(jpe?g|png)$/i, '').trim().slice(0, 60) || 'Bild'; }
function htmlAus(text){
  const e = String(text || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/\r?\n/g, '<br>');
  return `<div style="font-family:Calibri,Arial,sans-serif;font-size:11pt;">${e}</div><br>`;
}
function b64Zeilen(buf){ return buf.toString('base64').replace(/.{1,76}/g, z => z + '\r\n'); }
function kopf(t){ return /^[\x20-\x7e]*$/.test(t) ? t : '=?UTF-8?B?' + Buffer.from(t, 'utf8').toString('base64') + '?='; }
function eml(an, betreff, text, bildPfad, bildName, typ){
  const k = ['To: ' + an, 'Subject: ' + kopf(betreff), 'X-Unsent: 1', 'MIME-Version: 1.0'];
  const tx = b64Zeilen(Buffer.from(String(text).replace(/\r?\n/g, '\r\n'), 'utf8'));
  if(!bildPfad) return k.concat(['Content-Type: text/plain; charset=UTF-8', 'Content-Transfer-Encoding: base64', '', tx]).join('\r\n');
  const g = 'MC_' + Date.now().toString(36), n = kopf(bildName);
  return k.concat([`Content-Type: multipart/mixed; boundary="${g}"`, '', `--${g}`, 'Content-Type: text/plain; charset=UTF-8', 'Content-Transfer-Encoding: base64', '', tx,
    `--${g}`, `Content-Type: ${typ}; name="${n}"`, `Content-Disposition: attachment; filename="${n}"`, 'Content-Transfer-Encoding: base64', '', b64Zeilen(fs.readFileSync(bildPfad)), `--${g}--`, '']).join('\r\n');
}

module.exports = function mailEinrichten(ipcMain){
  ipcMain.handle('mailEntwurf', async (e, arg) => {
    try{
      const an = String((arg && arg.an) || '').trim(), betreff = String((arg && arg.betreff) || '').slice(0, 300), text = String((arg && arg.text) || '').slice(0, 20000);
      if(!/^[^\s@<>"',;]+@[^\s@<>"',;]+\.[a-z]{2,}$/i.test(an)) return { ok: false, fehler: 'Ungültige E-Mail-Adresse' };
      const ordner = path.join(os.tmpdir(), 'MaklerCockpit-Mail');
      fs.mkdirSync(ordner, { recursive: true });
      for(const f of fs.readdirSync(ordner)){ try{ fs.unlinkSync(path.join(ordner, f)); }catch(x){} }
      let bildPfad = '', bildName = '', typ = '';
      const b = arg && arg.bild;
      if(b && b.b64){
        const buf = Buffer.from(String(b.b64), 'base64');
        if(buf.length > 8 * 1024 * 1024) return { ok: false, fehler: 'Bild zu groß' };
        const png = buf[0] === 0x89 && buf[1] === 0x50, jpg = buf[0] === 0xff && buf[1] === 0xd8;
        if(!png && !jpg) return { ok: false, fehler: 'Nur JPG oder PNG' };
        typ = png ? 'image/png' : 'image/jpeg';
        bildName = sauber(b.name) + (png ? '.png' : '.jpg');
        bildPfad = path.join(ordner, bildName);
        fs.writeFileSync(bildPfad, buf);
      }
      if(process.platform === 'win32' && !(arg && arg.ohneOutlook)){
        const json = path.join(ordner, 'entwurf.json'), ps1 = path.join(ordner, 'entwurf.ps1');
        fs.writeFileSync(json, JSON.stringify({ an, betreff, html: htmlAus(text), bild: bildPfad || '' }), 'utf8');
        fs.writeFileSync(ps1, '﻿' + PS, 'utf8');
        const r = await new Promise(res => execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', ps1, json], { windowsHide: true, timeout: 45000 },
          (err, out) => res(!err && /ok/.test(String(out || '')))));
        try{ fs.unlinkSync(json); }catch(x){}
        if(r) return { ok: true, weg: 'outlook' };
      }
      const datei = path.join(ordner, 'Anschreiben.eml');
      fs.writeFileSync(datei, eml(an, betreff, text, bildPfad, bildName, typ));
      const f = await shell.openPath(datei);
      if(f) return { ok: false, fehler: f };
      return { ok: true, weg: 'eml', datei };
    }catch(err){ return { ok: false, fehler: String(err.message || err) }; }
  });
};
module.exports._eml = eml;
