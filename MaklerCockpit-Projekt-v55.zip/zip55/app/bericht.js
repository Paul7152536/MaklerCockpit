// MaklerCockpit v24 – HTML (Eigentümerbericht, Briefing) im Hauptprozess zu PDF drucken.
// Eigenes, abgeschottetes Fenster: kein JavaScript, keine Netzwerkzugriffe, keine Navigation.
const { BrowserWindow, session } = require('electron');
const fs = require('fs');
const os = require('os');
const path = require('path');

module.exports = function berichtEinrichten(ipcMain){
  let ses = null;
  function sitzung(){
    if(ses) return ses;
    ses = session.fromPartition('mc-pdf');
    ses.webRequest.onBeforeRequest((d, cb) => cb({ cancel: !/^(file|data|about):/i.test(d.url) }));
    return ses;
  }
  ipcMain.handle('htmlZuPdf', async (e, html) => {
    let w = null, tmp = null;
    try{
      if(typeof html !== 'string' || !html.trim() || html.length > 8 * 1024 * 1024) return { ok: false, fehler: 'Ungültiger Inhalt für das PDF.' };
      tmp = path.join(os.tmpdir(), 'mc-bericht-' + process.pid + '-' + Date.now() + '.html');
      fs.writeFileSync(tmp, html, 'utf8');
      w = new BrowserWindow({ show: false, width: 900, height: 1270, webPreferences: { javascript: false, sandbox: true, contextIsolation: true, nodeIntegration: false, session: sitzung() } });
      w.webContents.on('will-navigate', ev => ev.preventDefault());
      w.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
      await w.loadFile(tmp);
      const buf = await w.webContents.printToPDF({ pageSize: 'A4', printBackground: true, preferCSSPageSize: true });
      return { ok: true, base64: Buffer.from(buf).toString('base64'), bytes: buf.length };
    }catch(err){ return { ok: false, fehler: String(err.message || err) }; }
    finally{
      try{ if(w && !w.isDestroyed()) w.destroy(); }catch(e2){}
      try{ if(tmp) fs.unlinkSync(tmp); }catch(e3){}
    }
  });
};
