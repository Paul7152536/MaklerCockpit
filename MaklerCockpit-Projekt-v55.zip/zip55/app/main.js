const { app, BrowserWindow, ipcMain, shell, Menu, dialog, clipboard } = require('electron');
const path = require('path');
const fs = require('fs');

app.setAppUserModelId('de.goerner.maklercockpit');
const ORDNER = path.join(app.getPath('documents'), 'MaklerCockpit');
const DATEI = path.join(ORDNER, 'daten.json');
const BACKUPS = path.join(ORDNER, 'backups');

function sicherstellen(){ fs.mkdirSync(BACKUPS, { recursive: true }); }

// v34: Datum nach deutscher Zeit (nicht UTC), nur gültige Daten sichern, auch bei tagelang laufendem Programm (stündliche Prüfung)
function heuteLokal(){ const d = new Date(); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }
function schreibeSicher(datei, text){ const tmp = datei + '.tmp'; fs.writeFileSync(tmp, text, 'utf8'); fs.renameSync(tmp, datei); }
function tagesBackup(){
  try{
    if(!fs.existsSync(DATEI)) return;
    const ziel = path.join(BACKUPS, 'daten-' + heuteLokal() + '.json');
    if(!fs.existsSync(ziel)){
      const text = fs.readFileSync(DATEI, 'utf8');
      try{ JSON.parse(text); }catch(e){ return; }          // beschädigte Datei nicht als Tagessicherung ablegen
      schreibeSicher(ziel, text);
    }
    const alle = fs.readdirSync(BACKUPS).filter(f=>/^daten-\d{4}-\d{2}-\d{2}\.json$/.test(f)).sort();
    while(alle.length > 60){ fs.unlinkSync(path.join(BACKUPS, alle.shift())); }
    // alte Sicherungen vor Importen / beschädigte Dateien: die letzten 10 behalten
    ['vor-import-', 'beschaedigt-'].forEach(vor => {
      const l = fs.readdirSync(BACKUPS).filter(f => f.startsWith(vor) && f.endsWith('.json')).sort();
      while(l.length > 10){ fs.unlinkSync(path.join(BACKUPS, l.shift())); }
    });
  }catch(e){ console.error('Backup', e); }
}
let ladeHinweis = null;

ipcMain.on('laden', (ev) => {
  try{
    sicherstellen();
    if(!fs.existsSync(DATEI)){ ev.returnValue = null; return; }
    try{ ev.returnValue = JSON.parse(fs.readFileSync(DATEI, 'utf8')); }
    catch(e){
      // beschädigt -> v34: Datei aufbewahren (wird sonst beim nächsten Speichern überschrieben), dann letzte gültige Sicherung
      let kopie = '';
      try{ kopie = 'beschaedigt-' + new Date().toISOString().replace(/[:.]/g, '-') + '.json'; fs.copyFileSync(DATEI, path.join(BACKUPS, kopie)); }catch(e3){ kopie = ''; }
      const alle = fs.readdirSync(BACKUPS).filter(f=>/^daten-\d{4}-\d{2}-\d{2}\.json$/.test(f)).sort().reverse();
      for(const f of alle){ try{ ev.returnValue = JSON.parse(fs.readFileSync(path.join(BACKUPS, f), 'utf8')); ladeHinweis = { sicherung: f, kopie }; return; }catch(e2){} }
      ladeHinweis = { sicherung: '', kopie };
      ev.returnValue = null;
    }
  }catch(e){ ev.returnValue = null; }
});

ipcMain.on('ladeHinweis', (ev) => { ev.returnValue = ladeHinweis; ladeHinweis = null; });
ipcMain.on('speichern', (ev, text) => {
  try{
    sicherstellen();
    const tmp = DATEI + '.tmp';
    fs.writeFileSync(tmp, text, 'utf8');
    fs.renameSync(tmp, DATEI);
    ev.returnValue = { ok: true };
  }catch(e){ ev.returnValue = { ok: false, fehler: String(e.message || e) }; }
});

ipcMain.on('sicherungSchreiben', (ev, name, text) => {
  try{
    sicherstellen();
    const datei = path.join(BACKUPS, String(name||'').replace(/[^\w.\-]/g,'_'));
    fs.writeFileSync(datei, String(text||''), 'utf8');
    ev.returnValue = { ok: true, datei };
  }catch(e){ ev.returnValue = { ok: false, fehler: String(e.message || e) }; }
});
ipcMain.on('sicherungLesen', (ev, name) => {
  try{ const datei = path.join(BACKUPS, String(name||'').replace(/[^\w.\-]/g,'_')); ev.returnValue = fs.existsSync(datei) ? fs.readFileSync(datei, 'utf8') : null; }
  catch(e){ ev.returnValue = null; }
});

ipcMain.on('importieren', (ev, text) => {
  try{
    let d = JSON.parse(text);
    if(d && d.db && typeof d.db === 'object' && !Array.isArray(d.db)) d = d.db;
    if(!d || typeof d !== 'object' || Array.isArray(d)) throw new Error('Datei enthält keine Cockpit-Daten');
    sicherstellen();
    if(fs.existsSync(DATEI)) fs.copyFileSync(DATEI, path.join(BACKUPS, 'vor-import-' + Date.now() + '.json'));
    schreibeSicher(DATEI, JSON.stringify(d));
    ev.returnValue = { ok: true, anzahl: Object.keys(d).map(k => k + ': ' + (Array.isArray(d[k]) ? d[k].length : '-')).join(', ') };
  }catch(e){ ev.returnValue = { ok: false, fehler: String(e.message || e) }; }
});


// ── KI (optional): Claude-API, nur wenn ein API-Key eingetragen ist ──
ipcMain.handle('claude', async (ev, key, body) => {
  try{
    const ctrl = new AbortController(); const t = setTimeout(() => ctrl.abort(), 300000);
    const r = await fetch('https://api.anthropic.com/v1/messages', { method:'POST', signal: ctrl.signal,
      headers:{ 'content-type':'application/json', 'x-api-key': String(key||''), 'anthropic-version':'2023-06-01' },
      body: JSON.stringify(body) });
    clearTimeout(t);
    let json = null; try{ json = await r.json(); }catch(e){}
    return { status: r.status, json };
  }catch(e){ return { fehler: e.name === 'AbortError' ? 'Zeitüberschreitung (5 Minuten)' : 'Keine Verbindung: ' + (e.message||e) }; }
});

// ── Nachrichten-Feeds (RSS) – ohne KI ──
ipcMain.handle('feed', async (ev, url) => {
  try{
    if(!/^https?:\/\//i.test(String(url))) return { ok:false, fehler:'ungültige Adresse' };
    const ctrl = new AbortController(); const t = setTimeout(() => ctrl.abort(), 20000);
    const r = await fetch(url, { signal: ctrl.signal, redirect:'follow', headers:{ 'user-agent':'MaklerCockpit-Feedleser/1 (persoenlich, selten)', 'accept':'application/rss+xml, application/atom+xml, application/xml, text/xml, text/html;q=0.8' } });
    clearTimeout(t);
    const buf = await r.arrayBuffer();
    if(buf.byteLength > 3000000) return { ok:false, fehler:'Feed zu groß' };
    const text = new TextDecoder('utf-8').decode(buf);
    return { ok: r.ok, status: r.status, text };
  }catch(e){ return { ok:false, fehler: e.name === 'AbortError' ? 'Zeitüberschreitung' : String(e.message||e) }; }
});


// ── Link-Check: Ist ein Inserat noch online? (normaler Seitenabruf wie ein Browser) ──
ipcMain.handle('seite', async (ev, url) => {
  try{
    if(!/^https?:\/\//i.test(String(url))) return { ok:false, fehler:'ungültige Adresse' };
    const ctrl = new AbortController(); const t = setTimeout(() => ctrl.abort(), 20000);
    const r = await fetch(url, { signal: ctrl.signal, redirect:'follow', headers:{ 'user-agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0 Safari/537.36', 'accept':'text/html,application/xhtml+xml', 'accept-language':'de-DE,de;q=0.9' } });
    clearTimeout(t);
    const buf = await r.arrayBuffer();
    const text = new TextDecoder('utf-8').decode(buf.byteLength > 1500000 ? buf.slice(0,1500000) : buf);
    return { ok: r.ok, status: r.status, url: r.url, text };
  }catch(e){ return { ok:false, fehler: e.name === 'AbortError' ? 'Zeitüberschreitung' : String(e.message||e) }; }
});


// ── Offene Daten abrufen (Adresssuche, Bodenrichtwerte) – mit eigener Kennung ──
ipcMain.handle('abruf', async (ev, url) => {
  try{
    if(!/^https:\/\/(nominatim\.openstreetmap\.org|gdi\.berlin\.de|ogc-api\.geobasis-bb\.de|isk\.geobasis-bb\.de)\//i.test(String(url))) return { ok:false, fehler:'Adresse nicht erlaubt' };
    const ctrl = new AbortController(); const t = setTimeout(() => ctrl.abort(), 25000);
    const r = await fetch(url, { signal: ctrl.signal, headers:{ 'user-agent':'MaklerCockpit/55 (Desktop-Programm, persoenliche Nutzung)', 'accept':'application/json, application/geo+json, */*;q=0.5', 'accept-language':'de' } });
    clearTimeout(t);
    const text = await r.text();
    return { ok: r.ok, status: r.status, text: text.length > 5000000 ? text.slice(0,5000000) : text };
  }catch(e){ return { ok:false, fehler: e.name === 'AbortError' ? 'Zeitüberschreitung' : String(e.message||e) }; }
});
ipcMain.handle('zwischenablage', () => { try{ const t = clipboard.readText(); return t.length > 400000 ? t.slice(0,400000) : t; }catch(e){ return ''; } });
ipcMain.on('fokus', () => { if(win){ if(win.isMinimized()) win.restore(); win.show(); win.focus(); } });
// v32: Mit Windows starten – Wahl liegt in pc-einstellungen.json (nur dieser PC), Standard: an, minimiert.
// Bei jedem Start zeigt der Windows-Autostart auf die gerade gestartete Version (neue exe → Eintrag wird umgestellt).
const PC_EINST = path.join(ORDNER, 'pc-einstellungen.json');
function pcEinst(){ try{ return JSON.parse(fs.readFileSync(PC_EINST, 'utf8')) || {}; }catch(e){ return {}; } }
function pcEinstSchreiben(e){ try{ sicherstellen(); fs.writeFileSync(PC_EINST, JSON.stringify(e, null, 1), 'utf8'); }catch(err){ console.error('pc-einstellungen', err); } }
function autostartPfad(){ return process.env.PORTABLE_EXECUTABLE_FILE || process.execPath; }
function autostartArgs(e){ return (e || pcEinst()).autostartMinimiert === false ? [] : ['--minimiert']; }
function autostartMoeglich(){ return app.isPackaged || !!process.env.MC_AUTOSTART_TEST; }
function autostartAn(){ try{ return autostartMoeglich() && app.getLoginItemSettings({ path: autostartPfad(), args: autostartArgs() }).openAtLogin; }catch(e){ return false; } }
function autostartSetzen(an, minimiert){
  const e = pcEinst(); e.autostart = !!an; if(minimiert !== undefined && minimiert !== null) e.autostartMinimiert = !!minimiert; pcEinstSchreiben(e);
  if(autostartMoeglich()){
    try{
      // alten Eintrag (andere Version / andere Startart) entfernen, dann neu eintragen
      app.setLoginItemSettings({ openAtLogin: false, path: autostartPfad(), args: ['--minimiert'] });
      app.setLoginItemSettings({ openAtLogin: false, path: autostartPfad(), args: [] });
      if(an) app.setLoginItemSettings({ openAtLogin: true, path: autostartPfad(), args: autostartArgs(e) });
    }catch(err){ console.error('Autostart', err); }
  }
  try{ menue(); }catch(err){}
  return autostartAn();
}
function autostartBeimStart(){
  const e = pcEinst();
  if(e.autostart === undefined){ e.autostart = true; e.autostartMinimiert = true; e.autostartNeu = true; pcEinstSchreiben(e); }
  if(e.autostart && autostartMoeglich() && !autostartAn()) autostartSetzen(true);
}
ipcMain.handle('autostart', (ev, an) => (an === undefined || an === null) ? autostartAn() : autostartSetzen(an));
ipcMain.handle('autostart2', (ev, w) => {
  if(w && w.gesehen){ const e = pcEinst(); delete e.autostartNeu; pcEinstSchreiben(e); }
  else if(w && w.an !== undefined) autostartSetzen(w.an, w.minimiert);
  const e = pcEinst();
  return { an: autostartAn(), gewaehlt: e.autostart !== false, minimiert: e.autostartMinimiert !== false, neu: !!e.autostartNeu, moeglich: autostartMoeglich(), datei: path.basename(autostartPfad()) };
});

ipcMain.on('ordner', () => { sicherstellen(); shell.openPath(ORDNER); });

// ── v20: Sicherung in einen Cloud-Ordner ──
require('./sicherung')(ipcMain, ORDNER, DATEI, () => win);
require('./webfenster')(ipcMain, () => win);
require('./mail')(ipcMain);   // v52: Anschreiben mit Bild-Anhang
require('./bericht')(ipcMain);   // v24: Bericht/Briefing als PDF
// ── v25: Abgleich-Stand dieses Geräts (nicht in daten.json, nicht in der Cloud-Sicherung) ──
const ABGLEICH_STAND = path.join(ORDNER, 'abgleich-stand.json');
ipcMain.on('abgleichStand', (ev, aktion, text) => {
  try{
    sicherstellen();
    if(aktion === 'lesen'){ ev.returnValue = fs.existsSync(ABGLEICH_STAND) ? fs.readFileSync(ABGLEICH_STAND, 'utf8') : null; return; }
    if(aktion === 'schreiben'){ const tmp = ABGLEICH_STAND + '.tmp'; fs.writeFileSync(tmp, String(text || ''), 'utf8'); fs.renameSync(tmp, ABGLEICH_STAND); ev.returnValue = { ok: true }; return; }
    if(aktion === 'loeschen'){ if(fs.existsSync(ABGLEICH_STAND)) fs.unlinkSync(ABGLEICH_STAND); ev.returnValue = { ok: true }; return; }
    ev.returnValue = null;
  }catch(e){ ev.returnValue = aktion === 'lesen' ? null : { ok: false, fehler: String(e.message || e) }; }
});

// ── v18: Unterlagen zu Objekten (Dokumente\MaklerCockpit\Unterlagen) ──
require('./dokumente')(ipcMain, ORDNER, () => win);

// ── v17: PDF speichern (aus allen Modulen, auch aus eingebetteten Fenstern) mit „Speichern unter“ ──
const gespeichertePdfs = new Set();
ipcMain.handle('dateiSpeichern', async (e, arg) => {
  try{
    let name = String((arg && arg.name) || 'Dokument.pdf').replace(/[\\/:*?"<>|\u0000-\u001f]+/g, '_').trim() || 'Dokument.pdf';
    if(!/\.pdf$/i.test(name)) name += '.pdf';
    const r = await dialog.showSaveDialog(win, { title: 'PDF speichern', defaultPath: path.join(app.getPath('downloads'), name), filters: [{ name: 'PDF', extensions: ['pdf'] }] });
    if(r.canceled || !r.filePath) return { ok: false, abgebrochen: true };
    const daten = Buffer.from(String((arg && arg.base64) || ''), 'base64');
    if(!daten.length || daten.slice(0, 4).toString() !== '%PDF') return { ok: false, fehler: 'Die PDF-Datei war leer oder beschädigt.' };
    fs.writeFileSync(r.filePath, daten);
    gespeichertePdfs.add(r.filePath);
    return { ok: true, pfad: r.filePath, name: path.basename(r.filePath) };
  }catch(err){ return { ok: false, fehler: String(err.message || err) }; }
});
ipcMain.on('dateiOeffnen', (e, pfad, art) => {
  if(!gespeichertePdfs.has(pfad)) return;
  if(art === 'ordner') shell.showItemInFolder(pfad); else shell.openPath(pfad);
});

// ── Google Kalender (v14/v15): Skript-Brücke oder Cloud-Anmeldung, Zugang verschlüsselt in google-konto.json ──
require('./google')(ipcMain, ORDNER, () => { if(win){ if(win.isMinimized()) win.restore(); win.show(); win.focus(); } });

let win;
function erstelleFenster(){
  win = new BrowserWindow({
    width: 1400, height: 900, minWidth: 900, minHeight: 600,
    backgroundColor: '#1a1c20', title: 'MaklerCockpit', icon: path.join(__dirname, 'icon.png'),
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false }
  });
  win.setMenuBarVisibility(true);
  win.webContents.setWindowOpenHandler(({ url }) => {
    if(/^(https?:|mailto:|tel:)/i.test(url)) shell.openExternal(url);
    return { action: 'deny' };
  });
  win.webContents.on('will-navigate', (e, url) => {
    if(!url.startsWith('file:')){ e.preventDefault(); if(/^(https?:|mailto:|tel:)/i.test(url)) shell.openExternal(url); }
    else if(!/\/index\.html(?:[?#].*)?$/i.test(url)) e.preventDefault();   // v21: hineingezogene Datei (PDF, Foto) nie anstelle des Programms öffnen
  });
  // Downloads ohne Dateinamen (z. B. aus eingebetteten Modulen) bekommen einen sinnvollen Namen
  win.webContents.session.on('will-download', (e, item) => {
    const n = item.getFilename() || '';
    if(!/\.[a-z0-9]{2,5}$/i.test(n) && /pdf/i.test(item.getMimeType() || '')){
      try{ item.setSaveDialogOptions({ title: 'PDF speichern', defaultPath: path.join(app.getPath('downloads'), 'Dokument.pdf'), filters: [{ name: 'PDF', extensions: ['pdf'] }] }); }catch(err){}
    }
  });
  // v34: stürzt die Programmoberfläche ab (z. B. zu wenig Speicher), lädt sie sich selbst neu – gespeicherte Daten bleiben
  let absturz = 0;
  win.webContents.on('render-process-gone', (e, d) => {
    if(!d || d.reason === 'clean-exit' || !win || win.isDestroyed()) return;
    console.error('Oberfläche abgestürzt:', d.reason);
    if(Date.now() - absturz < 15000) return;   // nicht in einer Schleife neu laden
    absturz = Date.now();
    setTimeout(() => { try{ if(win && !win.isDestroyed()) win.webContents.reload(); }catch(err){} }, 800);
  });
  win.loadFile(path.join(__dirname, 'index.html'));
  if(process.argv.includes('--minimiert')) win.once('ready-to-show', () => win.minimize());
}

function menue(){
  const vorlage = [
    { label: 'Datei', submenu: [
      { label: 'Datenordner öffnen', click: () => { sicherstellen(); shell.openPath(ORDNER); } },
      { label: 'Daten exportieren …', click: async () => {
          const r = await dialog.showSaveDialog(win, { defaultPath: 'MaklerCockpit-Export.json', filters: [{ name: 'JSON', extensions: ['json'] }] });
          if(!r.canceled && r.filePath){ try{ fs.copyFileSync(DATEI, r.filePath); }catch(e){ dialog.showErrorBox('Export', String(e.message||e)); } }
      } },
      { label: 'Daten importieren …', click: async () => {
          const r = await dialog.showOpenDialog(win, { filters: [{ name: 'JSON', extensions: ['json'] }], properties: ['openFile'] });
          if(r.canceled || !r.filePaths[0]) return;
          try{
            const inhalt = fs.readFileSync(r.filePaths[0], 'utf8'); JSON.parse(inhalt);
            const a = await dialog.showMessageBox(win, { type: 'warning', buttons: ['Importieren', 'Abbrechen'], defaultId: 1, cancelId: 1,
              message: 'Alle aktuellen Daten werden durch die importierte Datei ersetzt (ein Backup wird vorher angelegt). Fortfahren?' });
            if(a.response !== 0) return;
            sicherstellen();
            if(fs.existsSync(DATEI)) fs.copyFileSync(DATEI, path.join(BACKUPS, 'vor-import-' + Date.now() + '.json'));
            await win.webContents.executeJavaScript('window.__mcNichtSpeichern = true').catch(() => {});   // v25: alten Stand beim Neuladen nicht zurückschreiben
            schreibeSicher(DATEI, inhalt);
            win.webContents.reloadIgnoringCache();
          }catch(e){ dialog.showErrorBox('Import fehlgeschlagen', String(e.message||e)); }
      } },
      { type: 'separator' },
      { label: process.platform === 'darwin' ? 'Beim Anmelden starten' : 'Mit Windows starten', type: 'checkbox', checked: autostartAn(), click: (item) => autostartSetzen(item.checked) },
      { type: 'separator' }, { role: 'quit', label: 'Beenden' } ] },
    { label: 'Ansicht', submenu: [ { role: 'reload', label: 'Neu laden' }, { role: 'togglefullscreen', label: 'Vollbild' }, { role: 'zoomIn', label: 'Vergrößern' }, { role: 'zoomOut', label: 'Verkleinern' }, { role: 'resetZoom', label: 'Zoom zurücksetzen' } ] }
  ];
  if(process.platform === 'darwin'){   // Mac: App-Menü und Bearbeiten-Menü, sonst gehen ⌘C / ⌘V / ⌘A / ⌘Z in Eingabefeldern nicht
    vorlage.unshift({ label: 'MaklerCockpit', submenu: [ { role: 'about', label: 'Über MaklerCockpit' }, { type: 'separator' }, { role: 'hide', label: 'MaklerCockpit ausblenden' }, { role: 'hideOthers', label: 'Andere ausblenden' }, { role: 'unhide', label: 'Alle einblenden' }, { type: 'separator' }, { role: 'quit', label: 'MaklerCockpit beenden' } ] });
    vorlage.splice(2, 0, { label: 'Bearbeiten', submenu: [ { role: 'undo', label: 'Widerrufen' }, { role: 'redo', label: 'Wiederholen' }, { type: 'separator' }, { role: 'cut', label: 'Ausschneiden' }, { role: 'copy', label: 'Kopieren' }, { role: 'paste', label: 'Einsetzen' }, { role: 'selectAll', label: 'Alles auswählen' } ] });
    vorlage.push({ role: 'windowMenu', label: 'Fenster' });
  }
  Menu.setApplicationMenu(Menu.buildFromTemplate(vorlage));
}

if(!app.requestSingleInstanceLock()){ app.quit(); }
else {
  app.on('second-instance', () => { if(win){ if(win.isMinimized()) win.restore(); win.focus(); } });
  app.whenReady().then(() => {
    sicherstellen(); tagesBackup(); setInterval(tagesBackup, 60 * 60 * 1000); try{ autostartBeimStart(); }catch(e){ console.error('Autostart', e); } menue();
    // Kartenkacheln (OpenStreetMap): Programm-Kennung mitsenden, wie es die Nutzungsregeln verlangen
    try{ require('electron').session.defaultSession.webRequest.onBeforeSendHeaders({ urls: ['https://tile.openstreetmap.org/*'] }, (d, cb) => {
      d.requestHeaders['User-Agent'] = 'MaklerCockpit/55 (Desktop-Programm, Einzelnutzer)'; d.requestHeaders['Referer'] = 'https://maklercockpit.local/'; cb({ requestHeaders: d.requestHeaders }); }); }catch(e){}
    erstelleFenster();
  });
  app.on('window-all-closed', () => app.quit());
  app.on('activate', () => { if(app.isReady() && !BrowserWindow.getAllWindows().length) erstelleFenster(); });
}
