# Abnahmeprotokoll Mietrecht-Modul (MaklerCockpit PC v8)

Stand der Daten: 08.11.2026 · Prüfdatum im Test: 07.11.2026 (fest eingestellt)

**Prüfen:** `node mietrecht/test/abnahme.js` (Node.js ab Version 18). Mit einem neuen Mietspiegel oder neuen Verordnungen die Daten in `miete_daten.js` tauschen und den Test erneut laufen lassen – Abweichungen zeigen, welche Ergebnisse sich ändern.

**Zusätzlich geprüft:** 2.414 Zufallsfälle gegen das Python-Add-on `addon_miete.py` – ohne Abweichung, außer bei den bewusst korrigierten Stellen (Heizungs-Kappung innerhalb der 2-/3-€-Grenze, 7-€-Schwelle ohne Rundung).

## Ergebnis
```
✅ T01 Berlin 11/2026: Kappung 15 %
✅ T02 Potsdam: 15 % und Bremse
✅ T03 Rangsdorf: 20 %, keine Bremse
✅ T04 unbekannter Ort → prüfen
✅ T05 Berlin Kappung nach 10.05.2028 → prüfen
✅ T05b Regelwechsel zwischen Zugang und Wirkung erkannt
✅ T06 Feld 81, +1+1+1−1−1 → 7,75 / 465 €
✅ T07 5,90/7,30/9,55, −1−1 → 6,74 / 404,40 €
✅ T08 fünf + → Oberwert, fünf − → Unterwert
✅ T08b amtliches Beispiel 2024: 6,02/7,12/9,19, netto +1 → 7,53
✅ T09 Flächengrenze 59,99 / 60,00 → verschiedene Felder
✅ T10 Einfamilienhaus → außerhalb Mietspiegel
✅ T12 unklares Merkmal → Spanne
✅ T13 Vertrag 63 m², tatsächlich 60 m² → mit 60 gerechnet + Hinweis
✅ T14 Vergleichsmiete 465, Wunsch 550 → 511,50 / Differenz 38,50
✅ T15 Vormiete 570 → bis 570 €
✅ T16 Vormiete 570 mit 30 € vereinbarter Erhöhung → 540 €
✅ T18 Neubau ab 10/2014 → Ausnahme
✅ T20 Vergleichsmiete vor Maßnahme 800 €, Zuschlag 35 € → 915 €
✅ T22 400 → 440 Ist, 465 Vergleich → 460 (+20), Kappung bindet
✅ T23 800 → 880, 900 Vergleich → 900 (+20), Vergleichsmiete bindet
✅ T24 800 → 910 inkl. 30 € Modernisierung, 980 Vergleich → 950 (+40)
✅ T24b vereinbarter Modernisierungszuschlag zählt wie § 559
✅ T25 20-%-Gebiet: 800 → 880, 980 Vergleich → 960 (+80)
✅ T26 880 Ist, 870 Vergleich → keine Erhöhung
✅ T27 letzte Erhöhung 01.07.2026, Zugang 30.06.2027 → zu früh (Hinweis)
✅ T28 Zugang 01.07.2027 → wirksam 01.10.2027
✅ T29 Zugang 12.01.2027 → Zustimmung 31.03.2027, wirksam 01.04.2027, Fenster 01.04.2024
✅ T30 Zugang 02.02.2027 → wirksam 01.05.2027, Fenster 01.05.2024
✅ T32 kurzer Vertrag: Anfangsmiete ist Basis
✅ T33 Mietstand am Stichtag fehlt → vorläufig
✅ T35 Staffel/Index aktiv → § 558 gesperrt
✅ T37 Beginn 01.01.2027, Staffel 01.10.2027 → unter 1 Jahr
✅ T40 1.000 €, VPI 110 → 115,5, Zugang 12.01.2027 → 1.050 € ab 01.03.2027
✅ T41 VPI 120 → 114 → 950 €
✅ T43 790 €, 93,9 → 120,0 → 1.009,58 €
✅ T43b Schulung: 790 € Feb 2016 → Sep 2026 = 1.065,11 €
✅ T44 letzte Anpassung 01.06.2026 → frühestens 01.06.2027
✅ T47 50.000 − 10.000, 60 m², 600 € → 266,67 roh, 180 Rahmen, 780 €
✅ T48 frühere 60 € → Rest 120, 720 €
✅ T49 419,99 € → 120 € Rahmen, 420,00 € → 180 €
✅ T50 § 559c 10.000 € → 3.000 Pauschale, 46,67 €
✅ T51 § 559c mit 7.000 € früher → Restbudget 3.000 € vor neuer Maßnahme
✅ T53 Heizung 9.000, Förderung 3.000, 15 % → 4.650 Basis, 38,75 roh, 30 € Rahmen
✅ T54 Heizungsrahmen schon 18 € genutzt → 12 €
✅ T55 gemischt: Heizung 12 € Rest, Gesamt 50 € Rest → 12 + 38
✅ T55b Heizung im normalen § 559: nicht über 2/3-€-Grenze
✅ T56 Wärmepumpe ohne Nachweis → halbe Kosten
✅ T56b Wärmepumpe mit Ausnahme → volle Kosten
✅ T57 Zugang 12.01.2027 → wirksam 01.04.2027
✅ T58 angekündigt 100, tatsächlich 110 → 01.04.2027
✅ T59 angekündigt 100, tatsächlich 110,01 → 01.10.2027
✅ T60 zwei Verlängerungsgründe → nur einmal +6
✅ T62 § 561: Zugang Januar → Kündigung bis Ende März zum 31. Mai
✅ T64 Entwurf 20.000 € ändert nichts: 12.000 € vereinfacht → abgelehnt
✅ G1 Hoppegarten 2025 → 15 % + Bremse; 2026 → 20 %, keine
✅ G2 Berlin 15.06.2025 → Bremse (Übergangsverordnung)
✅ G3 Ludwigsfelde, Teltow-Fläming → Ludwigsfelde (nicht Teltow)
✅ G4 Potsdam-Mittelmark allein ist nicht Potsdam
✅ W1 § 193: Zustimmungsfrist am Sonntag → Montag
✅ L1 10 vs 11 €/m², Berlin: lohnt nur bis ca. 2 Monate (Recherche 2,0)
✅ L2 +5 %: unter 1 Monat
✅ L3 Vergleichsmiete steigt nicht: 7–8 Monate
✅ L4 20 % unter Vergleichsmiete gegen +10 %: ca. 12 Monate
✅ L5 Berlin, 5 Monate leer → Zweckentfremdungs-Warnung mit Bußgeld
✅ L6 Potsdam: Warnung erst über 6 Monate
✅ L7 Wunschmiete über Bremse → Warnung

67 bestanden, 0 fehlgeschlagen
```

## Dateien
- `miete_kern.js` – Rechenkern (Mietspiegel, § 558, Mietpreisbremse, §§ 559–559f, Index, Staffel, Vergleich, Gebiet)
- `miete_daten.js` – Daten: Mietspiegel 2026 (189 Felder), Orientierungshilfe, Verordnungen Berlin/Brandenburg 2020–2030, VPI bis 09/2026, Wissen, Quellen
- `miete_leerstand.js` – Leerstand-Rechner (Leer lassen oder sofort vermieten?), Ergebnisse L1–L4 decken sich mit der Modellrechnung der Recherche
- `ui5.js` – Oberfläche „🏠 Miete & Mietrecht“ in Jarvis
- `bau_daten.py`, `korr_bau.py` – erzeugen `miete_daten.js` aus den Add-on-Daten plus Korrekturen der Quellenprüfung

## Noch offen (fachlich)
- Die 189 Feldwerte sind aus dem Add-on übernommen; Stichproben passen, ein vollständiger Abgleich mit der amtlichen Tabelle 2026 steht aus.
- Wohnlage automatisch: Geodienst `wohnlagenadr2026` ist nicht bestätigt (Rückfall auf 2024 mit Hinweis).
- VPI Oktober 2026 erscheint am 11.11.2026 – im Programm unter „Indexmiete“ selbst nachtragen.
