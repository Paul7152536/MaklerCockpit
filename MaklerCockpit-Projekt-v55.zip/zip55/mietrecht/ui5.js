/* JARVIS im MaklerCockpit – Teil 5: Miete & Mietrecht (Berliner Mietspiegel 2026, § 558, Mietpreisbremse, Modernisierung, Index, Staffel, Betreten)
   Rechnet mit MR (miete_kern.js) und den Daten MR_DATEN. Rechenhilfe, keine Rechtsberatung. */
const MR_SUBS=[["vm","📊 Vergleichsmiete"],["me","📈 Mieterhöhung § 558"],["nv","🔑 Neuvermietung"],["mo","🛠️ Modernisierung"],["ix","📉 Indexmiete"],["st","🪜 Staffel prüfen"],["vs","⚖️ Standard · Index · Staffel"],["ls","⏳ Leer lassen oder sofort?"],["be","🚪 Betreten"],["ge","📍 Gebiet"],["wi","📚 Wissen"]];
const MR_HIST_ARTEN=[["beginn","Mietbeginn"],["558","Erhöhung § 558"],["vereinbarung","Vereinbarung"],["modernisierung","Modernisierung § 559"],["mod_vereinbart","Modernisierung (vereinbart)"],["index","Indexanpassung"],["staffel","Staffel"]];
const MR_GRUPPEN_NAMEN={bad:"Bad/WC",kueche:"Küche",wohnung:"Wohnung",gebaeude:"Gebäude",umfeld:"Wohnumfeld"};
let MR_LETZT=null;   // letztes Rechenergebnis der offenen Ansicht (für Entwurf, Termine, Speichern)

function mrS(){
  if(!S.miete||typeof S.miete!=="object") S.miete={};
  const m=S.miete;
  if(!m.sub||!MR_SUBS.some(x=>x[0]===m.sub)) m.sub="vm";
  m.w=m.w||{ort:"Berlin"}; m.w.merkmale=m.w.merkmale||{}; m.w.mk=m.w.mk||{};
  for(const k of ["me","nv","mo","ix","st","vs","be","ge","ls"]) if(!m[k]||typeof m[k]!=="object") m[k]={};
  if(!Array.isArray(m.me.historie)) m.me.historie=[];
  if(!Array.isArray(m.st.stufen)) m.st.stufen=[];
  if(!Array.isArray(m.be.termine)) m.be.termine=["","",""];
  m.vpi=m.vpi||{}; m.akten=Array.isArray(m.akten)?m.akten:[];
  return m;
}
try{ MR.setVpiExtra(mrS().vpi); }catch(e){}

// ── Eingaben ──
function mrGet(pfad){ return pfad.split(".").reduce((o,k)=>(o===null||o===undefined)?undefined:o[k], mrS()); }
function mrSet(pfad,wert){ const t=pfad.split("."); let o=mrS(); for(let i=0;i<t.length-1;i++){ if(o[t[i]]===null||typeof o[t[i]]!=="object") o[t[i]]={}; o=o[t[i]]; } o[t[t.length-1]]=wert; speichern(); }
function mrIn(el){ mrSet(el.dataset.mr, el.type==="checkbox"?el.checked:el.value); if(el.dataset.neu) mrNeu(); else mrErgebnis(); }
function mrNeu(){ const y=window.scrollY; renderMiete($("main")); window.scrollTo(0,y); }
function mrFeld(pfad,label,o){
  o=o||{}; const v=mrGet(pfad), typ=o.typ||"zahl", kl=o.kl?` class="${o.kl}"`:"", neu=o.neu?' data-neu="1"':"";
  const hilfe=o.hilfe?` <span title="${esc(o.hilfe)}" style="cursor:help;color:var(--blue);">ⓘ</span>`:"";
  if(typ==="select") return `<div${kl}><label>${label}${hilfe}</label><select data-mr="${pfad}" onchange="mrIn(this)"${neu}>${o.optionen.map(([k,l])=>`<option value="${esc(k)}" ${String(v===undefined||v===null?(o.std||""):v)===String(k)?"selected":""}>${esc(l)}</option>`).join("")}</select></div>`;
  if(typ==="check") return `<div${kl} style="display:flex;align-items:flex-end;"><label class="flex" style="margin:0 0 7px;"><input type="checkbox" data-mr="${pfad}" onchange="mrIn(this)" ${v?"checked":""}${neu}>${label}${hilfe}</label></div>`;
  const art = typ==="date"?'type="date"':typ==="month"?'type="month"':typ==="text"?'type="text"':'type="text" inputmode="decimal"';
  return `<div${kl}><label>${label}${hilfe}</label><input ${art} data-mr="${pfad}" value="${esc(v===undefined||v===null?"":v)}" placeholder="${esc(o.ph||"")}" ${typ==="date"||typ==="month"?'onchange="mrIn(this)"':""} oninput="mrIn(this)"${neu}></div>`;
}
const mrBox=(l,w,s,kl)=>`<div class="wert-box"><div class="l">${l}</div><div class="w ${kl||""}">${w}</div>${s?`<div class="hinweis" style="margin-top:2px;">${s}</div>`:""}</div>`;
const mrFehlerHtml=t=>`<div class="karte" style="border-left:3px solid var(--yellow);"><div class="warn" style="font-weight:700;margin-bottom:4px;">ℹ️ Noch nicht berechenbar</div><div>${esc(t)}</div></div>`;
const mrHinweise=l=>l&&l.length?`<ul class="liste-hinweise hinweis">${l.map(x=>`<li>${esc(x)}</li>`).join("")}</ul>`:"";
const mrE=x=>MR.e(x), mrQ=x=>MR.q(x), mrP=(x,n)=>MR.p(x,n), mrD=d=>MR.de(d);

// ── Wohnung (gemeinsame Daten aller Rechner) ──
function mrOst(){ const v=mrS().w.ostwest; return v==="ost"?true:v==="west"?false:undefined; }
function mrBasis(){
  const w=mrS().w;
  const merk={}; for(const g of MR.GRUPPEN) merk[g]=w.merkmale[g]||"";
  return {flaeche:w.flaeche, baujahr:w.baujahr, wohnlage:w.wohnlage, ort:w.ort||w.adresse||"", ost:mrOst(), wendewohnung:!!w.wendewohnung,
    minderausstattung:!!w.minderausstattung, gebaeudeart:w.efh?"Einfamilienhaus":"", merkmale:merk, mieter:w.mieter||"", adresse:w.adresse||"", merkmale_offen:mrMerkmaleOffen()};
}
function mrMerkmaleOffen(){ const w=mrS().w; return MR.GRUPPEN.filter(g=>w.mk[g]&&w.mk[g].offen); }
function mrObjekt(id){
  const o=cockpit.objekte().find(x=>String(x.id)===String(id)); if(!o) return;
  const w=mrS().w; w.objektId=o.id; if(o.adresse) w.adresse=o.adresse; if(o.ort) w.ort=o.ort;
  const fl=F(o.wohnflaeche); if(fl) w.flaeche=String(fl).replace(".",","); if(o.baujahr) w.baujahr=String(o.baujahr);
  speichern(); mrNeu(); toast("Objekt übernommen – bitte Wohnlage und Ausstattung prüfen");
}
function mrMerkmalHaken(g,seite,i,an){
  const w=mrS().w; const mk=w.mk[g]=w.mk[g]||{n:[],p:[]}; mk.n=mk.n||[]; mk.p=mk.p||[];
  const l=mk[seite]; const pos=l.indexOf(i); if(an&&pos<0) l.push(i); if(!an&&pos>=0) l.splice(pos,1);
  const M=MR_DATEN.mietspiegel.merkmale[g]; const gew=(txt)=>{ const m=/zählt als (\d)/.exec(txt||""); return m?+m[1]:1; };
  const np=mk.p.reduce((s,k)=>s+gew(M[2][k]),0), nn=mk.n.reduce((s,k)=>s+gew(M[1][k]),0);
  const wert = np>nn?"+":nn>np?"-":"0";
  w.merkmale[g]=(mk.p.length||mk.n.length)?wert:(w.merkmale[g]||"");
  const sel=document.querySelector(`[data-mr="w.merkmale.${g}"]`); if(sel) sel.value=w.merkmale[g];
  speichern(); mrErgebnis();
}
function mrMerkmaleHtml(){
  const w=mrS().w, M=MR_DATEN.mietspiegel.merkmale;
  return MR.GRUPPEN.map(g=>{
    const [name,minus,plus]=M[g]; const mk=w.mk[g]||{n:[],p:[]};
    const liste=(arr,seite,zeichen)=>arr.map((t,i)=>`<label class="flex klein" style="margin:3px 0;align-items:flex-start;"><input type="checkbox" ${(mk[seite]||[]).includes(i)?"checked":""} onchange="mrMerkmalHaken('${g}','${seite}',${i},this.checked)">${zeichen} ${esc(t)}</label>`).join("");
    return `<div style="border-top:1px solid var(--border);padding:8px 0;">
      <div class="flex"><b style="min-width:92px;">${esc(name)}</b>
        <select data-mr="w.merkmale.${g}" onchange="mrIn(this)" style="width:auto;">${[["","±0 (neutral)"],["+","+ positiv überwiegt"],["-","− negativ überwiegt"],["0","±0 ausgeglichen"]].map(([k,l])=>`<option value="${k}" ${String(w.merkmale[g]||"")===k?"selected":""}>${l}</option>`).join("")}</select>
        <label class="flex klein" title="Ein Merkmal ist unklar – Ergebnis wird als Spanne gezeigt"><input type="checkbox" ${mk.offen?"checked":""} onchange="mrMkOffen('${g}',this.checked)">unklar</label>
      </div>
      <details style="margin-top:4px;"><summary class="hinweis" style="cursor:pointer;">Merkmale ankreuzen (${(mk.n||[]).length} − / ${(mk.p||[]).length} +)</summary>
        <div class="grid g2" style="gap:6px 14px;margin-top:6px;"><div>${liste(minus,"n","➖")}</div><div>${liste(plus,"p","➕")}</div></div></details>
    </div>`;
  }).join("")+`<div class="hinweis" style="margin-top:6px;">Orientierungshilfe zur Spanneneinordnung: je Gruppe ±20 % der Spanne (Mittelwert→Ober- bzw. Unterwert), Gruppen werden verrechnet. Vom Mieter selbst geschaffene Ausstattung zählt nicht mit. Energie: nur EINE Stufe ankreuzen (zählt 1/2/3), entweder Kennwert oder Dämmung/Heizung; bei Bedarfsausweis Grenzen +20 %, ohne Warmwasser im Kennwert +20 kWh/(m²a) aufschlagen; Denkmalschutz: keine energetischen Negativmerkmale. Die Orientierungshilfe ist nicht Teil des qualifizierten Mietspiegels.</div>`;
}
function mrMkOffen(g,an){ const w=mrS().w; w.mk[g]=w.mk[g]||{n:[],p:[]}; w.mk[g].offen=an; speichern(); mrErgebnis(); }
function mrWohnungHtml(){
  const w=mrS().w, obj=cockpit.objekte();
  const mkAnz=MR.GRUPPEN.filter(g=>w.merkmale[g]&&w.merkmale[g]!=="0").length;
  return `<div class="karte">
    <h2>🏢 Wohnung <span class="rechts flex"><button class="ghost mini" onclick="mrBeispiel()" title="Beispieldaten ohne echte Mieter">🧪 Beispiel</button><button class="ghost mini" onclick="mrLeeren()">Leeren</button></span></h2>
    ${obj.length?`<div style="margin-bottom:10px;"><label>Aus dem Cockpit übernehmen</label><select onchange="mrObjekt(this.value)"><option value="">– Objekt wählen –</option>${obj.map(o=>`<option value="${esc(o.id)}" ${String(w.objektId)===String(o.id)?"selected":""}>${esc([o.adresse,o.ort].filter(Boolean).join(", ")||"(ohne Adresse)")}${o.wohnflaeche?" · "+esc(o.wohnflaeche)+" m²":""}</option>`).join("")}</select></div>`:""}
    <div class="felder">
      ${mrFeld("w.adresse","Adresse",{typ:"text",kl:"halb",ph:"Straße Nr."})}
      ${mrFeld("w.ort","Ort / Bezirk",{typ:"text",ph:"Berlin-Pankow, Potsdam …",hilfe:"Für Kappungsgrenze und Mietpreisbremse. Berlin + 36 Brandenburger Gemeinden sind hinterlegt."})}
      ${mrFeld("w.mieter","Mieter (für Entwürfe)",{typ:"text",ph:"Frau/Herr …"})}
      ${mrFeld("w.flaeche","Wohnfläche m²",{hilfe:"Tatsächliche Wohnfläche – sie zählt bei der Mieterhöhung, nicht die Vertragsangabe."})}
      ${mrFeld("w.flaeche_vertrag","Fläche laut Vertrag",{ph:"nur falls anders"})}
      ${mrFeld("w.baujahr","Baujahr (bezugsfertig)")}
      ${mrFeld("w.wohnlage","Wohnlage",{typ:"select",optionen:[["","– wählen –"],["einfach","einfach"],["mittel","mittel"],["gut","gut"]]})}
      ${mrFeld("w.ostwest","Ost/West",{typ:"select",optionen:[["","automatisch"],["ost","Ost"],["west","West"]],hilfe:"Nur für Baujahre 1973–1990 nötig (Bezirk vor 2001). Wird aus dem Ort erkannt."})}
      ${mrFeld("w.wendewohnung","Wendewohnung",{typ:"check",hilfe:"Ost, 1991–2001 bezugsfertig, aber noch zu DDR-Zeiten geplant"})}
      ${mrFeld("w.minderausstattung","ohne Heizung/Bad",{typ:"check",hilfe:"Sammelheizung und/oder Bad fehlen (nur Baujahr bis 1949: Abschlag 0,33 €/m²)"})}
      ${mrFeld("w.efh","Ein-/Zweifamilienhaus",{typ:"check",hilfe:"Ein-/Zweifamilien- und Reihenhäuser fallen nicht unter den Mietspiegel"})}
    </div>
    <div class="flex" style="flex-wrap:wrap;margin-top:10px;">
      ${HOST&&HOST.abruf?`<button class="sec mini" onclick="mrWohnlageAuto()" title="Adresse → Straßenverzeichnis (Geodienst Berlin), experimentell">🛰️ Wohnlage automatisch</button>`:""}
      <button class="sec mini" onclick="mrWohnlageSuchen()">🔎 Wohnlage nachschlagen</button>
      ${mrS().w.wohnlage_quelle?`<span class="badge" title="${esc(mrS().w.wohnlage_quelle)}">Wohnlage: ${esc(mrS().w.wohnlage_quelle).slice(0,40)}</span>`:""}
      <span class="hinweis" id="mrGebietKurz"></span>
    </div>
    <details style="margin-top:10px;" ${mkAnz?"":""}><summary style="cursor:pointer;font-weight:700;">🧾 Ausstattung einordnen (Orientierungshilfe) ${mkAnz?`<span class="badge b-orange">${mkAnz} Gruppe(n) gesetzt</span>`:'<span class="badge">alles neutral</span>'}</summary>
      <div style="margin-top:8px;">${mrMerkmaleHtml()}</div></details>
  </div>`;
}
function mrWohnlageSuchen(){
  const w=mrS().w; const a=[w.adresse,w.ort].filter(Boolean).join(", ");
  if(a) kopieren(a,"Adresse kopiert – im Mietspiegel-Abfrageformular einfügen");
  oeffneLink("https://mietspiegel.berlin.de/");
}
function mrLeeren(){ if(!confirm("Alle Eingaben im Mietrechner leeren? Gespeicherte Berechnungen bleiben.")) return; const m=mrS(); const akten=m.akten, vpi=m.vpi, sub=m.sub; S.miete={sub,akten,vpi}; mrS(); speichern(); mrNeu(); }
function mrBeispiel(){
  const m=mrS();
  m.w={ort:"Berlin-Lichtenberg",adresse:"Beispielstraße 1",mieter:"Frau Muster",flaeche:"58",baujahr:"1912",wohnlage:"mittel",ostwest:"",merkmale:{bad:"+",kueche:"",wohnung:"+",gebaeude:"-",umfeld:""},mk:{}};
  m.me={miete:"470",mietart:"standard",letzte_erhoehung_ab:"2024-03-01",miete_vorher:"430",mietbeginn:"2019-01-01",historie:[]};
  m.nv={miete:"620",vormiete:"",modernisierung_umlage:""};
  m.mo={kosten:"14000",erhaltung:"4000",verfahren:"normal"};
  m.ix={miete:"790",basis_monat:"2016-02"};
  m.st={stufen:[{ab:"2027-01-01",miete:"560"},{ab:"2028-01-01",miete:"575"},{ab:"2029-01-01",miete:"590"}],ovm_wachstum:"2"};
  m.vs={miete:"560",jahre:"10"};
  speichern(); mrNeu(); toast("🧪 Beispieldaten geladen (keine echten Personen)");
}

// ── Gebiet kurz ──
function mrGebietKurz(){
  const el=$("mrGebietKurz"); if(!el) return;
  const w=mrS().w; const ort=w.ort||w.adresse||"";
  if(!ort.trim()){ el.innerHTML="📍 Ort eintragen – Berlin wird angenommen."; return; }
  const g=MR.gebiet(ort);
  if(!g.bekannt){ el.innerHTML=`📍 <b>${esc(ort)}</b>: nicht in den hinterlegten Verordnungen → Kappung 20 %, keine Mietpreisbremse <span class="warn">(Landesrecht prüfen)</span>`; return; }
  el.innerHTML=`📍 <b>${esc(g.ort)}</b> (${g.land}): Kappung <b>${g.kappung} %</b> · Mietpreisbremse <b>${g.bremse?"ja":"nein"}</b>${g.status==="pruefen"?' <span class="warn">· Rechtsstand prüfen</span>':""}${(g.hinweise||[]).length?` <span title="${esc(g.hinweise.join(" "))}" style="cursor:help;color:var(--blue);">ⓘ</span>`:""}`;
}

// ── Ansicht ──
function renderMiete(main){
  const m=mrS();
  main.innerHTML=`
  <div class="karte akzent" style="margin-bottom:14px;">
    <div class="flex" style="flex-wrap:wrap;"><h2 style="margin:0;">🏠 Miete & Mietrecht</h2><span class="hinweis">Berlin & Brandenburg · ${esc(MR_DATEN.mietspiegel.name)} · Rechtsstand ${esc(MR_DATEN.stand)}</span><span class="spacer"></span>
      ${m.akten.length?`<button class="sec mini" onclick="mrAktenZeigen()">📁 Gespeichert (${m.akten.length})</button>`:""}</div>
    <div class="flex" style="flex-wrap:wrap;gap:6px;margin-top:10px;">${MR_SUBS.map(([k,l])=>`<button class="${m.sub===k?"":"sec"} mini" onclick="mrSub('${k}')">${l}</button>`).join("")}</div>
  </div>
  ${["wi","ge","be"].includes(m.sub)?"":mrWohnungHtml()}
  <div class="grid g2" style="margin-top:14px;align-items:start;">
    <div class="karte" id="mrForm">${mrFormHtml(m.sub)}</div>
    <div id="mrErg"></div>
  </div>
  <div class="hinweis" style="margin-top:14px;">⚖️ ${esc(MR_DATEN.hinweis)} Ergebnisse vor dem Versand prüfen – im Zweifel Mieterverein, Haus & Grund oder Anwalt.</div>`;
  mrErgebnis();
}
function mrSub(k){ mrS().sub=k; speichern(); renderMiete($("main")); window.scrollTo(0,0); }

function mrFormHtml(sub){
  const m=mrS();
  if(sub==="vm") return `<h2>📊 Ortsübliche Vergleichsmiete</h2><div class="hinweis">Aus Baujahr, Wohnlage, Fläche und Ausstattung (oben) – nach dem ${esc(MR_DATEN.mietspiegel.name)} (qualifiziert, in Kraft seit ${esc(MR_DATEN.mietspiegel.in_kraft)}, Stichtag ${esc(MR_DATEN.mietspiegel.stichtag)}).</div>
    <div class="felder" style="margin-top:10px;">${mrFeld("vm_vergleich","Aktuelle Miete (zum Vergleich)",{ph:"€ nettokalt"})}</div>
    <div class="hinweis" style="margin-top:10px;">Nicht erfasst: Ein-/Zweifamilien- und Reihenhäuser, ab 01.01.2025 bezugsfertige Wohnungen, preisgebundener Wohnraum, WC außerhalb der Wohnung. Für Brandenburg (z. B. Potsdam) gilt der dortige Mietspiegel – Vergleichsmiete dann in den Rechnern von Hand eintragen.</div>`;
  if(sub==="me"){ const me=m.me; return `<h2>📈 Mieterhöhung bis zur Vergleichsmiete (§ 558 BGB)</h2>
    <div class="felder">
      ${mrFeld("me.miete","Aktuelle Nettokaltmiete €")}
      ${mrFeld("me.mietart","Mietart",{typ:"select",optionen:[["standard","normal (ohne Staffel/Index)"],["staffel","Staffelmiete läuft"],["index","Indexmiete"]]})}
      ${mrFeld("me.letzte_erhoehung_ab","Letzte Erhöhung gilt seit",{typ:"date",hilfe:"Datum, ab dem die aktuelle Miete gilt. Modernisierungs- und Betriebskostenerhöhungen zählen hier nicht."})}
      ${mrFeld("me.miete_vorher","Miete davor €",{hilfe:"Für die Kappungsgrenze (Miete vor 3 Jahren)"})}
      ${mrFeld("me.mietbeginn","Mietbeginn",{typ:"date"})}
      ${mrFeld("me.anfangsmiete","Anfangsmiete €",{ph:"falls bekannt"})}
      ${mrFeld("me.zugang","Zugang beim Mieter am",{typ:"date",hilfe:"Wann das Schreiben ankommt (leer = heute). Alle Fristen rechnen ab Zugang."})}
      ${mrFeld("me.ovm_qm","Vergleichsmiete €/m² (von Hand)",{ph:"leer = Mietspiegel",hilfe:"Für Brandenburg oder wenn ein Gutachten/Vergleichswohnungen vorliegen"})}
      ${mrFeld("me.kappung_prozent","Kappung % (von Hand)",{ph:"leer = automatisch"})}
      ${mrFeld("me.hist_an","Mietverlauf genau erfassen",{typ:"check",neu:true,hilfe:"Für mehrere Erhöhungen, Modernisierungszuschläge im 3-Jahres-Fenster usw."})}
    </div>
    ${me.hist_an?mrHistorieHtml():""}`; }
  if(sub==="nv") return `<h2>🔑 Neuvermietung – Mietpreisbremse (§§ 556d–556g BGB)</h2>
    <div class="felder">
      ${mrFeld("nv.miete","Wunschmiete € nettokalt")}
      ${mrFeld("nv.ovm_qm","Vergleichsmiete €/m² (von Hand)",{ph:"leer = Mietspiegel"})}
      ${mrFeld("nv.vormiete","Vormiete € nettokalt",{hilfe:"Miete des Vormieters (§ 556e Abs. 1) – Nachweis nötig"})}
      ${mrFeld("nv.vormiete_erhoehung_letztes_jahr","davon im letzten Jahr vereinbart €",{hilfe:"Nur Erhöhungen, die im letzten Jahr vor Ende des Vormietverhältnisses VEREINBART wurden, zählen nicht (z. B. nach § 557). Mietminderungen bleiben außer Betracht – Vormiete ungemindert eintragen."})}
      ${mrFeld("nv.mietbeginn","Geplanter Mietbeginn",{typ:"date",hilfe:"Für den Rechtsstand der Mietpreisbremse (leer = heute)"})}
      ${mrFeld("nv.modernisierung_umlage","Modernisierungszuschlag €/Monat",{neu:true,hilfe:"Modernisierung in den letzten 3 Jahren vor Mietbeginn (§ 556e Abs. 2): fiktive Umlage nach § 559"})}
      ${F(m.nv.modernisierung_umlage)?mrFeld("nv.ovm_vor_mod_qm","Vergleichsmiete VOR Modernisierung €/m²",{hilfe:"§ 556e Abs. 2: Vergleichsmiete der Wohnung ohne die Modernisierung – sonst zählt sie doppelt"}):""}
      ${mrFeld("nv.moebliert_zuschlag","Möblierungszuschlag €",{ph:"optional"})}
      ${mrFeld("nv.neubau_ab_2014","Erstbezug nach 01.10.2014",{typ:"check",hilfe:"Erste Nutzung und erste Vermietung nach dem 01.10.2014 (§ 556f S. 1)"})}
      ${mrFeld("nv.umfassend_modernisiert","Erste Vermietung nach umfassender Modernisierung",{typ:"check",hilfe:"Aufwand ca. 1/3 eines Neubaus, Wohnung wie Neubau – Nachweise nötig (§ 556f S. 2)"})}
      ${mrFeld("nv.auskunft","Ausnahme vorher in Textform mitgeteilt",{typ:"check",hilfe:"§ 556g Abs. 1a: vor Abgabe der Vertragserklärung des Mieters unaufgefordert in Textform"})}
    </div>`;
  if(sub==="mo") return `<h2>🛠️ Modernisierungsumlage (§§ 559–559f BGB)</h2>
    <div class="felder">
      ${mrFeld("mo.kosten","Kosten für diese Wohnung €",{hilfe:"Bei mehreren Wohnungen: Anteil dieser Wohnung (z. B. nach Fläche)"})}
      ${mrFeld("mo.verfahren","Verfahren",{typ:"select",neu:true,optionen:[["normal","normal (§ 559, 8 %)"],["vereinfacht","vereinfacht (§ 559c, bis 10.000 €)"],["heizung","Heizung mit Förderung (§ 559e, 10 %)"]]})}
      ${(m.mo.verfahren||"normal")==="normal"?mrFeld("mo.erhaltung","Erhaltungsanteil €",{hilfe:"Kosten, die für eine Reparatur ohnehin angefallen wären (z. B. alte Fenster) – abziehen"})+mrFeld("mo.erhaltung_prozent","oder Erhaltung %"):""}
      ${mrFeld("mo.foerderung","Förderung/Zuschüsse €")}
      ${mrFeld("mo.miete","Miete vor der Erhöhung €",{ph:m.me.miete?"aus Mieterhöhung: "+m.me.miete:""})}
      ${mrFeld("mo.fruehere_mod_eur_6j","Frühere Umlagen in 6 J. €/Monat",{hilfe:"Schon genutzte Modernisierungserhöhungen der letzten 6 Jahre (nicht § 558/§ 560)"})}
      ${(m.mo.verfahren==="vereinfacht")?mrFeld("mo.fruehere_kosten_5j","Frühere Kosten § 559c in 5 J. €"):""}
      ${mrFeld("mo.zugang","Zugang der Erhöhungserklärung",{typ:"date"})}
      ${mrFeld("mo.angekuendigt","Ordnungsgemäß angekündigt?",{typ:"select",optionen:[["ja","ja (§ 555c)"],["nein","nein / fehlerhaft"]]})}
      ${mrFeld("mo.angekuendigter_betrag","Angekündigte Erhöhung €/Monat",{ph:"optional"})}
      ${mrFeld("mo.heizung","Maßnahme betrifft die Heizung",{typ:"check",neu:true,hilfe:"Neue Heizungsanlage (§ 555b Nr. 1a): dafür höchstens 0,50 €/m² in 6 Jahren – innerhalb der 2-/3-€-Grenze"})}
      ${(m.mo.heizung||m.mo.verfahren==="heizung")?mrFeld("mo.kosten_heizung","davon Heizungskosten €",{ph:"leer = alles Heizung"})+mrFeld("mo.fruehere_heiz_eur_6j","Frühere Heizungsumlage 6 J. €/Monat"):""}
      ${m.mo.verfahren==="heizung"?mrFeld("mo.ohne_pauschale","Anlage nach § 43 GModG (keine 15-%-Pauschale)",{typ:"check",neu:true,hilfe:"Seit 29.07.2026 gilt die 15-%-Pauschale nicht für Anlagen nach § 43 GModG – dann tatsächlichen Erhaltungsanteil eintragen"})+(m.mo.ohne_pauschale?mrFeld("mo.erhaltung","Erhaltungsanteil €"):""):""}
      ${mrFeld("mo.waermepumpe","Wärmepumpe",{typ:"check",neu:true})}
      ${m.mo.waermepumpe?mrFeld("mo.jaz_nachweis","JAZ ≥ 2,5 nachgewiesen",{typ:"check",hilfe:"Nachweis der Jahresarbeitszahl durch den Fachbetrieb (§ 559f)"})+mrFeld("mo.wp_ausnahme","Ausnahme greift",{typ:"check",hilfe:"Kein Nachweis nötig: Gebäude nach 1996 fertig, Wärmeschutz nach WSchV 1994, saniert nach GModG oder Vorlauftemperatur höchstens 55 °C"}):""}
    </div>`;
  if(sub==="ix") return `<h2>📉 Indexmiete (§ 557b BGB)</h2>
    <div class="felder">
      ${mrFeld("ix.miete","Aktuelle Nettokaltmiete €")}
      ${mrFeld("ix.basis_monat","Indexmonat der letzten Anpassung",{typ:"month",hilfe:"Monat laut Vertrag bzw. letzter Anpassung"})}
      ${mrFeld("ix.basis_index","oder Indexwert alt",{ph:"z. B. 93,9"})}
      ${mrFeld("ix.neu_monat","Neuer Indexmonat",{typ:"month",ph:"leer = neuester"})}
      ${mrFeld("ix.neu_index","oder Indexwert neu",{ph:"optional"})}
      ${mrFeld("ix.letzte_anpassung","Letzte Anpassung gilt seit",{typ:"date",hilfe:"Die Miete muss mindestens 1 Jahr unverändert bleiben"})}
      ${mrFeld("ix.zugang","Zugang der Erklärung",{typ:"date"})}
    </div>
    ${mrVpiHtml()}`;
  if(sub==="st") return `<h2>🪜 Staffelmiete prüfen (§ 557a BGB)</h2>
    <div class="hinweis">Staffeln immer in € (nicht in %), jede mindestens 1 Jahr. Erste Zeile = Mietbeginn mit Anfangsmiete.</div>
    ${mrStufenHtml()}
    <div class="felder" style="margin-top:10px;">
      ${mrFeld("st.ovm_qm","Vergleichsmiete €/m² heute",{ph:"leer = Mietspiegel"})}
      ${mrFeld("st.ovm_wachstum","Annahme Anstieg Vergleichsmiete % p. a.",{ph:"0"})}
      ${mrFeld("st.neubau_ab_2014","Erstbezug nach 01.10.2014",{typ:"check"})}
    </div>`;
  if(sub==="vs") return `<h2>⚖️ Standard · Index · Staffel im Vergleich</h2>
    <div class="felder">
      ${mrFeld("vs.miete","Startmiete € nettokalt")}
      ${mrFeld("vs.jahre","Jahre",{ph:"10"})}
      ${mrFeld("vs.ovm_qm","Vergleichsmiete €/m²",{ph:"leer = Mietspiegel"})}
      ${mrFeld("vs.inflation","Inflation % p. a.",{ph:"2,5"})}
      ${mrFeld("vs.ovm_wachstum","Mietspiegel-Anstieg % p. a.",{ph:"3"})}
      ${mrFeld("vs.staffel_prozent","Staffel % p. a.",{ph:"3"})}
      ${mrFeld("vs.neubau_ab_2014","Erstbezug nach 01.10.2014",{typ:"check"})}
    </div><div class="hinweis" style="margin-top:8px;">Szenario mit Annahmen – keine Prognose. Index: jährliche Anpassung mit der Inflation. Standard: alle 15 Monate bis zur Vergleichsmiete, höchstens Kappung. Staffel: jährlich +x % vom Start, je Staffel höchstens Vergleichsmiete + 10 %.</div>`;
  if(sub==="ls"){ const L=MR_DATEN.leerstand||{}; return `<h2>⏳ Leer lassen für mehr Miete – oder sofort vermieten?</h2>
    <div class="hinweis">Vergleicht zwei Wege über die Jahre – mit späteren Erhöhungen nach § 558 (Kappung, Vergleichsmiete), Mieterwechseln, Leerkosten, Ausfallrisiko, Steuer und Abzinsung.</div>
    <div class="felder" style="margin-top:10px;">
      ${mrFeld("ls.miete_sofort","A: Miete bei sofortiger Vermietung €",{hilfe:"Nettokalt, die du sofort bekommst"})}
      ${mrFeld("ls.miete_spaeter","B: Wunschmiete nach Leerstand €")}
      ${mrFeld("ls.leer_monate","B: zusätzliche Leermonate",{hilfe:"Monate, die du länger wartest als bei A"})}
      ${mrFeld("ls.leerkosten","Leerkosten €/Monat",{ph:"≈ "+MR.zahl(L.leerkosten_qm||2.68,2)+" €/m² = "+(F(m.w.flaeche)?MR.zahl((L.leerkosten_qm||2.68)*F(m.w.flaeche),0)+" €":"…"),hilfe:"Kosten, die du bei Leerstand selbst trägst: Betriebskosten/Hausgeld, Grundsteuer, Heizung-Grundlast, Versicherung"})}
      ${mrFeld("ls.einmalkosten","B: einmalige Zusatzkosten €",{ph:"z. B. Inserate"})}
      ${mrFeld("ls.jahre","Betrachtung Jahre",{ph:String(L.jahre||10)})}
      ${mrFeld("ls.ovm_qm","Vergleichsmiete €/m²",{ph:"leer = Mietspiegel"})}
      ${mrFeld("ls.ovm_wachstum","Anstieg Vergleichsmiete % p. a.",{ph:MR.zahl(L.ovm_wachstum||3.4,1),hilfe:"Berlin: Mietspiegel 2024→2026 ≈ +3,4 % p. a.; neuer Mietspiegel alle 2 Jahre (nächster voraussichtlich Mai 2028)"})}
      ${mrFeld("ls.mietdauer_jahre","Ø Mietdauer Jahre",{ph:"0 = kein Wechsel",hilfe:"Danach Mieterwechsel – dann darf neu bis Vergleichsmiete + 10 % oder bis zur Vormiete vermietet werden. Berlin: nur ca. 4,6 % der Mieter ziehen pro Jahr um."})}
      ${mrFeld("ls.ausfall_sofort","A: Mietausfall-Risiko %",{ph:"0",hilfe:"Erwarteter Ausfall pro Jahr in % der Miete (z. B. bessere Mieter bei günstigerer Miete)"})}
      ${mrFeld("ls.ausfall_spaeter","B: Mietausfall-Risiko %",{ph:"0",hilfe:"Ein Ausfall mit Räumung kostet in Berlin grob 9.000 € (3–6 Monate Räumungsklage)"})}
      ${mrFeld("ls.zins","Kalkulationszins % p. a.",{ph:MR.zahl(L.zins||3,1),hilfe:"Wie viel dir Geld heute mehr wert ist als später (z. B. Kreditzins oder Alternativrendite)"})}
      ${mrFeld("ls.steuersatz","Grenzsteuersatz %",{ph:"0 = vor Steuern"})}
      ${mrFeld("ls.neubau_ab_2014","Erstbezug nach 01.10.2014 (keine Bremse)",{typ:"check"})}
    </div>
    <div class="flex" style="flex-wrap:wrap;margin-top:8px;"><button class="sec mini" onclick="mrLsVorschlag()">💡 A = Vergleichsmiete, B = Grenze Mietpreisbremse</button></div>`; }
  if(sub==="be"){ const be=m.be; return `<h2>🚪 Betreten / Besichtigung ankündigen</h2>
    <div class="felder">
      ${mrFeld("be.anlass","Anlass",{typ:"select",optionen:Object.entries(MR_DATEN.anlaesse).map(([k,v])=>[k,v[0]])})}
      ${mrFeld("be.mieter","Mieter",{typ:"text",ph:m.w.mieter||"Frau/Herr …"})}
      ${mrFeld("be.adresse","Anschrift der Wohnung",{typ:"text",kl:"halb",ph:m.w.adresse||""})}
      ${mrFeld("be.termine.0","Termin 1",{typ:"text",ph:"Di 18.11. 17 Uhr"})}
      ${mrFeld("be.termine.1","Termin 2",{typ:"text"})}
      ${mrFeld("be.termine.2","Termin 3",{typ:"text"})}
      ${mrFeld("be.begleitung","Wer kommt mit",{typ:"text",kl:"halb",ph:"z. B. Paul Görner (Makler) mit 2 Interessenten"})}
      ${mrFeld("be.grund","Konkreter Grund (Details)",{typ:"text",kl:"breit",ph:"z. B. Verkauf der Wohnung / Wasserfleck im Bad"})}
    </div>`; }
  if(sub==="ge") return `<h2>📍 Gebiet prüfen</h2>
    <div class="felder">${mrFeld("ge.ort","Ort / Gemeinde",{typ:"text",ph:m.w.ort||"z. B. Falkensee"})}${mrFeld("ge.stichtag","Stichtag",{typ:"date",hilfe:"Für Altverträge: Rechtsstand an einem früheren Tag prüfen"})}</div>
    <div class="hinweis" style="margin-top:8px;">Kappungsgrenze (Bestand, § 558 Abs. 3) und Mietpreisbremse (Neuvermietung, § 556d) haben eigene Verordnungen mit eigenen Laufzeiten.</div>`;
  if(sub==="wi") return `<h2>📚 Wissen</h2>${mrWissenListe()}`;
  return "";
}

// Mietverlauf
function mrHistorieHtml(){
  const h=mrS().me.historie;
  return `<h3>Mietverlauf (nettokalt)</h3>
  <table class="t"><tr><th>gilt ab</th><th class="z">Miete €</th><th>Art</th><th></th></tr>
  ${h.map((x,i)=>`<tr><td><input type="date" data-mr="me.historie.${i}.ab" value="${esc(x.ab||"")}" onchange="mrIn(this)"></td><td><input inputmode="decimal" data-mr="me.historie.${i}.miete" value="${esc(x.miete||"")}" oninput="mrIn(this)" style="text-align:right;"></td>
    <td><select data-mr="me.historie.${i}.art" onchange="mrIn(this)">${MR_HIST_ARTEN.map(([k,l])=>`<option value="${k}" ${x.art===k?"selected":""}>${l}</option>`).join("")}</select></td><td><button class="ghost mini" onclick="mrHistWeg(${i})">✕</button></td></tr>`).join("")}
  </table>
  <div class="flex" style="margin-top:6px;"><button class="sec mini" onclick="mrHistNeu()">+ Zeile</button>${h.length?"":`<button class="ghost mini" onclick="mrHistAusFeldern()">aus den Feldern oben übernehmen</button>`}</div>
  <div class="hinweis" style="margin-top:4px;">Wenn der Verlauf ausgefüllt ist, rechnet der Rechner nur damit. Modernisierungszuschläge im 3-Jahres-Fenster werden zur Kappungsgrenze addiert.</div>`;
}
function mrHistNeu(){ mrS().me.historie.push({ab:"",miete:"",art:mrS().me.historie.length?"558":"beginn"}); speichern(); mrNeu(); }
function mrHistWeg(i){ mrS().me.historie.splice(i,1); speichern(); mrNeu(); }
function mrHistAusFeldern(){ const me=mrS().me; const h=[];
  if(me.mietbeginn) h.push({ab:me.mietbeginn,miete:me.anfangsmiete||me.miete_vorher||me.miete||"",art:"beginn"});
  if(me.letzte_erhoehung_ab) h.push({ab:me.letzte_erhoehung_ab,miete:me.miete||"",art:"558"});
  me.historie=h.length?h:[{ab:"",miete:"",art:"beginn"}]; speichern(); mrNeu(); }
// Staffeln
function mrStufenHtml(){
  const s=mrS().st.stufen;
  return `<table class="t" style="margin-top:8px;"><tr><th>#</th><th>ab</th><th class="z">Miete €</th><th></th></tr>
  ${s.map((x,i)=>`<tr><td>${i===0?"Start":i}</td><td><input type="date" data-mr="st.stufen.${i}.ab" value="${esc(x.ab||"")}" onchange="mrIn(this)"></td><td><input inputmode="decimal" data-mr="st.stufen.${i}.miete" value="${esc(x.miete||"")}" oninput="mrIn(this)" style="text-align:right;"></td><td><button class="ghost mini" onclick="mrStufeWeg(${i})">✕</button></td></tr>`).join("")}</table>
  <div class="flex" style="margin-top:6px;"><button class="sec mini" onclick="mrStufeNeu()">+ Staffel</button></div>`;
}
function mrStufeNeu(){ const s=mrS().st.stufen; const l=s[s.length-1]; let ab="";
  if(l&&l.ab){ const d=MR.datum(l.ab); if(d) ab=MR.iso(MR.plusMonate(d,12)); }
  s.push({ab,miete:l?l.miete:""}); speichern(); mrNeu(); }
function mrStufeWeg(i){ mrS().st.stufen.splice(i,1); speichern(); mrNeu(); }
// VPI
function mrVpiHtml(){
  const alle=MR.vpiAlle(); const keys=Object.keys(alle).map(k=>k.split("-").map(Number)).sort((a,b)=>b[0]-a[0]||b[1]-a[1]).slice(0,15);
  const eigene=mrS().vpi;
  return `<h3>Verbraucherpreisindex (Destatis, ${esc(MR_DATEN.vpi.basis)})</h3>
  <div class="flex klein" style="flex-wrap:wrap;gap:4px 12px;">${keys.map(([j,mo])=>`<span>${String(mo).padStart(2,"0")}/${j}: <b>${MR.zahl(alle[j+"-"+mo],1)}</b>${eigene[j+"-"+mo]!==undefined?" ✎":""}</span>`).join("")}</div>
  <div class="flex" style="margin-top:8px;"><input type="month" id="mrVpiMonat" style="width:auto;"><input id="mrVpiWert" inputmode="decimal" placeholder="Wert, z. B. 126,9" style="width:130px;"><button class="sec mini" onclick="mrVpiSetzen()">Wert speichern</button><button class="ghost mini" onclick="oeffneLink('https://www.destatis.de/DE/Themen/Wirtschaft/Preise/Verbraucherpreisindex/_inhalt.html')">destatis.de ↗</button></div>
  <div class="hinweis" style="margin-top:4px;">Neue Monatswerte erscheinen Mitte des Folgemonats. Alte und neue Zahl müssen dieselbe Basis haben (2020 = 100).</div>`;
}
function mrVpiSetzen(){
  const mon=$("mrVpiMonat").value, w=F($("mrVpiWert").value);
  if(!mon||!w||w<50||w>300){ toast("Bitte Monat und Indexwert (Basis 2020 = 100) eintragen"); return; }
  const [j,mo]=mon.split("-").map(Number); mrS().vpi[j+"-"+mo]=w; MR.setVpiExtra(mrS().vpi); speichern(); mrNeu(); toast(`VPI ${String(mo).padStart(2,"0")}/${j} = ${MR.zahl(w,1)} gespeichert`);
}

// ── Rechnen & Ergebnis ──
function mrRechnen(sub){
  const m=mrS(), b=mrBasis();
  if(sub==="vm") return MR.vergleichsmiete(b);
  if(sub==="me"){ const me=m.me; const a=Object.assign({},b,{miete:me.miete,mietart:me.mietart,letzte_erhoehung_ab:me.letzte_erhoehung_ab,miete_vorher:me.miete_vorher,mietbeginn:me.mietbeginn,anfangsmiete:me.anfangsmiete,zugang:me.zugang,ovm_qm:me.ovm_qm,kappung_prozent:me.kappung_prozent,flaeche_vertrag:m.w.flaeche_vertrag});
    if(me.hist_an) a.historie=me.historie.filter(x=>x.ab&&x.miete); return MR.mieterhoehung(a); }
  if(sub==="nv") return MR.neuvermietung(Object.assign({},b,m.nv));
  if(sub==="mo"){ const mo=Object.assign({},m.mo); if(!mo.miete) mo.miete=m.me.miete; mo.angekuendigt=mo.angekuendigt!=="nein"; return MR.modernisierung(Object.assign({flaeche:b.flaeche},mo)); }
  if(sub==="ix") return MR.indexmiete(Object.assign({mieter:b.mieter,adresse:b.adresse},m.ix));
  if(sub==="st"){ const st=m.st; let ovm=F(st.ovm_qm); if(!ovm&&b.baujahr&&b.wohnlage){ try{ ovm=MR.vergleichsmiete(b).qm; }catch(e){} }
    return MR.staffelPruefen({flaeche:b.flaeche,ort:b.ort||"Berlin",stufen:st.stufen,ovm_qm:ovm,ovm_wachstum:st.ovm_wachstum,neubau_ab_2014:st.neubau_ab_2014}); }
  if(sub==="vs") return MR.vergleich(Object.assign({},b,m.vs));
  if(sub==="ls") return MR.leerstand(Object.assign({},b,m.ls));
  if(sub==="ge"){ const ort=m.ge.ort||m.w.ort||"Berlin"; return MR.gebiet(ort, MR.datum(m.ge.stichtag)||undefined); }
  return null;
}
function mrErgebnis(){
  mrGebietKurz();
  const el=$("mrErg"); if(!el) return;
  const sub=mrS().sub; MR_LETZT=null;
  if(sub==="wi"){ el.innerHTML=mrWissenRechts(); return; }
  if(sub==="be"){ el.innerHTML=mrBetretenHtml(); return; }
  let r;
  try{ r=mrRechnen(sub); }catch(e){ el.innerHTML=mrFehlerHtml(e.fachlich?e.message:"Fehler: "+e.message); if(!e.fachlich) console.error(e); return; }
  MR_LETZT={sub,r};
  el.innerHTML=({vm:mrVmHtml,me:mrMeHtml,nv:mrNvHtml,mo:mrMoHtml,ix:mrIxHtml,st:mrStHtml,vs:mrVsHtml,ls:mrLsHtml,ge:mrGeHtml})[sub](r);
}
function mrAktionen(o){
  o=o||{};
  return `<div class="flex" style="flex-wrap:wrap;margin-top:12px;gap:6px;">
    ${o.entwurf?`<button class="mini" onclick="mrEntwurf()">✉️ ${esc(o.entwurf)}</button>`:""}
    ${o.termine&&HOST&&HOST.terminAnlegen?`<button class="sec mini" onclick="mrTermine()">📅 Fristen ins Cockpit</button>`:""}
    <button class="sec mini" onclick="mrSpeichern()">💾 Speichern</button>
    <button class="sec mini" onclick="mrPromptKopieren()" title="Prompt für Claude/ChatGPT: Ergebnis mit aktuellen Quellen prüfen lassen">📋 Prüf-Prompt</button>
    ${kiAn()?`<button class="ki mini" onclick="mrKiPruefen()">🤖 Direkt prüfen</button>`:""}
  </div>`;
}
function mrSpanne(F_,wert){
  const u=F_.u,o=F_.o,m=F_.m; const pos=v=>Math.max(0,Math.min(100,(v-u)/((o-u)||1)*100));
  return `<div style="position:relative;height:30px;margin:14px 6px 4px;">
    <div style="position:absolute;top:12px;left:0;right:0;height:6px;border-radius:3px;background:linear-gradient(90deg,var(--blue),var(--green) ${pos(m)}%,var(--yellow));"></div>
    <div style="position:absolute;top:6px;left:${pos(m)}%;width:2px;height:18px;background:var(--text);opacity:.5;"></div>
    <div title="Ergebnis" style="position:absolute;top:3px;left:calc(${pos(wert)}% - 8px);width:16px;height:24px;border-radius:5px;background:var(--orange);box-shadow:0 0 10px var(--orange);"></div>
  </div><div class="flex klein hinweis"><span>${mrQ(u)}</span><span class="spacer"></span><span>Mittel ${mrQ(m)}</span><span class="spacer"></span><span>${mrQ(o)}</span></div>`;
}
function mrVmHtml(v){
  const F_=v.feld, T=MR_DATEN.mietspiegel; const akt=F(mrS().vm_vergleich);
  return `<div class="karte"><h2>📊 Ergebnis <span class="rechts badge b-orange">Feld ${F_.zeile}</span></h2>
    <div class="grid g2" style="gap:10px;">${mrBox("Vergleichsmiete",mrQ(v.qm))}${mrBox("im Monat ("+MR.m2(v.flaeche)+")",mrE(v.monat),"nettokalt")}</div>
    ${v.spanne?`<div class="warn klein" style="margin-top:8px;">⚠️ Unklare Merkmale (${v.spanne.offen.map(g=>MR_GRUPPEN_NAMEN[g]).join(", ")}): Wert liegt zwischen <b>${mrQ(v.spanne.min)}</b> und <b>${mrQ(v.spanne.max)}</b>.</div>`:""}
    ${mrSpanne(F_,v.qm)}
    <table class="t" style="margin-top:10px;">
      <tr><td>Feld</td><td>${F_.zeile} · ${T.lagen[F_.lage]} Wohnlage</td></tr>
      <tr><td>Baualter</td><td>${esc(T.klassen[F_.klasse])}</td></tr>
      <tr><td>Wohnfläche</td><td>${esc(MR.flaechentext(F_))}</td></tr>
      <tr><td>Einordnung</td><td>Saldo ${v.saldo>0?"+":""}${v.saldo} × 20 % · ${esc(v.gruppen.join(" · "))}</td></tr>
      <tr><td>Mietpreisbremse</td><td>Neuvermietung höchstens ${mrE(MR.r(v.monat*1.1))} (+10 %)</td></tr>
      ${akt?`<tr><td>Aktuelle Miete</td><td>${mrE(akt)} = ${mrQ(MR.r(akt/v.flaeche))} → ${akt<v.monat?`<span class="pos">${mrE(MR.r(v.monat-akt))} unter Vergleichsmiete</span>`:`<span class="warn">${mrE(MR.r(akt-v.monat))} über Vergleichsmiete</span>`}</td></tr>`:""}
    </table>
    ${mrHinweise(v.hinweise)}
    <div class="hinweis klein" style="margin-top:6px;">ℹ️ ${esc(T.feld_hinweis||"")}</div>
    ${mrAktionen()}
  </div>`;
}
function mrMeHtml(r){
  const t=r.termine, g=r.gebiet;
  const proz=r.erhoehung>0?r.erhoehung/r.miete*100:0;
  const fruehZ=MR.plusMonate(r.letzte.ab,12);
  return `<div class="karte"><h2>📈 Ergebnis</h2>
    ${r.fehlend?`<div class="karte" style="border-left:3px solid var(--red);margin-bottom:10px;"><b class="neg">⚠️ Vorläufig:</b> Die Miete am ${mrD(r.fenster)} (Beginn des 3-Jahres-Fensters) ist unbekannt. Ich habe angenommen, dass sie schon ${mrE(r.ausgangsmiete)} war – trag die Miete davor oder den Mietverlauf ein, sonst ist der Höchstbetrag nicht verbindlich.</div>`:""}
    <div class="grid g2" style="gap:10px;">
      ${mrBox("Vergleichsmiete",mrE(r.ovm),mrQ(r.ovm_qm)+(r.v?` · Feld ${r.v.feld.zeile}`:" · von Hand"))}
      ${mrBox("Kappungsgrenze "+mrP(r.prozent,0),mrE(r.kappe),`Miete am ${mrD(r.fenster)}: ${mrE(r.ausgangsmiete)}${r.mod?` + Mod. ${mrE(r.mod)}`:""}`)}
      ${mrBox("Neue Miete höchstens",mrE(r.hoechst),"Grenze: "+r.bindet,r.erhoehung>0?"pos":"")}
      ${mrBox("Erhöhung",r.erhoehung>0?"+"+mrE(r.erhoehung):"keine",r.erhoehung>0?`+${mrP(proz)} · +${mrE(MR.r(r.erhoehung*12))} im Jahr`:"Miete liegt schon an der Grenze",r.erhoehung>0?"pos":"warn")}
    </div>
    ${r.v?`<div class="hinweis" style="margin-top:8px;">${esc(MR_DATEN.mietspiegel.name)}: Feld ${r.v.feld.zeile} (${MR_DATEN.mietspiegel.lagen[r.v.feld.lage]} Wohnlage), Spanne ${MR.zahl(r.v.feld.u)}–${MR.zahl(r.v.feld.o)} €/m², Mittelwert ${MR.zahl(r.v.feld.m)} · ${esc(r.v.gruppen.join(", "))}<br>ℹ️ ${esc(MR_DATEN.mietspiegel.feld_hinweis||"")}</div>`:""}
    ${r.regelwechsel||r.status==="pruefen"?`<div class="warn klein" style="margin-top:8px;">⚠️ Rechtsstand prüfen – siehe Hinweise unten.</div>`:""}
    <h3>📅 Fristen</h3>
    <table class="t">
      <tr><td>Letzte Erhöhung / Mietbeginn</td><td class="z">${mrD(r.letzte.ab)}</td></tr>
      <tr><td>Verlangen frühestens zustellen ab</td><td class="z">${mrD(fruehZ)}</td></tr>
      <tr><td>Zugang beim Mieter</td><td class="z"><b>${mrD(t.zugang)}</b></td></tr>
      <tr><td>Zustimmungsfrist bis</td><td class="z">${mrD(t.zustimmung_bis)}${t.zustimmung_werktag&&MR.iso(t.zustimmung_werktag)!==MR.iso(t.zustimmung_bis)?` <span class="hinweis" title="Fristende Sa/So/Feiertag → nächster Werktag (§ 193 BGB)">→ ${mrD(t.zustimmung_werktag)}</span>`:""}</td></tr>
      <tr><td>Neue Miete ab</td><td class="z"><b class="pos">${mrD(t.wirksam)}</b></td></tr>
      <tr><td>Ohne Zustimmung: Klage bis</td><td class="z">${mrD(t.klage_bis)}${t.klage_werktag&&MR.iso(t.klage_werktag)!==MR.iso(t.klage_bis)?` <span class="hinweis" title="Fristende Sa/So/Feiertag → nächster Werktag">→ ${mrD(t.klage_werktag)}</span>`:""}</td></tr>
      <tr><td>Sonderkündigung Mieter (§ 561) bis</td><td class="z">${mrD(t.kuendigung_bis)} zum ${mrD(t.kuendigung_zum)}</td></tr>
    </table>
    ${r.warten?`<div class="karte" style="margin-top:10px;border-left:3px solid var(--green);">💡 <b>Warten lohnt sich:</b> Geht das Verlangen erst ab ${mrD(r.warten.zugang)} zu, fällt eine ältere Miete aus dem 3-Jahres-Fenster – dann bis <b>${mrE(r.warten.hoechst)}</b> (+${mrE(r.warten.plus)} im Monat), wirksam ab ${mrD(r.warten.wirksam)}.</div>`:""}
    ${mrHinweise(r.notizen.concat(r.v?r.v.hinweise.filter(h=>!/Mittelwert genommen/.test(h)||!r.v.saldo):[]))}
    <div class="hinweis" style="margin-top:6px;">📝 Textform genügt (Brief oder E-Mail mit Namen), alle Vermieter an alle Mieter. Qualifizierter Mietspiegel: Feld und Spanne immer nennen (§ 558a Abs. 3). Bei Vertretung Vollmacht beilegen.</div>
    ${mrAktionen({entwurf:r.erhoehung>0?"Erhöhungsverlangen (Entwurf)":"",termine:r.erhoehung>0})}
  </div>`;
}
function mrNvHtml(r){
  const g=r.gebiet, frei=!!r.ausnahme||!g.bremse; const best=r.best[1];
  const wunsch=r.wunsch; const diff=wunsch?MR.r(wunsch-best):null; const ok=wunsch?(frei||wunsch<=best+0.005):null;
  const ausnahmeGenutzt=!frei && r.best[0]!==r.wege[0][0];
  const auskunft=!!mrS().nv.auskunft;
  return `<div class="karte"><h2>🔑 Ergebnis</h2>
    <div class="hinweis" style="margin-bottom:8px;">📍 ${esc(g.ort)}${g.land?" ("+g.land+")":""}: ${r.ausnahme?`<b class="pos">Ausnahme</b> – ${esc(r.ausnahme)}`:g.bremse?`Mietpreisbremse gilt (${esc(g.bremse_vo.vo)}${g.bremse_vo.fundstelle?", "+esc(g.bremse_vo.fundstelle):""}, bis ${mrD(MR.datum(g.bremse_vo.bis))})`:g.bekannt?"keine Mietpreisbremse":"keine Verordnung hinterlegt – Landesrecht prüfen"}</div>
    <div class="grid g2" style="gap:10px;">
      ${mrBox("Vergleichsmiete",mrE(r.ovm),mrQ(r.ovm_qm)+(r.v?` · Feld ${r.v.feld.zeile}`:""))}
      ${frei?mrBox("Grenze","frei","nur Mietpreisüberhöhung (§ 5 WiStG) und Wucher (§ 291 StGB)","pos"):mrBox("Höchstens",mrE(best),mrQ(MR.r(best/r.flaeche))+" nettokalt","pos")}
    </div>
    ${frei?"":`<table class="t" style="margin-top:10px;">${r.wege.map(([n,w])=>`<tr${n===r.best[0]?' class="sum"':""}><td>${esc(n)}</td><td class="z">${mrE(w)}</td></tr>`).join("")}</table>`}
    ${wunsch?`<div class="karte" style="margin-top:10px;border-left:3px solid var(--${ok?"green":"red"});">Wunschmiete ${mrE(wunsch)}: ${ok?'<b class="pos">✅ zulässig</b>':`<b class="neg">❌ ${mrE(diff)} zu hoch</b> – der Mieter kann rügen und zu viel gezahlte Miete zurückfordern (bei Rüge in den ersten 30 Monaten ab Mietbeginn).`}</div>`:""}
    ${ausnahmeGenutzt&&!auskunft?`<div class="warn klein" style="margin-top:8px;">⚠️ Für die Vormiete/Modernisierung als Ausnahme: Der Mieter muss <b>vor Abgabe seiner Vertragserklärung unaufgefordert in Textform</b> informiert werden (§ 556g Abs. 1a) – sonst darfst du dich erst 2 Jahre nach Nachholung darauf berufen. Entwurf über den Knopf unten.</div>`:""}
    <ul class="liste-hinweise hinweis">
      <li>Mietpreisüberhöhung bei mehr als 20 % über Vergleichsmiete, also über ${mrE(MR.r(r.ovm*1.2))} (§ 5 WiStG, wenn ein geringes Angebot ausgenutzt wird); Wucher ab etwa 50 % darüber, ${mrE(MR.r(r.ovm*1.5))} (§ 291 StGB).</li>
      ${(r.notizen||[]).map(x=>`<li class="warn">${esc(x)}</li>`).join("")}
      <li>Staffelmiete: jede Staffel muss die Grenze zum Zeitpunkt ihrer Fälligkeit einhalten (§ 557a Abs. 4). Indexmiete: nur die Anfangsmiete (§ 557b Abs. 4).</li>
      ${r.moebliert?`<li>🛋️ Möblierungszuschlag ${mrE(r.moebliert)}: heute nicht gesetzlich geregelt – im Bereich der Mietpreisbremse nur ein angemessener Zuschlag, separat ausweisen. Mietrecht II (Entwurf, nicht beschlossen): höchstens 1 % des Zeitwerts der Möbel pro Monat; bei Vollmöblierung werden bis 10 % der Miete für die unmöblierte Wohnung als angemessen VERMUTET (keine feste Obergrenze); Zuschlag muss vorher genannt werden, sonst gilt die Wohnung 2 Jahre als unmöbliert.</li>`:""}
      ${r.v?mrHinweise(r.v.hinweise).replace(/<\/?ul[^>]*>/g,""):""}
    </ul>
    ${mrAktionen({entwurf:ausnahmeGenutzt||r.ausnahme?"Auskunft § 556g Abs. 1a (Entwurf)":""})}
  </div>`;
}
function mrMoHtml(r){
  return `<div class="karte"><h2>🛠️ Ergebnis</h2>
    <div class="hinweis">${esc(r.regel)}</div>
    <table class="t" style="margin-top:8px;">
      <tr><td>Kosten</td><td class="z">${mrE(r.kosten)}</td></tr>
      ${r.basis!==r.kosten?`<tr><td>Wärmepumpe ohne Nachweis: halbe Kosten</td><td class="z">${mrE(r.basis)}</td></tr>`:""}
      <tr><td>− Erhaltungsanteil</td><td class="z">${mrE(r.erhaltung)}</td></tr>
      ${r.foerderung?`<tr><td>− Förderung</td><td class="z">${mrE(r.foerderung)}</td></tr>`:""}
      <tr class="sum"><td>Umlagefähig</td><td class="z">${mrE(r.umlagefaehig)}</td></tr>
      <tr><td>× ${mrP(r.satz,0)} pro Jahr</td><td class="z">${mrE(r.jahr)} = ${mrE(r.monat)}/Monat</td></tr>
      <tr><td>Kappung ${mrQ(r.grenze_qm)} in 6 J. (Miete vorher ${mrQ(MR.r(r.qm_vorher))}${r.unter_schwelle?" < 7 €/m² → 2 €":""})${r.frueher_eur?`, schon genutzt ${mrE(r.frueher_eur)}`:""}</td><td class="z">noch ${mrE(r.rest)}</td></tr>
      ${r.heizung?`<tr><td>davon Heizung höchstens 0,50 €/m²</td><td class="z">noch ${mrE(r.heiz_rest)}${r.heiz_final!==null?` · angesetzt ${mrE(r.heiz_final)}`:""}</td></tr>`:""}
    </table>
    <div class="grid g2" style="gap:10px;margin-top:10px;">
      ${mrBox("Erhöhung im Monat",mrE(r.final),r.gekappt?"gekappt":"ungekappt","pos")}
      ${mrBox("Neue Miete",mrE(r.neu),"ab "+mrD(r.wirksam)+(r.spaeter?" (+6 Monate)":""))}
    </div>
    ${r.restbudget!==undefined&&r.restbudget!==null?`<div class="hinweis" style="margin-top:6px;">Vereinfachtes Verfahren: Restbudget in den nächsten 5 Jahren ${mrE(r.restbudget)}.</div>`:""}
    <h3>📅 Ablauf</h3>
    <ol class="liste-hinweise hinweis">
      <li>Ankündigung spätestens 3 Monate vor Beginn in Textform: Art, Umfang, Beginn, Dauer, erwartete Erhöhung, künftige Betriebskosten, Hinweis auf Härteeinwand (§ 555c)${r.verfahren.startsWith("verein")?" – plus Hinweis auf das vereinfachte Verfahren":""}.</li>
      <li>Mieter: Härteeinwand bis Ende des Monats nach Zugang der Ankündigung (§ 555d); Sonderkündigung bis Ende des Folgemonats zum Ende des übernächsten Monats (§ 555e).</li>
      <li>Nach Abschluss: Erhöhungserklärung in Textform mit Berechnung und Erläuterung (§ 559b).</li>
      <li>Zugang ${mrD(r.zugang)} → neue Miete ab <b>${mrD(r.wirksam)}</b>${r.spaeter?" (6 Monate später: nicht ordnungsgemäß angekündigt oder mehr als 10 % über der Ankündigung)":""}.</li>
    </ol>
    ${mrHinweise(r.notizen.concat([r.verfahren.startsWith("verein")?"Vereinfachtes Verfahren: kein Härteeinwand wegen der Miethöhe, aber 5 Jahre lang keine weitere Umlage nach § 559 (Ausnahmen: unvorhersehbare gesetzliche Pflicht, WEG-Beschluss).":"Härteeinwand: Erhöhung entfällt, soweit sie eine nicht zu rechtfertigende Härte ist – außer bei allgemein üblichem Zustand oder gesetzlicher Pflicht (§ 559 Abs. 4).","Alternative: statt Umlage die Miete nach § 558 an die höhere Vergleichsmiete der modernisierten Wohnung anpassen."]))}
    ${mrAktionen({termine:true})}
  </div>`;
}
function mrIxHtml(r){
  const naechste=MR.naechsterErster(MR.plusMonate(r.wirksam,12));
  return `<div class="karte"><h2>📉 Ergebnis</h2>
    <table class="t">
      <tr><td>VPI ${r.basis_monat?MR.monatDe(r.basis_monat):"alt"}</td><td class="z">${MR.zahl(r.basis,1)}</td></tr>
      <tr><td>VPI ${MR.monatDe(r.neu_monat)}</td><td class="z">${MR.zahl(r.neu,1)}</td></tr>
      <tr class="sum"><td>Veränderung</td><td class="z">${r.aend>=0?"+":""}${mrP(r.aend)}</td></tr>
    </table>
    <div class="grid g2" style="gap:10px;margin-top:10px;">
      ${mrBox(r.plus>=0?"Neue Miete":"Neue Miete (Senkung)",mrE(r.neu_miete),(r.plus>=0?"+":"")+mrE(r.plus)+" im Monat",r.plus>=0?"pos":"warn")}
      ${mrBox("zu zahlen ab",mrD(r.wirksam),"Zugang "+mrD(r.zugang)+" + übernächster Monat")}
    </div>
    ${r.plus<0?`<div class="hinweis" style="margin-top:6px;">Sinkt der Index, kann der Mieter eine entsprechende Senkung verlangen.</div>`:""}
    ${mrHinweise(r.notizen.concat([`Nächste Anpassung frühestens ab ${mrD(naechste)} (Miete mindestens 1 Jahr unverändert).`,"Erklärung in Textform mit beiden Indexständen, Änderung in % und neuer Miete bzw. Erhöhung in €.","Keine Erhöhung nach § 558; Modernisierungsumlage nur für Maßnahmen, die der Vermieter nicht zu vertreten hat, und für einen Heizungstausch (§ 557b Abs. 2)."]))}
    ${r.reform?`<div class="karte" style="margin-top:8px;border-left:3px solid var(--purple);">🔮 <b>Mietrecht II – nur Entwurf</b> (BT-Drs. 21/6807, Stand ${esc(MR_DATEN.reform.stand||MR_DATEN.stand)}: ${esc(MR_DATEN.reform.status||"nicht beschlossen")}): In Gebieten mit Landesverordnung würde der Anstieg über 3 % pro Jahr nur zur Hälfte zählen – hier grob ${mrP(r.reform.aend)} = ${mrE(r.reform.miete)}. Gilt erst für Erklärungen nach Inkrafttreten, dann auch für laufende Verträge. Wie über mehrere Jahre gerechnet wird, ist noch offen.</div>`:""}
    ${mrAktionen({entwurf:"Anpassungserklärung (Entwurf)",termine:true})}
  </div>`;
}
function mrStHtml(r){
  const z=r.zeilen;
  return `<div class="karte"><h2>🪜 Prüfung</h2>
    <div class="hinweis">${r.bremse?`📍 ${esc(r.gebiet.ort)}: Mietpreisbremse gilt – jede Staffel höchstens Vergleichsmiete + 10 % zum Zeitpunkt ihrer Fälligkeit.`:`📍 ${esc(r.gebiet.ort)}: keine Mietpreisbremse für diese Staffeln.`}</div>
    <table class="t" style="margin-top:8px;"><tr><th>#</th><th>ab</th><th class="z">Miete</th><th class="z">Abstand</th><th class="z">Grenze</th><th></th></tr>
    ${z.map((x,i)=>`<tr><td>${i===0?"Start":i}</td><td>${mrD(x.ab)}</td><td class="z">${mrE(x.miete)}</td><td class="z">${x.abstand_monate===null?"–":x.abstand_monate+" Mon."}</td><td class="z">${x.bremse?(x.grenze?mrE(x.grenze)+(x.prognose?" *":""):"–"):"keine Bremse"}</td>
      <td>${x.zu_kurz?'<span class="badge b-rot">unter 1 Jahr</span>':""}${x.zu_hoch?'<span class="badge b-rot">über Grenze</span>':""}${x.sinkt?'<span class="badge b-gelb">sinkt</span>':""}${!x.zu_kurz&&!x.zu_hoch&&!x.sinkt?'<span class="badge b-gruen">ok</span>':""}</td></tr>`).join("")}</table>
    ${z.some(x=>x.prognose)?`<div class="hinweis" style="margin-top:4px;">* Grenze für künftige Staffeln ist eine Prognose (Annahme ${mrP(r.wachstum||0)} p. a.) – maßgeblich ist der Mietspiegel bei Fälligkeit. Läuft die Verordnung vorher aus, gilt für spätere Staffeln keine Bremse (Rechtsstand dann prüfen).</div>`:""}
    ${r.pruefen?`<div class="warn klein" style="margin-top:4px;">⚠️ Für mindestens eine Staffel liegt das Datum außerhalb der hinterlegten Verordnungen – Rechtsstand bei Fälligkeit prüfen.</div>`:""}
    ${mrHinweise(["Beträge immer in € angeben – „jährlich +3 %“ ist als Staffel unwirksam.","Während der Laufzeit keine Erhöhung nach §§ 558–559b; Betriebskosten (§ 560) bleiben möglich.","Kündigungsverzicht des Mieters höchstens 4 Jahre ab Vertragsschluss.","Eine einmal wirksame Staffelhöhe bleibt geschützt, auch wenn die Grenze später niedriger liegt."])}
    ${mrAktionen()}
  </div>`;
}
function mrLinien(r){
  const reihen=[["Standard (§ 558)","var(--orange)"],["Indexmiete","var(--blue)"],["Staffelmiete","var(--green)"]];
  const alle=reihen.flatMap(([n])=>r.res[n].reihe); const max=Math.max(...alle), min=Math.min(...alle); const n=r.res["Indexmiete"].reihe.length;
  const x=i=>20+i*(560/Math.max(n-1,1)), y=v=>170-(v-min)/((max-min)||1)*150;
  return `<svg viewBox="0 0 600 190" style="width:100%;height:auto;margin-top:8px;">
    <line x1="20" y1="170" x2="580" y2="170" stroke="var(--border)"/>
    ${reihen.map(([nm,c])=>`<polyline fill="none" stroke="${c}" stroke-width="2.5" points="${r.res[nm].reihe.map((v,i)=>x(i)+","+y(v)).join(" ")}"/>`).join("")}
    <text x="20" y="186" fill="var(--muted)" font-size="11">Jahr 1</text><text x="580" y="186" fill="var(--muted)" font-size="11" text-anchor="end">Jahr ${n}</text>
    <text x="22" y="${y(max)-4}" fill="var(--muted)" font-size="11">${MR.zahl(max,0)} €</text>
  </svg><div class="flex klein" style="flex-wrap:wrap;">${reihen.map(([nm,c])=>`<span><span style="display:inline-block;width:10px;height:3px;background:${c};vertical-align:middle;"></span> ${nm}</span>`).join("")}</div>`;
}
function mrVsHtml(r){
  const beste=Object.entries(r.res).sort((a,b)=>b[1].summe-a[1].summe)[0][0];
  return `<div class="karte"><h2>⚖️ Szenario ${r.jahre} Jahre</h2>
    ${r.notiz?`<div class="warn klein" style="margin-bottom:8px;">⚠️ ${esc(r.notiz)}</div>`:""}
    <table class="t"><tr><th>Modell</th><th class="z">Miete am Ende</th><th class="z">Summe ${r.jahre} J.</th></tr>
      ${Object.entries(r.res).map(([n,w])=>`<tr${n===beste?' class="sum"':""}><td>${n}${n===beste?" 🏆":""}</td><td class="z">${mrE(w.ende)}</td><td class="z">${mrE(w.summe)}</td></tr>`).join("")}</table>
    ${mrLinien(r)}
    <div class="hinweis" style="margin-top:6px;">Annahmen: Inflation ${mrP(r.inflation)}, Vergleichsmiete +${mrP(r.ovm_wachstum)} p. a. (${mrE(r.ovm0)} → ${mrE(r.ovm_ende)}), Staffel +${mrP(r.staffel)} p. a., Kappung ${mrP(r.kappung,0)}, Mietpreisbremse für Staffeln: ${r.bremse?"ja":"nein"}.</div>
    ${mrHinweise(["Standard: flexibel, Modernisierungsumlage möglich, aber Mietspiegel und Kappung begrenzen; jede Erhöhung braucht Begründung und Zustimmung.","Index: folgt der Inflation ohne Kappung und Mietspiegel; kein § 558, Umlage nur bei gesetzlich vorgeschriebenen Maßnahmen; bei Deflation sinkt die Miete. Mietrecht II (Entwurf) würde Anstiege über 3 % p. a. in Verordnungsgebieten halbieren.","Staffel: planbar, Beträge in € im Vertrag, mindestens 1 Jahr je Staffel; kein § 558/§ 559 – Modernisieren lohnt sich während der Laufzeit nicht; in Berlin muss jede Staffel die Mietpreisbremse einhalten (außer Neubau ab 10/2014)."])}
    ${mrAktionen()}
  </div>`;
}
function mrGeHtml(g){
  const G=MR_DATEN.gebiete; const st=mrS().ge.stichtag;
  const vo=(x,art)=>x?`${esc(x.vo)}${x.fundstelle?", "+esc(x.fundstelle):""} – gültig ${mrD(MR.datum(x.von))} bis ${mrD(MR.datum(x.bis))}`:`keine ${art} hinterlegt`;
  return `<div class="karte"><h2>📍 ${esc(g.ort)}${g.land?" ("+g.land+")":""}${st?` <span class="hinweis">Stand ${mrD(MR.datum(st))}</span>`:""}</h2>
    ${g.status==="pruefen"?`<div class="warn" style="margin-bottom:8px;">⚠️ ${esc(g.pruefen_text||"Rechtsstand für diesen Tag nicht sicher hinterlegt – Verordnung prüfen.")}</div>`:""}
    <div class="grid g2" style="gap:10px;">${mrBox("Kappungsgrenze (Bestand)",g.kappung+" %","in 3 Jahren, § 558 Abs. 3")}${mrBox("Mietpreisbremse (Neuvermietung)",g.bremse?"ja":"nein",g.bremse?"Vergleichsmiete + 10 %":"Grenze nur § 5 WiStG / § 291 StGB",g.bremse?"warn":"pos")}</div>
    <table class="t" style="margin-top:10px;"><tr><td>Kappung</td><td>${vo(g.kappung_vo,"Verordnung")}</td></tr><tr><td>Bremse</td><td>${vo(g.bremse_vo,"Verordnung")}</td></tr>
    <tr><td>Vergleichsmiete</td><td>${g.land==="Berlin"?esc(MR_DATEN.mietspiegel.name)+" (qualifiziert)":g.land==="Brandenburg"?"eigener Mietspiegel der Gemeinde (z. B. Potsdam), sonst Vergleichswohnungen oder Gutachten – der Berliner Mietspiegel gilt dort nicht":"örtlicher Mietspiegel, Vergleichswohnungen oder Gutachten"}</td></tr></table>
    ${mrHinweise(g.hinweise)}
    ${!g.bekannt?`<div class="hinweis" style="margin-top:8px;">Nicht in den hinterlegten Verordnungen (Berlin + 36 Brandenburger Gemeinden). Gesetzlich gilt dann 20 % Kappung und keine Mietpreisbremse – außer das Land hat die Gemeinde erfasst.</div>`:""}
    <details style="margin-top:10px;"><summary class="hinweis" style="cursor:pointer;">Brandenburg: ${G.bb_gemeinden.length} Gemeinden mit Verordnung seit 01.01.2026</summary><div class="klein" style="margin-top:6px;line-height:1.6;">${G.bb_gemeinden.map(esc).join(" · ")}</div>
    ${G.bb_weggefallen?`<div class="hinweis" style="margin-top:6px;">2021–2025 dabei, seit 2026 nicht mehr: ${G.bb_weggefallen.map(esc).join(", ")}</div>`:""}</details>
    <details style="margin-top:6px;"><summary class="hinweis" style="cursor:pointer;">Alle hinterlegten Verordnungen</summary><table class="t klein" style="margin-top:6px;">${(G.regeln||[]).map(x=>`<tr><td>${esc(x.land)}</td><td>${x.art==="kappung"?"Kappung "+x.prozent+" %":"Bremse"}</td><td>${esc(x.vo)}${x.fundstelle?", "+esc(x.fundstelle):""}</td><td>${mrD(MR.datum(x.von))}–${mrD(MR.datum(x.bis))}</td></tr>`).join("")}</table></details>
  </div>`;
}

// ── Betreten ──
function mrBetretenHtml(){
  const t=mrBetretenEntwurf(); const A=MR_DATEN.anlaesse; const be=mrS().be; const an=A[be.anlass||"verkauf"]||A.verkauf;
  return `<div class="karte"><h2>🚪 Regeln</h2>
    <div class="grid g2" style="gap:10px;">${mrBox("Ankündigung (Praxiswert)",esc(an[1]))}${mrBox("Zeiten (Praxiswert)",esc(an[2]).slice(0,80))}</div>
    <div class="hinweis" style="margin-top:6px;">${esc(MR_DATEN.anlaesse_hinweis||"")}</div>
    <ul class="liste-hinweise hinweis">
      <li>Kein allgemeines Kontrollrecht – nur aus konkretem, sachlichem Anlass nach rechtzeitiger Ankündigung (BGH VIII ZR 289/13, VIII ZR 420/21). Klauseln wie „jederzeit“ oder „einmal jährlich ohne Anlass“ sind unwirksam.</li>
      <li>Ankündigung mit Grund und Terminvorschlägen; Berufstätige dürfen Termine außerhalb der Arbeitszeit verlangen.</li>
      <li>Makler und Handwerker dürfen mit. Fotos nur mit Einwilligung des Mieters – für Exposés schriftlich einholen.</li>
      <li>Nie mit Zweitschlüssel ohne Erlaubnis hinein (außer Notfall) – Hausfriedensbruch, Kündigungsgrund für den Mieter.</li>
      <li>Verweigert der Mieter: schriftlich mit Frist auffordern, dann Duldungsklage; beharrliche Verweigerung kann nach Abmahnung eine Kündigung rechtfertigen.</li>
      <li>Gesundheitliche oder ähnliche Härtegründe des Mieters ernst nehmen und dokumentieren – Termine dann anpassen.</li>
    </ul>
    <h3>✉️ Ankündigung (Entwurf)</h3>
    <textarea id="mrBeText" style="min-height:280px;font-size:12px;">${esc(t)}</textarea>
    <div class="flex" style="flex-wrap:wrap;margin-top:8px;"><button class="mini" onclick="kopieren($('mrBeText').value,'Ankündigung kopiert ✓')">📋 Kopieren</button>${HOST&&HOST.terminAnlegen?`<button class="sec mini" onclick="mrBeTermine()">📅 Termine ins Cockpit</button>`:""}</div>
  </div>`;
}
function mrAnrede(n){ n=String(n||"").trim(); if(/^frau /i.test(n)) return "Sehr geehrte "+n; if(/^herr /i.test(n)) return "Sehr geehrter "+n; return n?"Guten Tag "+n:"Sehr geehrte Damen und Herren"; }
function mrBetretenEntwurf(){
  const be=mrS().be, w=mrS().w; const anlass=be.anlass||"verkauf";
  const mieter=be.mieter||w.mieter||"", adr=be.adresse||w.adresse||"";
  const termine=(be.termine||[]).filter(x=>String(x||"").trim()); const tl=termine.length?termine:["[Termin 1]","[Termin 2]","[Termin 3]"];
  const grund={verkauf:"Ich beabsichtige, die Wohnung zu verkaufen, und möchte sie Kaufinteressenten zeigen.",nachvermietung:"Da das Mietverhältnis endet, möchte ich die Wohnung Mietinteressenten zeigen.",handwerker:"In der Wohnung sind folgende Arbeiten nötig: [Arbeiten].",ablesen:"Es steht die Ablesung bzw. Wartung von [Zähler/Rauchmelder/Therme] an.",modernisierung:"Zur Vorbereitung der angekündigten Modernisierung ist eine Besichtigung nötig.",maengel:"Sie haben uns folgenden Mangel gemeldet: [Mangel]. Diesen möchte ich vor Ort prüfen.",notfall:"Wegen eines akuten Schadens ([Schaden]) ist ein sofortiger Zutritt nötig."}[anlass]||"[Grund]";
  return `[Name Vermieter, Anschrift]\n\nAn\n${mieter||"[Name Mieter]"}\n${adr||"[Anschrift]"}\n\nBerlin, ${new Date().toLocaleDateString("de-DE")}\n\nAnkündigung eines Besichtigungstermins\n\n${mrAnrede(mieter)},\n\n${grund}${be.grund?" "+be.grund:""} Ich bitte Sie deshalb, ${be.begleitung?be.begleitung:"mir bzw. [Name Makler/Handwerker]"} Zutritt zur Wohnung zu gewähren. Folgende Termine schlage ich vor:\n${tl.map(x=>"• "+x).join("\n")}\n\nDie Besichtigung dauert voraussichtlich ${anlass==="verkauf"||anlass==="nachvermietung"?"30–45":"[Dauer]"} Minuten. Passt keiner der Termine, nennen Sie mir bitte einen Alternativtermin in den nächsten zwei Wochen. Fotos werden nur mit Ihrer Zustimmung gemacht.\n\nVielen Dank für Ihr Verständnis.\n\nMit freundlichen Grüßen\n[Name]`;
}
function mrBeTermine(){ toast("Bitte die Termine im Cockpit-Kalender mit Datum eintragen – die Vorschläge sind Freitext."); }

// ── Wissen ──
function mrWissenListe(){
  const W=MR_DATEN.wissen;
  return Object.entries(W).filter(([k,[t,x]])=>x).map(([k,[t,x]])=>`<details style="border-top:1px solid var(--border);padding:8px 0;"><summary style="cursor:pointer;font-weight:700;">${esc(t)}</summary><div class="hinweis" style="white-space:pre-wrap;margin-top:6px;font-size:12px;color:var(--text);">${esc(x)}</div></details>`).join("");
}
function mrWissenRechts(){
  const Q=MR_DATEN.quellen;
  return `<div class="karte"><h2>🔗 Quellen</h2>${Q.map(([n,u])=>`<div class="zeile"><div class="haupt"><a href="#" onclick="oeffneLink('${esc(u)}');return false;">${esc(n)}</a></div></div>`).join("")}
    <div class="hinweis" style="margin-top:8px;">Datenstand: ${esc(MR_DATEN.stand)}. Mietspiegel, Verordnungen und Index ändern sich – bei neuen Ständen werden die Zahlen im Programm aktualisiert. Neue Indexwerte kannst du selbst unter „Indexmiete“ eintragen.</div></div>
    <div class="karte" style="margin-top:14px;"><h2>🧾 Orientierungshilfe – alle Merkmale</h2>${MR.GRUPPEN.map(g=>{ const [n,mi,pl]=MR_DATEN.mietspiegel.merkmale[g]; return `<details style="border-top:1px solid var(--border);padding:6px 0;"><summary style="cursor:pointer;">${esc(n)}</summary><div class="klein" style="margin-top:4px;line-height:1.5;">➖ ${mi.map(esc).join("<br>➖ ")}<br>➕ ${pl.map(esc).join("<br>➕ ")}</div></details>`; }).join("")}</div>`;
}

// ── Entwürfe ──
function mrEntwurfText(){
  if(!MR_LETZT) return "";
  const {sub,r}=MR_LETZT; const w=mrS().w; const mieter=w.mieter||"", adr=w.adresse||"";
  const kopf=`[Name Vermieter, Anschrift]\n\nAn\n${mieter||"[Name Mieter]"}\n${adr||"[Anschrift der Wohnung]"}\n\nBerlin, [Datum]\n\n`;
  if(sub==="me"){
    const t=r.termine, f=r.v?r.v.feld:null, T=MR_DATEN.mietspiegel;
    const begr=f?`Ihre Wohnung ist im ${T.name} (qualifiziert, in Kraft seit ${T.in_kraft}) dem Feld ${f.zeile} (${T.lagen[f.lage]} Wohnlage) zuzuordnen (${T.klassen[f.klasse]}, ${MR.flaechentext(f)}). Die Spanne reicht von ${mrQ(f.u)} über den Mittelwert ${mrQ(f.m)} bis ${mrQ(f.o)}. Nach der Orientierungshilfe zur Spanneneinordnung (${r.v.gruppen.join(", ")}) ergibt sich eine ortsübliche Vergleichsmiete von ${mrQ(r.ovm_qm)}.`:`Die ortsübliche Vergleichsmiete für Ihre Wohnung beträgt ${mrQ(r.ovm_qm)} [Begründung: Mietspiegel mit Feld/Spanne, drei Vergleichswohnungen oder Gutachten einfügen].`;
    return kopf+`Mieterhöhungsverlangen nach § 558 BGB\n\n${mrAnrede(mieter)},\n\nSie zahlen für die Wohnung ${adr||"[Lage der Wohnung]"} (${MR.m2(r.flaeche)}) derzeit eine Nettokaltmiete von ${mrE(r.miete)}. Die Miete ist seit dem ${mrD(r.letzte.ab)} unverändert.\n\nHiermit bitte ich Sie, einer Erhöhung der Nettokaltmiete auf ${mrE(r.hoechst)} monatlich mit Wirkung ab dem ${mrD(t.wirksam)} zuzustimmen. Die Betriebskostenvorauszahlungen bleiben unverändert.\n\nBegründung: ${begr} Die verlangte Miete von ${mrQ(MR.r(r.hoechst/r.flaeche))} übersteigt die ortsübliche Vergleichsmiete nicht. Die Kappungsgrenze von ${mrP(r.prozent,0)} innerhalb von drei Jahren ist eingehalten (Ausgangsmiete am ${mrD(r.fenster)}: ${mrE(r.ausgangsmiete)}).\n\nBitte erklären Sie Ihre Zustimmung bis zum ${mrD(t.zustimmung_bis)}. Nach § 561 BGB können Sie das Mietverhältnis bis zum Ablauf des zweiten Monats nach Zugang dieses Schreibens zum Ablauf des übernächsten Monats kündigen.\n\nMit freundlichen Grüßen\n[Name Vermieter]\n\n– – – – – – – – – – – – – – – – – – – –\nZustimmung: Ich/Wir stimme(n) der Erhöhung der Nettokaltmiete auf ${mrE(r.hoechst)} ab ${mrD(t.wirksam)} zu.\n\n[Ort, Datum, Unterschrift Mieter]`;
  }
  if(sub==="ix"){
    const bm=r.basis_monat?MR.monatDe(r.basis_monat):"[Ausgangsmonat]";
    return kopf+`Anpassung der Miete nach der vereinbarten Indexklausel (§ 557b BGB)\n\n${mrAnrede(mieter)},\n\nnach § [Nr.] unseres Mietvertrags ist die Nettokaltmiete an den vom Statistischen Bundesamt ermittelten Verbraucherpreisindex für Deutschland gebunden. Der Index (Basis ${MR_DATEN.vpi.basis}) stand im ${bm} bei ${MR.zahl(r.basis,1)} Punkten und im ${MR.monatDe(r.neu_monat)} bei ${MR.zahl(r.neu,1)} Punkten. Das entspricht einer Veränderung von ${mrP(r.aend)}.\n\nIhre Nettokaltmiete ${r.plus>=0?"erhöht":"ändert"} sich daher um ${mrE(Math.abs(r.plus))} von ${mrE(r.miete)} auf ${mrE(r.neu_miete)} monatlich. Die neue Miete ist ab dem ${mrD(r.wirksam)} zu zahlen. Die Betriebskostenvorauszahlungen bleiben unverändert.\n\nMit freundlichen Grüßen\n[Name Vermieter]`;
  }
  if(sub==="nv"){
    const nv=mrS().nv; const teile=[];
    if(r.ausnahme && nv.neubau_ab_2014) teile.push("Die Wohnung wurde nach dem 01.10.2014 erstmals genutzt und vermietet (§ 556f Satz 1 BGB). Die Vorschriften über die zulässige Miethöhe bei Mietbeginn (§§ 556d ff. BGB) sind daher nicht anzuwenden.");
    if(r.ausnahme && nv.umfassend_modernisiert) teile.push("Es handelt sich um die erste Vermietung nach einer umfassenden Modernisierung (§ 556f Satz 2 BGB). Die Vorschriften über die zulässige Miethöhe bei Mietbeginn sind daher nicht anzuwenden.");
    if(F(nv.vormiete)) teile.push(`Die Miete des vorherigen Mieters betrug zuletzt ${mrE(F(nv.vormiete))} nettokalt monatlich (§ 556e Abs. 1 BGB).`);
    if(F(nv.modernisierung_umlage)) teile.push(`In den letzten drei Jahren vor Beginn des Mietverhältnisses wurden Modernisierungsmaßnahmen im Sinne des § 555b BGB durchgeführt ([Maßnahmen, Abschluss]) (§ 556e Abs. 2 BGB).`);
    return `Auskunft vor Abschluss des Mietvertrags (§ 556g Abs. 1a BGB)\n\nWohnung: ${adr||"[Anschrift]"}\n\nSehr geehrte Mietinteressentin, sehr geehrter Mietinteressent,\n\nvor Abschluss des Mietvertrags teile ich Ihnen Folgendes mit:\n\n${teile.join("\n\n")||"[Angaben zur Ausnahme]"}\n\nMit freundlichen Grüßen\n[Name Vermieter]\n\n(Diese Auskunft muss in Textform und vor Ihrer Vertragserklärung zugehen.)`;
  }
  return "";
}
function mrEntwurf(){
  const t=mrEntwurfText(); if(!t){ toast("Für diese Berechnung gibt es keinen Entwurf"); return; }
  modal("✉️ Entwurf", `<div class="hinweis">Vor dem Versand prüfen und ergänzen ([…]). Textform genügt; bei Vertretung Vollmacht beilegen.</div><textarea id="mrEntwurfText" style="min-height:420px;font-size:12px;margin-top:8px;">${esc(t)}</textarea><div class="flex" style="margin-top:8px;"><button onclick="kopieren($('mrEntwurfText').value,'Entwurf kopiert ✓')">📋 Kopieren</button></div>`);
}

// ── Termine, Speichern, Prompt ──
function mrTermine(){
  if(!MR_LETZT||!HOST||!HOST.terminAnlegen) return;
  const {sub,r}=MR_LETZT; const w=mrS().w; const wer=[w.adresse,w.mieter].filter(Boolean).join(" – ")||"Wohnung";
  const liste=[];
  if(sub==="me"){ const t=r.termine;
    liste.push([t.zugang,`🏠 Mieterhöhung zustellen: ${wer}`,`Zugang spätestens heute, Ziel ${mrE(r.hoechst)}`]);
    liste.push([t.zustimmung_werktag||t.zustimmung_bis,`🏠 Zustimmungsfrist endet: ${wer}`,"Zustimmung da? Sonst Klage bis "+mrD(t.klage_werktag||t.klage_bis)]);
    liste.push([t.wirksam,`🏠 Neue Miete ${mrE(r.hoechst)} ab heute: ${wer}`,""]);
    liste.push([t.klage_werktag||t.klage_bis,`🏠 Letzter Tag Zustimmungsklage: ${wer}`,""]); }
  if(sub==="mo") liste.push([r.wirksam,`🛠️ Modernisierungsumlage ${mrE(r.final)} ab heute: ${wer}`,""]);
  if(sub==="ix"){ liste.push([r.wirksam,`📉 Indexmiete ${mrE(r.neu_miete)} ab heute: ${wer}`,""]); liste.push([MR.naechsterErster(MR.plusMonate(r.wirksam,12)),`📉 Indexmiete wieder anpassbar: ${wer}`,"VPI prüfen"]); }
  const vorhanden=new Set(cockpit.termine().map(t=>t.datum+"|"+t.titel)); let n=0;
  for(const [d,titel,notiz] of liste){ const iso=MR.iso(d); if(!iso||vorhanden.has(iso+"|"+titel)) continue; HOST.terminAnlegen({titel,datum:iso,uhrzeit:"",notiz:notiz||"aus Jarvis Mietrechner",art:"Mietrecht"}); n++; }
  toast(n?`📅 ${n} Termin(e) im Cockpit eingetragen`:"Termine sind schon eingetragen");
}
function mrKurz(sub,r){
  if(sub==="vm") return `Vergleichsmiete ${mrQ(r.qm)} = ${mrE(r.monat)}`;
  if(sub==="me") return `max. ${mrE(r.hoechst)} (+${mrE(r.erhoehung)}) ab ${mrD(r.termine.wirksam)}`;
  if(sub==="nv") return `Neuvermietung max. ${mrE(r.best[1])}`;
  if(sub==="mo") return `Umlage ${mrE(r.final)} → ${mrE(r.neu)} ab ${mrD(r.wirksam)}`;
  if(sub==="ix") return `Index ${mrP(r.aend)} → ${mrE(r.neu_miete)} ab ${mrD(r.wirksam)}`;
  if(sub==="vs") return `Vergleich ${r.jahre} J.`;
  if(sub==="ls") return `Leerstand ${r.L} Mon.: ${r.diff>=0?"lohnt (+":"lohnt nicht ("}${mrE(r.diff)})`;
  if(sub==="st") return `Staffel: ${r.zeilen.filter(x=>x.zu_hoch||x.zu_kurz).length} Problem(e)`;
  if(sub==="ge") return `${r.ort}: ${r.kappung} %, Bremse ${r.bremse?"ja":"nein"}${r.status==="pruefen"?" (prüfen)":""}`;
  return "";
}
function mrSpeichern(){
  if(!MR_LETZT){ toast("Nichts zu speichern"); return; }
  const m=mrS(); const {sub,r}=MR_LETZT;
  m.akten.unshift({id:uid(),zeit:new Date().toISOString(),sub,titel:[m.w.adresse,m.w.ort].filter(Boolean).join(", ")||"Berechnung",mieter:m.w.mieter||"",kurz:mrKurz(sub,r),stand:MR_DATEN.stand,
    w:JSON.parse(JSON.stringify(m.w)),d:JSON.parse(JSON.stringify(m[sub]||{}))});
  m.akten=m.akten.slice(0,80); speichern(); mrNeu(); toast("💾 Gespeichert");
}
function mrAktenZeigen(){
  const a=mrS().akten;
  modal("📁 Gespeicherte Berechnungen", a.length?a.map(x=>`<div class="zeile"><div class="haupt"><div class="t">${esc((MR_SUBS.find(s=>s[0]===x.sub)||["",""])[1])} · ${esc(x.titel)}</div><div class="m">${zeitDE(x.zeit)} · ${esc(x.kurz)}${x.mieter?" · "+esc(x.mieter):""} · Rechtsstand ${esc(x.stand||"")}</div></div><button class="sec mini" onclick="mrAkteLaden('${x.id}')">Öffnen</button><button class="ghost mini" onclick="mrAkteWeg('${x.id}')">✕</button></div>`).join(""):'<div class="leer">Noch nichts gespeichert.</div>');
}
function mrAkteLaden(id){ const m=mrS(); const x=m.akten.find(a=>a.id===id); if(!x) return; m.w=JSON.parse(JSON.stringify(x.w)); m[x.sub]=JSON.parse(JSON.stringify(x.d)); m.sub=x.sub; mrS(); speichern(); modalZu(); renderMiete($("main")); toast("Geöffnet – neu berechnet mit aktuellem Datenstand"); }
function mrAkteWeg(id){ const m=mrS(); m.akten=m.akten.filter(a=>a.id!==id); speichern(); mrAktenZeigen(); }
function mrPrompt(){
  if(!MR_LETZT) return "";
  const {sub,r}=MR_LETZT; const w=mrS().w; const name=(MR_SUBS.find(s=>s[0]===sub)||["",""])[1];
  const ein=JSON.stringify(Object.assign({wohnung:{ort:w.ort,flaeche:w.flaeche,flaeche_vertrag:w.flaeche_vertrag,baujahr:w.baujahr,wohnlage:w.wohnlage,ausstattung:w.merkmale}},{eingaben:mrS()[sub]}),null,1);
  return `Du prüfst für Paul Görner (Immobilienmakler, Berlin) eine Mietberechnung. Heute ist der ${new Date().toLocaleDateString("de-DE")}. Nutze die Websuche und bevorzuge amtliche Quellen (gesetze-im-internet.de, berlin.de, mietspiegel.berlin.de, bravors.brandenburg.de, bundesgerichtshof.de, destatis.de). Erfinde nichts.

THEMA: ${name}
EINGABEN:
${ein}
ERGEBNIS DES RECHNERS (Rechtsstand ${MR_DATEN.stand}): ${mrKurz(sub,r)}
${sub==="me"?`Vergleichsmiete ${mrE(r.ovm)}, Kappung ${r.prozent} % (Ausgangsmiete ${mrE(r.ausgangsmiete)} am ${mrD(r.fenster)}), Zugang ${mrD(r.termine.zugang)}, Zustimmung bis ${mrD(r.termine.zustimmung_bis)}, wirksam ${mrD(r.termine.wirksam)}.`:""}${sub==="mo"?`Umlagefähig ${mrE(r.umlagefaehig)}, Satz ${r.satz} %, Kappung ${mrQ(r.grenze_qm)}, Rest ${mrE(r.rest)}, wirksam ${mrD(r.wirksam)}.`:""}${sub==="ix"?`VPI ${r.basis} → ${r.neu}, Änderung ${MR.zahl(r.aend)} %, wirksam ${mrD(r.wirksam)}.`:""}${sub==="nv"?`Grenze ${mrE(r.grenze)}, bester Weg: ${r.best[0]} = ${mrE(r.best[1])}${r.ausnahme?", Ausnahme: "+r.ausnahme:""}.`:""}

AUFGABE:
1. Prüfe, ob Rechenweg, Fristen und Grenzen nach dem heute geltenden Recht stimmen (BGB, Landesverordnungen Berlin/Brandenburg, Mietspiegel). Nenne Abweichungen konkret mit Betrag/Datum.
2. Gibt es seit ${MR_DATEN.stand} neue Gesetze, Verordnungen, einen neuen Mietspiegel oder BGH-Urteile, die das Ergebnis ändern?
3. Welche Risiken oder fehlenden Angaben sollte Paul vor dem Versand klären?
Antworte kurz und auf Deutsch, mit Quellenlinks.`;
}
async function mrPromptKopieren(){ const p=mrPrompt(); if(!p) return; const ok=await kopieren(p,"Prüf-Prompt kopiert ✓ – in Claude oder ChatGPT einfügen"); if(!ok) modal("Prompt",`<textarea style="min-height:300px;font-size:11px;">${esc(p)}</textarea>`); }
async function mrKiPruefen(){
  const p=mrPrompt(); if(!p) return;
  modal("🤖 Prüfung", `<div class="hinweis">Claude prüft mit Websuche – dauert etwa 30–90 Sekunden …</div><div id="kiLaeuft" style="margin-top:14px;">⏳ läuft …</div>`);
  try{ const erg=await kiLauf(p,{suchen:6,abrufe:8,max_tokens:6000});
    $("modalInhalt").innerHTML=`<div class="flex"><h2>🤖 Prüfung</h2><span class="spacer"></span><button class="ghost" onclick="modalZu()">✕</button></div><div class="md">${md(erg.text)}</div>${quellenHtml(erg.quellen)}`;
  }catch(e){ const el=$("kiLaeuft"); if(el) el.innerHTML=`<span class="neg">⚠️ ${esc(e.message)}</span><div class="hinweis" style="margin-top:8px;">Über „📋 Prüf-Prompt“ geht es auch ohne API.</div>`; }
}

// ── Wohnlage automatisch (Geodienst Berlin, Straßenverzeichnis zum Mietspiegel) – experimentell ──
async function mrAbrufText(url){ const r=HOST&&HOST.abruf?await HOST.abruf(url):null; if(!r||!r.ok) throw new Error(r&&r.fehler?r.fehler:"HTTP "+(r&&r.status)); return r.text; }
function mrLageAus(p){
  for(const [k,v] of Object.entries(p||{})){ if(!/^(wol|wohnlage|lage|wl)$/i.test(k)&&!/wohnlage/i.test(k)) continue; const t=String(v||"").toLowerCase().trim();
    if(/^e$|einf/.test(t)) return "einfach"; if(/^m$|mittl|mittel/.test(t)) return "mittel"; if(/^g$|gut/.test(t)) return "gut"; }
  return null;
}
async function mrWohnlageAuto(){
  const w=mrS().w; const adr=[w.adresse,w.ort].filter(Boolean).join(", ");
  if(!w.adresse){ toast("Bitte erst die Adresse (Straße und Hausnummer) eintragen"); return; }
  toast("🛰️ Suche Wohnlage …",6000);
  try{
    const g=await geokodieren(adr);
    if(!/berlin/i.test(g.land)) throw new Error("Adresse liegt nicht in Berlin – der Berliner Mietspiegel gilt dort nicht");
    const [x,y]=utm33(g.lat,g.lon); const hnr=(String(w.adresse).match(/(\d+\s*[a-z]?)\s*$/i)||[])[1];
    let fehler="";
    for(const jahr of [2026,2024]){
      const basis=`https://gdi.berlin.de/services/wfs/wohnlagenadr${jahr}`;
      try{
        let typ=`wohnlagenadr${jahr}:wohnlagenadr${jahr}`;
        try{ const cap=await mrAbrufText(basis+"?SERVICE=WFS&REQUEST=GetCapabilities&VERSION=2.0.0"); const m=/<(?:wfs:)?FeatureType[^>]*>[\s\S]*?<(?:wfs:)?Name>([^<]+)<\/(?:wfs:)?Name>/i.exec(cap); if(m) typ=m[1].trim(); }catch(e){}
        const d=40; const url=`${basis}?SERVICE=WFS&VERSION=2.0.0&REQUEST=GetFeature&TYPENAMES=${encodeURIComponent(typ)}&OUTPUTFORMAT=application/json&COUNT=50&BBOX=${(x-d).toFixed(1)},${(y-d).toFixed(1)},${(x+d).toFixed(1)},${(y+d).toFixed(1)},urn:ogc:def:crs:EPSG::25833`;
        const j=JSON.parse(await mrAbrufText(url)); const fs=(j.features||[]).filter(f=>f&&f.properties&&mrLageAus(f.properties));
        if(!fs.length){ fehler="keine Adresse in der Nähe gefunden"; continue; }
        const dist=f=>{ const c=f.geometry&&f.geometry.coordinates; return Array.isArray(c)&&typeof c[0]==="number"?Math.hypot(c[0]-x,c[1]-y):999; };
        const passend=hnr?fs.filter(f=>String(f.properties.hnr||f.properties.hausnummer||"").replace(/\s/g,"").toLowerCase()===hnr.replace(/\s/g,"").toLowerCase()):[];
        const best=(passend.length?passend:fs).sort((a,b)=>dist(a)-dist(b))[0]; const p=best.properties;
        const lage=mrLageAus(p);
        w.wohnlage=lage; w.wohnlage_quelle=`${jahr===2026?"Straßenverzeichnis 2026":"Wohnlagen 2024 – für 2026 prüfen"}: ${[p.strasse,p.hnr].filter(Boolean).join(" ")||"nächste Adresse"}${passend.length?"":" (Hausnr. nicht exakt)"}`;
        speichern(); mrNeu(); toast(`Wohnlage ${lage} übernommen (${jahr})${jahr!==2026?" – bitte für 2026 prüfen":""}`,4500); return;
      }catch(e){ fehler=e.message; }
    }
    throw new Error(fehler||"nicht gefunden");
  }catch(e){ toast("Wohnlage nicht automatisch gefunden ("+e.message+") – bitte nachschlagen",5500); }
}

// ── Leerstand-Rechner ──
function mrLsVorschlag(){
  const b=mrBasis(); const ls=mrS().ls; let ovm=F(ls.ovm_qm);
  if(!ovm){ try{ ovm=MR.vergleichsmiete(b).qm; }catch(e){ toast("Erst Vergleichsmiete ermitteln (Baujahr, Wohnlage) oder €/m² eintragen"); return; } }
  const fl=F(b.flaeche); if(!fl){ toast("Wohnfläche fehlt"); return; }
  ls.miete_sofort=MR.zahl(MR.r(ovm*fl)); ls.miete_spaeter=MR.zahl(MR.r(ovm*fl*1.1)); if(!ls.leer_monate) ls.leer_monate="3";
  speichern(); mrNeu();
}
function mrLsKurve(r){
  const a=r.kumA,b=r.kumB,n=a.length; const alle=a.concat(b); const max=Math.max(...alle,1), min=Math.min(...alle,0);
  const x=i=>30+i*(550/Math.max(n-1,1)), y=v=>170-(v-min)/((max-min)||1)*150;
  return `<svg viewBox="0 0 600 195" style="width:100%;height:auto;margin-top:8px;">
    <line x1="30" y1="${y(0)}" x2="580" y2="${y(0)}" stroke="var(--border)"/>
    <polyline fill="none" stroke="var(--blue)" stroke-width="2.5" points="${a.map((v,i)=>x(i)+","+y(v)).join(" ")}"/>
    <polyline fill="none" stroke="var(--orange)" stroke-width="2.5" points="${b.map((v,i)=>x(i)+","+y(v)).join(" ")}"/>
    <text x="30" y="190" fill="var(--muted)" font-size="11">heute</text><text x="580" y="190" fill="var(--muted)" font-size="11" text-anchor="end">${r.jahre} Jahre</text>
    <text x="34" y="${y(max)+4}" fill="var(--muted)" font-size="11">${MR.zahl(max,0)} € kumuliert</text>
  </svg><div class="flex klein" style="flex-wrap:wrap;"><span><span style="display:inline-block;width:10px;height:3px;background:var(--blue);vertical-align:middle;"></span> A sofort ${mrE(r.m1)}</span><span><span style="display:inline-block;width:10px;height:3px;background:var(--orange);vertical-align:middle;"></span> B nach ${r.L} Mon. ${mrE(r.m2)}</span></div>`;
}
function mrLsHtml(r){
  const gewinnt=r.diff>=0; const ev=(l)=>l.filter(e=>e.art!=="start").slice(0,5).map(e=>`${e.art==="558"?"§ 558":"Mieterwechsel"} nach ${Math.round(e.t/12*10)/10} J. → ${mrE(MR.r(e.miete))}`).join("<br>")||"–";
  return `<div class="karte"><h2>⏳ Ergebnis <span class="rechts badge ${gewinnt?"b-gruen":"b-rot"}">${gewinnt?"Warten lohnt rechnerisch":"Sofort vermieten ist besser"}</span></h2>
    ${r.warn.length?`<div class="karte" style="border-left:3px solid var(--red);margin-bottom:10px;">${r.warn.map(w=>`<div class="klein" style="margin:3px 0;">⚠️ ${esc(w)}</div>`).join("")}</div>`:""}
    <div class="grid g2" style="gap:10px;">
      ${mrBox("A: sofort vermieten",mrE(r.npvA),`Barwert ${r.jahre} J. · Summe ${mrE(r.sumA)}`)}
      ${mrBox(`B: ${r.L} Monate leer`,mrE(r.npvB),`Barwert ${r.jahre} J. · Summe ${mrE(r.sumB)}`)}
      ${mrBox("Unterschied (B − A)",(r.diff>=0?"+":"")+mrE(r.diff),gewinnt?"zugunsten Leerstand":"zugunsten sofort",gewinnt?"pos":"neg")}
      ${mrBox("Lohnt sich bis",MR.zahl(r.breakEven,1).replace(",0","")+" Leermonate","bei dieser Wunschmiete (Barwert)")}
    </div>
    <table class="t" style="margin-top:10px;">
      <tr><td>Kosten des Leerstands</td><td class="z">${mrE(r.verlustLeer)} <span class="hinweis">(${r.L} × (${mrE(r.m1)} entgangene Miete + ${mrE(r.kosten)} Leerkosten)${r.einmal?" + "+mrE(r.einmal):""})</span></td></tr>
      <tr><td>Mehrmiete pro Monat</td><td class="z">${mrE(r.diffMonat)}</td></tr>
      <tr><td>Faustregel: aufgeholt nach</td><td class="z">${r.einfachBreakEven===null?"nie":Math.ceil(r.einfachBreakEven)+" Monaten"} <span class="hinweis">(ohne spätere Erhöhungen)</span></td></tr>
      <tr><td>Mit § 558 tatsächlich aufgeholt</td><td class="z">${r.aufholMonat?"nach "+r.aufholMonat+" Monaten":"nicht innerhalb von "+r.jahre+" Jahren"}</td></tr>
      <tr><td>Verlauf A</td><td class="klein">${ev(r.ereignisseA)}</td></tr>
      <tr><td>Verlauf B</td><td class="klein">${ev(r.ereignisseB)}</td></tr>
    </table>
    ${mrLsKurve(r)}
    <div class="hinweis" style="margin-top:8px;">Annahmen: Vergleichsmiete ${mrQ(r.ovm_qm)} (+${mrP(r.annahmen.ovm_wachstum)} p. a.${r.annahmen.stufig?`, neuer Mietspiegel in ${r.annahmen.naechster} Monaten, dann alle 2 Jahre`:""})${r.v?` · Feld ${r.v.feld.zeile}`:""}, Kappung ${mrP(r.annahmen.kappung,0)}, ${r.annahmen.mietdauer?`Mieterwechsel alle ${MR.zahl(r.annahmen.mietdauer,1)} J. (${r.annahmen.wechsel_leer} Monat leer)`:"kein Mieterwechsel"}, Ausfall A ${mrP(r.annahmen.ausfallA)} / B ${mrP(r.annahmen.ausfallB)}, Zins ${mrP(r.zins)}, Steuer ${mrP(r.steuer,0)}, Mietpreisbremse ${r.bremse?"ja (Grenze heute "+mrE(r.grenze)+")":"nein"}.</div>
    ${mrHinweise(["Wichtig: Eine Miete über der Vergleichsmiete wird bei § 558 erst erhöht, wenn die Vergleichsmiete sie eingeholt hat – eine niedrigere Startmiete holt durch die Erhöhungen oft auf.","Umgekehrt: Wer günstiger startet, senkt seine geschützte Vormiete (§ 556e) und kommt pro 3 Jahre höchstens 15 % hoch (Kappung).","Szenario-Rechnung mit Annahmen – keine Prognose und keine Rechtsberatung."])}
    ${mrAktionen()}
  </div>`;
}
