/* Leerstand-Rechner: „x Monate leer lassen für höhere Miete“ gegen „sofort (etwas günstiger) vermieten“.
   Monatsgenaue Simulation über einen Horizont mit § 558-Erhöhungen (Kappung, 15-Monats-Sperre, Vergleichsmiete),
   Mieterwechseln (Vormiete-Schutz § 556e), Leerkosten, Mietausfallrisiko, Steuern und Abzinsung. Rechenhilfe, keine Rechtsberatung. */
(function(root){
"use strict";
const MR=root.MR, MD=root.MR_DATEN;
const f=MR.f, r=MR.r;
function std(k,d){ const L=(MD.leerstand||{}); return L[k]!==undefined?L[k]:d; }

function pfad(o){
  // o: {start (Monat Mietbeginn), miete0, monate, fl, ovm0Qm, ovmWachstum, kappung, wechselMonate, wechselLeer, bremse, ausfall}
  const N=o.monate, rent=new Array(N).fill(0), ereignisse=[];
  let akt=0, beginn=o.start, letzteAend=o.start, mieteBeiBeginn=o.miete0, vormiete=0;
  // Qualifizierter Mietspiegel: Vergleichsmiete springt alle 24 Monate (erste Stufe beim nächsten Mietspiegel)
  const ovm=t=>{ if(!o.stufig) return o.ovm0Qm*o.fl*Math.pow(1+o.ovmWachstum,t/12);
    const n = t<o.naechster ? 0 : 1+Math.floor((t-o.naechster)/24); return o.ovm0Qm*o.fl*Math.pow(1+o.ovmWachstum,2*n); };
  const verlauf=[];   // Miete je Monat innerhalb des laufenden Mietverhältnisses
  for(let t=0;t<N;t++){
    if(t<o.start){ rent[t]=0; continue; }
    if(t===o.start){ akt=o.miete0; beginn=t; letzteAend=t; verlauf.length=0; ereignisse.push({t,art:"start",miete:akt}); }
    // Mieterwechsel
    if(o.wechselMonate>0 && t>o.start && (t-beginn)>=o.wechselMonate && t+0<N){
      vormiete=akt;
      const leer=o.wechselLeer||0;
      const grenze = o.bremse ? ovm(t)*1.1 : (o.marktAufschlag!==undefined? ovm(t)*(1+o.marktAufschlag) : ovm(t)*1.1);
      const neu=Math.max(grenze, vormiete);
      ereignisse.push({t,art:"wechsel",miete:neu,vormiete,leer});
      // Leerzeit beim Wechsel (in beiden Szenarien gleich lang)
      for(let k=0;k<leer&&t+k<N;k++){ rent[t+k]=0; }
      t+=leer; if(t>=N) break;
      akt=neu; beginn=t; letzteAend=t; verlauf.length=0;
    }
    // § 558: frühestens 15 Monate nach Beginn/letzter Erhöhung; Kappung auf Miete vor 36 Monaten (innerhalb des Mietverhältnisses)
    if(t-letzteAend>=15){
      const idx=t-36-beginn; const basis = idx>=0 ? verlauf[idx] : verlauf[0]!==undefined?verlauf[0]:akt;
      const ziel=Math.min(ovm(t), basis*(1+o.kappung));
      if(ziel>akt+0.5){ akt=ziel; letzteAend=t; ereignisse.push({t,art:"558",miete:akt}); }
    }
    verlauf.push(akt);
    rent[t]=akt*(1-(o.ausfall||0));
  }
  return {rent, ereignisse};
}

function naechsterMs(){ const n=MR.datum(std("naechster_mietspiegel","2028-05-01")), h=MR.heute(); return Math.max(0,(n.y-h.y)*12+(n.m-h.m)); }
function leerstand(a){
  const fl=f(a.flaeche); const m1=f(a.miete_sofort), m2=f(a.miete_spaeter);
  const L=Math.max(0,Math.round(f(a.leer_monate)||0));
  if(!fl||!m1||!m2) throw Object.assign(new Error("Wohnfläche, Miete bei sofortiger Vermietung und Wunschmiete nach dem Leerstand angeben."),{fachlich:true});
  const jahre=Math.max(1,Math.min(30,f(a.jahre)||std("jahre",10))), N=Math.round(jahre*12);
  const g=MR.gebiet(a.ort||"Berlin");
  const bremse = a.bremse!==undefined ? !!a.bremse : (!!g.bremse && !a.neubau_ab_2014);
  let ovmQm=f(a.ovm_qm), v=null;
  if(!ovmQm && a.baujahr && a.wohnlage){ try{ v=MR.vergleichsmiete(a); ovmQm=v.qm; }catch(e){} }
  if(!ovmQm) ovmQm=Math.max(m1,m2)/fl/1.1;                       // Notlösung: Wunschmiete = Grenze
  const pct=(k,d)=>{ const x=f(a[k]); return (x===null?d:x)/100; };
  const o={monate:N,fl,ovm0Qm:ovmQm,ovmWachstum:pct("ovm_wachstum",std("ovm_wachstum",3.4)),kappung:pct("kappung_prozent",g.kappung||20),
    wechselMonate:Math.round((f(a.mietdauer_jahre)??std("mietdauer_jahre",0))*12),wechselLeer:Math.round(f(a.wechsel_leer_monate)??std("wechsel_leer_monate",1)),bremse,
    stufig: a.stufig!==undefined ? !!a.stufig : g.land==="Berlin", naechster: naechsterMs()};
  const kosten=f(a.leerkosten)??std("leerkosten_qm",2.68)*fl;                 // €/Monat, solange leer
  const einmal=f(a.einmalkosten)||0;
  const zins=pct("zins",std("zins",3)), steuer=pct("steuersatz",0);
  const ausA=pct("ausfall_sofort",std("ausfall",0)), ausB=pct("ausfall_spaeter",std("ausfall",0));
  const A=pfad(Object.assign({},o,{start:0,miete0:m1,ausfall:ausA}));
  const B=pfad(Object.assign({},o,{start:L,miete0:m2,ausfall:ausB}));
  const ab=t=>1/Math.pow(1+zins,(t+1)/12);
  let npvA=0,npvB=0,sumA=0,sumB=0,aufholMonat=null; const kumA=[],kumB=[];
  for(let t=0;t<N;t++){
    let cA=A.rent[t], cB=B.rent[t];
    if(t<L) cB-=kosten; if(t===0) cB-=einmal;
    cA*=(1-steuer); cB*=(1-steuer);
    sumA+=cA; sumB+=cB; npvA+=cA*ab(t); npvB+=cB*ab(t); kumA.push(sumA); kumB.push(sumB);
    if(aufholMonat===null && t>=L && sumB>=sumA) aufholMonat=t+1;
  }
  // Break-even: wie viele Leermonate wären maximal sinnvoll (Barwert B ≥ A)?
  let breakEven=0, vorher=null;
  for(let l=0;l<=36;l++){
    const Bl=pfad(Object.assign({},o,{start:l,miete0:m2,ausfall:ausB})); let n=0;
    for(let t=0;t<N;t++){ let c=Bl.rent[t]; if(t<l) c-=kosten; if(t===0) c-=einmal; n+=c*(1-steuer)*ab(t); }
    if(n>=npvA){ breakEven=l; vorher=n; }
    else { if(vorher!==null && vorher>n) breakEven=Math.round((l-1+(vorher-npvA)/(vorher-n))*10)/10; break; }
    if(l===36) breakEven=36;
  }
  // Recht
  const warn=[], grenzeHeute=r(ovmQm*fl*1.1);
  const zw = g.land==="Berlin" ? {mon:3,text:"Berlin (Zweckentfremdungsverbot-Gesetz)",bussgeld:[1500,2500],max:"500.000 €"}
           : (g.gemeinde==="Potsdam" ? {mon:6,text:"Potsdam (Zweckentfremdungssatzung seit 30.04.2026)",bussgeld:null,max:"100.000 €"} : null);
  if(zw && L>zw.mon) warn.push(`${zw.text}: Leerstand von mehr als ${zw.mon} Monaten ist Zweckentfremdung – erlaubt nur bei nachweisbar ernsthaften, erfolglosen Vermietungsbemühungen oder zügiger Sanierung. Höchstmögliche Rendite oder Verkaufsabsicht rechtfertigen keinen Leerstand (VG Berlin 6 K 251/22).${zw.bussgeld?` Bußgeld in der Regel ${MR.zahl(zw.bussgeld[0],0)}–${MR.zahl(zw.bussgeld[1],0)} € je Monat und Wohnung – hier grob ${MR.e((L-zw.mon)*zw.bussgeld[0])} bis ${MR.e((L-zw.mon)*zw.bussgeld[1])}`:""}, in schweren Fällen bis ${zw.max}.`);
  else if(!zw && g.land==="Brandenburg" && L>6) warn.push("Brandenburg: Gemeinden dürfen per Satzung Leerstand über 6 Monate verbieten (Bußgeld bis 100.000 €) – Satzung der Gemeinde prüfen.");
  if(L>0) warn.push("Grundsteuer: Einen Erlass wegen Leerstand gibt es nicht, wenn du den Leerstand selbst zu vertreten hast (z. B. zu hohe Wunschmiete).");
  if(bremse && m2>grenzeHeute+0.005) warn.push(`Mietpreisbremse: ${MR.e(m2)} liegt über Vergleichsmiete + 10 % (${MR.e(grenzeHeute)}). Ohne Ausnahme (höhere Vormiete, Modernisierung, Neubau ab 10/2014) ist das nicht zulässig – Warten erhöht die Grenze nur, wenn ein neuer Mietspiegel kommt.`);
  if(bremse && m1>grenzeHeute+0.005) warn.push(`Auch ${MR.e(m1)} liegt über der Mietpreisbremse (${MR.e(grenzeHeute)}).`);
  if(m2>ovmQm*fl*1.2) warn.push(`${MR.e(m2)} ist mehr als 20 % über der Vergleichsmiete – Risiko Mietpreisüberhöhung (§ 5 WiStG, Bußgeld bis 50.000 €); ab etwa 50 % Mietwucher (§ 291 StGB).`);
  if(L>0) warn.push("Steuer: Werbungskosten während des Leerstands nur absetzbar, wenn du ernsthaft und nachweisbar vermieten willst (Inserate, Besichtigungen dokumentieren). Wer bewusst zu teuer anbietet, riskiert, dass das Finanzamt die Vermietungsabsicht verneint.");
  if(m1<ovmQm*fl*std("verbilligt_grenze",0.66)) warn.push(`Steuer: ${MR.e(m1)} liegt unter 66 % der ortsüblichen Miete – verbilligte Vermietung (§ 21 Abs. 2 EStG), Werbungskosten nur noch anteilig (unter 50 %).`);
  const diffMonat=m2-m1;
  return {flaeche:fl,m1,m2,L,jahre,ovm_qm:ovmQm,v,gebiet:g,bremse,grenze:grenzeHeute,kosten:r(kosten),einmal,zins:zins*100,steuer:steuer*100,
    npvA:r(npvA),npvB:r(npvB),diff:r(npvB-npvA),sumA:r(sumA),sumB:r(sumB),aufholMonat,breakEven,
    verlustLeer:r(L*m1+L*kosten+einmal),diffMonat:r(diffMonat),einfachBreakEven: diffMonat>0? r((m1+kosten)*L/diffMonat):null,
    ereignisseA:A.ereignisse,ereignisseB:B.ereignisse,kumA:kumA.filter((x,i)=>i%3===2||i===N-1).map(r),kumB:kumB.filter((x,i)=>i%3===2||i===N-1).map(r),
    warn, annahmen:{stufig:o.stufig,naechster:o.naechster,ovm_wachstum:o.ovmWachstum*100,kappung:o.kappung*100,mietdauer:o.wechselMonate/12,wechsel_leer:o.wechselLeer,ausfallA:ausA*100,ausfallB:ausB*100}};
}
MR.leerstand=leerstand;
})(typeof window!=="undefined"?window:globalThis);
