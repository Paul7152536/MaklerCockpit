/* Mietrechner Berlin/Brandenburg – Rechenkern (Port aus addon_miete.py, Jarvis)
   Rechenhilfe, keine Rechtsberatung. Alle Funktionen deterministisch: gleiche Eingaben + gleicher Datenstand = gleiches Ergebnis. */
(function(root){
"use strict";
const MD = root.MR_DATEN;            // Mietspiegel, Merkmale, VPI, Gebiete, Wissen …
let HEUTE_OVERRIDE = null;           // für Tests
let VPI_EXTRA = {};                  // vom Nutzer nachgetragene VPI-Werte {"2026-10":126.9}

// ── Geld ──
// kaufmännisch auf Cent (wie Decimal ROUND_HALF_UP); kleine Toleranz gegen Fließkomma-Fehler
function r(x){ if(x===null||x===undefined||!isFinite(x)) return x; const s=x<0?-1:1; return s*Math.round(Math.abs(x)*100+1e-7)/100; }
function zahl(x,n=2){ if(x===null||x===undefined||!isFinite(x)) return "–"; return x.toLocaleString("de-DE",{minimumFractionDigits:n,maximumFractionDigits:n}); }
const e = x => (x===null||x===undefined) ? "–" : zahl(x)+" €";
const q = x => (x===null||x===undefined) ? "–" : zahl(x)+" €/m²";
function p(x,n=2){ let t=zahl(x,n); if(t.includes(",")) t=t.replace(/0+$/,"").replace(/,$/,""); return t+" %"; }
function m2(x){ return zahl(x,2).replace(/0+$/,"").replace(/,$/,"")+" m²"; }
function f(x){
  if(x===null||x===undefined||x==="") return null;
  if(typeof x==="number") return isFinite(x)?x:null;
  if(typeof x==="boolean") return null;
  let s=String(x).replace(/[^\d,.\-]/g,""); if(!s) return null;
  if(s.includes(",")) s=s.replace(/\./g,"").replace(",",".");
  else if((s.match(/\./g)||[]).length>1 || /^-?\d{1,3}\.\d{3}$/.test(s)) s=s.replace(/\./g,"");
  const n=Number(s); return isFinite(n)?n:null;
}

// ── Datum (reine Kalendertage, ohne Zeitzone) ──
const MONATE=["Januar","Februar","März","April","Mai","Juni","Juli","August","September","Oktober","November","Dezember"];
function D(y,m,d){ return {y,m,d}; }
function tageImMonat(y,m){ return new Date(Date.UTC(y,m,0)).getUTCDate(); }
function cmp(a,b){ return (a.y-b.y)||(a.m-b.m)||(a.d-b.d); }
const lt=(a,b)=>cmp(a,b)<0, le=(a,b)=>cmp(a,b)<=0;
function maxD(...xs){ return xs.reduce((a,b)=>cmp(a,b)>=0?a:b); }
function plusMonate(d,n){ const t=d.m-1+n; const y=d.y+Math.floor(t/12), m=((t%12)+12)%12+1; return D(y,m,Math.min(d.d,tageImMonat(y,m))); }
const erster = d => D(d.y,d.m,1);
const ende = d => D(d.y,d.m,tageImMonat(d.y,d.m));
const naechsterErster = d => d.d===1 ? d : plusMonate(erster(d),1);
const de = d => d ? String(d.d).padStart(2,"0")+"."+String(d.m).padStart(2,"0")+"."+d.y : "–";
const iso = d => d ? d.y+"-"+String(d.m).padStart(2,"0")+"-"+String(d.d).padStart(2,"0") : "";
const monatDe = d => MONATE[d.m-1]+" "+d.y;
function heute(){ if(HEUTE_OVERRIDE) return HEUTE_OVERRIDE; const n=new Date(); return D(n.getFullYear(),n.getMonth()+1,n.getDate()); }
function datum(x){
  if(x===null||x===undefined||x==="") return null;
  if(typeof x==="object" && x.y) return x;
  const s=String(x).trim().toLowerCase(); let m;
  for(let i=0;i<12;i++){ const n=MONATE[i].toLowerCase(); if(s.startsWith(n)||s.startsWith(n.slice(0,3)+" ")){ const j=s.match(/(\d{4})/); return j?D(+j[1],i+1,1):null; } }
  if((m=s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/))) return D(+m[1],+m[2],+m[3]);
  if((m=s.match(/^(\d{4})-(\d{1,2})$/))) return D(+m[1],+m[2],1);
  if((m=s.match(/^(\d{1,2})\.(\d{1,2})\.(\d{2,4})$/))) return D(+m[3]+(m[3].length===2?2000:0),+m[2],+m[1]);
  if((m=s.match(/^(\d{1,2})[./](\d{4})$/))) return D(+m[2],+m[1],1);
  return null;
}
// Feiertage Berlin/Brandenburg (für § 193 BGB)
function ostern(j){ const a=j%19,b=Math.floor(j/100),c=j%100,d=Math.floor(b/4),e2=b%4,f2=Math.floor((b+8)/25),g2=Math.floor((b-f2+1)/3),h2=(19*a+b-d-g2+15)%30,i=Math.floor(c/4),k=c%4,l=(32+2*e2+2*i-h2-k)%7,m=Math.floor((a+11*h2+22*l)/451),mo=Math.floor((h2+l-7*m+114)/31),ta=((h2+l-7*m+114)%31)+1; return D(j,mo,ta); }
function plusTage(d,n){ const x=new Date(Date.UTC(d.y,d.m-1,d.d+n)); return D(x.getUTCFullYear(),x.getUTCMonth()+1,x.getUTCDate()); }
function feiertage(j,land){ const o=ostern(j); const l=[D(j,1,1),plusTage(o,-2),plusTage(o,1),D(j,5,1),plusTage(o,39),plusTage(o,50),D(j,10,3),D(j,12,25),D(j,12,26)];
  if(land==="Brandenburg") l.push(D(j,10,31)); else l.push(D(j,3,8)); return new Set(l.map(x=>x.y+"-"+x.m+"-"+x.d)); }
function wochentag(d){ return new Date(Date.UTC(d.y,d.m-1,d.d)).getUTCDay(); }
function werktag(d,land){ let x=d; const fs=new Set([...feiertage(d.y,land),...feiertage(d.y+1,land)]); while(wochentag(x)===0||wochentag(x)===6||fs.has(x.y+"-"+x.m+"-"+x.d)) x=plusTage(x,1); return x; }
function fehler(t){ const x=new Error(t); x.fachlich=true; return x; }

// ── Gebiet ──
function norm(s,klammernWeg){ s=String(s||"").toLowerCase(); if(klammernWeg) s=s.replace(/\(.*?\)/g," "); s=s.replace(/\bbei berlin\b|\bstadt\b|\bgemeinde\b/g," "); return s.replace(/[^a-zäöüß0-9]+/g," ").trim(); }
function wort(w,t){ const re=new RegExp("(?<![a-zäöüß])"+w.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")+"(?![a-zäöüß])"); const m=re.exec(t); return m; }
function bbGemeinde(o){
  let best=null;
  for(const g of MD.gebiete.bb_gemeinden){
    const name=norm(g,true);
    for(const tok of [name].concat(name.split(" ").filter(t=>t.length>=5))){ const m=wort(tok,o); if(m && (best===null||m.index<best[0])) best=[m.index,g]; }
  }
  return best?best[1]:null;
}
function istBerlin(ort){ const o=norm(ort); if(/\b(1[0-3]\d{3}|14[01]\d{2})\b/.test(o)) return true; return MD.gebiete.berlin_bezirke.concat(MD.gebiete.ost,MD.gebiete.west).some(b=>wort(b,o)); }
const inZeit = (vo,t) => vo && le(datum(vo.von),t) && le(t,datum(vo.bis));
function bbGemeindeIn(o,liste){ const alt=MD.gebiete.bb_gemeinden; MD.gebiete.bb_gemeinden=liste; try{ return bbGemeinde(o); } finally{ MD.gebiete.bb_gemeinden=alt; } }
function istBrandenburg(ort){ const s=String(ort||"").toLowerCase(); const o=norm(ort);
  if(/\b(14[2-9]\d{2}|1[56]\d{3})\b/.test(o)) return true;
  if(/\bbrandenburg\b|\(mark\)/.test(s)) return true;
  return MD.gebiete.landkreise.filter(k=>k.trim().length>4&&k!=="landkreis").some(k=>o.includes(k)); }
/* Regel je Land, Art (kappung/bremse), Gemeinde und Stichtag. Ohne passende Regel innerhalb der geprüften
   Zeiträume gilt das Gesetz (20 % / keine Bremse); außerhalb → Status „pruefen“ statt stillem Rückfall. */
function regelFinden(land,art,gemeinde,t){
  const G=MD.gebiete; const R=G.regeln||[];
  const liste=k=>k==="alle"?null:(k==="bb2021"?G.bb_gemeinden_2021:G.bb_gemeinden)||[];
  const r=R.find(x=>x.land===land&&x.art===art&&inZeit(x,t)&&(x.gemeinden==="alle"||liste(x.gemeinden).includes(gemeinde)));
  const ab=(G.abdeckung||{})[land]||{}; const fenster=ab[art];
  const gedeckt = fenster ? (le(datum(fenster[0]),t)&&le(t,datum(fenster[1]))) : false;
  return {r, gedeckt};
}
function gebiet(ort,stichtag){
  const t=stichtag||heute(); let o=norm(ort);
  for(const k of MD.gebiete.landkreise) o=o.split(k).join(" ");
  const G=MD.gebiete;
  let land="", gem=null;
  if(!wort("berlin",o)){ gem=bbGemeinde(o) || (G.bb_gemeinden_2021?bbGemeindeIn(o,G.bb_gemeinden_2021):null); if(gem) land="Brandenburg"; }
  if(!land && istBerlin(ort)){ land="Berlin"; gem="Berlin"; }
  if(!land && istBrandenburg(ort)){ land="Brandenburg"; gem=null; }
  if(!land) return {ort:ort||"unbekannt", land:"", kappung:20, kappung_vo:null, bremse:null, bremse_vo:null, bekannt:false, status:"pruefen",
    pruefen_text:"Ort nicht hinterlegt (nur Berlin und Brandenburg) – Landesverordnung prüfen.", hinweise:[]};
  const hinweise=[]; let status="ok"; const texte=[];
  const k=regelFinden(land,"kappung",gem,t), b=regelFinden(land,"bremse",gem,t);
  for(const [x,name] of [[k,"Kappungsgrenze"],[b,"Mietpreisbremse"]]){
    if(x.r&&x.r.unsicher) hinweise.push(name+": "+x.r.unsicher);
    if(!x.r&&!x.gedeckt){ status="pruefen"; texte.push(`${name}: Für den ${de(t)} ist keine geprüfte Verordnung hinterlegt – ich rechne mit dem Gesetz (${name==="Kappungsgrenze"?"20 %":"keine Bremse"}), bitte prüfen.`); }
  }
  const anzeige = land==="Berlin"?"Berlin":(gem||String(ort).trim()||"Brandenburg");
  if(land==="Brandenburg" && !gem) hinweise.push("Gemeinde steht in keiner Brandenburger Verordnung (2026: 36 Gemeinden, 2021–2025: 19) – gesetzlich 20 % und keine Mietpreisbremse.");
  if(land==="Brandenburg" && gem && (G.bb_weggefallen||[]).includes(gem) && !k.r) hinweise.push(`${gem} war 2021–2025 in den Verordnungen, seit 01.01.2026 nicht mehr.`);
  return {ort:anzeige, land, gemeinde:gem, kappung: k.r?k.r.prozent:20, kappung_vo:k.r||null, bremse: !!b.r, bremse_vo:b.r||null, bekannt:true,
    status, pruefen_text:texte.join(" "), hinweise};
}
function ostWest(ort){ const o=norm(ort); if(o.includes("west staaken")) return true; if(MD.gebiete.ost.some(x=>wort(x,o))) return true; if(MD.gebiete.west.some(x=>wort(x,o))) return false; return null; }
function nurBerlin(ein,notizen){
  const ort=ein.ort||"";
  if(!ort.trim()){ ein.ort="Berlin"; if(notizen) notizen.push("Ort fehlte – ich habe Berlin angenommen."); return; }
  const g=gebiet(ort);
  if(g.land!=="Berlin" && !istBerlin(ort)) throw fehler(`Der Berliner Mietspiegel gilt nur in Berlin. Für ${ort} brauche ich die Vergleichsmiete (€/m²) aus dem dortigen Mietspiegel, aus Vergleichswohnungen oder einem Gutachten.`);
}

// ── Mietspiegel ──
const FELDER = MD.mietspiegel.felder.map(([zeile,lage,klasse,von,bis,u,m,o])=>({zeile,lage,klasse,von,bis,u,m,o}));
function flaechentext(F){ if(F.von===0&&F.bis===null) return "alle Wohnflächen"; if(F.von===0) return `unter ${F.bis} m²`; if(F.bis===null) return `ab ${F.von} m²`; return `${F.von} bis unter ${F.bis} m²`; }
function baualtersklasse(bj,ost,wende){
  const K=MD.mietspiegel.klassengrenzen;
  if(bj<=1918) return "1918"; if(bj<=1949) return "1949"; if(bj<=1964) return "1964"; if(bj<=1972) return "1972";
  if(bj<=1990){ if(ost===null||ost===undefined) throw fehler("Für Baujahre 1973–1990 brauche ich Ost oder West (Bezirk vor 2001, z. B. Lichtenberg = Ost, Spandau = West)."); return ost?"1990O":(bj<=1985?"1985W":"1990W"); }
  if(bj<=2001) return (wende&&ost)?"1990O":"2001"; if(bj<=2009) return "2009"; if(bj<=2015) return "2015"; if(bj<=2019) return "2019"; if(bj<=K.letztes_baujahr) return "2024";
  throw fehler(`Wohnungen, die ab 01.01.${K.letztes_baujahr+1} bezugsfertig wurden, fallen nicht unter den ${MD.mietspiegel.name} – Vergleichswohnungen oder Gutachten nötig. Wurde sie nach dem 01.10.2014 erstmals genutzt und vermietet, gilt die Mietpreisbremse nicht (§ 556f).`);
}
function lageKurz(w){ w=String(w||"").trim().toLowerCase(); for(const [k,v] of [["e","einfach"],["m","mittel"],["g","gut"]]) if(w.startsWith(v.slice(0,4))||w===k) return k; throw fehler("Wohnlage fehlt (einfach, mittel oder gut) – steht im Straßenverzeichnis zum Mietspiegel."); }
function feldFinden(bj,fl,lage,ost,wende){
  const kl=baualtersklasse(Math.trunc(bj),ost,wende), l=lageKurz(lage);
  const F=FELDER.find(x=>x.lage===l&&x.klasse===kl&&x.von<=fl&&(x.bis===null||fl<x.bis));
  if(!F) throw fehler(`Kein Mietspiegelfeld für ${kl}/${l}/${fl} m² gefunden.`);
  if(F.u===null||F.m===null) throw fehler(`Im Mietspiegelfeld ${F.zeile} gibt es keinen belastbaren Wert (zu wenige Daten) – Vergleichswohnungen oder Gutachten nötig.`);
  return F;
}
const GRUPPEN=["bad","kueche","wohnung","gebaeude","umfeld"];
function merkmalWert(v){ const s=String(v===null||v===undefined?"":v).trim().toLowerCase();
  if(["+","plus","positiv","1","besser","überwiegend positiv","ja"].includes(s)) return 1;
  if(["-","–","minus","negativ","-1","schlechter","überwiegend negativ"].includes(s)) return -1; return 0; }
function einordnen(F,merkmale){
  merkmale=merkmale||{}; const werte={}; GRUPPEN.forEach(g=>werte[g]=merkmalWert(merkmale[g]));
  const saldo=GRUPPEN.reduce((s,g)=>s+werte[g],0);
  const anteil=MD.mietspiegel.anteil_je_gruppe;   // 0,2
  let w; if(saldo>0) w=F.m+saldo*anteil*(F.o-F.m); else if(saldo<0) w=F.m+saldo*anteil*(F.m-F.u); else w=F.m;
  const text=GRUPPEN.map(g=>`${MD.mietspiegel.merkmale[g][0]}: ${werte[g]>0?"+":werte[g]<0?"−":"±0"}`);
  return [r(w),saldo,text,werte];
}
function vergleichsmiete(a){
  const fl=f(a.flaeche); if(!fl||fl<=0) throw fehler("Wohnfläche fehlt.");
  const bj=Math.trunc(f(a.baujahr)||0); if(!bj) throw fehler("Baujahr (Bezugsfertigkeit) fehlt.");
  if(a.gebaeudeart && /einfamil|zweifamil|reihenh|doppelh|\befh\b|\bzfh\b|\brh\b/.test(String(a.gebaeudeart).toLowerCase())) throw fehler("Ein-/Zweifamilien- und Reihenhäuser fallen nicht unter den Berliner Mietspiegel – Vergleichswohnungen oder Gutachten nötig.");
  const ort=a.ort||""; if(ort.trim()) nurBerlin({ort});
  let ost=a.ost; if(ost===undefined||ost===null||ost==="") ost=ostWest(ort); else ost=!!ost&&ost!=="false"&&ost!=="west";
  const F=feldFinden(bj,fl,a.wohnlage,ost,!!a.wendewohnung);
  let [qm,saldo,gruppen,werte]=einordnen(F,a.merkmale);
  const hinweise=[];
  if(a.minderausstattung){
    if(bj<=(MD.mietspiegel.minder_bis||1949)){ qm=r(qm-MD.mietspiegel.abschlag_minderausstattung); hinweise.push(`Abschlag ${zahl(MD.mietspiegel.abschlag_minderausstattung)} €/m² für Minderausstattung (ohne Sammelheizung und/oder Bad) – nicht Teil des qualifizierten Mietspiegels.`); }
    else if(bj<=(MD.mietspiegel.minder_pruefen_bis||0)) hinweise.push(`Abschlag für Minderausstattung habe ich nicht abgezogen: belegt ist er für 2026 bis Baujahr ${MD.mietspiegel.minder_bis||1949}; im Mietspiegel 2024 galt er bis 1964 (0,45 €/m²) – für 2026 in der Broschüre prüfen.`);
    else hinweise.push("Abschlag für Minderausstattung gilt nur für ältere Baujahre.");
  }
  if(!a.merkmale || !GRUPPEN.some(g=>merkmalWert(a.merkmale[g])!==0)) hinweise.push("Ohne Angaben zur Ausstattung habe ich den Mittelwert genommen. Für mehr: je Merkmalgruppe angeben, ob die positiven oder negativen Merkmale überwiegen.");
  let spanne=null; const offen=(a.merkmale_offen||[]).filter(g=>GRUPPEN.includes(g));
  if(offen.length){ const mk=Object.assign({},a.merkmale||{}); const lo=Object.assign({},mk), hi=Object.assign({},mk); offen.forEach(g=>{ lo[g]="-"; hi[g]="+"; });
    let mn=einordnen(F,lo)[0], mx=einordnen(F,hi)[0]; if(a.minderausstattung && bj<=(MD.mietspiegel.minder_bis||1949)){ mn=r(mn-MD.mietspiegel.abschlag_minderausstattung); mx=r(mx-MD.mietspiegel.abschlag_minderausstattung); }
    spanne={min:mn,max:mx,offen}; }
  return {feld:F, qm, monat:r(qm*fl), saldo, gruppen, werte, flaeche:fl, baujahr:bj, hinweise, ost, spanne, ausgabe:MD.mietspiegel.name};
}

// ── Mieterhöhung § 558 ──
function historie(a){
  const notizen=[], h=[];
  for(const x of (a.historie||[])){ const d=datum(x.ab), m=f(x.miete); if(d&&m) h.push({ab:d,miete:m,art:String(x.art||"558").toLowerCase()}); }
  if(!h.length){
    const miete=f(a.miete), vorher=f(a.miete_vorher), beginn=datum(a.mietbeginn), anfang=f(a.anfangsmiete), letzte=datum(a.letzte_erhoehung_ab);
    if(beginn) h.push({ab:beginn, miete: anfang || (letzte?vorher:miete) || miete, art:"beginn"});
    if(letzte){
      if(!beginn){
        if(vorher===null) notizen.push("Miete vor der letzten Erhöhung fehlt – für die Kappungsgrenze nehme ich an, dass sie vorher genauso hoch war (bitte nachreichen).");
        h.push({ab:D(1900,1,1), miete: vorher!==null?vorher:miete, art:"unbekannt", annahme: vorher===null});
      }
      h.push({ab:letzte, miete, art:String(a.letzte_art||"558")});
    }
  }
  h.sort((x,y)=>cmp(x.ab,y.ab));
  return [h,notizen];
}
function mieteAm(h,tag){ const v=h.filter(s=>le(s.ab,tag)); const s=v.length?v[v.length-1]:h[0]; return [s.miete,s]; }
const MOD_ARTEN=["modernisierung","mod_vereinbart"];   // § 559 und vereinbarte Modernisierungszuschläge (BGH): zählen weder für Kappung noch Sperrfrist
function kappungsbasis(h,wirksam,prozent){
  const start=plusMonate(wirksam,-36); const [aus,stand]=mieteAm(h,start); let mod=0;
  h.forEach((s,i)=>{ if(MOD_ARTEN.includes(s.art) && lt(start,s.ab) && le(s.ab,wirksam) && i>0) mod+=s.miete-h[i-1].miete; });
  return [r(aus*(1+prozent/100)+mod), aus, r(mod), start, stand];
}
function termine(z){ return {zugang:z, wirksam:plusMonate(erster(z),3), zustimmung_bis:ende(plusMonate(z,2)), klage_bis:ende(plusMonate(z,5)), kuendigung_bis:ende(plusMonate(z,2)), kuendigung_zum:ende(plusMonate(z,4))}; }
function mieterhoehung(a){
  const art=String(a.mietart||"standard").toLowerCase();
  if(["index","indexmiete"].includes(art)) throw fehler("Bei einer Indexmiete ist eine Erhöhung nach § 558 ausgeschlossen (§ 557b Abs. 2 BGB) – angepasst wird nur über den Verbraucherpreisindex.");
  if(["staffel","staffelmiete"].includes(art)) throw fehler("Während einer Staffelmiete sind Erhöhungen nach §§ 558–559b ausgeschlossen (§ 557a Abs. 2 BGB). Nach der letzten Staffel geht es wieder nach § 558.");
  const miete=f(a.miete), fl=f(a.flaeche);
  if(!miete||!fl) throw fehler("Aktuelle Nettokaltmiete und Wohnfläche fehlen.");
  let [h,notizen]=historie(a);
  if(!h.length) throw fehler("Seit wann gilt die aktuelle Miete? Ich brauche das Datum der letzten Erhöhung (oder den Mietbeginn, falls nie erhöht) – und die Miete davor.");
  if(Math.abs(h[h.length-1].miete-miete)>0.01 && !MOD_ARTEN.includes(h[h.length-1].art)){ notizen.push(`Die letzte Miete in der Historie (${e(h[h.length-1].miete)}) weicht von der aktuellen (${e(miete)}) ab – ich rechne mit der aktuellen.`); h.push({ab:heute(),miete,art:"unbekannt"}); }
  let v=null, ovmQm=f(a.ovm_qm);
  if(!ovmQm && a.baujahr && a.wohnlage){ nurBerlin(a,notizen); v=vergleichsmiete(a); ovmQm=v.qm; }
  if(!ovmQm) throw fehler("Ortsübliche Vergleichsmiete fehlt: entweder €/m² angeben oder Baujahr + Wohnlage (Berliner Mietspiegel).");
  const ovm=r(ovmQm*fl);
  const flV=f(a.flaeche_vertrag);
  if(flV && Math.abs(flV-fl)>=0.01) notizen.push(`Vertrag nennt ${m2(flV)}, gerechnet wird mit der tatsächlichen Fläche ${m2(fl)} (BGH: bei § 558 zählt die tatsächliche Wohnfläche).`);
  const relevante=h.filter(s=>!MOD_ARTEN.includes(s.art));
  const letzte=relevante.length?relevante[relevante.length-1]:h[h.length-1];
  if(letzte.art==="unbekannt" && letzte.ab.y===1900) throw fehler("Seit wann ist die Miete unverändert? (Datum der letzten Erhöhung oder Mietbeginn)");
  const fruehZugang=plusMonate(letzte.ab,12);
  const gewuenscht=datum(a.zugang)||heute();
  const zugang=maxD(gewuenscht,fruehZugang, a.zugang?gewuenscht:heute());
  if(lt(gewuenscht,fruehZugang)) notizen.push(`Ein Erhöhungsverlangen ist frühestens ein Jahr nach der letzten Erhöhung zulässig – also ab ${de(fruehZugang)}. Ich rechne mit Zugang an diesem Tag.`);
  const t=termine(zugang);
  const minWirksam=naechsterErster(plusMonate(letzte.ab,15));
  if(lt(t.wirksam,minWirksam)){ t.wirksam=minWirksam; notizen.push(`Die Miete muss beim Wirksamwerden 15 Monate unverändert sein – frühestens ab ${de(minWirksam)}.`); }
  let g=gebiet(a.ort||"",zugang); const gW=gebiet(a.ort||"",t.wirksam);
  if(!g.bekannt && !f(a.kappung_prozent)) notizen.push(`Für „${a.ort||"den Ort"}“ ist keine Verordnung hinterlegt – ich rechne mit den gesetzlichen 20 %. In Berlin und den hinterlegten Brandenburger Gemeinden gelten 15 %.`);
  if(g.status==="pruefen" && g.pruefen_text && !f(a.kappung_prozent)) notizen.push(g.pruefen_text);
  (g.hinweise||[]).forEach(x=>notizen.push(x));
  let regelwechsel=false;
  if(gW.kappung!==g.kappung && !f(a.kappung_prozent)){ regelwechsel=true; notizen.push(`Achtung Regelwechsel: Beim Zugang (${de(zugang)}) gilt ${g.kappung} %, beim Wirksamwerden (${de(t.wirksam)}) ${gW.kappung} % – Rechtslage prüfen. Ich rechne mit dem Stand beim Zugang.`); }
  const prozent=f(a.kappung_prozent)||g.kappung;
  const [kappe,aus,mod,fenster,stand]=kappungsbasis(h,t.wirksam,prozent);
  const fehlend = !!stand.annahme;
  if(!fehlend && stand.art==="unbekannt" && stand.ab.y===1900) notizen.push(`Annahme: Die Miete von ${e(aus)} galt schon am ${de(fenster)}. Gab es seitdem weitere Erhöhungen, den Mietverlauf erfassen – sonst stimmt die Kappungsgrenze nicht.`);
  t.zustimmung_werktag=werktag(t.zustimmung_bis,g.land); t.klage_werktag=werktag(t.klage_bis,g.land);
  const hoechst=Math.min(kappe,ovm), erh=r(hoechst-miete);
  let warten=null;
  for(let n=1;n<=12;n++){
    const z2=plusMonate(erster(zugang),n), w2=maxD(plusMonate(z2,3),minWirksam), k2=kappungsbasis(h,w2,prozent)[0];
    if(Math.min(k2,ovm)-hoechst>=1){ warten={zugang:z2,wirksam:w2,hoechst:Math.min(k2,ovm),plus:r(Math.min(k2,ovm)-hoechst)}; break; }
  }
  return {miete,flaeche:fl,ovm_qm:ovmQm,ovm,v,gebiet:g,prozent,kappe,ausgangsmiete:aus,ausgang_stand:stand,fenster,mod,hoechst,erhoehung:Math.max(erh,0),
    termine:t,letzte,warten,notizen,fehlend,regelwechsel,status:g.status,bindet:kappe<ovm?"Kappungsgrenze":"Vergleichsmiete",prozent_angegeben:!!f(a.kappung_prozent),mieter:a.mieter||"",adresse:a.adresse||""};
}

// ── Neuvermietung §§ 556d–556g ──
function neuvermietung(a){
  const fl=f(a.flaeche); if(!fl) throw fehler("Wohnfläche fehlt.");
  let v=null, ovmQm=f(a.ovm_qm);
  if(!ovmQm && a.baujahr && a.wohnlage){ nurBerlin(a); v=vergleichsmiete(a); ovmQm=v.qm; }
  if(!ovmQm) throw fehler("Ortsübliche Vergleichsmiete fehlt (€/m² oder Baujahr + Wohnlage).");
  const stichtag=datum(a.mietbeginn)||heute();
  const g=gebiet(a.ort||"Berlin",stichtag), ovm=r(ovmQm*fl), grenze=r(ovm*1.1);
  const wege=[["Mietpreisbremse: Vergleichsmiete + 10 %",grenze]]; const notizen=[];
  let ausnahme=null;
  if(a.neubau_ab_2014) ausnahme="Wohnung nach dem 01.10.2014 erstmals genutzt und vermietet (§ 556f S. 1 BGB) – Mietpreisbremse gilt nicht, auch bei späteren Vermietungen";
  else if(a.umfassend_modernisiert) ausnahme="erste Vermietung nach umfassender Modernisierung (§ 556f S. 2 BGB) – Mietpreisbremse gilt nicht";
  const vormiete=f(a.vormiete);
  if(vormiete) wege.push(["Vormiete (§ 556e Abs. 1 BGB; im letzten Jahr vereinbarte Erhöhungen zählen nicht, Minderungen bleiben außer Betracht)", r(vormiete-(f(a.vormiete_erhoehung_letztes_jahr)||0))]);
  const mod=f(a.modernisierung_umlage);
  if(mod){
    const vorQm=f(a.ovm_vor_mod_qm);
    const basis = vorQm ? r(r(vorQm*fl)*1.1) : grenze;
    if(!vorQm) notizen.push("Modernisierung (§ 556e Abs. 2): Maßgeblich ist die Vergleichsmiete der Wohnung OHNE die Modernisierung. Ich habe die eingegebene Vergleichsmiete genommen – enthält sie die modernisierte Ausstattung schon, zählt die Modernisierung doppelt. Feld „Vergleichsmiete vor Modernisierung“ ausfüllen.");
    wege.push([`Modernisierung in den letzten 3 Jahren (§ 556e Abs. 2): Vergleichsmiete ${vorQm?"vor Modernisierung ":""}+ 10 % + Umlage`, r(basis+mod)]);
  }
  const best=wege.reduce((x,y)=>y[1]>x[1]?y:x);
  if(g.status==="pruefen" && g.pruefen_text) notizen.push(g.pruefen_text);
  (g.hinweise||[]).forEach(x=>notizen.push(x));
  return {flaeche:fl,ovm_qm:ovmQm,ovm,v,gebiet:g,grenze,wege,best,ausnahme,wunsch:f(a.miete),moebliert:f(a.moebliert_zuschlag),notizen,stichtag};
}

// ── Modernisierung §§ 559–559f ──
function modernisierung(a){
  const kosten=f(a.kosten), fl=f(a.flaeche), vorher=f(a.miete);
  if(!kosten||!fl||!vorher) throw fehler("Ich brauche Kosten für die Wohnung (€), Wohnfläche und die Miete vor der Erhöhung.");
  const verfahren=String(a.verfahren||"normal").toLowerCase(); const foerder=f(a.foerderung)||0; const notizen=[];
  const P=MD.modernisierung; let basis=kosten;
  const wpHalb = !!a.waermepumpe && !a.jaz_nachweis && !a.wp_ausnahme;
  if(wpHalb){ basis=basis/2; notizen.push(P.text_waermepumpe); }
  let erhaltung, umlagefaehig, satz, regel, restbudget=null;
  if(verfahren.startsWith("verein")){
    const grenze=P.vereinfacht_grenze, frueher=f(a.fruehere_kosten_5j)||0;
    if(kosten+frueher>grenze) throw fehler(`Vereinfachtes Verfahren nur bis ${e(grenze)} je Wohnung (inkl. Modernisierungskosten der letzten 5 Jahre: ${e(kosten+frueher)}). ${P.vereinfacht_reform||""} Rechne normal nach § 559.`);
    restbudget=r(grenze-kosten-frueher);
    erhaltung=basis*P.vereinfacht_pauschale; umlagefaehig=basis-erhaltung-foerder; satz=P.satz_normal;
    regel=`§ 559c (vereinfacht): ${p(P.vereinfacht_pauschale*100,0)} pauschal für Erhaltung, ${p(P.satz_normal*100,0)} pro Jahr`;
  } else if(verfahren.startsWith("heiz") && foerder>0){
    erhaltung=a.ohne_pauschale ? (f(a.erhaltung)||0) : basis*P.heizung_pauschale; umlagefaehig=basis-foerder-erhaltung; satz=P.satz_heizung;
    regel=`§ 559e (Heizung mit Förderung): Förderung abziehen, ${a.ohne_pauschale?"tatsächlicher Erhaltungsanteil":p(P.heizung_pauschale*100,0)+" pauschal Erhaltung"}, ${p(P.satz_heizung*100,0)} pro Jahr`;
    if(P.text_heizung_pauschale) notizen.push(P.text_heizung_pauschale);
  } else {
    if(verfahren.startsWith("heiz")) notizen.push("Ohne in Anspruch genommene Förderung gilt für die Heizung der normale § 559 (8 %).");
    let erh=f(a.erhaltung);
    if(erh===null && a.erhaltung_prozent!==undefined && a.erhaltung_prozent!==null && a.erhaltung_prozent!=="") erh=basis*(f(a.erhaltung_prozent)||0)/100;
    if(erh===null){ erh=0; notizen.push("Erhaltungsanteil fehlt: Kosten, die auch für eine Reparatur angefallen wären (z. B. alte, abgenutzte Fenster), müssen abgezogen werden (§ 559 Abs. 2) – ich habe 0 € angesetzt."); }
    erhaltung=erh; umlagefaehig=basis-erhaltung-foerder; satz=P.satz_normal; regel=`§ 559: Kosten minus Erhaltung minus Förderung, ${p(P.satz_normal*100,0)} pro Jahr`;
  }
  umlagefaehig=Math.max(umlagefaehig,0);
  const jahrRoh=umlagefaehig*satz, jahr=r(jahrRoh), monat=r(jahrRoh/12);
  // Kappung § 559 Abs. 3a (2 €/3 € je m² in 6 Jahren; Heizung davon höchstens 0,50 €/m²) – Schwelle 7 €/m² ohne Rundung vergleichen
  const heizVerf = verfahren.startsWith("heiz") && foerder>0;
  const istHeiz = heizVerf || !!a.heizung || verfahren.startsWith("heiz");
  let heizAnteil=0; if(heizVerf) heizAnteil=1; else if(istHeiz){ const kh=f(a.kosten_heizung); heizAnteil=kh?Math.min(kh/kosten,1):1; }
  const unterSchwelle = vorher < P.kappung_schwelle*fl - 1e-9;
  const grenzeQm = unterSchwelle ? P.kappung_niedrig : P.kappung_hoch;
  const fruehEur = f(a.fruehere_mod_eur_6j)!==null ? f(a.fruehere_mod_eur_6j) : (f(a.fruehere_mod_qm_6j)||0)*fl;
  const restGesamt=Math.max(grenzeQm*fl-fruehEur,0);
  const restHeiz = istHeiz ? Math.max(P.kappung_heizung*fl-(f(a.fruehere_heiz_eur_6j)||0),0) : null;
  let fin, finHeiz=null;
  if(istHeiz){ const mh=monat*heizAnteil, mo=monat-mh; finHeiz=Math.min(mh,restHeiz); fin=Math.min(finHeiz+mo,restGesamt); finHeiz=Math.min(finHeiz,fin); }
  else fin=Math.min(monat,restGesamt);
  fin=r(fin); const gekappt=fin<monat-0.004;
  const zugang=datum(a.zugang)||heute(); let wirksam=plusMonate(erster(zugang),3);
  const angek = a.angekuendigt===undefined ? true : a.angekuendigt; const angB=f(a.angekuendigter_betrag);
  const spaeter=(angek===false) || (angB!==null && fin>angB*1.1+1e-9);
  if(spaeter) wirksam=plusMonate(wirksam,6);
  return {kosten,basis:r(basis),erhaltung:r(erhaltung),foerderung:foerder,umlagefaehig:r(umlagefaehig),satz:satz*100,jahr,monat,grenze_qm:grenzeQm,rest:r(restGesamt),final:fin,gekappt,vorher,
    neu:r(vorher+fin),flaeche:fl,regel,verfahren,zugang,wirksam,spaeter,notizen,qm_vorher:vorher/fl,unter_schwelle:unterSchwelle,heizung:istHeiz,heiz_rest:restHeiz===null?null:r(restHeiz),
    heiz_final:finHeiz===null?null:r(finHeiz),heiz_anteil:heizAnteil,frueher_eur:r(fruehEur),frueher_qm:fruehEur/fl,restbudget,wp_halb:wpHalb};
}

// ── Indexmiete § 557b ──
function vpiAlle(){ const w={}; for(const [j,reihe] of Object.entries(MD.vpi.werte)) reihe.forEach((x,i)=>{ if(x!==null) w[j+"-"+(i+1)]=x; }); for(const [k,x] of Object.entries(VPI_EXTRA)) w[k.replace(/-0(\d)$/,"-$1")]=x; return w; }
function vpi(monat){ const w=vpiAlle(); if(monat){ const x=w[monat.y+"-"+monat.m]; return x?[monat,x]:null; } const keys=Object.keys(w).map(k=>k.split("-").map(Number)).sort((a,b)=>a[0]-b[0]||a[1]-b[1]); const [j,m]=keys[keys.length-1]; return [D(j,m,1),w[j+"-"+m]]; }
function indexmiete(a){
  const miete=f(a.miete); if(!miete) throw fehler("Aktuelle Nettokaltmiete fehlt.");
  const bm=datum(a.basis_monat); const bi=f(a.basis_index)||(bm&&vpi(bm)?vpi(bm)[1]:null);
  if(!bi) throw fehler("Ausgangsindex fehlt: Monat der letzten Anpassung bzw. des Vertragsbeginns (laut Vertrag) oder den Indexwert angeben.");
  const nm=datum(a.neu_monat);
  const neu=(nm&&f(a.neu_index))?[nm,f(a.neu_index)]:(nm?vpi(nm):vpi());
  if(!neu||!neu[1]) throw fehler("Für den Monat liegt mir kein Indexwert vor – bitte angeben (destatis.de).");
  const [nmon,ni]=neu; const aend=ni/bi-1; const neuMiete=r(miete*(1+aend));
  const zugang=datum(a.zugang)||heute(); let wirksam=plusMonate(erster(zugang),2); const notizen=[];
  const letzte=datum(a.letzte_anpassung);
  if(letzte && lt(wirksam,plusMonate(letzte,12))){ wirksam=naechsterErster(plusMonate(letzte,12)); notizen.push(`Die Miete muss mindestens ein Jahr unverändert bleiben – frühestens ab ${de(wirksam)}.`); }
  const jahre = bm ? Math.max((nmon.y-bm.y)*12+nmon.m-bm.m,0)/12 : null;
  let reform=null;
  if(jahre && aend>0 && MD.reform && MD.reform.index_schwelle){
    const schwelle=Math.pow(1+MD.reform.index_schwelle,jahre)-1;
    if(aend>schwelle){ const ra=schwelle+(aend-schwelle)/2; reform={aend:ra*100,miete:r(miete*(1+ra))}; }
  }
  return {miete,basis:bi,basis_monat:bm,neu:ni,neu_monat:nmon,aend:aend*100,neu_miete:neuMiete,plus:r(neuMiete-miete),zugang,wirksam,notizen,reform,jahre,mieter:a.mieter||"",adresse:a.adresse||""};
}

// ── Vergleich Standard / Index / Staffel ──
function vergleich(a){
  const start=f(a.miete), fl=f(a.flaeche); if(!start||!fl) throw fehler("Startmiete (nettokalt) und Wohnfläche fehlen.");
  let ovmQm=f(a.ovm_qm), v=null;
  if(!ovmQm && a.baujahr && a.wohnlage){ v=vergleichsmiete(a); ovmQm=v.qm; }
  const ovm0=ovmQm?ovmQm*fl:start, jahre=Math.trunc(f(a.jahre)||10);
  const num=(k,d)=>{ const x=f(a[k]); return (x!==null?x:d)/100; };
  const inf=num("inflation",2.5), gw=num("ovm_wachstum",3.0), st=num("staffel_prozent",3.0);
  const g=gebiet(a.ort||"Berlin"); const kap=(f(a.kappung_prozent)||g.kappung)/100;
  const bremse=!!g.bremse && !a.neubau_ab_2014; const monate=jahre*12;
  const ovm=t=>ovm0*Math.pow(1+gw,t/12);
  const std=[start]; let letzte=0;
  for(let t=1;t<monate;t++){ let rr=std[std.length-1]; if(t-letzte>=15){ const basis=std[Math.max(t-36,0)]; const neu=Math.min(ovm(t),basis*(1+kap)); if(neu>rr+0.5){ rr=neu; letzte=t; } } std.push(rr); }
  const idx=[start]; for(let t=1;t<monate;t++) idx.push(t%12===0?idx[idx.length-1]*(1+inf):idx[idx.length-1]);
  const stf=[start]; const schritt=start*st;
  for(let t=1;t<monate;t++){ let rr=stf[stf.length-1]; if(t%12===0){ let ziel=rr+schritt; if(bremse) ziel=Math.max(rr,Math.min(ziel,ovm(t)*1.1)); rr=ziel; } stf.push(rr); }
  let notiz=""; if(bremse && start>ovm0*1.1+0.005) notiz=`Startmiete liegt über Vergleichsmiete + 10 % (${e(r(ovm0*1.1))}) – mit Mietpreisbremse nur zulässig mit Ausnahme (Vormiete, Modernisierung, Neubau).`;
  const res={}; for(const [n,reihe] of [["Standard (§ 558)",std],["Indexmiete",idx],["Staffelmiete",stf]]) res[n]={summe:r(reihe.reduce((s,x)=>s+x,0)),ende:r(reihe[reihe.length-1]),reihe:reihe.filter((x,i)=>i%12===0).map(r)};
  return {start,flaeche:fl,jahre,inflation:inf*100,ovm_wachstum:gw*100,staffel:st*100,kappung:kap*100,bremse,res,ovm0:r(ovm0),ovm_ende:r(ovm(monate-1)),v,notiz};
}

// ── Staffelmiete prüfen (§ 557a) ──
function staffelPruefen(a){
  const fl=f(a.flaeche); const stufen=(a.stufen||[]).map(x=>({ab:datum(x.ab),miete:f(x.miete)})).filter(x=>x.ab&&x.miete).sort((x,y)=>cmp(x.ab,y.ab));
  if(!fl||!stufen.length) throw fehler("Wohnfläche und mindestens eine Staffel (Datum + Miete in €) angeben.");
  const ovmQm=f(a.ovm_qm); const wachs=(f(a.ovm_wachstum)??0)/100; const basisDatum=stufen[0].ab; const h=heute();
  const zeilen=stufen.map((x,i)=>{
    const g=gebiet(a.ort||"Berlin",x.ab); const bremse=!!g.bremse&&!a.neubau_ab_2014;
    const abstand = i? (x.ab.y-stufen[i-1].ab.y)*12+(x.ab.m-stufen[i-1].ab.m)+(x.ab.d<stufen[i-1].ab.d?-1:0) : null;
    const jahre=Math.max(((x.ab.y-h.y)*12+(x.ab.m-h.m))/12,0);
    const grenze= ovmQm ? r(r(ovmQm*Math.pow(1+wachs,jahre)*fl)*1.1) : null;
    return {nr:i+1, ab:x.ab, miete:x.miete, abstand_monate:abstand, zu_kurz: abstand!==null && abstand<12, grenze, bremse, status:g.status,
      zu_hoch: bremse&&grenze!==null&&x.miete>grenze+0.005, prognose: lt(h,x.ab), sinkt: i>0 && x.miete<stufen[i-1].miete};
  });
  const g0=gebiet(a.ort||"Berlin",basisDatum);
  return {zeilen, bremse:zeilen.some(z=>z.bremse), gebiet:g0, wachstum:wachs*100, pruefen:zeilen.some(z=>z.status==="pruefen")};
}

root.MR = {D, datum, de, iso, monatDe, heute, plusMonate, r, zahl, e, q, p, m2, f, gebiet, istBerlin, ostWest, baualtersklasse, feldFinden, einordnen,
  vergleichsmiete, mieterhoehung, termine, kappungsbasis, neuvermietung, modernisierung, indexmiete, vpi, vpiAlle, vergleich, staffelPruefen, flaechentext, FELDER, GRUPPEN, werktag, naechsterErster, merkmalWert,
  setHeute:(d)=>{ HEUTE_OVERRIDE=d?datum(d):null; }, setVpiExtra:(o)=>{ VPI_EXTRA=o||{}; }};
})(typeof window!=="undefined"?window:globalThis);
