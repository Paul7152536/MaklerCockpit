# Erzeugt miete_daten.js (window.MR_DATEN) aus den Add-on-Daten + Korrekturen aus der Quellenprüfung
import json, sys
A = json.load(open('/tmp/mr/daten_addon.json', encoding='utf8'))
K = json.load(open('/tmp/mr/korrekturen.json', encoding='utf8')) if len(sys.argv) < 2 else {}

STAND = K.get('stand', '07.11.2026')
D = {
  'stand': STAND,
  'hinweis': 'Rechenhilfe nach Rechtsstand ' + STAND + ', keine Rechtsberatung.',
  'mietspiegel': {
    'name': 'Berliner Mietspiegel 2026', 'qualifiziert': True, 'in_kraft': '28.05.2026', 'stichtag': '01.09.2025',
    'durchschnitt': 7.71, 'abschlag_minderausstattung': 0.33, 'link': 'https://mietspiegel.berlin.de/',
    'felder': A['felder'], 'klassen': A['klassen'], 'lagen': {'e': 'einfache', 'm': 'mittlere', 'g': 'gute'},
    'tabelle': {'e': '9.1', 'm': '9.2', 'g': '9.3'}, 'klassengrenzen': {'letztes_baujahr': 2024},
    'anteil_je_gruppe': 0.2, 'merkmale': A['merkmale'],
  },
  'gebiete': {
    'berlin_bezirke': A['bezirke'], 'ost': A['ost'], 'west': A['west'], 'landkreise': A['kreise'], 'bb_gemeinden': A['bb'],
    'berlin_kappung': {'prozent': 15, 'vo': 'Kappungsgrenzenverordnung Berlin vom 14.03.2023', 'von': '2023-05-11', 'bis': '2028-05-10'},
    'berlin_bremse': {'vo': 'Mietenbegrenzungsverordnung Berlin', 'von': '2026-01-01', 'bis': '2029-12-31'},
    'bb_kappung': {'prozent': 15, 'vo': 'Kappungsgrenzenverordnung Brandenburg', 'von': '2026-01-01', 'bis': '2030-12-31'},
    'bb_bremse': {'vo': 'Mietpreisbegrenzungsverordnung Brandenburg', 'von': '2026-01-01', 'bis': '2029-12-31'},
  },
  'vpi': {'basis': '2020 = 100', 'werte': A['vpi']},
  'modernisierung': {
    'satz_normal': 0.08, 'satz_heizung': 0.10, 'vereinfacht_grenze': 10000, 'vereinfacht_pauschale': 0.30,
    'vereinfacht_reform': 'Geplant sind 20.000 € (Mietrecht II, noch nicht beschlossen).',
    'heizung_pauschale': 0.15, 'kappung_schwelle': 7, 'kappung_niedrig': 2, 'kappung_hoch': 3, 'kappung_heizung': 0.5,
    'text_waermepumpe': 'Wärmepumpe ohne Nachweis Jahresarbeitszahl ≥ 2,5 (und keine Ausnahme wie Baujahr nach 1996 oder Vorlauf ≤ 55 °C): nur die halben Kosten sind umlagefähig (§ 559f BGB).',
    'text_heizung_pauschale': 'Die 15-%-Pauschale gilt laut Gesetz nicht für bestimmte Heizungsanlagen (Verweis auf das GEG/GModG) – bei neuen Gas-/Ölheizungen prüfen.',
  },
  'reform': {'index_schwelle': 0.03, 'name': 'Mietrecht II (Entwurf)'},
  'anlaesse': A['anlaesse'], 'wissen': A['wissen'], 'quellen': A['quellen'],
}

# Korrekturen aus der Quellenprüfung (tief zusammenführen)
def merge(a, b):
    for k, v in b.items():
        if isinstance(v, dict) and isinstance(a.get(k), dict): merge(a[k], v)
        else: a[k] = v
merge(D, K.get('daten', {}))

js = '/* Mietrecht-Daten Berlin/Brandenburg – Stand ' + STAND + ' (aus addon_miete.py + Quellenprüfung) */\nwindow.MR_DATEN=' + json.dumps(D, ensure_ascii=False, separators=(',', ':')) + ';\n'
open('/tmp/mr/miete_daten.js', 'w', encoding='utf8').write(js)
print('miete_daten.js', len(js))
