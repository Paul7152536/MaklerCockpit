package de.goerner.maklercockpit.handy;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import java.nio.charset.StandardCharsets;
import java.security.KeyStore;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/** Web-App-Adresse und Schlüssel der Google-Brücke – verschlüsselt mit einem Schlüssel aus dem Android-Keystore. */
final class Tresor {
    private static final String ALIAS = "maklercockpit_tresor";
    private final SharedPreferences prefs;

    Tresor(Context c) { prefs = c.getSharedPreferences("tresor", Context.MODE_PRIVATE); }

    private SecretKey schluessel() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        if (!ks.containsAlias(ALIAS)) {
            KeyGenerator kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
            kg.init(new KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setKeySize(256)
                    .build());
            kg.generateKey();
        }
        return ((KeyStore.SecretKeyEntry) ks.getEntry(ALIAS, null)).getSecretKey();
    }

    private String verschl(String t) throws Exception {
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.ENCRYPT_MODE, schluessel());
        byte[] iv = c.getIV();
        byte[] ct = c.doFinal(t.getBytes(StandardCharsets.UTF_8));
        return Base64.encodeToString(iv, Base64.NO_WRAP) + ":" + Base64.encodeToString(ct, Base64.NO_WRAP);
    }

    private String entschl(String s) {
        try {
            if (s == null || !s.contains(":")) return "";
            String[] t = s.split(":", 2);
            Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
            c.init(Cipher.DECRYPT_MODE, schluessel(), new GCMParameterSpec(128, Base64.decode(t[0], Base64.NO_WRAP)));
            return new String(c.doFinal(Base64.decode(t[1], Base64.NO_WRAP)), StandardCharsets.UTF_8);
        } catch (Exception e) {
            return "";
        }
    }

    void speichern(String url, String key, String email) throws Exception {
        prefs.edit().putString("u", verschl(url)).putString("k", verschl(key)).putString("e", email == null ? "" : email).apply();
    }

    String url() { return entschl(prefs.getString("u", null)); }
    String key() { return entschl(prefs.getString("k", null)); }
    String email() { return prefs.getString("e", ""); }
    boolean gekoppelt() { return !url().isEmpty() && !key().isEmpty(); }
    void loeschen() { prefs.edit().clear().apply(); }
}
