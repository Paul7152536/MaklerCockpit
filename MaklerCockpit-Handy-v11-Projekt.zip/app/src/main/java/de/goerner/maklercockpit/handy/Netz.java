package de.goerner.maklercockpit.handy;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/** Einfache HTTPS-Abrufe (ohne Zusatzbibliotheken). */
final class Netz {
    static final class Antwort {
        final int status; final String text; final String url;
        Antwort(int status, String text, String url) { this.status = status; this.text = text; this.url = url; }
        boolean ok() { return status >= 200 && status < 300; }
    }

    private static String lesen(HttpURLConnection c, int max) throws Exception {
        InputStream in;
        try { in = c.getInputStream(); } catch (Exception e) { in = c.getErrorStream(); }
        if (in == null) return "";
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] b = new byte[16384];
        int n, gesamt = 0;
        while ((n = in.read(b)) > 0) { out.write(b, 0, n); gesamt += n; if (gesamt > max) break; }
        in.close();
        return out.toString(StandardCharsets.UTF_8.name());
    }

    /** POST an die Google-Brücke. Google antwortet mit einer Weiterleitung, die per GET abgeholt wird. */
    static Antwort post(String adresse, String json) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(adresse).openConnection();
        c.setInstanceFollowRedirects(false);
        c.setRequestMethod("POST");
        c.setDoOutput(true);
        c.setConnectTimeout(20000);
        c.setReadTimeout(90000);
        c.setRequestProperty("Content-Type", "text/plain;charset=utf-8");
        byte[] daten = json.getBytes(StandardCharsets.UTF_8);
        c.setFixedLengthStreamingMode(daten.length);
        OutputStream o = c.getOutputStream();
        o.write(daten);
        o.close();
        int st = c.getResponseCode();
        if (st >= 300 && st < 400) {
            String ziel = c.getHeaderField("Location");
            c.disconnect();
            if (ziel == null) return new Antwort(st, "", adresse);
            return get(ziel, null, 50_000_000);
        }
        String text = lesen(c, 50_000_000);
        c.disconnect();
        return new Antwort(st, text, adresse);
    }

    static Antwort get(String adresse, String kennung, int max) throws Exception {
        String url = adresse;
        for (int i = 0; i < 6; i++) {
            HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
            c.setInstanceFollowRedirects(false);
            c.setConnectTimeout(20000);
            c.setReadTimeout(60000);
            c.setRequestProperty("Accept", "application/json, text/html;q=0.9, */*;q=0.5");
            c.setRequestProperty("Accept-Language", "de-DE,de;q=0.9");
            if (kennung != null) c.setRequestProperty("User-Agent", kennung);
            int st = c.getResponseCode();
            if (st >= 300 && st < 400 && c.getHeaderField("Location") != null) {
                url = new URL(new URL(url), c.getHeaderField("Location")).toString();
                c.disconnect();
                if (!url.startsWith("https://") && !url.startsWith("http://")) break;
                continue;
            }
            String text = lesen(c, max);
            c.disconnect();
            return new Antwort(st, text, url);
        }
        return new Antwort(0, "", url);
    }
}
