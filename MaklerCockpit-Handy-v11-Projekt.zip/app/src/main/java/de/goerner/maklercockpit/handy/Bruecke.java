package de.goerner.maklercockpit.handy;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicReference;
import java.util.regex.Pattern;

/**
 * Brücke zwischen Oberfläche (window.pc) und Android: Daten speichern, Google-Brücke (Kalender + Abgleich),
 * Anrufen/Teilen/Drucken. Der Schlüssel der Google-Brücke verlässt diese Klasse nie.
 */
final class Bruecke {
    private static final Pattern SKRIPT_URL = Pattern.compile("^https://script\\.google\\.com/(?:a/macros/[\\w.-]+/|macros/)s/[\\w-]{20,}/exec$");
    private static final Pattern KALENDER_PFAD = Pattern.compile("^/(users/me/calendarList|calendars/[^?#\\s]+)$");
    private static final Pattern ABRUF_ERLAUBT = Pattern.compile("^https://(nominatim\\.openstreetmap\\.org|gdi\\.berlin\\.de|ogc-api\\.geobasis-bb\\.de|isk\\.geobasis-bb\\.de)/.*", Pattern.CASE_INSENSITIVE);
    private static final String KENNUNG = "MaklerCockpit-Handy/1 (Android-App, persoenliche Nutzung)";

    private final MainActivity akt;
    private final WebView web;
    private final Tresor tresor;
    private final File ordner, sicherungen;
    private final ExecutorService netz = Executors.newFixedThreadPool(3);

    Bruecke(MainActivity akt, WebView web) {
        this.akt = akt;
        this.web = web;
        this.tresor = new Tresor(akt);
        this.ordner = akt.getFilesDir();
        this.sicherungen = new File(ordner, "sicherungen");
        if (!sicherungen.exists()) sicherungen.mkdirs();
    }

    // ── Dateien ──
    private static String lies(File f) {
        try (FileInputStream in = new FileInputStream(f)) {
            byte[] b = new byte[(int) f.length()];
            int pos = 0, n;
            while (pos < b.length && (n = in.read(b, pos, b.length - pos)) > 0) pos += n;
            return new String(b, 0, pos, StandardCharsets.UTF_8);
        } catch (Exception e) {
            return null;
        }
    }

    private static boolean schreib(File f, String text) {
        File tmp = new File(f.getPath() + ".tmp");
        try (FileOutputStream o = new FileOutputStream(tmp)) {
            o.write(text.getBytes(StandardCharsets.UTF_8));
            o.getFD().sync();
        } catch (Exception e) {
            return false;
        }
        return tmp.renameTo(f);
    }

    private static String sicher(String name) { return String.valueOf(name).replaceAll("[^\\w.\\-]", "_"); }

    private void tagesSicherung() {
        try {
            File d = new File(ordner, "daten.json");
            if (!d.exists()) return;
            String tag = new SimpleDateFormat("yyyy-MM-dd", Locale.GERMANY).format(new Date());
            File z = new File(sicherungen, "daten-" + tag + ".json");
            if (!z.exists()) {
                String t = lies(d);
                // v34: nur gültige Daten als Tagessicherung ablegen
                if (t != null) { try { new JSONObject(t); schreib(z, t); } catch (Exception ungueltig) { } }
            }
            File[] alle = sicherungen.listFiles((dir, n) -> n.startsWith("daten-") && n.endsWith(".json"));
            if (alle != null && alle.length > 30) {
                Arrays.sort(alle);
                for (int i = 0; i < alle.length - 30; i++) alle[i].delete();
            }
        } catch (Exception ignored) { }
    }

    @JavascriptInterface
    public String laden() {
        File d = new File(ordner, "daten.json");
        String t = d.exists() ? lies(d) : null;
        if (t != null) {
            try { new JSONObject(t); return t; } catch (Exception e) { /* beschädigt → Sicherung */ }
            // v34: beschädigte Datei aufbewahren (wird sonst beim nächsten Speichern überschrieben)
            schreib(new File(sicherungen, "beschaedigt-" + System.currentTimeMillis() + ".json"), t);
            // zuerst die neueste Tagessicherung, dann die übrigen Sicherungen (neueste zuerst)
            File[] tage = sicherungen.listFiles((dir, n) -> n.matches("daten-\\d{4}-\\d{2}-\\d{2}\\.json"));
            if (tage != null) {
                Arrays.sort(tage);
                for (int i = tage.length - 1; i >= 0; i--) {
                    String s = lies(tage[i]);
                    try { new JSONObject(s); return s; } catch (Exception ignored) { }
                }
            }
            File[] alle = sicherungen.listFiles((dir, n) -> n.endsWith(".json") && !n.startsWith("beschaedigt-"));
            if (alle != null) {
                Arrays.sort(alle, (a, b) -> Long.compare(b.lastModified(), a.lastModified()));
                for (File f : alle) {
                    String s = lies(f);
                    try { new JSONObject(s); return s; } catch (Exception ignored) { }
                }
            }
        }
        return "null";
    }

    @JavascriptInterface
    public String speichern(String text) {
        tagesSicherung();
        return schreib(new File(ordner, "daten.json"), text) ? "{\"ok\":true}" : "{\"ok\":false,\"fehler\":\"Speichern fehlgeschlagen\"}";
    }

    @JavascriptInterface
    public String importieren(String text) {
        try {
            new JSONObject(text);
            File d = new File(ordner, "daten.json");
            if (d.exists()) { String alt = lies(d); if (alt != null) schreib(new File(sicherungen, "vor-import-" + System.currentTimeMillis() + ".json"), alt); }
            return schreib(d, text) ? "{\"ok\":true}" : "{\"ok\":false,\"fehler\":\"Schreiben fehlgeschlagen\"}";
        } catch (Exception e) {
            return "{\"ok\":false,\"fehler\":\"Keine gültigen Cockpit-Daten\"}";
        }
    }

    @JavascriptInterface
    public String sicherungSchreiben(String name, String text) {
        return schreib(new File(sicherungen, sicher(name)), text == null ? "" : text) ? "{\"ok\":true}" : "{\"ok\":false}";
    }

    @JavascriptInterface
    public String sicherungLesen(String name) {
        File f = new File(sicherungen, sicher(name));
        return f.exists() ? lies(f) : null;
    }

    @JavascriptInterface
    public String standLesen() {
        File f = new File(ordner, "abgleich-stand.json");
        return f.exists() ? lies(f) : null;
    }

    @JavascriptInterface
    public String standSchreiben(String text) {
        return schreib(new File(ordner, "abgleich-stand.json"), text == null ? "" : text) ? "{\"ok\":true}" : "{\"ok\":false}";
    }

    @JavascriptInterface
    public String standLoeschen() {
        new File(ordner, "abgleich-stand.json").delete();
        return "{\"ok\":true}";
    }

    // ── Antworten an die Oberfläche ──
    private void antwort(String id, JSONObject o) {
        final String js = "window.__mcAntwort(" + JSONObject.quote(id) + "," + JSONObject.quote(o.toString()) + ")";
        akt.runOnUiThread(() -> web.evaluateJavascript(js, null));
    }

    private static JSONObject fehler(String code, String text) {
        JSONObject o = new JSONObject();
        try { o.put("ok", false); o.put("code", code); o.put("fehler", text); } catch (Exception ignored) { }
        return o;
    }

    // ── Google-Brücke (Apps Script) ──
    private JSONObject skript(String url, String key, JSONObject nutzlast) throws Exception {
        nutzlast.put("key", key);
        Netz.Antwort a;
        try {
            a = Netz.post(url, nutzlast.toString());
        } catch (Exception e) {
            return fehler("netz", "Keine Verbindung zu Google (Internet?).");
        }
        try {
            return new JSONObject(a.text);
        } catch (Exception e) {
            if (a.status == 404) return fehler("skript_weg", "Die Web-App-Adresse gibt es nicht (mehr). Am PC neu koppeln.");
            if (a.status == 429 || a.status >= 500) return fehler("netz", "Google ist gerade überlastet – nächster Versuch automatisch.");
            if (a.text != null && a.text.contains("accounts.google.com")) return fehler("skript_zugriff", "Die Web-App verlangt eine Anmeldung – bei der Bereitstellung muss „Wer hat Zugriff: Jeder“ eingestellt sein.");
            return fehler("skript", "Unerwartete Antwort von deinem Google-Skript (HTTP " + a.status + ").");
        }
    }

    private JSONObject mitWiederholung(JSONObject nutzlast) throws Exception {
        String url = tresor.url(), key = tresor.key();
        if (url.isEmpty() || key.isEmpty()) return fehler("nicht_verbunden", "Das Handy ist noch nicht mit dem PC gekoppelt.");
        JSONObject j = null;
        for (int v = 0; v < 3; v++) {
            j = skript(url, key, new JSONObject(nutzlast.toString()));
            String code = j.optString("code", "");
            if ("schluessel".equals(code)) return fehler("abgelaufen", "Dein Google-Skript erkennt das Handy nicht mehr (Schlüssel geändert) – am PC neu koppeln.");
            if (("netz".equals(code) || "belegt".equals(code)) && v < 2) { Thread.sleep(2000L * (v + 1)); continue; }
            break;
        }
        return j;
    }

    @JavascriptInterface
    public void google(String id, String aktion, String argJson) {
        netz.execute(() -> {
            try {
                JSONObject arg = argJson == null || argJson.equals("null") ? new JSONObject() : new JSONObject(argJson);
                switch (aktion) {
                    case "status": {
                        JSONObject o = new JSONObject();
                        o.put("ok", true); o.put("modus", "skript"); o.put("eingerichtet", tresor.gekoppelt()); o.put("verbunden", tresor.gekoppelt()); o.put("email", tresor.email()); o.put("verschluesselt", true);
                        antwort(id, o); return;
                    }
                    case "api": {
                        String pfad = arg.optString("pfad", ""), methode = arg.optString("methode", "GET").toUpperCase(Locale.ROOT);
                        if (!KALENDER_PFAD.matcher(pfad).matches() || pfad.contains("..") || !Arrays.asList("GET", "POST", "PATCH", "PUT", "DELETE").contains(methode)) { antwort(id, fehler("pfad", "Pfad nicht erlaubt")); return; }
                        JSONObject n = new JSONObject();
                        n.put("methode", methode); n.put("pfad", pfad); n.put("query", arg.optJSONObject("query") == null ? new JSONObject() : arg.optJSONObject("query"));
                        if (arg.has("body") && !arg.isNull("body")) n.put("body", arg.get("body"));
                        JSONObject j = mitWiederholung(n);
                        if (j.has("code") && !j.has("status")) { antwort(id, j); return; }
                        int st = j.optInt("status", 0);
                        JSONObject o = new JSONObject();
                        o.put("ok", j.optBoolean("ok", false)); o.put("status", st); if (j.has("data")) o.put("data", j.get("data"));
                        if (!j.optBoolean("ok", false)) {
                            String grund = String.valueOf(j.opt("data"));
                            String code = st == 404 || st == 410 ? "weg" : (st == 403 && grund.matches("(?s).*(forbiddenForNonOrganizer|requiredAccessLevel|forbidden).*") ? "kein_recht" : "api");
                            o.put("code", code); o.put("fehler", code.equals("weg") ? "Nicht gefunden." : code.equals("kein_recht") ? "Diesen Termin darfst du in Google nicht ändern." : ("Google meldet Fehler " + st + (j.has("fehler") ? ": " + j.optString("fehler") : "")));
                        }
                        antwort(id, o); return;
                    }
                    case "abgleich": {
                        String a = arg.optString("aktion", "");
                        if (!Arrays.asList("abgleich", "abgleichStatus", "test").contains(a)) { antwort(id, fehler("aktion", "Aktion nicht erlaubt")); return; }
                        JSONObject n = new JSONObject();
                        n.put("aktion", a);
                        if (a.equals("abgleich")) {
                            n.put("geraet", arg.optString("geraet", "")); n.put("seit", arg.optLong("seit", 0)); n.put("ohneEigene", arg.optBoolean("ohneEigene", false));
                            n.put("aenderungen", arg.optJSONArray("aenderungen") == null ? new JSONArray() : arg.optJSONArray("aenderungen"));
                        }
                        antwort(id, mitWiederholung(n)); return;
                    }
                    case "trennen": tresor.loeschen(); antwort(id, new JSONObject().put("ok", true).put("verbunden", false)); return;
                    default: antwort(id, fehler("aktion", "Am Handy nicht verfügbar"));
                }
            } catch (Exception e) {
                antwort(id, fehler("fehler", String.valueOf(e.getMessage())));
            }
        });
    }

    @JavascriptInterface
    public void koppeln(String id, String code) {
        netz.execute(() -> {
            try {
                String c = String.valueOf(code).trim();
                if (!c.startsWith("MC1-")) { antwort(id, fehler("code", "Das ist kein gültiger Kopplungscode.")); return; }
                JSONObject d = new JSONObject(new String(Base64.decode(c.substring(4), Base64.URL_SAFE | Base64.NO_WRAP | Base64.NO_PADDING), StandardCharsets.UTF_8));
                String url = d.optString("u", ""), key = d.optString("k", ""), email = d.optString("e", "");
                if (!SKRIPT_URL.matcher(url).matches() || key.length() < 8) { antwort(id, fehler("code", "Der Kopplungscode ist unvollständig – am PC neu anzeigen lassen.")); return; }
                JSONObject t = skript(url, key, new JSONObject().put("aktion", "test"));
                if ("schluessel".equals(t.optString("code"))) { antwort(id, fehler("schluessel", "Der Schlüssel passt nicht zu deinem Google-Skript – am PC einen neuen Code anzeigen lassen.")); return; }
                if (t.has("code") && !t.has("version")) { antwort(id, t); return; }
                if (t.optInt("version", 1) < 2) { antwort(id, fehler("skript_alt", "Dein Google-Skript ist noch Version 1 – am PC unter „Handy & Abgleich“ zuerst aktualisieren.")); return; }
                tresor.speichern(url, key, email.isEmpty() ? t.optString("email", "") : email);
                antwort(id, new JSONObject().put("ok", true).put("email", tresor.email()));
            } catch (Exception e) {
                antwort(id, fehler("code", "Kopplung fehlgeschlagen: " + e.getMessage()));
            }
        });
    }

    @JavascriptInterface
    public String gekoppelt() { return tresor.gekoppelt() ? "true" : "false"; }

    @JavascriptInterface
    public void entkoppeln() { tresor.loeschen(); }

    // ── Offene Daten (Adresssuche, Wohnlage) und Seiten-Check ──
    @JavascriptInterface
    public void abruf(String id, String url) {
        netz.execute(() -> {
            try {
                if (!ABRUF_ERLAUBT.matcher(String.valueOf(url)).matches()) { antwort(id, fehler("adresse", "Adresse nicht erlaubt")); return; }
                Netz.Antwort a = Netz.get(url, KENNUNG, 5_000_000);
                antwort(id, new JSONObject().put("ok", a.ok()).put("status", a.status).put("text", a.text));
            } catch (Exception e) { antwort(id, fehler("netz", String.valueOf(e.getMessage()))); }
        });
    }

    @JavascriptInterface
    public void seite(String id, String url) {
        netz.execute(() -> {
            try {
                if (!String.valueOf(url).matches("(?i)^https?://.+")) { antwort(id, fehler("adresse", "ungültige Adresse")); return; }
                Netz.Antwort a = Netz.get(url, "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0 Mobile Safari/537.36", 1_500_000);
                antwort(id, new JSONObject().put("ok", a.ok()).put("status", a.status).put("url", a.url).put("text", a.text));
            } catch (Exception e) { antwort(id, fehler("netz", String.valueOf(e.getMessage()))); }
        });
    }

    // ── Zwischenablage, Dateien, Teilen, Drucken, Links ──
    @JavascriptInterface
    public String zwischenablage() {
        final AtomicReference<String> r = new AtomicReference<>("");
        final CountDownLatch l = new CountDownLatch(1);
        akt.runOnUiThread(() -> {
            try {
                ClipboardManager cm = (ClipboardManager) akt.getSystemService(Context.CLIPBOARD_SERVICE);
                ClipData d = cm == null ? null : cm.getPrimaryClip();
                if (d != null && d.getItemCount() > 0) { CharSequence t = d.getItemAt(0).coerceToText(akt); r.set(t == null ? "" : t.toString()); }
            } catch (Exception ignored) { }
            l.countDown();
        });
        try { l.await(); } catch (InterruptedException ignored) { }
        String t = r.get();
        return t.length() > 400000 ? t.substring(0, 400000) : t;
    }

    @JavascriptInterface
    public void dateiSpeichern(String id, String name, String base64) {
        netz.execute(() -> {
            try {
                byte[] daten = Base64.decode(base64, Base64.DEFAULT);
                if (daten.length < 4 || daten[0] != '%' || daten[1] != 'P') { antwort(id, fehler("pdf", "Die PDF-Datei war leer oder beschädigt.")); return; }
                String n = String.valueOf(name).replaceAll("[\\\\/:*?\"<>|\\x00-\\x1f]+", "_").trim();
                if (n.isEmpty()) n = "Dokument.pdf";
                if (!n.toLowerCase(Locale.ROOT).endsWith(".pdf")) n += ".pdf";
                ContentValues cv = new ContentValues();
                cv.put(MediaStore.Downloads.DISPLAY_NAME, n);
                cv.put(MediaStore.Downloads.MIME_TYPE, "application/pdf");
                cv.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/MaklerCockpit");
                Uri uri = akt.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                if (uri == null) { antwort(id, fehler("speichern", "Speichern im Download-Ordner nicht möglich.")); return; }
                try (OutputStream o = akt.getContentResolver().openOutputStream(uri)) { o.write(daten); }
                antwort(id, new JSONObject().put("ok", true).put("pfad", uri.toString()).put("name", n));
            } catch (Exception e) { antwort(id, fehler("speichern", String.valueOf(e.getMessage()))); }
        });
    }

    @JavascriptInterface
    public void dateiOeffnen(String pfad) {
        akt.runOnUiThread(() -> {
            try {
                Uri u = Uri.parse(pfad);
                if (!"content".equals(u.getScheme())) return;
                Intent i = new Intent(Intent.ACTION_VIEW).setDataAndType(u, "application/pdf").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                akt.startActivity(Intent.createChooser(i, "PDF öffnen"));
            } catch (Exception ignored) { }
        });
    }

    @JavascriptInterface
    public void teilen(String text, String titel) {
        akt.runOnUiThread(() -> {
            Intent i = new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text);
            if (titel != null && !titel.isEmpty()) i.putExtra(Intent.EXTRA_SUBJECT, titel);
            akt.startActivity(Intent.createChooser(i, "Teilen"));
        });
    }

    @JavascriptInterface
    public void drucken(String html, String titel) { akt.runOnUiThread(() -> akt.drucken(html, titel)); }

    @JavascriptInterface
    public void oeffnen(String url) { akt.runOnUiThread(() -> akt.extern(url)); }

    @JavascriptInterface
    public String sperre(String an) {
        SharedPreferences p = akt.getSharedPreferences("einstellungen", Context.MODE_PRIVATE);
        if ("1".equals(an) || "0".equals(an)) p.edit().putBoolean("sperre", "1".equals(an)).apply();
        return p.getBoolean("sperre", true) ? "true" : "false";
    }
}
