package de.goerner.maklercockpit.handy;

import android.app.Activity;
import android.app.KeyguardManager;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.hardware.biometrics.BiometricManager;
import android.hardware.biometrics.BiometricPrompt;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.MimeTypeMap;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/** MaklerCockpit fürs Handy: dieselbe Oberfläche wie am PC, aus der App heraus geladen. */
public class MainActivity extends Activity {
    static final String HOST = "app.maklercockpit.local";
    static final String START = "https://" + HOST + "/index.html";
    private static final int DATEI_WAHL = 41;
    private static final long SPERRE_NACH_MS = 5 * 60 * 1000L;

    private WebView web;
    private LinearLayout sperrBild;
    private ValueCallback<Uri[]> dateiRueckruf;
    private WebView druckWeb;
    private long imHintergrundSeit = 0;
    private boolean entsperrt = false;

    @Override
    protected void onCreate(Bundle zustand) {
        super.onCreate(zustand);
        FrameLayout rahmen = new FrameLayout(this);
        rahmen.setBackgroundColor(0xFF0A1120);
        web = new WebView(this);
        web.setBackgroundColor(0xFF0A1120);
        rahmen.addView(web, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        sperrBild = sperrBildBauen();
        rahmen.addView(sperrBild, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(rahmen);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setSupportMultipleWindows(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setTextZoom(100);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setUserAgentString(s.getUserAgentString() + " MaklerCockpitHandy/1");
        web.addJavascriptInterface(new Bruecke(this, web), "MCAndroid");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if (!HOST.equals(u.getHost())) return null;
                return asset(u.getPath());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if (HOST.equals(u.getHost())) return false;
                extern(u.toString());
                return true;
            }

            // v34: Oberfläche abgestürzt (z. B. zu wenig Speicher) → neu aufbauen statt die App zu beenden
            @Override
            public boolean onRenderProcessGone(WebView v, RenderProcessGoneDetail d) {
                if (v != web) { try { v.destroy(); } catch (Exception ignored) { } return true; }
                try { ((ViewGroup) v.getParent()).removeView(v); } catch (Exception ignored) { }
                try { v.destroy(); } catch (Exception ignored) { }
                web = null;
                Intent neu = new Intent(MainActivity.this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(neu);
                finish();
                return true;
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> rueckruf, FileChooserParams p) {
                if (dateiRueckruf != null) dateiRueckruf.onReceiveValue(null);
                dateiRueckruf = rueckruf;
                try {
                    Intent i = p.createIntent();
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    if (p.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE) i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                    startActivityForResult(i, DATEI_WAHL);
                } catch (ActivityNotFoundException e) {
                    dateiRueckruf = null;
                    return false;
                }
                return true;
            }
        });

        if (zustand != null) web.restoreState(zustand);
        else web.loadUrl(START);
        if (sperreNoetig()) entsperren(); else freigeben();
    }

    // ── Programmdateien aus der App (assets/www) unter einer festen https-Adresse ──
    private WebResourceResponse asset(String pfad) {
        if (pfad == null || pfad.isEmpty() || pfad.equals("/")) pfad = "/index.html";
        if (pfad.contains("..")) return leer(403);
        try {
            InputStream in = getAssets().open("www" + pfad);
            String endung = pfad.substring(pfad.lastIndexOf('.') + 1).toLowerCase(Locale.ROOT);
            String mime = endung.equals("js") ? "application/javascript" : endung.equals("mjs") ? "application/javascript" : endung.equals("wasm") ? "application/wasm"
                    : endung.equals("json") ? "application/json" : MimeTypeMap.getSingleton().getMimeTypeFromExtension(endung);
            if (mime == null) mime = "application/octet-stream";
            Map<String, String> kopf = new HashMap<>();
            kopf.put("Cache-Control", "no-cache");
            kopf.put("Access-Control-Allow-Origin", "https://" + HOST);
            return new WebResourceResponse(mime, mime.startsWith("text") || mime.contains("javascript") || mime.contains("json") ? "utf-8" : null, 200, "OK", kopf, in);
        } catch (Exception e) {
            return leer(404);
        }
    }

    private static WebResourceResponse leer(int status) {
        return new WebResourceResponse("text/plain", "utf-8", status, status == 404 ? "Not Found" : "Forbidden", new HashMap<>(), new ByteArrayInputStream(new byte[0]));
    }

    // ── Links nach außen: Anrufen, WhatsApp, E-Mail, Webseiten ──
    void extern(String url) {
        try {
            if (url == null) return;
            Uri u = Uri.parse(url);
            String sch = u.getScheme() == null ? "" : u.getScheme().toLowerCase(Locale.ROOT);
            Intent i;
            switch (sch) {
                case "tel": i = new Intent(Intent.ACTION_DIAL, u); break;
                case "mailto": case "sms": case "smsto": i = new Intent(Intent.ACTION_SENDTO, u); break;
                case "http": case "https": case "whatsapp": case "geo": i = new Intent(Intent.ACTION_VIEW, u); break;
                default: return;
            }
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this, "Keine passende App gefunden", Toast.LENGTH_SHORT).show();
        }
    }

    // ── Drucken / „Als PDF speichern“ (Eigentümerbericht, Briefing) ──
    void drucken(String html, String titel) {
        druckWeb = new WebView(this);
        druckWeb.getSettings().setJavaScriptEnabled(false);
        druckWeb.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) { return true; }

            @Override
            public void onPageFinished(WebView v, String url) {
                PrintManager pm = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                String name = (titel == null || titel.isEmpty() ? "MaklerCockpit" : titel).replaceAll("[\\\\/:*?\"<>|]+", "_");
                PrintDocumentAdapter ad = v.createPrintDocumentAdapter(name);
                pm.print(name, ad, new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).build());
            }
        });
        druckWeb.loadDataWithBaseURL("https://" + HOST + "/", html, "text/html", "utf-8", null);
    }

    // ── App-Sperre (Fingerabdruck, Gesicht oder Geräte-PIN) ──
    private boolean sperreNoetig() {
        boolean an = getSharedPreferences("einstellungen", Context.MODE_PRIVATE).getBoolean("sperre", true);
        KeyguardManager km = (KeyguardManager) getSystemService(Context.KEYGUARD_SERVICE);
        return an && km != null && km.isDeviceSecure();
    }

    private LinearLayout sperrBildBauen() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setGravity(Gravity.CENTER);
        l.setBackgroundColor(0xFF0A1120);
        l.setClickable(true);
        TextView t = new TextView(this);
        t.setText("🔒 MaklerCockpit ist gesperrt");
        t.setTextColor(Color.WHITE);
        t.setTextSize(20);
        t.setGravity(Gravity.CENTER);
        Button b = new Button(this);
        b.setText("Entsperren");
        b.setOnClickListener(v -> entsperren());
        l.addView(t);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = 40;
        l.addView(b, lp);
        l.setVisibility(View.GONE);
        return l;
    }

    private void freigeben() {
        entsperrt = true;
        sperrBild.setVisibility(View.GONE);
        web.setVisibility(View.VISIBLE);
    }

    @SuppressWarnings("deprecation")
    private void entsperren() {
        entsperrt = false;
        sperrBild.setVisibility(View.VISIBLE);
        web.setVisibility(View.INVISIBLE);
        BiometricPrompt.Builder b = new BiometricPrompt.Builder(this)
                .setTitle("MaklerCockpit entsperren")
                .setSubtitle("Kontaktdaten deiner Kunden sind geschützt");
        if (Build.VERSION.SDK_INT >= 30) b.setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_WEAK | BiometricManager.Authenticators.DEVICE_CREDENTIAL);
        else b.setDeviceCredentialAllowed(true);
        try {
            b.build().authenticate(new CancellationSignal(), getMainExecutor(), new BiometricPrompt.AuthenticationCallback() {
                @Override
                public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult r) { freigeben(); }

                @Override
                public void onAuthenticationError(int code, CharSequence text) { /* Sperrbild bleibt, „Entsperren“ erneut möglich */ }
            });
        } catch (Exception e) {
            freigeben();   // ohne eingerichtete Sperre am Gerät nicht aussperren
        }
    }

    // ── Lebenszyklus ──
    @Override
    protected void onPause() {
        super.onPause();
        imHintergrundSeit = System.currentTimeMillis();
        if (web == null) return;
        web.evaluateJavascript("try{ if(typeof _saveTimer!=='undefined' && _saveTimer){ clearTimeout(_saveTimer); _schreibe(); } }catch(e){}", null);
        web.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web == null) return;
        web.onResume();
        if (entsperrt && imHintergrundSeit > 0 && System.currentTimeMillis() - imHintergrundSeit > SPERRE_NACH_MS && sperreNoetig()) entsperren();
    }

    @Override
    protected void onSaveInstanceState(Bundle aus) {
        super.onSaveInstanceState(aus);
        if (web != null) web.saveState(aus);
    }

    @Override
    @SuppressWarnings("deprecation")
    protected void onActivityResult(int anfrage, int ergebnis, Intent daten) {
        super.onActivityResult(anfrage, ergebnis, daten);
        if (anfrage == DATEI_WAHL && dateiRueckruf != null) {
            Uri[] r = null;
            if (ergebnis == RESULT_OK && daten != null) {
                if (daten.getClipData() != null) {
                    r = new Uri[daten.getClipData().getItemCount()];
                    for (int i = 0; i < r.length; i++) r[i] = daten.getClipData().getItemAt(i).getUri();
                } else if (daten.getData() != null) r = new Uri[]{daten.getData()};
            }
            dateiRueckruf.onReceiveValue(r);
            dateiRueckruf = null;
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (web == null) { super.onBackPressed(); return; }
        web.evaluateJavascript("(window.h25Zurueck && window.h25Zurueck()) ? 'ja' : 'nein'", v -> {
            if (!"\"ja\"".equals(v)) moveTaskToBack(true);
        });
    }
}
