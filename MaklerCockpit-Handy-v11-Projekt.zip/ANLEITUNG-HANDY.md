# MaklerCockpit Handy v11 – so kommt die App aufs Handy

Die App zeigt dieselbe Oberfläche wie das PC-Programm (v35) und gleicht sich über **dein eigenes Google-Skript** mit dem PC ab. Kostenlos, ohne Play Store.

## 1. Am PC (einmalig)
1. `MaklerCockpit-PC-v35.exe` starten.
2. Zahnrad unten links → **Handy & Abgleich**.
3. Steht dort „Version 1“: **Code kopieren** → script.google.com → dein Projekt *MaklerCockpit Kalender* → alten Code ersetzen → speichern → **Bereitstellen → Bereitstellungen verwalten → ✎ Bearbeiten → Version: Neue Version → Bereitstellen** → Google fragt nach Zugriff auf **Google Drive** → erlauben. Danach **Prüfen**.
4. **Abgleich einschalten** – der PC lädt einmal alles in deinen Drive-Ordner „MaklerCockpit-Abgleich“.

## 2. App bauen auf GitHub (Browser, geht auch am Handy)
1. github.com → **New repository** → Name z. B. `maklercockpit-handy` → **Private** (wichtig: enthält den Signatur-Schlüssel der App).
2. **Add file → Upload files** → `MaklerCockpit-Handy-v11-Projekt.zip` hochladen → *Commit changes*.
3. **Add file → Create new file** → als Namen genau `.github/workflows/handy-app.yml` eintippen → Inhalt der Datei `handy-app.yml` einfügen → *Commit changes*.
4. **Actions** → links **Handy-App bauen** → **Run workflow** → grüner Knopf. Dauert ca. 5–8 Minuten.
5. Fertig: rechts unter **Releases** liegt `MaklerCockpit-Handy-v11.apk` (alternativ in der Actions-Ausführung unter *Artifacts*).

## 3. Auf dem Handy
1. APK herunterladen und antippen → Installation aus dieser Quelle erlauben → **Installieren**.
2. App öffnen → mit Fingerabdruck/PIN entsperren.
3. **Mit PC koppeln**: am PC unter *Handy & Abgleich* → **Kopplungscode anzeigen** → QR-Code mit der Handy-Kamera scannen → Text kopieren → in der App einfügen → **Koppeln**.
4. Die App holt alle Daten. Danach gleicht sie automatisch ab (beim Öffnen, nach Änderungen und jede Minute).

## Updates
Neue Projekt-ZIP (v2, v3 …) ins Repository hochladen, **Run workflow**, neue APK über die alte installieren – die Daten bleiben.

## Gut zu wissen
- Kopplungscode und Repository nicht weitergeben.
- Unterlagen-Dateien (PDFs), das Kleinanzeigen-Fenster und die KI-Schnittstelle gibt es nur am PC. Berichte druckst du am Handy über „Drucken → Als PDF speichern“.
- Termine, die du am Handy anlegst, trägt das Handy selbst in deinen Google Kalender ein (Kalender vom PC wird übernommen). Termine, die nur in Google entstehen, holt der PC.
- Ändern PC und Handy gleichzeitig dasselbe Feld, gewinnt die neuere Änderung; das steht im Abgleich-Protokoll (Handy & Abgleich → Protokoll).

## Update auf v11 (von einer älteren Version)
Hattest du schon eine ältere Version gebaut: `MaklerCockpit-Handy-v11-Projekt.zip` zusätzlich ins Repository hochladen (ältere ZIPs dürfen liegen bleiben – der Workflow nimmt automatisch die neueste), **Run workflow**, APK über die alte installieren.
